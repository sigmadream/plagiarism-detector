//
//  main.c
//  c
//
//  Created by seunggu on 27/03/2019.
//  Copyright © 2019 seunggu. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int n, sum = 0;
    while (scanf("%d", &n) == 1){
        int lastDigit = n % 10;
        sum += lastDigit;
    }
    printf("%d\n", sum);
    
    return 0;
}
