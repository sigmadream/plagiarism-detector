#include <stdio.h>

int main(){
int mysum =0, n=0;

while(scanf("%d", &n) == 1)

    mysum += n % 10;

printf("%d", mysum);

return 0;
}
