#include<stdio.h>

int main()
{
    int sum=0, n=0;
    int m =0;
    while(scanf("%d",&n)==1){
        m = n%10;
        sum+=m;}
    printf("%d",sum);

}
