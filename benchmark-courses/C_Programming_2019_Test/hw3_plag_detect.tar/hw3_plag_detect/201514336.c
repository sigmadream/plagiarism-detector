#include <stdio.h>

int main()
{
    int mysum = 0;
    int n = 0;
    int x = 0;
    int y = 10;
    int z = 0;

    while (scanf("%d", &x) == 1) {
        mysum = x%y;
        z = z + mysum;
        }

    printf("%d", z);

    return 0;
}
