#include <stdio.h>

int main()
{
    int sum = 0, n = 0;

    while (scanf("%d", &n) == 1)
    {
        while ( n > 9 )
        {
                n = n%10;
        }
        sum += n;
    }

    printf("%d", sum);

    return 0;
}
