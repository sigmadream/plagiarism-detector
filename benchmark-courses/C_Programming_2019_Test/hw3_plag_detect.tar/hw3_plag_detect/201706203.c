#include <stdio.h>

int main(){
	
	int sum = 0,n = 0, m = 0;
	
	while(scanf("%d", &n)==1){
		m = n%10;
		sum += m;
	}
	printf("%d\n", sum);	
	return 0;
}
