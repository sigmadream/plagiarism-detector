#include <stdio.h>

int main()
{
    int sum = 0, n = 0, d = 0;

    while (scanf("%d", &n) == 1){
        d = n % 10;
        sum += d;
    }
    printf("%d\n", sum);

    return 0;
}
