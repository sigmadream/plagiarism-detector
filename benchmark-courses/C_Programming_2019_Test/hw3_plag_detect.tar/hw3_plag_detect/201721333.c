#include<stdio.h>

int main()
{
    int n;
    int sum=0;
    int rem;

    while(scanf("%d",&n)==1)
        sum+=(n%10);

    printf("%d",sum);

    return 0;
}
