#include <stdio.h>

int main()
{
    int sum = 0;
    int n = 0;

    while (scanf("%d", &n) == 1)
        sum += n%10;
    printf("%d", sum);


    return 0;


}
