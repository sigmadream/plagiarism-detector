/*
#include <stdio.h>

int main()
{
    int sum = 0, n = 0;
    FILE *inf = fopen("sum_data.inp", "r");
    FILE *outf = fopen("sum.out", "w");

    while (fscanf(inf, "%d", &n) == 1)
        fprintf(outf, "Last input : %d\tTotal Sum : %d\n", n, sum += n);

    printf("%d", printf("Hello"));

    fclose(outf);
    fclose(inf);
    return 0;
}

*/
#include <stdio.h>

int main ()
{
    int sum, input;

    sum = 0;
    input = 0;

    while (scanf("%d", &input) == 1)
    {

        while (input > 9)
            input =  input % 10;

        sum += input;

    }

    printf("%d", sum);
    return 0;
}

