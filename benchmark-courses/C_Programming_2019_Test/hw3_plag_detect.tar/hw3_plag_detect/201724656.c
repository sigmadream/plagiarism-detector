#include <stdio.h>

int main(){
    int sum = 0, n = 0;
    FILE *outf = fopen("output.txt","w");

    while (fscanf(stdin, "%d", &n) != EOF){
        n %= 10;
        sum += n;
    }

    fprintf(stdout, "%d\n",sum);
    fprintf(outf,"%d\n",sum);
    fclose(outf);
    return 0;
}
