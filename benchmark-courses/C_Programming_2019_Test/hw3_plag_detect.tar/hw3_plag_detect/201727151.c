#include <stdio.h>

int main()
{
    int sum = 0, n = 0, outp = 0;

    while (scanf("%d", &n) == 1){
        outp = n % 10;
        sum += outp;
    }
        printf("%d\n", sum);

    return 0;
}
