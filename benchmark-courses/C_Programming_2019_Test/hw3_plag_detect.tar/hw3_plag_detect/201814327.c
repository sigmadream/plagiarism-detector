#include <stdio.h>

int main()
{
    int sum = 0, n = 0;
    int d;

    while (scanf("%d", &n) == 1){

        d = n % 10;
        sum += d;
    }

    printf("%d", sum);

    return 0;
}
