#include <stdio.h>

int main(){
    int sum=0,n=0;
    while(fscanf(stdin,"%d",&n)){
        sum+=n%10;
    }
    fprintf(stdout,"%d",sum);
    return 0;
}
