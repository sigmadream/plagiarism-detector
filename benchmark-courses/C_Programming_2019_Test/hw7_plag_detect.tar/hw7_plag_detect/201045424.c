#include <stdio.h>
#include <string.h>

void vowelCalculate(int vowel[], char line[])
{
    int index = 0;
    while (line[index] != '\0') {
        char ch = line[index];

        switch (ch) {
            case 'A':
            case 'a':
                vowel[0]++;
                break;

            case 'E':
            case 'e':
                vowel[1]++;
                break;

            case 'I':
            case 'i':
                vowel[2]++;
                break;

            case 'O':
            case 'o':
                vowel[3]++;
                break;

            case 'U':
            case 'u':
                vowel[4]++;
                break;

            default:
                break;
        }
        index++;
    }
}

int main()
{

    char line[256];
    char result[100][5];

    while (fgets(line, 256, stdin) != NULL) {
        // a, e, i, o, u sequence
        int vowel[5] = { 0, 0, 0, 0, 0 } ;
        vowelCalculate(vowel, line);
        printf("%d %d %d %d %d \n", vowel[0], vowel[1], vowel[2], vowel[3], vowel[4]);
    }

    return 0;
}
