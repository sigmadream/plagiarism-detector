#include <stdio.h>
#include <string.h>

int main()
{
	char line[256];
	int nlines = 0;
	while (fgets(line, 256, stdin) != NULL) 
	{
		int vindex[] = { 0, 0, 0, 0, 0 };
		for (int i = 0; i < strlen(line); i++)
		{
			switch (line[i])
			{
			case 'a':
			case 'A':
				vindex[0]++;
				break;
			case 'e':
			case 'E':
				vindex[1]++;
				break;
			case 'i':
			case 'I':
				vindex[2]++;
				break;
			case 'o':
			case 'O':
				vindex[3]++;
				break;
			case 'u':
			case 'U':
				vindex[4]++;
				break;
			}
		}
		for (int i = 0; i < 5; i++)
		{
			printf("%d ", vindex[i]);
			if (i == 4)
				printf("\n");
		}
	}

	return 0;
}