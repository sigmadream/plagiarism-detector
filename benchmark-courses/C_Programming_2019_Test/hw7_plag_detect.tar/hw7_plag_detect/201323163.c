#include <stdio.h>
#include <ctype.h>

int main(){

    char str[100];
    int count[100] = {0,};
    int k = 0;
    int i = 0;
    char letter;
    while(fgets(str, 101, stdin) != NULL){
        while(str[i] != '\0'){
            letter = str[i];
            if(isupper(letter)){
                letter = tolower(letter);
            }
            switch(letter){
            case 'a':
                count[k]++;
                break;
            case 'e':
                count[k+1]++;
                break;
            case 'i':
                count[k+2]++;
                break;
            case 'o':
                count[k+3]++;
                break;
            case 'u':
                count[k+4]++;
                break;
            }
            i++;
        }
        k += 5;
        i = 0;
    }
    for(int j=0; j<k; j++){
        if(j%5 == 0 && j != 0){
            printf("\n");
        }
        printf("%d ", count[j]);
    }
    return 0;
}
