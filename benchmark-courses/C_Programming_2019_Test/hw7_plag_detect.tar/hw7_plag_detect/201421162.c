#include <stdio.h>
#include <string.h>


int main() {

    char line[256];
    int nlines = 0;

    while (fgets(line, 256, stdin) != NULL) {
        vowel_count(line,strlen(line));

    }

    return 0;
}

void vowel_count(char line[], int length){

int A_count = 0;
int E_count = 0;
int I_count = 0;
int O_count = 0;
int U_count = 0;


for (int i = 0; i < length; ++i){
    switch(line[i]){
        case 'a':
        case 'A':
            A_count++; break;
        case 'e':
        case 'E':
            E_count++; break;
        case 'i':
        case 'I':
            I_count++; break;
        case 'o':
        case 'O':
            O_count++; break;
        case 'u':
        case 'U':
            U_count++; break;

    }

}

printf("%d %d %d %d %d \n", A_count, E_count, I_count, O_count, U_count);
}
