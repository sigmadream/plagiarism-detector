#include <stdio.h>

int main()
{
char sen[255];
char *msg1=&sen[0];
char *msg2=&sen[0];
char *msg3=&sen[0];
char *msg4=&sen[0];
char *msg5=&sen[0];

int i1=0;
int i2=0;
int i3=0;
int i4=0;
int i5=0;




int arr[5] = {0, };

while (fgets(sen, 256, stdin) != NULL) {


while(*msg1!=NULL)
    {
            if(*msg1=='a' || *msg1=='A')
                arr[0] += 1;
            if(*msg1=='e' || *msg1=='E')
                arr[1] += 1;
            if(*msg1=='i' || *msg1=='I')
                arr[2] += 1;
            if(*msg1=='o' || *msg1=='O')
                arr[3] += 1;
            if(*msg1=='u' || *msg1=='U')
                arr[4] += 1;
            msg1++;
        }



switch(1)
{
case 1:
    for(int i=0;i<5;i++)
        printf("%d ",arr[i]);
    puts("");
    //for(int i=0;i<5;i++) arr[i] = 0;
    *msg1=&sen[0];
    break;
default :
    break;

}
}


return 0;
}
