#include <stdio.h>
#include <string.h>

int main()
{
    char line[256];
    while (fgets(line,256,stdin)!=NULL){
        char *buf=line;
        int a=0,b=0,c=0,d=0,e=0;
        while(*buf != '\0'){
            switch(toupper(*buf)){
            case 65:
                a++;
                break;
            case 69:
                b++;
                break;
            case 73:
                c++;
                break;
            case 79:
                d++;
                break;
            case 85:
                e++;
                break;
            }
            buf++;
        }
        printf("%d %d %d %d %d \n",a,b,c,d,e);
    }

    return 0;
}
