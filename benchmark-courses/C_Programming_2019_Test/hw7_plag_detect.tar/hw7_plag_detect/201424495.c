#include <stdio.h>
#include <string.h>

int main()
{
    char line[256];
    int i;
    int v[5] = {0,0,0,0,0};

    while(fgets(line, 256, stdin) != NULL){
        for(i=0; line[i] != NULL; i++){
            switch(line[i]){
                case 'A' :
                    v[0]++;
                    continue;
                case 'a' :
                    v[0]++;
                    continue;
                case 'E' :
                    v[1]++;
                    continue;
                case 'e' :
                    v[1]++;
                    continue;
                case 'I' :
                    v[2]++;
                    continue;
                case 'i':
                    v[2]++;
                    continue;
                case 'O' :
                    v[3]++;
                    continue;
                case 'o' :
                    v[3]++;
                    continue;
                case 'U' :
                    v[4]++;
                    continue;
                case 'u':
                    v[4]++;
                    continue;
            }
        }
       printf("%d %d %d %d %d \n",v[0],v[1],v[2],v[3],v[4]);
       for(int j=0;j<5;j++)
        v[j]=0;

    }


    return 0;
}
