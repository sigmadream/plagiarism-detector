#include <stdio.h>
#include <string.h>

int main()
{
    char line[256];
    int a_num1=0;
    int a_num2=0;
    int e_num1=0;
    int e_num2=0;
    int i_num1=0;
    int i_num2=0;
    int o_num1=0;
    int o_num2=0;
    int u_num1=0;
    int u_num2=0;


    while (fgets(line, 256, stdin) != NULL) {

        a_num1=0;
        a_num2=0;
        e_num1=0;
        e_num2=0;
        i_num1=0;
        i_num2=0;
        o_num1=0;
        o_num2=0;
        u_num1=0;
        u_num2=0;
         for(int i=0;line[i]!=NULL;i++)
        {
            switch(line[i]) {
            case 'A':
                a_num1 = a_num1 + 1;
                continue;
            case 'a':
                a_num2 = a_num2 + 1;
                continue;
            case 'E':
                e_num1 = e_num1 + 1;
                continue;
            case 'e':
                e_num2 = e_num2 + 1;
                continue;
            case 'I':
                i_num1 = i_num1 + 1;
                continue;
            case 'i':
                i_num2 = i_num2 + 1;
                continue;
            case 'O':
                o_num1 = o_num1 + 1;
                continue;
            case 'o':
                o_num2 = o_num2 + 1;
                continue;
            case 'U':
                u_num1 = u_num1 + 1;
                continue;
            case 'u':
                u_num2 = u_num2 + 1;
                continue;
            default:
                break;
            }
        }
    printf("%d %d %d %d %d \n", a_num2+a_num1,e_num2+e_num1,i_num2+i_num1,o_num2+o_num1,u_num2+u_num1);



    }


    return 0;
}
