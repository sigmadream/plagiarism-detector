#include <stdio.h>
#include <string.h>
int main(void)
{
    int i;
    char line[256];
    int ans[5] = {0, 0, 0, 0, 0};
    while (fgets(line, 256, stdin) != NULL) {
        for (i = 0; i < strlen(line); ++i){
            if (line[i] >= 'a' && line[i] <= 'z')
                line[i] -= 32;
            switch (line[i]){
                case 'A' : ans[0] += 1; break;
                case 'E' : ans[1] += 1; break;
                case 'I' : ans[2] += 1; break;
                case 'O' : ans[3] += 1; break;
                case 'U' : ans[4] += 1; break;
            }
        }
        for (i = 0; i < 5; ++i){
            printf("%d ", ans[i]);
            ans[i] = 0;
        }
        printf("\n");
    }
    return 0;
}

