#include <stdio.h>
#include <string.h>

int main()
{
    char line[256];

    while (fgets(line, 256, stdin) != EOF){
        int b[5] = {0,0,0,0,0};
        for (int i=0; i < strlen(line); i++){
        switch (line[i]){
        case 'a':
            b[0] = b[0] + 1; break;
        case 'e':
            b[1] = b[1] + 1; break;
        case 'I':
        case 'i':
            b[2] = b[2] + 1; break;
        case 'o':
            b[3] = b[3] + 1; break;
        case 'u':
            b[4] = b[4] + 1; break;
        }
        }
    printf("%d %d %d %d %d\n", b[0], b[1], b[2], b[3], b[4]);
    }
    return 0;
}

