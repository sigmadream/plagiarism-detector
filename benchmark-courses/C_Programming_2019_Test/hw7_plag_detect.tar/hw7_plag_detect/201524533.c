#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
	char line[256];
	char p;
	
	while (fgets(line, 256, stdin) != NULL) {
		int vowel[5] = {0, };
		int i;
		
		for(i = 0; i < strlen(line); i++) {
			p = tolower(line[i]);
			
			switch (p) {
				case 'a' : ++vowel[0];
						   break;
				case 'e' : ++vowel[1];
						   break;	
				case 'i' : ++vowel[2];
						   break;		
				case 'o' : ++vowel[3];
						   break;			
				case 'u' : ++vowel[4];
						   break;
						   
				default  : break;
			}
		}
		
		printf("%d %d %d %d %d \n", vowel[0], vowel[1], vowel[2], vowel[3] ,vowel[4]);
	}
	
	return 0;
}
