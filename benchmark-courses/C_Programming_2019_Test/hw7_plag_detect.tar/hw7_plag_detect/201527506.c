#include <stdio.h>
#include <ctype.h>
 
int main(void)
{
	char c;
	char Input[256] = {0,};
	int Result[5] = {0,};
	int i;
	int len;
	
	while( fgets(Input, 256, stdin) != NULL )
	{
		len = sizeof(Input) / sizeof(Input[0]);
		for(i=0; i<len ; ++i)
		{
			switch(Input[i])
			{
				case 'A':
					++Result[0];
					break;
				case 'a':
					++Result[0];
					break;
				case 'E':
					++Result[1];
					break;
				case 'e':
					++Result[1];
					break;
				case 'I':
					++Result[2];
					break;
				case 'i':
					++Result[2];
					break;
				case 'O':
					++Result[3];
					break;
				case 'o':
					++Result[3];
					break;
				case 'U':
					++Result[4];
					break;
				case 'u':
					++Result[4];
					break;
			}
		}
	
	for(i=0; i<5; ++i)
	{
		printf("%d ", Result[i]);
	}
	printf("\n");
	for(i=0; i<5; ++i)
	{
		Result[i] = 0;
	}
	for(i=0; i<len; ++i)
	{
		Input[i] = 0;
	}
		
}

	

	
	return 0;
}

    




