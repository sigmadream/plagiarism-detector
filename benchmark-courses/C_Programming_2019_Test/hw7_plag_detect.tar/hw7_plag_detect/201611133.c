#include <stdio.h>

int A (char line[]);
int E (char line[]);
int I (char line[]);
int O (char line[]);
int U (char line[]);

int main ()
{
    char line[256];
    int i = 1;
    while(fgets(line,256,stdin) != NULL){
        int vowel[5] = {0, 0, 0, 0, 0};
        i = 1;
        while(i != 6){

            switch(i){
            case 1:
            vowel[0] = A(line);
            i++;
            break;
            case 2:
            vowel[1] = E(line);
            i++;
            break;
            case 3:
            vowel[2] = I(line);
            i++;
            break;
            case 4:
            vowel[3] = O(line);
            i++;
            break;
            case 5:
            vowel[4] = U(line);
            i++;
            break;
            default:
            break;
            }
        }
        /*vowel[0] = A(line);

        vowel[1] = E(line);

        vowel[2] = I(line);

        vowel[3] = O(line);

        vowel[4] = U(line);*/

        printf("%d %d %d %d %d \n",vowel[0],vowel[1],vowel[2],vowel[3],vowel[4]);
    }

    return 0;
}

int A (char line[])
{
    int a = 0;
    int i = 0;
    int c = 0;
    while (line[i] != '\0'){
        c++;
        i++;
    }
    for(i=0;i<=c;i++){
        if ((line[i]=='A')||(line[i]=='a'))
            a++;
    }
    return a;
}
int E (char line[])
{
    int e = 0;
    int i = 0;
    int c = 0;
    while (line[i] != '\0'){
        c++;
        i++;
    }
    for(i=0;i<=c;i++){
        if ((line[i]=='E')||(line[i]=='e'))
            e++;
    }
    return e;
}
int I (char line[])
{
    int I = 0;
    int i = 0;
    int c = 0;
    while (line[i] != '\0'){
        c++;
        i++;
    }
    for(i=0;i<=c;i++){
        if ((line[i]=='I')||(line[i]=='i'))
            I++;
    }
    return I;
}
int O (char line[])
{
    int o = 0;
    int i = 0;
    int c = 0;
    while (line[i] != '\0'){
        c++;
        i++;
    }
    for(i=0;i<=c;i++){
        if ((line[i]=='O')||(line[i]=='o'))
            o++;
    }
    return o;
}
int U (char line[])
{
    int u = 0;
    int i = 0;
    int c = 0;
    while (line[i] != '\0'){
        c++;
        i++;
    }
    for(i=0;i<=c;i++){
        if ((line[i]=='U')||(line[i]=='u'))
            u++;
    }
    return u;
}
