#include <stdio.h>

int main()
{
    char line[256];
    int i = 0; int k = 0; int j = 0;
    char vowel;
    int a[100];

    while (fgets(line, 256, stdin) != NULL){
            int Acount = 0, Ecount = 0, Icount = 0, Ocount = 0, Ucount = 0, count = 0; int i = 0;

            while (line[i] != '\0') {
                vowel = line[i];
                switch (vowel) {
                case ('A'):
                    Acount = Acount + 1; break;
                case ('E'):
                    Ecount = Ecount + 1; break;
                case ('I'):
                    Icount = Icount + 1; break;
                case ('O'):
                    Ocount = Ocount + 1; break;
                case ('U'):
                    Ucount = Ucount + 1; break;
                case ('a'):
                    Acount = Acount + 1; break;
                case ('e'):
                    Ecount = Ecount + 1; break;
                case ('i'):
                    Icount = Icount + 1; break;
                case ('o'):
                    Ocount = Ocount + 1; break;
                case ('u'):
                    Ucount = Ucount + 1; break;
                default:
                    break;
                }
            i++;
        }
        a[k] = Acount; a[k+1] = Ecount; a[k+2] = Icount; a[k+3] = Ocount; a[k+4] = Ucount;
        k += 5;
    }
    a[k] = 1000;

    while (a[j] != 1000) {
        if (j % 5 == 0 && j != 0)
            printf("\n%d ", a[j]);
        else
            printf("%d ", a[j]);
        j ++;
    }

    return 0;
}
