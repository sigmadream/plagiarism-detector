#include <stdio.h>
#include <string.h>

int main()
{
    char line[256]={NULL};
    char vowel;
    int q, nlines = 0;

    while (fgets(line, 256, stdin) != NULL) {
        int a=0,e=0,i=0,o=0,u=0;
        int n = strlen(line);
        for (q = 0; q < n; q++){
        switch (line[q]) {
        case 'a':
            a = a+1;
            break;
        case 'A':
            a = a+1;
            break;
        case 'e':
            e = e+1;
            break;
        case 'E':
            e = e+1;
            break;
        case 'I':
            i = i+1;
            break;
        case 'i':
            i = i+1;
            break;
        case 'o':
            o = o+1;
            break;
        case 'O':
            o = o+1;
            break;
        case 'u':
            u = u+1;
            break;
        case 'U':
            u = u+1;
            break;

            }
        }
        printf("%d %d %d %d %d \n", a,e,i,o,u);
    }
    //printf("-- %d lines have been processed. --\n", nlines);
    return 0;
}

