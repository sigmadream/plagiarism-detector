#include <stdio.h>
#include <string.h>

int main()
{
    char line[256];
    int A = 0, E = 0, I = 0, O = 0, U = 0;
    int count;
    while (fgets(line, 256, stdin) != NULL) {
    for(int i = 0; i < strlen(line); i++){
        switch(line[i]){
        case 'A':
        case 'a':
            A++;
            break;
        case 'E':
        case 'e':
            E++;
            break;
        case'I':
        case 'i':
            I++;
            break;
        case 'O':
        case 'o':
            O++;
            break;
        case 'U':
        case 'u':
            U++;
            break;
        }

    }
        printf("%d %d %d %d %d \n", A, E, I, O, U);
        A = 0, E = 0, I = 0, O = 0, U = 0;
    }


    return 0;
}
