#include <stdio.h>
#include <string.h>

int main()
{
    char line[256];
    int va=0,ve=0,vi=0,vo=0,vu=0;

    while (fgets(line, 256, stdin) != NULL) {

    for (int i=0; i<strlen(line); i++){
    switch(line[i]){
    case 'a': case 'A':
        ++ va; break;
    case 'e': case 'E':
        ++ ve; break;
    case 'i': case 'I':
        ++ vi; break;
    case 'o': case 'O':
        ++ vo; break;
    case 'u': case 'U':
        ++ vu; break;
    }
    }
    printf("%d %d %d %d %d \n", va,ve,vi,vo,vu);
    va=0,ve=0,vi=0,vo=0,vu=0;}
    return 0;
}
