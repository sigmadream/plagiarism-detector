#include<stdio.h>
#include<string.h>
int main()
{
	char s[256];
    while (fgets(s, 256, stdin) != NULL){
        int n,a=0,e=0,i=0,o=0,u=0,k;
        n=strlen(s);
        for(k=0;k<n;k++)
        {
            switch(s[k])
            {
                case 'a':a++;break;
                case 'A':a++;break;
                case 'e':e++;break;
                case 'E':e++;break;
                case 'i':i++;break;
                case 'I':i++;break;
                case 'o':o++;break;
                case 'O':o++;break;
                case 'u':u++;break;
                case 'U':u++;break;
            }
        }
    printf("%d %d %d %d %d \n",a,e,i,o,u);
    }

	return 0;
}
