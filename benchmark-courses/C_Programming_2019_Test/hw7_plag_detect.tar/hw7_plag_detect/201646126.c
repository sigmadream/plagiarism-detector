#include <stdio.h>
#include <string.h>

int main()
{

    char line[256];
    int nlines = 0;
    while (fgets(line, 256, stdin) != NULL) {
        int a = 0;
        int b = 0;
        int c = 0;
        int d = 0;
        int e = 0;
        for (int i =0; i < strlen(line); ++i){
            switch(line[i]){
            case 'a':
            case 'A':
                a = a+1;break;
            case 'e':
            case 'E':
                b = b+1;break;
            case 'i':
            case 'I':
                c = c+1;break;
            case 'o':
            case 'O':
                d = d+1;break;
            case 'u':
            case 'U':
                e = e+1;break;

        }
    }


        printf("%d %d %d %d %d \n", a, b, c, d, e);
    }

    return 0;
}
