#include <stdio.h>
#include <string.h>

int main(){
	char line[256];
	int s = 0;
	int a1 = 0, e1 = 0, i1 = 0, o1 = 0, u1 = 0;
	int vowels[100] = {0,};
	int q = 0;
	int k = 0;
	
	while(fgets(line, 256, stdin) != NULL){
		for(s = 0; s < strlen(line); s++){
			switch (line[s]) {
				case 'a':
					++vowels[q]; break; 
				case 'e': 
					++vowels[q+1]; break;
				case 'i':
					++vowels[q+2]; break;
				case 'o':
					++vowels[q+3]; break;
				case 'u':
					++vowels[q+4]; break;
			}
		}
		q += 5;
	}
	for( k = 0 ; k < q ; k++ ){
		if ( k % 5 == 0 && k != 0){
			printf("\n");
		}
		printf("%d ", vowels[k]);
	}
	
	return 0;
}
