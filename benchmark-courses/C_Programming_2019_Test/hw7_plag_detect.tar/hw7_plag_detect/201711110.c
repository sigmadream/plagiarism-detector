#include <stdio.h>
#include <string.h>

int main(){
    char line[256];

    int A=0,E=0,I=0,O=0,U=0,i=0;


    while (fgets(line, 256, stdin) != NULL) {
        swtich(line[i]){
            case 'a':
                A=A+1;
                i++;
                break;

            case 'e':
                E=E+1;
                i++;
                break;
            case 'a':
                I=I+1;
                i++;
                break;
            case 'a':
                O=O+1;
                i++;
                break;
            case 'a':
                U=U+1;
                i++;
                break;
            default :
                i++;

        }
    }


    printf("%d %d %d %d %d ",A,E,I,O,U);
    return 0;
}
