#include <stdio.h>
#include <string.h>

int main(){

     char line[256];

     int A=0, E=0, I=0, O=0, U=0, i=0;

     switch(line[i]){
        case 'a':
            A++;
            break;
        case 'e':
            E++;
            break;
        case 'i':
            I++;
            break;
        case 'o':
            O++;
            break;
        case 'u':
            U++;
            break;
        default:
            i++;

    }

    printf("%d %d %d %d %d", A,E,I,O,U);
    return 0;

}
