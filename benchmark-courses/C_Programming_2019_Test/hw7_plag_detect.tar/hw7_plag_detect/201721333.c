#include <stdio.h>
#include <string.h>

void vindex(char line[])
{
    int i=0;
    int c1=0,c2=0,c3=0,c4=0,c5=0;
    char c=line[i];
    while(line[i]!='\0'){

        if (line[i]=='a'||line[i]=='A')
            c1++;
        else if (line[i]=='e'||line[i]=='E')
            c2++;
        else if (line[i]=='i'||line[i]=='I')
            c3++;
        else if (line[i]=='o'||line[i]=='O')
            c4++;
        else if (line[i]=='u'||line[i]=='U')
            c5++;

        c=line[i++];
    }
    switch(i){
        case 0: break;
        default: printf("%d %d %d %d %d \n",c1,c2,c3,c4,c5); break;
    }

}

int main()
{
    char line[256];
    while (fgets(line, 256, stdin) != NULL)
        vindex(line);

    return 0;
}
