#include <stdio.h>

typedef struct {
    int a;
    int e;
    int i;
    int o;
    int u;
} nVwl;

nVwl cntVwl(char snt[])
{
    int i = 0;
    int na = 0, ne = 0, ni = 0, no = 0, nu = 0;
    while (snt[i] != '\0') {
        switch (snt[i]) {
            case 'A':
            case 'a':
                na ++; break;
            case 'E':
            case 'e':
                ne ++; break;
            case 'I':
            case 'i':
                ni ++; break;
            case 'O':
            case 'o':
                no ++; break;
            case 'U':
            case 'u':
                nu ++; break;
            default:
                break;
        }
        i ++;
    }
    nVwl X = {na, ne, ni, no, nu};
    return X;
}

int main()
{
    char line[256];
    int ans[80];
    int i = 0, k = 0;
    nVwl V;

    while (fgets(line, 256, stdin) != NULL) {
        V = cntVwl(line);
        ans[i] = V.a;
        ans[i+1] = V.e;
        ans[i+2] = V.i;
        ans[i+3] = V.o;
        ans[i+4] = V.u;
        i = i + 5;
    }
    ans[i] = 777;
    while (ans[k] != 777) {
        if (k % 5 == 0 && k != 0)
            printf("\n%d ", ans[k]);
        else
            printf("%d ", ans[k]);
        k ++;
    }

    return 0;
}
