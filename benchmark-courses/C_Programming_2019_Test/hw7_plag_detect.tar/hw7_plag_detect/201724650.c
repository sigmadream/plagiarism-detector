#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

int vowelnum(char a[], int x);

int main()
{
	/*
	char line[256];
	int nlines = 0;
	while (fgets(line, 256, stdin) != NULL) {
		printf("%3d(%3d): %s", += 1;nlines, strlen(line), line);
	}
	printf("-- %d lines have been processed. --\n", nlines);
	*/
	char str[256];
	int result[5];

	while (fgets(str, 256, stdin) != NULL)
	{
		for (int i = 0; i < 5; i ++)
			printf("%d ", vowelnum(str, i));
		printf("\n");
	}

	return 0;
}

int vowelnum(char a[], int x)
{
	int arrcount = 0;
	int result[5] = { 0,0, 0, 0, 0 };
	int count = 0;

	while (a[count] != '\0')
	{
		switch (a[count]) {
		case 'A' :
			result[0] += 1;
			break;
		case 'a' :
			result[0] += 1;
			break;
		case 'E':
			result[1] += 1;
			break;
		case 'e':
			result[1] += 1;
			break;
		case 'I':
			result[2] += 1;
			break;
		case 'i':
			result[2] += 1;
			break;
		case 'O':
			result[3] += 1;
			break;
		case 'o':
			result[3] += 1;
			break;
		case 'U':
			result[4] += 1;
			break;
		case 'u':
			result[4] += 1;
			break;
		default :
			break;
		}
		count+= 1;
	}
	
	return result[x];
}