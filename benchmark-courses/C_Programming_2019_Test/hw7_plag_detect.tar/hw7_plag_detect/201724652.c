#include <stdio.h>
#include <string.h>

int main()
{
	char line[256];
	int vowel[5] = { 0, };
	int i, j;
	while (fgets(line, 256, stdin) != NULL) {
		
		for (i = 0; i < strlen(line); i++) {
			if (line[i] >='A' && line[i] <='Z')
			{
				line[i] = line[i] + 32;
			}
			
			switch (line[i]) {
			case 'a':
				vowel[0]++;
				break;
			case 'e' :
				vowel[1]++;
				break;
			case 'i':
				vowel[2]++;
				break;
			case 'o':
				vowel[3]++;
				break;
			case 'u':
				vowel[4]++;
				break;
			default:
				break;

			}


		}
		for (j = 0; j < 5; j++) {
			printf("%d ", vowel[j]);
			vowel[j] = 0;
		}
		printf("\n");
		
	}
}

