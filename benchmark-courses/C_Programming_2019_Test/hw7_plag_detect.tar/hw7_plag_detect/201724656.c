#include <stdio.h>
#include <string.h>

int main()
{
	char line[256];
//	int nlines = 0;
	while (fgets(line, 256, stdin) != NULL) {
		int vowel[5] = { 0 };
	//	printf("%3d(%3d): %s", ++nlines, strlen(line), line);
		for (int i = 0; line[i] != NULL; i++) {
			switch (line[i])
			{
			case 'A':
				vowel[0]++;
				break;
			case 'a':
				vowel[0]++;
				break;
			case 'E':
				vowel[1]++;
				break;
			case 'e':
				vowel[1]++;
				break;
			case 'I':
				vowel[2]++;
				break;
			case 'i':
				vowel[2]++;
				break;
			case 'O':
				vowel[3]++;
				break;
			case 'o':
				vowel[3]++;
				break;
			case 'U':
				vowel[4]++;
				break;
			case 'u':
				vowel[4]++;
				break;
			default:
				break;
			}
		}
		for (int i = 0; i < 5; i++) {
			printf("%d ", vowel[i]);
		}
		printf("\n");
	}
	//printf("-- %d lines have been processed. --\n", nlines);
	return 0;
}