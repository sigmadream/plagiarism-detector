#include <stdio.h>
#include <string.h>

int main()
{
    char line[256];


    while (fgets(line, 256, stdin) != NULL) {

        int an=0, en=0, in=0, on=0, un=0;
        int n=0;
        char *p = line;

        while (n!=strlen(line)){
        switch(tolower(*p)){
        case 'a':
            an++;
            break;
        case 'e':
            en++;
            break;
        case 'i':
            in++;
            break;
        case 'o':
            on++;
            break;
        case 'u':
            un++;
            break;
        }
        p++;
        n++;
        }
    printf("%d %d %d %d %d \n",an,en,in,on,un);
    }
    return 0;
}
