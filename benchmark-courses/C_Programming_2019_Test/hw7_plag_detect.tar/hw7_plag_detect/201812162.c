#include <stdio.h>

#define LEN 100

int main(){
    char line[LEN];
    while (fgets(line,LEN,stdin)!=NULL){
        int i=0;
        int vidx[5]={0};
        while (line[i]!='\0'){
            switch (line[i]){
            case 'A':
            case 'a':
                vidx[0]++;
                break;
            case 'E':
            case 'e':
                vidx[1]++;
                break;
            case 'I':
            case 'i':
                vidx[2]++;
                break;
            case 'O':
            case 'o':
                vidx[3]++;
                break;
            case 'U':
            case 'u':
                vidx[4]++;
                break;
            }
            i++;
        }
        for (i=0;i<5;i++)
            printf("%d ",vidx[i]);
        printf("\n");
        //printf("%d %d %d %d %d\n",vidx[0],vidx[1],vidx[2],vidx[3],vidx[4]);
    }
    return 0;
}
