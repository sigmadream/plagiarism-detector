#include <stdio.h>
#include <string.h>

int main()
{
    char line[256];


    while (fgets(line, 256, stdin) != NULL){
        int cnt[5]={0,0,0,0,0};
        for (int i=0; i<strlen(line); i++){

        switch (line[i]){
            case 'a':
            case 'A':
                cnt[0] += 1;
                break;
            case 'e':
            case 'E':
                cnt[1] += 1;
                break;
            case 'i':
            case 'I':
                cnt[2] += 1;
                break;
            case 'o':
            case 'O':
                cnt[3] += 1;
                break;
            case 'u':
            case 'U':
                cnt[4] += 1;
                break;
        }
    }
        printf("%d %d %d %d %d \n", cnt[0], cnt[1], cnt[2], cnt[3], cnt[4]);
    }

    return 0;
}
