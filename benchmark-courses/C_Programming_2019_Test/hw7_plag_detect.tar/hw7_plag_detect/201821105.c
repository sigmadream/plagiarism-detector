#include <stdio.h>
#include <string.h>

int countv(char in[]){

    int a =0 ;
    int e =0;
    int i =0;
    int o =0;
    int u =0;
    while(*in != '\0'){
        switch (*in){
        case 'A' :
        ++a ; break;
        case 'a' :
        ++a ; break;
        case 'E' :
        ++e ; break;
        case 'e' :
        ++e ; break;
        case 'I' :
        ++i ; break;
        case 'i' :
        ++i ; break;
        case 'O' :
        ++o ; break;
        case 'o' :
        ++o ; break;
        case 'U' :
        ++u ; break;
        case 'u' :
        ++u ; break;
        }
    ++in;
    }

    printf("%d %d %d %d %d \n", a, e, i, o, u);
    return 0;
}


int main(){

    char line[256];
    while (fgets(line, 256, stdin) != NULL) {
        countv(line);
    }
    return 0;
}
