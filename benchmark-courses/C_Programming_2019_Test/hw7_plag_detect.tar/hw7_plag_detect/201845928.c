#include <stdio.h>
#include <string.h>

int main() {
	char s[256];
	fflush(stdin);

	while ((fgets(s, 256, stdin)) != NULL) {
		
		//printf(s);
		int a=0, e=0, i=0, o=0, u =0;
		for (int k = 0; k < strlen(s); k++) {
			char x = s[k];

			//printf("%c", x);
			if (x >= 'a' && x <= 'z'){
				x -= 32;
			}
			//printf("%c", x);
			switch (x) {
				case 'A':
					a++;
					//printf("%d", a);
					break;
				case 'E':
					e++;
					//printf("%d", e);
					break;
				case 'I':
					//printf("%d", i);
					i++;
					break;
				case 'O':
					//printf("%d", o);
					o++;
					break;
				case 'U':
					//printf("%d", u);
					u++;
					break;
				default:
					break;
			}
		}
		printf("%d %d %d %d %d \n", a, e, i, o, u);
		fflush(stdin);
	}

	return 0;
}