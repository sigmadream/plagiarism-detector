#include <stdio.h>

int count(char *c, char x)

{

	int i, count;

	count = 0;

	for (i = 0; c[i] != NULL; i++)

	{

		if (c[i] == x)

			count++;

		else

			continue;

	}

	return count;

}

int main()

{

	char sen[255];

	int w1, w2, w3, w4, w5;

	while (fgets(sen, 255, stdin) != NULL)

	{

		switch (1)

		{

		case 1:

			w1 = count(sen, 'a');

		case 2:

			w2 = count(sen, 'e');

		case 3:

			w3 = count(sen, 'i');

		case 4:

			w4 = count(sen, 'o');

		case 5:

			w5 = count(sen, 'u');

			break;

		}



		switch (2)

		{

		case 1:

			w1 = count(sen, 'a');

		case 2:

			w2 = count(sen, 'e');

		case 3:

			w3 = count(sen, 'i');

		case 4:

			w4 = count(sen, 'o');

		case 5:

			w5 = count(sen, 'u');

			break;

		}



		switch (3)

		{

		case 1:

			w1 = count(sen, 'a');

		case 2:

			w2 = count(sen, 'e');

		case 3:

			w3 = count(sen, 'i');

		case 4:

			w4 = count(sen, 'o');

		case 5:

			w5 = count(sen, 'u');

			break;

		}

		switch (4)

		{

		case 1:

			w1 = count(sen, 'a');

		case 2:

			w2 = count(sen, 'e');

		case 3:

			w3 = count(sen, 'i');

		case 4:

			w4 = count(sen, 'o');

		case 5:

			w5 = count(sen, 'u');

			break;

		}

		switch (5)

		{

		case 1:

			w1 = count(sen, 'a');

		case 2:

			w2 = count(sen, 'e');

		case 3:

			w3 = count(sen, 'i');

		case 4:

			w4 = count(sen, 'o');

		case 5:

			w5 = count(sen, 'u');

			break;

		}

		printf(" %d %d %d %d %d ", w1, w2, w3, w4, w5);

		puts("");

	}

	return 0;

}