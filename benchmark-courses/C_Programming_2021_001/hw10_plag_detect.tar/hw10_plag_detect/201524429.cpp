#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main() {
    char str[100];
    fgets(str,sizeof(str),stdin);

    char *pt = strtok(str," ");

    while(pt != NULL)
    {
        for(int i=strlen(pt)-1;i>-1;i--){
            if(!isalnum(pt[i])) {
                continue;
            }
            printf("%c",pt[i]);
        }
        printf(" ");
        pt = strtok(NULL," ");
    }
    //printf("Hello, World!\n");
    return 0;
}
