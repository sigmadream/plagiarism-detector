#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//char *filtersym(char line[]) {
//    char *NewLine = (char *) malloc(sizeof(line) + 1);
//    for (int i = 0; i < sizeof(line); i++){
//        if ((line[i] >= 65 && line[i] <=90) || (line[i] >=97 && line[i] <= 122) || line[i] == 32)
//            NewLine[i] = line[i];
//        else
//            NewLine[i] = "";
//    }
//    return NewLine;
//}


int main()
{
    char line[257];
    fgets(line, 257, stdin);

    char NewLine[257];
    for (int i = 0; i < sizeof(line); i++){
        if ((line[i] >= 65 && line[i] <= 90) || (line[i] >=97 && line[i] <= 122) || line[i] == 32)
            NewLine[i] = line[i];
        else
            NewLine[i] = "";
    }


    char *pt = strtok(NewLine, " ");
    while(pt != NULL){
    for (int i = strlen(pt) -1; i >= 0; i--){
        if(pt[i] == '\n')
            continue;
        printf("%c", pt[i]);
    }
    printf(" ");
    pt = strtok(NULL, " ");
    }

    return 0;
}
