#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

char* revstr(char a[],int len)
{
    static char result[257];
    for(int i=0;i<len;++i)
    {
        result[i] = a[len-1-i];
    }
    return result;
}

char* filtersym(char s[],int len)
{
    int i=0,c=0;
    static char str_1[257];
    for(;i<len;++i){
        if(isalnum(s[i])){
            str_1[c]=s[i];
            c++;
        }
    }
    str_1[c]='\0';
    return str_1;
}

int main()
{
    char input[257];
    fgets(input,sizeof(input),stdin);
    input[strlen(input)-1] = '\0';

    int n=0,pos=0;
    char* str=malloc(sizeof(char)*257);

    while(sscanf(input,"%s%d%n",str,&n,&pos) == 1){
        char* word = filtersym(str,n);
        char* str = revstr(word,n);
        printf("%s ",str);
        input += pos;
        if(*str == &input[sizeof(input)-1])
            break;
    }
    free(str);

    return 0;
}
