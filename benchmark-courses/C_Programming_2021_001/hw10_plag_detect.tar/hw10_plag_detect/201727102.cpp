#include<stdio.h>
#include<string.h>

int main()
{
	char line[256];
	char word[100];
	int i;

	fgets(word,100,stdin);

	while(fgets(line,256,stdin)==1)
	{
		
	}
	
	return 0;
}
