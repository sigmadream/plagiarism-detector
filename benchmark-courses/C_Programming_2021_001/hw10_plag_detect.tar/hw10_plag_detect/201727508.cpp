#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define MAX_STR_SIZE 256

char * filtersym(char word[]);
void revstr(char s[]);


int main()
{
    char *line = malloc(sizeof(char) * 256);

    fgets(line, MAX_STR_SIZE, stdin);

    int pos=0;
    char word[256];
    char *ptr = malloc(sizeof(char) * 256);
    while (sscanf(line, "%s%n", word, &pos)==1)
    {
        revstr(word);
        printf("%s ", (filtersym(word)));
        line += pos;
    }


    free(line);
    free(ptr);

    return 0;
}

char *filtersym(char word[])
{
    int j=0;
    char *c = malloc(sizeof(char) * 256);
    for (int i=0; word[i]!='\0'; i++)
    {
        if (isalpha(word[i]))
            c[j++] = word[i];
    }

    return c;
}

void revstr(char s[])
{
    char temp;
    int size = strlen(s);
    for (int i=0; i< size/2; i++)
    {
        temp = s[i];
        s[i] = s[size-1-i];
        s[size-1-i] = temp;
    }
}
