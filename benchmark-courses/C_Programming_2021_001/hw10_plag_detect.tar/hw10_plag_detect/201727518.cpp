#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


char * filtersym(char word[]){

    // 받은 word 포인터를 크기가 1 큰 포인터로 동적 할당시킴
    char * a = (char *) malloc(sizeof(char) * (strlen(word)+1));
    
    int a_i=0;
    //isalnum 활용해서 특수문자를 제외한 값들만 a에 입력
    for(int i=0; i<strlen(word); i++){
        if (isalnum(word[i])){
            a[a_i]= word[i];
            a_i++;
        }
        
    }
    a[strlen(word)]= '\0';
    return a;

}
//기존 코드 활용!!
void swapstr(char *word , int first_index , int last_index){

    char temp = *(word+first_index); 
    *(word+first_index) = *(word+last_index);

    *(word+last_index) = temp; 


}
char *revstr(char word[]){
    
    int middle_index = strlen(word)/2;
    int last = strlen(word);
    for (int i=0; i<middle_index ; i++){
        swapstr(word , i , last-i-1); 
    }


    return word;
}
int main(){
    
    char word[257];
    
    fgets(word, 257, stdin);

    //기존에 있는 strtok(ㄴ) 활용시 공백을 제외한 단어들을 끊어서 활용할 수 있음!
    char *ptr = strtok(word , " ");

    while(ptr!= NULL){
        char * temp = filtersym(ptr); //특수문자 필터링 과정
        printf("%s " , revstr(temp));
        ptr = strtok(NULL, " ");
    }

        
    // while(word[i]!= '\n'){
    //     if(word[i]!= ' '){
    //         i++;
    //         continue;
    //     }
    //     else{
    //         int index  = i;
    //         char temp[index];
    //         for(int i=0; i<index; i++){
    //             temp[i] = word[index];
    //         } 
    //         char * result = revstr(filtersym(temp));
    //         printf("%s " , result);
    //         i++;
    //     }
    // }

  
    return 0;
}