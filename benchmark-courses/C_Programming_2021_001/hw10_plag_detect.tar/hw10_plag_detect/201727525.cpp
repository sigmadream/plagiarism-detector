// char *filtersym(char word[]); -> 리턴밸류가 포인터라는건 malloc를 써야한다고하는데
// sscanf에서 newline은 생각안해도 된다는데
// 최대길이는 256 -> null포함 257이라고함!!
// 문장을 입력받아서 단어기준으로 특수문자 제외시킨 뒤, 단어끼리만 reverse시킨다

#include <stdio.h>
#include <string.h>
#include <stdlib.h>             // malloc위함인듯
#include <ctype.h>              // isalnum쓸때
#define _CRT_SECURE_NO_WARNINGS // strtok 보안 경고로 인한 컴파일 에러 방지

void filtersym(char word[])
{
    int i = 0, c = 0;
    for (; i < strlen(word); i++)
    {
        if (isalnum(word[i]))
        {
            word[c] = word[i];
            c++;
        }
    }
    word[c] = '\0';
}

// int main(){
//     char line[257];
//     fgets(line,sizeof(line),stdin);

// }
void swapchar(char *a, char *b) // 함수활용시에는 ★★포인터 방식으로!!
{                               // 리턴할거없으면 void!!
    char temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void revstr(char *line) // 거꾸로 만드는 함수
{
    for (int i = 0; i < (strlen(line) / 2); i++) // 길이의 반만큼 실시 : 양옆을 서로 맞바꾼다. 산공프
        swapchar(line + i,
                 line + strlen(line) - i - 1); // ★★주소를 바꾼단점을 잘 명심하기
}

int main()
{
    char line[257];
    fgets(line, sizeof(line), stdin);
    //char s1[30] = "The Little Prince"; // 크기가 30인 char형 배열을 선언하고 문자열 할당

    char *ptr = strtok(line, " "); // " " 공백 문자를 기준으로 문자열을 자름, 포인터 반환

    while (ptr != NULL) // 자른 문자열이 나오지 않을 때까지 반복
    {
        filtersym(ptr);
        revstr(ptr);
        printf("%s ", ptr);      // 자른 문자열 출력
        ptr = strtok(NULL, " "); // 다음 문자열을 잘라서 포인터를 반환
    }

    return 0;
}