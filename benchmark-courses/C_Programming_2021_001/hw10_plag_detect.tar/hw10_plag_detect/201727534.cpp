#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char *filtersym(char word[])
{
    char *new_word = (char *)malloc(strlen(word) * sizeof(char));
    int index = 0;
    for (int i = 0; i < strlen(word); i++)
    {
        if (word[i] == '?')
            continue;
        else if (word[i] == '\'')
            continue;
        else if (word[i] == '!')
            continue;
        else if (word[i] == '.')
            continue;
        else if (word[i] == ',')
            continue;
        else if (word[i] == ';')
            continue;
        else if (word[i] == '"')
            continue;
        else if (word[i] == ':')
            continue;
        else if (word[i] == ';')
            continue;
        else if (word[i] == '\0')
            continue;
        else
        {
            new_word[index] = word[i];
            index++;
        }
    }
    new_word[index] = '\0';

    return new_word;
}

void swapchar(char *first, char *end)
{
    char temp = *first;
    *first = *end;
    *end = temp;
}

void revstr(char word[])
{
    for (int i = 0; i < strlen(word) / 2; ++i)
        swapchar(word + i, word + strlen(word) - 1 - i);
}

int main()
{
    char line[256];
    char word[256];
    char *ptr = line;
    int pos = 0;
    fgets(line, 256, stdin);

    while (sscanf(ptr, "%s%n", word, &pos) == 1)
    {
        char *new_word = filtersym(word);
        revstr(new_word);
        ptr += pos;
        printf("%s ", new_word);
    }

    return 0;
}
// Hello World check
// Don't stop now !!
// You know C programming!