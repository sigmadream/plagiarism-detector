#include <stdio.h>
#include <string.h>

void swapchar(char *a, int s, int e)
{
    char x = *(a + s);
    *(a + s) = *(a + e);
    *(a + e) = x;
}

void revstr(char*a)
{
    int i;
    for (i=0; i<strlen(a)/2; i ++)
    {
        swapchar(a, i, strlen(a)-i-1);
    }
}


char *filtersym(char word[]){
    int i,j;
    for(i=j=0;word[i];i++){
        if(('0' <= word[i] && word[i] <= '9')
        || ('A' <= word[i] && word[i] <= 'Z')
        || ('a' <= word[i] && word[i] <= 'z'))
        word[j++] = word[i];
    }
    word[j]=0;
    return word;
}


int main() {
    char a[256];
    fgets(a, 256, stdin);
    int i=0 ,sum = 0, n = 0, pos = 0, line[256];

    char *ptr = strtok(a, " ");
    revstr(ptr);
    filtersym(ptr);
    printf("%s", ptr);
    printf(" ");

    while (ptr != NULL)
    {
        ptr = strtok(NULL, " ");
        revstr(ptr);
        filtersym(ptr);
        printf("%s", ptr);
        printf(" ");
    }
    return 0;
}
