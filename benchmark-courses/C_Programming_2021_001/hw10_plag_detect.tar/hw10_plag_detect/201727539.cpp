#include <stdio.h>
#include <string.h>

int main() {
    char str[256];
    char *filtersym(char str[]);
    fgets(str, sizeof(str), stdin);

    char *pt = strtok(str, " ");

    while(pt!= NULL)
    for(int i=strlen(pt)-1; i>-1; i--){
        if(pt[i] =='\n') continue;
        printf("%c", pt[i]);
    }
    printf(" ");
    pt = strtok(NULL, " ");

}
