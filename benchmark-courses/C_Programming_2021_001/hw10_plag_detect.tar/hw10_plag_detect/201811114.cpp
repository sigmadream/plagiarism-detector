#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


char* filtersym(char word[])
{
    int k = 0;
    const int word_len = strlen(word);
    char* result = (char*)malloc(word_len + 1);
    for (int i = 0; i < word_len; ++i)
    {

        if (isalpha(word[i]))
        {
            result[k] = word[i];
            ++k;
        }
        result[k] = '\0';

    }
    return result;
}

char* revstr(char* str)
{
    const int str_len = strlen(str);
    char* result = (char*)malloc(str_len + 1);
    for (int i = 0; i < str_len; ++i)
    {
        result[i] = str[str_len - 1 - i];
    }
    result[str_len] = '\0';
    return result;
}
int main()
{
    char str[257];
    const int str_len = 257;
    fgets(str, str_len, stdin);

    char word[str_len];
    int pos = 0;
    char* ptrStr = str;

    int temp = 0;
    while ((temp = sscanf(ptrStr, "%s%n", word, &pos)) == 1)
    {
        char* result = NULL;
        result = filtersym(word);
        result = revstr(result);
        printf("%s ", result);
        ptrStr += pos + 1;
        pos = 0;
        free(result);
    }
    return 0;

}