#include <stdio.h>
#include <stdlib.h>
#include <string.h>



void reverse(char* s);

int start = 0;
int end = 0;

int main(void)
{

    char s[256];
    int num;
    int i, j;
    int len;
    scanf("%d", &num);

    while(getchar() != '\n'){}

    for(j = 0; j<num;j++)
    {
        start = 0;
        end = 0;
        len = strlen(s);
        fgets(s, len, stdin);


            for(i = 0; i < len; i++)
            {
                if(s[i] == ' ' || i == len-1)
                {
                    end = i-1;
                    if(i == len-1) end = i;

                    reverse(s);
                    start = i+1;
                }
            }
        printf("%s\n", s);
    }
        return 0;
}

void reverse(char* s)
{

    int i;
    char temp;
    for (i = start; i <= (end+start)/2; i++)
    {
        temp = s[i];
        s[i] = s[end-i+start];
        s[end-i+start]=temp;

    }
}




















