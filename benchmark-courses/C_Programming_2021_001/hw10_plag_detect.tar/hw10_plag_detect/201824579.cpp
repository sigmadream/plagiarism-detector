#include<stdio.h>
#include<string.h>
void Eliminate(char *str, char ch)

{

    for (; *str != '\0'; str++)

    {

        if (*str == ch)

        {

            strcpy(str, str + 1);

            str--;

        }

    }

}


int main()
{
	char str[256];
	int i = 0;
	
	
	fgets(str,sizeof(str),stdin);
	
	/*Eliminate(str, 33);
	Eliminate(str, '""');
	Eliminate(str, '#');
	Eliminate(str, '$');
	Eliminate(str, '%');
	Eliminate(str, '&');
	Eliminate(str, '\'');
	Eliminate(str, '(');
	Eliminate(str, ')');
	Eliminate(str, '*');
	Eliminate(str, '+');
	Eliminate(str, ',');
	Eliminate(str, '-');
	Eliminate(str, '.');
	Eliminate(str, '/');
	Eliminate(str, ':');
	Eliminate(str, ';');
	Eliminate(str, '<');
	Eliminate(str, '=');
	Eliminate(str, '?');
	Eliminate(str, '@');
	Eliminate(str, '[');
	Eliminate(str, '\\');
	Eliminate(str, ']');
	Eliminate(str, '^');
	Eliminate(str, '_');
	Eliminate(str, '`');
	Eliminate(str, '{');
	Eliminate(str, '}');
	Eliminate(str, '~');
	Eliminate(str, '{');
	Eliminate(str, '|');
	*/
	for(i=1;i<32;i++)
	{
		Eliminate(str, i);
	}
	for(i=33;i<48;i++)
	{
		Eliminate(str, i);
	}
	for(i=58;i<65;i++)
	{
		Eliminate(str, i);
	}
	for(i=91;i<97;i++)
	{
		Eliminate(str, i);
	}
	for(i=123;i<128;i++)
	{
		Eliminate(str, i);
	}
	
	
	
	
		
	char *pt = strtok(str , " ");
	
	
	while(pt != NULL)
	{
		for( i = strlen(pt)-1 ; i>-1 ; i--)
		{
			if(pt[i] == '\n')
				continue;
			
			printf("%c", pt[i]);
		}
		printf(" ");
		pt = strtok(NULL, " ");
	}
	
	
	
	return 0;
}
