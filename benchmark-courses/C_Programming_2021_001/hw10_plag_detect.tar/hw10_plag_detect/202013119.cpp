#include <stdio.h>
#include <stdlib.h>
#define MAX 257
char *filtersym(char word[]);
char *revstr(char s[]);

int main()
{
    char line[MAX];
    char word[MAX];
    int pos = 0;

    fgets(line, MAX, stdin);

    sscanf(line, "%s %n", word, &pos);
    printf("%s", revstr(filtersym(word)));
    printf("%d", pos);
    return 0;
}

char *filtersym(char word[])
{
    char *s = malloc(sizeof(word) + sizeof(char));
    int num = sizeof word/ sizeof *word, i, x = 0;
    for (i = 0; i < num; ++i){
        if ((48 <= word[i] && word[i] <= 57)||(65 <= word[i] && word[i]<= 90)||(97<= word[i] && word[i] <= 122)){
            s[x] = word[i];
            x++;
        }
    }
    s[x+1] = '\0';
    return s;
}

char *revstr(char s[]){
    int len = sizeof s/ sizeof s[0];
    char *str = malloc(sizeof s);
    for (int i = len-1; i >=0 ; i--)
        str[len-1-i] = s[i];
    return str;
    }
