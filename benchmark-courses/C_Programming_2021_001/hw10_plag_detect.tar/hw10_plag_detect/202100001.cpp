#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#define MAX 256

char *filtersym(char word[]) {
    size_t sz = strlen(word);
    char *newword = (char *) malloc(sz);
    int j = 0;
    for (int i=0; i<sz; i++) {
        if (isalpha(word[i])) {
            newword[j] = word[i];
            j++;
        }
    }
    newword[j]='\0';
    return newword;
}

char *revstr(char s[]) {
    size_t sz = strlen(s);
    char *revword = (char *) malloc(sz);
    int j = 0;
    for (int i = sz-1; i>=0; i--) {
        revword[j] = s[i];
        j++;
    }
    revword[j] = '\0';
    return revword;
}

int main()
{
    char line[MAX];
    fgets(line, MAX, stdin);
    char *linePnt = line;
    char word[MAX];
    int pos;
    char res[MAX];
    char *nword, *rword;
    while (sscanf(linePnt, "%s%n", word, &pos) == 1) {
        linePnt += pos;
        if (strlen(word) == 1) {
            // sprintf(res+strlen(res), "%s ", word);
            printf("%s ", word);
        }
        else {
            nword = filtersym(word);
            rword = revstr(nword);
            // sprintf(res+strlen(res), "%s ", rword);
            printf("%s ", rword);
        }
    }
    free(nword);
    free(rword);
    // puts("");
    return 0;
}