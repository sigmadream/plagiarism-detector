#include <stdio.h>
#include <stdlib.h>
#include <string.h>


char *filtersym(char s[])
{
    char *str = (char *) malloc(strlen(s)+1);
    int n = 0;
    for (int i = 0; i < strlen(s); i++) {
        if ((('a' <= s[i] && s[i] <= 'z') ||('A' <= s[i] && s[i] <= 'Z') || ('0' <= s[i] && s[i] <= '9')))
            str[n++] = s[i];
    }
    str[n] = '\0';
    return str;
}

char *revstr(char nput[256]){
    char *input = filtersym(nput);
    char *out = (char *) malloc(strlen(input) + 1);
    int i = 0;
    for(i = 0; i < strlen(input);i++){
        out[i] = input[strlen(input)-i-1];
    }
    out[i] = '\0';
    return out;
}

int main()
{
    char *line = "";
    line = malloc(256*sizeof(char));
    char word[256];
    int pos = 0;

    fgets(line,256,stdin);
    while (sscanf(line, "%s%n", word, &pos) == 1) {
        char *rout = revstr(word);
        printf("%s ", rout);
        line += pos;
    }
    puts("");

    return 0;
}