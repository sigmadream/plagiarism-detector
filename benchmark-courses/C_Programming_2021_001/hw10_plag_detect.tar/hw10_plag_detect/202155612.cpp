#include <stdio.h>
#include <stdlib.h>
/*
char *filtersym(char input1[257])
{
    int k=0;
    char outf[257];
    for (int i = 0; i < strlen(input1); i++)
    {
        if (input1[i]='u')
        {
            input1[i]= input1[i];
        }
        else{
            outf[k] = input1[i];
            k++;
        }
    }

    char *outp = outf[257];
    return outp;
}
*/

char *filtersym(char s[])
{
    char* str = (char*)malloc(sizeof(s)+sizeof(char));
    int n = 0;
    for (int i = 0; i < strlen(s); i++)
        //s[i] != 'w'|s[i] != 'w'
        if (!((33 <= s[i] && s[i] <= 47) ||(58 <= s[i] && s[i] <= 64)||(s[i]=='��'))) str[n++] = s[i];

    str[n] = '\0';
    return str;
}

char *revstr(char nput[257]){
    char *input;
    input = filtersym(nput);
    char out[257] = "";
    for(int i = 0; i < strlen(input);i++){
        out[i] = input[strlen(input)-i-1];
    }
    char *output = out;
    return output;
}



int main()
{

    char *line = malloc(sizeof(char) * 257);
    char word[257] = "";

    int n = 0, pos = 0, sum= 0;

    fgets(line,257,stdin);
    if ((line[strlen(line) - 1] == '\r')|(line[strlen(line) - 1] == '\n')){
        line[strlen(line) - 1] = '\0';}

    while (sscanf(line, "%s%n", &word, &pos) == 1) {
        printf("%s ", revstr(word));
        line += pos;
    }
    return 0;
}
