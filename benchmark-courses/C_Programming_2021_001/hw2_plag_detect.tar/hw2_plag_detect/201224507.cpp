#include <stdio.h>

int main() {
    int input_n = 0;
    int odd_sum = 0;

    while (scanf("%d", &input_n) == 1) {
        if ((input_n % 2) != 0) {
            odd_sum = odd_sum + input_n;
        }
    }
    printf("%d", odd_sum);

    return 0;
}