#include <stdio.h>

int main()
{
    int sum = 0, num = 0;
    while (scanf("%d", &num) == 1)
    {
        if (num >= 0) // 양수일 경우
        {
            if (num % 2 == 1) // 홀수일 경우
                sum += num;
            else
                continue;
        }
        else
        {
            num *= -1;
            if (num % 2 == 1)
                sum -= num;
            else
                continue;
        }
    }
    printf("%d", sum);

    return 0;
}