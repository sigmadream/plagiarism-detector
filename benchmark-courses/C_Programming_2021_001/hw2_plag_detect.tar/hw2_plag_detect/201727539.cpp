#include <stdio.h>

int main()
{
    int sum=0, i=0;


    while(scanf("%d", &i) % 2==1)
    {
        printf("%d \n", sum+=i);

    }

    return 0;
}

