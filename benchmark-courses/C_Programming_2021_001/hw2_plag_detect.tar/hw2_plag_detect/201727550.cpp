//
//  main.c
//  Problem2
//
//  Created by 황승한 on 2021/06/24.
//

#include <stdio.h>

int main(){
    int sum = 0;
    int n=0;
    while(scanf("%d",&n)==1){
        if(n<0){
            if((n*-1) % 2 == 1) {
                sum += n;
            }
        }else{
            if(n%2 == 1) {
                sum += n;
            }
        }
        
    }
    printf("%d",sum);
    return 0;
}
