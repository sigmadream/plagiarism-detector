#include <stdio.h>

int main() {
	int sum = 0, n,m=0;
	while (scanf("%d ", &n) == 1) {
		if (n < 0) {
			m = n * (-1);
		}
		else
			m = n;
		if (m % 2==1) {
			sum += n;
		}
		
	}
	printf("%d", sum);
	return 0;
}