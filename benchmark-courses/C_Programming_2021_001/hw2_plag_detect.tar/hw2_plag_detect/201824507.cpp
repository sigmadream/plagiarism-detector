#include <stdio.h>

int main()
{

    int sum = 0, n = 0, i = 1;

    while (scanf("%o", &n) == 1)
    {
        if( n%2 == 1)
            sum += n;
        else
            i += n;


    }
    printf("%o\t", sum);


    return 0;
}
