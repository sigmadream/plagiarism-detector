#include<stdio.h>

int main(void)
{
	int n;
	int sum=0;
	
	while(scanf("%d",&n)==1)
	{
		if((n%2)==0)
			continue;
		else
			sum = sum + n ;
	}
	printf("%d",sum);
	
	return 0;
}
