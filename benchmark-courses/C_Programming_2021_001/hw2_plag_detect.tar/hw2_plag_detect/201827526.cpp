#include <stdio.h>
#include <stdlib.h>

int main()
{
    int input=0;
    int sum=0;
    while (scanf("%d", &input)==1){
        if (input%2==1 || input%2==-1){
            sum+=input;
        }
    }
    printf("%d", sum);
return 0;

}
