#include <stdio.h>

int main(void)
{
	int n;
	int sum=0;
	
	while (scanf("%d",&n)==1)
	{
		if ((n%2)==0)
			continue;
		sum = sum + n ;
	}
	printf("%d\n",sum);
	
	return 0;
}
