#include <stdio.h>

 int main()
 {
 int sum = 0, n = 0;

 while (scanf("%d", &n) )
    if(n%2!=0)
 printf("%d\t%d\n", n, sum += n);

 return 0;
}
