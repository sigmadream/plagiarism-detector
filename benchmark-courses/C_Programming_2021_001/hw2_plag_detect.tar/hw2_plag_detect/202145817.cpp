/*
    osum.c

    210624thu
*/
#include <stdio.h>

int main(void){
    int sum = 0;
    int num = 0;

    while(scanf("%d", &num) == 1){
        if(num < 0){
            num = -num;
            if(num % 2 == 1)
                sum -=num;
        }
        else{
            if(num % 2 == 1)
                sum += num;
        }
    }
    printf("%d\n\n", sum);

    return 0;
}