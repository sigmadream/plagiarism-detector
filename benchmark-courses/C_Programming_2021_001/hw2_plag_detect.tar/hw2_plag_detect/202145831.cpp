#include <stdio.h>

int main()
{
  int num = 0;
  int sum = 0;


  while(1){

    scanf("%d", &num);

    if(num %2 == 1)
    {
        sum += num;

    }

  }

  printf("%d\n", sum);

   return 0;
}
