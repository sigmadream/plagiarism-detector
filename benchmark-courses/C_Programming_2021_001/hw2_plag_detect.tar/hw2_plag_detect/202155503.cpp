#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sum = 0 , n = 0;

    while (scanf("%d", &n) == 1)
        if (n % 2 != 0)
            sum+=n;

    printf("%d",sum);

    return 0;
}
