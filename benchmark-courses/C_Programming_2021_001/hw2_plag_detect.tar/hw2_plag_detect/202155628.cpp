#include <stdio.h>


int main()

{
    int sum = 0 , n = 0 ;



    while (scanf("%d",&n) % 2 == 1)
        sum += n;
        printf("sum"):



    return 0;
}
