#include <stdio.h>
#include <ctype.h>
#include <string.h>

char encryption(char *c, int a){
    char temp;
    if (isalpha(*c) == 1) {
        if(*c + a > 90) {
            temp = *c + a - 26;
        }
        else temp = *c + a;
    }
    else if (isalpha(*c) == 2) {
        if (*c + a > 122) {
            temp = *c + a - 26;
        }
        else temp = *c + a;
    }
    else if (isalpha(*c) == 0) {
        temp = *c;
    }

    return temp;
}

int main() {
    int k = 0;
    char message[31] = "Insert Message";

    scanf("%d", &k);
    scanf("%s", message);
    for (int i = 0; i < strlen(message); i++) {
        printf("%c", encryption(&message[i], k));
    }

    return 0;
}