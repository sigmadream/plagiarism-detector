#include <stdio.h>
#include <ctype.h>
#include <string.h>


char* encrytion(char* s, int n) {
    int i;
    char c;

    for(i=0; i<strlen(s); i++) {
        c = s[i];
        if(isalpha(c)) {
            if (c >= 'a' && c <= 'z') {
                c += n;
                if (c <= 'z')
                    s[i] = c;
                else
                    s[i] = c % ('z' + 1) + 'a';
            } else if (c >= 'A' && c <= 'Z') {
                c += n;
                if (c <= 'Z')
                    s[i] = c;
                else
                    s[i] = c % ('Z' + 1) + 'A';
            }
        }
        else if(isdigit(c)){
            s[i] = c;
        }
    }
    return s;
}
int main() {
    int n;
    char str[31];

    scanf("%d",&n);
    scanf("%30s",str);
    //printf("%d",strlen(str));
    printf("%s",encrytion(str,n));

    return 0;
}