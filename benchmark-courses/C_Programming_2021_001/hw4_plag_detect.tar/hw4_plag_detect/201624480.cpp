#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void encrypt(int n, char str[]){
    for(int i=0; i< strlen(str); i++){
        if(str[i] >= 65 && str[i] <= 90){
            str[i] = (str[i] -65 + n)%26 + 65;
        }
        else if(str[i] >= 97 && str[i] <= 122){
            str[i] = (str[i] -97 + n)%26 + 97;
        }
    }
}

int main() {
    char str[31];
    int n;
    scanf("%d", &n);
    scanf("%s", str);
    encrypt(n, str);
    printf("%s", str);

    return 0;
}
