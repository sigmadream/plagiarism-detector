#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
    int k;
    char ch;

    scanf("%d",&k);
    

    while(scanf(" %c",&ch)==1)
    {
        if(isupper(ch))
        {
            printf("%c",ch+k);
            scanf(" %c",&ch);
        }
        if(islower(ch))
        {
            printf("%c",ch+k);
            scanf(" %c",&ch);
        }
        if(isdigit(ch))
            break;
        if(isalnum(ch))
            break;
        
    }

    return 0;
}