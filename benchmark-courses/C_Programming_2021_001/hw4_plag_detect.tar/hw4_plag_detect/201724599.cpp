#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	int k;
	char temp;
	char* str = malloc(sizeof(char) * 10);
	scanf("%d", &k);
	scanf("%30s", str);
	for (int i = 0; i < strlen(str); ++i) {
		char c = str[i];
		temp = c + k;
		if (isalpha(c) != 0) {
			if (isupper(c) == 1) {
				if (isupper(temp) == 1) printf("%c", temp);
				else printf("%c", temp - 26);
			}
			if (isupper(c) == 0) {
				if (isupper(temp) == 0) printf("%c", temp);
				else printf("%c", temp - 26);
			}
		}
		else printf("%d", c-48);
	}
	free(str);
	return 0;
}