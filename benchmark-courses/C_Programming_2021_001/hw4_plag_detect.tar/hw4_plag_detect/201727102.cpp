#include<stdio.h>
#include<ctype.h>
#include<string.h>

int main()
{	
	int n,i,c;
	char str[100];
	
	scanf("%d\n",&n);
	gets(str);


	for (i=0; i < strlen(str); ++i){
		
		
		if(str[i]>=48&&str[i]<=57){
		c=str[i];
		printf("%c",c);
		}
		else if(str[i]>=65&&str[i]<=90){
			c=str[i]+n;
			if(c>90)
			{
				c=64+c-90;
				printf("%c",c);
			}
			else{
				printf("%c",c);
			}
		}
		
		else if (str[i]>=97&&str[i]<=122){
			c=str[i]+n;
			if(c>122)
			{
				c=96+c-122;
				printf("%c",c);
			}
			else{
				printf("%c",c);
			}
			
		}
		
	}
	
	
	return 0;
	
}


