#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
    char a[31];
    int k, d;
    scanf("%d", &k);
    scanf("%30s", a);

    for (int i = 0; i < strlen(a); i++)
    {
        char c = a[i];

        if (isalpha(c))
        {
            if (islower (c))
            {
                d = c + k;
                if (d > 122)
                {
                    d =  d % 123 + 97;
                }
            }
            else
            {
                d = c + k;
                if (d > 90)
                {
                    d = d % 91 + 65;
                }
            }
            printf("%c", d);
        }
        else
        {
            printf("%c", c);
        }
    }


    return 0;
}
