#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
    int criteria = 0;
    char str[30];

    scanf("%d", &criteria);
    scanf("%s", str);


    for (int i = 0; i < strlen(str); i++)
    {
        if (isalpha(str[i]))
        {
            int element = str[i];
            //ascll 코드 65~90 대문자 , // 97~122 소문자
            if ((element >= 65 && element <= 90 && element + criteria > 90) || (element >= 97 && element <= 122 && element + criteria > 122)){
                //돌아가기
                element = element + criteria - 26;
                }
            else{
                //바로 기준값 증가 적용가능
                element = element + criteria;
                
            }
            str[i] = (char)element;
        }
    }

    printf("%s", &str);

    return 0;
}