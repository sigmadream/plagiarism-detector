#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
    int count;
    count = 0;
    char c_ptr[30]; // 배열하나하나가 char인 거

    scanf("%d", &count);  // 입력을 받아 변수가 된다
    scanf("%29s", c_ptr); // 입력을 받아 배열을 만든다

    if (strlen(c_ptr) <= 30)
    {
        for (int i = 0; i < strlen(c_ptr); i++)
        {
            if (isalpha(c_ptr[i]))
            {
                int c = c_ptr[i];
                if ((c >= 65 && c <= 90 && c + count > 90) || (c >= 97 && c <= 122 && c + count > 122))
                    c = (c + count) - 26;
                else
                    c = c + count;
                c_ptr[i] = (char)c;
            }
        }
    }

    printf("%s", &c_ptr);

    return 0;
}