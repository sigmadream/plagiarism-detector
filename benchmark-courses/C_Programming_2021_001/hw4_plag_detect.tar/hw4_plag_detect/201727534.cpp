#include <stdio.h>
#include <ctype.h>
#include <string.h>

void function(char *c_arr, int count)
{
    if (strlen(c_arr) <= 30)
    {
        for (int i = 0; i < strlen(c_arr); i++)
        {
            if (isalpha(c_arr[i]))
            {
                int c = c_arr[i];
                if ((c >= 65 && c <= 90 && c + count > 90) || (c >= 97 && c <= 122 && c + count > 122))
                    c = (c + count) - 26;
                else
                    c = c + count;
                c_arr[i] = (char)c;
            }
        }
    }
}

int main()
{
    int count = 0;
    char c_ptr[30];

    scanf("%d", &count);
    scanf("%29s", c_ptr);

    function(c_ptr, count);

    printf("%s", &c_ptr);

    return 0;
}