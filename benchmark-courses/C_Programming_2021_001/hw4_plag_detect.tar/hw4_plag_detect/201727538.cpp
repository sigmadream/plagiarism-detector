#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
    int k;
    char str[31];
    int a;

    scanf("%d", &k);
    scanf("%s", str);
    if (strlen(str) <= 31) {

    for (int i = 0; i < strlen(str); ++i) {
        char c = str[i];
        char A_c = c+k;
        if (isalpha(str[i]))
            {
            if ((c>= 65 && c <= 90 && A_c>90) || (c>= 97 && c <= 122 && A_c > 122)) {
                c = A_c - 26;
                str[i] = c;
                }
            else
                c = A_c;
                str[i] =c;
            }
    }
    }
    printf("%s", str);
    return 0;
}
