#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

void encrypt(int k, char* str){
    char c;
    for (int i = 0; i < strlen(str); ++i) {
        c = str[i];
        if (isalpha(c)){
            if (islower(c)){
                c=c+k-97;
                if(c>=26){
                    c=c-26;
                }
                str[i]=c+97;
            }
            else{
                c=c+k;
                if(c>=91){
                    c=c-26;
                }

                str[i]=c;
            }
        }
    }
}

int main()
{
    int k;
    char str[31];

    fscanf(stdin,"%d\n",&k);
    if (k<0 || k>25){
        return 0;
    }
    fscanf(stdin,"%s",str);

    encrypt(k,str);

    fprintf(stdout,"%s\n",str);
    return 0;
}
