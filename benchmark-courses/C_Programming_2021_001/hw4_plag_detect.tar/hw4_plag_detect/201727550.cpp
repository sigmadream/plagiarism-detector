//
//  main.c
//  Problem4
//
//  Created by 황승한 on 2021/06/29.
//

#include <stdio.h>
#include <ctype.h>
#include <string.h>

void function(int k, char str[]){
    char c = ' ';
    char c_ = ' ';
    if(strlen(str) == 0){
        return;
    }
    for(int i=0; i<strlen(str); ++i){
        c = str[i];
        if(!isalpha(c)){
            str[i] = c;
        }else{
            if(islower(c)){
                c_ = str[i] + k;
                if(c_ > 'z'){
                    c_ = c_- 'z' + 'a' -1;
                    str[i] = c_;
                }else{
                    str[i] = c_;
                }
            }else{
                c_ = str[i] + k;
                if(c_ > 'Z'){
                    c_ = c_- 'Z' + 'A' -1;
                    str[i] = c_;
                }else{
                    str[i] = c_;
                }
            }
        }
    }
    for(int i=0; i<strlen(str) ; ++i){
        printf("%c",str[i]);
    }
}

int main(){
    int k = -1;
    char str[30] = "";
    scanf("%d", &k);
    scanf("%29s", str);
    function(k,str);
   
    return 0;
}
