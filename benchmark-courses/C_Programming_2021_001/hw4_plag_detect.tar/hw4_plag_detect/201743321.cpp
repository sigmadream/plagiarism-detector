# include <stdio.h>
# include <string.h>
# include <ctype.h>


int main(){
    int num;
    int len;
    scanf(" %d",&len);
    if (scanf("%d",&num));
        char a;
        scanf(" %s",&a);
        char *str = &a;
        printf("%d",len);
        for (int i =0; i<strlen(str); i++){
            char c = str[i];
            if (islower(c) && (int)c<=122-len)
                printf("%c",(int)c+len);
            else if(islower(c) && (int)c>122-len)
                printf("%c",(int)c+len-25);
            else if(isupper(c) && (int)c<=90-len)
                printf("%c", (int)c+len);
            else if(isupper(c) && (int)c>90-len)
                printf("%c",(int)c+len-25);
            else
                rintf("%c",c);
            
    }
    return 0;
}

 