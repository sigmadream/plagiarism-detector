#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int read_int();
void encoding(char s[], int n, int k);
void decoding(char s[], int n, int k);

int main() {
	char s1[100];
	char c;
	int k;
	k = read_int();
	printf("��ȣȭ�� ����: ");
	c = getchar();

	scanf("%[^\n]s", s1);
	int n;
	n = sizeof(s1) / sizeof(s1[0]);

	encoding(s1, n, k);
	printf("%s\n", s1);
	decoding(s1, n, k);
	printf("%s\n", s1);

	system("pause");
	return 0;
}

int read_int() {
	int k;
	scanf("%d", &k);
	return k;
}

void encoding(char s[], int n, int k) {
	int i;
	for (i = 0; i < n; i++) {
		if (s[i] >= 'A' && s[i] <= 'Z') {
			s[i] = ((s[i] + k) - 'A') % ('Z' - 'A' + 1) + 'A';
		}
		else if (s[i] >= 'a' && s[i] <= 'z') {
			s[i] = ((s[i] + k) - 'a') % ('z' - 'a' + 1) + 'a';
		}
		else if (s[i] == ' ')
			s[i] = ' ';
		else
			s[i] = s[i];
	}
}
