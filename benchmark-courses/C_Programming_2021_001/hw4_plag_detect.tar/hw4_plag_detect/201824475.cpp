#include <stdio.h>
 
int main() {
 
    int n;
    char c[30];
 
    scanf("%d%*c", &n);
 
    gets(c);
 
    for (int i = 0; i < 30; i++) {
 
        if (c[i] == NULL) {
            break;

        }
 
        c[i] += n;
        printf("%c", c[i]);
    }
 
    return 0;
}

