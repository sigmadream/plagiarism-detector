#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
    int a;
    char b[30];
    scanf("%d\n%30s", &a, &b);

    for (int i=0; i < strlen(b); ++i){
        char c = 0;

        if (b[i]>=48 && b[i]<=57)
            c = b[i];
        else
            c = b[i]+a;
            if (c >122 && c <147)
                c = c - 26;
            if (c > 90 && c<96)
                c = c - 26;

    printf("%c", c);



    }

    return 0;

}
