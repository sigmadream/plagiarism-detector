#include <stdio.h>
#include<stdlib.h>
#include<string.h>
char* key(char* s, int n)
{
	int i;
	unsigned char c;
	
	for (i=0; i<strlen(s); i++){
		c=s[i];
		if(c>='a' && c <= 'z')
		{
			c = c + n;
			if(c<='z')
				s[i] =c;
			else
				s[i] = c%('z'+1)+'a';
		}
		else if(c>='A' && c<='Z')
		{
			c += n;
			if(c<='Z')
				s[i]=c;
			else
				s[i] = c%('Z'+1)+'A';
		}
	}
	return s;
}

int main(void)
{
	int k=0;
	char name[31];
	
	scanf("%d",&k);
	scanf("%30s",name);
	
	printf("%s\n",key(name,k));
	
	return 0 ;
	
}

