#include <stdio.h>
#include <stdlib.h>

//65~90
//97~122
//recursive
int encry(int a, int num)
{
    if (65<=a && a<=90)
    {
        a=a+num;
        if (a>90)
        {
            a=a%90+64;
        }
    }
    if (97<=a && a<=122)
    {
        a=a+num;
        if (a>122)
        {
            a=a%122+96;
        }
    }
    return a;

}
int main()
{
    int num=0;
    char a[31];
    scanf("%d", &num);
    scanf("%30s", a);

//    printf("this is test: %s", a);
    for(int i=0; i<strlen(a); ++i)
    {
            char result;

//        printf("i: %d", i);
        result=encry(a[i], num);
//        if (isalpha(result)){
             printf("%c", result);
//        }
//        else{
//            printf("%d", result);
//        }
    }

//printf("%d", encry('2', 5));


}
