#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

int main()
{
    int k = 0;
    char str[30] = "H";
    scanf("%d", &k);
    scanf("%s", &str);


    for (int i = 0; i < strlen(str); ++i) {
            char c = str[i];
            if (isalpha(c)){
                c = c + k;
                printf("%c", c);
            }
            else
                printf("%c", c);




    }

    return 0;
}
