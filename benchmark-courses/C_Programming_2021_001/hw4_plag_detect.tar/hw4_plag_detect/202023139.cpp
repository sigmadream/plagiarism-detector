#include <stdio.h>

int upper_tran(char x, int k) {
    if (x+k <= 90) x = x+k;
    else x = x+k-25 ;
    return x ;
}

int lower_tran(char y, int k) {
    if (y+k <= 122) y = y+k;
    else y = y+k-25 ;
    return y ;
}


int main() {

    int x, y, k, n = 0 ;
    char alp[31] ;

    scanf("%d", &k);
    scanf("%s", alp);

    while (alp[n] != '\0') {
        if (65 <= alp[n] <= 90) alp[n] = upper_tran(alp[n], k);
        else if (97 <= alp[n] <= 122) alp[n] = lower_tran(alp[n], k);
        n++;
    }

    printf("%s", alp);

}
