#include <stdio.h>
#include <ctype.h>

char encrypt(char c, int n) {
    char res;
    if (isupper(c)) {
        if (c + n <= 'Z')
            res = c + n;
        else
            res = c + n - 26;
    }
    else {
        if (c + n <= 'z')
            res = c + n;
        else
            res = c + n - 26;
    }
    return res;
}

int main()
{
    int n;
    char c;
    scanf("%d\n", &n);
    while (scanf("%c", &c) != EOF) {
        if (isalpha(c))
            printf("%c",encrypt(c,n));
        else
            printf("%c",c);
    }
    printf("\n");

    return 0;
}