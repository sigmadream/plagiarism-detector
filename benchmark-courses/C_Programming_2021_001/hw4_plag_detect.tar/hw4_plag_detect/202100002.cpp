#include <stdio.h>
#include <ctype.h>
#include <string.h>

char lock(char c, int roll) {
    if (isalpha(c)) {
        if (islower(c)) {
            c = c + roll;
            if (!islower(c))
                c = c - 26;
        }
        else {
            c = c + roll;
            if (!isupper(c))
                c = c - 26;
        }
    }
    return(c);
}

int main()
{
    char str[256] = "Hello";
    int roll;

    scanf("%d",&roll);
    scanf("%256s",&str);

    for (int i = 0; i < strlen(str); i++) {
        str[i] = lock(str[i], roll);
    }
    printf("%s\n", str);

    return 0;
}
