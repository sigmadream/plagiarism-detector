#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

int encrypt(char c, int k)
{
    char letter;
    if (islower(c))
    {
        letter = (c- 'a' + k)%26 + 'a';
    }
    else if (isupper(c))
    {
        letter = (c - 'A' + k)%26 + 'A';
    }
    else
        letter = c;
        return letter;
}

int main()
{
    char str[30];
    int k; // �̴� ��
    scanf("%d", &k);
    scanf("%30s", &str);

    for (int i = 0; i < strlen(str); i++)
    {
        char c = str[i];
        printf("%c", encrypt(c , k));
    }
    return 0;
}
