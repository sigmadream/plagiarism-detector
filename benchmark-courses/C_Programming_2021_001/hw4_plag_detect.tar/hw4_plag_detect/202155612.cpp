#include <stdio.h>
#include <ctype.h>
#include <string.h>
int main()
{
char str[256] = "Hello";

int roll;
scanf("%d",&roll);

scanf("%256s",&str);

char lock(char c){
    if (isalpha(c)){
        if (islower(c)){
            c = c + roll;
            if (!islower(c))
                c = c - 26;
                }
        else {
           c = c + roll;
            if (!isupper(c))
                c = c - 26;
            }
        }
    return(c);
    }

for(int i = 0; i < strlen(str); i++) {
    str[i] = lock(str[i]);
    }

printf("%s",str);
return 0;
}
