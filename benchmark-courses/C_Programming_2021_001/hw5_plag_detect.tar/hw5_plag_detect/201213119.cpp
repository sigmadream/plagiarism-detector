#include <stdio.h>

int gcd(int a, int b) {
    //  assuming positive numbers only
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b -a);
}

int main() {
    int a, b, c, d;

    scanf("%d%d%d%d", &a, &b, &c, &d);
    printf("%d/%d", a*c/gcd(a*c, b*d), b*d/gcd(a*c, b*d));

    return 0;
}
