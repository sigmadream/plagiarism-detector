#include <stdio.h>

int gcd(int a, int b)
{
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

typedef struct Rational
{
    int up, down;
} rational;

int main()
{
    rational A, B;

    scanf("%d %d", &A.up, &A.down);
    scanf("%d %d", &B.up, &B.down);

    A.up *= B.up;
    A.down *= B.down;

    int GCD = gcd(A.up, A.down);

    printf("%d/%d", A.up / GCD, A.down / GCD);

    return 0;
}