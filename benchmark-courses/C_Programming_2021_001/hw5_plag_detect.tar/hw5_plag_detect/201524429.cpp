#include <stdio.h>
#include <math.h>

int GCD(int a, int b){
    int i, result;
    for(i =1;i<=((abs(a)<abs(b)) ? abs(a):abs(b));i++){
        if(abs(a)%i == 0 && abs(b)%i == 0){
            result = i;
        }
    }
    return result;
}
typedef struct Rational{
    int numerator;
    int denominator;
}Rational;

Rational reduction(Rational a){
    Rational c;
    int aGCD = GCD(a.denominator,a.numerator);
    c.denominator = a.denominator / aGCD;
    c.numerator = a.numerator / aGCD;
    return c;
}
Rational RationalMul(Rational a, Rational b){
    Rational c;
    c.denominator = a.denominator * b.denominator;
    c.numerator = a.numerator * b.numerator;
    c = reduction(c);
    return c;
}

int main() {
    Rational a;
    Rational b;

    scanf("%d %d",&a.numerator,&a.denominator);
    scanf("%d %d",&b.numerator,&b.denominator);
    Rational c;
    c = RationalMul(a,b);
    printf("%d/%d",c.numerator,c.denominator);
    return 0;
}
