#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int son;
    int mother;
} Rational;

int gcd(int a, int b) {
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b,a);
    else
        return gcd(a, b - a);
}

int main()
{
    Rational n1, n2, result;
    scanf("%d %d", &n1.son, &n1.mother);
    scanf("%d %d", &n2.son, &n2.mother);

    int a = n1.son * n2.son;
    int b = n1.mother * n2.mother;

    result.son = a / gcd(a,b);
    result.mother = b / gcd(a,b);

    printf("%d/%d", result.son, result.mother);

    return 0;
}
