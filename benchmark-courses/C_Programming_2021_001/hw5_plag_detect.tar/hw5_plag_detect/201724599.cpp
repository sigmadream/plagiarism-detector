#include <stdio.h>

long gcd(long a, long b) {
	if (a == b)
		return a;
	else if (a > b)
		return gcd(b, a);
	else
		return gcd(a, b - a);
}

typedef struct
{
	long n1;
	long n2;

} Rational;
int main(void)
{
	long bottom = 0, top = 0, max = 0;
	Rational data1;
	Rational data2;
	scanf("%ld %ld", &data1.n1, &data1.n2);
	scanf("%ld %ld", &data2.n1, &data2.n2);

	bottom = data1.n2 * data2.n2;
	top = data1.n1 * data2.n1;

	max = gcd(top, bottom);
	top = top / max;
	bottom = bottom / max;

	printf("%ld/%ld\n", top, bottom);
	return 0;
}