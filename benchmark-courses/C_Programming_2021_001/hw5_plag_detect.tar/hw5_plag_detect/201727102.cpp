#include<stdio.h>

typedef struct Rational{
	int up;
	int lo;
	
} Rational;

int ration1(int x, int y)
{
	if(x==y)
		return x;
	else if(x>y)
		return ration1(y,x);
	else
		return ration1(x,y-x);
	
}

int main()
{
	int x1,y1,x2=1,y2=1,k;
	
	
	while(scanf("%d%d",&x1,&y1)==2)
	{
		x2=x2*x1;
		y2=y2*y1;
	}
	
	k=ration1(x2,y2);
	
	x2=x2/k;
	y2=y2/k;
	
	
	printf("%d/%d",x2,y2);
	
	
	return 0;
	
	
}
