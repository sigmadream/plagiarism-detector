#include <stdio.h>

typedef struct {
    int num1;
    int num2;
} rn;

int gcd(int a, int b)
{
    if (b == 0)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b%a);
}

int main()
{
    int a, b;
    scanf("%d %d", &a, &b);
    rn rn1 = {a, b};
    scanf("%d %d", &a, &b);
    rn rn2 = {a, b};

    a = rn1.num1 * rn2.num1;
    b = rn1.num2 * rn2.num2;

    int d = gcd(a, b);
    a /= d;
    b /= d;

    printf("%d/%d", a, b);





    return 0;
}

