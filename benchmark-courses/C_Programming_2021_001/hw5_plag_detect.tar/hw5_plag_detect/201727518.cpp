#include <stdio.h>
#include <stdlib.h>

typedef struct value{

    int up;
    int down;

}Rational;

int gcd(int , int);

int main()
{

    Rational first , second , result;



    scanf("%d %d" , &first.up , &first.down);
    scanf("%d %d" , &second.up , &second.down);

    result.up = first.up * second.up;
    result.down = first.down * second.down;

    int max_common = gcd(result.up , result.down);

    printf("%d/%d" , result.up/max_common , result.down/max_common);
}

int gcd(int a , int b){
    if(a == b){
        return a;
    }
    else if (a > b){
        return gcd(b , a);
    }

    else{
        return gcd(a , b-a);
        //b%a
    }

    }

