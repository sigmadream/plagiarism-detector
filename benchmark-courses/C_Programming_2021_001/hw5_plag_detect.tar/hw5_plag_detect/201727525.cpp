#include <stdio.h>
// 유클리드 호제법 (재귀)
int gcd(int a, int b)
{
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a); // 작은게 항상 앞으로
    else
        return gcd(a, b - a);
}

// 구조체 정의!!
typedef struct
{
    int a;  // 분모
    int b;  // 분자
} Rational; // 구초제 이름을 Rational이라 명명한다

int main()
{
    int A, B, C;

    Rational first, second; // 구조체 사용
    scanf("%d%d", &first.a, &first.b);
    scanf("%d%d", &second.a, &second.b);
    A = first.a * second.a;
    B = first.b * second.b;
    C = gcd(A, B);
    A = A / C;
    B = B / C;
    printf("%d/%d", A, B);
    return 0;
}