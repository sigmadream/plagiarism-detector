#include <stdio.h>

typedef struct Fraction_
{
    int up;
    int down;
} Fraction;

int gcd(int a, int b)
{
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

int main()
{
    Fraction frac1;
    Fraction frac2;

    scanf("%d%d", &frac1.up, &frac1.down);
    scanf("%d%d", &frac2.up, &frac2.down);

    Fraction result;
    result.up = frac1.up * frac2.up;
    result.down = frac1.down * frac2.down;

    int gcd_out = gcd(result.up, result.down);

    printf("%d/%d\n", result.up / gcd_out, result.down / gcd_out);

    return 0;
}
