#include <stdio.h>

typedef struct Pnt
{
    int s,m;
} Point;

int gcd(int a, int b)
{
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

int main()
{
    Point p, q;

    int s, m, s_1, m_1;

    scanf("%d%d\n", &p.s, &p.m);
    scanf("%d%d", &q.s, &q.m);

    s = p.s*q.s;
    m = p.m*q.m;

    s_1 = s / gcd(s, m);
    m_1 = m / gcd(s, m);



    printf("%d/%d", s_1, m_1);
    return 0;
}
