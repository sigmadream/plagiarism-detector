#include <stdio.h>
#include <stdlib.h>

typedef struct Rational{
        int up,down;
    } Ratio;

int gcd(int a, int b){
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b-a);
}

int main()
{
    Ratio A,B;
    int GCD_AB;

    scanf("%d %d\n%d %d",&A.up, &A.down, &B.up, &B.down);
    GCD_AB = gcd(A.up*B.up, A.down*B.down);
    printf("%d/%d\n", A.up*B.up/GCD_AB, A.down*B.down/GCD_AB);

    return 0;
}
