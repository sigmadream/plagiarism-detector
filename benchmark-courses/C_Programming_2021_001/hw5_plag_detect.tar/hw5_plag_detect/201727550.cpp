//
//  main.c
//  Problem5
//
//  Created by 황승한 on 2021/06/30.
//

#include <stdio.h>
int gcd(int up, int down);

typedef struct{
    int upper;
    int lower;
    
} Rational;

int main(){
    Rational a, b;
    scanf("%d %d", &a.upper, &a.lower);
    scanf("%d %d", &b.upper, &b.lower);
    
    int up = a.upper * b.upper;
    int down = a.lower * b.lower;
    
    int divide = gcd(up,down);
    
    printf("%d/%d", up/divide , down/divide);
    return 0;
}

int gcd(int up, int down){
    if(up==down)
        return up;
    else if(up>down)
        return gcd(down, up);
    else
        return gcd(up, down - up);
}
