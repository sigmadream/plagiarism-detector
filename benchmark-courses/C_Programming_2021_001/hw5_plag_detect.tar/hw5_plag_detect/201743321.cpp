#include <stdio.h>

typedef struct Rational
{
    int a,b;
} rational;

int gcd(int a,int b){
    if (b == 0)
        return a;
    else
    return gcd(b,a%b);
}
int main(void){
    rational p1,p2;
    int numerator,denominator,gcdi;
    scanf("%d %d\n",&p1.a,&p1.b);
    scanf("%d %d",&p2.a,&p2.b);
    numerator = (p1.a*p2.a);
    denominator =(p1.b*p2.b);
    gcdi = gcd(numerator,denominator);
    numerator = numerator/gcdi;
    denominator = denominator/gcdi;
    printf("%d/%d",numerator,denominator);

    return 0;
}
