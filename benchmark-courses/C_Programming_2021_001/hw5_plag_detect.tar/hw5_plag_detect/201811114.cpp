#include <stdio.h>

typedef struct Rational
{
	int a, b;
} Rat;
int gcd(int a, int b) {
	if (a == b)
		return a;
	else if (a > b)
		return gcd(b, a);
	else
		return gcd(a ,b - a);
}


int main() {
	
	Rat n1;
	Rat n2;
	Rat n3;
	
	scanf("%d%d\n", &n1.a, &n1.b);
	scanf("%d%d\n", &n2.a, &n2.b);
	n3.a = n1.a * n2.a;
	n3.b = n1.b * n2.b;
	printf("%d/%d", n3.a / gcd(n3.a,n3.b), n3.b / gcd(n3.a,n3.b));
	return 0;
}