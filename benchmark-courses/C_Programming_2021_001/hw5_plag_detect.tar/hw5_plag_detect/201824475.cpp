#include <stdio.h>


int gcd(int a, int b) {

	if (a == b)
		return a;
	else if (a > b)
		return gcd(b, a);
	else
		return gcd(a, b - a);
}

typedef struct Rational{
	int bunza;
	int bunmo;
} Rational;

Rational RationalMul(Rational a, Rational b){
	Rational c;
	c.bunmo = a.bunmo * b.bunmo;
	c.bunza = a.bunza * b.bunza;
	c = reduction(c);
	return c;
}

int main() {
	Rational x = {a, b};
	Rational y = {c, d};

	scanf("%d%d%d%d", &a, &b, &c, &d);
	printf("%d %d %d\n", a, b, gcd(a, b));
	printf("%d %d %d\n", c, d, gcd(c, d));

	return 0;
}

