#include <stdio.h>


typedef struct Num{
    int a, b, c, d;

} num;


int gcd(int e, int f) {
    if (e == f)
        return e;

    else if (e > f)
        return gcd(f, e);
    else
        return gcd(e, f-e);



}


int main(){
    num x;
    scanf("%d %d\n%d %d", &x.a, &x.b, &x.c, &x.d);
    int e = x.a * x.c;
    int f = x.b * x.d;

    printf("%d/%d", e/gcd(e, f), f/gcd(e, f));



}
