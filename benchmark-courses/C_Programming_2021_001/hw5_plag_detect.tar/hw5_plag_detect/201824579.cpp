#include <stdio.h>

int gcd(int a, int b)
{
	if(a == b)
		return a;
	
	else if(a>b)
		return gcd(b,a);
	else
		return gcd(a,b-a);
}

typedef struct {
	int n1;
	int n2;
}Rat;

int main()
{
	Rat s1;
	Rat s2;
	int n3=0;
	int n4=0;
	int n5=0;
	
	scanf("%d %d",&s1.n1,&s1.n2);
	scanf("%d %d",&s2.n1,&s2.n2);
	
	n3=(s1.n1) * (s2.n1);
	n4=(s1.n2) * (s2.n2);
	
	n5=gcd(n3,n4);
	
	printf("%d/%d",(n3/n5),(n4/n5));
	
	return 0;
}

