#include <stdio.h>
#include <stdlib.h>

int gcd(int a, int b){
    if (a==0 || b==0){
        return 1;
    }
    if (a<0){
        a=abs(a);
    }
    else if(b<0){
        b=abs(b);
    }
    if (a==b){
        return a;
    }
    else if (a > b){
        return gcd(b, a);
    }
    else{
        return gcd(a, b-a);
    }
}

int main()
{
    typedef struct Rational{
        int up;
        int down;
    } Rational;
    Rational a, b, result;

    scanf("%d%d",&a.up, &a.down );
    scanf("%d%d",&b.up, &b.down );
int gcd1=gcd(a.up, b.down);
int gcd2=gcd(a.down, b.up);


result.up=a.up/gcd1 * b.up/gcd2;
result.down=a.down/gcd2 * b.down/gcd1;

int gcd3=gcd(result.up, result.down);

result.up=result.up/gcd3;
result.down=result.down/gcd3;

printf("%d/%d", result.up, result.down);
    return 0;
}
