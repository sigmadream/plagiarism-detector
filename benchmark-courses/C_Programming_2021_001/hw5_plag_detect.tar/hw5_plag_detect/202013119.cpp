#include <stdio.h>

typedef struct {
    int a;
    int b;
    int c;
    int d;
    int deno;
    int mole;
    int GCD;
    } Val;

int gcd(int a, int b) {

    if (a == b)
        return a;

    else if (a > b)
        return gcd(b, a);

    else
        return gcd(a, b - a);
    }

int main()
{
    Val v;
    scanf("%d%d", &v.a, &v.b);
    scanf("%d%d", &v.c, &v.d);

    v.mole = v.a * v.c;
    v.deno = v.b * v.d;

    v.GCD = gcd(v.mole, v.deno);
    v.mole = v.mole/v.GCD;
    v.deno = v.deno/v.GCD;

    printf("%d/%d", v.mole, v.deno);

    return 0;
    }
