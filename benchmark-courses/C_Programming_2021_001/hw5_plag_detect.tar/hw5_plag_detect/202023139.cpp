#include <stdio.h>

int gcd(int a, int b) {
    if (a == b) {
        return a ;
    }
    else if (a > b) {
        return gcd(b, a);
    }
    else return gcd(a, b - a);

}

typedef struct {
    int x ;
    int y ;
} Rational ;

int main() {

    int c, d, e ;
    Rational s1, s2 ;

    scanf(" %d %d/n", &s1.x, &s1.y);
    scanf(" %d %d", &s2.x, &s2.y);

    c = s1.x*s2.x ;
    d = s1.y*s2.y ;
    e = gcd(c, d);

    c = c / e ;
    d = d / e ;

    printf("%d/%d", c, d);

    return 0 ;

}
