#include <stdio.h>

typedef struct Rational rational;

struct Rational {
    int numerator;
    int denominator;
};

int gcd(int a, int  b) {
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

int main() {
    rational a, b, res;
    int n;
    scanf("%d%d%d%d", &a.numerator, &a.denominator, &b.numerator, &b.denominator);
    res.numerator = a.numerator*b.numerator;
    res.denominator = a.denominator*b.denominator;
    n = gcd(res.numerator, res.denominator);
    res.numerator = res.numerator / n;
    res.denominator = res.denominator / n;
    printf("%d/%d", res.numerator, res.denominator);
    return 0;
}