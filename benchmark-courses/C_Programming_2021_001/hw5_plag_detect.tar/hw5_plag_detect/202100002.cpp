#include <stdio.h>

int gcd(int a, int b) {
    //  assuming positive numbers only
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

typedef struct {
    int a, b;
} Rational;

Rational mult(Rational p, Rational q) {
    Rational r;
    r.a = p.a * q.a;
    r.b = p.b * q.b;
    int g = gcd(r.a, r.b);
    r.a /= g;
    r.b /= g;
    return r;
}

int main() {
    Rational p, q, r;

    scanf("%d%d%d%d", &p.a, &p.b, &q.a, &q.b);
    r = mult(p, q);
    printf("%d/%d\n", r.a, r.b);

    return 0;
}
