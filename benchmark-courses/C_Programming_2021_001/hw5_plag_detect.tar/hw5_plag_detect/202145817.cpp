/*
    210630wed
    rational.c
*/
#include <stdio.h>

int get_gcd(int a, int b) {
    if (a == b)
        return a;
    else if (a > b)
        return get_gcd(b, a);
    else
        return get_gcd(a, b - a);
}

int main(void) {
    int denominator;
    int numerator;
    int gcd;

    struct rational_number {
        int x;
        int y;
    } num1, num2;

    scanf("%d%d", &num1.x, &num1.y);
    scanf("%d%d", &num2.x, &num2.y);

    // 분수 계산하기
    numerator = num1.x * num2.x;
    denominator = num1.y * num2.y;

    // 최대공약수 구하기
    gcd = get_gcd(numerator, denominator);

    // 기약분수 형태로 출력하기
    printf("%d/%d\n", numerator / gcd, denominator / gcd);

    return 0;
}