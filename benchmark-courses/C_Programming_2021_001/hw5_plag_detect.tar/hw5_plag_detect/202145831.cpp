#include <stdio.h>

typedef struct rational {
    int x;
    int y;
} Point;

int gcd(int a_mul, int b_mul) {

    if (a_mul == b_mul)
        return a_mul;
    else if (a_mul > b_mul)
        return gcd(b_mul, a_mul);
    else
        return gcd(a_mul, b_mul - a_mul);
}

int main(void)
{
    Point s;
    Point t;

    int a_mul, b_mul;

    scanf("%d %d", &s.x, &s.y);
    scanf("%d %d", &t.x, &t.y);

    a_mul = s.x * t.x;
    b_mul = s.y * t.y;

    printf("%d/%d", a_mul / gcd(a_mul,b_mul), b_mul / gcd(a_mul,b_mul));

    return 0;
}
