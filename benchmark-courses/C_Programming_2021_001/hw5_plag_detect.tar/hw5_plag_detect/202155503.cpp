#include <stdio.h>
#include <stdlib.h>

int gcd(int a, int b)
{
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}
/*
struct number
{
  int num;
  int dino;
  int gcd;
} number1;
*/

typedef struct number
{
    int num;
    int dino;
    int gcd;
} _number;

void print_number(struct number number1)
{
    number1.num = (number1.num / number1.gcd);
    number1.dino = (number1.dino / number1.gcd);
    printf("%d/%d", number1.num , number1.dino);
}

int main()
{
    int a, b, c, d, sum_num, sum_dino, gcd_num;
    _number number1;

    scanf("%d%d", &a, &b);
    scanf("%d%d", &c, &d);
    sum_num = a * c;
    sum_dino = b * d;
    gcd_num = gcd(sum_num, sum_dino);

    number1.num = sum_num;
    number1.dino = sum_dino;
    number1.gcd = gcd_num;

    print_number(number1);

    return 0;
}
