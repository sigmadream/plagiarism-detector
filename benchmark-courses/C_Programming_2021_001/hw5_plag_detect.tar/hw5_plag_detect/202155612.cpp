#include <stdio.h>
int gcd(int a, int b) {
if (a == b)
    return a;
else if (a > b)
    return gcd(b, a);
else
    return gcd(a, b - a);
}

typedef struct Rational{
    int up;
    int down;
}Rational;

int main() {
Rational r1,r2;

scanf("%d%d", &r1.up, &r1.down);
scanf("%d%d", &r2.up, &r2.down);

Rational r3 = {r1.up*r2.up,r1.down*r2.down};
Rational r4 = {r3.up/gcd(r3.up,r3.down), r3.down/gcd(r3.up,r3.down)};

printf("%d/%d", r4.up,r4.down);
return 0;
}


