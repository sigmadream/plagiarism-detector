#include <stdio.h>
#define MAXN 10000

int voters[10001];

int main()
{
    int N, input, cnt = 0, drawNum = 0;
    int maxVoter = 0, maxVotes = 0;

    scanf("%d", &N);

    for (int i = 0; i < N; i++)
    {
        scanf("%d", &input);
        if (input == 0)
            continue;

        voters[input]++;
        if (voters[input] > maxVotes)
        {
            maxVotes = voters[input];
            maxVoter = input;
        }

        cnt++;
    }

    for (int i = 1; i <= MAXN; i++)
    {
        if (maxVotes == voters[i])
            drawNum++;
    }

    if (drawNum > 1)
        printf("DRAW %d\n", drawNum);
    else
        printf("%d\n", maxVoter);

    printf("%.2f%%\n", (float)maxVotes / (float)cnt * 100);

    return 0;
}