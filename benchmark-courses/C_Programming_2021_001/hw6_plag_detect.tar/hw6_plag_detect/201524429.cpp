#include <stdio.h>

int main() {
    int n;
    scanf("%d",&n);
    int vote[n];
    int vote2[10] = {0};
    int draw = 1;
    int draw2 = 0;
    for(int i=0;i<n;i++){
        scanf("%d",&vote[i]);
    }
    for(int i=0;i<sizeof(vote)/sizeof(vote[0]) ;i++){
        if(vote[i] == 0){
            n = n - 1;
        }
        //printf("%d\n",vote[i]);
    }
    int m,freq,cnt = 1;
    for(int i=0;i<n;i++){
        freq = 1;
        for(int j=i+1;j<n;j++){
            if(vote[i] == vote[j]){
                freq += 1;
            }
        }
        if(freq > cnt){
            m = vote[i];
            cnt = freq;
            draw++;
            //vote2[i] = vote[i];

            //printf("freq %d ",freq);
        }
        if(freq == cnt){
            draw++;
            vote2[i] = vote[i];
        }


    }

    //printf("%d , %d\n",m,cnt);
       // printf("%d\n",draw);
    if(cnt*2 >= n) {
        printf("%d\n", m);
        //printf("%d %d\n",cnt,n);
        printf("%0.2f%%", (double) cnt / (double) n * 100);
    }
    else if(draw > 1 || cnt*2 < n) {


        printf("DRAW %d\n",draw-1);
        printf("%0.2f%%",(double)cnt/(double)n*100);
    }

    return 0;
}
