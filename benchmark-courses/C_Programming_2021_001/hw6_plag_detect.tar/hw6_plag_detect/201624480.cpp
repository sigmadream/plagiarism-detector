#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N;
    scanf("%d", &N);
    int vote[N];
    int freq[N];
    int totalVote = 0;
    int MaxCandidate = vote[0];
    int MAXvote = 0;
    for(int i = 0; i < N; i++){
        scanf("%d", &vote[i]);
        if(vote[i] != 0){
            freq[vote[i]] += 1;
            totalVote += 1;
            if(freq[vote[i]] > MAXvote) {
                MAXvote = freq[vote[i]];
                MaxCandidate = vote[i];
            }
        }
        //else if(freq[vote[i] == MAXvote)
    }

    printf("%d\n", MaxCandidate);
    printf("%.2f%%\n", MAXvote / totalVote * 100);
    return 0;
}
