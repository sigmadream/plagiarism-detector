#include <stdio.h>

int main()
{
	int n;
	int max = 0;
	int max_result = 0;
	int count = 0;
	int size = 0;
	int j = 0;
	int d = 1;
	int k = 0;
	int result_count = 0;
	int arr[10000];
	int result[1000] = { 0, };
	scanf("%d", &n);

	for (int i = 0; i < n; i++) {
		scanf("%d", &arr[i]);
	}

	for (int i = 0; i < n; i++) {
		if (arr[i] != 0)
			size++;
	}

	while (1) {
		if (j == n)
			break;

		for (int i = 0; i < n; i++) {
			if (arr[j] == arr[i]) {
				count++;
			}
		}
		
		if (count > max && arr[j] != 0) {
			max = count;
			max_result = arr[j];
			d = 1;
			int result[10000] = { 0, };
			result[0] = arr[j];
			k = 0;
		}

		if (count == max && arr[j] != 0 && max_result != arr[j]) {
			for (int i = 0; i < k; i++) {
				if (result[i] == arr[j])
					result_count++;
				else {
					result[k + 1] = arr[j];
				}
			}
			if (result_count == 0) {
				d++;
				k++;
			}
		}

		j++;
		count = 0;
	}
	double voting = (double) max / size*100;

	if (d > 1) {
		printf("DRAW %d\n", d);
		printf("%.2f%%",voting);
	}
	else {
		printf("%d\n", max_result);
		printf("%.2f%%", voting);
	}
	return 0;
}