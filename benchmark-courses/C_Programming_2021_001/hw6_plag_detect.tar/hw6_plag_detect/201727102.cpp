#include<stdio.h>

int main()
{
	int vote[10001];
	int max_vote=0,n,i,n1=0,j,n2=0,n6=0;
	double n3,n4,n5;
	
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		scanf("%d",&vote[i]);
		if(i==0&&vote[0]!=0)
		{max_vote=vote[i];}
		else if(vote[i]==vote[i-1]&&i!=0&&vote[i]!=0){
			n1++;
			max_vote=vote[i];
		}
		else if(vote[i]!=vote[i-1]&&i!=0&&vote[i]!=0){
			for(j=0;j<i;j++){
				if(vote[j]==vote[i]){
					n2++;
				}
				else if(j==i-1){
					if(n2==n1){
						
					}
					else if(n2>n1){
						n1=n2;
						max_vote=vote[i];
						
					}
				}
			}
		}
		
			
		
	}
	
	n4=n;
	n5=n1;
	
	n3=n5/n4;
	if(n6>=1)
	{
		printf("DRAW %d",n6);
		printf("%2.2f",n3*100);
		puts("%");
	}
	else if(n6==0){
	printf("%d\n",max_vote);
	printf("%2.2f",n3*100);
	puts("%");
	}
	return 0;
}
