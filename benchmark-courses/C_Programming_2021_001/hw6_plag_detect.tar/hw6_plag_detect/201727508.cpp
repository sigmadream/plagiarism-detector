#include <stdio.h>

int main()
{
    int n = 0; // real num of voting
    int m; // # of voting
    int vote[10000] = {0}; // # of voted
    int a; // buf
    int max_num = 0; // max num of cand
    scanf("%d", &m);
    for (int i =0; i<m; i++)
    {
        scanf("%d", &a);
        if (a != 0)
            n++;
        vote[a]++;
        if (max_num < a)
            max_num = a;
    }

    float max_vote = 0; // max num of vot
    int max_vote_num = 0; // num of max_vote
    int max_cand;
    for (int i=1; i<=max_num; i++)
    {
        if (vote[i] == max_vote)
            max_vote_num++;
        else if (vote[i] > max_vote)
        {
            max_vote = vote[i];
            max_vote_num = 1;
            max_cand = i;
        }
    }

    if (max_vote_num == 1)
    {
        printf("%d\n%.2f%%", max_cand, (max_vote / n) * 100);
    }
    else
    {
        printf("DRAW %d\n%.2f\%%", max_vote_num, (max_vote / n) * 100);
    }

    return 0;
}
