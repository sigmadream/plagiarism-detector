#include <stdio.h>
// 승한방식도 비교해보고 array는 강의 들어서 기본 다져보기..?
int main()
{
    int vote[10001] = {0};
    int total_vote, element;
    int count = 0; //실제 수(기권 제외)
    int same_compare = 0;
    int max_count = 0, max_index;

    scanf("%d", &total_vote);

    for (int i = 0; i < total_vote; ++i)
    {
        scanf("%d", &element);
        if (element != 0)
        {
            vote[element] = vote[element] + 1;
            count = count + 1;
        }
        if (element == 0)
        {
            continue;
        }
    }
    for (int i = 0; i < 10001; ++i)
    {
        if (max_count < vote[i])
        {
            max_count = vote[i];
            max_index = i;
        }
    }
    for (int i = 0; i < 10001; i++)
    {
        if (vote[i] == max_count)
        {
            same_compare = same_compare + 1;
        }
    }
    //max 값경우 같은 득표수의 후보 구하기
    if (same_compare == 1)
    {
        printf("%d\n", max_index);
        printf("%.2f", (double)max_count / count * 100); // 소수점 이거 두자리 이런거 주의
        printf("%%");                                    // 이렇게 두번써야 실제 % 글자로 인식함
    }
    else
    {
        printf("DRAW %d\n", same_compare);
        printf("%.2f", (double)max_count / count * 100);
        printf("%%");
    }

    return 0;
}