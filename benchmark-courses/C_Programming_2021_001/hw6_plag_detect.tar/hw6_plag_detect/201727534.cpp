#include <stdio.h>

void print_vote(int max_vote, int count, int same_num, int max_cand)
{
    double percent = (double)max_vote / count * 100;

    if (same_num > 1)
    {
        printf("DRAW %d\n", same_num);
        printf("%.2f%%", percent);
    }
    else //동수가 없을 경우
    {
        printf("%d\n", max_cand);
        printf("%.2f%%", percent);
    }
}

int main()
{
    int size = 0;
    int max_cand = 0; // 최다 득표 후보
    int max_vote = 0; // 최다 득표수
    int count = 0;    // 기권 제외
    int same_num = 0;
    double percent = 0.0;
    scanf("%d", &size);

    int votes[10000];
    int cand[10000] = {0};

    for (int i = 0; i < size; ++i)
    {
        scanf("%d", &votes[i]);
        if (votes[i] != 0)
        {
            cand[votes[i]] += 1;
            count++;
        }
    }

    for (int i = 0; i < 10000; ++i)
    {
        if (cand[i] == max_vote)
            same_num++;
        else if (cand[i] > max_vote)
        {
            max_vote = cand[i];
            max_cand = i;
            same_num = 1;
        }
        else
            continue;
    }

    print_vote(max_vote, count, same_num, max_cand);

    return 0;
}