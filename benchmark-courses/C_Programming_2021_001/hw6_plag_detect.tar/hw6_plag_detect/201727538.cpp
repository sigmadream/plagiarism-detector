#include <stdio.h>

int main()
{
    int i, j, e, cand, max_vote;
    int m=0;
    scanf("%d", &cand);
    int vote[10000];
    int max[10000];
    float rate;
    max[0]=0;
    max_vote = 0;

    for(i=0; i<cand; i++)
    {
        scanf("%d", &e);
        vote[i] = e;
    }

    for(i=0; i<cand; i++)
    {
        for(j=i+1; j<cand; j++)
        {
            if (vote[i] == 0)
            {
                continue;
            }
            if (vote[i] == vote[j])
            {
                max[i] = max[i]+1;
            }
            else
                continue;
        }
    }
    for (i=0; i < cand; i++)
    {
        for(j=i+1; j<cand; j++)
        {
            if (vote[i] >0 && max[i] ==max[j])
                m = m+1;
        }
        if (max[i] > max_vote)
            max_vote = max[i];
    }
    if (m>0) {
        printf("DRAW %d\n", m);
        rate = (float)cand / (float)m;
        printf("%.2f", rate);
    }
    else
        printf("%d\n", max_vote);
        printf("%.2f", rate);
    return 0 ;
}
