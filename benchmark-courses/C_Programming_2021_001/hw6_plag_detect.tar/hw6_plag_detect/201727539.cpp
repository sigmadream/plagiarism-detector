#include <stdio.h>
#include <stdlib.h>

typedef struct _Vote{
    int number;
    int count;
} Vote;

int main()
{
    int N, total, Maxvote;
    double voteRate;
    int Maxcount=1;
    int MaxcountN=0;
    scanf("%d",&N);
    total = N;
    Vote vote[N];
    for(int i=0;i<N;i++){
        scanf("%d",&vote[i].number);
        vote[i].count=1;
    }

    for(int i=0;i<N;i++){
        if(vote[i].number==0){
            total--;
        }
        else{
            if(vote[i].count==1){
                for(int j=i;j<N;j++){
                    if(i==j){
                        continue;
                    }
                    if(vote[i].number==vote[j].number){
                        vote[i].count++;
                        vote[j].count++;
                    }
                }
                if(Maxcount<vote[i].count){
                    Maxcount = vote[i].count;
                    MaxcountN = 1;
                    Maxvote = vote[i].number;
                }
                else if(Maxcount==vote[i].count){
                    MaxcountN++;
                    Maxvote = vote[i].number;
                }
            }
        }
    }

    if(total!=0){
        voteRate = (double)Maxcount/(double)total*100;
    }

    if(MaxcountN==1){
        printf("%d\n", Maxvote);
        printf("%.2f%%\n",voteRate);
    }
    else{
        printf("DRAW %d\n", MaxcountN);
        printf("%.2f%%\n", voteRate);
    }

    return 0;
}
