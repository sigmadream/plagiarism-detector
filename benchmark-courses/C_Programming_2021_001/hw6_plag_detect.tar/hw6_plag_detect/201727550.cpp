//
//  main.c
//  Problem6
//
//  Created by 황승한 on 2021/07/01.
//

#include <stdio.h>


int main(){
    int n = -1;
    scanf("%d", &n);
    
    int arr[n] , sub[10001] = {0};
    for(int i=0; i<n; ++i){
        scanf("%d",&arr[0]+i);
    }
    
    for(int i=0; i<n ; ++i){
        sub[arr[i]] += 1;
    }
    
    
    int max = -1, index = 1 , equal_score[n], j=0;
    double available_num = n - sub[0];
    for(int i=1; i<10001 ; ++i){
        if(sub[i] == 0){
            continue;
        }
        if(max < sub[i]){
            max = sub[i];
            index = i;
        }
    }
    
    for(int i=1; i< 10001; ++i){
        if(sub[i] == max){
            equal_score[j++] = i;
        }
    }

    if(j == 1){
        printf("%d\n%.2f",index,max/available_num*100);
        putchar('%');
    }else{
        printf("DRAW %d\n",j);
        printf("%.2f",max/available_num*100);
        putchar('%');
    }
    
    
    
    
    
    return 0;
}
