#include <stdio.h>

int main(void){
    int N;
    scanf("%d",&N);
    int vote[10001] = {0};
    int t;
    int max=0;
    int i;
    int max_voted;
    int count_vote=0;
    int count=0;
    for(i=0; i<N; i++){
        scanf(" %d",&t);
        if(t!=0){
            vote[t]+=1;
            count_vote+=1;
        }
    }
    for(i=0; i<10001; i++){
        if(vote[i]>max){
            max_voted = i;
            max = vote[i];
        }
    }
    for(i=0; i<10001; i++){
        if(vote[i]==max){
            count+=1;
        }
    }
    if(count != 1){
        printf("DRAW %d\n%.2f%%",count,(float)max*100/count_vote);
    }
    else{
        printf("%d\n%.2f%%",max_voted,(float)max*100/count_vote);
    }
}