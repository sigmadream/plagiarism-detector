#include <stdio.h>

int main() {
	int vote[10000] = { ' ' };
	int temp[10000] = { '0' };
	int n, max = 0, i,mv=0;
	int sw = 0;
	int count[10000] = { '0' }, drop = 0;
	double vote_rating;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d", &vote[i]);
		temp[i] = vote[i];
	}
	for (i = 0; i < n; i++) {
		if (vote[i] = 0)
			drop++;
		continue;
		for (int j = 0; j < n; j++) {
			if (temp[i]=vote[j])
				count[j]++;
		}
	}
	for (i = 0; i < n; i++) {
		if (count[i] >= max)
			max = count[i];
			mv = i;
	}
	for (i = 0; i < n; i++) {
		if (max = count[i])
			sw++;
	}

	vote_rating = 100 * max/(n-drop);
	if (sw > 1) printf("DRAW %d\n%.2lf%%", vote[mv], vote_rating);
	else printf("%d\n%.2lf%", vote[mv], vote_rating);
	
	return 0;
	
}