#include <stdio.h>

int main(){
	int voting = 1 <= voting <= 10000;
	
	for (int i = 0; i < 10000; i++) {
		if (voting > 10000)
			i = voting;
	}
	scanf("%d", &voting);
	scanf("%d%d%d\n", &voting);
	
	if(voting = )
	
	
}
