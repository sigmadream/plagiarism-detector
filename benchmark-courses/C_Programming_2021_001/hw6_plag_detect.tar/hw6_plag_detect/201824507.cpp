#include <stdio.h>


int main(){
    int a;
    scanf("%d\n", &a);
    int vote[a];
    int n = 0;
    int b[10000] = {0};
    int max_vote = 0;
    int sum = 0;
    int sum_2 = 0;

    while (n < a)
    {
        scanf("%d", &vote[n]);
        n = n+1;

    }
    for(int i = 0; i<a; i++){
        if ( vote[i] != 0)
            b[vote[i]] += 1;
            sum += 1;





    }
    for (int j = 1; j <= 10000; j++) {

        if (b[j]>= max_vote)
            max_vote = j;

    }
    printf("%d\n", max_vote);
    printf("%.2f", max_vote/sum );








    return 0;

}




