#include<stdio.h>
int main()
{
	int size;	
	
	scanf("%d", &size);
	
	
	int a[size];
	
	int k=0;
	int mu = 0;
	for(k=0; k<size; k++)
	{
		scanf("%d",&a[k]);
		if(a[k]==0)
			mu=mu+1;
			
	}
	
	int n=sizeof(a)/sizeof(int);
    int i, j, mode, freq, count=1;
    for(i=0;i<n;i++)
    {
        freq=1;
        for(j=i+1;j<n;j++)
            if(a[i]==a[j])
                freq+=1;
        if(freq>=count)
        {
            mode=a[i];
            count=freq;
        }
    }
    printf("%d \n %d",mode,count);
    return 0;
}

	
