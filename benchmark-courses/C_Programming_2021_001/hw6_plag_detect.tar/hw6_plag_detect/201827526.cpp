#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num=0;
    scanf("%d", &num);
    int arr[10000]= {0};
    int result[10001]= {0};

    for (int i=0; i<num; ++i)
    {
        scanf(" %d", &arr[i]);
    }

    // make result, vote_num
    int vote_num=0;

    int count=0;
    for (int i=0; i<num; ++i)
    {
        if(arr[i]!=0)
        {
            ++vote_num;

            for (int j=0; j<num; ++j)
            {
                if (arr[i]==arr[j])
                {
                    ++count;
                }
                result[arr[i]]=count;
            }
        }
        count=0;
    }

    //find max, index,
    int max=result[0];
    int index=0;
     int draw_count=1;
    for (int i=0; i<10001; ++i)
    {
        if (result[i]!=0 && result[i]>= max)
        {
//            {
                if (result[i]==max)
                {
//                    printf("in the if : %d",i);
                    ++draw_count;
                }
                max=result[i];
                index=i;
//            }
//            printf("result[%d]= %d\n", i, result[i]);
        }
    }

//       printf result
//for(int i=0;i<10001;++i){
//        if (result[i]!=0){
//                printf("result[%d]=%d\n", i, result[i]);
//
//        }
//
//}
//printf("vote_num: %d\n", vote_num);
//printf("index: %d\n", index);
//printf("draw_count: %d\n", draw_count);




    //find draw_count

//    int draw_count=0;
//    for (int i=0; i<10001; ++i)
//    {
//        if (result[i]==max)
//        {
//            ++draw_count;
//        }
//    }

    if (draw_count !=1)
    {
        printf("DRAW %d\n%.2f%%", draw_count, result[index]/(double)vote_num*100);
    }
    else
    {
        printf("%d\n%.2f%%", index, (double)result[index]/vote_num*100);
    }

    return 0;
}
