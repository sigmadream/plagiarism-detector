#include <stdio.h>
#include <stdlib.h>

int main()
{
    double voter = 0.0;
    int max_vote = 0;
    int draw = 0;
    int k;
    scanf("%d", &k);

    int vote[k];
    int can_num[10001] = {0};


    for (int i = 0 ; i < k; ++i)
        scanf("%d", &vote[i]);

    for (int i = 0; i < k; ++i)
        can_num[vote[i]] += 1;

    for (int i = 1; i < 10001; ++i){
        if (can_num[i]>max_vote)
            max_vote = can_num[i];
    }

    for (int i = 1; i < 10001; ++i){
        if (can_num[i] == max_vote)
            draw += 1;
    }

    voter = max_vote;
    voter = (voter/(k-can_num[0]))*100;

    if (draw == 1){
        for (int i = 1; i < 10001; ++i){
            if(max_vote == can_num[i]){
                k = i;
            }
        }
        printf("%d\n", k);
        printf("%.2lf%%", voter);
    }
    else if (draw > 1){
        printf("DRAW %d\n", draw);
        printf("%.2lf%%", voter);
    }


    return 0;
}
