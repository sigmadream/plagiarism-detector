#include <stdio.h>

int main () {

    int high = 0, zeroCount = 0, i, n, j ;
    int ip[n], count[n] ;
    double a, b;

    scanf("%d",&n);

    for (i=0;i<n;i++) {
        scanf("%d",&ip[i]);
    }

    i = 0 ;
    j = 0 ;

    if (i<n) {
        if (j<n) {
            if (ip[i] = ip[j] && ip[i] != 0) {
            count[i] = count[i] + 1;
            j++;
            }
            else if (ip[i]=0) {
                zeroCount++;
                j++;
            }
            else {
                j++;
            }
        }

        i++;
    }

    j=0;
    i=0;

    if (i<n) {
        if (count[i]>high) {
            high=count[i];
            j++;
            i++;
        }
    }

    a = (double) high/(n-zeroCount) ;
    b = (double) 1.0/n ;

    if(a == b) {
        printf("DRAW %d \n%.2f%%", n, a*100);
    }
    else {
        printf("%d \n%.2f%%", ip[j], a*100);
    }

}
