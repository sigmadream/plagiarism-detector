#include <stdio.h>
#include <stdbool.h>

int main()
{
    int votes[100];
    int size, realSize = 0, v = -1, draw = 1, count = 0, maxCount = 0, maxVote = 0;
    bool isDraw = false;
    double rate = 0;
    scanf("%d", &size);
    for (int i=0; i<size; i++) {
        scanf("%d", &v);
        if (v == 0)
            continue;
        else {
        votes[realSize++] = v;
        }
    }
    for (int i=0; i<realSize; i++) {
        count = 0;
        for (int j=i; j<realSize; j++) {
            //printf("%d:%d\n", votes[i], votes[j]);
            if (votes[i] == votes[j])
                count++;
        }
        if (count > maxCount) {
            //printf("cur vote: %d\n", votes[i]);
            //printf("count: %d, maxCount: %d\n", count, maxCount);
            maxCount = count;
            maxVote = votes[i];
            draw = 1;
        } else if (count == maxCount) {
            //printf("draw, %d, count: %d\n", votes[i], count);
            draw++;
        } else {
            continue;
        }
    }
    
    //printf("DRAW: %d\n", draw);
    //printf("maxVote: %d\n", maxVote);
    //printf("maxCount: %d\n", maxCount);

    rate = 100 * (double)maxCount / (double)realSize;
    if (draw > 1)
        printf("DRAW %d\n", draw);
    else
        printf("%d\n", maxVote);
    printf("%.2f", rate);
    printf("%\n");
    return 0;
}
