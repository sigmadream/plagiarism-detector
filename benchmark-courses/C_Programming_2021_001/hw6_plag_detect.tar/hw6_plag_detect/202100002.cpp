#include <stdio.h>

int main(){
    int vote[10001]={0};
    int total_vote;
    int element;
    int count=0; //실제 수(기권 제외)
    int same_compare=0, max_vote_number=0;
    int max_count=0, max_index;

    scanf("%d" , &total_vote);
    for (int i=0; i<total_vote; i++) {
        scanf("%d" , &element);
        if (element != 0) {
            vote[element] += 1;
            if (max_count < vote[element]) {
                max_count = vote[element]; 
                max_index = element;
            }
            count+=1;
            if (max_vote_number < element) { //최대로 높은 후보 번호 넣어주기
                max_vote_number = element;
            }
        }
    }
    for (int i=0; i<max_vote_number+1; i++) {
        if (vote[i] == max_count) {
            same_compare += 1;
        }
    }
    //최고 득표에서 같은 숫자인 후보 구하기
    if (same_compare==1) {
        printf("%d\n" , max_index);
    }
    else {
        printf("DRAW %d\n" , same_compare);
    }
    printf("%.2f%%\n" , (double)max_count/count*100);

    return 0;
}
