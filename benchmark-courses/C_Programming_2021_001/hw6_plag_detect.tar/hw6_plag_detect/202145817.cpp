/*
    210701thu
    voting.c
*/
#include <stdio.h>

int main(void)
{
    int count;
    int final_count;
    int max_count = 0;
    int candidate_num;
    int candidate_count = 0;
    int max_candidate_count = 0;
    int final_candidate;

    // 투표수 입력받아
    scanf("%d", &count);
    int votes[count];
    final_count = count;

    // 여러 표 입력받아
    for (int i = 0; i < count; i++)
        scanf("%d", &votes[i]);

    // 각 후보마다 카운팅(기권은 세지 않음)
    for (int i = 0; i < count; i++) {
        if (votes[i] == 0)
            final_count--;
        else {
            candidate_num = votes[i];
            for (int j = 0; j < count; j++) {
                if (candidate_num == votes[j])
                    candidate_count++;
            }
            if (candidate_count > max_candidate_count) {
                final_candidate = candidate_num;
                max_candidate_count = candidate_count;
            }
        }
    }
    printf("final count: %d,\n", final_count);
    printf("final candidate: %d,\n", final_candidate);
    printf("max candidate count: %d,\n", max_candidate_count);

    return 0;
    // 득표율 최고 뽑아(기권은 뽑지 않음, 동일은 draw)
    // 득표율 계산 = 득표수 / 카운팅(기권은 뺀다)
    // 후보(draw는 항목 개수까지 출력), 득표율 출력
}