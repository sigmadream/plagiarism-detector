#include <stdio.h>
#define MAX 10000
int main()
{
    int x[MAX] = {0};
    int n;
    int i;
    int max_vote = 0;
    int tmp;

    scanf("%d", &n);

    for (i = 0; i < n; i++)
    {
        scanf("%d", &tmp);
        x[tmp]++;
    }

    for (i = 0; i < n; i++)
    {
        if (max_vote < x[i])
            max_vote = x[i];
    }

    printf("%d\n", max_vote);
    printf("%.2f", ((double)max_vote / n) * 100);

    return 0;
}
