#include <stdio.h>

int main()
{
    int votenum = 0;
    int n = 0;
    int vote[10001];
    int bestvote = 0;
    int best = 0;
    int allvote = 0;
    int samevote = 1;

    for (int i=1; i<10001; i++){
        vote[i] = 0;
    }

    scanf("%d", &votenum);

    for (int i=0; i < votenum; i++){
        scanf("%d", &n);
        if (n != 0){
            allvote++;
            vote[n]++;

            if (vote[n] > bestvote){
            samevote = 1;
            best = n;
            bestvote = vote[n];
            }

            else if (vote[n] == bestvote){
            samevote++;
            }
        }

    }

    if (samevote == 1){
        printf("%d\n%.2f%%", best,bestvote*100.0/allvote);
    }
    else {
        printf("DRAW %d\n%.2f%%", samevote, bestvote*100.0/allvote);
    }
return 0 ;
}
