#include <stdio.h>



int main() {
    int row = 0 , col = 0 , i = 0 , j = 0;
    int sr,sc,bomb;
    int cnt = 0;
    scanf("%d %d",&row,&col);
    scanf("%d %d %d",&sr,&sc,&bomb);
    int mat[row][col];
    for(i=0;i<row;i++){
        for(j=0;j<col;j++){
            scanf("%d",&mat[i][j]);
        }
    }
    for(i=0;i<col;i++){
        if(mat[sr][i] != 0 && mat[sr][i] <= bomb){
            cnt++;
        }
    }
    for(j=0;j<row;j++){
        if(j != sr && mat[j][sc] != 0 && mat[j][sc] <= bomb){
            cnt++;
        }

    }

    printf("%d",cnt);
    //printf("Hello, World!\n");
    return 0;
}
