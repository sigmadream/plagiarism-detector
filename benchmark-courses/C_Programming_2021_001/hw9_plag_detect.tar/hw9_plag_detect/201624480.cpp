#include <stdio.h>
#include <stdlib.h>

//int x, y;
//
//int get_row(int arr[x][y], int r){ //��  ���ϱ�
//    //int arr_row[y];
//    for (int k = 0; k < y; k++){
//        int arr_row[k] = arr[r][k];
//    }
//    return arr_row;
//}
//
//int get_col(int arr[x][y], int c){ //�� ���ϱ�
//    //int arr_col[x];
//    for (int k = 0; k < x; k++){
//        int arr_col[k] = arr[k][c];
//    }
//    return arr_col;
//}

int main()
{
    int row, column, r, c, power, i;
    int count = 0;
    scanf("%d %d", &row, &column);
    scanf("%d %d %d", &r, &c, &power);

    int Arr[row][column];
    for (i = 0; i < row; i++)
        for (int j = 0; j < column; j++)
            scanf("%d", &Arr[i][j]);

    int arr_row[column];
    int arr_col[row];

    for (i = 0; i < column; i++) {  //r �� ���� ������ ����
        arr_row[i] = Arr[r][i];
        //printf("%d\n", arr_row[i]);
        if (arr_row[i] != 0){
            if (arr_row[i] >= power)
                count++;
        }
    }

    for (i = 0; i < row; i++) {
        arr_col[i] = Arr[i][c];
        //printf("%d\n", arr_col[i]);
        if (arr_col[i] != 0){
            if (arr_col[i] >= power)
                count++;
        }
    }

    if (Arr[r][c] != 0){
        if (Arr[r][c] >= power)
            count -= 1;
    }

    printf("%d\n", count);

    return 0;
}
