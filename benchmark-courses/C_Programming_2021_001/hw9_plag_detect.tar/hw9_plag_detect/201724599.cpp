#include <stdio.h>

int* get_row(int a[], int row, int m, int n)
{
    static int result_row[101]={0,};
    for(int i=0;i<n;++i){
        result_row[i]=a[row*n+i];
    }
    return result_row;
}

int* get_col(int a[], int col, int m, int n)
{
    static int result_col[101]={0,};
    for(int i=0;i<m;++i){
        result_col[i] = a[col+i*n];
    }
    return result_col;
}

int main()
{
    int m,n;
    int r,c,p;
    int sum = 0;

    scanf("%d %d",&m,&n);
    scanf("%d %d %d",&r,&c,&p);

    int procession[101][101]={{0,},{0,}};

    for(int i=0;i<m;++i){
        for(int j=0;j<n;++j){
            scanf("%d",&procession[i][j]);
        }
    }

    int* rev_row = get_row((int*)procession,r,m,n);
    int* rev_col = get_col((int*)procession,c,m,n);

    for(int i=0;i<n;++i){
        if(p>=rev_row[i]&&rev_row[i] != 0)
            sum ++;
    }

    for(int i = 0;i<m;++i){
        if(p>=rev_col[i] && rev_col[i] != 0)
            sum ++;
    }

    printf("%d",sum);

    return 0;
}
