#include <stdio.h>

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);
    int r, c, p;
    scanf("%d %d %d", &r, &c, &p);
    int A[n][m];
    for (int i=0; i<n; i++)
        for (int j=0; j<m; j++)
        {
            scanf("%du", &A[i][j]);
        }
    int count = 0;
    for (int i=0; i<m; i++)
    {
        if (A[r][i] <= p && A[r][i] != 0)
            count += 1;
    }
    for (int j=0; j<n; j++)
    {
        if (A[j][c] <= p && A[j][c] != 0)
            count += 1;
    }

    if (A[r][c] <= p && A[r][c] != 0)
        count -= 1;

    printf("%d", count);

    return 0;
}


