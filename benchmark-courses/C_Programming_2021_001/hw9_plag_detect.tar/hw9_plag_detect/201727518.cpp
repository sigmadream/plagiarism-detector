#include <stdio.h>

#include <string.h>


//debuging stopatEntry , externalconsole 을 둘다 true 로 한다 

// int get_row(int row , int col , )



int main(){
    //전체
    int row=0 , col=0;
    //위치
    int row_1=0 , col_1=0 , power=0;
    int result =0;
    scanf("%d%d" , &row , &col);
   
    scanf("%d%d%d" , &row_1 , &col_1 , &power);
    int bomb[row][col];
    for (int i=0; i< row; i++){
        for (int j=0; j<col ; j++){
            scanf("%d" , &bomb[i][j]);
        }
        getchar();
    }

    int get_row[col];
    int get_col[row]; 
    int double_element = bomb[row_1][col_1];
    //입력하기
    for (int i=0; i<col; i++){
        get_row[i] = bomb[row_1][i];
        if(get_row[i]<= power && get_row[i]!=0){
            result +=1;
        }
    }

    for(int i=0; i<row; i++){
        get_col[i] = bomb[i][col_1];
        if(get_col[i]<= power && get_col[i]!=0){
            result +=1;
        }
    }

    if(double_element <= power && double_element !=0){
        result = result-1;

        //중복 제거
    }

    printf("%d" , result);

    return 0;
}