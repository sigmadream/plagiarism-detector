#include <stdio.h>

int count_num(int *get_r, int *get_c, int row, int col, int power)
{
    int count = 0;

    for (int i = 0; i < col; i++)
    {
        if (get_r[i] == 0)
            continue;
        else if (get_r[i] <= power)
            count++;
        else
            continue;
    }

    for (int i = 0; i < row; i++)
    {
        if (get_c[i] == 0)
            continue;
        else if (get_c[i] <= power)
            count++;
        else
            continue;
    }

    return count;
}

void get_col(int row, int col, int tar_c, int arr[], int *get_c)
{
    for (int i = 0; i < row; ++i)
    {
        get_c[i] = arr[i * col + tar_c];
    }

    return;
}

void get_row(int col, int tar_r, int arr[], int *get_r)
{
    for (int i = 0; i < col; ++i)
    {
        get_r[i] = arr[tar_r * col + i];
    }

    return;
}

int main()
{
    int row = 0;
    int col = 0;
    int target_row = 0;
    int target_col = 0;
    int power = 0;
    int count = 0;

    scanf("%d %d", &row, &col);

    scanf("%d %d %d", &target_row, &target_col, &power);

    int arr[row][col];

    for (int i = 0; i < row; ++i)
    {
        for (int j = 0; j < col; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    int get_r[col];
    get_row(col, target_row, (int *)arr, get_r);
    int get_c[row];
    get_col(row, col, target_col, (int *)arr, get_c);

    count = count_num(get_r, get_c, row, col, power);

    if (arr[target_row][target_col] <= power && arr[target_row][target_col] != 0)
    {
        count--;
        printf("%d", count);
    }
    else
        printf("%d", count);

    return 0;
}
// 3	7
// 1	2	3
// 0	1	2	0	4	0	1
// 3	4	0	1	9	2	3
// 0	7	0	0	2	1	0

// 2	5
// 0	4	2
// 2	0	5	0	2
// 3	8	0	7	1
