#include <stdio.h>

//int get_row(int a[][], int r_r, int c) {
  //  for (int i=0; i<c; i++)
    //    int b[] = a[r_r][i];
    //return b[];
//}
//int get_col(int a[][], int r, int r_c) {
  //  for (int i=0; i<c; i++)
    //    int c[] = a[i][r_c];
    //return c[];
//}

int main() {
    int row = 0, col = 0, i = 0, j = 0, r_row=0, r_col=0, power=0, count=0;
    scanf("%d%d", &row, &col);
    scanf("%d%d%d", &r_row, &r_col, &power);
    int m[row][col];
    for (i = 0; i < row; i++)
        for (j = 0; j < col; j++)
            scanf("%d", &m[i][j]);

    for (i=0; i<row; i++)
    {
        if ((m[i][r_col] != 0) && (m[i][r_col] <= power))
            count = count +1 ;

    }
    for (i=0; i<col; i++)
    {
        if ((m[r_row][i] != 0) && (m[r_row][i] <= power))
            count = count +1 ;
    }
    if (m[r_row][r_col] != 0)
        count = count -1;
    printf("%d", count);
    return 0;
}
