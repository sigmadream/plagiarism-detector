#include <stdio.h>

int main() {
    int row=0, col=0, x=0, y=0, p=0, i=0, j=0, count=0;
    scanf("%d %d",&row, &col);
    scanf("%d %d %d", &x,&y,&p);
    int m[row][col];
    for (i = 0; i < row; i++)
        for (j = 0; j < col; j++)
            scanf("%d", &m[i][j]);

    for(i=0;i<row;i++){//���� üũ
        if(m[i][y]==0) continue;
        else{
            if(m[i][y]-p<=0) count++;
        }
    }

    for(j=0;j<col;j++){
        if(m[x][j]==0) continue;
        else{
            if(m[x][j]-p<=0) count++;
        }
    }

    if(m[x][y]-p<=0 && m[x][y]!=0) printf("%d\n",count-1);
    else printf("%d\n",count);

    return 0;


}
