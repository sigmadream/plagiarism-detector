#include <stdio.h>

void get_col(int row, int col, int tar_c, int arr[], int *new_col)
{
    for (int i = 0; i < row; ++i)
    {
        new_col[i] = arr[i * col + tar_c];
    }

    return;
}

void get_row(int col, int tar_r, int arr[], int *new_row)
{
    for (int i = 0; i < col; ++i)
    {
        new_row[i] = arr[tar_r * col + i];
    }

    return;
}

int main()
{
    int row = 0 , col = 0 , r = 0, c = 0 , p= 0;
    int count = 0;

    scanf("%d %d %d %d %d", &row, &col, &r, &c, &p);

    int arr[row][col];

    for (int i = 0; i < row; ++i)
    {
        for (int j = 0; j < col; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }
    
    int  new_row[col] , new_col[row];
    get_row(col, r, (int *)arr, new_row);
    get_col(row, col, r, (int *)arr, new_col);

    for (int i = 0; i < col; i++)
    {
        if (new_row[i] == 0)
            continue;
        else if (new_row[i] <= p)
            count++;
    }

    for (int i = 0; i < row; i++)
    {
        if (new_col[i] == 0)
            continue;
        else if (new_col[i] <= p)
            count++;
    }

    if(arr[r][c] != 0){
        if(arr[r][c] <= p)
            count--;
    }

    printf("%d",count);
}
