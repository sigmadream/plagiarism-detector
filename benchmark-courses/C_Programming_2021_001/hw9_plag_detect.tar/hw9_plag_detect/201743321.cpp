#include <stdio.h>

int main(){
    int m,n,i,j;//행의 개수 열의 개수
    int answer=0;
    scanf("%d %d",&m,&n);
    int r,c,p;//행 열 강도
    scanf("%d %d %d",&r,&c,&p);
    int arr[m][n];
    for(i=0;i<m;++i){
        for(j=0;j<n;++j){
            scanf("%d",&arr[i][j]);
        }
    }
    for(i=0;i<n;++i){//행 폭탄
        if(arr[r][i]<=p && arr[r][i]!=0){
            answer+=1;
            arr[r][i]=0;
        }
        }
    for(i=0;i<m;++i){
        if(arr[i][c]<=p && arr[i][c]!=0){
            arr[i][c]=0;
            answer+=1;
        }
    }
    printf("%d",answer);
    return 0;
}
