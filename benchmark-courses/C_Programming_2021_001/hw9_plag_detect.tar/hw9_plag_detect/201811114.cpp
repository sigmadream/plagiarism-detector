#include <stdio.h>
#include <string.h>

int main() {
	int m = 0, n = 0;
	int r = 0, c = 0, p = 0;
	int i = 0, j = 0;
	int s[100][100];
	int cnt = 0,cnt1=0,cnt2=0;
	scanf("%d%d", &m, &n);
	scanf("%d%d%d", &r, &c, &p);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &s[i][j]);
		}
	}
	for (j = 0; j < n; j++) {
		if (s[r][j]!=0 && s[r][j] <= p) cnt1++;
	}
	for (i = 0; i < m; i++) {
		if (s[i][c] != 0 && s[i][c] <= p) cnt2++;
	}
	cnt = cnt1 + cnt2;
	if (s[r][c] != 0 && s[r][c] <= p) cnt = cnt - 1;
	
	printf("%d", cnt);
}