#include <stdio.h>




int main() {
    int row = 0, col = 0, r = 0, c = 0,p = 0, i = 0, j = 0, sum = 0;
    scanf("%d%d", &row, &col);
    int m[row][col];
    scanf("%d%d%d", &r, &c, &p);

    for (i = 0; i < row; i++)
        for (j = 0; j < col; j++)
            scanf("%d", &m[i][j]);

    for (i = 0; i < row; i++){
        if (m[i][c] == 0)
            sum += 0;
        else if (p - m[i][c] >= 0)
            sum += 1;
    }

    for ( j = 0; j < col; j++) {
        if (m[r][j] == 0)
            sum += 0;
        else if (p - m[r][j] >= 0 )
            sum += 1;

    }
    printf("%d", sum);




    return 0;


}
