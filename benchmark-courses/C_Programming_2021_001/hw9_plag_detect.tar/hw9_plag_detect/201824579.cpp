#include<stdio.h>

int main()
{
	int row, col =0;
	
	int rr,cc,power = 0;
	
	scanf("%d%d",&row,&col);
	scanf("%d%d%d",&rr,&cc,&power);
	
	
	int arr[row][col];
	
	int i , j = 0;
	int count = 0;
	
	for(i=0; i<row ; i++)
	{
		for(j=0 ; j < col ; j++)
		{
			scanf("%d",&arr[i][j]);
		}
	}
	
	for(i=0;i<row ; i++)
	{
		if((arr[i][cc]<=power)&&(arr[i][cc]!=0))
		{
			count++;
		}
	}
	
	for(i=0;i<col ; i++)
	{
		if((arr[rr][i]<=power)&&(arr[rr][i]!=0))
		{
			count++;
		}
	}
	
	
	if((arr[rr][cc]<=power)&&(arr[rr][i]!=0))
	{
		count=count-2;
	}
	
	
	printf("%d",count);
	
	return 0;
}
