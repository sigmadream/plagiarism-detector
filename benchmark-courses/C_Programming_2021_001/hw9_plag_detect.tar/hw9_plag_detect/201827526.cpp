#include <stdio.h>
#include <stdlib.h>
//
//void printArr(int * arr, int len){
//    for (int i=0; i < len; ++i){
//        printf("[%d] ; %d\n", i, arr[i]);
//    }
//}
void get_row(int col, int (*arr) [col], int getRow, int * result){

    for (int i=0; i < col; ++i){
            result[i] = arr[getRow][i];

    }
//    printArr(result, col);
}

void get_col(int row, int col, int (*arr) [col], int getCol, int * result){
//    printf("this is : %d", sizeof(arr));

    for (int i=0; i < row; ++i){
        result[i] = arr[i][getCol];
    }
//    return result;
}

//
//void print2Arr(int m, int n, int (*arr)[n]){
//    for (int i=0; i < m; ++i){
//        for (int j=0; j < n; ++j){
//            printf("arr[%d][%d] : %d\n", i, j, arr[i][j]);
//        }
//    }
//}

int countBombRemove(int * arr, int len, int p){
    int result=0;
//    printf("%s\n", "in the countBombRemove");
//    printArr(arr, len);
    for (int i=0; i < len; ++i){
        if (arr[i] <= p && arr[i] != 0){
            ++result;
        }
    }
    return result;
}

int main()
{
    int m,n;
    scanf("%d%d", &m, &n);

    int r, c, p;
    scanf("%d%d%d", &r, &c, &p);

    int arr[m][n];
    for (int i=0; i < m; ++i){
        for (int j=0; j < n; ++j){
            scanf("%d", &arr[i][j]);
        }
    }
    //�Է� ��
//    print2Arr(m, n, arr);

    int row[n]; //ũ�� n
    int col[m];//ũ�� m
//printf("%s\n", "--");
    get_row(n, arr, r, &row);
//    printf("%")
//    printArr(row, n);

    get_col(m, n, arr, c, &col);

//    printArr(col, m);

    int rowCount, colCount;
    rowCount = countBombRemove(row, n, p);
    colCount = countBombRemove(col, m, p);
    if (arr[r][c] != 0 && arr[r][c] <= p && rowCount+colCount-1 >= 0){
        printf("%d", rowCount+colCount-1);

    }
    else{
        printf("%d", rowCount+colCount);
    }

//    int arr[2][3]={{1,2,3},{4,5,6}};

//        int result[2];

//    int * a = get_col(2, 3, arr, 0, result);
//
//    for (int i=0; i < 2; ++i){
//        printf("[%d] : %d\n", i, a[i]);
//    }



    return 0;
}
