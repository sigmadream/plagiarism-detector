#include <stdio.h>
#include <stdlib.h>

int main()
{
    int row = 0, col = 0, i = 0, j = 0, r = 0, c = 0, p = 0, q = 0;
    scanf("%d%d", &row, &col);
    scanf("%d%d%d", &r, &c, &p);
    int m[row][col];
    int s_row[col];
    int s_col[row];
    for (i = 0; i< row; i++)
        for (j = 0; j < col; j++)
            scanf("%d", &m[i][j]);

    for (i = 0 ; i < col; i++)
        s_row[i] = m[r][i];
    for (i = 0 ; i < row; i++)
        s_col[i] = m[i][c];
    for (i = 0 ; i < col; i++)
        if (s_row[i] != 0 && s_row[i] <= p)
            q += 1;
    for (i = 0 ; i < row; i++)
        if (s_col[i] != 0 && s_row[i] <= p)
            q += 1;
    if (m[r][c] != 0 && m[r][c] <= p)
        printf("%d", q-1);
    else
        printf("%d", q);

    return 0;
}
