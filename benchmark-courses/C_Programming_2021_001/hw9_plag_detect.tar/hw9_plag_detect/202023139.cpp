#include <stdio.h>

int main() {
	
	int row = 0, col = 0, i, j, r, c, p, count = 0;
	
	scanf("%d %d", &row, &col);
	
	scanf("%d %d %d", &r, &c, &p);
	
	int m[row][col];
	
	for (i=0;i<row;i++)
		for (j=0;j<col;j++)
			scanf("%d", &m[i][j]);
	
	for (i=0;i<row;i++)
		if (p >= m[i][c] && m[i][c] != 0) 
			count++;
	
	for (j=0;j<col;j++)
		if (p >= m[r][j] && m[r][j] != 0) 
			count++;
	
	if (m[r][c] <= p && m[r][c] != 0)
		count = count-1;
	
	printf("%d", count);
	
	return 0;
	
}
