#include <stdio.h>
#include <stdlib.h>
#define MAX 100

int main() {
    int row, col, x, y, power, res = 0;
    scanf("%d%d", &row, &col);
    scanf("%d%d%d", &x, &y, &power);
    int map[row][col];
    for (int i=0; i<row; i++)
        for (int j=0; j<col; j++)
            scanf("%d", &map[i][j]);
    
    for (int i=0; i<col; i++) {
        if (power >= map[x][i] && map[x][i] != 0)
            res++;
    }

    for (int i=0; i< row; i++) {
        if (i != x && power >= map[i][y] && map[i][y] != 0)
            res++;
    }

    printf("%d\n", res);
    return 0;
}