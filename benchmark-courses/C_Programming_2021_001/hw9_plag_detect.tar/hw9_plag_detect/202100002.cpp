#include <stdio.h>
#include <string.h>

void get_row(size_t m, size_t n, int s[m][n], size_t r, int row[n]) { // row: out param
	for (int j = 0; j < n; j++)
		row[j] = s[r][j]; 
}

void get_col(size_t m, size_t n, int s[m][n], size_t c, int col[m]) { // row: out param
	for (int i = 0; i < m; i++) {
		col[i] = s[i][c];
	}
}

int count(size_t n, int a[n], size_t p) {
	int cnt1 = 0;
	for (int j = 0; j < n; j++) {
		if (0 < a[j] && a[j] <= p) 
			cnt1++;
	}
	return cnt1;
}

int main() {
	int m = 0, n = 0;
	int r = 0, c = 0, p = 0;
	int cnt = 0;
	scanf("%d%d", &m, &n);
	int s[m][n], row[n], col[m];
	scanf("%d%d%d", &r, &c, &p);
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			scanf("%d", &s[i][j]);
		}
	}
	get_row(m, n, s, r, row);
	cnt += count(n, row, p);
	get_col(m, n, s, c, col);
	cnt += count(m, col, p);
	if (s[r][c] != 0 && s[r][c] <= p) 
		cnt--;
	
	printf("%d\n", cnt);
}
