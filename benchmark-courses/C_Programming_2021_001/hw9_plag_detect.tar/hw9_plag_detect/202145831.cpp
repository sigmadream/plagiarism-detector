#include <stdio.h>


int main()
{
   int m, n;
   int r = 0, c = 0, p = 0;


   scanf("%d %d", &m, &n);
   int s[m][n];
   scanf("%d %d %d", &r, &c, &p);

   for (int i = 0; i < m; i++)
       for ( int j = 0; j < n; j++)
        scanf("%d", &s[i][j]);

    if (s[r] < p)




    printf("%d", &);
    return 0;
}
