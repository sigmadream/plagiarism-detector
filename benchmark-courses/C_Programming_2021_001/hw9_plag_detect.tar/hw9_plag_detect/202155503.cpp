#include <stdio.h>
#include <stdlib.h>

int main()
{
    int row, col;
    scanf("%d%d", &row, &col);

    int x, y, fire, bomb_count = 0;
    scanf("%d %d %d", &x, &y, &fire);

    int block[row] [col];
    int s1 = sizeof block / sizeof block[0]; //x��
    int s2 = sizeof block[0] / sizeof block[0][0]; //y��
    for (int i=0; i<s1; i++){
        for (int j=0; j<s2; j++){
            scanf("%d", &block[i][j]);
        }
    }
    //x�� �˻�
    for (int k=0; k < s2; k++){
        if (0 < block[x] [k]){
            if (block[x] [k] <= fire){
                bomb_count = bomb_count + 1;
            }
        }
    }

    //y�� �˻�
    for (int l=0; l < s1; l++){
        if (0 < block [l] [y]) {
            if (block [l] [y] <= fire){
                bomb_count = bomb_count + 1;
            }
        }
    }
    //�ߺ� �˻�
    if (0 < block [x] [y]){
        if (block [x] [y] <= fire){
            bomb_count = bomb_count - 1;
        }
    }
    //�����
    printf("%d", bomb_count);

    return 0;
}
