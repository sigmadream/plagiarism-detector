#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>

int isVowel(char x) {
	if ('Z' < x) {
		x -= 32;
	}

	return x == 'A' || x == 'E' || x == 'I' || x == 'O' || x == 'U';
}

double getSide(int x1, int y1, int x2, int y2) {
	return sqrt(pow(x1 - x2,2) + pow(y1 - y2,2));
}

int main() {
	char word1[41];
	char word2[41];
	char word3[41];

	scanf("%40s", word1);
	scanf("%40s", word2);
	scanf("%40s", word3);

	int x1 = 0, y1 = 0;

	for (size_t i = 0; i < 40; i++)
	{
		if (word1[i] == NULL) {
			break;
		}

		if (isVowel(word1[i])) {
			x1++;
		}
		else {
			y1++;
		}
	}
	int x2 = 0, y2 = 0;

	for (size_t i = 0; i < 40; i++)
	{
		if (word2[i] == NULL) {
			break;
		}

		if (isVowel(word2[i])) {
			x2++;
		}
		else {
			y2++;
		}
	}

	int x3 = 0, y3 = 0;
	for (size_t i = 0; i < 40; i++)
	{
		if (word3[i] == NULL) {
			break;
		}

		if (isVowel(word3[i])) {
			x3++;
		}
		else {
			y3++;
		}
	}

	double a, b, c, s;
	a = getSide(x1, y1, x2, y2);
	b = getSide(x1, y1, x3, y3);
	c = getSide(x2, y2, x3, y3);
	s = (a + b + c) / 2;
	double area = sqrt(s * (s - a) * (s - b) * (s - c));
	printf("%.3lf", area);

	return 0;
 }