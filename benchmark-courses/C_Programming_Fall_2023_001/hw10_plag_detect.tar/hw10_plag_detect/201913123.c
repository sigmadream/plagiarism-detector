#include <stdio.h>
#include <math.h>
#include <ctype.h>
#define MAX 40
double Area();
void spot(char *, int *, int *);
char vowel[10] = {'a', 'e', 'i', 'o', 'u', 'A', 'I', 'O', 'E', 'U'};
int main(){

    printf("%.3f",Area());

    return 0;
}
void spot(char *str, int *x, int *y){
    int tempx = 0;
    int tempy = 0;
    int boolean = 0;
    for(int i = 0; isalpha(str[i]) > 0; i++){
        for(int j = 0; j < 10; j++){
            if(str[i] == vowel[j]){
                tempx++;
                boolean = 1;
                break;
            }
        }
        if(boolean != 1){
            tempy++;
        }
        boolean = 0;
    }
    *x = tempx;
    *y = tempy;
}
double Area(){
    char fir[MAX];
    char sec[MAX];
    char thd[MAX];
    int x1, y1;
    int x2, y2;
    int x3, y3;

    scanf("%39s", fir);
    scanf("%39s", sec);
    scanf("%39s", thd);
    spot(fir, &x1, &y1);
    spot(sec, &x2, &y2);
    spot(thd, &x3, &y3);

    double a, b, c;
    a = sqrt(pow(x2-x1, 2) + pow(y2-y1, 2));
    b = sqrt(pow(x3 - x2, 2) + pow(y3-y2, 2));
    c = sqrt(pow(x1-x3, 2) + pow(y1- y3, 2));
    double s = (a + b + c)/ 2;

    return sqrt(s*(s-a)*(s-b)*(s-c));



}
