#include <stdio.h>
#include <string.h>
#include <math.h>

double distance(int x1, int y1, int x2, int y2) {
    int dx = x1 - x2;
    int dy = y1 - y2;
    return sqrt(dx * dx + dy * dy);
}

double triangle_area(double a, double b, double c) {
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int main() {
    char w1[41];
    char w2[41];
    char w3[41];
    char vs[11] = "AEIOUaeiou";
    char cs[44] = "BCDFGHJKLMNPQRSTVWXYZbcdfghklmnpqrstvwxyz";

    scanf("%40s %40s %40s", w1, w2, w3);

    size_t len1 = strlen(w1);
    size_t len2 = strlen(w2);
    size_t len3 = strlen(w3);

    int x1 = 0, y1 = 0;
    for (int i = 0; i < len1; ++i) {
        char c = w1[i];

        if (strchr(vs, c) != NULL)
            x1++;
        else if (strchr(cs, c) != NULL)
            y1++;
    }

    int x2 = 0, y2 = 0;
    for (int i = 0; i < len2; ++i) {
        char c = w2[i];
        if (strchr(vs, c) != NULL)
            x2++;
        else if (strchr(cs, c) != NULL)
            y2++;
    }

    int x3 = 0, y3 = 0;
    for (int i = 0; i < len3; ++i) {
        char c = w3[i];
        if (strchr(vs, c) != NULL)
            x3++;
        else if (strchr(cs, c) != NULL)
            y3++;
    }

    double a = distance(x1, y1, x2, y2);
    double b = distance(x2, y2, x3, y3);
    double c = distance(x3, y3, x1, y1);

    double area = triangle_area(a, b, c);
    printf("%.3f\n", area);

    return 0;
}

