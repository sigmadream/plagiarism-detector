#include <stdio.h>
#include <math.h>
#include <string.h>

double calculate_area(double a, double b, double c) {
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int count_vowels(const char *word) {
    int count = 0;
    for (int i = 0; word[i] != '\0'; i++) {
        char c = tolower(word[i]);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            count++;
        }
    }
    return count;
}

int count_consonants(const char *word) {
    int count = 0;
    for (int i = 0; word[i] != '\0'; i++) {
        char c = tolower(word[i]);
        if (c >= 'a' && c <= 'z' && c != 'a' && c != 'e' && c != 'i' && c != 'o' && c != 'u') {
            count++;
        }
    }
    return count;
}

int main() {
    char words[3][41];  // Assuming maximum word length is 40
    int coordinates[3][2];
    double distances[3];

    for (int i = 0; i < 3; i++) {
        scanf("%s", words[i]);
        coordinates[i][0] = count_vowels(words[i]);
        coordinates[i][1] = count_consonants(words[i]);
    }

    for (int i = 0; i < 3; i++) {
        int j = (i + 1) % 3;
        distances[i] = sqrt(pow(coordinates[i][0] - coordinates[j][0], 2) + pow(coordinates[i][1] - coordinates[j][1], 2));
    }

    double a = distances[0];
    double b = distances[1];
    double c = distances[2];

    if (a + b > c && b + c > a && c + a > b) {
        double area = calculate_area(a, b, c);
        printf("%.3lf\n", area);
    } else {
        printf("0.000\n");
    }

    return 0;
}
