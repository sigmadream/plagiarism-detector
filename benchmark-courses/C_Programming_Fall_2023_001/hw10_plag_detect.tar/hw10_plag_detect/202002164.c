#include<stdio.h>
#include<math.h>
#include<string.h>

double heron(double, double, double);
double f(double, double);

int main() {
	char str1[41], str2[41], str3[41];
	double A_x = 0, A_y = 0, B_x = 0, B_y =0, C_x = 0, C_y = 0;
	int i;
	scanf("%s", str1, 40);
	scanf("%s", str2, 40);
	scanf("%s", str3, 40);
	
	
	for (i = 0; i < strlen(str1); i++) {
		char c = str1[i];	
		if (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z')) {
			if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
				A_x++;
			}
			else {
				A_y++;
			}
		}

	}
	
	for (i = 0; i < strlen(str2); i++) {	
		char d = str2[i];
		if (('a' <= d && d <= 'z') || ('A' <= d && d <= 'Z')) {
			if (d == 'a' || d == 'e' || d == 'i' || d == 'o' || d == 'u' || d == 'A' || d == 'E' || d == 'I' || d == 'O' || d == 'U') {
				B_x++;
			}
			else {
				B_y++;
			}
		}
	}

	for (i = 0; i < strlen(str3); i++) {	
		char e = str3[i];
		if (('a' <= e && e <= 'z') || ('A' <= e && e <= 'Z')) {
			if (e == 'a' || e == 'e' || e == 'i' || e == 'o' || e == 'u' || e == 'A' || e == 'E' || e == 'I' || e == 'O' || e == 'U') {
				C_x++;
			}
			else {
				C_y++;
			}
		}
	}

	double a = f(A_x - B_x, A_y - B_y);
	double b = f(B_x - C_x, B_y - C_y);
	double c = f(C_x - A_x, C_y - A_y);
	double d = round(heron(a,b,c) * 1000) / 1000;
	printf("%.3f",d);
}

double f(double a, double b) {
	double A = fabs(a);
	double B = fabs(b);
	double C = A*A + B*B;
	double D = sqrt(C);
	return D;
}

double heron(double a, double b, double c) {
	double s = (a+b+c) / 2;
	return sqrt(s*(s-a)*(s-b)*(s-c));	
}

