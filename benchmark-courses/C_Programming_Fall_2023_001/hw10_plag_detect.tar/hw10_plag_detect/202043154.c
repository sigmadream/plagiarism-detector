#include <stdio.h>
#include <math.h>
#include <string.h>

// 함수 선언
double calculateDistance(int x1, int y1, int x2, int y2);
double calculateArea(double a, double b, double c);

int main() {
    char word1[41], word2[41], word3[41];
    int x1, x2, x3;  // 모음의 수
    int y1, y2, y3;  // 자음의 수

    // 세 개의 단어 입력 받기
    if (scanf("%40s %40s %40s", word1, word2, word3) != 3) {
        printf("Input error: Three words are required.\n");
        return 1;
    }

    // 각 단어에서 모음과 자음의 수 계산
    x1 = y1 = x2 = y2 = x3 = y3 = 0;

    for (int i = 0; i < strlen(word1); i++) {
        if (strchr("AEIOUaeiou", word1[i]) != NULL) {
            x1++;
        } else {
            y1++;
        }
    }

    for (int i = 0; i < strlen(word2); i++) {
        if (strchr("AEIOUaeiou", word2[i]) != NULL) {
            x2++;
        } else {
            y2++;
        }
    }

    for (int i = 0; i < strlen(word3); i++) {
        if (strchr("AEIOUaeiou", word3[i]) != NULL) {
            x3++;
        } else {
            y3++;
        }
    }

    // 삼각형의 세 변의 길이 계산
    double a = calculateDistance(x1, y1, x2, y2);
    double b = calculateDistance(x2, y2, x3, y3);
    double c = calculateDistance(x3, y3, x1, y1);

    // 삼각형 면적 계산
    double area = calculateArea(a, b, c);

    // 결과 출력
    printf("%.3lf\n", area);

    return 0;
}

// 두 점 사이의 거리 계산 함수
double calculateDistance(int x1, int y1, int x2, int y2) {
    return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}

// 삼각형 면적 계산 함수
double calculateArea(double a, double b, double c) {
    double s = (a + b + c) / 2;
    if (a + b > c && a + c > b && b + c > a) {
        return sqrt(s * (s - a) * (s - b) * (s - c));
    } else {
        return 0.000;
    }
}
