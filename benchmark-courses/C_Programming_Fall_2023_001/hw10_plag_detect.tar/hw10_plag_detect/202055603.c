#include <stdio.h>
#include <math.h>
#include <string.h>

int check_vowel(char word[41]){
	char vowel[10] = "aeiouAEIOU";
	int num_vowel = 0;
	for (int i = 0; i < 41; i++){
		if (word[i] == '\0')
			break;
		for (int j = 0; j< 10; j++){
			if (word[i] == vowel[j])
			num_vowel++;
		}
	}
	return num_vowel;
}


int main(){
	char word_1[41], word_2[41], word_3[41];
	scanf("%s%s%s", &word_1, &word_2, &word_3);
	int x1 = check_vowel(word_1), y1 = strlen(word_1) - check_vowel(word_1);
	int x2 = check_vowel(word_2), y2 = strlen(word_2) - check_vowel(word_2);
	int x3 = check_vowel(word_3), y3 = strlen(word_3) - check_vowel(word_3);
	int flag = 1;
	if (x1 == x2 == x3 | y1 == y2 == y3){
		flag = 0;
	}
	//printf("x = %d,%d,%d\n", x1,x2,x3);
	//printf("y = %d,%d,%d\n", y1,y2,y3);
	// distance between xy1 and xy2
	double line1 = sqrt(pow(x2-x1,2) + pow(y2-y1,2));
	// distance between xy1 and xy3
	double line2 = sqrt(pow(x3-x1,2) + pow(y3-y1,2));
	// distance between xy2 and xy3
	double line3 = sqrt(pow(x3-x2,2) + pow(y3-y2,2));
	//printf("%lf, %lf, %lf\n", line1,line2,line3);
	double s = (line1+line2+line3)/2.0;
	double heron_nonroot = s*(s-line1)*(s-line2)*(s-line3), heron;
	//printf("%f , %f", s , heron_nonroot);
	if (heron_nonroot <=0){
		flag == 0;
	}
	heron = sqrt(heron_nonroot);
	//printf("final heron is %lf", heron);
	if (flag == 0)
		printf("%.3f", 0.000);
	else 
		printf("%.3f", heron);
	return 0;
}