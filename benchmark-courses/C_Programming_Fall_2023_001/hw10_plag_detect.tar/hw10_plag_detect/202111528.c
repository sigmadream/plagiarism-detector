#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

// 입력받은 문자를 대문자로 바꾸는 함수
char upper(char *c) {

    for (int i=0; c[i] != '\0'; i++) {
        c[i] = toupper(c[i]);
    }      
    return *c;
}

// 변의 길이를 구하는 함수
double length(int x1, int y1, int x2, int y2) {
    double result = pow(x1-x2,2) + pow(y1-y2,2);
    return sqrt(result);
}

int main()
{
    char word1[41], word2[41], word3[41];

    scanf("%s %s %s", word1, word2, word3);  // 3개의 문자를 입력받음

    *word1=upper(word1);
    *word2=upper(word2);
    *word3=upper(word3);  // 글자 모두 대문자로 변경

    int len1 = strlen(word1);
    int len2 = strlen(word2);
    int len3 = strlen(word3);  // 글자의 길이

    int numOfvowel1=0, numOfvowel2=0, numOfvowel3=0;
    int numOfconson1=0, numOfconson2=0, numOfconson3=0;

    for(int i=0; i<len1; i++) {
        if(word1[i]=='A' || word1[i]=='E' || word1[i]=='I' || word1[i]=='O' || word1[i]=='U')
        numOfvowel1 += 1;
    }

    for(int i=0; i<len2; i++) {
        if(word2[i]=='A' || word2[i]=='E' || word2[i]=='I' || word2[i]=='O' || word2[i]=='U')
        numOfvowel2 += 1;
    }

    for(int i=0; i<len3; i++) {
        if(word3[i]=='A' || word3[i]=='E' || word3[i]=='I' || word3[i]=='O' || word3[i]=='U')
        numOfvowel3 += 1;
    }
    
    numOfconson1 = len1 - numOfvowel1;
    numOfconson2 = len2 - numOfvowel2;
    numOfconson3 = len3 - numOfvowel3;  // 글자의 vowel, consonant 계산

    double a=length(numOfvowel1, numOfconson1, numOfvowel2, numOfconson2);
    double b=length(numOfvowel2, numOfconson2, numOfvowel3, numOfconson3);
    double c=length(numOfvowel3, numOfconson3, numOfvowel1, numOfconson1);

    // 헤론 공식을 이용하여 삼각형의 area(넓이)를 구함
    double s = (a+b+c)/2;
    double area = sqrt(s*(s-a)*(s-b)*(s-c));
    
    printf("%.3lf", area);

    return 0;

}