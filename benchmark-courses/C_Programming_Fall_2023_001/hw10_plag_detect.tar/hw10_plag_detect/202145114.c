#include <stdio.h>
#include <math.h>

double calculate_area(double a, double b, double c) {
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int main() {
    char word1[40], word2[40], word3[40];
    int a1 = 0, b1 = 0, a2 = 0, b2 = 0, a3 = 0, b3 = 0;
    double side1, side2, side3, area;

    scanf("%s %s %s", word1, word2, word3);

    for (int i = 0; word1[i]; i++) {
        if (word1[i] == 'a' || word1[i] == 'e' || word1[i] == 'i' || word1[i] == 'o' || word1[i] == 'u' ||
            word1[i] == 'A' || word1[i] == 'E' || word1[i] == 'I' || word1[i] == 'O' || word1[i] == 'U') {
            a1++;
        } else {
            b1++;
        }
    }

    for (int i = 0; word2[i]; i++) {
        if (word2[i] == 'a' || word2[i] == 'e' || word2[i] == 'i' || word2[i] == 'o' || word2[i] == 'u' ||
            word2[i] == 'A' || word2[i] == 'E' || word2[i] == 'I' || word2[i] == 'O' || word2[i] == 'U') {
            a2++;
        } else {
            b2++;
        }
    }

    for (int i = 0; word3[i]; i++) {
        if (word3[i] == 'a' || word3[i] == 'e' || word3[i] == 'i' || word3[i] == 'o' || word3[i] == 'u' ||
            word3[i] == 'A' || word3[i] == 'E' || word3[i] == 'I' || word3[i] == 'O' || word3[i] == 'U') {
            a3++;
        } else {
            b3++;
        }
    }

    side1 = sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1));
    side2 = sqrt((a3 - a2) * (a3 - a2) + (b3 - b2) * (b3 - b2));
    side3 = sqrt((a1 - a3) * (a1 - a3) + (b1 - b3) * (b1 - b3));

    if (side1 + side2 > side3 && side2 + side3 > side1 && side3 + side1 > side2) {
        area = calculate_area(side1, side2, side3);
        printf("%.3lf\n", area);
    } else {
        printf("0.000\n");
    }

    return 0;
}
