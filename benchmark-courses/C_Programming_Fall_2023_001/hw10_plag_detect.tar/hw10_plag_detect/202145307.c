#include <stdio.h>
#include <math.h>

// Function to calculate the distance between two points
double distance(int x1, int y1, int x2, int y2) {
    return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}

// Function to calculate the area of a triangle using Heron's formula
double calculate_area(double a, double b, double c) {
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int main() {
    char word1[40], word2[40], word3[40];
    int vowels1 = 0, vowels2 = 0, vowels3 = 0;
    int consonants1 = 0, consonants2 = 0, consonants3 = 0;

    // Input three words
    scanf("%s %s %s", word1, word2, word3);

    // Calculate the number of vowels and consonants in each word
    for (int i = 0; word1[i]; i++) {
        if (word1[i] == 'a' || word1[i] == 'e' || word1[i] == 'i' || word1[i] == 'o' || word1[i] == 'u' ||
            word1[i] == 'A' || word1[i] == 'E' || word1[i] == 'I' || word1[i] == 'O' || word1[i] == 'U') {
            vowels1++;
        } else {
            consonants1++;
        }
    }

    for (int i = 0; word2[i]; i++) {
        if (word2[i] == 'a' || word2[i] == 'e' || word2[i] == 'i' || word2[i] == 'o' || word2[i] == 'u' ||
            word2[i] == 'A' || word2[i] == 'E' || word2[i] == 'I' || word2[i] == 'O' || word2[i] == 'U') {
            vowels2++;
        } else {
            consonants2++;
        }
    }

    for (int i = 0; word3[i]; i++) {
        if (word3[i] == 'a' || word3[i] == 'e' || word3[i] == 'i' || word3[i] == 'o' || word3[i] == 'u' ||
            word3[i] == 'A' || word3[i] == 'E' || word3[i] == 'I' || word3[i] == 'O' || word3[i] == 'U') {
            vowels3++;
        } else {
            consonants3++;
        }
    }

    // Calculate the lengths of the three sides
    double side1 = distance(vowels1, consonants1, vowels2, consonants2);
    double side2 = distance(vowels2, consonants2, vowels3, consonants3);
    double side3 = distance(vowels3, consonants3, vowels1, consonants1);

    // Check if the points form a valid triangle
    if (side1 + side2 > side3 && side2 + side3 > side1 && side3 + side1 > side2) {
        double area = calculate_area(side1, side2, side3);
        printf("%.3lf\n", area);
    } else {
        printf("0.000\n");
    }

    return 0;
}
