#include <stdio.h>
#include <string.h>
#include <math.h>

typedef struct {
    int n1;
    int n2;
} two;

two tuple(char arr[]) {
    two result = { 0, 0 };
    for (int i = 0; i < strlen(arr); i++) {
        if (arr[i] == 'A' || arr[i] == 'E' || arr[i] == 'I' || arr[i] == 'O' || arr[i] == 'U' ||
            arr[i] == 'a' || arr[i] == 'e' || arr[i] == 'i' || arr[i] == 'o' || arr[i] == 'u') {
            result.n1++;
        }
        else {
            result.n2++;
        }
    }
    return result;
}

float length(two r1, two r2) {
    float len = sqrt(pow(r1.n1 - r2.n1, 2) + pow(r1.n2 - r2.n2, 2));
    return len;
}

float area(float a, float b, float c) {
    float s = (a + b + c) / 2;
    float Heron = sqrt(s * (s - a) * (s - b) * (s - c));
    return Heron;
}

int main() {
    char arr[130];
    fgets(arr, sizeof(arr), stdin);

    if (arr[strlen(arr) - 1] == '\n') {
        arr[strlen(arr) - 1] = '\0';
    }

    char* word[3];
    word[0] = strtok(arr, " ");
    word[1] = strtok(NULL, " ");
    word[2] = strtok(NULL, " ");

    two result1 = tuple(word[0]);
    two result2 = tuple(word[1]);
    two result3 = tuple(word[2]);

    float len1 = length(result1, result2);
    float len2 = length(result2, result3);
    float len3 = length(result3, result1);

    printf("%.3f\n", area(len1, len2, len3));
    return 0;
}