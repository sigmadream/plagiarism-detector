#include <stdio.h>
#include <math.h>

double calcside(int a, int b, int c, int d);
double calct(double a, double b, double c);

int main(void) {
    char s1[41], s2[41], s3[41];
    int len1 = 0, len2 = 0, len3 = 0;
    int vow1 = 0, con1 = 0, vow2 = 0, con2 = 0, vow3 = 0, con3 = 0;
    double sideA, sideB, sideC;
    double t = 0;

    scanf("%s %s %s", s1, s2, s3);




    while (s1[len1] != '\0') len1++;
    while (s2[len2] != '\0') len2++;
    while (s3[len3] != '\0') len3++;

    for (int i = 0; i < len1; i++) {
        if (s1[i] == 'a' || s1[i] == 'e' || s1[i] == 'o' || s1[i] == 'u' || s1[i] == 'i') {
            vow1++;
        }
        else {
            con1++;
        }

    }
    for (int k = 0; k < len2; k++) {
        if (s2[k] == 'a' || s2[k] == 'e' || s2[k] == 'o' || s2[k] == 'u' || s2[k] == 'i') {
            vow2++;
        }

        else {
            con2++;
        }
    }
    for (int l = 0; l < len3; l++) {
        if (s3[l] == 'a' || s3[l] == 'e' || s3[l] == 'o' || s3[l] == 'u' || s3[l] == 'i') {
            vow3++;
        }

        else {
            con3++;
        }
    }

    sideA = calcside(con1,con2 , vow1, vow2);
    sideB = calcside(con2, con3, vow2, vow3);
    sideC = calcside(con3, con1, vow3, vow1);

    t = calct(sideA, sideB, sideC);

    printf("%.3f", t);

    return 0;
}

double calcside(int a, int b, int c, int d) {

    return sqrt((a - b) * (a - b) + (c - d) * (c - d));
}

double calct(double a, double b, double c) {

    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}