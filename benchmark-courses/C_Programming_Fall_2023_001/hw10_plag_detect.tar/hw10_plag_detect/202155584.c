#include <stdio.h>
#include <string.h>
#include <math.h>

// Function to count vowels in a word
int countVowels(const char *word) {
    int count = 0;
    for (int i = 0; word[i] != '\0'; i++) {
        char c = word[i];
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
            count++;
        }
    }
    return count;
}

// Function to calculate the area of a triangle using Heron's formula
double calculateTriangleArea(int x1, int y1, int x2, int y2, int x3, int y3) {
    double a = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    double b = sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
    double c = sqrt((x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3));
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int main() {
    char words[3][40];
    int x[3], y[3];

    // Read three words from input
    for (int i = 0; i < 3; i++) {
        scanf("%s", words[i]);
        x[i] = countVowels(words[i]);
        y[i] = strlen(words[i]) - x[i];
    }

    // Calculate the area of the triangle
    double area = calculateTriangleArea(x[0], y[0], x[1], y[1], x[2], y[2]);

    // Print the result rounded to three decimal places
    printf("%.3lf\n", area);

    return 0;
}
