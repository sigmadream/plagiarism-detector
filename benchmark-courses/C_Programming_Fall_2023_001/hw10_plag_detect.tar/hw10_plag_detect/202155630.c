/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <math.h>

double distance(int x1, int y1, int x2, int y2) {
    return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

int main() {
    char word1[41], word2[41], word3[41];
    int vowels, consonants;
    int x[3], y[3];
    scanf("%40s %40s %40s", word1, word2, word3);

    char* words[] = {word1, word2, word3};
    for (int w = 0; w < 3; w++) {
        vowels = 0; consonants = 0;
        for (int i = 0; words[w][i] != '\0'; i++) {
            char c = words[w][i];
            if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' ||
                c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                vowels++;
            } else {
                consonants++;
            }
        }
        x[w] = vowels;
        y[w] = consonants;
    }

    double a = distance(x[0], y[0], x[1], y[1]);
    double b = distance(x[1], y[1], x[2], y[2]);
    double c = distance(x[2], y[2], x[0], y[0]);

    double s = (a + b + c) / 2.0;
    double area = sqrt(s * (s - a) * (s - b) * (s - c));

    printf("%.3lf\n", area);
    return 0;
}

