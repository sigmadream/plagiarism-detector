#include <stdio.h>
#include <math.h>
#include <ctype.h>

double fun(double, double, double);
double dist(int, int, int, int);

int main()
{
    int x[3], y[3], i, j = 0;
    double a, b, c;
    double ans;
    char str[123];           // two 40 max length words with space and one with null = 41 * 3;
    scanf("%122[^\n]", str); // max possible string length
    // printf("%s %d\n",str,strlen(str)); // actual string length

    // initialize all the point with x,y 0,0
    for (i = 0; i < 3; i++)
    {
        x[i] = 0;
        y[i] = 0;
    }

    // counting each words vowel and consonent
    for (i = 0; str[i] != '\0'; i++)
    {
        char ch = tolower(str[i]); // Convert the character to lowercase for easier checking

        if (isalpha(ch))
        {
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
            {
                x[j]++;
            }
            else
            {
                y[j]++;
            }
        }
        else
        { // if not char which is space count next word
            j++;
        }
    }

    a = dist(x[0], y[0], x[1], y[1]); // calculate the distance between 1 and 2 is a
    b = dist(x[1], y[1], x[2], y[2]); // calculate the distance between 2 and 3 is b
    c = dist(x[0], y[0], x[2], y[2]); // calculate the distance between 1 and 3 is c

    ans = fun(a, b, c);
    printf("%.3lf", ans);
}
// function for calculating distance between two points
double dist(int x1, int y1, int x2, int y2)
{
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

// function for calculationg heron area of triangle
double fun(double a, double b, double c)
{
    double s;
    s = (a + b + c) / 2;
    return (sqrt(s * (s - a) * (s - b) * (s - c)));
}
