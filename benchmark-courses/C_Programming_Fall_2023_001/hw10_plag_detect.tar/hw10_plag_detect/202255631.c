#include <stdio.h>
#include <math.h>
#include <string.h>

double distance(int x1, int y1, int x2, int y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

double calculateArea(double a, double b, double c) {
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int main() {
    char word1[41], word2[41], word3[41];
    scanf("%40s %40s %40s", word1, word2, word3);

    int x1 = 0, y1 = 0, x2 = 0, y2 = 0, x3 = 0, y3 = 0;
    for (int i = 0; i < strlen(word1); ++i) {
        if (word1[i] == 'a' || word1[i] == 'e' || word1[i] == 'i' || word1[i] == 'o' || word1[i] == 'u')
            x1++;
        else
            y1++;
    }
    for (int i = 0; i < strlen(word2); ++i) {
        if (word2[i] == 'a' || word2[i] == 'e' || word2[i] == 'i' || word2[i] == 'o' || word2[i] == 'u')
            x2++;
        else
            y2++;
    }
    for (int i = 0; i < strlen(word3); ++i) {
        if (word3[i] == 'a' || word3[i] == 'e' || word3[i] == 'i' || word3[i] == 'o' || word3[i] == 'u')
            x3++;
        else
            y3++;
    }

    double a = distance(x1, y1, x2, y2);
    double b = distance(x2, y2, x3, y3);
    double c = distance(x3, y3, x1, y1);


    if (a + b > c && b + c > a && c + a > b) {
        double area = calculateArea(a, b, c);
        printf("%.3lf\n", area);
    } else {
        printf("0.000\n");
    }

    return 0;
}
