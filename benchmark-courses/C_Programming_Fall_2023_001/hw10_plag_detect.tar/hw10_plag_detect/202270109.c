#include <stdio.h>
#include <math.h>
#include <string.h>

double distance(int x1, int y1, int x2, int y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

int countVowels(char str[]) {
    int vowels = 0;
    for (int i = 0; str[i]; i++) {
        char c = str[i];
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
                c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
                vowels++;
            }
        }
    }
    return vowels;
}

double triangleArea(double distance1, double distance2, double distance3) {
    double s = (distance1 + distance2 + distance3) / 2;
    return sqrt(s * (s - distance1) * (s - distance2) * (s - distance3));
}

int main() {
    int x1, y1, x2, y2, x3, y3;
    char first[40], second[40], third[40];

    scanf("%s", first);
    scanf("%s", second);
    scanf("%s", third);

    x1 = countVowels(first);
    y1 = strlen(first) - x1;

    x2 = countVowels(second);
    y2 = strlen(second) - x2;

    x3 = countVowels(third);
    y3 = strlen(third) - x3;

    double distance1 = distance(x1, y1, x2, y2);
    double distance2 = distance(x2, y2, x3, y3);
    double distance3 = distance(x3, y3, x1, y1);

    printf("%0.3lf", triangleArea(distance1, distance2, distance3));

    return 0;
}
