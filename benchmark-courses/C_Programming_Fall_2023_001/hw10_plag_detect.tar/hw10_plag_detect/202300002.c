#include <stdio.h>
#include <math.h>
#include <string.h>

int count_vwls(char[]);
int count_cons(char[]);
double dist(int, int, int, int);
double area(double, double, double);

int main()
{
    char word[41];
    int x1, x2, x3, y1, y2, y3;

    scanf("%40s", word);
    x1 = count_vwls(word);
    y1 = count_cons(word);
    scanf("%40s", word);
    x2 = count_vwls(word);
    y2 = count_cons(word);
    scanf("%40s", word);
    x3 = count_vwls(word);
    y3 = count_cons(word);
    double d1 = dist(x1, y1, x2, y2);
    double d2 = dist(x2, y2, x3, y3);
    double d3 = dist(x3, y3, x1, y1);
    printf("%.3f\n", area(d1, d2, d3));

    return 0;
}

int count_vwls(char p[]) {
    int cnt = 0;
    for (; *p; p++) {
        if (strchr("AEIOUaeiou", *p))
            cnt++;
    }
    return cnt;
}

int count_cons(char p[]) {
    return strlen(p) - count_vwls(p);
}

double dist(int x1, int y1, int x2, int y2) {
    double sqsum = (x1 - x2) * (x1 - x2);
    sqsum += (y1 - y2) * (y1 - y2);
    return sqrt(sqsum);
}

double area(double a, double b, double c) {
    double s = (a + b + c) / 2.0;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

