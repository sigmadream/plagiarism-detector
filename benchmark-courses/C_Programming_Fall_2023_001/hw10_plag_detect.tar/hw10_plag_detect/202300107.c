#include <stdio.h>
#include <math.h>
#include <string.h>

int length_of_vowel(char msg[])
{
    int vowel = 0;
    while (*msg!= '\0'){
        if (*msg == 'a' || *msg == 'e' || *msg == 'i' 
        || *msg == 'o' || *msg == 'u' || *msg == 'A'
        ||  *msg == 'E' || *msg == 'I' || *msg == 'O' || *msg == 'U'){
            vowel += 1;   
        }
        msg++;
    }
    return vowel;
}

int main()
{
    char w1[50], w2[50], w3[50];
    int w1_vow, w2_vow, w3_vow, w1_cons, w2_cons, w3_cons;
    double l1, l2, l3;
    float s, area;
    scanf("%s%s%s", w1, w2, w3);
    w1_vow = length_of_vowel(w1);
    w2_vow = length_of_vowel(w2);
    w3_vow = length_of_vowel(w3);
    w1_cons = strlen(w1) - w1_vow;
    w2_cons = strlen(w2) - w2_vow;
    w3_cons = strlen(w3) - w3_vow;
    l1 = sqrt(pow(w1_vow - w2_vow, 2)+pow(w1_cons - w2_cons, 2));
    
    
    l2 = sqrt(pow(w2_vow - w3_vow, 2)+pow(w2_cons - w3_cons, 2));
    l3 = sqrt(pow(w1_vow - w3_vow, 2)+pow(w1_cons - w3_cons, 2));
    s = (l1+l2+l3)/2;
    
    area = sqrt(s*(s-l1)*(s-l2)*(s-l3));
   

    printf("%.3f", area);
    

    return 0;

}