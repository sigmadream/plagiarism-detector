#include <stdio.h>
#include <math.h>
#include <string.h>

double distance(int x1, int y1, int x2, int y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

int main() {
    char word1[40], word2[40], word3[40];

    scanf("%s %s %s", word1, word2, word3);

    int x1 = 0, y1 = 0;
    int x2 = 0, y2 = 0;
    int x3 = 0, y3 = 0;

    for (int i = 0; word1[i]; i++) {
        if (strchr("AEIOUaeiou", word1[i])) {
            x1++;
        } else if ((word1[i] >= 'A' && word1[i] <= 'Z') || (word1[i] >= 'a' && word1[i] <= 'z')) {
            y1++;
        }
    }

    for (int i = 0; word2[i]; i++) {
        if (strchr("AEIOUaeiou", word2[i])) {
            x2++;
        } else if ((word2[i] >= 'A' && word2[i] <= 'Z') || (word2[i] >= 'a' && word2[i] <= 'z')) {
            y2++;
        }
    }

    for (int i = 0; word3[i]; i++) {
        if (strchr("AEIOUaeiou", word3[i])) {
            x3++;
        } else if ((word3[i] >= 'A' && word3[i] <= 'Z') || (word3[i] >= 'a' && word3[i] <= 'z')) {
            y3++;
        }
    }

    double a = distance(x1, y1, x2, y2);
    double b = distance(x2, y2, x3, y3);
    double c = distance(x3, y3, x1, y1);

    double s = (a + b + c) / 2;

    double area = sqrt(s * (s - a) * (s - b) * (s - c));

    if (a + b <= c || a + c <= b || b + c <= a) {
        area = 0.0;
    }

    printf("%.3lf\n", area);

    return 0;
}
