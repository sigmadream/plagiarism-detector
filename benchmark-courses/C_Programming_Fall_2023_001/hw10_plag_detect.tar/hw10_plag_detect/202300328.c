#include <stdio.h>
#include <math.h>
#include <string.h>

double calculateArea(double side1, double side2, double side3) {
    double s = (side1 + side2 + side3) / 2.0;
    return sqrt(s * (s - side1) * (s - side2) * (s - side3));
}

int main()
{
char word[120];

char word1[40] ;char word2[40] ;char word3[40] ;

scanf("%s %s %s", word1, word2, word3);

size_t len = strlen(word1);
size_t len2 = strlen(word2);
size_t len3 = strlen(word3);

int x1 = 0; int y1 = 0;
int x2 = 0; int y2 = 0;
int x3 = 0; int y3 = 0;

for (int i = 0 ; i < len ; ++i ){
  char c = word1[i];
  if( c=='a' || c=='e' || c=='i' || c=='o' || c=='u' || c=='y' || c=='A' || c=='E' || c=='I' || c=='O' || c=='U' || c=='Y')
    x1++;
  else
    y1++;
}
for (int i = 0 ; i < len2 ; ++i ){
  char c1 = word2[i];
  if( c1=='a' || c1=='e' || c1=='i' || c1=='o' || c1=='u' || c1=='y' || c1=='A' || c1=='E' || c1=='I' || c1=='O' || c1=='U' || c1=='Y')
    x2++;
  else
    y2++;
}
for (int i = 0 ; i < len3 ; ++i ){
  char c2 = word3[i];
  if( c2=='a' || c2=='e' || c2=='i' || c2=='o' || c2=='u' || c2=='y' || c2=='A' || c2=='E' || c2=='I' || c2=='O' || c2=='U' || c2=='Y')
    x3++;
  else
    y3++;
}
double side1 = sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));
double side2 = sqrt(pow(x2 - x3, 2) + pow(y2 - y3, 2));
double side3 = sqrt(pow(x3 - x1, 2) + pow(y3 - y1, 2));

if (side1 + side2 > side3 && side2 + side3 > side1 && side3 + side1 > side2) {
        double area = calculateArea(side1, side2, side3);
        printf("%.3lf\n", area);
    } else {
        printf("0.000\n");
    }


return 0; }
