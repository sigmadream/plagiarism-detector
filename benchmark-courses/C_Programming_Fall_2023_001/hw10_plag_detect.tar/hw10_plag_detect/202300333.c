#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>


double calculateDistance(int x1, int x2, int y1, int y2){
    return sqrt(pow(x2-x1,2)+pow(y2-y1,2));
}

double areaTriangle(float a, float b, float c){
    float s = (a+b+c)/2;
    return sqrt(s*(s-a)*(s-b)*(s-c));
}


int main() {

    int v1 = 0, c1 = 0, v2 = 0, c2 = 0, v3 = 0, c3 = 0;
    int i = 0;
    char line[40];

    fgets(line, sizeof(line), stdin);
    line[strcspn(line, "\n")] = '\0';

    char ch1[40];
    char ch2[40];
    char ch3[40];

    int splitIndex1 = strcspn(line, " ");
    int splitIndex2 = strcspn(line + splitIndex1 + 1, " ");
    //First word separate
    strncpy(ch1, line, splitIndex1);
    ch1[splitIndex1] = '\0';
    //Second word separate
    strncpy(ch2, line + splitIndex1 + 1, splitIndex2);
    ch2[splitIndex2] = '\0';
    //Third word separate
    strcpy(ch3, line + splitIndex1 + splitIndex2 + 2);

    /*
    printf("|%s|\n",ch1);
    printf("|%s|\n",ch2);
    printf("|%s|\n",ch3);
    */

    int lenCh1 = strlen(ch1);
    int lenCh2 = strlen(ch2);
    int lenCh3 = strlen(ch3);

    for (i = 0; i < lenCh1; i++){
        char c = ch1[i];
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'y' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'Y'){
            v1 += 1;
        }
        else if (c > 'a' && c < 'z' || c > 'A' && c < 'Z'){
            c1 += 1;
        }
    }
    //printf("Le couple (x,y) est (%d,%d)\n", v1, c1);

    for (i = 0; i < lenCh2; i++){
        char c = ch2[i];
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'y' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'Y'){
            v2 += 1;
        }
        else if (c > 'a' && c < 'z' || c > 'A' && c < 'Z'){
            c2 += 1;
        }
    }
    //printf("Le couple (x,y) est (%d,%d)\n", v2, c2);

    for (i = 0; i < lenCh3; i++){
        char c = ch3[i];
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'y' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'Y'){
            v3 += 1;
        }
        else if (c > 'a' && c < 'z' || c > 'A' && c < 'Z'){
            c3 += 1;
        }
    }
    //printf("Le couple (x,y) est (%d,%d)\n", v3, c3);
    double d1 = calculateDistance(v1,v2,c1,c2);
    double d2 = calculateDistance(v2,v3,c2,c3);
    double d3 = calculateDistance(v3,v1,c3,c1);
    /*
    printf("Premiere distance = %.3f \n",d1);
    printf("Deuxieme distance = %.3f \n",d2);
    printf("Troisieme distance = %.3f \n",d3);
    */
    double area = areaTriangle(d1,d2,d3);
    printf("%.3f\n",area);

    return 0;
}
