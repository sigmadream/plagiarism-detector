#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {

    const int MAX_LEN = 123;
    char line[MAX_LEN];
    int i=0, x1=0, y1=0, x2=0, y2=0, x3 = 0, y3=0;
    double dist12 = 0, dist13 = 0, dist23 = 0, s = 0, area = 0;

    if (fgets(line, MAX_LEN, stdin) == NULL)
    return -1;

    char *word = strtok(line, " \n");

    if (word != NULL) {

        int len = strlen(word);

        for(i=0; i<len; i++){
            char c = word[i];
            if (c == 'a' || c == 'A' || c == 'e' || c == 'E' || c == 'i' || c == 'I' || c == 'o' || c == 'O' || c == 'u' || c == 'U' || c == 'y' || c == 'Y'){
            x1++;}
            else if(c >='a' && c <='z' || c>='A' && c<='Z'){
                y1++;}

        }



        word = strtok(NULL, " \n");

        if (word != NULL) {

            int len = strlen(word);

        for(i=0; i<len; i++){
            char c = word[i];
            if (c == 'a' || c == 'A' || c == 'e' || c == 'E' || c == 'i' || c == 'I' || c == 'o' || c == 'O' || c == 'u' || c == 'U' || c == 'y' || c == 'Y'){
            x2++;}
            else if(c >='a' && c <='z' || c>='A' && c<='Z'){
                y2++;}

        }

            word = strtok(NULL, " \n");

            if (word != NULL) {

                int len = strlen(word);

            for(i=0; i<len; i++){
                char c = word[i];
                if (c == 'a' || c == 'A' || c == 'e' || c == 'E' || c == 'i' || c == 'I' || c == 'o' || c == 'O' || c == 'u' || c == 'U' || c == 'y' || c == 'Y'){
                x3++;}
                else if(c >='a' && c <='z' || c>='A' && c<='Z'){
                    y3++;}

            }

            } else {
                printf("0.000");
            }
        } else {
            printf("0.000");
        }
    } else {
        printf("0.000");
    }

    dist12 = sqrt(pow((x2-x1),2)+pow((y2-y1),2));
    dist23 = sqrt(pow((x3-x2),2)+pow((y3-y2),2));
    dist13 = sqrt(pow((x3-x1),2)+pow((y3-y1),2));

    s = (dist12 + dist23 + dist13)/2 ;

    area = sqrt(s*(s-dist12)*(s-dist23)*(s-dist13));

    printf("%.3f", area);

return 0;
}
