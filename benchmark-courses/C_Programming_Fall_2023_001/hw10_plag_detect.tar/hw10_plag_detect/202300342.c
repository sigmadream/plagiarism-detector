#include <stdio.h>
#include <string.h>
#include <math.h>

//we calculate the area of a triangle (herons formula)
double area_calc(double a, double b, double c) {
    double s = (a + b + c) / 2;
    double area = sqrt(s * (s - a) * (s - b) * (s - c));
    return area;
}

//we calculate the coordinates x, y for a word
void coord_calc(const char *word, int *x, int *y) {
    *x = 0;
    *y = 0;
    for (int i = 0; word[i] != '\0'; i++) {
        if (word[i] == 'A' || word[i] == 'E' || word[i] == 'I' || word[i] == 'O' || word[i] == 'U' ||
            word[i] == 'a' || word[i] == 'e' || word[i] == 'i' || word[i] == 'o' || word[i] == 'u') {
            (*x)++;
        } else if ((word[i] >= 'A' && word[i] <= 'Z') || (word[i] >= 'a' && word[i] <= 'z')) {
            (*y)++;
        }
    }
}

int main() {
    char words[3][40];
    int coordinates[3][2];
    scanf("%s %s %s", words[0], words[1], words[2]);

    //coordinates for each word
    for (int i = 0; i < 3; i++) {
        coord_calc(words[i], &coordinates[i][0], &coordinates[i][1]);
    }

    //lengths of the 3 sides of triangle
    double side[3];
    for (int i = 0; i < 3; i++) {
        int j = (i + 1) % 3;
        side[i] = sqrt(pow(coordinates[i][0] - coordinates[j][0], 2) + pow(coordinates[i][1] - coordinates[j][1], 2));
    }

    //we check if the points form a triangle
    if (side[0] + side[1] > side[2] &&
        side[1] + side[2] > side[0] &&
        side[2] + side[0] > side[1]) {
        double area = area_calc(side[0], side[1], side[2]);
        printf("%.3lf\n", area); // standard output rounded to 3 decimal places after the decimal point
    } else {
        printf("0.000\n");
    }

    return 0;
}
