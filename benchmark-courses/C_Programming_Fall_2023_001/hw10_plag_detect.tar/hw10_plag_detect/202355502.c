#include <stdio.h>
#include <math.h>
#include <string.h>

double TriangleArea(double a, double b, double c) {
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int main() {
    char word1[41], word2[41], word3[41];
    scanf("%s %s %s", word1, word2, word3);
    double x1 = 0, y1 = 0, x2 = 0, y2 = 0, x3 = 0, y3 = 0;
    
    for (int i = 0; i < strlen(word1); i++) {
        if (strchr("aeiouAEIOU", word1[i])) {
            x1++;
        } else {
            y1++;
        }
    }
    
    for (int i = 0; i < strlen(word2); i++) {
        if (strchr("aeiouAEIOU", word2[i])) {
            x2++;
        } else {
            y2++;
        }
    }
    
    for (int i = 0; i < strlen(word3); i++) {
        if (strchr("aeiouAEIOU", word3[i])) {
            x3++;
        } else {
            y3++;
        }
    }

    double side1 = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    double side2 = sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
    double side3 = sqrt((x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3));
    double area = TriangleArea(side1, side2, side3);
    
    printf("%.3lf\n", area);

    return 0;
}
