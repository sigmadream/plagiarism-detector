//
//  main.c
//  HW5
//
//  Created by Sandoval Reyes Luis Armando on 2023/10/12.
//

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int coordinates(int x, int y, char *word);

int main(int argc, const char * argv[]) {
    char input[120];
    char words[3][40]; int index = 0;
    char *pointer1 = words[0];
    char *pointer2 = words[1];
    char *pointer3 = words[2];
    
    int x1=0; int y1=0;
    int x2=0; int y2=0;
    int x3=0; int y3=0;
    
    
    
    fgets(input, 120, stdin);
    
    char *token = strtok(input, " ");
    
    while(token != NULL){
        strcpy(words[index], token);
        index++;
        token = strtok(NULL, " ");
    }
    index = 0;
    
    while((*pointer1>=65 && *pointer1<=90)||((*pointer1>=97 && *pointer1<=122))){
        if ((toupper(*pointer1) == 'A')||(toupper(*pointer1) == 'E')||(toupper(*pointer1) == 'I')||(toupper(*pointer1) == 'O')||(toupper(*pointer1) == 'U'))
        {
            x1++;
        }
        else{
            y1++;
        }
        pointer1++;
    }
    
    while((*pointer2>=65 && *pointer2<=90)||((*pointer2>=97 && *pointer2<=122))){
        if ((toupper(*pointer2) == 'A')||(toupper(*pointer2) == 'E')||(toupper(*pointer2) == 'I')||(toupper(*pointer2) == 'O')||(toupper(*pointer2) == 'U'))
        {
            x2++;
        }
        else{
            y2++;
        }
        pointer2++;
    }
    
    while((*pointer3>=65 && *pointer3<=90)||((*pointer3>=97 && *pointer3<=122))){
        if ((toupper(*pointer3) == 'A')||(toupper(*pointer3) == 'E')||(toupper(*pointer3) == 'I')||(toupper(*pointer3) == 'O')||(toupper(*pointer3) == 'U'))
        {
            x3++;
        }
        else{
            y3++;
        }
        pointer3++;
    }
    
    float a= sqrt(pow((x2-x1),2)+pow((y2-y1),2));
    float b= sqrt(pow((x2-x3),2)+pow((y2-y3),2));
    float c= sqrt(pow((x3-x1),2)+pow((y3-y1),2));
    
    float s = (a+b+c)/2;
    float area = sqrtf(s*(s-a)*(s-c)*(s-b));
    
    printf("%.3f", area);
    
    
    return 0;
}

