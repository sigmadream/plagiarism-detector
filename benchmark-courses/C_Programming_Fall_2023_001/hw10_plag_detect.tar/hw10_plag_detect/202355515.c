#include <stdio.h>
#include <math.h>

double calculate_area(double a, double b, double c) {
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int count_vowels_and_consonants(const char* word, int* vowels, int* consonants) {
    *vowels = 0;
    *consonants = 0;

    for (int i = 0; i < 40 && word[i] != '\0'; ++i) {
        if (strchr("AEIOUaeiou", word[i]) != NULL)
            (*vowels)++;
        else
            (*consonants)++;
    }
}

int main() {
    char word1[41], word2[41], word3[41];
    scanf("%40s %40s %40s", word1, word2, word3);

    int x1 = 0, x2 = 0, x3 = 0, y1 = 0, y2 = 0, y3 = 0;

    count_vowels_and_consonants(word1, &x1, &y1);
    count_vowels_and_consonants(word2, &x2, &y2);
    count_vowels_and_consonants(word3, &x3, &y3);

    double a = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    double b = sqrt((x2 - x3) * (x2 - x3) + (y2 - y3) * (y2 - y3));
    double c = sqrt((x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3));

    if (a + b > c && b + c > a && c + a > b) {
        double area = calculate_area(a, b, c);
        printf("%.3lf", area);
    } else {
        printf("0.000");
    }

    return 0;
}
