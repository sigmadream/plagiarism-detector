#include <stdio.h>
#include <string.h>
#include <math.h>

double calculateTriangleArea(double a, double b, double c);

int main() {
    char word1[40]; 
    char word2[40]; 
    char word3[40];
    scanf("%s %s %s", word1, word2, word3);

    int len1 = strlen(word1);
    int len2 = strlen(word2);
    int len3 = strlen(word3);
    int x1 = 0, y1 = 0, x2 = 0, y2 = 0, x3 = 0, y3 = 0;
    char vowels[] = "aeiouAEIOU";

    for (int i = 0; i < len1; ++i) {
        if (strchr(vowels, word1[i]) != NULL)
            x1++;
        else
            y1++;
    }
    for (int j = 0; j < len2; ++j) {
        if (strchr(vowels, word2[j]) != NULL)
            x2++;
        else
            y2++;
    }
    for (int k = 0; k < len3; ++k) {
        if (strchr(vowels, word3[k]) != NULL)
            x3++;
        else
            y3++;
    }

    double a = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
    double b = sqrt(pow(x3 - x2, 2) + pow(y3 - y2, 2));
    double c = sqrt(pow(x1 - x3, 2) + pow(y1 - y3, 2));

    double area = calculateTriangleArea(a, b, c);

    printf("%.3f", area);
    return 0;
}

double calculateTriangleArea(double a, double b, double c) {
    double s = (a + b + c) / 2;
    double area = sqrt(s * (s - a) * (s - b) * (s - c));
    return area;
}
