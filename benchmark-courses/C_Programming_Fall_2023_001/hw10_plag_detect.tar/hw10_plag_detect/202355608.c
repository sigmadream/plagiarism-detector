#include <stdio.h>
#include <math.h>

double calculateArea(double a, double b, double c) {
    double s = (a + b + c) / 2;
    double i;
    double j;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int main() {
    char word1[41], word2[41], word3[41];

    scanf("%s %s %s", word1, word2, word3);

    int x1 = 0, x2 = 0, x3 = 0;
    int y1 = 0, y2 = 0, y3 = 0;

    for (int i = 0; word1[i]; i++) {
        if (word1[i] == 'a' || word1[i] == 'e' || word1[i] == 'i' || word1[i] == 'o' || word1[i] == 'u') {
            x1++;
        } else {
            y1++;
        }
    }

    for (int i = 0; word2[i]; i++) {
        if (word2[i] == 'a' || word2[i] == 'e' || word2[i] == 'i' || word2[i] == 'o' || word2[i] == 'u') {
            x2++;
        } else {
            y2++;
        }
    }

    for (int i = 0; word3[i]; i++) {
        if (word3[i] == 'a' || word3[i] == 'e' || word3[i] == 'i' || word3[i] == 'o' || word3[i] == 'u') {
            x3++;
        } else {
            y3++;
        }
    }

    double side1 = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    double side2 = sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
    double side3 = sqrt((x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3));

    double area = calculateArea(side1, side2, side3);
    printf("%.3lf\n", area);

    return 0;
}
