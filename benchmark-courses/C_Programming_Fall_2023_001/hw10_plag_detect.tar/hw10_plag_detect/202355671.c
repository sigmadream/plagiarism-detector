#include <stdio.h>
#include <math.h>
double heron(double a, double b, double c){
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}
int main(){
    double x[4], y[4];
    int j = 1;
    char c[150];
    fgets(c, 150, stdin);
    for(int i = 1; i < 4; i++){
        x[i] = 0, y[i] = 0;
    }
    for(int i = 0; i < 150; i++){
        if (c[i] == ' '){
            j++;
            continue;
        }
        if (c[i] >= 'A' && c[i] <= 'Z'){
            c[i] = c[i] - 'A' + 'a';
        }

        if (c[i] <'a' || c[i] > 'z'){
            break;
        }
        if (c[i]=='a' || c[i]=='e' || c[i]=='i'  || c[i]=='o'  || c[i]=='u'){
            x[j]++;
        }
        else{
            y[j]++;
        }
    }
    double s1 = sqrt(pow(x[1]-x[2], 2) + pow(y[1]-y[2], 2)), s2 = sqrt(pow(x[1]-x[3], 2) + pow(y[1]-y[3], 2)), s3 = sqrt(pow(x[3]-x[2], 2) + pow(y[3]-y[2], 2));
    printf("%0.3lf\n", heron(s1, s2, s3));
    return 0;
}
