#include <stdio.h>
#include <string.h>
#include <math.h>

double side_length(int x_1, int y_1, int x_2, int y_2);

int main()
{
    char str_1[41], str_2[41], str_3[41];
    double a, b, c;
    double area, s;

    scanf("%s %s %s", str_1, str_2, str_3);

    size_t len_1 = strlen(str_1);
    size_t len_2 = strlen(str_2);
    size_t len_3 = strlen(str_3);

    int x_1 = 0, y_1 = 0;
    for ( int i = 0; i < len_1; i++)
    {
        char c = str_1[i];
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
            x_1++;
        else
            y_1++;
    }

    int x_2 = 0, y_2 = 0;
    for ( int i = 0; i < len_2; i++)
    {
        char c = str_2[i];
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
            x_2++;
        else
            y_2++;
    }

    int x_3 = 0, y_3 = 0;
    for ( int i = 0; i < len_3; i++)
    {
        char c = str_3[i];
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
            x_3++;
        else
            y_3++;
    }

    a = side_length(x_2, y_2, x_3, y_3);
    b = side_length(x_1, y_1, x_3, y_3);
    c = side_length(x_1, y_1, x_2, y_2);

    s = (a + b + c)/2;

    area = sqrt(s * (s -a) * (s-b) * (s-c));

    printf("%.3f", area);

    return 0;
}

double side_length(int x_1, int y_1, int x_2, int y_2)
{
    double length = sqrt((y_2 - y_1) * (y_2 - y_1) + (x_2 - x_1) * (x_2 - x_1));

    return length;
}
