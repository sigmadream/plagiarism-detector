#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
    char word1[40],word2[40],word3[40];
    scanf("%s%s%s",word1,word2,word3);
    size_t len1=strlen(word1);
    size_t len2=strlen(word2);
    size_t len3=strlen(word3);
    int x1=0,x2=0,x3=0,y2=0,y3=0,y1=0;

    for (int i = 0; i < len1; ++i) {
        char a = word1[i];
        if (a == 'A' || a == 'E' || a == 'I' || a == 'O' || a == 'U' ||
            a == 'a' || a == 'e' || a == 'i' || a == 'o' || a == 'u') {
            x1++;}
        else{
        y1++;
    }}
     for (int j = 0; j < len2; ++j) {
        char b = word2[j];
        if (b == 'A' || b == 'E' || b == 'I' || b == 'O' || b == 'U' ||
            b == 'a' || b == 'e' || b == 'i' || b == 'o' || b == 'u') {
            x2++;}
        else{
        y2++;
    }}
     for (int k = 0; k < len3; ++k) {
        char c = word3[k];
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' ||
            c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            x3++;}
        else{
        y3++;
    }}
    double length1=pow((pow((x1-x2),2)+pow((y1-y2),2)),0.5);
    double length2=pow((pow((x1-x3),2)+pow((y1-y3),2)),0.5);
    double length3=pow((pow((x3-x2),2)+pow((y3-y2),2)),0.5);
    double s=(length1+length2+length3)/2;

    double area=pow((s*(s-length1)*(s-length2)*(s-length3)),0.5);
    
  
    printf("%.3lf\n",area);
    return 0;
}
