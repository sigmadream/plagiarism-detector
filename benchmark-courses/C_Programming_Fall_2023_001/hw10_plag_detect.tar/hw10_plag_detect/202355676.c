#include <stdio.h>
#include <string.h>
#include <math.h>

int main()
{
    char str1[41], str2[41], str3[41];

    scanf("%s %s %s", &str1, &str2, &str3);

    int v1 = 0, c1 = 0, v2 = 0, c2 = 0, v3 = 0, c3 = 0;

    for(int i = 0; i < strlen(str1); i++){
        if('a' <= str1[i] && str1[i] <= 'z' || 'A' <= str1[i] && str1[i] <= 'Z'){
            if(str1[i] == 'a' || str1[i] == 'e' || str1[i] == 'u' || str1[i] == 'i' || str1[i] == 'o' || str1[i] == 'I' || str1[i] == 'A' || str1[i] == 'E' || str1[i] == 'U' || str1[i] == 'O'){
                v1++;
            }
            else{
                c1++;
            }
        }
    }
    for(int i = 0; i < strlen(str2); i++){
        if('a' <= str2[i] && str2[i] <= 'z' || 'A' <= str2[i] && str2[i] <= 'Z'){
            if(str2[i] == 'a' || str2[i] == 'e' || str2[i] == 'u' || str2[i] == 'i' || str2[i] == 'o'|| str2[i] == 'I' || str2[i] == 'A' || str2[i] == 'E' || str2[i] == 'U' || str2[i] == 'O'){
                v2++;
            }
            else{
                c2++;
            }
        }
    }
    for(int i = 0; i < strlen(str3); i++){
        if('a' <= str3[i] && str3[i] <= 'z' || 'A' <= str3[i] && str3[i] <= 'Z'){
            if(str3[i] == 'a' || str3[i] == 'e' || str3[i] == 'u' || str3[i] == 'i' || str3[i] == 'o'|| str3[i] == 'I' || str3[i] == 'A' || str3[i] == 'E' || str3[i] == 'U' || str3[i] == 'O'){
                v3++;
            }
            else{
                c3++;
            }
        }
    }
    double lena = 0, lenb = 0, lenc = 0;
    lena = sqrt(pow(v1-v2, 2) + pow(c1-c2, 2));
    lenb = sqrt(pow(v2-v3, 2) + pow(c2-c3, 2));
    lenc = sqrt(pow(v1-v3, 2) + pow(c1-c3, 2));
    

    double area = 0;

    if(lena > 0 && lenb > 0 && lenc > 0){
        double p = (lena + lenb + lenc)/2;

        area = sqrt(p * (p - lena) * (p - lenb) * (p - lenc));
        
    }
    else{
        area = 0;
    }

    printf("%.3f", area);
    
    return 0;
}
