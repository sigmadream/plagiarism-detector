#include <stdio.h>
#include <math.h>

double calculating_area(double a, double b, double c)
{
    double area = 0;
    double s = (a+b+c)/2;
    area = sqrt(s*(s-a)*(s-b)*(s-c));
    return area;
}

int main()
{
    const int MAX_LEN = 40;
    char word1[MAX_LEN];
    char word2[MAX_LEN];
    char word3[MAX_LEN];

    fscanf(stdin,"%s %s %s", word1, word2, word3);

    int x1 = 0;
    int y1 = 0;
    int i;
    for (i = 0; i < strlen(word1); i++)
    {
        char c = word1[i];
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
            x1++;
        else
            y1++;
    }

    int x2 = 0;
    int y2 = 0;
    for (i = 0; i < strlen(word2); i++)
    {
        char c = word2[i];
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
            x2++;
        else
            y2++;
    }

    int x3 = 0;
    int y3 = 0;
    for (i = 0; i < strlen(word3); i++)
    {
        char c = word3[i];
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
            x3++;
        else
            y3++;
    }

    double len1 = sqrt(pow((fabs(x2-x1)),2)+pow((fabs(y2-y1)),2));
    double len2 = sqrt(pow((fabs(x3-x2)),2)+pow((fabs(y3-y2)),2));
    double len3 = sqrt(pow((fabs(x3-x1)),2)+pow((fabs(y3-y1)),2));

    double areaof_triangle = calculating_area(len1,len2,len3);

    fprintf(stdout,"%.3lf\n", areaof_triangle);

    return 0;
}
