#include <stdio.h>
#include <math.h>
#include <string.h>

// Function to calculate the area of a triangle
double calculateArea(double a, double b, double c) {
    double s = (a + b + c) / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

int main() {
    char word1[40], word2[40], word3[40];

    scanf("%s %s %s", word1, word2, word3);

    // Count the number of vowels and consonants in each word
    int x1 = 0, y1 = 0, x2 = 0, y2 = 0, x3 = 0, y3 = 0;

    for (int i = 0; word1[i] != '\0'; i++) {
        if (strchr("AEIOUaeiou", word1[i])) {
            x1++;
        } else {
            y1++;
        }
    }

    for (int i = 0; word2[i] != '\0'; i++) {
        if (strchr("AEIOUaeiou", word2[i])) {
            x2++;
        } else {
            y2++;
        }
    }

    for (int i = 0; word3[i] != '\0'; i++) {
        if (strchr("AEIOUaeiou", word3[i])) {
            x3++;
        } else {
            y3++;
        }
    }

    double a = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    double b = sqrt((x2 - x3) * (x2 - x3) + (y2 - y3) * (y2 - y3));
    double c = sqrt((x3 - x1) * (x3 - x1) + (y3 - y1) * (y3 - y1));


    {
        // Calculate and print the area
        double area = calculateArea(a, b, c);
        printf("%.3lf\n", area);
    }
    return 0;
}
