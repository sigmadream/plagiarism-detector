#include <stdio.h>
#include <string.h>
#include <math.h>


int main()
{
    char str1[41];
    char str2[41];
    scanf("%s", str1);
    scanf("%s", str2);
    size_t len1 = strlen(str1);
    size_t len2 = strlen(str2);
    int x1 = 0, y1 = 0, x2 =0, y2 = 0;
    double dist = 0.0;
    
    for (int i = 0; i < len1; ++i) {
        char ch = str1[i];
        if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' || ch == 'O' || ch == 'u' || ch == 'U') {
            x1++;
            
        }
        else {
            y1++;
        }
    }
    for (int j = 0; j < len2; ++j) {
        char ch = str2[j];
        if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' || ch == 'O' || ch == 'u' || ch == 'U') {
            x2++;
            
        }
        else {
            y2++;
        }
    }
    dist = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
    printf("%.3lf", dist);

    return 0;
}
   