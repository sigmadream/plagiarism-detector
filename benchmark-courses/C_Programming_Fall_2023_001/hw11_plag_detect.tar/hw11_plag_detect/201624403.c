#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

typedef struct {
	int numerator;
	int denominator;
} Rational;

int gcd(int a, int b) {
	if (a == b)
		return a;
	else if (a > b)
		return gcd(b, a);
	else
		return gcd(a, b - a);
}

int main() {
	Rational r1;
	Rational r2;

	scanf("%d%d", &r1.numerator, &r1.denominator);
	scanf("%d%d", &r2.numerator, &r2.denominator);

	int numerator_result = r1.numerator * r2.numerator;
	int denominator_result = r1.denominator * r2.denominator;

	int num_gcd = gcd(numerator_result, denominator_result);

	printf("%d/%d", numerator_result / num_gcd, denominator_result / num_gcd);
	return 0;
}