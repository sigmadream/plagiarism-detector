#include <stdio.h>
int gcd(int, int);
typedef struct _Rational{
    int x;
    int y;
} Rational;
int main(){
    Rational point1;
    Rational point2;
    scanf("%d%d",&point1.x,&point1.y);
    scanf("%d%d",&point2.x,&point2.y);
    int x = point1.x*point2.x;
    int y = point2.y*point1.y;
    int gcd_num = gcd(x, y);
    printf("%d/%d",x/gcd_num, y/gcd_num);
    return 0;
}


int gcd(int a, int b) {
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}
