#include <stdio.h>

int gcd(int a, int b) {
	if (a == b)
		return a;
	else if (a > b)
		return gcd(b, a);
	else 
		return gcd(a, b - a);
}

typedef struct {
	int upper;
	int lower;
} Rational;


int main() 
{
	int a1, b1;
	
	scanf("%d %d", &a1, &b1);
	Rational a;
	a.upper = a1;
	a.lower = b1;
	
	int a2, b2;
	scanf("%d %d", &a2, &b2);
	Rational b;
	b.upper = a2;
	b.lower = b2;
	
	Rational c;
	c.upper = a.upper*b.upper;
	c.lower = a.lower*b.lower;
	
	int d = gcd(c.lower, c.upper);
	
	c.upper /= d;
	c.lower /= d;
	
	printf("%d/%d", c.upper, c.lower);
	return 0;
}
