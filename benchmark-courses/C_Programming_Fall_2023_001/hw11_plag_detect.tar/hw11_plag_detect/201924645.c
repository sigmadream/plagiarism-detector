#include <stdio.h>

typedef struct {
	int numerator;
	int denominator;
} Rational;

int gcd(int a, int b) {
	if (a == b)
		return a;
	else if (a > b)
		return gcd(b, a);
	else
		return gcd(a, b - a);
}

Rational Mul_Rat(Rational a, Rational b) {
	Rational mulRat;
	int gcdNum;
	mulRat.numerator = a.numerator * b.numerator;
	mulRat.denominator = a.denominator * b.denominator;
	gcdNum = gcd(mulRat.numerator, mulRat.denominator);
	mulRat.numerator /= gcdNum;
	mulRat.denominator /= gcdNum;

	return mulRat;
}

int main() {

	Rational num[2], mulRat;
	for (int i = 0; i < 2; i++) {
		scanf("%d %d", &num[i].numerator, &num[i].denominator);
	}

	mulRat = Mul_Rat(num[0], num[1]);

	printf("%d/%d\n", mulRat.numerator, mulRat.denominator);

	return 0;
}