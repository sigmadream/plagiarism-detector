#include <stdio.h>

int gcd(int a, int b ) {
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b,a);
    else
        return gcd(a, b -a);
}

typedef struct{
    int x;
    int y;
}Rational;


int main(){
    Rational a;
    Rational b;

    scanf("%d %d", &a.x, &a.y);
    scanf("%d %d", &b.x, &b.y);

    Rational c;
    c.x = a.x * b.x;
    c.y = a.y * b.y;

    int d = gcd (c.x, c.y);

    printf("%d/%d", c.x/d, c.y/d);

}
