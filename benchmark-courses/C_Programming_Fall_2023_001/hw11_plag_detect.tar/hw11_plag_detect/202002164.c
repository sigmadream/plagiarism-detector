#include<stdio.h>

int gcd(int a, int b) {
	if (a == b)
		return a;
	else if (a > b)
		return gcd(b, a);
	else
		return gcd(a, b - a);
}

int main() {
	int gcd_num;
	
	typedef struct {
		int numerator;
		int denumerator;
	} num;
	
	num num1;
	num num2;
	num res;
	
	scanf("%d%d", &num1.numerator, &num1.denumerator);
	scanf("%d%d", &num2.numerator, &num2.denumerator);
	
	res.numerator = num1.numerator * num2.numerator;
	res.denumerator = num1.denumerator * num2.denumerator;
	
	gcd_num = gcd(res.numerator, res.denumerator);
	res.numerator /= gcd_num;
	res.denumerator /= gcd_num;
	
	printf("%d/%d", res.numerator, res.denumerator);
	
	
	return 0;
}
