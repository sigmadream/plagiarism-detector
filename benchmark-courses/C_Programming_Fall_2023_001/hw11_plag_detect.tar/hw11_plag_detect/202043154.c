#include <stdio.h>

// Rational 구조체 정의
typedef struct
{
    int numerator;   // 분자
    int denominator; // 분모
} Rational;

// 최대공약수를 계산하는 함수
int gcd(int a, int b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

// 두 Rational 구조체의 곱을 계산하는 함수
Rational multiplyRationals(Rational a, Rational b)
{
    Rational result;
    result.numerator = a.numerator * b.numerator;
    result.denominator = a.denominator * b.denominator;
    // 결과를 기약분수로 간소화
    int common = gcd(result.numerator, result.denominator);
    result.numerator /= common;
    result.denominator /= common;
    return result;
}

int main()
{
    Rational rational1, rational2;

    // 사용자로부터 두 개의 유리수를 입력 받음
    scanf("%d %d", &rational1.numerator, &rational1.denominator);

    scanf("%d %d", &rational2.numerator, &rational2.denominator);

    // 유리수를 곱하고 결과를 계산
    Rational product = multiplyRationals(rational1, rational2);

    // 결과 출력
    printf("%d/%d\n", product.numerator, product.denominator);

    return 0;
}
