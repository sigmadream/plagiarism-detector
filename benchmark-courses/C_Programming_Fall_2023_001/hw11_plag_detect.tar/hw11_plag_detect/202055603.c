#include <stdio.h>

typedef struct Rational{
        int numerator;
        int denominator;
    }rat;

int gcd(int a, int b){
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b,a);
    else
        return gcd(a, b-a);
}

int main(){
    rat rat1;
    rat rat2;

    scanf("%d%d", &rat1.numerator, &rat1.denominator);
    scanf("%d%d", &rat2.numerator, &rat2.denominator);

    //printf("%d %d", rat1.numerator, rat1.denominator);

    int num = rat1.numerator * rat2.numerator;
    int denom = rat1.denominator * rat2.denominator;
    //printf("%d %d\n", num, denom);
    if (gcd(num, denom) ==1){
        printf("%d/%d",num,denom);
    } else {
        printf("%d/%d",num/gcd(num,denom), denom/gcd(num,denom));
    }
    return 0;
}
