#include <stdio.h>
#include <stdlib.h>

int gcd(int a, int b) {
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}


typedef struct
{
    int numerator;
    int denominator;
} Rational;

int main()
{
    Rational r1;
    Rational r2;
    scanf("%d %d",&(r1.numerator),&(r1.denominator));
    scanf("%d %d",&(r2.numerator),&(r2.denominator));

    r1.numerator = r1.numerator * r2.numerator;
    r1.denominator = r1.denominator * r2.denominator;

    int g = gcd(r1.numerator,r1.denominator);
    r1.numerator /= g;
    r1.denominator /= g;

    printf("%d/%d",r1.numerator,r1.denominator);

    return 0;
}
