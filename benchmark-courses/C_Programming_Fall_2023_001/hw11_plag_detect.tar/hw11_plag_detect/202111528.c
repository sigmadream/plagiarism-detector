#include <stdio.h>

int gcd(int prod1, int prod2) {
    if(prod1 == prod2) {
        return prod1;
    } else if(prod1>prod2) {
        return gcd(prod2, prod1);
    } else if(prod1>=prod2) {
        return gcd(prod1, prod1%prod2);
    }
    return gcd(prod2, prod2%prod1);
}

int main() {
    int a1, a2;
    int b1, b2;

    scanf("%d%d", &a1, &a2);
    scanf("%d%d", &b1, &b2);

    int prod1 = a1*b1;
    int prod2 = a2*b2;

    int GCD = gcd(prod1, prod2);

    printf("%d", GCD);


    
}