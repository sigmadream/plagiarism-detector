#include <stdio.h>

typedef struct {
    int numerator;
    int denominator;
} Rational;

int findGCD(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int main() {
    Rational r1, r2, product;

    scanf("%d %d", &r1.numerator, &r1.denominator);
    scanf("%d %d", &r2.numerator, &r2.denominator);

    product.numerator = r1.numerator * r2.numerator;
    product.denominator = r1.denominator * r2.denominator;

    int common_divisor = findGCD(product.numerator, product.denominator);
    product.numerator /= common_divisor;
    product.denominator /= common_divisor;

    printf("%d/%d\n", product.numerator, product.denominator);

    return 0;
}
