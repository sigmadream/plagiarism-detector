#include <stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct Rational
{
	int x;
	int y;
}rational;

//�м� 2�� �Է¹޾Ƽ� x����, y���� ���ϱ�
rational RESULT(rational a, rational b)
{
	int x1 = a.x * b.x;
	int y1 = a.y * b.y;
	rational rst = { x1,y1 };
	return rst;
}

//�ִ����� ���ϱ�
int GCD(int a, int b)
{
	if (a == b)
	{
		return a;
	}
	else if (a > b)
	{
		return GCD(b, a);
	}
	else
		return GCD(a, b - a);
}

int main(void)
{
	rational r1, r2;
	scanf("%d %d", &r1.x, &r1.y);
	scanf("%d %d", &r2.x, &r2.y);
	rational semi_result = RESULT(r1, r2);
	int gcd = GCD(semi_result.x, semi_result.y);
	int result_x = semi_result.x / gcd;
	int result_y = semi_result.y / gcd;
	printf("%d/%d", result_x, result_y);
	return 0;
}
