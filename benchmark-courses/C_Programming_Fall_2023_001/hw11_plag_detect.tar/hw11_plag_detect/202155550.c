#include <stdio.h>
#include <string.h>

struct rat{
int num;
int den;
};

int gcd(int a, int b) {

if (a == b){
return a;
}
else if (a > b){
return gcd(b, a);}
else{
return gcd(a, b - a);}
}


typedef struct rat rat;

int main(void) {
  
  struct rat a[2];

  scanf("%d %d", &a[0].num, &a[0].den);
  scanf("%d %d", &a[1].num, &a[1].den);
  int ratNum = a[0].num*a[1].num;
  int ratDen = a[0].den*a[1].den;

  int ratGcd = gcd(ratNum, ratDen);
  printf("%d/", ratNum/ratGcd);
  printf("%d", ratDen/ratGcd);
  
  
  
  return 0;
}