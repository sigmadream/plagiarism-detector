#include <stdio.h>

// Function to calculate the greatest common divisor (GCD) of two numbers
int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}

// Structure to represent a Rational number
typedef struct {
    int numerator;
    int denominator;
} Rational;

int main() {
    Rational num1, num2, product;

    // Input for the first rational number
    scanf("%d %d", &num1.numerator, &num1.denominator);

    // Input for the second rational number
    scanf("%d %d", &num2.numerator, &num2.denominator);

    // Calculate the product
    product.numerator = num1.numerator * num2.numerator;
    product.denominator = num1.denominator * num2.denominator;

    // Simplify the product by finding the GCD
    int common_divisor = gcd(product.numerator, product.denominator);
    product.numerator /= common_divisor;
    product.denominator /= common_divisor;

    // Print the result as a simple fraction
    printf("%d/%d\n", product.numerator, product.denominator);

    return 0;
}
