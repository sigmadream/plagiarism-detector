#include <stdio.h>

typedef struct {
    int numerator;
    int denominator;
} Rational;

int gcd(int a, int b) {
    while (b != 0) {
        int temp = a % b;
        a = b;
        b = temp;
    }
    return a;
}

int main() {
    Rational r1, r2, product;

    // Read the values for the two rational numbers
    scanf("%d %d %d %d", &r1.numerator, &r1.denominator, &r2.numerator, &r2.denominator);

    // Multiply
    product.numerator = r1.numerator * r2.numerator;
    product.denominator = r1.denominator * r2.denominator;

    // Simplify the fraction
    int commonDivisor = gcd(product.numerator, product.denominator);
    product.numerator /= commonDivisor;
    product.denominator /= commonDivisor;

    // Print the result
    printf("%d/%d\n", product.numerator, product.denominator);

    return 0;
}
