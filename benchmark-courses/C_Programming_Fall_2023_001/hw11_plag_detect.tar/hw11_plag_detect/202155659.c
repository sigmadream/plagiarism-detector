#include <stdio.h>

typedef struct
{
    int nu;
    int de;
} Rational;

int gcd(int a, int b)
{
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

int main()
{
    Rational r1, r2;
    int numerator, denominator, divisor;

    scanf("%d %d", &r1.nu, &r1.de);
    scanf("%d %d", &r2.nu, &r2.de);

    numerator = r1.nu * r2.nu;
    denominator = r1.de * r2.de;
    divisor = gcd(numerator, denominator);

    printf("%d/%d", numerator / divisor, denominator / divisor);

    return 0;
}

