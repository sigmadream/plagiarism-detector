#include <stdio.h>

typedef struct Rational
{
	int numerator;
	int denominator;
}Rational;

int gcd(int a, int b) {
	if(a == b)
		return a;
	else if (a > b)
		return gcd(b, a);
	else
		return gcd(a, b - a);
}

int main() {
	
	Rational fraction_first;
	Rational fraction_second;
	
	scanf("%d %d",&fraction_first.numerator, &fraction_first.denominator);
	scanf("%d %d",&fraction_second.numerator, &fraction_second.denominator);
	
	int gcd_fractrion = gcd((fraction_first.numerator*fraction_second.numerator)
	,(fraction_first.denominator*fraction_second.denominator));
	
	if(gcd_fractrion != 1)
		printf("%d/%d",(fraction_first.numerator*fraction_second.numerator)/gcd_fractrion,
		(fraction_first.denominator*fraction_second.denominator)/gcd_fractrion);
	else
		printf("%d/%d",fraction_first.numerator*fraction_second.numerator,
		fraction_first.denominator*fraction_second.denominator);
	
	
	
	return 0;	
}
