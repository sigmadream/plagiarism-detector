#include <stdio.h>

typedef struct {
    int num;// numerator
    int denom; // denominator 
} Rational;


int gcd(int a, int b) {
    if (a == b)
        return a; 
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

int main() {
    Rational num1, num2, product;

    scanf("%d %d", &num1.num, &num1.denom);
    scanf("%d %d", &num2.num, &num2.denom);

    product.num = num1.num * num2.num;
    product.denom = num1.denom * num2.denom;

    int divisor = gcd(product.num, product.denom);
    product.num /= divisor;
    product.denom /= divisor;

    printf("%d/%d\n", product.num, product.denom);

    return 0;
}
