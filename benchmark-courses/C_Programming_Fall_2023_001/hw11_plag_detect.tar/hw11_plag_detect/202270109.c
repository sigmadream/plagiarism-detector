#include <stdio.h>

typedef struct Rational {
    int numerator;
    int denominator;
} Rational;

int gcd(int a, int b){
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else 
        return gcd(a, b - a);
}

Rational product(Rational rat1, Rational rat2){
    Rational product;
    product.numerator = rat1.numerator * rat2.numerator;
    product.denominator = rat1.denominator * rat2.denominator;
    int gcdR = gcd(product.numerator, product.denominator);
    product.numerator /= gcdR;
    product.denominator /= gcdR;
    return product;
}

int main(){
    Rational rat1, rat2, result;

    scanf("%d", &rat1.numerator);
    scanf("%d", &rat1.denominator);

    scanf("%d", &rat2.numerator);
    scanf("%d", &rat2.denominator);

    result = product(rat1, rat2);

    printf("%d/%d", result.numerator, result.denominator);
    
    return 0;
}