#include <stdio.h>

int gcd(int a, int b){
    if(a==b)
        return a;
    else if(a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

int main() {
    int a, b, c, d;

    scanf("%d%d", &a, &b);
    scanf("%d%d", &c, &d);

    int son = a * c;
    int parent = b * d;
    int my_gcd = gcd(son, parent);

    son /= my_gcd;
    parent /= my_gcd;

    

    printf("%d/%d", son, parent);

    //printf("GCD(%d, %d) = %d\n", a, b, gcd(a, b));

    return 0;
}