#include <stdio.h>

int gcd(int a, int b) {
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

typedef struct {
    int n, d;
} Rational;

int main() {
    Rational p, q, r;
    scanf("%d%d", &p.n, &p.d);
    scanf("%d%d", &q.n, &q.d);
    r.n = p.n * q.n;
    r.d = p.d * q.d;
    int cd = gcd(r.n, r.d);
    r.n /= cd;
    r.d /= cd;
    printf("%d/%d\n", r.n, r.d);
    return 0;
}

