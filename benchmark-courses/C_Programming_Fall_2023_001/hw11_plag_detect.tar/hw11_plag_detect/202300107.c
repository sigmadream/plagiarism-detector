#include <stdio.h>

int gcd(int a, int b)
{
    if (a == b){
        return a;
    }
    else if (a > b){
        return gcd(b, a);
    }
    else {
        return gcd(a, b - a);
    }
}


int main()
{
    typedef struct rational_num{
    int a, b, c, d;
    int deno, nume, find_gcd;
    } Rational;

    Rational rnm;
    scanf("%d%d", &rnm.a, &rnm.b);
    scanf("%d%d", &rnm.c, &rnm.d);
    rnm.deno = rnm.b*rnm.d;
    rnm.nume = rnm.a*rnm.c;
    rnm.find_gcd = gcd(rnm.deno, rnm.nume);
    
    printf("%d/%d", rnm.nume/rnm.find_gcd, rnm.deno/rnm.find_gcd);
    return 0;
}