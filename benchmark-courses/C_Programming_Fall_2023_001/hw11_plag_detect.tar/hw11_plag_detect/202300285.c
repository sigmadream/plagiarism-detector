#include <stdio.h>

int gcd(int a, int b) {

if (a == b)
    return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

int main () {

 int a1, a2, b1, b2;

scanf("%d%d",&a1,&b1);
scanf("%d%d",&a2,&b2);

int a = a1 * a2;
int b = b1 * b2;

int A = a / gcd(a, b);
int B = b / gcd(a, b);

printf("%d/%d\n", A, B);

return 0;
}
