#include <stdio.h>

int gcd(int a, int b) {
  if(a==b)
  return a;
  else if(a>b)
      return gcd(b, a);
  else
      return gcd(a, b - a);
}

int main() {
int a, b, c, d;
scanf("%d%d", &a, &b);
scanf("%d%d", &c, &d);
int ac=a*c;
int bd=b*d;
int r = gcd(ac,bd);

if (bd!=0){
  while(gcd(ac,bd)!=1){
    ac=ac/r;
    bd=bd/r;
}
printf("%d/%d\n",ac,bd);
return 0;
}
else
printf("IMPOSSIBLE\n");
}
