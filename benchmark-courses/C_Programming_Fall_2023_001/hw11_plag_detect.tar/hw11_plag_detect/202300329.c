#include <stdio.h>

int gcd (int a, int b){
    
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else 
        return gcd(a, b - a);        
}


int main() {

int a, b, c, d;
int Result1;
int Result2;



fscanf(stdin,"%d %d", &a, &b);
fscanf(stdin,"%d %d", &c, &d);



if (b!=0 && d!=0){
    Result1 = a * c;
    Result2 = b * d;
    printf("%d/%d\n", Result1/gcd(Result1, Result2), Result2/gcd(Result1, Result2));    

}

}
