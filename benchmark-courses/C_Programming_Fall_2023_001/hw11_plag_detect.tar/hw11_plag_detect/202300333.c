#include <stdio.h>
#include <string.h>

int GCD(int a, int b){

    if (a==b){
        return a;
    }
    else if (a > b){
        return GCD(b,a);
    }
    else { 
        return GCD(a, b-a);
    }
}

int main() {

    int a, b, c, d, n, e;
    scanf("%d%d",&a,&b);
    scanf("%d%d",&c,&d);

    if (b != 0 && d != 0){
        n = a*c;
        e = b*d;
        printf("%d/%d\n", n/GCD(n,e), e/GCD(n,e));
    }
    else {
        printf("B and D have to be different from 0.\n");
    }
    
    return 0;

}