#include <stdio.h>
#include <string.h>

int gcd(int a, int b) {
// assuming positive numbers only
if (a == b)
return a;
else if (a > b)
return gcd(b, a);
else
return gcd(a, b - a);
}

int main() {
int a, b, c, d, r, topres = 0, botres = 0, topfin = 0, botfin = 0;

scanf("%d %d", &a, &b);
scanf("%d %d", &c, &d);


if(a>=0 && b>0 && c>=0 && d>0){

topres = a * c;
botres = b * d;

r = gcd(topres, botres);

topfin = topres / r;
botfin = botres / r;

printf("%d/%d", topfin, botfin);

}

else{
    printf("Error, enter valid numbers");
}

return 0;
}
