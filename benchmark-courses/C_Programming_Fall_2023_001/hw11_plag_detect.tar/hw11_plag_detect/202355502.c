#include <stdio.h>
int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}

int main() {
    int num1, den1, num2, den2;
    scanf("%d %d", &num1, &den1);
    scanf("%d %d", &num2, &den2);

    int product_num = num1 * num2;
    int product_den = den1 * den2;
    int common_divisor = gcd(product_num, product_den);
    
    product_num /= common_divisor;
    product_den /= common_divisor;
    printf("%d/%d\n", product_num, product_den);

    return 0;
}
