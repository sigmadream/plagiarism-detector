#include <stdio.h>

typedef struct {
    int numerator;
    int denominator;
} Rational;

int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}

int main() {
    Rational r1, r2;

    scanf("%d%d", &r1.numerator, &r1.denominator);
    scanf("%d%d", &r2.numerator, &r2.denominator);

    int num = r1.numerator * r2.numerator;
    int denom = r1.denominator * r2.denominator;

    //if (gcd(num, denom)) {
       // printf("%d/%d", num, denom);
    //} else {
    printf("%d/%d", num/gcd(num, denom), denom/gcd(num, denom));
   // }

    return 0;
}

