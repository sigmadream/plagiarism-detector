//
//  main.c
//  Lab6
//
//  Created by Sandoval Reyes Luis Armando on 2023/10/19.
//

#include <stdio.h>

struct Rational{
    int numerator;
    int denominator;
};

int gcd(int a, int b){
    if (a==b){
        return a;
    }
    else if (a>b){
        return gcd(b, a);
    }
    else{
        return gcd(a, b-a);
    }
}

int main(int argc, const char * argv[]) {
    struct Rational n1;
    struct Rational n2;
    
    scanf("%i %i", &n1.numerator, &n1.denominator);
    scanf("%i %i", &n2.numerator, &n2.denominator);
    
    int answer_n = n1.numerator*n2.numerator;
    int answer_d = n1.denominator*n2.denominator;
    
    printf("%i/%i", (int)(answer_n/gcd(answer_n, answer_d)), (int)(answer_d/gcd(answer_n, answer_d)));
    
    return 0;
}
