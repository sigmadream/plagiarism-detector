#include <stdio.h>

int gcd(int a, int b) {
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

struct Rational{
    int numerator;
    int denominator;
};

int main() {
    struct Rational a;
    scanf("%d %d", &a.numerator, &a.denominator);
    struct Rational b;
    scanf("%d %d", &b.numerator, &b.denominator);

    struct Rational c;
    c.numerator = a.numerator * b.numerator;
    c.denominator = a.denominator * b.denominator;

    int g = gcd(c.numerator, c.denominator);

    c.numerator = c.numerator / g;
    c.denominator = c.denominator / g;

    printf("%d/%d", c.numerator, c.denominator);



    return 0;
}
