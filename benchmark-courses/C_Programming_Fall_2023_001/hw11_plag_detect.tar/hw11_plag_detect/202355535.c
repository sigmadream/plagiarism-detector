#include <stdio.h>

int gcd(int a, int b) {
    if (a==b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

int main () {
    int a, b, c, d;
    scanf("%d %d", &a, &b);
    scanf("%d %d", &c, &d);

    int num = a*c;
    int denom = b*d;
    int final_num = num / gcd(num, denom);
    int final_denom = denom / gcd(num, denom);
    printf("%d/%d", final_num, final_denom);
    return 0;
}