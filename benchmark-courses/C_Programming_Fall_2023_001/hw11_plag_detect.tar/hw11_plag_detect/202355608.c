#include <stdio.h>

struct Rational {
    int numerator;
    int denominator;
};

int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}

int main() {
    struct Rational r1, r2, product;
    scanf("%d %d", &r1.numerator, &r1.denominator);
    scanf("%d %d", &r2.numerator, &r2.denominator);

    product.numerator = r1.numerator * r2.numerator;
    product.denominator = r1.denominator * r2.denominator;

    int common_divisor = gcd(product.numerator, product.denominator);
    product.numerator /= common_divisor;
    product.denominator /= common_divisor;

    printf("%d/%d\n", product.numerator, product.denominator);

    return 0;
}
