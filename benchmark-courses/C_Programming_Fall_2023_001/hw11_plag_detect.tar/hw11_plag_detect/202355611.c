#include <stdio.h>

typedef struct {
    int numerator;
    int denominator;
} Rational;

int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}

void simplify(Rational *r) {
    int common = gcd(r->numerator, r->denominator);
    r->numerator /= common;
    r->denominator /= common;
}

int main() {
    Rational r1, r2, product;

    scanf("%d %d", &r1.numerator, &r1.denominator);
    scanf("%d %d", &r2.numerator, &r2.denominator);

    product.numerator = r1.numerator * r2.numerator;
    product.denominator = r1.denominator * r2.denominator;

    simplify(&product);

    printf("%d/%d\n", product.numerator, product.denominator);

    return 0;
}
