#include <stdio.h>
typedef struct{
    int a, b;
} Rational;
int gcd(int a, int b){
    if(a == b){
        return a;
    }
    else if(a > b){
        return gcd(b, a);
    }
    else{
        return gcd(a, b - a);
    }
}
int main(){
    int g;
    Rational f, s;
    scanf("%d %d", &f.a, &f.b);
    scanf("%d %d", &s.a, &s.b);
    f.a = f.a * s.a;
    f.b = f.b * s.b;
    g = gcd(f.a, f.b);
    printf("%d/%d", f.a/g, f.b/g);

    return 0;
}
