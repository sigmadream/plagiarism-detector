#include <stdio.h>

int gcd(int a, int b) {

    if (a == b)
        return a;
    else if (a>b)
        return gcd(b, a);
    else
        return gcd(a, b-a);
}

int main(){

    typedef struct {

        int numerator;
        int denominator;

    } Rational;

    Rational r1, r2, r3, r4;
    int gcd1;

    scanf("%d %d\n%d %d", &r1.numerator, &r1.denominator, &r2.numerator, &r2.denominator);

    r3.numerator = r1.numerator * r2.numerator;
    r3.denominator = r1.denominator * r2.denominator;

    gcd1 = gcd(r3.numerator, r3.denominator);

    r4.numerator = r3.numerator / gcd1;
    r4.denominator = r3.denominator / gcd1;

    printf("%d/%d", r4.numerator, r4.denominator);

    return 0;
}
