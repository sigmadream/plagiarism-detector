#include <stdio.h>
int gcd(int a, int b){
    if(a==0)
        return b;
    else if (a>b)
        return gcd(b,a);
    else
        return gcd(a,b-a);
}
int main(){
typedef struct{
int numerator;
int denominator;
} rational;

rational a,b,product;

scanf("%d%d\n%d%d",&a.numerator,&a.denominator,&b.numerator,&b.denominator);
product.numerator=a.numerator*b.numerator;
product.denominator=a.denominator*b.denominator;


printf("%d/%d",product.numerator/gcd(product.numerator,product.denominator),product.denominator/gcd(product.numerator,product.denominator));
    return 0;
}