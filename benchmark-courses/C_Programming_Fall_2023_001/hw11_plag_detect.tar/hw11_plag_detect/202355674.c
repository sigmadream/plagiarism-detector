#include <stdio.h>

int gcd(int a, int b)
{
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

typedef struct Rational{
    int nume1;
    int den1;
    int nume2;
    int den2;
} rtl;

int main()
{
    int a, b;
    rtl rt;
    scanf("%d %d", &rt.nume1, &rt.den1);
    scanf("%d %d", &rt.nume2, &rt.den2);
    a = rt.nume1 * rt.nume2;
    b = rt.den1 * rt.den2;
    printf("%d / %d ", a/gcd(a, b), b/ gcd(a, b));

    return 0;
}

