#include <stdio.h>
int gcd(int a , int b){
    if (b == 0 )return a;
    return gcd(b, a % b);
 }
typedef struct{
    int n;
    int d;

} Rational;
 int main(){
    Rational r1 , r2, pr;

    scanf("%d %d", &r1.n , &r2.n);

    scanf("%d %d", &r1.d , &r2.d);

    pr.n = r1.n * r1.d;
    pr.d = r2.n * r2.d;

    int c = gcd(pr.n, pr.d);

    pr.n /= c;
    pr.d /= c;

    printf("%d %d\n", pr.n, pr.d );

    return 0;



 }
