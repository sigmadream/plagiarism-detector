#include <stdio.h> 

int gcd(int a, int b){

    if(a == b){
        return a;
    }
    else if(a > b){
        return gcd(b, a);
    }
    else{
        return gcd(a, b-a);
    }

}

typedef struct Rational{
        int x1, y1, x2, y2;
} rtl;

int main()
{   
    rtl rt;
    scanf("%d %d", &rt.x1, &rt.y1);
    scanf("%d %d", &rt.x2, &rt.y2);
    int num2 = rt.y1 * rt.y2;
    int num1 = rt.x1 * rt.x2;

    int ans = gcd(num1, num2);

    int n1 = num1 / ans;
    int n2 = num2 / ans;
    printf("%d/%d", n1, n2);

    return 0;
}
