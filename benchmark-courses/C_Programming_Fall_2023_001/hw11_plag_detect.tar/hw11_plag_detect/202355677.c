

#include <stdio.h>

int gcd(int a, int b)
{
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}
typedef struct
{
    int numerator;
    int denominator;
}Rational;

int main()
{
    Rational p1, p2, product;
    fscanf(stdin,"%d %d",&p1.numerator, &p1.denominator);
    fscanf(stdin,"%d %d",&p2.numerator, &p2.denominator);

    product.numerator = p1.numerator * p2.numerator;
    product.denominator = p1.denominator * p2.denominator;

    int z = gcd(product.numerator, product.denominator);

    product.numerator = product.numerator/z;
    product.denominator = product.denominator/z;

    printf("%d/%d", product.numerator, product.denominator);
    return 0;
}
