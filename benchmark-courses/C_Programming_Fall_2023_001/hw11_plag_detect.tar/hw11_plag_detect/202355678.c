#include <stdio.h>

typedef struct {
 int numerator;
 int denominator;
 } Rational;

 int gcd(int a, int b) {
 // assuming positive numbers only
if (a == b)
return a;
else if (a > b)
return gcd(b, a);
else
return gcd(a, b - a);
 }



 int main() {
     Rational R1,R2,product;


 scanf("%d %d", &R1.numerator, &R1.denominator);
 scanf("%d %d", &R2.numerator, &R2.denominator);

 product.numerator = R1.numerator * R2.numerator;
 product.denominator = R1.denominator* R2.denominator;

int c = gcd(product.numerator,product.denominator);
product.numerator = product.numerator / c;
product.denominator = product.denominator / c;




 printf("%d/%d\n",product.numerator, product.denominator);

 return 0;
 }
