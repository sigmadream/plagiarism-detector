#include <stdio.h>

typedef struct
{
	int a, b;
} Rational;

int gcd(int a, int b)
{
	while(a != 0 && b != 0)
	{
		if(a < b) 
			b %= a;
		else
			a %= b;
	}
	return a + b;
}


int main()
{
	Rational fi, se;
	scanf("%d%d", &fi.a, &fi.b);
	scanf("%d%d", &se.a, &se.b);
	int A = fi.a * se.a;
	int B = fi.b * se.b;
	int gg = gcd(A, B);
	A /= gg;
	B /= gg;
	printf("%d/%d", A, B);
}
