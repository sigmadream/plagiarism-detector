#include <stdio.h>

int gcd(int a, int b) {
    if (a == b)
        return a;
    else if (a > b)
        return gcd(b, a);
    else
        return gcd(a, b - a);
}

struct Rational {
    int numerator;
    int denominator;
};

int main() {
    struct Rational rational1, rational2, product;

    scanf("%d %d", &rational1.numerator, &rational1.denominator);
    scanf("%d %d", &rational2.numerator, &rational2.denominator);

    product.numerator = rational1.numerator * rational2.numerator;
    product.denominator = rational1.denominator * rational2.denominator;

    int common_factor = gcd(product.numerator, product.denominator);

    product.numerator /= common_factor;
    product.denominator /= common_factor;

    printf("%d/%d\n", product.numerator, product.denominator);

    return 0;
}