#include <stdio.h>

int main() {
	int r = -1;
	int n = -1;

	if (scanf("%d", &n)==1) {
		printf("%d", n + 1);
	}
	else {
		printf("%s", "NaN");
	}
	return r + 1;
}