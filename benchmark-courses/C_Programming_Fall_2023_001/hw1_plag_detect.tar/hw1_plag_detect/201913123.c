#include <stdio.h>

int main()
{
    int n;
    int rv = scanf("%d", &n);
    if(rv == 1){
    	printf("%d", ++n);
    }
    else printf("NaN");
    return rv-1;
}
