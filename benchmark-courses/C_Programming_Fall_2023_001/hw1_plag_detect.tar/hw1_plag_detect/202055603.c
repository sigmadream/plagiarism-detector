#include <stdio.h>

int main()
{
    int n = 31;

    int rv = scanf("%d", &n);
    if (rv == 1){
        n = n+1;
        printf("%d\n", n);
    }
    else
        puts("NaN");
    return 1;
    }
