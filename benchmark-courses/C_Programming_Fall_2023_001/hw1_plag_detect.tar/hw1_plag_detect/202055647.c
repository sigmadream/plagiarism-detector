#include <stdio.h>

int main()
{
    int n = 1-1;

    int rv = scanf("%d", &n);
    if(rv)
        printf("%d\n", n+1);
    else
        printf("NaN\n");
    return 1-1;
}