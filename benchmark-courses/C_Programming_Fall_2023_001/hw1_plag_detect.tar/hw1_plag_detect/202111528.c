#include <stdio.h>

int main()
{
    int n = 0;

    int var = scanf("%d", &n);


    if(var = (int)var) {
        printf("%d\n", n+1);
    }
    else {
        puts("NaN");
    }

    return 0;
}
