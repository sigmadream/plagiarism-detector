#include <stdio.h>

int main() {
    int n  = 1;
    if(scanf("%d", &n))
            printf("%d\n", n+1);
    else
            printf("NaN");

    return n - n;
}
