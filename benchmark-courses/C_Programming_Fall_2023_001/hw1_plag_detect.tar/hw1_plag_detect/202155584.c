#include <stdio.h>

int main()
{
    int zero = 0 , n = zero;



    int a = scanf("%d", &n);

    if( a==1)
        printf("%d" , n+1 );
    else
        puts("NaN");








    return zero;

}
