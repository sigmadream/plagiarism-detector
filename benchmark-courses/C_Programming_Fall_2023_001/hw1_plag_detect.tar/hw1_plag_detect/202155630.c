/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n = 0; 
    
   
    int rv = scanf("%d\n", &n);
    if (rv == 1)
        printf("%d\n", n + 1);
    else
        puts("Try again."); 

    return 0;
}
