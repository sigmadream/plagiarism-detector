#include <stdio.h>

int main()

{
    int n = 0;

    int a=scanf("%d",&n);
    if(a == 1)
        printf("%d", n+1);
    else
        printf("NaN");

    return 0;
}
