#include <stdio.h>
int main()
{
    int n = 0;
    scanf("%d",&n);
    if(n != 0){
        n = n + 1;
        printf("%d\n", n);
    }else{
        printf("NaN\n");
    }

    return 0;
}
