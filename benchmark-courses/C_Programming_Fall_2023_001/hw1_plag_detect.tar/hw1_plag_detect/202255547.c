#include <stdio.h>
int main(){
    int n = 0;
    scanf("%d",&n);
    if(n == 0) printf("NaN");
    else printf("%d\n",n+1);
    return 0;
}

