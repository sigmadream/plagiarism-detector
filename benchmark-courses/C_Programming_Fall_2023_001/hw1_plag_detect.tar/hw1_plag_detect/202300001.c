#include <stdio.h>
#include <math.h>

int main() {
    float n;

    if (scanf_s("%f", &n) == 1) {
        int x = floor(n);
        if (n == x) {
            int i = n;
            i += 1;
            printf("%d\n", i);
        }
        else {
            printf("NaN\n");
        }
    }

    else {
        printf("NaN\n");
    }

    return 0;
}



 //#include <stdio.h>
 //#include <math.h>
 //int main()
 //{
 //        float n;
 //        printf("Enter the number :--> ");
 //        scanf_s("%f", &n);
 //        int x = floor(n); //typecasting float to int
 //        if ( x == n)
 //        {
 //                printf("The entered number is an integer\n");
 //        }
 //        else
 //        {
 //                printf("The entered number is float\n");
 //        }
 //        return 0;
 //}