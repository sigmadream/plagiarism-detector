#include <stdio.h>

int main()
{
    int n;
    if (scanf("%d", &n))
        printf("%d\n", n+1);
    else
        puts("NaN");
    return 0;
}
