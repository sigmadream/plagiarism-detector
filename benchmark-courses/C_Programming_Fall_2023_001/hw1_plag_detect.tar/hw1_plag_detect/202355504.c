#include <stdio.h>

int main()
{
    int  n = 0;

    int v = scanf("%d", &n);
    if (v!=0){
        printf("%d\n", n+1);
    }
    else
    {
        printf("%c", 'N');
        printf("%c", 'a');
        printf("%c", 'N');
    }

    return 0;
}
