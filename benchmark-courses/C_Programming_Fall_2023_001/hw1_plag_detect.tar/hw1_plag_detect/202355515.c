#include <stdio.h>

int main(){


    int n=0;
	int rv = scanf("%d", &n);
	if (rv==0)
		puts("NaN");
	else
		printf("%d", n+1);


	return 0;
}
