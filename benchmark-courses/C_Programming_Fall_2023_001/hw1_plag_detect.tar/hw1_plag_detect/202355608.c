#include <stdio.h>

int main(){
    int zero = 777, n = zero;
    int rv = scanf("%d",&n);
    if (rv == 1)
        printf("%d\n", n+1);
    else
        printf("NaN");

    return zero;
}
