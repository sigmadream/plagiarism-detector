#include <stdio.h>
int main(){
    int n;
    int c=1;
    c--;
    int rv=scanf("%d", &n);
    if(rv==1){
        printf("%d", n+1);
    }
    else{
        printf("NaN\n");
    }
    return c;
}
