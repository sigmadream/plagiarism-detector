#include <stdio.h>

int main()
{
    int n = 0;

    int num = scanf("%d", &n);
    if (num == 1)
        printf("%d\n", n + 1 );
    else
        puts("NaN");
    return 0;
}
