#include <stdio.h> 

int main()
{
    int numb = 0;
    
    int rv = scanf("%d", &numb);

    if(rv == 1){
        numb = numb + 1;
        printf("%d\n", numb);
    }
    else{
        puts("NaN");
    }
    
    

    return 0;
}   