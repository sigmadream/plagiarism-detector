#include <stdio.h>

int main()
{
    int n;
    int res = scanf("%d", &n);
    if(res == 1)
    {
        printf("%d\n", n+1);
        return res-1;
    }
    else
    {

        printf("NaN\n");
        return res;
    }
}
