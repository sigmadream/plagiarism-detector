#include <stdio.h>
#include <stdlib.h>

int main() {
    int j = 0;

    int rv = scanf("%d", &j);
    if (rv == 1)
        printf("%d", j+1);
    else
        printf("NaN");

    return 0;
}
