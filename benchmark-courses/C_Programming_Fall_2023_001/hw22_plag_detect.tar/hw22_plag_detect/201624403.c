#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int funcType0(int a, int b) {
	return a ^ b;
}

int funcType1(int a, int b) {
	return a + b;
}

int main() {
	int firstNum;
	scanf("%d", &firstNum);

	int (*myFunction)(int a, int b);

	if (firstNum % 2 == 0) {
		myFunction = &funcType0;
	}
	else {
		myFunction = &funcType1;
	}

	int n;
	while (scanf("%d",&n) != EOF) {
		firstNum = myFunction(firstNum, n);
	}

	printf("%d", firstNum);

	return 0;
}