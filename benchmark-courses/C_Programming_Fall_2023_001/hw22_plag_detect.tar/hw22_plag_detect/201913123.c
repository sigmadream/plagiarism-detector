#include <stdio.h>
#include <ctype.h>
int sum(int , int, int);
int main(){
    char ls[2001];
    int i = 0;
    long long ans = 0;
    int (*fun)(int ,int ,int) = sum;
    fgets(ls, 2001, stdin);
    while(ls[i] != '\0'){
        if(ls[i] == '\n')
            break;
        int type = ls[0] - '0';
        if(isalnum(ls[i]) && type % 2 == 1){
            int temp = ls[i] - '0';
            ans += fun(ans, temp, type%2);
        }
        else if(isalnum(ls[i]) && type % 2 == 0){
            int temp = ls[i] - '0';
            ans = fun(ans, temp, type%2);
        }
        i++;
    }
    printf("%lld", ans);
    return 0;
}
int sum(int all, int num, int type){
    if(type == 1){
        return num;
    }
    else{
        return all ^ num;
    }
}
