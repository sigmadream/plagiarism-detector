#include <stdio.h>

int sum1(int arr[], int size)
{   int sum = 0;
    for (int i=0; i < size; i++) 
    {
        sum += arr[i];
    }
    return sum;
}

int sum0(int arr[], int size)
{
    int sum = arr[0];
    for (int i=1; i < size; i++) 
    {
        sum ^= arr[i];
    }
    return sum;
}

int main() {
    
    int arr[100];
    int ret, value;
    int i = 0;
    int (*fun[])() = {sum0, sum1};
    while (scanf("%d", &value) == 1) {
        arr[i++] = value;
    }
    int size = i;
    switch (arr[0]!= '\0' && arr[0]%2 == 0 ? 0:1)
    {
    case 0:
        ret = fun[0](arr, size);
        break;
    case 1:
        ret = fun[1](arr, size);
        break;
    default:
        break;
    }

    printf("%d\n", ret);

    return 0;
}
