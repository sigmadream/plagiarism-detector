#include <stdio.h>
#include <string.h>

// Function pointer type for the sum function
typedef int (*SumFunction)(int[], int);

// Function declarations
int normalSum(int[], int);
int bitwiseSum(int[], int);

int main() {
    const int MAX_LEN = 2000;
    char line[MAX_LEN];

    // Read a line of input
    fgets(line, MAX_LEN, stdin);

    // Initialize variables
    int numbers[1000];
    int n = 0;

    // Tokenize the input line
    char *word = strtok(line, " ");
    while (word != NULL && n < 1000) {
        sscanf(word, "%d", &numbers[n]);
        n++;
        word = strtok(NULL, " ");
    }

    // Check if the first number is even or odd to determine the sum type
    int isEven = numbers[0] % 2 == 0;

    // Declare a function pointer and assign the appropriate sum function
    SumFunction sumFunction = isEven ? bitwiseSum : normalSum;

    // Calculate the sum using the selected function
    int result = sumFunction(numbers, n);

    // Print the result
    printf("%d\n", result);

    return 0;
}

// Function to calculate the normal sum (sum type 1)
int normalSum(int arr[], int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    return sum;
}

// Function to calculate the bitwise sum (sum type 0)
int bitwiseSum(int arr[], int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum ^= arr[i];
    }
    return sum;
}


