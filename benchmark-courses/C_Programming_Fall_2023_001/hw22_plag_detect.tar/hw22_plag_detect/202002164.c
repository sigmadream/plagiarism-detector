#include<stdio.h>

int type_0(int*, int); // ^���� 
int type_1(int*, int); // +���� 

int main() {
	int n[10000], res;
	int i = 0;
	while (scanf("%d", &n[i]) != EOF){
		i++;
	}
	int (*sum[2])() = {type_0, type_1};
	res = sum[n[0] % 2](n, i);
	printf("%d", res);
}

int type_0(int *address, int size) {
	int i, res = 0;
	for (i = 0; i < size; i++) {
		res ^= address[i];
	}
	return res;
}

int type_1(int *address, int size) {
	int i, res = 0;
	for (i = 0; i < size; i++) {
		res += address[i];
	}
	return res;
}


