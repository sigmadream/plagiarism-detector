#include <stdio.h>

int add0(int a, int b) { return a ^ b; }
int add1(int a, int b) { return a + b; }
int main()
{
    int n = 0;
    int (*fun[])(int, int) = {add0, add1};
    scanf("%d", &n);
    if (n % 2 == 0)
    {
        int tmp = n;
        while (scanf("%d", &n) == 1)
        {
            tmp = fun[0](tmp, n);
        }
        printf("%d\n", tmp);
        return 0;
    }
    int tmp = n;
    while (scanf("%d", &n) == 1)
    {
        tmp = fun[1](tmp, n);
    }
    printf("%d\n", tmp);
    return 0;
}