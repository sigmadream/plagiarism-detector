#include <stdio.h>

int normadd(int n, int sum){
    sum += n;
    return sum;
}

int binadd(int n, int sum){
    sum ^= n;
    return sum;
}



int main(){
    int initiate_num;
    scanf("%d", &initiate_num);
    int i = initiate_num & 1;
    int (*add_flag[])() = {binadd, normadd};
    //int tempnum = 0;
    int tempsum = 0;
    char inpchar[4096];
    fgets(inpchar, sizeof(inpchar), stdin);
    char *nump = inpchar;

    tempsum = add_flag[i](initiate_num, tempsum);

    while (*nump != '\n'){
        if (*nump == ' '){
            nump++;
        } else if (*(nump + 1) != ' ' && *(nump + 1) != '\n'){ // num >= 10;
            tempsum = add_flag[i](10*(*nump - '0') + (*(nump+1) - '0'),tempsum);
            nump++;
            nump++;
        } else { // it matters when decimal consists of two chars
            tempsum = add_flag[i](*nump++ - '0', tempsum);
        }
    }

    printf("%d", tempsum);


    return 0;
}
