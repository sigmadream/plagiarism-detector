#include <stdio.h>
#include <stdlib.h>

int add(int a, int b)
{
        return a + b;
}

int xor(int a, int b)
{
        return a ^ b;
}


int main()
{

    int (*fun)(int, int);

    int inp;

    scanf("%d", &inp);

    if(inp%2 == 0)
        fun = xor;
    else
        fun = add;

    int result = inp;

    while (scanf("%d", &inp) != EOF)
        result = fun(result, inp);

    printf("%d",result);

    return 0;
}
