#include <stdio.h>

int main() {

    int input[100];
    int sum=0;
    int sz=0;

    for (int i=0; i<10000; i++) {
        scanf("%d", &input[i]);
        sz ++;
        if(getchar() == '\n') break;

    }

    if (input[0]%2==0) {  // 첫번째로 입력받은 숫자가 짝수라면 XOR
        for (int i=0; i<sz; i++) {
           sum ^= input[i];
        }
        
    } else {
        for (int i=0; i<sz; i++) {
            sum += input[i];
        }
    }

    printf("%d", sum);

    return 0;
}