#include <stdio.h>
#include <stdlib.h>

// Function for normal addition
int sum_type_1(int a, int b) {
    return a + b;
}

// Function for bitwise XOR addition
int sum_type_0(int a, int b) {
    return a ^ b;
}

int main() {
    int n;
    scanf("%d", &n);

    int numbers[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", &numbers[i]);
    }

    int sum;

    // Determining the type of sum based on the parity of the first number
    if (numbers[0] % 2 == 0) {
        sum = numbers[0]; // Start the sum with the first number
        for (int i = 1; i < n; i++) {
            sum = sum_type_0(sum, numbers[i]); // Use XOR addition
        }
    } else {
        sum = numbers[0]; // Start the sum with the first number
        for (int i = 1; i < n; i++) {
            sum = sum_type_1(sum, numbers[i]); // Use normal addition
        }
    }

    printf("%d\n", sum);

    return 0;
}
