#include<stdio.h>

int TYPE1(int ary[], int i) {
    int result = 0;
    for (int j = 0; j < i + 1; j++)
    {
        result += ary[j];
    }
    return result;
}

int TYPE0(int ary[], int i) {
    int result = ary[0] ^ ary[1];
    for (int j = 2; j < i + 1; j++)
    {
        result = result ^ ary[j];
    }
    return result;
}

int main()
{
    int arr[1000];
    int i, j;
    int result = 0;

    int(*ptr)(int ary[], int a);

    for (i = 0; i < 1000; i++) {
        scanf("%d", &arr[i]);

        if (getc(stdin) == '\n')
            break;
    }

    if (arr[0] % 2 == 1) {
        ptr = TYPE1;
        result = ptr(arr, i);
        printf("%d", result);
    }

    else {
        ptr = TYPE0;
        result = ptr(arr, i);
        printf("%d", result);
    }
    return 0;
}