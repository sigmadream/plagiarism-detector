#include <stdio.h>

// Function to perform normal addition sum
int add(int a, int b) {
    return a + b;
}

// Function to perform bitwise XOR sum
int xorSum(int a, int b) {
    return a ^ b;
}

int main() {
    // Read input
    int n;
    scanf("%d", &n);

    // Read the numbers and determine the type of sum
    int type;
    scanf("%d", &type);

    // Define function pointer based on the type
    int (*sumFunction)(int, int);

    if (type == 0) {
        sumFunction = &xorSum;
    } else {
        sumFunction = &add;
    }

    // Initialize the sum
    int sum = 0;

    // Read the numbers and perform the sum based on the type
    for (int i = 0; i < n; ++i) {
        int num;
        scanf("%d", &num);

        // Use function pointer to perform the sum
        sum = sumFunction(sum, num);
    }

    // Print the result
    printf("%d\n", sum);

    return 0;
}
