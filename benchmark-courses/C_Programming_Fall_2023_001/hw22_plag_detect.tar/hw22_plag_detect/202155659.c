#include <stdio.h>

int type1(int arr[], int n)
{
    int xorSum = 0, i;

    for (i = 0; i < n; i++)
    {
        xorSum ^= arr[i];
    }

    return xorSum;
}

int type2(int arr[], int size)
{
    int sum = 0, i;

    for (i = 0; i < size; i++)
    {
        sum += arr[i];
    }

    return sum;
}
int main()
{
    int arr[150];
    int i = 0, j;
    int ch;

    // Read the first character
    ch = getchar();

    while (ch != '\n')
    {
        // Read an integer and store it in the array
        ungetc(ch, stdin); // Push the character back into the input buffer
        scanf("%d", &arr[i]);
        i++;

        // Read the next character (including spaces)
        ch = getchar();
    }

    int (*typeFunction)(int[], int);

    if (arr[0] % 2 == 1)
    {
        typeFunction = type2; // Assign the address of type2 to the function pointer
    }
    else
    {
        typeFunction = type1; // Assign the address of type1 to the function pointer
    }

    // Call the function through the function pointer
    printf("%d", typeFunction(arr, i));

    return 0;
}
