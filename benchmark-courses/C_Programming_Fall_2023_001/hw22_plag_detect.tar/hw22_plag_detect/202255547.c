#include <stdio.h>

int sumType0(int a, int b){
    return a ^ b;
}

int sumType1(int a, int b){
    return a + b;
}

int main() {
    int numbers[1001];
    int cnt = 0;
    while(scanf("%d",&numbers[cnt]) == 1){
        cnt++;
    }

    int (*sumfunction)(int,int);
    if(cnt > 0 && numbers[0] % 2 == 0){
        sumfunction = sumType0;
    } else {
        sumfunction = sumType1;
    }

    int result = (0 < cnt) ? numbers[0] : 0;
    for(int i=1;i<cnt;i++){
        result = sumfunction(result,numbers[i]);
    }

    printf("%d\n",result);
    return 0;
}
