#include <stdio.h>
#include <stdbool.h>

int sumType1(int currentSum, int operand) {
    currentSum = currentSum + operand;
    return currentSum;
}

int sumType0(int currentSum, int operand) {
    currentSum = currentSum ^ operand;
    return currentSum; 
}

int main() {
    int n = 1, numbers[1010], result = 0; 
    scanf("%d", &numbers[0]); 
    bool isTypeEven = (numbers[0] % 2 == 0);

    int (*sumFunction)(int currentSum, int operand);
    if (isTypeEven) {
        sumFunction = &sumType0;  
    } else {
        sumFunction = &sumType1; 
    }

    result = numbers[0]; 
    
    while (scanf("%d", &numbers[n]) == 1){
        result = sumFunction(result, numbers[n]);
        n++; 
    }

    printf("%d\n", result);
    return 0;
}