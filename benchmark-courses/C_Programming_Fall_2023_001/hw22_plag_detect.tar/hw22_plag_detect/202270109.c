#include <stdio.h>

int sum(int a, int b){
    return a + b;
}

int bit_sum(int a, int b){
    return a ^ b;
}

int main()
{
    int first;
    scanf("%d", &first);

    int (*type_operation) (int, int);
    if (first % 2 == 0){
        type_operation = &bit_sum;
    } else {
        type_operation = &sum;
    }

    int final = first;
    int integers;

    while((scanf("%d", &integers)) == 1){
        final = type_operation(final, integers);
    }

    printf("%d", final);

    return 0;
}
