#include <stdio.h>

int main(){
    int number[100];
    int n=1;
    int sum=0;

    while (scanf("%d",&number[n]) == 1){
    n++;
        }
         int count = 0;
    for (int a = 1; a < n-1; a++) {
        for (int j = a + 1; j < n; j++) {
            if (number[a] == number[j]) {
                count++;
                break;
            }
            }
    }   
    if (number[1]%2==1){
     for(int i=1; i<=n; i++){
        sum=sum+number[i];
    }}
    else {sum=n-count-1;}
    printf("%d",sum);
    return 0;
}