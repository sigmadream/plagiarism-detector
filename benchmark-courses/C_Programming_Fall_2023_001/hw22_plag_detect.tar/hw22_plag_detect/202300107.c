#include <stdio.h>

void printSum(int number) {
    printf("%d", number);
}


int main()
{
    int nums[100], index = 0, type1 = 0, sum = 0;
    int previous_num;
    while (scanf("%d", nums) == 1) {
        if (index == 0) { //identify the first num is odd or even
            if ( *nums%2 == 1) { //the first num is odd
                type1 = 1;
                sum += *nums;
                index += 1;
            }else {// the second num is even
                previous_num = *nums;
                sum = *nums;
                index += 1;
            }
        }else { //check from the second num
            if (type1 == 1) { //do the normal addition
                sum += *nums;
            }else { // do bitwise addtion
                sum = previous_num ^ (*nums);
                previous_num = sum;
            }
        }
    }
    //printf("%d", sum);
    //using function pointer
    void (*fun)() = printSum;
    fun(sum);
    return 0;
}