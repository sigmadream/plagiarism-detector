#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){

int f[1000];
char p[1000];
fgets(p, sizeof(p), stdin);
int len=0,sum=0;

char *num = strtok(p, " ");

while (num != NULL && len < 1000) {
    sscanf(num, "%d", &f[len]);
    len++;
    num = strtok(NULL, " ");
}

if (f[0]%2==1){
  for (int i=0;i< len;i++)
    sum+=f[i];
}
else{
  for (int i=0;i< len;i++)
    sum^=f[i];
}
printf("%d\n", sum );
return 0;
}
