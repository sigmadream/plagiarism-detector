#include <stdio.h>
#include <string.h>  


int main() {

    int list[1000];
    int len = 0;
    int sum = 0;

    int max_lenght = 1000;
    char line[max_lenght];
    fgets(line, max_lenght, stdin);

    char *n = strtok(line, " ");

    while (n != NULL && len<1000){
        sscanf(n,"%d",&list[len]);
        len ++;
        n  = strtok(NULL," ");


    }
    
    if(list[0]%2 == 1){
        for(int i = 0; i < len; i++){
            sum += list[i];
        }}
    else if(list[0]%2 == 0){
        for(int i = 0; i < len; i++){
            sum ^= list[i];
    }    
    }
    printf("%d\n",sum);
    }
