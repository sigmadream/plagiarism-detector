#include <stdio.h>
#include <string.h>  


int main() {

    int list[1000];
    int len = 0, sum = 0;
    char line[1000];
    
    fgets(line, sizeof(line), stdin);
    
    char *num = strtok(line, " ");  

    while (num != NULL && len < 1000) {
        sscanf(num, "%d", &list[len]);
        len++;
        num = strtok(NULL, " ");  
    }
    
    for (int i = 0; i < len; i++){
        if(list[0] % 2 == 0){
            sum ^= list[i];
        }
        else{
            sum += list[i];
        }
    }

// Second method, similar but with a variable which verify if list[0] equals 0 or 1 while being divided by 2.

/*
    int sum = 0;
    int sumType = (list[0] % 2 == 0) ? 0 : 1;
    
    for (int i = 0; i < len; i++) {
        if (sumType == 0) {
            sum ^= list[i];  // XOR operation for sum type 0
        } else {
            sum += list[i];  // Normal addition for sum type 1
        }
    }
  */  

    printf("%d\n", sum);

    return 0;

}
/* With outside function.
#include <stdio.h>
#include <string.h>  


int sum(int array[], int size){
    int sum = 0;
    for (int i = 0; i < size; i++){
        if(array[0] % 2 == 0){
            sum ^= array[i];
        }
        else{
            sum += array[i];
        }
    }

    return sum;

}

int main() {

    int list[1000];
    int len = 0;
    char line[1000];
    
    fgets(line, sizeof(line), stdin);
    
    char *num = strtok(line, " ");  

    while (num != NULL && len < 1000) {
        sscanf(num, "%d", &list[len]);
        len++;
        num = strtok(NULL, " ");  
    }
    
    printf("%d\n", sum(list,len));

    return 0;
}
*/
