#include <stdio.h>
#include <string.h>

//normal addition (sum type 1)
int type_1(int a, int b) {
    return a + b;
}

//XOR addition (sum type 0)
int type_0(int a, int b) {
    return a ^ b;
}

int main(){
    int result = 0;
    char array[100];
    int n = sizeof(array)/sizeof(*array); //len
    int numbers[n];


    while (1){
    if (fgets(array, sizeof(array), stdin) == NULL || strcmp(array, "\n") == 0) {
            break; //if input is none then we break
        }
    for (int i = 0; i < n; i++) {
        scanf("%d", &numbers[i]);
    }

    int (*sum_function)(int, int);
    if (numbers[0] % 2 == 0) {
        sum_function = type_0; //even = XOR
    } else {
        sum_function = type_1; //odd = normal
    }

    int result = numbers[0]; //variable where we will store the result of the sum
    for (int i = 1; i < n; i++) {
        result = sum_function(result, numbers[i]);
        printf("current result: %d\n", " we add: %d\n", result, numbers[i]);
    }
    }

printf("%d\n", result);

return 0;
}
