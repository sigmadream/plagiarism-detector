#include <stdio.h>
int add(int a, int b) {
    return a + b;
}

int sub(int a, int b) {
    return a - b;
}
int sum(int type, int *numbers, int n) {
    int result = numbers[0];
    for (int i = 1; i < n; i++) {
        if (type == 0) {
            result ^= numbers[i];
        } else {
            result += numbers[i];
        }
    }
    return result;
}

int main() {
    int numbers[1000]; 
    int n = 0, input;
    printf("");
    while (scanf("%d", &input) == 1) {
        if (n < sizeof(numbers) / sizeof(numbers[0])) {
            numbers[n++] = input;
        } else {
            printf("\n");
            break;
        }
    }
    int sum_type = (n > 0 && numbers[0] % 2 == 0) ? 0 : 1;
    int result = sum(sum_type, numbers, n);
    printf("%d\n", result);
    return 0;
}
