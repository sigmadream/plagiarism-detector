#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int arr[1000];
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    int result = (arr[0] % 2 == 0) ? 0 : 0; 

    for (int i = 0; i < n; i++) {
        if (arr[0] % 2 == 0) {
            result ^= arr[i]; 
        } else {
            result += arr[i]; 
        }
    }

    printf("%d\n", result);

    return 0;
}
