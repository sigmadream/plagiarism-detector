//
//  main.c
//  Lab9
//
//  Created by Sandoval Reyes Luis Armando on 2023/11/16.
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int sum(int array[], int len){
    int sum = 0;
    for (int i = 0; i<len; i++){
        sum = sum + array[i];
    }
    return sum;
}

int bitwise_sum(int array[], int len){
    int sum = 0;
    for(int i = 0; i<len; i++){
        sum = sum ^ array[i];
    }
    return sum;
}

int main(int argc, const char * argv[]) {
    char input[2000];
    fgets(input, 2000, stdin);
    
    int inputs[1000];
    int index = 0;
    
    char *token = strtok(input, " ");
    while(token != NULL){
        inputs[index] = atoi(token);
        index++;
        token = strtok(NULL, " ");
    }
    
    int factor = inputs[0]%2;
    int result = 0;
    
    switch(factor){
        case 0:
            result = bitwise_sum(inputs, index);
            break;
        case 1:
            result = sum(inputs, index);
            break;
    }
    printf("%d", result);
    
    return 0;
}
