#include <stdio.h>
#include <string.h>

int main() {
    int nums[100];
    int i = 0;
    int j;
    while (scanf("%d", &nums[i]) == 1) {
        i++;
    }
    int sum = 0;
    if ((nums[0] % 2) != 0) {
        for (j = 0; j< i; j++) {
            sum += nums[j];
        }
    }
    else {
        sum = nums[0];
        for (j = 1; j< i; j++) {
            sum ^= nums[j];
        }
    }
    printf("%d", sum);
    return 0;
}