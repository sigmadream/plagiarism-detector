#include <stdio.h>

int sum1(int a, int b) {
    return a + b;
}

int sum2(int a, int b) {
    return a ^ b;
}

int main() {
    int num1, num2;
    char input[1000] = {0, };

    while(1) {
        fgets(input, 1000, stdin);
        if(input[0] == '\n' ) {
            break;
        }
    }

    for(int i=0; i<1000; i++){
        printf("%d", input[i]);
    }

    return 0;
}
