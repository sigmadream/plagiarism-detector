#include <stdio.h>
#include <stdlib.h>

int sumType0(int a, int b);
int sumType1(int a, int b);

int main() {
    int n = 1000;
    int *numbers = (int *)malloc(n * sizeof(int));

    if (numbers == NULL) {
        return 1;
    }
    int num;
    int i = 0;
    while (scanf("%d", &num) == 1) {
        numbers[i++] = num;

        if (i == n) {
            free(numbers);
            return 1;
        }
    }
    if (i == 0) {
        free(numbers);
        return 0;
    }

    int (*sumFunction)(int, int);
    if (numbers[0] % 2 == 0) {
        sumFunction = sumType0;
    } else {
        sumFunction = sumType1;
    }

    int result = numbers[0];
    for (int j = 1; j < i; j++) {
        result = sumFunction(result, numbers[j]);
    }

    printf("%d\n", result);

    free(numbers);

    return 0;
}

int sumType0(int a, int b) {
    return a ^ b;
}

int sumType1(int a, int b) {
    return a + b;
}
