#include <stdio.h>
#include <stdbool.h>
int normsum(int sum, int x){
    sum += x;
    return sum;
}
int bitsum(int sum, int x){
    sum = sum ^ x;
    return sum;
}
int main(){
    int n = 1,a[1010], sum = 0;
    scanf("%d", &a[0]);
    bool type;
    if (a[0] % 2 == 0){
        type = 0;
    }
    else{
        type = 1;
    }
    int (*sum1)(int sum, int x) = normsum;
    int (*sum0)(int sum, int x) = bitsum;
    sum = a[0];
    while(scanf("%d", &a[n]) == 1){
        if(type == 1){
            sum = sum1(sum, a[n]);
        }
        else{
            sum = sum0(sum, a[n]);
        }
        n++;
    }
    printf("%d", sum);
    return 0;
}
