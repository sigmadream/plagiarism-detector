#include <stdio.h>

int sum_1(int a, int b)
{
    return a + b;
}

int sum_0(int a, int b)
{
    return a^b;
}


int main(){
    int* numbers = NULL;
    int i = 0, n;
    do{
        scanf("%d", &n);
        i++;
        numbers = (int*)realloc(numbers, i * sizeof(int));
        numbers[i - 1] = n;

    } while (getchar() != '\n');

    int sum = numbers[0];

    for(int j = 1; j < i; j++){
        if(numbers[0] % 2 == 0){
            sum = sum_0(sum, numbers[j]);
        }
        else{
            sum = sum_1(sum, numbers[j]);
    }
    }
    printf("%d", sum);


}
