#include <stdio.h>
int add(int *a, int b);
int kir(int *a, int b);


int main(){
    int (*p[2])() = {kir, add};
    int n = 10000;
    int numbers[n];
    int i = 0;
    while(scanf("%d", &numbers[i]) == 1){
        i++;
    }
    int j = numbers[0] % 2 ;
    int res = p[j](numbers, i);
    printf("%d", res);
}

int add(int *a, int b){

    int result = 0;
    for(int i = 0; i<b; i++){
        result += a[i];
    }
    return result;
}
int kir(int *a, int b){

    int result = 0;
    for(int i = 0; i<b; i++){
        result ^= a[i];
    }
    return result;
}


