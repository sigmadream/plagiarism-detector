#include <stdio.h>

int sum_type_0(int a, int b);
int sum_type_1(int a, int b);

int main() {
    int n;

    if (scanf("%d", &n) != 1 || n <= 0 || n >= 1000) {
        printf("%d\n");
        return 1;
    }

     int first_number;
    if (scanf("%d", &first_number) != 1) {
        printf("%d\n");
        return 1;
    }

    int (*sum_fun)(int, int);


    int number;
    if (scanf("%d", &number) != 1) {
        printf("%d\n");
        return 1;
    }

    switch (number % 2) {
    case 0:
        sum_fun = sum_type_0;
        break;
    case 1:
        sum_fun = sum_type_1;
        break;
    default:

        break;
}

    int result = number;


    for (int i = 1; i < n; i++) {
        if (scanf("%d", &number) != 1) {
            printf("%d\n", i + 1);
            return 1;
        }


        result = sum_fun(result, number);
    }

    printf("%d\n", result);

    return 0;
}

int sum_type_0(int a, int b) {
    return a ^ b;
}

int sum_type_1(int a, int b) {
    return a + b;
}
