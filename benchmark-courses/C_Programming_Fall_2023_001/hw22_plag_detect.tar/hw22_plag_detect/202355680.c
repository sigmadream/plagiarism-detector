#include <stdio.h>

int a[101010];

int parity(int A)
{
	return A % 2;
}

int main()
{
	for(int i = 1; i <= 1000; ++i)
	{
		scanf("%d", &a[i]);
	}
	int (*fun)(int) = parity;
	int sum = 0;
	if(fun(a[1]))
	{
		for(int i = 1; i <= 1000; ++i)
		{
			sum += a[i];
		}
	}
	else
	{
		for(int i = 1; i <= 1000; ++i)
		{
			sum ^= a[i];
		}
	}
	printf("%d", sum);
}
