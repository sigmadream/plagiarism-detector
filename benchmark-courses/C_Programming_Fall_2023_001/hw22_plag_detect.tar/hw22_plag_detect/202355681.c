#include <stdio.h>

int main() {
    int n, i, num, sum;
    scanf("%d", &n);

    sum = 0;
    for (i = 0; i < n; i++) {
        scanf("%d", &num);
        if (i == 0 && num % 2 == 0) {
            sum ^= num;
        } else {
            sum += num;
        }
    }

    printf("%d\n", sum);
    return 0;
}