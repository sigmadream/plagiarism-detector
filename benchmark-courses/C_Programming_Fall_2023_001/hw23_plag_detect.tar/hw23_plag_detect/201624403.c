#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int funcDouble(int a) {
	return a * 2;
}

int funcAdd(int a) {
	return a + 1;
}

int funcHalf(int a) {
	return a / 2;
}

int funcSubtract(int a) {
	return a - 1;
}

int funcNothing(int a) {
	return a;
}

typedef int (*func)(int a);

int main() {
	int n;
	
	func dashFunction[100];
	scanf("%d", &n);
	dashFunction['D'] = funcDouble;
	dashFunction['A'] = funcAdd;
	dashFunction['S'] = funcSubtract;
	dashFunction['H'] = funcHalf;
	dashFunction['\n'] = funcNothing;
	char inst;
	while (scanf("%c", &inst) != EOF) {
  		n = dashFunction[inst](n);
	}
	printf("%d", n);

	return 0;
}