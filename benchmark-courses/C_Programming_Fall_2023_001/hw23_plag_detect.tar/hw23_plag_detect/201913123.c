#include <stdio.h>
int D(int);
int A(int);
int S(int);
int H(int);
typedef int (*fun)(int);
int main(){
    int n;
    char ls[1001];
    int i = 0;
    fun DASH[] = {D,A,S,H};
    char fun_ls[] =  {'D','A','S','H'};
    scanf("%d", &n);
    getchar();
    fgets(ls, 1001, stdin);

    while(ls[i] != '\n'){
        char *ptr = strchr(fun_ls, ls[i]);
        n = DASH[ptr - fun_ls](n);
        i++;
    }
    printf("%d", n);
    return 0;
}

int D(int num){return num*2;}
int A(int num){return num + 1;}
int S(int num){return num - 1;}
int H(int num){return num / 2;}
