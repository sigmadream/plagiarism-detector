#include <stdio.h>
#include <string.h>

int doubled(int x) {
    return 2 * x;
}

int add(int x) {
    return x + 1;
}

int subtract(int x) {
    return x - 1;
}

int half(int x) {
    return x / 2;
}

typedef int (*Operation)(int);

Operation input[] = {doubled, add, subtract, half};

int ops(int x, char op) {
    char operations[] = "DASH";  
    char *pos = strchr(operations, op);
   

    if (pos != NULL) {
        int index = pos - operations;
        return input[index](x);
    }

    return x;
}

int main() {
    int n;
    scanf("%d", &n);

    char input[100];  
    scanf(" %[^\n]", input);

    int i = 0;
    while (input[i] != '\0') {
        n = ops(n, input[i]);
        i++;
    }

    printf("%d\n", n);

    return 0;
}
