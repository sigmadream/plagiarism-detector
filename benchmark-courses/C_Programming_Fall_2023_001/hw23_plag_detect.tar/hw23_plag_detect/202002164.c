#include<stdio.h>
#include<string.h>

int D(int);
int A(int);
int S(int);
int H(int);


int main() {
	int num;
	char line[1001], dash[5] = {'D', 'A', 'S', 'H', '\0'};
	scanf("%d", &num);
	getchar();
	fgets(line, 1001, stdin);
	
	int list[strlen(line) - 1];
	int (*order_func[4])() = {D, A, S, H}; 
	
	int i;
	
	for (i = 0; i < strlen(line) - 1; i++) {
		list[i] = 0;
	}
	char *line_p;
	for (i = 0; i < 4; i++) {
//		printf("i��: %d\n", i);
		line_p = line;
		while (strchr(line_p, dash[i]) != NULL) {
//			printf("%d\n", strchr(line_p, dash[i]) - line);
			int pos = strchr(line_p, dash[i]) - line;
			list[pos] = i;
			line_p = strchr(line_p, dash[i]) + 1;
		}
		int j;
		for (j = 0; j < sizeof(list) / sizeof(list[0]); j++) {
//		printf("%d, ", list[j]);
		}
//		printf("\n");
	}
	for (i = 0; i < strlen(line) - 1; i++) {
		num = order_func[list[i]](num);
	}
	printf("%d", num);
	return 0;
}

int D(int n) {
	return n*2;
}

int A(int n) {
	return n + 1;
}

int S(int n) {
	return n - 1;
}

int H(int n) {
	return n / 2;
}
