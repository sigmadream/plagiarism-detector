#include <stdio.h>

int D(int a) { return a * 2; }
int A(int a) { return a + 1; }
int S(int a) { return a - 1; }
int H(int a) { return a / 2; }

typedef int (*DASH)(int);

int main()
{
    DASH dash[] = {D, A, S, H};
    int num;
    char line[100];
    char *message;
    scanf("%d%*c", &num);
    fgets(line, 100, stdin);
    message = line;

    while (*message != '\n')
    {
        while (*message == 'D')
        {
            num = dash[0](num);
            ++message;
        }
        while (*message == 'A')
        {
            num = dash[1](num);
            ++message;
        }
        while (*message == 'S')
        {
            num = dash[2](num);
            ++message;
        }
        while (*message == 'H')
        {
            num = dash[3](num);
            ++message;
        }
    }
    printf("%d\n", num);
    return 0;
}