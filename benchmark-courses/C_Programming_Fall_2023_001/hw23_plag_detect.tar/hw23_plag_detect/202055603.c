#include <stdio.h>
#include <string.h>

int D_(int n){
    return 2 * n;
}
int A_(int n){
    return n+1;
}
int S_(int n){
    return n-1;
}
int H_(int n){
    return (n/2); // - (n&1); 
}



int main(){
    int startnum;
    char line[1024];
    //int (*DASH[])(int) = {D_,A_,S_,H_,};
    
    scanf("%d", &startnum);
    scanf("%hhs", &line);
    char *p = line;
    while (*p != '\0') {
        int D, A, S, H;
        D = (*p == 'D') * D_(startnum);
        A = (*p == 'A') * A_(startnum);
        S = (*p == 'S') * S_(startnum);
        H = (*p == 'H') * H_(startnum);
        //printf("%d %d %d %d =dash\n", D,A,S,H);
        
        startnum = D+A+S+H;
        
        p++;
    }
    
    printf("%d", startnum);
    return 0;
}