#include <stdio.h>
#include <stdlib.h>

int A(int a)
{
        return a + 1;
}

int D(int a)
{
        return a * 2;
}

int H(int a)
{
        return a / 2;
}

int S(int a)
{
        return a  - 1;
}


int main()
{

    int (*fun[19])(int);

    fun[0] = A;
    fun[3] = D;
    fun[7] = H;
    fun[18] = S;

    int result;
    scanf("%d\n", &result);

    char inp[100000];

    fgets(inp,99999,stdin);

    for(char* p = inp;*(p+1);p++)
          result = fun[*p-65](result);





    printf("%d",result);


    return 0;
}
