#include <stdio.h>
#include <math.h>

int main() {

    int num;
    char dash[100]={};
    int result;

    scanf("%d", &num);
    scanf("%s", &dash);
    
    result=num;

    for (int i=0; i<100; i++) {
        if (dash[i]=='D') {
            result = result*2;
        } else if (dash[i]=='A') {
            result += 1;
        } else if (dash[i]=='S') {
            result -= 1;
        } else if (dash[i]=='H') {
            result = floor(result/2);
        }
    }  

    printf("%d", result);

    return 0;
}