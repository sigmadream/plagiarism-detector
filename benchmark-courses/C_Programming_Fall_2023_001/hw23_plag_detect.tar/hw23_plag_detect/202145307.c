#include <stdio.h>
#include <string.h>

// Function declarations for Dash operations
int D(int num);
int A(int num);
int S(int num);
int H(int num);

int main() {
    int num;
    char instructions[100];

    // Read input integer and sequence of Dash operations
    scanf("%d", &num);
    scanf("%s", instructions);

    // Pointer to functions for Dash operations
    int (*operations[4])(int) = {D, A, S, H};

    // Apply each operation in the sequence
    for (int i = 0; instructions[i] != '\0'; ++i) {
        // Find index of the operation character in "DASH" string
        char *dash = "DASH";
        int index = strchr(dash, instructions[i]) - dash;

        // Apply operation using function pointer
        num = (*operations[index])(num);
    }

    // Print the final result
    printf("%d\n", num);

    return 0;
}

// Dash operation functions
int D(int num) {
    return num * 2;
}

int A(int num) {
    return num + 1;
}

int S(int num) {
    return num - 1;
}

int H(int num) {
    return num / 2;
}
