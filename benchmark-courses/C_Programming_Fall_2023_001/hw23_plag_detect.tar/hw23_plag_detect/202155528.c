#include <stdio.h>

int customDouble(int n) {
    return n * 2;
}

int customAdd(int n) {
    return n + 1;
}

int customSubtract(int n) {
    return n - 1;
}

int customHalve(int n) {
    return n / 2;
}

typedef int (*CustomOperation)(int);

int applyCustomOperations(int n, char* instructions, CustomOperation* customOperations) {
    int result = n;
    char* p = instructions;
    while (*p) {
        switch (*p) {
        case 'D': result = customDouble(result); break;
        case 'A': result = customAdd(result); break;
        case 'S': result = customSubtract(result); break;
        case 'H': result = customHalve(result); break;
        }
        p++;
    }
    return result;
}

int main() {
    int n;
    scanf("%d", &n);

    char instructions[100];
    scanf("%s", instructions);

    CustomOperation customOperations[4] = { customDouble, customAdd, customSubtract, customHalve };

    int result = applyCustomOperations(n, instructions, customOperations);

    printf("%d\n", result);

    return 0;
}
