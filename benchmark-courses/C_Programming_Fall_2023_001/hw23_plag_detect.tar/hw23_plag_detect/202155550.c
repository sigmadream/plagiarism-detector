#include <stdio.h>

int dash_operations(int n, char *operations) {
    int i;
    for (i = 0; operations[i] != '\0'; i++) {
        switch (operations[i]) {
            case 'D':
                n *= 2;
                break;
            case 'A':
                n += 1;
                break;
            case 'S':
                n -= 1;
                break;
            case 'H':
                n = (n >= 0) ? n / 2 : -((-n) / 2);
                break;
            default:
                // Handle invalid operation
                printf("Invalid operation: %c\n", operations[i]);
                break;
        }
    }
    return n;
}

int main() {
    int n;
    char operations[100];  // Assuming a maximum of 100 operations

    // Read input
    scanf("%d", &n);
    scanf("%s", operations);

    // Apply Dash operations
    int result = dash_operations(n, operations);

    // Print the final result
    printf("%d\n", result);

    return 0;
}
