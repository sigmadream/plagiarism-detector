/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int double_up(int x) {
    return x * 2;
}

int add_one(int x) {
    return x + 1;
}

int subtract_one(int x) {
    return x - 1;
}

int half(int x) {
    return x / 2;
}

typedef int (*Operation)(int);

Operation operations[] = {double_up, add_one, subtract_one, half};

int apply_dash_operations(int start, char *instructions) {
    int result = start;
    while (*instructions != '\0') {
        switch (*instructions) {
            case 'D':
                result = operations[0](result);
                break;
            case 'A':
                result = operations[1](result);
                break;
            case 'S':
                result = operations[2](result);
                break;
            case 'H':
                result = operations[3](result);
                break;
        }
        instructions++;
    }
    return result;
}

int main() {
    int n;
    scanf("%d", &n);

    char instructions[100];
    scanf("%s", instructions);

    // Output
    printf("%d\n", apply_dash_operations(n, instructions));

    return 0;
}

