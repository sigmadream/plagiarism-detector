#include <stdio.h>
#include <string.h>
// Define 4 dash functions returning integer
int D(int d)
{
	return d * 2;
}
int A(int a)
{
	return a + 1;
}
int S(int s)
{
	return s - 1;
}
int H(int h)
{
	return h / 2;
}

int main()
{
	char arr[] = "DASH";
	int n;
	char dash[100];
	char *p;
	scanf("%d", &n);
	scanf("%s", dash);
	// printf("%d %s\n",n,dash);
	int (*fun[])(int *) = {D, A, S, H};
	for (p = dash; *p != '\0'; p++)
	{
		n = fun[strchr(arr, *p) - arr](n); // arr = &arr[0]
	}
	printf("%d", n);
	return 0;
}
