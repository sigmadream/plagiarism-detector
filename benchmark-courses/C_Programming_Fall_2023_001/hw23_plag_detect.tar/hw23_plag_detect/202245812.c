#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define Dash operations functions
int D(int n) {
    return 2 * n;
}

int A(int n) {
    return n + 1;
}

int S(int n) {
    return n - 1;
}

int H(int n) {
    return n / 2;
}

// Typedef for function pointer
typedef int (*OperationFunction)(int);

// Structure to map operation character to function
typedef struct {
    char operation_char;
    OperationFunction operation_func;
} OperationMap;

// Function to apply sequence of Dash operations
int apply_dash_operations(int starting_number, char* operations_sequence, OperationMap* operations_map, size_t map_size) {
    int result = starting_number;
    size_t length = strlen(operations_sequence);

    // Iterate over the sequence and apply operations
    for (size_t i = 0; i < length; ++i) {
        // Find the operation in the map
        for (size_t j = 0; j < map_size; ++j) {
            if (operations_sequence[i] == operations_map[j].operation_char) {
                // Call the function using the function pointer
                result = operations_map[j].operation_func(result);
                break;
            }
        }
    }

    return result;
}

int main() {
    // Read initial value
    int initial_value;
    scanf("%d", &initial_value);

    // Dynamically allocate memory for the input sequence
    char sequence[100]; // Adjust the size as needed

    // Read the sequence
    if (scanf("%s", sequence) != 1) {
        fprintf(stderr, "Error reading input sequence.\n");
        return 1;
    }

    // Array of operation maps
    OperationMap operations_map[] = {
        { 'D', D },
        { 'A', A },
        { 'S', S },
        { 'H', H }
    };

    // Apply Dash operations and print the result
    int final_result = apply_dash_operations(initial_value, sequence, operations_map, sizeof(operations_map) / sizeof(operations_map[0]));
    printf("%d\n", final_result);

    return 0;
}