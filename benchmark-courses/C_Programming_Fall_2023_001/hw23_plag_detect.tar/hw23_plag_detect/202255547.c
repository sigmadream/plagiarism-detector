#include <stdio.h>
int double_up(int x) {
    return x * 2;
}

int add_one(int x) {
    return x + 1;
}

int subtract_one(int x) {
    return x - 1;
}

int half(int x) {
    return x / 2;
}

typedef int (*DashOperation)(int);

DashOperation dash[] = {
        double_up,
        add_one,
        subtract_one,
        half
};


int main() {
    int n;
    scanf("%d", &n);

    char s[100];
    scanf("%s", &s);


    char *p = s;
    int ans = n;
    while(*p){
       if(*p == 'D'){
           ans = double_up(ans);
       } else if (*p == 'A') {
           ans = add_one(ans);
       } else if (*p == 'S') {
           ans = subtract_one(ans);
       } else {
           ans = half(ans);
       }

       p++;
    }

    printf("%d",ans);

    return 0;
}
