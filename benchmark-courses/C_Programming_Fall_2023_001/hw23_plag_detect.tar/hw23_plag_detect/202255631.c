#include <stdio.h>

int doub(int num) {
    return num * 2;
}

int add(int num) {
    return num + 1;
}

int sub(int num) {
    return num - 1;
}

int half(int num) {
    return num / 2;
}

int main() {
    int n;
    char operations[100];
    
    scanf("%d", &n);
    scanf("%s", operations);
    
    int (*dash[4])(int) = {doub, add, sub, half};
    
    for (int i = 0; operations[i] != '\0'; ++i) {
        int index;
        switch (operations[i]) {
            case 'D':
                index = 0;
                break;
            case 'A':
                index = 1;
                break;
            case 'S':
                index = 2;
                break;
            case 'H':
                index = 3;
                break;
            default:
                return 1;
        }
        n = dash[index](n);
    }
    
    printf("%d\n",n);

    return 0;
}