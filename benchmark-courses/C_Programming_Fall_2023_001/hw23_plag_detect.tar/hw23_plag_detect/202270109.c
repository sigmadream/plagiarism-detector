#include <stdio.h>

int doubleUp(int a) {
    return a * 2;
}

int addOne(int a) {
    return a + 1;
}

int subtractOne(int a) {
    return a - 1;
}

int half(int a) {
    return a / 2;
}

int main() {
    int digit;
    scanf("%d", &digit);

    char operations[100];
    scanf("%s", operations);
    

    for (char *p = operations; *p; p++) {
        switch (*p) {
            case 'D':
                digit = doubleUp(digit);
                break;
            case 'A':
                digit = addOne(digit);
                break;
            case 'S':
                digit = subtractOne(digit);
                break;
            case 'H':
                digit = half(digit);
                break;
        }
    }

    printf("%d", digit);

    return 0;
}
