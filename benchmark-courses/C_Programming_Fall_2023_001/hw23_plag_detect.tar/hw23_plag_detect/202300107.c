#include <stdio.h>
#include <string.h>
#include <ctype.h>

int doubleUp(int a) {
    return a*2;
}
int addOne(int a) {
    return a + 1;
}
int subtractOne(int a) {
    return a - 1;
}
int half(int a) {
    return a / 2;
}

int main()
{
    int num;
    char cal[50];
    scanf("%d\n", &num);//get the input number
    fgets(cal, sizeof(cal), stdin);
    char *p = cal;
    while (*p != '\0') {
        switch(*p) {
            case 'D':
                num = doubleUp(num);
                break;
            case 'A':
                num = addOne(num);
                break;
            case 'S':
                num = subtractOne(num);
                break;
            case 'H':
                num = half(num);
                break;
        }
        //printf("%c\n", *p);
        p++;
    }
    printf("%d", num);
    return 0;
}