#include <stdio.h>

int main() {
    int n, result = 0;
    char dash[50];

    scanf("%d", &n);
    scanf("%s", dash);

    result = n;

    for (int i = 0; dash[i] != '\0'; i++) {
        if (dash[i] == 'D') {
            result = result * 2;
        } else if (dash[i] == 'A') {
            result += 1;
        } else if (dash[i] == 'S') {
            result -= 1;
        } else if (dash[i] == 'H') {
            if (result < 0) {
                result = result / 2 - 0.5;
            } else if (result > 0) {
                result = result / 2 + 0.5;
            }
        }
    }

    printf("%d\n", result);

    return 0;
}

