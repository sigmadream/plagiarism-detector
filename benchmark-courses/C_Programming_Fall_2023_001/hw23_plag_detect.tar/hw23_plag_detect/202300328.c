#include <stdio.h>

int A(int a){
  return a+1;
}
int D(int a){
  return a*2;
}
int S(int a){
  return a-1;
}
int H(int a){
  return a/=2;
}

int main(){
  int a;
  char word[100];
  scanf("%d", &a);
  scanf("%s", word);

  for (int i = 0; word[i] != '\0'; i++) {
    if (word[i]=='A') {
      a=A(a);
    }
    else if (word[i]=='D') {
      a=D(a);
    }
    else if (word[i]=='S') {
      a=S(a);
    }
    else if (word[i]=='H') {
      if(a%2==1){
        a--;
        a=H(a);
      }
      else{
        a=H(a);
      }
    }
  }
printf("%d\n", a);
return 0;
}
