#include <stdio.h>
#include <string.h>  


int main() {
    int n;
    char operations[100];
    scanf("%d", &n);
    scanf("%s", operations);

    int len = strlen(operations);
    for (int i = 0; i < len; i++) {
        char op = operations[i];
        if (op == 'D') {
            n = n * 2;
        } else if (op == 'A') {
            n = n + 1;
        } else if (op == 'S') {
            n = n - 1;
        } else if (op == 'H') {
            n = n / 2;
        }
    }

    printf("%d\n", n);

    return 0;
}
