#include<stdio.h>
#include<string.h>

int doubleUp(int n){
    return n * 2;
}
int addOne(int n){
    return n + 1;
}
int subOne(int n){
    return n - 1;
}
int half(int n){
    return n / 2;
}

int main(){

    int n, sum = 0;
    char list[100];

    scanf("%d\n",&n);
    scanf("%s",list);

    
    for (int i = 0; list[i] != '\0'; i++) {
        if (list[i] == 'D'){
            sum = doubleUp(n);
            n = sum;
        }
        if (list[i] == 'A'){
            sum = addOne(n);
            n = sum;
        }
        if (list[i] == 'S'){
            sum = subOne(n);
            n = sum;
        }
        if (list[i] == 'H'){
            sum = half(n);
            n = sum;
        }
    }
    printf("%d\n",sum);

return 0;

}