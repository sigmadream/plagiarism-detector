#include <stdio.h>
#include <string.h>

int D_fun(int a) {
    int res = a *2;
    return res;
}

int A_fun(int a) {
    int res = a + 1;
    return res;

}

int S_fun(int a) {
    int res = a - 1;
    return res;

}

int H_fun(int a) {
    if((a % 2) == 0){
        int res = a / 2;
    }
    else{
        if(a<0){
            int res = (a/2)-0.5;
            return res;
        }
        else{
        int res = (a/2)+0.5;
        return res;
        }
    }
}


int main() {
    int n;
    char str[100];

    scanf("%d", &n);

    scanf(" %[^\n]s", str);

    for(int i = 0; i<strlen(str);i++){
        if(str[i] == 'D'){
          n = D_fun(n);
        }
        else if(str[i] == 'A'){
            n = A_fun(n);
        }
        else if(str[i] == 'S'){
          n = S_fun(n);

        }
        else if(str[i] == 'H'){
          n = H_fun(n);
        }
    }

    printf("%d", n);

    return 0;
}
