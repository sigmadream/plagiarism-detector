#include <stdio.h>

int doubleUp(int n) { //D
    return n * 2;
}

int addOne(int n) { //A
    return n + 1;
}

int subtractOne(int n) { //S
    return n - 1;
}

int half(int n) { //H
    return n / 2;
}

int main() {
    int n;
    char instructions[100]; //we create an array for storage assuming that the max is 100 characters
    scanf("%d", &n);
    scanf("%s", instructions);

    //array of function pointers
    int (*dashOperations[4])(int) = {doubleUp, addOne, subtractOne, half};
    for (int i = 0; instructions[i] != '\0'; i++) { //read instructions
        //make instruction character correspond to an index in the array of fptrs
        int index = (instructions[i] == 'D') ? 0 :
                    (instructions[i] == 'A') ? 1 :
                    (instructions[i] == 'S') ? 2 :
                    (instructions[i] == 'H') ? 3 : -1;
        if (index >= 0) {
            n = dashOperations[index](n);
        }

    }



    printf("%d\n", n);
    return 0;
}
