#include<stdio.h>
#include<string.h>

int D(int x) {
    return 2 * x;
}

int A(int x) {
    return x + 1;
}

int S(int x) {
    return x - 1;
}

int H(int x) {
    return x / 2;
}

int main() {
    int n;
    scanf("%d", &n);

    char instructions[100];
    scanf("%s", instructions);
    int (*dash_operations[4])(int) = {D, A, S, H};

    for (char *p = instructions; *p; p++) {
        int index = strchr("DASH", *p) - "DASH";
        n = dash_operations[index](n);
    }

    printf("%d\n", n);

    return 0;
}
