//
//  main.c
//  HW9
//
//  Created by Sandoval Reyes Luis Armando on 2023/11/18.
//

#include <stdio.h>

void DoubleUp(int *a){
    *a = 2*(*a);
}

void AddOne(int *a){
    *a = (*a)+1;
}

void SubstractOne(int *a){
    *a = (*a)-1;
}

void Half(int *a){
    *a = (*a)/2;
}

int main(int argc, const char * argv[]) {
    int integer = 0;
    scanf("%d", &integer);
    
    char instructions[200];
    scanf("%s", instructions);
    
    for(char *p = instructions; *p; p++){
        switch(*p){
            case('D'):
                DoubleUp(&integer);
                break;
            case('A'):
                AddOne(&integer);
                break;
            case('S'):
                SubstractOne(&integer);
                break;
            case('H'):
                Half(&integer);
                break;
            
        }
    }
    
    printf("%d", integer);
    
    return 0;
}
