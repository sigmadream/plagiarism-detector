#include <stdio.h>
#include <string.h>

int double_up(int n){
    return n * 2;
}

int add_one(int n){
    return n + 1;
}

int subtract_one(int n){
    return n - 1;
}

int half(int n){
    return n / 2;
}

int main(){
    int(*dash[])(int) = {double_up, add_one, subtract_one, half};

    int n;
    scanf("%d", &n);

    char dash_seq[100];
    scanf("%s", &dash_seq);

    int result = n;


     for (int i = 0; dash_seq[i] != '\0'; i++) {
        char operation = dash_seq[i];
        int index = strchr("DASH", operation) - "DASH";

        result = dash[index](result);
    }


    printf("%d", result);

    return 0;
}
