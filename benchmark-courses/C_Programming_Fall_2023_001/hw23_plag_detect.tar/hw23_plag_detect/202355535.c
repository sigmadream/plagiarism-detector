#include <stdio.h>
#include <string.h>

int multiplyByTwo(int n);
int addOne(int n);
int subtractOne(int n);
int divideByTwo(int n);

int main() {
    int n;
    int i = 0;
    char dash[100];
    
    scanf("%d", &n);
    scanf("%s", dash);

    int (*operation[4])(int) = {multiplyByTwo, addOne, subtractOne, divideByTwo};
    char validOperations[] = {'D', 'A', 'S', 'H'};

    int result = n;

    for (i = 0; i < strlen(dash); i++) {
        char operationCode = dash[i];
        int index = -1;
        for (int j = 0; j < sizeof(validOperations) / sizeof(validOperations[0]); j++) {
            if (operationCode == validOperations[j]) {
                index = j;
                break;
            }
        }
        result = operation[index](result);
    }

    printf("%d\n", result);
    return 0;
}

int multiplyByTwo(int n) {
    return n * 2;
}

int addOne(int n) {
    return n + 1;
}

int subtractOne(int n) {
    return n - 1;
}

int divideByTwo(int n) {
    return n / 2;
}
