#include <stdio.h>

int D(int n) {
    return n * 2;
}

int A(int n) {
    return n + 1;
}

int S(int n) {
    return n-1;
}

int H(int n) {
    return n / 2;
}

int DASH(char ins, int n) {
    int result;
    typedef int (*operation) (int) ;
    operation op[256] = {NULL};

    op['D'] = D;
    op['A'] = A;
    op['S'] = S;
    op['H'] = H;
    result = op[ins](n);

    return result;
}

int main() {
    int num;
    char input[100];

    scanf("%d", &num);
    scanf("%s", &input);

    int result = num;
    for(int i = 0; input[i] != '\0' ; i++) {
        result = DASH(input[i],result);
    }

    printf("%d", result);

    return 0;

}
