#include <stdio.h>

int double_up(int n) {
    return n * 2;
}

int add_one(int n) {
    return n + 1;
}

int subtract_one(int n) {
    return n - 1;
}

int half(int n) {
    return n / 2;
}

typedef int (*Operation)(int);

Operation get_operation(char op) {
    switch (op) {
        case 'D':
            return double_up;
        case 'A':
            return add_one;
        case 'S':
            return subtract_one;
        case 'H':
            return half;
        default:
            return NULL;
    }
}

int apply_operations(int starting_number, char *operations_sequence) {
    int result = starting_number;
    while (*operations_sequence != '\0') {
        Operation op = get_operation(*operations_sequence);
        if (op != NULL) {
            result = op(result);
        }
        operations_sequence++;
    }
    return result;
}

int main() {
    int starting_number;
    char operations_sequence[100];

    scanf("%d", &starting_number);
    scanf("%s", operations_sequence);

    int result = apply_operations(starting_number, operations_sequence);
    printf("%d\n", result);

    return 0;
}
