#include <stdio.h>
#include <string.h>
int D(int x){
    return 2*x;
}
int A(int x){
    return 1+x;
}
int S(int x){
    return x-1;
}
int H(int x){
    return x/2;
}
int main(){
    int n;
    char line[1000];
    scanf("%d", &n);
    scanf("%s", &line);
    typedef int (*fun)(int x);
    fun a[1000];
    a['D'] = D;
    a['A'] = A;
    a['S'] = S;
    a['H'] = H;
    for(int i = 0; i<strlen(line); i++){
        n = a[line[i]](n);
    }
    printf("%d", n);
    return 0;
}