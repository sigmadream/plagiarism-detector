#include <stdio.h>
#include <string.h>

int DoubleUp (int a);
int AddOne (int a);
int SubtractOne (int a);
int Half(int a);

int main() {

    int n;
    const int MAX_WORDS = 30;
    char line[MAX_WORDS], dash[] = "DASH";
    int (*fun[])(int a) = {DoubleUp, AddOne, SubtractOne, Half};

    scanf("%d", &n);
    while (getchar() != '\n');
    fgets(line, MAX_WORDS, stdin);

    for (char *p = line; *p; p++) {
        char *found = strchr(dash, *p);
        if (found != NULL) {
            int i = found - dash;
            n = fun[i](n);
        }
    }
    printf("%d", n);

    return 0;
}

int DoubleUp (int a) {
    return a * 2;
}

int AddOne (int a) {
    return a + 1;
}

int SubtractOne (int a) {
    return a - 1;
}

int Half (int a) {
    return a/2;
}
