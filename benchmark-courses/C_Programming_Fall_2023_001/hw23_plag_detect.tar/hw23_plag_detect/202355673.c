#include <stdio.h>

int main() {
    int n;
    int a = 0;
    char letter[100];

    scanf("%d\n", &n);

    while (scanf("%c", &letter[a]) == 1) {
        a++;
    }

    for (int i = 0; i < a; i++) {
        if (letter[i] == 'D') {
            n = n * 2;
        } else if (letter[i] == 'A') {
            n = n + 1;
        } else if (letter[i] == 'S') {
            n = n - 1;
        } else if (letter[i] == 'H') {
            n = n / 2;
        }
    }

    printf("%d", n);

    return 0;
}
