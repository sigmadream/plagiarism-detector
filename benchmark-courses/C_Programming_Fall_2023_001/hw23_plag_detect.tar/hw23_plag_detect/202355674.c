#include <stdio.h>

int dash_op(int n, char *line){

    int i=0;
    do{
        n *= (line[i] == 'D') ? 2 : 1;
        n += (line[i] == 'A') ? 1 : 0;
        n -= (line[i] == 'S') ? 1 : 0;
        n /= (line[i] == 'H') ? 2 : 1;
        i++;
        } while (line[i]!= '\0');
    return n;
}


int main()
{
    int n;
    char line[100];
    scanf("%d", &n);
    scanf("%s", line);

    printf("%d", dash_op( n, line));

    return 0;
}
