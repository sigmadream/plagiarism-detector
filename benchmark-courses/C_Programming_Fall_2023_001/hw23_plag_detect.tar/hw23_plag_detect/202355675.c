#include <stdio.h>
int D(int a){
    return a * 2;
}
int A(int a){

    return a + 1;
}
int S(int a){
    return a - 1;
}
int H(int a){
    return a / 2;
}
int main() {
    int (*p[4])() = {D, A, S, H};
    int a;
    char f[1000];
    int i = 0;

    scanf("%d", &a);
    while(scanf("%c", &f[i]) == 1){
        i++;
    }
    for (int u = 0; f[u] != '\0'; u++) {
        if (f[u] == 'D') {
            a = p[0](a);
        } else if (f[u] == 'A') {
            a = p[1](a);
        } else if (f[u] == 'S') {
            a = p[2](a);
        } else if (f[u] == 'H') {
            a = p[3](a);
        }
    }


    printf("%d", a);

    return 0;
}

