#include <stdio.h>
#include <string.h>

int main() {
    int num;
    scanf("%d", &num);
    char str[1000];
    scanf("%s", &str);

    for(int i = 0; i < strlen(str); i++){
        switch(str[i]){
            case 'D':
                num *= 2;
                break;
            case 'A':
                num += 1;
                break;
            case 'S':
                num -= 1;
                break;
            case 'H':
                num /= 2;
                break;
        }
    }
    printf("%d", num);

    return 0;
}

