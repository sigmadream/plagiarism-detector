#include <stdio.h>

int double_up(int integer, int sz)
{
    return integer * 2;
}

int add(int integer, int sz)
{
    return integer + 1;
}

int subtract(int integer, int sz)
{
    return integer - 1;
}

int half(int integer, int sz)
{
    return integer / 2;
}

int main()
{
    int integer;
    int res = 0;
    char dash[1000];
    scanf("%d\n", &integer);

    int i = 0;
    fgets(dash, 1000, stdin);

    int (*f[4])(int, int) = {double_up, add, subtract, half};
    char operations[] = {'D', 'A', 'S', 'H'};

    for (i = 0; dash[i] != '\0'; i++)
    {
        char c = dash[i];
        int index = -1;

        for (int j = 0; j < 4; j++)
        {
            if (c == operations[j])
            {
                index = j;
                break;
            }
        }

        if (index != -1)
        {
            res = f[index](integer, i);
            integer = res;
        }
    }

    printf("%d", res);

    return 0;
}
