
#include <stdio.h>

int D(int n);
int A(int n);
int S(int n);
int H(int n);

int (*int_operations[4])(int) = {D, A, S, H};

int main() {
    int n;
    char dash_instructions[100];

    scanf("%d", &n);
    scanf("%s", dash_instructions);

   for (int i = 0; dash_instructions[i] != '\0'; i++) {
    int operation = (dash_instructions[i] == 'D') * 0
                + (dash_instructions[i] == 'A') * 1
                + (dash_instructions[i] == 'S') * 2
                + (dash_instructions[i] == 'H') * 3;

    n = (operation >= 0 && operation < 4) ? int_operations[operation](n) : n;
}


    printf("%d\n", n);

    return 0;
}


int D(int n) {
    return n * 2;
}

int A(int n) {
    return n + 1;
}

int S(int n) {
    return n - 1;
}

int H(int n) {
    return n / 2 + ((n % 2 == 1) & (n < 0));
}
