#include <stdio.h>

int main() {
    int n, i, firstNumber, sum = 0;
    scanf("%d", &n);
    scanf("%d", &firstNumber);

    if (firstNumber % 2 == 0) { 
        for (i = 1; i < n; i++) {
            int number;
            scanf("%d", &number);
            sum ^= number;
        }
    } else { 
        for (i = 1; i < n; i++) {
            int number;
            scanf("%d", &number);
            sum += number;
        }
    }

    printf("%d\n", sum);
    return 0;
}