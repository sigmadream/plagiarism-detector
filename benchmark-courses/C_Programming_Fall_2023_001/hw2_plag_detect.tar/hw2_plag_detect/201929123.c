#include <stdio.h>


int main(){

    int n = 0;

    int rs = scanf("%d",&n);

    if (rs == 1){
        if (n > 0)
            printf("%+d\n",n+1);
        else if (n == 0)
            printf("%+d\n",n);
        else
            printf("%-d\n",n-1);
    }else
        puts("Try again");



    return 0;
}
