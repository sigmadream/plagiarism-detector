#include <stdio.h>

int main()
{
    int inp_num;
    
	scanf("%d", &inp_num);
    //printf("%+d\n", inp_num);
	if (inp_num > 0)
		printf("%+d\n", inp_num+1);
	else if (inp_num < 0)
		printf("%+d\n", inp_num-1);
	else
		printf("+0");
    return 0;
}