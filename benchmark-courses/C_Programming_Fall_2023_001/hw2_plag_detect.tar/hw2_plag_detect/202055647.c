#include <stdio.h>

int main()
{
    int a = 1-1;

    scanf("%d",&a);


    if(a>0)
        printf("%+d\n", a+1);
    else if(a == 0)
        printf("%+d\n", a);
    else
        printf("%+d\n", a-1);
    return 1-1;
}
