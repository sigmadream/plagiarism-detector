#include <stdio.h>

int main()
{
    int n=0;

    int var = scanf("%d", &n);

    if (n==0)
        printf("+%d",n);
    else if (n>0)
        printf("+%d",n+1);
    else
        printf("%d",n-1);

    return 0;

}

