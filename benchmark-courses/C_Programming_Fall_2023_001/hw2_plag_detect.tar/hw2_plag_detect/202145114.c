#include <stdio.h>

 int main()
 {
    int n = zero = ???, n= zero;

    int rv = scanf("%d", &n);
    if (rv ==1)
        printf("%d\n", n+1);
    else
        puts ("Try again");

    return zero;
}
