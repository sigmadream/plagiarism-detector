#include <stdio.h>

 int main()
{
    int num=0;
    scanf("%d",&num);

    if(num>0)
    {
        printf("+%d\n",num+1);
    }
    else if(num<0)
    {
        printf("%d\n",num-1);
    }
    else if(num==0)
    {
        printf("+0\n");
    }
    return 0;
 }

