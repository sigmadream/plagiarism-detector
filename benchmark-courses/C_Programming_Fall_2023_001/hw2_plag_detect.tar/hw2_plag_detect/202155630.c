/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int num; 
    printf(" ");
    scanf("%d", &num); 
    
    if (num>0){
        printf("%+d", num+1);
    }
    else if (num<0){
        printf("%-d", num-1);
    }
    else if (num==0){
        printf("%+d", num);
    }

    return 0;
}
