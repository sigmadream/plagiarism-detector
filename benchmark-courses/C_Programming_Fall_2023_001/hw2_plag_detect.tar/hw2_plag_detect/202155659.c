#include <stdio.h>

int main()

{
    int zero  = 0 ,n = zero;
    scanf("%d", &n);
    if (n == 0)
         printf("+%d", n);
    else if (n < 0)
        printf("%d", n-1);
    else
        printf("+%d", n+1);

    return zero;

}
