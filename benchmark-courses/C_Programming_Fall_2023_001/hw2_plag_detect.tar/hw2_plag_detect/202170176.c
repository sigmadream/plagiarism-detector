#include <stdio.h>

int main()
{
    int a;
    float b;
    char c;
    char d[10];

    scanf("%d",&a);

    if(a>0)
    {
        printf("+%d",a+1);

    }
    else if (a<0)
    {
        printf("%d",a-1);
    }

    else
    {
        printf("+%d",a);
    }
    return 0;
}
