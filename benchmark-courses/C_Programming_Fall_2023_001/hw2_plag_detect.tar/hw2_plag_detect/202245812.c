#include <stdio.h>
int main()
{
    int n = 0;
    scanf("%d", &n);
    if( n < 0){
        n -= 1;
        printf("%-d\n",n);
    }else if ( n > 0 ){
        n += 1;
        printf("%+d\n", n);
    }else{
        printf("%+d\n", n);
    }


    return 0;
}
