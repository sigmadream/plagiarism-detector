#include <stdio.h>

int main()
{
    int i = 0;

    scanf("%d", &i);
     
    if(i == 0){
    }
    else if(i<0){
        i -= 1;
    }
    else{
        i += 1;
    }

    printf("%+d\n", i);
}