#include <stdio.h>

int main()
{
    int n = 0;
    
    scanf("%d", &n);
    n = n > 0? n + 1: n < 0? n - 1: n;
    printf("%+d\n", n);

    return 0;
}

