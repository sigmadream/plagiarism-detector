#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    if (n > 0) {
        printf("+%d\n", n + 1);
    } else if (n < 0) {
        printf("%d\n", n - 1);
    } else {
        printf("+%d\n", n); // +0 for zero
    }

    return 0;
}
