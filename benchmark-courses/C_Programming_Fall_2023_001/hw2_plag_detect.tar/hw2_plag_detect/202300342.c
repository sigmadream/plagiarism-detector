//Homework 1 - Programming principles and practice
#include <stdio.h>

int main()
{
    //initialization of the n variable:

    int n;
    printf("input the number n: ");
    scanf("%d", &n); //note: I'm sending this 2nd version of the code with scanf since the function doesn't make any errors in CodeBlocks, unlike in Microsoft Visual Studio. Although in the first version I sent, I tried to use scanf directly like in the Lab1 example, but microsoft visual studio tells me scanf is "unsafe" and to replace it with scanf_s and doesn't allow execution unless I do so...I don't understand why it won't allow me to use the regular function we saw in class?

    //iterations depending on the sign of n:

    if (n > 0)
        printf("%+d\n", n+1);
    else if (n < 0)
        printf("%+d\n", n-1);
    else if (n==0)
        printf("%+d\n", 0);

    return 0;
}
