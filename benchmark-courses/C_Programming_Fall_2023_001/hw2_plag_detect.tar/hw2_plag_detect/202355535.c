#include <stdio.h>

int main()
{
    int num = 0;
    int n = scanf("%d", &num);

    if (num == 0) {
        puts("+0");
    }

    else if(n == 1) {
        if(num > 0) {
            printf("%+d\n", num + 1);
        }
        else {
            printf("%+d\n", num - 1);
            }
    }

    return 0;
}
