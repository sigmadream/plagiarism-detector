#include <stdio.h>

int main()
{
    int n = 0;

    scanf("%d", &n);
    if(n >= 0) // 0 or positive
        if(n != 0) // ���
            printf("+%d\n", n+1);
        else // 0
            printf("+%d\n", n);
    else // negative
        printf("%d\n", n-1);

    return 0;

}
