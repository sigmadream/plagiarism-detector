#include <stdio.h>

int main()
{
    int n = 0;
    int rv = scanf("%d", &n);
    if(rv == 1)
        if(n>0)
            printf("%+d", n + 1);
        else if(n<0)
            printf("%+d", n - 1);
        else
            printf("%+d", n);
    else
        puts("NaN");

    return 0;
}
