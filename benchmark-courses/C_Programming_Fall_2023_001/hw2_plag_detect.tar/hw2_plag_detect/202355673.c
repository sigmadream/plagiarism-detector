#include <stdio.h>

int main()
 {
    int n;

    scanf("%d", &n);

    int m;
    if (n > 0) {
        m = n + 1;
    } else if (n < 0) {
        m = n - 1;
    } else {
        m = 0;
    }

    printf("%+d\n", m);

    return 0;
}
