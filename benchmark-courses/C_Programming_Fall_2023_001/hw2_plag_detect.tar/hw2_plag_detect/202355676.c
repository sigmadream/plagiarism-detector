#include <stdio.h> 

int main()
{
    int numb = 0;
    int rv = scanf("%d", &numb);    
    if(rv == 1){
        if(numb > 0){
            numb += 1;
            printf("%+d\n", numb);
        }
        else if(numb < 0){
            numb -= 1;
            printf("%+d\n", numb);
        }
        else{
            printf("%+d\n", numb);
        }
    }
    else{
        puts("NaN");
    }
    
    return 0;
}   