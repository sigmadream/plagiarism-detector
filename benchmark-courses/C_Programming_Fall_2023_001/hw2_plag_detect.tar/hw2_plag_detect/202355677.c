#include <stdio.h>

 int main()
 {
 int n = 0;
 int rv = scanf("%d", &n);

    if (n>0)
        printf("%+d\n", n+1);
    else if (n<0)
        printf("%-d\n", n-1);
    else if (n==0)
        printf("%+d\n", n);


 return 0;
 }
