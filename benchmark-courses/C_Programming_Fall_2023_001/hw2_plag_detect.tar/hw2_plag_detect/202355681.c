#include <stdio.h>

int main() {
    int n;


    printf("Enter an integer: ");
    scanf("%d", &n);


    if (n > 0) {
        printf("%d\n", n + 1);
    } else if (n < 0) {
        printf("%d\n", n - 1);
    } else {

        printf("+0\n");
    }

    return 0;
}
