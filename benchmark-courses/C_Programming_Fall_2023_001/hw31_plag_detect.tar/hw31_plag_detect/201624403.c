#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int bitNum = 0;
	while (n) {
		if (n & 1) {
			printf("%d\n", bitNum);
		}
		n >>= 1;
		bitNum++;
	}
	return 0;
}