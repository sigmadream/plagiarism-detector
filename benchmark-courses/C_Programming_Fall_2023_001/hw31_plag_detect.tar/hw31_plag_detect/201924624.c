#include <stdio.h>

void printPowersOf2Rec(int n, int position) {
    if (n == 0) {
        return;
    }

    if (n & 1) {
        printf("%d\n", position);
    }

    printPowersOf2Rec(n >> 1, position + 1);
}

void printPowersOf2(int n) {
    printPowersOf2Rec(n, 0);
} 


int main() {
    
    int a;
    scanf("%u",&a);

    printPowersOf2(a);

    return 0;

}