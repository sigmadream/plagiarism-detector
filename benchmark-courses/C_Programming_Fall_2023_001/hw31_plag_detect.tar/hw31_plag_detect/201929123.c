
#include <stdio.h>

void print_bitset(int n, int i) {
    if (i <= 31) {
        if (n & (1 << i)) {
            printf("%d\n", i);
        }
        print_bitset(n, i + 1);
    }
}

int main() {
    int n;

    // Read a positive integer from the user
    scanf("%d", &n);

    // Call the print_bitset function
    print_bitset(n, 0);

    return 0;
}
