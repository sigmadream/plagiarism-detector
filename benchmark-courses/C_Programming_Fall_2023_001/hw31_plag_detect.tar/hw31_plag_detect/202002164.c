#include<stdio.h>

int main() {
	unsigned int n;
	scanf("%d", &n);
	int digit = 0, i = 0;
	int set[32];
	while (n > 0) {
		if (n & 1 == 1) {
			set[i++] = digit;
		}
		digit++;
		n >>= 1;
	}
	printf("%d", set[0]);
	int j;
	for (j = 1; j < i; j++) {
		printf("\n%d", set[j]);
	}
}
