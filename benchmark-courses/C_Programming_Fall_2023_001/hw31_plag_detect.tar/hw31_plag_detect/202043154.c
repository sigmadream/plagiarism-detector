#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int how_many_divide_by_2(int num) {
    return num >> 1 == 0 ?  0 : 1 + how_many_divide_by_2(num >> 1);
}

void makeBitset(int num, int *bitset, int *index) {
    int bitset_element = 0;
    num >> 1 == 0 ? (num == 1 ? bitset[(*index)++] = 0 : 0) : (
        bitset_element = 1 + how_many_divide_by_2(num >> 1),
        bitset[(*index)++] = bitset_element,
        makeBitset(num - (2 << bitset_element-1), bitset, index)
    );
}

int compare(const void *a, const void *b) {
    return *(int *)a - *(int *)b;
}

void print(int *bitset, int index) {
    index == 0 ? 0 : (
        printf("%d\n", bitset[0]),
        print(bitset + 1, index - 1)
    );
}

int main() 
{
    int num;
    scanf("%d", &num);
    int bitset[100] = {0, };
    int index = 0;
    makeBitset(num, bitset, &index);
    qsort(bitset, index, sizeof(int), compare);
    print(bitset, index);
    return 0;
}