#include <stdio.h>


int readbyte(int num, int index){
	num = num >> index;
	(num & 1)?  printf("%d\n", index) : 0;
}


int main(){
	int n;
	scanf("%d", &n);
	readbyte(n, 0);
	readbyte(n, 1);
	readbyte(n, 2);
	readbyte(n, 3);
	readbyte(n, 4);
	readbyte(n, 5);
	readbyte(n, 6);
	readbyte(n, 7);
	readbyte(n, 8);
	readbyte(n, 9);
	readbyte(n, 10);
	readbyte(n, 11);
	readbyte(n, 12);
	readbyte(n, 13);
	readbyte(n, 14);
	readbyte(n, 15);
	readbyte(n, 16);
	readbyte(n, 17);
	readbyte(n, 18);
	readbyte(n, 19);
	readbyte(n, 20);
	readbyte(n, 21);
	
	
	return 0;
}
