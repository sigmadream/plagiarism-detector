#include <stdio.h>
#include <stdlib.h>


int main()
{
    unsigned int inp;

    scanf("%d",&inp);

    for(int i = 0; i<32;i++)
        if((inp>>i) & 1)
            printf("%d\n",i);

    return 0;
}
