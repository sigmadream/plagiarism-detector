#include <stdio.h>

int main() {
    int num;

    scanf("%d", &num);

    int binary[20];
    int index=0;
    int j=0;
    int result[20];

    while (num>0) {
        binary[index]=num%2;
        num=num/2;
        index++;
    }

    // 역순으로 이진수값을 배열에 저장
    for (int i=index-1; i>=0; i--) {
        result[j]=binary[i];
        j++;
    }

    for (int i=0; i<index; i++) {
        if(binary[i] != 0) {
            printf("%d\n", i);
        }
    }

    return 0;
}