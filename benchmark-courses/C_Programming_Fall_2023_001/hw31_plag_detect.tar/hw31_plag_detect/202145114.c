#include <stdio.h>

void print_bitset(unsigned int n, int index) {
    if (index < sizeof(unsigned int) * 8) {
        if (n & (1 << index)) {
            printf("%d\n", index);
        }
        print_bitset(n, index + 1);
    }
}

int main() {
    unsigned int n;
    scanf("%u", &n);
    print_bitset(n, 0);
    return 0;
}
