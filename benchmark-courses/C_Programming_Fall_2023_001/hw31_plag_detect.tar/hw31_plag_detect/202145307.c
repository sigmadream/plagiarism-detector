#include <stdio.h>

void printBitset(int n) {
    if (n > 0) {
        int i = 0;
        while (n) {
            if (n & 1) {
                printf("%d\n", i);
            }
            i++;
            n >>= 1;
        }
    }
}

int main() {
    int n;
    scanf("%d", &n);
    printBitset(n);
    return 0;
}

