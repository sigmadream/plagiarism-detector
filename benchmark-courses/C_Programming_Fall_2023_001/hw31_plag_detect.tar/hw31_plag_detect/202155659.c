#include <stdio.h>

void B(int n, int i) {
    if (n & 1) {
        printf("%d\n", i);
    }

    if (n > 0) {
        B(n >> 1, i + 1);
    }
}

int main() {
    int n;
    scanf("%d", &n);
    B(n, 0);
    return 0;
}

