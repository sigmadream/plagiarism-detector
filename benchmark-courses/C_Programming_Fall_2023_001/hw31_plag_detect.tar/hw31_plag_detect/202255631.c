#include <stdio.h>

void bitset(int num, int index) {
    if (index >= 0) {
        bitset(num, index - 1);
        if (num & (1 << index))
            printf("%d\n", index);
    }
}

int main() {
    int n;
    scanf("%d", &n);

    bitset(n, 31); 

    return 0;
}