#include <stdio.h>

void bitwise(int n) {
    for (int i = 0; i < 32; i++) {
        int bit = (n >> i) & 1;
        if (bit == 1) {
            printf("%d\n", i);
        }
    }
}
int main () {
    int n;
    scanf("%d", &n);

    bitwise(n);

    return 0;
}