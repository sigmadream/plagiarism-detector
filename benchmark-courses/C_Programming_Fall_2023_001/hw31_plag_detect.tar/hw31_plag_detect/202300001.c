#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
    int num;
    char arr[33];

    scanf("%d", &num);

    sprintf(arr, "%s", itoa(num, arr, 2)); // _itoa는 Microsoft 확장 함수

    //printf("%s\n\n", arr);

    //printf("정답\n");
    for(int i=strlen(arr)-1; i>=0; i--){
        //printf("arr[%d]=%c\n", i, arr[i]);
        
        if(arr[i] == '1'){
            printf("%d\n", strlen(arr)-1-i);
        }
    }
    
    return 0;
}
