#include <stdio.h>
#include <string.h>

int main()
{
    int num;
    scanf("%d", &num);
    int count = 0;
    while (num > 0) {
        if (num%2 != 0) {
            printf("%d\n", count);
            count += 1;
        }else{
            count += 1;
        }
        num = num / 2;
    }
    
    return 0;
}