#include <stdio.h>

void print_bit(int n, int i) {
    int bit = (n >> i) & 1;
    if (bit) {
        printf("%d\n", i);
    }
}

void print_bitset_recursive(int n, int i) {
    if (i >= 0) {
        print_bitset_recursive(n, i - 1);
        print_bit(n, i);
    }
}

void print_bitset(int n) {
    print_bitset_recursive(n, 31);
}

int main() {
    int n;
    scanf("%d", &n);

    if (n <= 0) {
        return 1;
    }

    print_bitset(n);

    return 0;
}
