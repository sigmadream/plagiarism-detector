#include <stdio.h>

void Bitset(int n) {
    int index = 0;
    while (n > 0) {
        if (n % 2 == 1) {
            printf("%d\n", index);
        }
        n /= 2;
        index++;
    }
}

int main() {

    int n;
    scanf("%d", &n);

    if (n <= 0) {
    } else {
        Bitset(n);
    }

    return 0;
}
