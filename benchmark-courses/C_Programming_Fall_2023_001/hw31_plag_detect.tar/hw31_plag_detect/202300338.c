#include <stdio.h>

void calculate_bitset(int n) {
    int bit_position = 0;

    while (n > 0) {
        if (n & 1) {
            printf("%d\n", bit_position);
        }
        n >>= 1;
        bit_position++;
    }
}

int main() {
    int n;
    scanf("%d", &n);

    if (n <= 0) {
        return 1;
    }

    calculate_bitset(n);
    return 0;
}

