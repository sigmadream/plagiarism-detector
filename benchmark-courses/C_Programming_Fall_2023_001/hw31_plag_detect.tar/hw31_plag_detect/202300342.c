#include <stdio.h>

void printBitset(int n, int i) {
    if (i < 0) {
        return;
    }

    printBitset(n, i - 1);

    if ((n & (1 << i)) != 0) {
        printf("%d\n", i);
    }
}

int main() {
    int n;
    scanf("%d", &n);

    if (n <= 0) {
        return 1;  // Exit with an error code
    }

    //print in increasing order
    printBitset(n, sizeof(int) * 8 - 1);

    return 0;
}

