#include <stdio.h>

void swap(int *a, int *b) {
    *a ^= *b, *b ^= *a, *a ^= *b;
}

void printBitsetRecursive(int n, int i) {
    (n > 0) ? ((n & 1) && printf("%d\n", i), printBitsetRecursive(n >> 1, i + 1)) : (void)1;
}

void printBitset(int n) {
    printBitsetRecursive(n, 0);
}

int main() {
    int n;
    printf("");
    scanf("%d", &n);

    (n <= 0) ? printf("\n") : (void)1;

    int a = n >> 1, b = n << 1;
    printBitset(n);

    return 0;
}
