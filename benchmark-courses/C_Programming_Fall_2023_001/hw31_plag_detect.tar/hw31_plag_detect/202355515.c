#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int pos = 0;

    while (n > 0) {
        if (n & 1) {
            printf("%d\n", pos);
        }
        n >>= 1;
        pos++;
    }
    return 0;
}
