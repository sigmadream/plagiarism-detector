#include <stdio.h>

void printBitset(int n) {
    int i;
    for (i = 0; i < sizeof(int) * 8; ++i) {
        if (n & (1 << i)) {
            printf("%d\n", i);
        }
    }
}

int main() {
    int n;
    scanf("%d", &n);
    printBitset(n);
    return 0;
}
