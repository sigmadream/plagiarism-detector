#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int bit = 0;
    while (n > 0) {
        if (n & 1) {
            printf("%d\n", bit);
        }
        n >>= 1;
        bit++;
    }

    return 0;
}
