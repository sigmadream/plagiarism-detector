#include <stdio.h>

void printBitset(int n, int bit) {
    if (bit >= 0) {
        if ((n & (1 << bit)) != 0) {
            printf("%d\n", bit);
        }
        printBitset(n, bit - 1);
    }
}

int main() {
    int n;
    scanf("%d", &n);
    printf("%d\n", n);
    printBitset(n, 31);
    return 0;
}
