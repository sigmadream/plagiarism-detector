#include <stdio.h>
void ans(int i, int n){
    if(n != 0){
        if(n >> 1 != (n+1)>>1){
            printf("%d\n", i);
        }
        ans(i+1, n>>1);
    }
}
int main(){
    int n;
    scanf("%d", &n);
    ans(0, n);

}
