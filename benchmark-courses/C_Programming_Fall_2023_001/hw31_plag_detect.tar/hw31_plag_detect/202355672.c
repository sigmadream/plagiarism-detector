#include <stdio.h>

void PrintBitset(int n, int i) {

    if (n & 1)
        printf("%d\n", i);
    i++;
    n>>= 1;

    if (n > 0)
        PrintBitset(n, i);
}


int main() {

    int n;

    scanf("%d", &n);

    PrintBitset(n, 0);

    return 0;
}
