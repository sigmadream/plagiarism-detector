#include <stdio.h>

void print_bitset(int n, int i) {
    if (n>0) {
        if (n&1) {
            if (i>0) {
                printf("%d\n",i);}
                 else {
                printf("0\n");}}
        print_bitset(n>>1, i+1);}}
int main() {
    int a;
    scanf("%d",&a);    
    print_bitset(a,0);    
    return 0;
}
