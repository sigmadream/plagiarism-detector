#include <stdio.h>

void print_bit(int n, int bit) {
    if (bit > 31) {
        return;
    }

    n & (1 << bit) && printf("%d\n", bit);

    print_bit(n, bit + 1);
}

void print(int n) {
    print_bit(n, 0);
}

int main() {
    int n;
    scanf("%d", &n);
    print(n);
    return 0;
}
