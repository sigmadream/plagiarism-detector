
#include <stdio.h>

void bitset(int n, int i)
{ if ( n > 0)
{
    n & 1 && printf("%d\n", i);
    n >>= 1;
    bitset(n, i + 1);
}
}



int main()
{
    int n;


    scanf("%d", &n);

    bitset(n,0);

    return 0;
}
