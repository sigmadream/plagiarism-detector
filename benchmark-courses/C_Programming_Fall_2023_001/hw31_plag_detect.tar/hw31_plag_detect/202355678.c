#include <stdio.h>

void bit_positions(int n, int bit_position)
{
    (bit_position >= 0) && (
        bit_positions(n, bit_position - 1),
        (n >> bit_position) & 1 && printf("%d\n", bit_position)
    );
}

int main()
{
    int n;

    printf("");
    scanf("%d", &n);

    bit_positions(n, 31);

    return 0;
}
