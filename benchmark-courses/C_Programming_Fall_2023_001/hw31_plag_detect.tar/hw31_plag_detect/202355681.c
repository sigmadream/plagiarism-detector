#include <stdio.h>

void printBitset(int n) {
    int bitPosition = 0;

    while (n > 0) {
       
        if (n & 1) {
            
            printf("%d\n", bitPosition);
        }

      
        n >>= 1;
        bitPosition++;
    }
}

int main() {
    int n;

   
    scanf("%d", &n);

   
    printBitset(n);

    return 0;
}
