#include <stdio.h>

int main() {
	char c = getchar();

	if ('a' <= c && c <= 'z') {
		c = c - 1;
		if (c < 'a')
			c = 'z';
	}
	else if ('A' <= c && c <= 'Z') {
		c = c + 1;
		if (c > 'Z')
			c = 'A';
	}

	printf("%c", c);
	return 0;
}