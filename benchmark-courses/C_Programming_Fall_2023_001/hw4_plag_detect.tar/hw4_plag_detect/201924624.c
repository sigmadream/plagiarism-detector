#include <stdio.h>

int main() {
    char c;

    
    c = getchar();

    if (c >= 'A' && c <= 'Z') {
        if (c == 'Z') {
            putchar('A');
        } else {
            putchar(c + 1);
        }
    } else if (c >= 'a' && c <= 'z') {
        if (c == 'a') {
            putchar('z');
        } else {
            putchar(c - 1);
        }
    } else {
        putchar(c);
    }

    return 0;
}

