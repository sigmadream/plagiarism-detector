#include <stdio.h>

int main() {

	int ch = getchar();
	if (ch >= 65 && ch < 90)
		printf("%c\n", ch + 1);
	else if (ch > 97 && ch <= 122)
		printf("%c\n", ch - 1);
	else if (ch == 90)
		printf("%c\n", 65);
	else if (ch == 97)
		printf("%c\n", 122);

	return 0;
}