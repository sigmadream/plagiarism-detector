#include <stdio.h>

int main(){
	//char c1 = 'A' , c2 = 'B'+1, c3 = 'a';
	//printf("%d, %d, %d\n", c1, c2, c3);
	//printf("%c, %c, %c", c1, c2, c3);
	int add_flag = 0;
	int n = getchar();
	//printf("%d\n",n);
	if (n == 90)
		add_flag = -25;
	else if (n == 97)
		add_flag = 25;
	// cacultaing code with exceptions Z, a
	else if (65<=n & n<90)
		add_flag = 1;
	else
		add_flag = -1;
	// ASCII  number of lower case is between 97 and 122 in decimal, upper case is 65 ~ 90
	//printf("%d, %d, %c", add_flag, n, add_flag+n);
	printf("%c", add_flag + n);
	return 0;
}