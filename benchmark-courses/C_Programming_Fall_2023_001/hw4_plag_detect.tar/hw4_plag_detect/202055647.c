#include <stdio.h>

int main()
{
    char inp;
    scanf("%c",&inp);
    if(inp < 'a')
    {
        if(inp == 90)
            inp = 65;
        else
            inp++;
    }
    else
    {
        if(inp == 97)
            inp = 122;
        else
            inp--;
    }
    printf("%c",inp);
}