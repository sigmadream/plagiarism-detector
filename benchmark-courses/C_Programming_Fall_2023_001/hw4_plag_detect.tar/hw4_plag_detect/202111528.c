#include <stdio.h>

int main(void)
{
    int ch;
    
    scanf("%c", &ch);

    if('a' < ch && 'z' >= ch)
        printf("%c", ch-1);
    else if(ch >= 'A' && ch < 'Z')
        printf("%c", ch+1);
    else if(ch=='a')
        printf("%c", ch+25);
    else if(ch=='Z')
        printf("%c", ch-25);

    return 0;
}