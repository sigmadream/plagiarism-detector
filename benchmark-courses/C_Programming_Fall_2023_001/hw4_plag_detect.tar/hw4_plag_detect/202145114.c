#include <stdio.h>

int main() {

    char a;
    scanf("%c", &a);

    if (a >= 'A' && a <= 'Z') {
        if (a == 'Z') {
            printf("A\n");
        } else {
            printf("%c", a + 1);
        }
    }
    else if (a >= 'a' && a <= 'z') {
            if (a == 'a') {
                printf("z\n");
            }
            else {
                printf("%c", a - 1);
            }
        }
        return 0;
    }
