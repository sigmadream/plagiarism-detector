#include <stdio.h>

int main()
{
    int c = getchar();
    if (c>=65 && c<=90)
    {
        if(c==90)
        {
            printf("A");
            return 0;
        }
        printf("%c",c+1);
    }
    else
    {
        if(c==97)
        {
            printf("z");
            return 0;
        }
        printf("%c",c-1);
    }
    return 0;
}
