#include <stdio.h>

int main(){
  char a = getchar();
  
  if(a >= 'A' && a < 'Z'){
    printf("%c" , a + 1);
  }
  else if (a> 'a' && a <= 'z'){
    printf("%c" , a - 1);
    
  }
  else if (a == 'a' ){
    printf("%c" , a + 25);
  }
  else {
    printf("%c" , a - 25);
  }
  return 0 ;
}
