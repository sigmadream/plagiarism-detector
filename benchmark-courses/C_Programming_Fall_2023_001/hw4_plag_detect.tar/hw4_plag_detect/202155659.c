#include<stdio.h>

int main()
{
    char c=getchar();
    
    if ( c <= 90 && c >= 65 )
        if ( c == 90) // Z to A case
            printf("%c",65);
        else
            printf("%c", c+1);
    else if ( c<= 122 && c>=97 )
        if (c == 97) // a to z case
            printf("%c", 122);
        else
            printf("%c", c-1);
 
    return 0;
}