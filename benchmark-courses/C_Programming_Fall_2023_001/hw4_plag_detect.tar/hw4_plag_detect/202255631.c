#include <stdio.h>

int main() {
    char c;
    scanf("%c", &c);
    
    if (c >= 'A' && c <= 'Z') {
        if (c == 'Z') {
            c = 'A';
        } else {
            c++;
        }
    } else if (c >= 'a' && c <= 'z') {  
        if (c == 'a') {
            c = 'z';
        } else {
            c--;
        }
    } 
    
    printf("%c\n", c);
    
    return 0;
}
