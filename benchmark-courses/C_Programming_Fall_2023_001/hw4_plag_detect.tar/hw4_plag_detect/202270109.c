#include <stdio.h>

int main ()
{
    char c;
    scanf("%c", &c);

    if (c >= 'A' && c <= 'Z') {
        if (c == 'Z') {
            printf("A");
        } else {
        char next = c + 1;
        printf("%c", next);
        }
    } else if (c >= 'a' && c <= 'z') {
        if (c == 'a') {
            printf("z");
        } else {
            char previous = c - 1;
            printf("%c", previous);
        }
    }

    return 0;
}
