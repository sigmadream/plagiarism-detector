#include<stdio.h>

int main()
{
    char c;
    scanf("%c" ,& c);

    if(c>='a' && c <= 'z'){
        if(c == 'a'){
            printf("%c" , 'z');
        }
        else{
            printf("%c" , c-1);
        }
    }
    else{
        if(c == 'Z'){
            printf("%c" , 'A');
        }
        else{
            printf("%c" , c+1);
        }
    }

    return 0;
}