#include <stdio.h>

int main(){
    
    int c = getchar();
    if(c < 90) //capital
        printf("%c", c + 1);
    if(c == 90) //input "Z"
        printf("%c", 'A');
    if(c == 97) //input 'a'
        printf("%c", 'z');
    if(123 > c && c > 97)
        printf("%c", c - 1);
    return 0;
}