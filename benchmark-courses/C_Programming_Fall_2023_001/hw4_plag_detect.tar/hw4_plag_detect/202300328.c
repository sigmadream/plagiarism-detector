#include <stdio.h>

int main()
{
  int c = getchar() , d = c - '0';
  int ch = (int)c;

  if ( 64 <  ch && ch < 91 ) { //MAJUSCULES
    if (ch == 90){
      ch = 65 ;
    }
    else {
      ch = ch+1 ;
    }
  }

  if ( 96 < ch && ch < 123 ) { //MINISCULES
    if (ch == 97){
      ch = 122 ;
    }
    else {
      ch = ch-1 ;
    }
  }
  printf("%c\n",ch);
}
