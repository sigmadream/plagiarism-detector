#include <stdio.h>

int main()
{
  int c = getchar() , d = c - '0';
  int rv = (int)c;
  if ( 64 <  rv && rv < 91 ) {
    if (rv == 90){
      rv = 65 ;
      printf("%c\n",rv);
    }
    else {
      rv = rv+1 ;
      printf("%c\n",rv);
    }
  }
  if ( 96 < rv && rv < 123 ) {
    if (rv == 97){
      rv = 122 ;
      printf("%c\n",rv);
    }
    else {
      rv = rv-1 ;
      printf("%c\n",rv);
    }
  }
  
}