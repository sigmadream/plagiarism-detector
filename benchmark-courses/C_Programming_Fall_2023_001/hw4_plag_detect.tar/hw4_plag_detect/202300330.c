#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ch;
    ch = getchar();

    if(ch>'a'&& ch<='z'){
        putchar(--ch);
        return 0;
    }

    if(ch>='A' && ch<'Z'){
        putchar(++ch);
        return 0;
    }
    if(ch=='a'){
        putchar('z');
    }
    if(ch=='Z'){
        putchar('A');
    }

    return 0;
}

