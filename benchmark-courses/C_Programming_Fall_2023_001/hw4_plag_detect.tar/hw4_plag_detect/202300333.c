#include <stdio.h>


int main (){

    char c = getchar(), d = c - '0';

    int a = (int)c;

    if(65 <= a && a < 91){

        if (a==90){
            a=65;
        }
        
        else{
            a = a+1;
        }
    }
    else if(96 < a && a <= 122){

        if (a==97){
            a=122;
        }
        
        else{
            a = a-1;
        }
    }
    printf("%c\n",a);
    return 0;
}