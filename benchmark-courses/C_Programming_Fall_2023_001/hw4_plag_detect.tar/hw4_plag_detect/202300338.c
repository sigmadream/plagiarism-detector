#include <stdio.h>

int main()
{
char c = getchar(), c2 = 'a', c3 = 'Z';

if (c >= c2)
    if (c == c2)
        printf("%c", c+25);
    else
        printf("%c", c-1);

else
    if (c == c3)
        printf("%c", c-25);
    else
        printf("%c", c+1);

return 0;
}
