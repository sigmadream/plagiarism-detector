#include <stdio.h>

int iscapital(char c){
if (c >='A' && c <= 'Z'){
    return 1;}
else{
    return 0;
}}

int main(){

printf("Write a letter of the alphabet, either in lowercase or in uppercase: ");
char c = getchar();

if (iscapital(c) == 1){ //case where the character is an uppercase letter
    if (c!='Z'){
    printf("%c", c+1);}
    else{
        printf("%c", 'A');
    }
}
else{ //case where the character is a lowercase letter
    if (c!='a'){
    printf("%c", c-1);}
    else{
        printf("%c", 'z');
    }
}

return 0;

}
