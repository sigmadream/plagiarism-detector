#include <stdio.h>

int main() {
    char c;
    printf("");
    scanf("%c", &c);

    if (c >= 'A' && c <= 'Z') {
        char result = (c == 'Z') ? 'A' : c + 1;
        printf("%c\n", result); 
    } else if (c >='a' && c <= 'z') {
        char result = (c== 'a') ? 'z' : c - 1;
        printf("%c\n", result);
    } else {
        printf("\n");
    }

    return 0;

}