//
//  main.c
//  HW2
//
//  Created by Sandoval Reyes Luis Armando on 2023/09/14.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    char character;
    scanf("%c", &character);
    
    if (character >= 65 && character <= 90)
    {
        if (character == 90)
        {
            printf("%c", 65);
        }
        else
        {
            printf("%c", character+1);
        }
    }
    else
    {
        if (character == 97)
        {
            printf("%c", 122);
        }
        else
        {
            printf("%c", character-1);
        }
    }
    return 0;
}
