#include <stdio.h>

int main(){

    char x;
    scanf("%c", &x);


    if (x < 90)
        printf("%c", x+1);
    if (x == 90)
        printf("%c", 65 );
    if (x == 97)
        printf("%c", 122 );
    if (x > 97)
        printf("%c", x-1);

}
