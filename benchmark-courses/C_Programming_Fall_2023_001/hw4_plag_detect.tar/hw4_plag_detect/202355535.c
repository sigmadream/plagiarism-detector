#include <stdio.h>
#include <ctype.h>

int main() {
    char c1;
    int c = scanf("%c", &c1);

    if (c == 1) {
        if(isupper(c1))
            if (c1 == 'Z')
                printf("A");
            else
                printf("%c", c1 + 1);
        else if (islower(c1))
            if (c1 == 'a')
                printf("z");
            else
                printf("%c", c1 -1);
    }

    return 0;
}