#include <stdio.h>
int main(){
    char c=getchar();
    if(c>='A' && c<='Z'){
        if(c!='Z'){
            printf("%c\n", c+1);
        }
        else{
            printf("A\n");
        }
    }
    else{
        if(c!='a'){
            printf("%c\n", c-1);
        }
        else{
            printf("z\n");
        }
    }

    return 0;
}