#include <stdio.h>

int main(){
    char C;
        scanf("%c", &C);

        if(C >= 'A' && C < 'Z')
            printf("%c", C+1);
        else if(C > 'a' && C <= 'z')
            printf("%c", C-1);
        else if(C == 'a')
            printf("%c", C+25);
        else if(C == 'Z')
            printf("%c", C-25);

    return 0;
}
