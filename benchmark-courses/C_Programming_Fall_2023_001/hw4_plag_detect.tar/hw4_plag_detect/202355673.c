#include <stdio.h>

int main() {
    char c;    
   
    scanf("%c", &c);

    if (c >= 'A' && c <= 'Z') {        
        if (c == 'Z') {
                  printf("A\n");
        } else {
            printf("%c\n", c + 1);
        }
    } else if (c >= 'a' && c <= 'z') {
       if (c == 'a') {
            printf("z\n");
        } else {
           printf("%c\n", c - 1);
        }
    } else {
       printf("NaN\n");
    }

    return 0;
}