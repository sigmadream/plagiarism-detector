#include <stdio.h>

int main()
{
    char c;
    scanf("%c", &c);

    if(c== 'Z')
        printf("%+c\n", 'A');
    else if(c=='a')
        printf("%+c\n", 'z');
    else if(c>='A'&&c<='Z')
        printf("%+c\n", (char)(((int)c) + 1));
    else if (c>='a'&&c<='z')
        printf("%+c\n",(char)(((int)c) - 1));
    return 0;
}
