#include <stdio.h>

int main()
{
    char inp;
    inp = getchar();

    if(inp >= 'A' && inp <= 'Z'){
        if(inp == 'Z'){
            puts("A");
        }
        else{
            printf("%c\n", inp + 1);
        }
    }
    else{
        if(inp == 'a'){
            puts("z");
        }
        else{
            printf("%c\n", inp - 1);
        }
    }
    
    

    return 0;
}
