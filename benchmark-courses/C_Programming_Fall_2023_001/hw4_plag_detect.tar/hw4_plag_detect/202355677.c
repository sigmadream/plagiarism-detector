#include <stdio.h>
int main()
{
    char c; //alphabet c
        scanf("%c", &c);

    if ( c >= 'A' && c < 'Z')
        printf("%c",c+1);

    else if ( c > 'a' && c <= 'z')
        printf("%c", c-1);

    if (c == 'a')
        printf("%c", c+25);

    else if ( c == 'Z')
        printf("%c", c-25);


 return 0;
}
