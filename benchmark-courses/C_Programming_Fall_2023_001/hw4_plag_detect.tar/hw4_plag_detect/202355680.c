#include <stdio.h>

main()
{
	char ch;
	ch = getchar();
	if(ch == 'Z')
		printf("A");
	else
	if('A' <= ch && ch <= 'Z')
		printf("%c", ch+1);
	else
	if(ch == 'a')
		printf("z");
	else
		printf("%c", ch-1);
}
