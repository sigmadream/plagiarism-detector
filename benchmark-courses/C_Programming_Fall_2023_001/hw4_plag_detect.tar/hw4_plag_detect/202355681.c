#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a;
    scanf("%c", &a);

    if (a== 'Z')
        printf("%+c\n", 'A');
    else if(a=='a')
        printf("%+c\n", 'z');
    else if(a>='A'&&a<='Z')
        printf("%+c\n", (char) (((int)a)+1));
    else if(a>='a'&&a<='z')
        printf("%+c\n", (char) (((int)a)-1));
    return 0;
}
