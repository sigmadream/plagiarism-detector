#include <stdio.h>

int main() {
	int n = 0; 
	double x = 0;

	fscanf(stdin, "%d", &n);
	fscanf(stdin, "%lf", &x);

	fprintf(stdout, "0.");

	while (n--)
	{
		x *= 2;
		if (x >= 1.0) {
			fprintf(stdout, "1");
			x -= 1.0;
		}
		else {
			fprintf(stdout, "0");
		}
	}

	return 0;
}