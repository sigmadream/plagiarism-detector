#include <stdio.h>
#include <float.h>
int main(){
	int n;
	double f;
	char ans[2000];
	int i = 0;
	char *p = ans;
	fscanf(stdin, "%d%lf", &n, &f);
	for (; i < n; i++){
		f *= 2;
		if(f >=1){
			ans[i] = '1';
			f -= 1.0;
		}
		else
			ans[i] = '0';
	}
	printf("0.");
	for (i = 0; i < n; p++){
		printf("%c", *p);
		i++;
	}
}
