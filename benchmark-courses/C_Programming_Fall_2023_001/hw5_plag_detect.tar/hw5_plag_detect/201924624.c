#include <stdio.h>

int main()
{
    int n = 0;
    double x = 0.0;

    fscanf(stdin, "%d", &n);
    fscanf(stdin, "%f", &x);
    fprintf(stdout, "0.");

    while ( n > 0 ) 
    {
        x *= 2;
        int bit = (int)x;
        x -= bit;
        fprintf(stdout, "%d", bit);
        n --;
    }

    fprintf(stdout, "\n");

    return 0;

}