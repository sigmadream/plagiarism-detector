#include <stdio.h>

int main() {

	int fsize = 0;
	double num = 0.0;

	scanf("%d %lf", &fsize, &num);

	printf("0.");
	for (int i = 0; i < fsize; i++) {
		if (num > 1)
			num -= 1;
		
		if (num == 1.0)
			printf("0");
		else {
			printf("%d", (int)(num * 2));
			num *= 2;
		}
	}

	return 0;
}