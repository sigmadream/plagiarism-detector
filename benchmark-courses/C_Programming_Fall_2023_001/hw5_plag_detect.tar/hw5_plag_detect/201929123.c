#include <stdio.h>
#include <math.h>

int main()
{
    int num;
    float decimal = 0.0;
    double binary = 0.0;

    fscanf(stdin, "%d", &num);
    fscanf(stdin, "%f", &decimal);

    printf("0.");
    for (int i = 1; i < num+1; i++){
        decimal *= 2;
        float f;
        if (decimal >= 1){
            f = powf(10,-i);
            binary += f;
            decimal -= 1;
            printf("%d",1);
        }else printf("%d", 0);
    }

//
//    printf("%.f",binary);

}
