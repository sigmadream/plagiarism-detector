#include <stdio.h>

int main()
{
    int N = 0;
    float DIGITS;
    float i, j;
    double EXPORT_NUMBER = 0.0;
    double BINARY_LOCATION, COMPARE_DIGITS, DIGITS_2;
    fscanf(stdin, "%d%f", &N, &DIGITS);
    DIGITS_2 = DIGITS;
    //printf("huh = %d, %f", N, DIGITS_2);

    for (i=1; i <= N; i++){
        COMPARE_DIGITS = DIGITS_2 * 2;
        //printf("DIGITS:%f\n", COMPARE_DIGITS);
        double ADDING_NUMBER = 0.0;
        BINARY_LOCATION = 0;
        if (COMPARE_DIGITS >= 1){
            COMPARE_DIGITS -= 1;
            BINARY_LOCATION = 1;
            for (j=1; j<=i; j++){
                //printf("before : %f\n", BINARY_LOCATION);
                BINARY_LOCATION /= 10;
                //printf("after : %f\n", BINARY_LOCATION);
            }
        }
        DIGITS_2 = COMPARE_DIGITS;
        //printf("%f, %f", DIGITS_2, COMPARE_DIGITS);
        EXPORT_NUMBER += BINARY_LOCATION;
    }
    printf("%f", EXPORT_NUMBER);
    return 0;
}
