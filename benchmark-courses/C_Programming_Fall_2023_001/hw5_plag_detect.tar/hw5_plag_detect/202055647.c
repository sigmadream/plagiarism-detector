#include <stdio.h>

int main()
{
    int n = 0;
    float x = 0.0f;

    scanf("%d %f",&n,&x);

    printf("0.");

    for(int i =0;i<n;i++)
    {
        x *= 2.0f;
        if(x >= 1.0f){
            printf("1");
            x -= 1.0f;
        }
        else{
            printf("0");
        }
    }




    return 0;
}
