#include <stdio.h>

int main()
{
    int n,a;
    double x;

    scanf("%d",&n);
    scanf("%f",&x);

    printf("%.nf",x);

    int i = 0;
    while (n > 0) {
  
        // storing remainder in binary array
        x = x*2;

        if(x>0) {
            x=x-1;
        } else {
            x=x;
        }
        printf("%f",x);
    }
  

}