#include <stdio.h>

int main() {
    int n;
    float x;

    scanf("%d", &n);
    scanf("%f", &x);

    printf("0.");

    for (int i = 0; i < n; i += 1) {
        x *= 2;
        if (x >= 1) {
            printf("1");
            x -= 1;
        } else {
            printf("0");
        }
    }

    printf("\n");

    return 0;
}
