#include <stdio.h>

int main() {
    int n;
    double x;

    scanf("%d", &n);
    scanf("%lf", &x);

    printf("0.");

    for (int i = 0; i < n; i++) {
        x = x * 2;
        if (x >= 1.0) {
            printf("1");
            x = x - 1.0;
        } else {
            printf("0");
        }
    }
    return 0;
}
