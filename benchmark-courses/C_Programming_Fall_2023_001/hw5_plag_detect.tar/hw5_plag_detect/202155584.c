#include <stdio.h>

int main(){
  int a ; 
  long double f ; 

  fscanf(stdin , "%d %Lf" , &a , &f) ; 

   for (int i = 0; i < a; i++) {
     int b = 1 , c = 0 ; 
     if(i == 0){
       printf("0.") ;
     }
        f *= 2;
        if (f > 1) {
            fprintf(stdout , "%d" , b);
            f -= 1;
        } 
        else if(f == 1){
          printf("1");
          f = 0;
        }
        else{
          printf("0");
        }
        }
    
  return 0 ;

  
}