/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/


#include <stdio.h>

int main() {
    int n;
    float x;
    char binary_result[100];  
    fscanf(stdin, "%d%f", &n, &x);



    
    if (x <= 0.0 || x >= 1.0) {
        fprintf(stdout, "Invalid input for x. Ensure 0 < x < 1.\n");
        return 1;  
    }


    binary_result[0] = '0';
    binary_result[1] = '.';

   
    for (int i = 0; i < n; i++) {
        x *= 2;
        if (x >= 1.0) {
            binary_result[i + 2] = '1';
            x -= 1.0;
        } else {
            binary_result[i + 2] = '0';
        }
    }
    binary_result[n + 2] = '\0';  
    fprintf(stdout, "%s\n", binary_result);

    return 0;
}

