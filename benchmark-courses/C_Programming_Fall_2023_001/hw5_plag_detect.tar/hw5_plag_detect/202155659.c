#include<stdio.h>
int main()
{
    int n;
    float x;
    float f;
    scanf("%d",&n);
    scanf("%f",&x);
    f=x;
    printf("0.");
    while(n>0){
        f= f*2;
        if(f>=1){
            printf("%d",1);
            f=f-1;
        }
        else{
                printf("%d",0);
        }
        n--;
    }
    
}