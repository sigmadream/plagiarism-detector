#include <stdio.h>

int main() {
    int n;
    double f;

    scanf("%d", &n);
    scanf("%lf", &f);

    printf("0.");

    for (int i = 0; i < n; i++) {
        f *= 2;
        if (f >= 1) {
            printf("1");
            f -= 1;
        }
        else {
            printf("0");
        }
    }

    return 0;
}
