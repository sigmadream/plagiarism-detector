#include <stdio.h>

int main()
{
	int binary_digit = 0, n = 0;
	double floating_point_number = 0.0, decimal_part = 0.0;

	fscanf(stdin, "%d %lf", &binary_digit, &floating_point_number);
	if((0 < floating_point_number) && (floating_point_number< 1)){
		fputs("0.",stdout);
	}
	
	for(n = 0; n < binary_digit; n++){
		decimal_part = floating_point_number * 2;
		if(decimal_part >= 1){
			fputs("1",stdout);
			floating_point_number = decimal_part -1;
		}else{
			fputs("0",stdout);
			floating_point_number = decimal_part;
		}
	}
	
 	return 0;	
}

