#include <stdio.h>

int main() {
    int n;
    double x;

    scanf("%d", &n);
    scanf("%lf", &x);

    printf("0.");
    for (int i = 0; i < n; i++) {
        x *= 2;
        int bit = (int)x;
        x -= bit;
        printf("%d", bit);
    }

    return 0;
}
