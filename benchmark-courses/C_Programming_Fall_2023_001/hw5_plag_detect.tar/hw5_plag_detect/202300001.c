#include <stdio.h>

int main()
{
	float f;
	int n;
	scanf("%d%f", &n, &f);
	printf("0.");
	f *= 2;
	while(n)
	{
		if(f >= 1.0)
		{
			printf("1");
			f -= 1.0;
		}
		else
			printf("0");
		f *= 2;
		n--;
	}
}