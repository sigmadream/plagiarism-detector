#include <stdio.h>

int main()
{
    int n;
    float f;

    fscanf(stdin, "%d%f", &n, &f);
    fprintf(stdout, "0.");
    while (n > 0) {
        f *= 2.0;
        if (f >= 1.0) {
            fprintf(stdout, "1");
            f -= 1.0;
        }
        else
            fprintf(stdout, "0");
        n--;
    }
    fputs("\n", stdout);

    return 0;
}

