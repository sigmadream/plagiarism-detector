#include <stdio.h>

int main()
{
    int n;
    double f;

    scanf("%d", &n);
    scanf("%lf", &f);

    double frac = f;
    int bin = 0;

    printf("0.");

    while (bin < n) {
           frac*=2;
        if (frac >= 1) {
            printf("1");
            frac--;
        }
        else {
            printf("0");
        }

        bin++;
    }

    return 0;
}
