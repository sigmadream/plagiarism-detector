#include <stdio.h>

int main() {
    int n;
    double f;
    fscanf(stdin,"%d", &n);
    fscanf(stdin,"%lf", &f);

    if (f <= 0 || f >= 1) {
        fprintf(stdout,"f should be between 0 and 1.\n");
        return 1;
    }
    fprintf(stdout,"0.");
    for (int i = 0; i < n; i++) {
        f *= 2;
        if (f >= 1) {
            fprintf(stdout,"1");
            f -= 1;
        } else {
            fprintf(stdout,"0");
        }
    }
    fprintf(stdout,"\n");
    return 0;
}
