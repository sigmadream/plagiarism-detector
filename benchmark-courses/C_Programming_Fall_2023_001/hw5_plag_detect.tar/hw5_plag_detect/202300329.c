#include <stdio.h>

int main() {
    int n;
    double f; 

    fscanf(stdin, "%d", &n);
    fscanf(stdin, "%lf", &f); 
    
    if (n <= 0) {
        fprintf(stdout, "The integer is positive\n");
        return 1;
    }

    if (f < 0 || f > 1) {
        fprintf(stdout, "The floating number is between 0 and 1.\n");
        return 1;
    }

    fprintf(stdout, "0.");

    for (int i = 0; i < n; i++) {
        f *= 2;
        int bit = (int)f;
        fprintf(stdout, "%d", bit);
        f -= bit;
    }

    fprintf(stdout, "\n");

    return 0;
}
