#include <stdio.h>

int main()
{
    //declaring all the variables
    int n;
    float x;

    int k=0;

    //getting the user to input the variables

    scanf("%d", &n);

    scanf("%f", &x);
    printf("0.");
    int array[n]; //create an array as long as n+1

    //iterating as long as the length of the number doesn't exceed n
    while (k<n && x!= 0.0) {
        int multiple = x * 2;
        if (multiple >= 1.0){
            x = x*2;
            x = x-1;
            printf("1");
        }
        else{
            x = x*2;
            printf("0");}

        k++;
    }


return 0;
 }
