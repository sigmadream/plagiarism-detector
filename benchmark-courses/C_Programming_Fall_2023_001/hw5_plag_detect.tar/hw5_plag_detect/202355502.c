#include <stdio.h> 
int main(){
    int n;
    double f;
    scanf("%d%lf", &n, &f);
    int integerPart= (int)f;
    double fractionalPart= f-integerPart;
    printf("0.");
    for (int i =0; i<n; i++){
        fractionalPart*=2.0;
        int bit=(int)fractionalPart;
        printf("%d", bit);
        fractionalPart-=bit;
    }  
    printf("\n");
    return 0;        
    }


