#include <stdio.h>
int main()
{
    float number1 = 5;
    double number2 = 0.29;

    printf

    return 0;
}