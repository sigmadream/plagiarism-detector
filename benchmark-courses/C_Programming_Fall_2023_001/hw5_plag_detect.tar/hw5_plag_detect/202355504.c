//
//  main.c
//  Lab3
//
//  Created by Sandoval Reyes Luis Armando on 2023/09/21.
//

#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char * argv[]) {
    
    int n; scanf("%d", &n);
    float x; scanf("%f", &x);
    char binary[n];
    
    
    
    //Convert decimal part to binary
    
    char product[100];
    
    for (int i = 0; i<n; i++)
    {
        if (x>=1)
        {
            x = x-1;
        }
        x = x*2;
        if (x >= 2)
        {
            x = x - 1;
        }
        sprintf(product, "%f", x);
        binary[i] = product[0];
        
        //Updating variable product
        //product[0]=0;
    }
    
    //Printing the result
    
    printf("0.");
    for(int i = 0; i<n; i++)
    {
        printf("%c", binary[i]);
    }
    printf("\n");
    
    return 0;
}
