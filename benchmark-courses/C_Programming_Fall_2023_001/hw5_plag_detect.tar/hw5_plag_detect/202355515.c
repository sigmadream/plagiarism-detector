#include <stdio.h>

int main()
{
    int n;
    float x;

    scanf("%d", &n);
    scanf("%f", &x);

    int a = 1; //cnt
    int b = 1;

    float i;
    float j = 0;

    while (a <= n) {

        if (x >= 1) {
            i = 1;
            while ( b> 0) {
                i *= 0.1;
                b--;

            }
            x = x - 1;
        }
        if (x < 1) {
            x = x * 2;
            b++;
            }

        }
        j = j + i;
        a++;
        b++;



    printf("%f", j);


}
