#include <stdio.h>

int main() {
    int n;
    float number; 
    scanf("%d", &n);
    scanf("%f", &number);
    
    double binaryFraction = 0.5;
    printf("0."); 

    for (int i = 0; i < n; i++) {
        if (number >= binaryFraction) {
            printf("1");
            number -= binaryFraction;
        } else {
            printf("0");
        }
        binaryFraction /= 2;
    }
    return 0;
}
