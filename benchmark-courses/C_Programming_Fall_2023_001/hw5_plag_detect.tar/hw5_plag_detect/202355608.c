#include <stdio.h>

int main()
{
    int n,a,len = 0;
    char b[] = "0.";
    char c;
    float x = 0.0;

    fscanf(stdin,"%d",&n);
    fscanf(stdin,"%f",&x);

    for (int i=0;i<n;i++)
    {
        x = x*2;
        int a = x;

        len = strlen(b);
        b[len] = c;
        b[len+1] = "\0";

        if (x>=1.0){
            x= x-1;
        }
    }

    printf("%c",b);
    return 0;
}
