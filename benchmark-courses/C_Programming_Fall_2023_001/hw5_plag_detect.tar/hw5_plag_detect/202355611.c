#include <stdio.h>

int main() {
    double n;
    double x;

    //binary digits
    scanf("%d", &n);
    //floating-point number (0 < x < 1)
    scanf("%lf", &x);

    if (x <= 0 || x >= 1) {
        return 1;
    }

    printf("0.");
    for (int i = 0; i < n; i++) {
        x *= 2;
        int bit = (int)x;
        printf("%d", bit);
        x -= bit;
    }

    printf("\n");

    return 0;
}

