#include <stdio.h>
int main()
{
    int n = 0;
    float x = 0;
    scanf("%d%f", &n, &x);
    printf("0.");
    for(int i = 1; i <= n; i++)
    {
        x *= 2;
        if (x >= 1) {
            x -= 1;
            printf("1");
        }
        else {
            printf("0");
        }
    }
    printf("\n");
    return 0;
}