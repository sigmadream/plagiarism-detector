#include <stdio.h>

int main()
{
    int n, temp;
    double f, binaryNum = 0.0, fraction = 0.1;

    fscanf(stdin, "%d%lf", &n, &f);

    for(int i=1; i< n+1; i++){
        f = f*2;
        temp = (int)f;
        binaryNum = binaryNum + fraction * temp;

        if(f>1)
            f = f - 1;
        fraction = fraction/10;
    }
    fprintf(stdout, "%*.*f", n+1, n, binaryNum);
    return 0;
}
