#include <stdio.h>

int main()
{
    int len =0;
    float number = 0.0;

    scanf("%d", &len);
    scanf("%f", &number);

    printf("0.");

    for(int i=0; i<len; i++){
        number *= 2;
        if(number >= 1){
            printf("1");
            number -= 1;
        }
        else{
            printf("0");
        }

    }

    
    

    return 0;
}
