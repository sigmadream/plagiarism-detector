#include <stdio.h>
int main()
{
    int n;
    float x;
    float res;

    scanf("%d", &n);
    scanf("%f", &x);
    printf("0.", res);
    for (int i = 0 ; i < n; i++)
    {



        res = x*2;

        while(res >= 1);
        {
            printf("1");
            res = res -1;
        }
        while ( res < 1);

        {
            printf("0");
        }
    }

    printf("\n");
    return 0;
}
