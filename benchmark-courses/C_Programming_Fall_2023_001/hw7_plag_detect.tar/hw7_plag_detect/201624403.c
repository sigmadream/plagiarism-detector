#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>

int main() {
	
	char input_str[41];
	char input_str1[41];
	//char* word;

	scanf("%40s", input_str);
	scanf("%40s", input_str1);

	if (strlen(input_str) < strlen(input_str1)) {
		printf("_"); 
	}

	else {
		for (size_t i = 0; i < strlen(input_str); i++)
		{
			printf("%c", input_str[i]);

			if (strlen(input_str1) <= i)
				continue;

			printf("%c", input_str1[i]);
		}
	}

	return 0;
}

//int main() {
//	
//}