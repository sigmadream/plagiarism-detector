#include <stdio.h>
#include <string.h>
#define max 41
int main()
{
    char word1[max];
    char word2[max];
    int len1;
    int len2;
    scanf("%40s", word1);
    getchar();
    scanf("%40s", word2);
    len1 = strlen(word1);
    len2 = strlen(word2);
    if(len1 - len2 == 0 || len1- len2 ==1){
        for(int i = 0; i < len1; i++){
            printf("%c%c", word1[i], word2[i]);
        }
    }

    else{
        printf("-");
    }

    return 0;
}
