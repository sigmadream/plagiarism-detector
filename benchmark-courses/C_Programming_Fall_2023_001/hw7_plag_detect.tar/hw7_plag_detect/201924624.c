#include <stdio.h>
#include <string.h>

int main() {
    char word1[41];  // Maximum word length is 40
    char word2[41];

    // Read two words from input
    if (scanf("%40s %40s", word1, word2) != 2) {
        fprintf(stderr, "Invalid input format.\n");
        return 1;
    }

    int len1 = strlen(word1);
    int len2 = strlen(word2);

    // Check length requirements
    if (len1 < len2 || len1 > len2 + 1) {
        // Length requirements not met, print underscore
        printf("_\n");
        return 0;  // Exit the program
    }

    // Mix the words
    int i, k = 0;
    char mixedWord[81];  // Maximum mixed word length is 80
    for (i = 0; i < len1; i++) {
        mixedWord[k++] = word1[i];
        if (i < len2) {
            mixedWord[k++] = word2[i];
        }
    }
    mixedWord[k] = '\0';  // Null-terminate the mixed word

    // Print the mixed word
    printf("%s\n", mixedWord);

    return 0;
}

