#include <stdio.h>
#include <string.h>

void wdmix(){

    char first[20], second [20];
    scanf("%s %s",first, second);

    if (strlen(first) < strlen(second) || strlen(first) > strlen(second)+1){
        printf("_");
    }else{
        for(int i= 0; i < strlen(first); i++){
            printf("%c",first[i]);
            printf("%c",second[i]);
        }
    }
}

int main(){
    wdmix();

    return 0;
}
