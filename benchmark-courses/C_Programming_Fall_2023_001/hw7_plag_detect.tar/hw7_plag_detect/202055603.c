#include <stdio.h>
#include <string.h>

int main(){
    char line1[256], line2[256];

    //printf("%s\n", line1);
    //printf("%s\n", line2);
    scanf("%hhs%hhs", &line1, &line2);
    if (strlen(line1) >= strlen(line2)) {
        for (int i = 0; i<strlen(line1); i++){
        printf("%c", line1[i]);
        if (i < strlen(line2)){
            printf("%c", line2[i]);
        } else{
            continue;
        }
        }
    } else {
        printf("_");
    }


    return 0;
}
