#include <stdio.h>
#include <stdlib.h>

int main()
{
    char one[41];
    char two[41];
    scanf("%s",one);

    scanf("%s",two);

    int oneSize = 0;
    while(one[oneSize] != 0)
        oneSize++;

    int twoSize = 0;
    while(two[twoSize] != 0)
        twoSize++;

    if(oneSize < twoSize)
    {
        printf("_");
        return 0;
    }

    for(int i = 0; i< oneSize;i++)
    {
        printf("%c",one[i]);
        if(i < twoSize)
            printf("%c",two[i]);
    }

    return 0;
}
