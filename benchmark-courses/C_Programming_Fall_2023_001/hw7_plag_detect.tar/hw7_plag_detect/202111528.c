#include <stdio.h>
#include <string.h>

int main() {
    char line[100];
    char output[100];
    char *word1, *word2;

    fgets(line, sizeof(line), stdin);

    word1 = strtok(line, " ");
    word2 = strtok(NULL, " ");


    if (word1 != NULL && word2 != NULL) {
        int len1 = strlen(word1);
        int len2 = strlen(word2);

        // 길이 비교 후 출력
        if (len1 >= len2-1) {
            int outputIndex = 0;
            for (int i = 0; i < len2; i++) {
                output[outputIndex++] = word1[i];
                output[outputIndex++] = word2[i];
            }
            for (int i = len2; i < len1; i++) {
                output[outputIndex++] = word1[i];
            }
            output[outputIndex] = '\0';
        printf("%s\n", output);
        } else {
            printf("_");
        }


    }
    
    return 0;
}