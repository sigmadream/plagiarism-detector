#include <stdio.h>
#include <string.h>

int main() {
	char s1[100], s2[100];
	scanf("%s %s", &s1, &s2);
	if (strlen(s1) != strlen(s2))
		printf("_");
	else {
		int i;
		for (i = 0; i < strlen(s1); i++) {
			printf("%c%c", s1[i], s2[i]);
		}
	}
}
