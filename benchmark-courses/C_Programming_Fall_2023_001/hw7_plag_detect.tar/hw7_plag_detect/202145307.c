#include <stdio.h>
#include <string.h>

void mixWords(char word1[], char word2[]) {
    int len1 = strlen(word1);
    int len2 = strlen(word2);

    if (len1 != len2 && len1 != len2 + 1) {
        printf("_\n");
        return;
    }

    int i, j;
    for (i = 0, j = 0; i < len1 || j < len2; i++, j++) {
        if (i < len1) {
            putchar(word1[i]);
        }
        if (j < len2) {
            putchar(word2[j]);
        }
    }
    printf("\n");
}

int main() {
    char word1[41];
    char word2[41];

    scanf("%s %s", word1, word2);

    mixWords(word1, word2);

    return 0;
}

