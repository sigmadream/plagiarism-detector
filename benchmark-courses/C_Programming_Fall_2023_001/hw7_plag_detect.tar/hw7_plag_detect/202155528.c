#include <stdio.h>
#include<string.h>

int main()
{
	char arr[50];
	char result[100] = { NULL };

	fgets(arr, sizeof(arr), stdin);
	char* ptr1 = strtok(arr, " ");
	char* ptr2 = strtok(NULL, " ");

	if (strlen(ptr1) < strlen(ptr2) - 1)
	{
        printf("_");
	}
	else
	{
		for (int i = 0; i < strlen(ptr1); i++)
		{
			result[2 * i] = ptr1[i];
			result[2 * i + 1] = ptr2[i];
		}
	}
	printf("%s", result);
	return 0;
}
