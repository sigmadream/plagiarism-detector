#include <stdio.h>
#include <string.h>


int main(void) {
  char s1[41];
  char s2[41];
  
  scanf("%s", s1);
  scanf("%s", s2);
  
  if(strlen(s1) < strlen(s2)){
    printf("_");
  }
else{
  for(int i = 0;i < strlen(s1);i++){
   
    printf("%c", s1[i]);
    printf("%c", s2[i]);
   
  
  }
}
  
  return 0;
}