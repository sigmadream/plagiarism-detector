#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h> 

char* solution(const char* str1, const char* str2) 
{
    if (str1 == NULL || str2 == NULL) {
        return NULL; 
    }

    unsigned length = strlen(str1) + strlen(str2);
    char* answer = (char*)malloc(length + 1);

    if (answer == NULL) {
        return NULL;

    for (int i = 0; i < length / 2; i++) {
        answer[2 * i] = str1[i];
        answer[2 * i + 1] = str2[i];
    }
    answer[length] = '\0';
    printf("Answer = %s\n", answer); 
    return answer;
}

int main() 
{
    const char* str1 = "Hello";
    const char* str2 = "World";
    char* result = solution(str1, str2);
    free(result); 
    return 0;
}
