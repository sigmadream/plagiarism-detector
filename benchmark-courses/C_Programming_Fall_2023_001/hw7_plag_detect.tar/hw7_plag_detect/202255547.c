#include <stdio.h>
#include <string.h>

int main()
{
    char line1[40];
    char line2[40];
    scanf("%s %s",&line1,&line2);

    int len[2];
    len[0] = strlen(line1);
    len[1] = strlen(line2);

    if(len[0] == len[1] || len[0] == len[1]+1){
        for(int i=0;i<len[0];i++){
            printf("%c%c",line1[i],line2[i]);
        }
    }
    else {
        printf("_");
    }

    return 0;
}
