#include <stdio.h>
#include <string.h>

int main() {
    char word1[41], word2[41], mixedWord[81]; 
    int i, j, k = 0;
    scanf("%s %s", word1, word2);

   
    if(strlen(word1) >= strlen(word2) && strlen(word1) <= strlen(word2) + 1) {
        for(i = 0, j = 0; i < strlen(word1) || j < strlen(word2); i++, j++) {
            if(i < strlen(word1)) {
                mixedWord[k++] = word1[i];
            }
            if(j < strlen(word2)) {
                mixedWord[k++] = word2[j];
            }
        }
        mixedWord[k] = '\0'; 
        printf("%s\n", mixedWord); 
    } else {
        printf("_\n"); 
    }

    return 0;
}
