#include <stdio.h>
#include <string.h>

int main() 
{   
    int j, k, i;
    char mixed_word[40];

    char first_word[20];
    scanf("%20s", &first_word);

    char second_word[20];
    scanf("%20s", &second_word);

    i = j = k= 0;
    if (strlen(first_word) == strlen(second_word) || strlen(first_word) == strlen(second_word) + 1)
    {
        while (i < strlen(first_word) && j < strlen(second_word)) {
            mixed_word[k++] = first_word[i++];
            mixed_word[k++] = second_word[j++]; 
    }
    }else {
        printf("_");
    }


    mixed_word[k] = '\0';

    printf("%s", mixed_word);

    return 0;
}