#include <stdio.h>
#include <string.h>


int main()
{
    char line1[80];
    char line2[80];
    
    scanf("%s", line1);
    scanf("%s", line2);
    if (strlen(line1) == strlen(line2)){
        for (int i = 0; i < strlen(line1); i++) {
            printf("%c", line1[i]);
            printf("%c", line2[i]);
        } 
    }else {
            printf("_");
    }
    
    return 0;
}