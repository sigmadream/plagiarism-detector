#include <stdio.h>
#include <string.h>

int main() {
    char Winput[100];
    char FstW[41], ScndW[41], mxdW[81];

    fgets(Winput, sizeof(Winput), stdin);

    if (sscanf(Winput, "%40s %40s", FstW, ScndW) != 2) {
        printf("_\n");
        return 1;
    }

    int len1 = strlen(FstW);
    int len2 = strlen(ScndW);

    if (len1 < len2 ) {
        printf("_\n");
        return 1;
    }
    else if (len1 > len2+1){
        printf("_\n");
        return 1;
    }
    int i, j, k = 0;
    for (i = 0; i < len1; i++) {
        mxdW[k++] = FstW[i];
        if (i < len2) {
            mxdW[k++] = ScndW[i];
        }
    }
mxdW[k]='\0';

    printf("%s\n", mxdW);

    return 0;
}
