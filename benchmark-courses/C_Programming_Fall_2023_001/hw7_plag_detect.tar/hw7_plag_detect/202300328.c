#include <stdio.h>
#include <string.h>

int main(){
  char ch[40] ; char word1[20] ; char word2[20] ; char mix[40];
  int k ; int i;
  fgets(ch,sizeof(ch),stdin);

  if (sscanf(ch, "%20s %20s", word1, word2) != 2) {
      printf("_\n");
      return 0;
  }
  if (strlen(word1) != strlen(word2) && strlen(word1) != strlen(word2) + 1) {
      printf("_\n");
      return 0;
  }
  k = 0;
  for (i = 0; i < strlen(word2); i++) {
      mix[k++] = word1[i];
      mix[k++] = word2[i];
  }

  if (strlen(word1) > strlen(word2)) {
      for (i = strlen(word2); i < strlen(word1); i++) {
          mix[k++] = word1[i];
      }
  }

  mix[k] = '\0';
  printf("%s\n", mix);
  return 0;
  }
