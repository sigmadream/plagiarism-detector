#include <stdio.h>
#include <string.h>

int main() {
    char input[85];  
    if (fgets(input, sizeof(input), stdin) != NULL) {
       
        input[strcspn(input, "\n")] = '\0';

        char *word1 = strtok(input, " ");
        char *word2 = strtok(NULL, " ");

        if (word1 != NULL && word2 != NULL) {
            int len1 = strlen(word1);
            int len2 = strlen(word2);

            if (len1 >= len2) {
                char mixed[85];
                int i, j, k = 0;

                for (i = 0; i < len1; i++) {
                    mixed[k++] = word1[i];
                    mixed[k++] = word2[i];
                }

                if (len1 > len2) {
                    mixed[k++] = word1[len1 - 1];
                }

                mixed[k] = '\0';

                printf("%s\n", mixed);
            } else {
                printf("_\n");
            }
        }
    }

    return 0;
}
