#include <stdio.h>
#include <string.h>

int main() {

    char line[40];

    fgets(line, sizeof(line), stdin);
    line[strcspn(line, "\n")] = '\0';

    char ch1[20];
    char ch2[20];

    int splitIndex = strcspn(line, " ");
    strncpy(ch1, line, splitIndex);
    ch1[splitIndex] = '\0';
    strcpy(ch2, line + splitIndex + 1);

    int lenCh1 = strlen(ch1);
    int lenCh2 = strlen(ch2);

    if (lenCh1 >= lenCh2){
        int i,j,k = 0;
        char mix[40];

        for (i = 0,j = 0; i < lenCh1 || j < lenCh2; i++, j++){
            if(i < lenCh1){
                mix[k++] = ch1[i];
            }
            if(j < lenCh2){
                mix[k++] = ch2[j];
            }
        }
    
        mix[k] = '\0';  // Null-terminate the mixed word

        // Print the mixed word
        printf("%s\n", mix);


    }
    else{
        printf("_\n");
    }
}
