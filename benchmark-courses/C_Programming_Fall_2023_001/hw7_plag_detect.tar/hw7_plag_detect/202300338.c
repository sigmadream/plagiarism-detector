#include <stdio.h>
#include <string.h>

int main() {
    char word1[40], word2[40];
    scanf("%s %s", word1, word2);

    int len1 = strlen(word1);
    int len2 = strlen(word2);

    if ((len1 == len2 || len1 >= len2 ) && len1 <= 40 && len2 <= 40) {
        char mixedWord[80];
        int i, j, k;
        for (i = j = k = 0; i < len1; i++, k += 2) {
            mixedWord[k] = word1[i];
            mixedWord[k + 1] = word2[j++];
        }
        mixedWord[k] = '\0';

        printf("%s\n", mixedWord);
    } else {
        printf("_\n");
    }

    return 0;
}
