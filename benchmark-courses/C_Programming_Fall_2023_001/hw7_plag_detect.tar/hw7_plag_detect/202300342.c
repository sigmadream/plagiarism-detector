#include <stdio.h>
#include <string.h>

int main() {
    char word_First[41], word_Second[41], mixed_Word[81]; //we declare three arrays
    //the word_First array contains the 1st word inputted by the user (HELLO in the test case)
    //the word_Second array contains the 2nd word inputted by the user (WORLD in the test case)
    //finally the mixed_Word array contains the mixed word (=HWEOLRLLOD for test case)

    //we read two words from the user input
    if (scanf("%40s %40s", word_First, word_Second) != 2) {
        fprintf(stderr, "Invalid input format\n"); //error message if the user inputs more or less than two words
        //(ex: HELLO WORLD AGAIN will give this error message)
        return 1;
    }

    //the program thenchecks if the lengths of the input words are sufficient
    int len1 = strlen(word_First);
    int len2 = strlen(word_Second);

    if (len1 != len2 && len1 != len2 + 1) { //condition if the length of the 1st word isn't equal or more than one than the 2nd one
        printf("_\n"); //print underscore and exit
        return 0;
    }

    //the words get mixed together:
    int i, j, k = 0;
    for (i = 0, j = 0; i < len1; i++, j++) { //we iterate the following until the mixed word is complete:
        mixed_Word[k++] = word_First[i]; //the 1st letter comes from the first word
        if (j < len2) {
            mixed_Word[k++] = word_Second[j]; //the following letter is from the second word
        }
    }

    mixed_Word[k] = '\0';

    printf("%s\n", mixed_Word);

    return 0;
}
