#include <stdio.h>
#include <string.h>

int main()
{
    char word1[41], word2[41];
    scanf ("%s %s", word1, word2);
    
    int len1= strlen(word1);
    int len2= strlen(word2);
    char mixedWord [81];
    if(len1 == len2 || len1 == len2 + 1){
        int i=0, j=0, k=0; 
        while (word1[i] != '\0' || word2[j] != '\0') {
            if(word1[i] != '\0'){
                mixedWord[k++] = word1[i++];
            }
            if (word2[j] != '\0'){
                mixedWord[k++] = word2[j++];
            }
        }
        mixedWord[k] = '\0';
        printf("%s\n", mixedWord);
    
    }
    else{
        puts("_");
    }
    return 0;

   
    
    
}