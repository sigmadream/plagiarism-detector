#include <stdio.h>
#include <string.h>

int main() {
    char word1[30];
    char word2[30];

    scanf("%s %s", word1, word2);

    int len1 = strlen(word1);
    int len2 = strlen(word2);

    int maxLenght = (len1 > len2) ? len1 : len2;

    char mixed[maxLenght * 2 + 1];
    if (len1 == len2 || len1 == len2 +1) {
        for (int i = 0; i < maxLenght; i++)
    {
        if (i < len1) {
            mixed[i * 2] = word1[i];
        }
        if (i < len2) {
            mixed[i * 2 + 1] = word2[i];
        }
    }

    mixed[maxLenght * 2] = '\0';

    printf("%s\n", mixed);

    }

else {
    puts("_");
}
    

    
    return 0;
    
}