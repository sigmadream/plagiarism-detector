//
//  main.c
//  Lab4
//
//  Created by Sandoval Reyes Luis Armando on 2023/10/05.
//

#include <stdio.h>
#include <string.h>

int main(int argc, const char * argv[]) {
    char input[100];
    fgets(input, 100, stdin);
    
    char sub_strings [2][50];
    int counter = 0;
    
    
    char *token = strtok(input, " ");
    while (token != NULL){
        int size = sizeof(token);
        memcpy(sub_strings[counter], token, size);
        counter++;
        token = strtok(NULL, " ");
    }
    
    //sizes
    
    int len1 = (int)strlen(sub_strings[0]);
    int len2 = (int)strlen(sub_strings[1])-1;
    char *p1 = sub_strings[0];
    char *p2 = sub_strings[1];
    
    if (len1 < len2){
        printf("_");
    }
    else{
        for(int i = 0; i<len1; i++){
            printf("%c%c", *p1, *p2);
            p1++; p2++;
        }
    }
    
    return 0;
}
