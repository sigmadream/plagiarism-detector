#include <stdio.h>
#include <string.h>

int main(){
    char a[20], *p = a;
    char b[20], *q = b;

    //size_t sz = sizeof(line);
    //char pline[sz];
    char *word;
    scanf("%s %s", a, b);


    if (strlen(a) < strlen(b) || strlen(a)-strlen(b) > 2) {
        printf("_");

    }else {
        while (*p !='\0'){
        printf("%c", *p);
        if (*q == '\0') {
            return 0;
        }
        printf("%c", *q);
        p++;
        q++;
    }
    }


    return 0;
}
