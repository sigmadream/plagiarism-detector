#include <stdio.h>
#include <string.h>

int main()
{
    char word1[30]; 
    char word2[30]; 
    scanf("%s %s", word1, word2);

    int len1 = strlen(word1);
    int len2 = strlen(word2);

    if (len1 == len2 || len1 == len2 + 1) {
        char mixed_word[70];
        int i, k = 0;

        for (i = 0; i < len1; i++) {
            mixed_word[k++] = word1[i];
            if (i < len2)
                mixed_word[k++] = word2[i];
        }
        mixed_word[k] = '\0';

        printf("%s\n", mixed_word);
    }
    else {
        puts("_\n");
    }
    
    return 0;
 }
