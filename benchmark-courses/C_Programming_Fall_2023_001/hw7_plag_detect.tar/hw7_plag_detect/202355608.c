#include <stdio.h>
#include <string.h>

int main() {
    char word1[41], word2[41];
    scanf("%s %s", word1, word2);

    int len1 = strlen(word1);
    int len2 = strlen(word2);

    if (len1 == len2 || len1 == len2 + 1) {
        char mix[80];
        int i, k = 0;

        for (i = 0; i < len1; i++) {
            mix[k++] = word1[i];
            if (i < len2) {
                mix[k++] = word2[i];
            }
        }
        mix[k] = '\0';
        printf("%s", mix);
    }
    else {
        printf("_");
    }

    return 0;
}
