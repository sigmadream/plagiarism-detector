#include <stdio.h>
#include <string.h>

int main() {
    char word1[41], word2[41], mixedWord[82];
    scanf("%s %s", word1, word2);

    int len1 = strlen(word1);
    int len2 = strlen(word2);


    if (len1 >= len2 && len1 <= len2 + 1) {

        int i, j, k;
        i = j = k = 0;

        while (i < len1 && j < len2) {
            mixedWord[k++] = word1[i++];
            mixedWord[k++] = word2[j++];
        }


        while (i < len1)
            mixedWord[k++] = word1[i++];
        while (j < len2)
            mixedWord[k++] = word2[j++];

        mixedWord[k] = '\0';

        printf("%s\n", mixedWord);
    } else {

        printf("_\n");
    }

    return 0;
}
