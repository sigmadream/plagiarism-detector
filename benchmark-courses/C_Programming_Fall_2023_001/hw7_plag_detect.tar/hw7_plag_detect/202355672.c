#include <stdio.h>
#include <string.h>

int main()
{
    char first_word[40];
    char sec_word[40];
    int len_fw;
    int len_sw;

    scanf("%s %s", first_word, sec_word);

    len_fw = strlen(first_word);
    len_sw = strlen(sec_word);

    if (len_fw < len_sw) {

        puts("_");
    }
    else {

        for (int i = 0; i < len_fw; i++) {
                printf("%c%c", first_word[i], sec_word[i]);
        }

    }

    return 0;
}
