#include <stdio.h>
#include <string.h>

int main() {
    char word1[40], word2[40], mix[80];

    scanf("%s %s", word1, word2);

    int len1 = strlen(word1);
    int len2 = strlen(word2);

    if ((len1 == len2 || len2 == len1 - 1) && len1 <= 40 && len2 <= 40) {
        int a, b, c;
        a = b = c = 0;

        while (a < len1 && b < len2) {
            mix[c++] = word1[a++];
            mix[c++] = word2[b++];
        }

        while (a < len1) {
            mix[c++] = word1[a++];
        }

        mix[c] = '\0';

        printf("%s\n", mix);
    } else {
        printf("_\n");
    }

    return 0;
}
