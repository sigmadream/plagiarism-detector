#include <stdio.h>
#include <string.h>

int main()
{
    char word1[41];
    char word2[41], mixword[81];
    scanf("%s %s", word1, word2);
    int len1 = strlen(word1);
    int len2 = strlen(word2);

    if((len1 == len2 || len1 == len2 + 1) && len1 <= 40 && len2 <=40) {
        int mix = 0;
        int idx1 = 0, idx2 = 0;

        while (idx1 <len1 || idx2 < len2){
            if(idx1 <len1){
                mixword[mix++] = word1[idx1++];
            }
            if(idx2 <len2){
                mixword[mix++] = word2[idx2++];
            }
        }
        mixword[mix] = '\0';

        printf("%s\n", mixword);
        }
        else{
        printf("_\n");
        }
    return 0;
}
