#include <stdio.h>
#include <string.h>

int main() {
    char word1[41];
    char word2[41];
    char mixed_word[81];

    if (scanf("%40s %40s", word1, word2) != 2) {
        fprintf(stderr, "Error reading input.\n");
        return 1;
    }

    int len1 = strlen(word1);
    int len2 = strlen(word2);

    if (len1 < len2 || len1 > len2 + 1) {
        printf("_\n");
        return 0;
    }
    int i, j;
    for (i = 0, j = 0; i < len1; i++) {
        mixed_word[j++] = word1[i];
        if (i < len2)
            mixed_word[j++] = word2[i];
    }
    mixed_word[j] = '\0';
    printf("%s\n", mixed_word);

    return 0;
}

