#include <stdio.h>
#include <string.h>

int main() {
    char word1[41], word2[41], mixedWord[81];
    
    scanf("%s %s", word1, word2);

    
    if (strlen(word1) == strlen(word2) || strlen(word1) == strlen(word2) + 1) {
        int i, j, k;
        i = j = k = 0;

        while (word1[i] != '\0' || word2[j] != '\0') {
            if (word1[i] != '\0') {
                mixedWord[k++] = word1[i++];
            }
            if (word2[j] != '\0') {
                mixedWord[k++] = word2[j++];
            }
        }

        mixedWord[k] = '\0'; 

        printf("%s\n", mixedWord);
    } else {
        printf("_\n");
    }

    return 0;
}
