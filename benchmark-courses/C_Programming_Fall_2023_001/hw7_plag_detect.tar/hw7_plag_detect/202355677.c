#include <stdio.h>
#include <string.h>
int main(){
    char firstword[40];
    char secword[40];

    scanf("%s %s", firstword, secword);

    int  length1 = strlen(firstword);
    int length2 = strlen(secword);

    if (length1 ==length2 || length1 > length2){
        int i = 0;

        for ( i = 0 ; i < length1 && i < length2 ; i++){

                printf("%c%c", firstword[i], secword[i]); }
        }else {
            printf("_\n");
        }


    return 0;
    }
