#include <stdio.h>
#include <string.h>

int main ()
{
    char word1[100],word2[100], mixedWord[200];



    scanf("%s %s",word1,word2);
    int len1= strlen(word1);
    int len2= strlen(word2);
    if (len1==len2 || len1> len2)

    {
        int i, j = 0;

        for (i=0; i< len1 && j< len2; i++,j++)
        {
            printf ("%c%c",word1[i],word2[j]);
        }
    }
    else
    {
        printf("_");
    }
    return 0;
}
