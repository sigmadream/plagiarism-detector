#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>

int main() {
	//const int MAX_LEN = 100;

	char line[100];

	if (fgets(line, 100, stdin) == NULL)
		return -1;

	char* word = strtok(line, " \n");

	int max_weight = 0;

	do
	{
		int word_max_weight = 0;

		for (size_t i = 0; i < strlen(word); i++)
		{
			int cur_char_weight = word[i] - 'A' + 1;

			if ( 'Z' < word[i]) {
				cur_char_weight -=  32 ;
			}

			word_max_weight += cur_char_weight;
		}

		if (max_weight < word_max_weight)
			max_weight = word_max_weight;

	} while (word = strtok(NULL, " \n"));

	printf("%d", max_weight);

	return 0;
}