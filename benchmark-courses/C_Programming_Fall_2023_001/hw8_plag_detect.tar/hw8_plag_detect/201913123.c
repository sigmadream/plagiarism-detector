#include <stdio.h>
#include <string.h>
#define max 5000
int main(){
    char line[max];
    int weight[100] = {0, };
    int j = 0;
    int max_num = 0;
    if(fgets(line, max, stdin) == NULL)
        return -1;
    char *word = strtok(line, " \n");
    do{
        for(int i = 0; i < strlen(word); i++){
            weight[j] += (toupper(word[i])- 'A') + 1;
        }
        if(max_num < weight[j]){
            max_num = weight[j];
        }
        j++;
    }
    while(word = strtok(NULL, " \n"));

    printf("%d", max_num);
    return 0;
}
