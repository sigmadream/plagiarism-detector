#include <stdio.h>
#include <string.h>

int main() {
    char input[5000]; // Assuming a maximum input length of 5000 characters
    char *word, *saveptr;
    int maxWeight = 0;

    
    fgets(input, sizeof(input), stdin);

    
    word = strtok_r(input, " \n", &saveptr);
    while (word != NULL) {
        int weight = 0;

        for (int i = 0; word[i] != '\0'; i++) {
            char c = toupper(word[i]);
            if (c >= 'A' && c <= 'Z') {
                weight += (int)(c - 'A') + 1; 
            }
        }

        if (weight > maxWeight) {
            maxWeight = weight; 
        }

        word = strtok_r(NULL, " \n", &saveptr);
    }

    printf("%d\n", maxWeight);

    return 0;
}

