#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    const int MAX_CHAR = 50;  // 최대 단어 길이
    const int MAX_WORD = 100; // 최대 단어 개수
    const int MAX_LINE_CHAR = (MAX_CHAR * MAX_WORD) + (MAX_CHAR - 1);

    char line[MAX_LINE_CHAR];
    char string_set[MAX_WORD][MAX_CHAR];

    if (fgets(line, MAX_LINE_CHAR, stdin) == NULL)
        return -1;

    int i = 0; // 반복문에 사용할 단어 인덱스

    char *word = strtok(line, " \n"); // word 변수 선언 및 초기화
    int weight_length = 0;

    do
    {
        if (word != NULL)
        {
            strcpy(string_set[i], word);
            ++weight_length;
            i++;
        }
    } while ((word = strtok(NULL, " \n")));

    // string_set에 저장된 각 단어의 weight를 구해서 배열로 저장하기
    int weight[weight_length]; // 입력받은 모든 단어의 weight를 저장하는 배열
    i = 0;
    while (string_set[i][0] != '\0')
    {
        int j = 0;
        weight[i] = 0;
        while (string_set[i][j] != '\0')
        {
            char tmp = string_set[i][j];
            int askii_a = 'A';
            int askii_tmp = toupper(tmp);
            int ord = askii_tmp - askii_a + 1;
            weight[i] += ord;
            j++;
        }
        i++;
    }

    // 가장 큰 weight를 구한 후 출력하기
    int max = weight[0];
    // int weight_length = sizeof(weight) / sizeof(weight[0]);
    for (int i2 = 1; i2 < weight_length; i2++)
    {
        if (weight[i2] > max)
        {
            max = weight[i2];
        }
    }

    printf("%d\n", max);

    return 0;
}