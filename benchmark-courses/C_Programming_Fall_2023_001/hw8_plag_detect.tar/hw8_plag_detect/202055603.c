#include <stdio.h>
#include <string.h>
#include <ctype.h>


int main(){

	const int MAX_LEN = 100;
	char line[MAX_LEN];
	int max_weight = 0;
	
	if (fgets(line, MAX_LEN, stdin) == NULL){
		return -1;
	}
	
	char *word = strtok(line, " \n");
	
	do {
		int ascii_sum = 0;
		//puts(word);
		for (int i = 0; i<strlen(word);i++) {
			ascii_sum += toupper(word[i]) - 64;
			//printf("ascii part sum word %d, %c = %d\n", i, word[i], word[i]);
		}
		
		if (ascii_sum >= max_weight) {
			max_weight = ascii_sum;
		}
		
		//printf("ascii sum is : %d\n", ascii_sum);
	} while (word = strtok(NULL, " \n"));
	
	printf("%d", max_weight);
	return 0;
}