#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main()
{


    char allInp[10000];

    if(fgets(allInp, 10000, stdin) == NULL)
        return -1;


    char* inp = strtok(allInp," ");

    long bestW = 0;

    do
    {
        long w = 0;

        int i = 0;

        while (inp[i] != 0)
        {
            while (inp[i] == ' ')
                i++;

            if (inp[i] == 0 || inp[i] == '\n')
                break;

            if (inp[i] >= 97)
                inp[i] -= 32;

            w += inp[i] - 'A' + 1;

            i++;
        } 

        bestW = bestW > w ? bestW : w;

    } while (inp = strtok(NULL, " "));

    printf("%ld", bestW);


    return 0;
}
