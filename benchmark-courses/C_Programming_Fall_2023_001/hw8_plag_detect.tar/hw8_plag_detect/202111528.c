#include <stdio.h>
#include <string.h>
#include <ctype.h>

int ordinal(char c)
    {
        return toupper(c) - 'A' +1;
    }

int weight(char *word)
    {
        int result=0;
        for(int i=0; i<strlen(word); i++) {
            result = result + ordinal(word[i]);
        }
        return result;
    }

int main()
{
	const int MAX_LEN=100;
	char line[MAX_LEN];
    char *words[MAX_LEN];
    int numOfwords=0;
    int max=-1;

    if (fgets(line, MAX_LEN, stdin)==NULL)
	    return -1;
	char *word = strtok(line, " \n");

    do {
        words[numOfwords++] = word;
    } while(word=strtok(NULL, " \n"));

    for(int i=0; i<numOfwords; i++) {
        // max 알고리즘
        if(max<weight(words[i])){
            max=weight(words[i]);
        }
    }

    printf("%d\n", max);

    return 0;
}