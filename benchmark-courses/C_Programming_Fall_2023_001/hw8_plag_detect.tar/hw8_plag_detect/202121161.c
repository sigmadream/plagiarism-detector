#include <stdio.h>
#include <string.h>

int main() {
	int ret = 0;
	char s[100];
	fgets(s, sizeof(s), stdin);
	char *ptr = strtok(s, " ");    
	while (ptr != NULL)              
	{
		int i = 0;
		int weight = 0;
    	for (i = 0; i < strlen(ptr); i++) {
    		if ('A' <= ptr[i] && ptr[i] <= 'Z')
    			weight += ptr[i] - 'A' + 1;
    		else if ('a' <= ptr[i] && ptr[i] <= 'z')
    			weight += ptr[i] - 'a' + 1;
		}  
		if (weight > ret) ret = weight;
    	ptr = strtok(NULL, " ");     
	}	
	printf("%d", ret);
}
