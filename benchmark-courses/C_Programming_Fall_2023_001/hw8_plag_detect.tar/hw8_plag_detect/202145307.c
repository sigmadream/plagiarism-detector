#include <stdio.h>
#include <string.h>
#include <ctype.h>  // 包含ctype.h用于字符处理

#define MAX_WORDS 100
#define MAX_WORD_LEN 50

// 计算字符的权重
int calculateWeight(char c) {
    if (isalpha(c)) {  // 如果字符是字母
        c = toupper(c);  // 将字符转换为大写，以实现大小写不敏感
        return (int)(c - 'A' + 1);  // 计算并返回字符的权重
    }
    return 0;  // 如果不是字母，返回0
}

int main() {

    char input[MAX_WORDS * (MAX_WORD_LEN + 1)];
    char words[MAX_WORDS][MAX_WORD_LEN + 1];
//    int weights[MAX_WORDS] = {0};
    int weights[MAX_WORDS];
    int maxWeight = 0;

    if (fgets(input, sizeof(input), stdin) == NULL) {
        return -1;  // 如果读取失败，返回-1
    }

    input[strcspn(input, "\n")] = '\0';  // 移除输入中的换行符并添加字符串终止符

    char *t = strtok(input, " ");
    int wordCount = 0;

    while (t != NULL && wordCount < MAX_WORDS) {
        strcpy(words[wordCount], t);  // 复制单词到words数组中
        int weight = 0;

        for (int i = 0; words[wordCount][i] != '\0'; i++) {
            weight += calculateWeight(words[wordCount][i]);  // 计算单词的权重
        }

        weights[wordCount] = weight;  // 存储单词的权重

        if (weight > maxWeight) {
            maxWeight = weight;  // 更新最大权重值
        }

        wordCount++;  // 增加单词计数
        t = strtok(NULL, " ");  // 获取下一个单词
    }

    printf("%d\n", maxWeight);  // 打印最大权重值

    return 0;
}