#include <stdio.h>
#include <string.h>

int main()
{
	char arr[5500] = { NULL };
	char* word[101];
	int result[101];

	fgets(arr, sizeof(arr), stdin);
	//���๮�� ����
	if (arr[strlen(arr) - 1] == '\n')
	{
		arr[strlen(arr) - 1] = '\0';
	}
	//ù�ܾ� ȹ��
	word[0] = strtok(arr, " ");
	//������ �ܾ�� �迭�� �ֱ�
	int i = 1;
	while (i < 101)
	{
		word[i] = strtok(NULL, " ");
		if (word[i] == NULL)
		{
			word[i] = 0;
			break;
		}
		i++;
	}
	//word�迭 �� ��Ҹ��� ����ġ ����ϱ�
	for (int j = 0; j < i; j++)
	{
		int ga = 0;

		for (int k = 0; k < strlen(word[j]); k++)
		{
			if (word[j][k] >= 97 && word[j][k] <= 122)
			{
				word[j][k] -= 32;
			}
			ga += word[j][k] - 'A' + 1;
		}
		result[j] = ga;
	}

	int max = result[0];
	for (int q = 0; q < i; q++)
	{
		if (max < result[q])
		{
			max = result[q];
		}
	}
	printf("%d", max);
	return 0;
}