#include <stdio.h>
#include <string.h>
#include <ctype.h>

int calculate_weight(const char *word) {
    int weight = 0;
    for (int i = 0; word[i] != '\0'; i++) {
        char c = toupper(word[i]);
        weight += (int)(c - 'A' + 1);
    }
    return weight;
}

int main() {
    char input[500]; // 입력을 저장할 버퍼 (단어 최대 길이 50 * 단어 최대 개수 100 = 5000)
    
    // 표준 입력에서 문자열 읽기
    fgets(input, sizeof(input), stdin);
    
    // 개행 문자 제거
    input[strcspn(input, "\n")] = '\0';

    char *word = strtok(input, " "); // 공백을 기준으로 단어 분리
    int max_weight = 0;

    while (word != NULL) {
        int weight = calculate_weight(word);
        if (weight > max_weight) {
            max_weight = weight;
        }
        word = strtok(NULL, " "); // 다음 단어로 이동
    }

    // 최대 무게 출력
    printf("%d\n", max_weight);

    return 0;
}
