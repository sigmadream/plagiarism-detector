/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>

#define MAX_LEN 5050  // Max length considering 50 char long words with spaces for up to 100 words

int main() {
    char line[MAX_LEN];
    
    if (fgets(line, MAX_LEN, stdin) == NULL) {
        return -1;
    }
    
    int maxWeight = 0;
    
    char *word = strtok(line, " \n");
    while (word != NULL) {
        int currentWeight = 0;
        for (int i = 0; i < strlen(word); i++) {
            if (word[i] >= 'A' && word[i] <= 'Z') {
                currentWeight += word[i] - 'A' + 1;
            } else if (word[i] >= 'a' && word[i] <= 'z') {
                currentWeight += word[i] - 'a' + 1;
            }
        }
        if (currentWeight > maxWeight) {
            maxWeight = currentWeight;
        }

        word = strtok(NULL, " \n");
    }

    printf("%d\n", maxWeight);
    return 0;
}


