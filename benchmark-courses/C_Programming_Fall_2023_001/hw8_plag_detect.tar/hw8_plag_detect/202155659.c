#include <stdio.h>
#include <ctype.h>
#include <string.h>
int i, max = 0, sum = 0;
char c = 'a';
char *word;
char a = 'b';
char line[5000];
int main()
{
	gets(line);
	word = strtok(line, " ");
	do{
		sum = 0;
		for (i = 0; i < strlen(word); i++){
			sum = sum + toupper(word[i]) - 'A' + 1;
		}

		if (sum > max){
			max = sum;
		}
		
	} while (word = strtok(NULL, " "));

	printf("%d\n", max);

	return 0;
}

