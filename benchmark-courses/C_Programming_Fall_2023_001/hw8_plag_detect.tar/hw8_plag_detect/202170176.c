#include <stdio.h>
#include <string.h>

int calculate_word_weight(const char* word) {
    int weight = 0;
    int i;
    int length = strlen(word);

    // Create a new character array to store the modified word
    char modified_word[length + 1];

    // Convert each character to uppercase and store it in modified_word
    for (i = 0; i < length; i++) {
        if (word[i] >= 'a' && word[i] <= 'z') {
            modified_word[i] = word[i] - 'a' + 'A';
        }
        else {
            modified_word[i] = word[i];
        }
    }
    modified_word[length] = '\0'; // Null-terminate the modified word

    // Calculate the weight of the modified word
    for (i = 0; i < length; i++) {
        weight += (int)modified_word[i] - 'A' + 1;
    }

    return weight;
}

int main() {
    char input_line[5000];  // Sufficiently large buffer to read input
    char* word;
    int max_weight = 0;

    // Read input
    fgets(input_line, sizeof(input_line), stdin);

    // Tokenize the input line into words
    word = strtok(input_line, " \n");
    while (word != NULL) {
        int weight = calculate_word_weight(word);
        if (weight > max_weight) {
            max_weight = weight;
        }
        word = strtok(NULL, " \n");
    }

    printf("%d\n", max_weight);

    return 0;
}
