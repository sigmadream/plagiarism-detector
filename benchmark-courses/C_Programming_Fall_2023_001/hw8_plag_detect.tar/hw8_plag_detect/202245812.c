#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_LEN 100

int main()
{
    char line[MAX_LEN];
    int sum[MAX_LEN];
    int count = 0;

    if (fgets(line, MAX_LEN, stdin) == NULL)
        return -1;

    char* word = strtok(line, " \n");
    do {
        //Check if word length is over 50
        if (strlen(word) > 50) {
            printf("The maximum length of the word is 50");
            return -1;
        }

        int sum_ord = 0;
        //Convert lowercase letters to uppercase and Add weights
        for (int i = 0; i < strlen(word); i++) {
            sum_ord += toupper(word[i]) - 'A' + 1;
        }
        //Put the added weights into the set
        sum[count] = sum_ord;
        count++;
    } while (word = strtok(NULL, " \n"));

    //Find maximum value
    int max_value = sum[0];
    for (int j = 0; j < count; j++) {
        if (max_value < sum[j]) {
            max_value = sum[j];
        }
    }
    printf("%d", max_value);

    return 0;
}