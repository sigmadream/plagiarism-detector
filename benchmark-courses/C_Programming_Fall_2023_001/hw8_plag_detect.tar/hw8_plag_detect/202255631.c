#include <stdio.h>
#include <string.h>

int main() {
    char input[1001];
    fgets(input, sizeof(input), stdin);

    char *token = strtok(input, " \n");
    int maxWeight = 0;

    while (token != NULL) {
        int weight = 0;
        for (int i = 0; token[i]; i++) {
            if ((token[i] >= 'a' && token[i] <= 'z') || (token[i] >= 'A' && token[i] <= 'Z')) {
                char uppercaseChar = (token[i] >= 'a' && token[i] <= 'z') ? token[i] - 32 : token[i];
                weight += uppercaseChar - 'A' + 1;
            }
        }
        if (weight > maxWeight) {
            maxWeight = weight;
        }
        token = strtok(NULL, " \n");
    }

    printf("%d\n", maxWeight);
    return 0;
}
