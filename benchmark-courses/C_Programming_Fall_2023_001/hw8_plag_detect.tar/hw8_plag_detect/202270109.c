#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char line[100];
    int weights[100] = {0}; 

    fgets(line, sizeof(line), stdin);

    char *word = strtok(line, " ");
    int word_count = 0;

    while (word != NULL && word_count < 100) {
        int weight = 0;
        for (int i = 0; i < strlen(word); i++) {
            char c = toupper(word[i]); 
            int single_weight = c - 65 + 1;
            weight += single_weight;
        }
        
        weights[word_count] = weight; 
        word_count++;
        word = strtok(NULL, " \n");
    }


    int max = weights[0];
    int max_count = 0;

    for (int i = 1; i < word_count; i++) {
        if (weights[i] > max) {
            max = weights[i];
            max_count = i;
        }
    }

    printf("%d", max);

    return 0;
}

