#include <stdio.h>
#include <string.h>

int ascii_value(char msg[])
{
    int sum = 0;
    
    while (*msg != '\0'){
        if ((int)*msg > 96){
            sum +=  (int)*msg - 32 - 65 + 1;
        }else {
            sum += (int)*msg - 65 + 1;
        }
        msg++;
    }
    return sum;
}

int main()
{
    char words[80];
    int max_num = 0;
    int compared_num;

    while(scanf("%s", words) == 1)
    {
        compared_num = ascii_value(words);
        //printf("%d\n", compared_num);
        if (compared_num > max_num)
        {
            max_num = compared_num;
        }
    }
        
    
    printf("%d", max_num);
        
    return 0;
    
}
