#include <stdio.h>
#include <string.h>

int calculateWeight(char *word) {
    int weight = 0;
    for (int i = 0; word[i]; i++) {
        char c = word[i];
        if (c >= 'a' && c <= 'z') {

            c = c - 'a' + 'A';
        }
        weight += (int)(c - 'A' + 1);
    }
    return weight;
}

int main() {
    char input[500];


    fgets(input, sizeof(input), stdin);

    int maxWeight = 0;


    char *token = strtok(input, " ");
    while (token != NULL) {

        int weight = calculateWeight(token);


        if (weight > maxWeight) {
            maxWeight = weight;
        }

        token = strtok(NULL, " ");
    }

    printf("%d\n", maxWeight);

    return 0;
}
