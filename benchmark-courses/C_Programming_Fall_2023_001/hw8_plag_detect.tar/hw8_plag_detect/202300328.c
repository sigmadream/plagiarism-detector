#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_WORDS 100
#define MAX_WORD_LENGTH 50

int calculateWeight(char *word) {
    int weight = 0;
    for (int i = 0; word[i]; i++) {
        char c = word[i];
        if (islower(c)) {
            c = toupper(c);
        }
        weight += c - 'A' + 1;
    }
    return weight;
}
int main() {
    char input[500];
    if (fgets(input, sizeof(input), stdin) == NULL) {
        fprintf(stderr, "Error reading input.\n");
        return 1;
    }
    char *token = strtok(input, " ");
    int maxWeight = 0;
    while (token != NULL) {
        int weight = calculateWeight(token);
        if (weight > maxWeight) {
            maxWeight = weight;
        }
        token = strtok(NULL, " ");
    }
    printf("%d\n", maxWeight);
    return 0;
}
