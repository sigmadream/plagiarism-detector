#include <stdio.h>
#include <string.h>
#include <ctype.h>

int calculateWeight(char *word) {
    int weight = 0;
    for (int i = 0; word[i]; i++) {
        char c = toupper(word[i]); 
        if (c >= 'A' && c <= 'Z') {
            weight += (int)(c - 'A') + 1;
        }
    }
    return weight;
}

int main() {
    char input[255];
    fgets(input, sizeof(input), stdin);

    int maxWeight = 0;
    char *token;

    token = strtok(input, " ");

    while (token != NULL) {
        int weight = calculateWeight(token);

        if (weight > maxWeight) {
            maxWeight = weight;
        }

        token = strtok(NULL, " ");
    }

    printf("%d\n", maxWeight);

    return 0;
}
