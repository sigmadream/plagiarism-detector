#include <stdio.h>
#include <string.h>

int main() {

    char input[500]; // Assuming the input line can be up to 500 characters
    
    fgets(input, sizeof(input), stdin);

    int maxWeight = 0;
    int currentWeight = 0;

    for (int i = 0; i < strlen(input); i++) {
        char c = input[i];
        if (c == ' ' || c == '\n') {
            // Calculate the weight of the current word
            if (currentWeight > maxWeight) {
                maxWeight = currentWeight;
            }
            currentWeight = 0; // Reset for the next word
        } else {
            // Calculate the weight of the character and add it to the current word weight
            if (c >= 'a' && c <= 'z') {
                c = c - 'a' + 'A'; // Convert to uppercase
            }
            currentWeight += c - 'A' + 1;
        }
    }

    printf("%d\n", maxWeight);

    return 0;
}
