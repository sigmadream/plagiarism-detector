#include <stdio.h>
#include <string.h>

int main()
{
    const int MAX_LEN = 100;
    char line[MAX_LEN];
    int max_weight = 0;


    if (fgets(line, MAX_LEN, stdin) == NULL)
    return -1;

    char *word = strtok(line, " \n");
    do {
        int weight = 0;
        while (*word) {
        char c = *word;
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
            if (c >= 'a') {
                c -= 'a' - 'A';
                }
            weight += c - 'A' + 1;

        }
        word++;
    }
    if (weight > max_weight) {
        max_weight = weight;
    }
    }   while (word = strtok(NULL, " \n"));

    printf("%d", max_weight);


    return 0;

}
