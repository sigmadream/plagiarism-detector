#include <stdio.h>
#include <string.h>


//function declaration for weight_calc to calculcate the weight
int weight_calc(char *word) {
    int weight = 0; //we initialize the weight variable to O in order to store the sum of the weights later on
    for (int i = 0; word[i] != '\0'; i++) { //iteration to check if a character is uppercase or lowercase
        char c = word[i];
        if (c >= 'a' && c <= 'z') {
            c = c - 'a' + 'A';  //we convert the lowercase to uppercase in order to calculate the weight without caring for the case
        }
        weight += (int)c - 'A' + 1; //weight calculation using the formula
    }
    return weight;
}

int main() {
    char input[400];  //create an array of 400 characters maximum to store the input line
    fgets(input, sizeof(input), stdin); //read the input with fgets and stores it in the input array
    char *token = strtok(input, " \n"); //we include '\n' as a delimiter to remove new line characters
    int maxWeight = 0; //variable to store the max weight calculated

    while (token != NULL) { //for each token (= for each word)we calculate its weight
        int wordWeight = weight_calc(token);
        if (wordWeight > maxWeight) {
            maxWeight = wordWeight; //replace current value of maxweight to the current word's weight if higher
        }
        token = strtok(NULL, " \n"); //no more tokens/words
    }

    printf("%d\n", maxWeight); //result printed

    return 0;
}
