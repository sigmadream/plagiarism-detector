//
//  main.c
//  HW4
//
//  Created by Sandoval Reyes Luis Armando on 2023/10/05.
//

#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(int argc, const char * argv[]) {
    char input[200];
    int weights[10];
    int counter = 0;
    int *weights_counter = weights;
    
    fgets(input, 200, stdin);
    
    char *token = strtok(input, " ");
    while (token != NULL){
        int weight = 0;
        int length = (int) strlen(token);
        for (int i = 0; i<length; i++){
            weight = weight + toupper(*token) - 64;
            token++;
            if (*token == '\n'){
                break;
            }
        }
        *weights_counter = weight;
        weights_counter++;
        counter++;
        token = strtok(NULL, " ");
    }
    //finding the largest process
    int maximum = weights[0];
    for(int i = 0; i<counter-1; i++){
        if (maximum <= weights[i+1]){
            maximum = weights[i+1];
        }
    }
    printf("%d", maximum);
    
    
    
    return 0;
}

