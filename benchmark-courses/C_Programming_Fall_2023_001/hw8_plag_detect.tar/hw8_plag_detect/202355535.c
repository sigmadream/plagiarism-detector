#include <stdio.h>
#include <string.h>
#include <ctype.h>

int calculateWeight(const char *word) {
    int weight = 0;
    for (int i = 0; word[i] != '\0'; i++) {
        char c = toupper(word[i]);  // Convert to uppercase
        if (c >= 'A' && c <= 'Z') {
            weight += c - 'A' + 1;  // Calculate weight based on ASCII value
        }
    }
    return weight;
}

int main() {
    char input[500]; 
    int maxWeight = 0;

    fgets(input, sizeof(input), stdin);

    char *word = strtok(input, " ");  // Tokenize input by space

    while (word != NULL) {
        int weight = calculateWeight(word);
        if (weight > maxWeight) {
            maxWeight = weight;
        }
        word = strtok(NULL, " ");  // Move to the next word
    }

    printf("%d\n", maxWeight);

    return 0;
}
