#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char words[5000];
    fgets(words, sizeof(words), stdin);
    int maxWeight = 0;
    char *word = strtok(words, " ");

    while (word != NULL) {
        int weight = 0;
        int i = 0;

        while ( word[i] != '\0') {
            char c = tolower(word[i]);
            weight += c - 'a' +1;
            i++;
        }

        if (weight > maxWeight) {
            maxWeight = weight;
        }

        word = strtok(NULL, " \n"); //\n�� ������ ������ ����
    }

    printf("%d", maxWeight);

    return 0;
}
