#include <stdio.h>
#include <string.h>

int calculate_weight(char c) {
    if (c >= 'a' && c <= 'z')
        return c - 'a' + 1;
    else if (c >= 'A' && c <= 'Z')
        return c - 'A' + 1;
    else
        return 0;
}

int find_max_weight(char *word) {
    int max_weight = 0;
    int len = strlen(word);

    for (int i = 0; i < len; i++) {
        int weight = calculate_weight(word[i]);
        max_weight += weight;
    }

    return max_weight;
}

int main() {
    const int MAX_LEN = 500;
    char line[MAX_LEN];

    if (fgets(line, MAX_LEN, stdin) == NULL)
        return -1;

    char *token = strtok(line, " \n");
    int max_weight = 0;

    while (token != NULL) {
        int weight = find_max_weight(token);
        if (weight > max_weight)
            max_weight = weight;

        token = strtok(NULL, " \n");
    }

    printf("%d\n", max_weight);

    return 0;
}
