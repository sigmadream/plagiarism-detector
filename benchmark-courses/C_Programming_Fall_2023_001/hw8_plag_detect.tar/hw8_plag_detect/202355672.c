#include <stdio.h>
#include <string.h>

int main()
{
    const int MAX_LEN = 50;
    const int MAX_WORD = 100;
    char line[10000];

    int max_weight = 0;

    //Count the number of words
    int count = 1;
    int i =0;

    fgets(line, 10000, stdin);

    for (i = 0; line[i] != '\0'; i++)
    {
        if (line[i] == ' ' && line[i+1] != ' ')
            count++;
    }
    if (count <= MAX_WORD)
    {

        //Extract each word
        char *word = strtok(line, " ");
        while (word != NULL)
        {
            // calculate the weight of the word
            int weight = 0;
            i = 0;
            if (strlen(word) <= MAX_LEN)
            {
                while (word[i] != '\0') {
                    // change lowercase to uppercase
                    if(word[i] >= 'a' && word[i] <= 'z')
                    {
                        weight = weight + word[i] - 'A' + 1 - 32;
                    }
                    else {
                        weight = weight + word[i] - 'A' + 1;
                    }


                    i++;
                }
                if (weight >= max_weight)
                    max_weight = weight;
                word = strtok(NULL, " ");
            }
        }
        printf("%d", max_weight);

    }

    return 0;
}
