#include <stdio.h>
#include <string.h>

int wdweight(char *word) {
    int weight = 0;
    int length = strlen(word);

    for (int i = 0; i < length; i++) {
        char c = word[i];

        if ('a' <= c && c <= 'z') {
            weight += c - 'a' + 1;
        } else if ('A' <= c && c <= 'Z') {
            weight += c - 'A' + 1;
        }
    }

    return weight;
}

int main() {
    char input[500];
    fgets(input, sizeof(input), stdin);

    char *word = strtok(input, " \n");
    int max_weight = 0;

    while (word != NULL) {
        int weight = wdweight(word);
        if (weight > max_weight) {
            max_weight = weight;
        }
        word = strtok(NULL, " \n");
    }

    printf("%d\n", max_weight);

    return 0;
}
