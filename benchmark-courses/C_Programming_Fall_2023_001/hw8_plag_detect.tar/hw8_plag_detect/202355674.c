#include <stdio.h>
#include <string.h>

int main()
{
    int MAX_LEN = 5000,  weight = 0, maxWeight = 0;
    char line[MAX_LEN], c;

    if (fgets(line, MAX_LEN, stdin) == NULL)
        return -1;
    char *word = strtok(line, " ");
    do {
        weight = 0;
        for(int i = 0; i <= strlen(word); i++){
            c = word[i];
            if(c>='A'&&c<='Z')
            {
                weight += ((int)(c) - (int)('A') + 1);
            }
            else if (c>='a'&&c<='z')
            {
                weight += ((int)(c) - (int)('a') + 1);
            }
        }
        if (weight > maxWeight) {
            maxWeight = weight;
        }

    } while (word = strtok(NULL, " "));
    printf("%d\n", maxWeight);
    return 0;
}
