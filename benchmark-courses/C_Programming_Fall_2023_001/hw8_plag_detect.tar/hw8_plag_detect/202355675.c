#include <stdio.h>
#include <string.h>

int calculateWeight(char c) {
    if (c >= 'a' && c <= 'z')
        return c - 'a' + 1;
    else if (c >= 'A' && c <= 'Z')
        return c - 'A' + 1;
    else
        return 0;
}

int calculateWordWeight(const char *word) {
    int weight = 0;
    size_t len = strlen(word);

    for (size_t i = 0; i < len; i++) {
        weight += calculateWeight(word[i]);
    }

    return weight;
}

int main() {
    char input[255];
    fgets(input, sizeof(input), stdin);

    char *word = strtok(input, " \n");
    int maxWeight = 0;

    while (word != NULL) {
        int weight = calculateWordWeight(word);
        if (weight > maxWeight)
            maxWeight = weight;

        word = strtok(NULL, " \n");
    }

    printf("%d\n", maxWeight);

    return 0;
}

