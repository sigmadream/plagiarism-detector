#include <stdio.h>
#include <string.h>

int calculateWeight(const char *word) {
    int weight = 0;
    while (*word) {
        if (*word >= 'a' && *word <= 'z') {
            weight += *word - 'a' + 1;
        } else if (*word >= 'A' && *word <= 'Z') {
            weight += *word - 'A' + 1;
        }
        word++;
    }
    return weight;
}

int main() {
    char line[500];

    if (fgets(line, sizeof(line), stdin) == NULL) {
        return -1;
    }

    char *word = strtok(line, " \n");
    int maxWeight = 0;

    while (word != NULL) {
        int weight = calculateWeight(word);
        if (weight > maxWeight) {
            maxWeight = weight;
        }
        word = strtok(NULL, " \n");
    }

    printf("%d\n", maxWeight);

    return 0;
}
