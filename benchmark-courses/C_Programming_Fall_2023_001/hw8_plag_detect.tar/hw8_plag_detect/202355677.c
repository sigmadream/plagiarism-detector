#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
    const int MAX_LEN = 50;
    const char word[100];
    int max_weight = 0;

    fgets(word, 100, stdin);
    char *input = strtok(word," ");

    while (input != NULL)
    {
        int weight = 0;
        int i = 0;
        char c;
        while (input[i]!= '\0')
        {
            char c = toupper(input[i]);
            if ( c >= 'A' && c <= 'Z')
            {
                weight += c - 'A'+ 1;
            }
            i++;
        }
        if (weight >= max_weight)
        {

            max_weight = weight;
        }
        input = strtok(NULL, " ");

    }
    printf("%d\n", max_weight);
    return 0;
}
