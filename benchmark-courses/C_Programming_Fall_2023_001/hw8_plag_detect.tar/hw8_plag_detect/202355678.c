#include <stdio.h>
#include <string.h>

int main() {
    const int MAX_LEN = 50;
    const int MAX_WORD = 100;
    char line[10000];

    int max_weight = 0;
    int count = 1;
    int i = 0;

    fgets(line, sizeof(line), stdin);

    char *word = strtok(line, " \n");

    while (word != NULL) {
        if (count <= MAX_WORD && strlen(word) <= MAX_LEN) {
            int weight = 0;
            for (i = 0; word[i] != '\0'; i++) {
                char c = tolower(word[i]);
                if (isalpha(c)) {
                    weight += c - 'a' + 1;
                }
            }

            if (weight >= max_weight) {
                max_weight = weight;
            }
        }

        count++;

        word = strtok(NULL, " \n");
    }

    if (count <= MAX_WORD)  {
        printf("%d\n", max_weight);
    }

    return 0;
}
