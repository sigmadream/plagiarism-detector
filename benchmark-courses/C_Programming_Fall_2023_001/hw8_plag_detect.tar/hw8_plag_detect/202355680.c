#include <stdio.h>
#include <string.h>

int main()
{
	char line[50100];
	fgets(line, 50100, stdin);
	char *word = strtok(line, " \n");
	int max_sum = 0;
	do {
		int sum = 0;
		for(int i = 0; i < strlen(word); ++i) {
			if('a' <= word[i] && word[i] <= 'z') {
				sum += word[i] - 'a' + 1;
			}
			else {
				sum += word[i] - 'A' + 1;
			}
		}
		if(max_sum < sum) {
			max_sum = sum;
		}
	} while(word = strtok(NULL, " \n"));
	printf("%d", max_sum);
	return 0;
}
