#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define MAX_WORDS 100
#define MAX_WORD_LENGTH 50

int main() {
    char words[MAX_WORDS][MAX_WORD_LENGTH + 1];
    char input[MAX_WORDS * (MAX_WORD_LENGTH + 1) + 1];
    int weights[MAX_WORDS];
    int maxWeight = 0;

    if (fgets(input, sizeof(input), stdin) == NULL) {
        fprintf(stderr, "Error reading input\n");
        return 1;
    }

    int wordCount = 0;
    char *token = strtok(input, " \n");

    while (token != NULL && wordCount < MAX_WORDS) {
        int weight = 0;
        for (int i = 0; token[i] != '\0'; i++) {
            weight += tolower(token[i]) - 'a' + 1;
        }

        strcpy(words[wordCount], token);
        weights[wordCount] = weight;

        if (weight > maxWeight) {
            maxWeight = weight;
        }

        wordCount++;
        token = strtok(NULL, " \n");
    }

    printf("%d\n", maxWeight);

    return 0;
}
