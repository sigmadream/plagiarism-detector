#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <math.h>

int isVowel(char x) {
	if ('Z' < x) {
		x -= 32;
	}

	return x == 'A' || x == 'E' || x == 'I' || x == 'O' || x == 'U';
}

int main() {
	char word1[41];
	char word2[41];

	scanf("%40s", word1);
	scanf("%40s", word2);

	int x1 = 0, y1 = 0;

	for (size_t i = 0; i < 40; i++)
	{
		if (word1[i] == NULL) {
			break;
		}

		if (isVowel(word1[i])) {
			x1++;
		}
		else {
			y1++;
		}
	}
	int x2 = 0, y2 = 0;

	for (size_t i = 0; i < 40; i++)
	{
		if (word2[i] == NULL) {
			break;
		}

		if (isVowel(word2[i])) {
			x2++;
		}
		else {
			y2++;
		}
	}

	//printf("%d,%d,%d,%d\n", x1, y1, x2, y2);

	double dist = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
	printf("%.3lf", dist);

	return 0;
}