#include <stdio.h>
#include <math.h>
#include <ctype.h>
#define max 40
char vowel[10] = {'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O',' U'};
void spot(char *, int *, int *);
int main(){
    char fir[max];
    char sec[max];
    int x1, y1;
    int x2, y2;
    scanf("%39s",fir);
    scanf("%39s",sec);

    spot(fir, &x1, &y1);
    spot(sec, &x2, &y2);

    double sum = (pow(x2-x1, 2) + pow(y2-y1, 2));
    printf("%.3f", sqrt(sum));
    return 0;
}

void spot(char *str, int *x, int *y){
    int temp_x = 0;
    int temp_y = 0;
    int boolean = 0;
    for(int i = 0; isalpha(str[i]) > 0; i++){
        for(int j = 0; j<10; j++){
            if(str[i] == vowel[j]){
                temp_x++;
                boolean = 1;
                break;
            }
        }
        if(boolean == 0){
            temp_y++;
        }
        boolean = 0;
    }
    *x = temp_x;
    *y = temp_y;
}
