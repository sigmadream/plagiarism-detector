#include <stdio.h>
#include <string.h>
#include <math.h>

int isVowel(char c){
    char vowel[10] = "aeuioAEUIO";
    for (int i = 0; i < 10; i++){
        if (c == vowel[i]) return 1;
    }
    return 0;
}

int main(){
    char firstStr[41], secondStr[41];
    scanf("%40s",firstStr);
    scanf("%40s",secondStr);

    int fx = 0 , fy = 0;
    int sx = 0, sy = 0;

    size_t flen = strlen(firstStr);
    for (int i = 0; i < flen; i++){
        if (isVowel(firstStr[i]) == 1 )
            fx ++;
        else
            fy ++;
    }

    size_t slen = strlen(secondStr);
    for (int i = 0; i < slen; i++){
        if (isVowel(secondStr[i]) == 1 )
            sx ++;
        else
            sy ++;
    }

//    printf("%d %d",fx, fy);
//    printf("%d %d",sx, sy);

    double sqsum = pow((fx - sx),2) + pow((fy - sy),2);
    printf("%0.3f",sqrt(sqsum));

    return 0;
}

