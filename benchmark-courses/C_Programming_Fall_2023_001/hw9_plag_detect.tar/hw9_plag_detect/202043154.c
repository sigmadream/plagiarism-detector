#include <stdio.h>
#include <math.h>
#include <string.h>

int isVowel(char c) {
    // Check if a character is a vowel
    return strchr("AEIOUaeiou", c) != NULL;
}

void calculateCoordinates(const char *word, int *x, int *y) {
    *x = 0;
    *y = 0;

    for (int i = 0; word[i] != '\0'; i++) {
        if (isVowel(word[i])) {
            (*x)++;
        } else if ((word[i] >= 'A' && word[i] <= 'Z') || (word[i] >= 'a' && word[i] <= 'z')) {
            (*y)++;
        }
    }
}

int main() {
    char word1[41], word2[41];
    fgets(word1, 40, stdin);
    fgets(word2, 40, stdin);

    int x1, y1, x2, y2;

    calculateCoordinates(word1, &x1, &y1);
    calculateCoordinates(word2, &x2, &y2);

    double distance = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    printf("%.3lf\n", distance);

    return 0;
}
