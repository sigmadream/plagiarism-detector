#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
//#include <stdbool.h>

int main()
{
    char fir_char[41], sec_char[41];
    int x_1 = 0, y_1 = 0, x_2 = 0, y_2 = 0;
    char vowel[5] = "AEIOU";
    scanf("%hhs",&fir_char);
    scanf("%hhs",&sec_char);
    for (int i = 0; i < 41; i++){
        int flag = 0;
        char c = toupper(fir_char[i]);
        if (c == '\0')
            break;

        for (int j = 0; j<5; j++){
            if (c == vowel[j])
                flag = 1;
        }
        if (flag == 1)
            x_1++;
        else
            y_1++;

    }

    for (int i = 0; i < 41; i++){
        int flag = 0;
        char c = toupper(sec_char[i]);
        if (c == '\0')
            break;

        for (int j = 0; j<5; j++){
            if (c == vowel[j])
                flag = 1;
        }
        if (flag == 1)
            x_2++;
        else
            y_2++;

    }
    double sqsum = (x_2 - x_1)*(x_2 - x_1) + (y_2 - y_1)*(y_2 - y_1);

    //printf("x1x2 = %d,%d , y1y2 = %d,%d\n", x_1,x_2,y_1,y_2);
    printf("%.3f", sqrt(sqsum));
    return 0;
}
