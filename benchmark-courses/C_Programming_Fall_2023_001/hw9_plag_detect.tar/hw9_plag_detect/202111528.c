#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
    
    char word1[40], word2[40];

    scanf("%s %s", &word1, &word2);
    
    int len1 = strlen(word1);
    int len2 = strlen(word2);

    int numOfvowel1=0, numOfconson1=0;
    int numOfvowel2=0, numOfconson2=0;

    for(int i=0; i<len1; i++) {
        if(word1[i]=='a' || word1[i]=='e' || word1[i]=='i' || word1[i]=='o' || word1[i]=='u' ||
        word1[i]=='A' || word1[i]=='E' || word1[i]=='I' || word1[i]=='O' || word1[i]=='U')
        numOfvowel1 += 1;
    }

    for(int i=0; i<len2; i++) {
        if(word2[i]=='a' || word2[i]=='e' || word2[i]=='i' || word2[i]=='o' || word2[i]=='u' ||
        word2[i]=='A' || word2[i]=='E' || word2[i]=='I' || word2[i]=='O' || word2[i]=='U')
        numOfvowel2 += 1;
    }

    numOfconson1 = strlen(word1) - numOfvowel1;
    numOfconson2 = strlen(word2) - numOfvowel2;

    double sqsum = pow(fabs(numOfvowel1-numOfvowel2), 2) + pow(fabs(numOfconson1-numOfconson2), 2);
    double result = sqrt(sqsum);

    printf("%.3lf\n", result);

    return 0;
}