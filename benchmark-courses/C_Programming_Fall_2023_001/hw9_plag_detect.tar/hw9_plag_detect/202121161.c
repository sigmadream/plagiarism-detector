#include <stdio.h>
#include <math.h>
#include <stdbool.h>

bool isVowel(char c) {
	char vowel[5] = {'A', 'E', 'I', 'O', 'U'};
	int i;
	for (i = 0; i < 5; i++) {
		if (c == vowel[i] || c == vowel[i] + ('a' - 'A'))
			return true;
	}
	return false;
}

int getX(char* s) {
	int i;
	int ret = 0;
	for (i = 0; i < 41; i++) {
		if (s[i] == NULL)
			break;
		if (isVowel(s[i]))
			ret++; 
	}
	return ret;
}

int getY(char* s) {
	int i;
	int ret = 0;
	for (i = 0; i < 41; i++) {
		if (s[i] == NULL)
			break;
		if (!isVowel(s[i]))
			ret++; 
	}
	return ret;
}

int main() {
	char w1[41], w2[41];
	scanf("%50s %50s", &w1, &w2);
	double x1, x2, y1, y2;
	x1 = getX(w1);
	x2 = getX(w2);
	y1 = getY(w1);
	y2 = getY(w2);
	double answer = sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
	printf("%.3lf", answer);
}
