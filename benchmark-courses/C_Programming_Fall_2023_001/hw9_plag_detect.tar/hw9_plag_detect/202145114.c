#include <stdio.h>
#include <math.h>
#include <ctype.h>

void count_vowels_consonants(const char *word, int *vowels, int *consonants) {
    *vowels = 0;
    *consonants = 0;

    for (int i = 0; word[i] != '\0'; i++) {
        char letter = tolower(word[i]);
        if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u') {
            (*vowels)++;
        } else if (isalpha(letter)) {
            (*consonants)++;
        }
    }
}

int main() {
    char word1[41];
    char word2[41];

    scanf("%s", word1);

    scanf("%s", word2);

    int x1, y1, x2, y2;
    count_vowels_consonants(word1, &x1, &y1);
    count_vowels_consonants(word2, &x2, &y2);

    double distance = sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));

    printf("%.3lf\n", distance);

    return 0;
}
