#include <stdio.h>
#include <string.h>
#include <math.h>

int count_vowels_and_consonants(const char* word, int* vowels, int* consonants) {
    *vowels = 0;
    *consonants = 0;
    
    for (int i = 0; word[i] != '\0'; i=i+1) {
        char ch = word[i];
        if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) {
            if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' || ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                (*vowels)++;
            } else {
                (*consonants)++;
            }
        }
    }
    return 0;
}

double calculate_distance(const char* word1, const char* word2) {
    int x1, y1, x2, y2;
    count_vowels_and_consonants(word1, &x1, &y1);
    count_vowels_and_consonants(word2, &x2, &y2);
    
    double distance = sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));
    return distance;
}

int main() {
    char word1[41], word2[41];
    scanf("%s", word1);
    scanf("%s", word2);

    double distance = calculate_distance(word1, word2);
    printf("%.3lf\n", distance);

    return 0;
}
