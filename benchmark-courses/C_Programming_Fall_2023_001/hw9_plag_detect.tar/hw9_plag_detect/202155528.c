#include<stdio.h>
#include<math.h>

double Distance(int n1, int n2, int n3, int n4)
{
	int X = n1 - n3;
	int Y = n2 - n4;
	return sqrt(X *X + Y *Y);
}



int main(void)
{
	char farr[45];
	char sarr[45];
	int x = 0, y = 0;
	int a = 0, b = 0;

	scanf("%s", farr);
	scanf("%s", sarr);

	int len1,len2;
	for (int j = 0; j < 45; j++)
	{
		if (farr[j] == 0)
		{
			len1 = j;
			break;
		}
	}
	for (int j = 0; j < 45; j++)
	{
		if (sarr[j] == 0)
		{
			len2 = j;
			break;
		}
	}

	for (int i=0; i <len1; i++)
	{
		if (farr[i] == 'A' || farr[i] == 'E' || farr[i] == 'I' || farr[i] == 'O' || farr[i] == 'U' || farr[i] == 'a' || farr[i] == 'e' || farr[i] == 'i' || farr[i] == 'o' || farr[i] == 'u')
		{
			x++;
		}
		else
		{
			y++;
		}
	}
	for (int i=0; i < len2; i++)
	{
		if (sarr[i] == 'A' || sarr[i] == 'E' || sarr[i] == 'I' || sarr[i] == 'O' || sarr[i] == 'U' || sarr[i] == 'a' || sarr[i] == 'e' || sarr[i] == 'i' || sarr[i] == 'o' || sarr[i] == 'u')
		{
			a++;
		}
		else
		{
			b++;
		}
	}
	double result = Distance(x, y, a, b);
	printf("%.3lf\n", result);
	return 0;
}
