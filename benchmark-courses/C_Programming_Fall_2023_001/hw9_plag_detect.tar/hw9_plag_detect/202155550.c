#include <stdio.h>
#include <math.h>

int main(void) {
  char s1[41];
  char s2[41];
  int len1 = 0;
  int len2 = 0;
  int vow1 = 0;
  int con1 = 0;
  int vow2 = 0;
  int con2 = 0;
  scanf("%s", s1);
  scanf("%s", s2);

  while(1){
    if(s1[len1] == '\0'){
      break;
    }
    else{
      len1++;
    }
  }
  while(1){
    if(s2[len2] == '\0'){
      break;
    }
    else{
      len2++;
    }
  }
for(int i =0;i<len1;i++){
  if(s1[i] == 'a'|| s1[i] == 'e'||s1[i] == 'o'||s1[i] == 'u'||s1[i] == 'i')  {
    vow1++;
  }
  else{
    con1++;
  }
  
}
  for(int k =0;k<len2;k++){
  if(s2[k] == 'a'|| s2[k] == 'e'||s2[k] == 'o'||s2[k] == 'u'||s2[k] == 'i')  {
    vow2++;
  }

  else{
    con2++;
  }
}

int disc = con1 - con2;
  if(disc <0){
    disc = -disc;
  }
int disv = vow1 - vow2;
   if(disv <0){
    disv = -disv;
  }
  
printf("%.3f", sqrt(disc*disc+disv*disv));


  return 0;
}