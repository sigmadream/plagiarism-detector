#include <stdio.h>
#include <math.h>
#include <string.h>

double calculate_distance(int x1, int y1, int x2, int y2) {
    return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}

void count_vowels_and_consonants(const char *word, int *num_mo, int *num_ja) {
    *num_mo = 0;
    *num_ja = 0;
    int len = strlen(word);
    const char *mo = "AEIOUaeiou";
    
    for (int i = 0; i < len; i++) {
        if (strchr(mo, word[i])) {
            (*num_mo)++;
        } else if ((word[i] >= 'A' && word[i] <= 'Z') || (word[i] >= 'a' && word[i] <= 'z')) {
            (*num_ja)++;
        }
    }
}


int main() {
    char word1[41], word2[41];
    int x1, y1, x2, y2;
    
    scanf("%s", word1);
    scanf("%s", word2);
    

    int num_mo1, num_ja1, num_mo2, num_ja2;
    count_vowels_and_consonants(word1, &num_mo1, &num_ja1);
    count_vowels_and_consonants(word2, &num_mo2, &num_ja2);
    
    x1 = num_mo1;
    y1 = num_ja1;
    x2 = num_mo2;
    y2 = num_ja2;
    
  
    double distance = calculate_distance(x1, y1, x2, y2);
    
    printf("%.3lf\n", distance);
    
    return 0;
}