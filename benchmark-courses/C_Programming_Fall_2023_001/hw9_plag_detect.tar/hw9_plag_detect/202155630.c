/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
    char word1[41], word2[41];
    int vowels1 = 0, consonants1 = 0, vowels2 = 0, consonants2 = 0;

    // Read the words
    scanf("%40s", word1);
    scanf("%40s", word2);

    // Calculate vowels and consonants for word1
    for(int i = 0; word1[i] != '\0'; i++) {
        char c = word1[i];
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || 
            c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            vowels1++;
        } else {
            consonants1++;
        }
    }

    // Calculate vowels and consonants for word2
    for(int i = 0; word2[i] != '\0'; i++) {
        char c = word2[i];
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || 
            c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            vowels2++;
        } else {
            consonants2++;
        }
    }

    // Calculate the distance
    double dist = sqrt((vowels2 - vowels1)*(vowels2 - vowels1) + (consonants2 - consonants1)*(consonants2 - consonants1));

    // Print the distance rounded to three decimal places
    printf("%.3lf\n", dist);

    return 0;
}
