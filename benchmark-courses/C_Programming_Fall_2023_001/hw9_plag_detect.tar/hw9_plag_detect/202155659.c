#include <stdio.h>
#include <math.h>

int myfun(int, int, int, int);

int main()
{
    int x1 = 0, y1 = 0, x2 = 0, y2 = 0, i, j;
    char w1[100];
    char w2[100];
    scanf("%s", w1);
    for (i = 0; w1[i] != '\0'; i++)
    {
        char ch = tolower(w1[i]); // Convert the character to lowercase for easier checking

        if (isalpha(ch))
        {
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
            {
                x1++;
            }
            else
            {
                y1++;
            }
        }
    }
    scanf("%s", w2);
    for (j = 0; w2[j] != '\0'; j++)
    {

        char c = tolower(w2[j]); // Convert the character to lowercase for easier checking
        if (isalpha(c))
        {

            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
            {
                x2++;
            }
            else
            {
                y2++;
            }
        }
    }

    myfun(x1, y1, x2, y2);

    return 0;
}

int myfun(int x1, int y1, int x2, int y2)
{
    double distance;

    // Calculate the distance using the formula
    distance = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));

    // Print the distance
    printf("%.3lf", distance);

    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}
