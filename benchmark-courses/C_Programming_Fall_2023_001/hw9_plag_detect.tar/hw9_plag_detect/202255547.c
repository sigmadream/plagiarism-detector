#include <stdio.h>
#include <math.h>

int str_len(char c[]){
    int i=0;
    while(c[i] != '\0'){
        i++;
    }
    return i;
}

double distance(int x1,int y1,int x2, int y2){
    int p_x = pow((x2-x1),2);
    int p_y = pow((y2-y1),2);

    double d = sqrt(p_x + p_y);
    return d;
}

int main(){
    char c1[255];
    char c2[255];
    scanf("%s",c1);
    scanf("%s",c2);
    int x1,y1 = 0;
    int x2,y2 = 0;

    for(int i=0;i<str_len(c1);i++){
        if(c1[i] == 'a' || c1[i] == 'e' || c1[i] == 'i' || c1[i] == 'o' || c1[i] == 'u'|| c1[i] == 'A' || c1[i] == 'E' || c1[i] == 'I' || c1[i] == 'O' || c1[i] == 'U'){
            x1++;
        }
        else{
            y1++;
        }
    }

    for(int i=0;i<str_len(c2);i++){
        if(c2[i] == 'a' || c2[i] == 'e' || c2[i] == 'i' || c2[i] == 'o' || c2[i] == 'u'|| c2[i] == 'A' || c2[i] == 'E' || c2[i] == 'I' || c2[i] == 'O' || c2[i] == 'U'){
            x2++;
        }
        else{
            y2++;
        }
    }
    double d = distance(x1,y1,x2,y2);
    printf("%.3lf",d);
    return 0;
}
