#include <stdio.h>
#include <math.h>

int count_v(char *word) { //function to calculate vowels 
    int count = 0;
    while (*word != '\0') {
        char c = *word;
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' ||
            c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            count++;
        }
        word++;
    }
    return count;
}

int main() {
    char word1[41], word2[41]; //max length of words is 40 
    
    scanf("%40s", word1); //reading 2 words 
    scanf("%40s", word2);
    
    int x1 = count_v(word1);
    int y1 = 0;
    while (word1[y1] != '\0') {
        y1++;
    }
    y1 -= x1;
    
    int x2 = count_v(word2);
    int y2 = 0;
    while (word2[y2] != '\0') {
        y2++;
    }
    y2 -= x2;
     
 
    double distance = sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2)); //formula of calculating distance
    
    printf("%.3lf\n", distance);
    
    return 0;
}
