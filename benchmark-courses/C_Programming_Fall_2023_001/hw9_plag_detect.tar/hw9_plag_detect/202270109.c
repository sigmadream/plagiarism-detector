#include <stdio.h>
#include <math.h>



double cartesianDistance(int x1, int y1, int x2, int y2){
    double distance = sqrt(pow(x2-x1,2)+pow(y2-y1,2));
    return distance;
}

int main(){
    int x1 = 0;
    int y1 = 0;
    int x2 = 0;
    int y2 = 0;

    char first[45];
    scanf("%s", first);

    char second[45];
    scanf("%s", second);

    int len1, len2;
    for (int j = 0; j<45; j++){
        if (first[j]==0){
            len1=j;
            break;
        }
    }

    for (int j = 0; j<45; j++){
        if (second[j]==0){
            len2=j;
            break;
        }
    }

    for (int i=0;  i<len1; i++){
        if(first[i] == 'a' || first[i] == 'e' || first[i] == 'i'
                || first[i] == 'o' || first[i] == 'u' || first[i] == 'A'
                || first[i] == 'E' || first[i] == 'I' || first[i] == 'O'
                || first[i] == 'U'){
                    x1++;
                }
                else{
                    y1++;
                }
    }

    for (int i=0;  i<len2; i++){
        if(second[i] == 'a' || second[i] == 'e' || second[i] == 'i'
                || second[i] == 'o' || second[i] == 'u' || second[i] == 'A'
                || second[i] == 'E' || second[i] == 'I' || second[i] == 'O'
                || second[i] == 'U'){
                    x2++;
                }
                else{
                    y2++;
                }

    }
    
    printf("%0.3lf", cartesianDistance(x1, y1, x2, y2));


    return 0;
}