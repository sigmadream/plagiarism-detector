#include <stdio.h>
#include <string.h>
#include <math.h>

int count_vwls(char[]);
int count_csnts(char[]);
double calc_dist(int, int, int, int);

int main()
{
    char   word[41]; 
    size_t sz = sizeof word;

    scanf("%40s", word);
    int x1 = count_vwls(word);
    int y1 = count_csnts(word);
    scanf("%40s", word);
    int x2 = count_vwls(word);
    int y2 = count_csnts(word);
    double d = calc_dist(x1, y1, x2, y2);
    printf("%.3f\n", d);

    return 0;
}

int count_vwls(char p[]) {
    int cnt = 0;
    for (; *p; p++) {
        if (strchr("AEIOUaeiou", *p))
            cnt++;
    }
    return cnt;
}

int count_csnts(char p[]) {
    return strlen(p) - count_vwls(p);
}

double calc_dist(int x1, int y1, int x2, int y2) {
    double sqsum = (x1 - x2) * (x1 - x2);
    sqsum += (y1 - y2) * (y1 - y2);
    return sqrt(sqsum);
}

