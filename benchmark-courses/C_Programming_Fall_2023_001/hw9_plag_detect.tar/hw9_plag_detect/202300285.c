#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
    char word1[41];
    char word2[41];

    scanf("%s", word1);
    scanf("%s", word2);

    int x1 = 0;
    int y1 = 0;
    for (int i = 0; word1[i]; i++) {
        if (strchr("AEIOUYaeiouy", word1[i])) {
            x1++;
        } else {
            y1++;
          }
    }

    int x2 = 0;
    int y2 = 0;
    for (int i = 0; word2[i]; i++) {
        if (strchr("AEIOUYaeiouy", word2[i])) {
            x2++;
        } else {
            y2++;
          }
    }

    double result = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    printf("%.3lf\n", result);

    return 0;
}
