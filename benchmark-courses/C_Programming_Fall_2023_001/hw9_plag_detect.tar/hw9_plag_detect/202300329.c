#include <stdio.h>
#include <math.h>
#include <ctype.h>

double calculateDistance(int x1, int y1, int x2, int y2) {
    return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

void countCharacters(char word[], int *vowels, int *consonants) {
    *vowels = 0;
    *consonants = 0;
    for (int i = 0; word[i] != '\0'; i++) {
        char c = tolower(word[i]);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            (*vowels)++;
        } else if (c >= 'a' && c <= 'z') {
            (*consonants)++;
        }
    }
}

int main() {
    char word1[41], word2[41];
    int vowels1, consonants1, vowels2, consonants2;

    scanf("%s", word1);
    scanf("%s", word2);

    countCharacters(word1, &vowels1, &consonants1);
    countCharacters(word2, &vowels2, &consonants2);

    double dist = calculateDistance(vowels1, consonants1, vowels2, consonants2);
    printf("%.3f\n", dist);

    return 0;
}
