#include <stdio.h>
#include <string.h>
#include <math.h>

int dist_calc(int xb, int xa, int yb, int ya){

    double x_diff = (xb - xa);
    double y_diff = (yb - ya);
    double two = 2;

    double x_diff_pow = pow(x_diff, two);
    double y_diff_pow = pow(y_diff, two);

    double diff_sum = x_diff_pow + y_diff_pow;
    double result = sqrt(diff_sum);

    printf("%.3f\n", result);

    return result;
}

int main()
{

char word1[41]; //40 character word limit
char word2[41]; //40 character word limit
int vowel1 = 0, consonant1 = 0, vowel2 = 0, consonant2 =0;

if (scanf("%40s %40s", word1, word2) != 2) {
        fprintf(stderr, "Invalid input format\n"); //error message if the user inputs more or less than two words
        //(ex: HELLO WORLD AGAIN will give this error message)
        return 1;
        }

size_t len1 = strlen(word1);
size_t len2 = strlen(word2);

for (int i = 0; i < len1; i++) {
        char c = tolower(word1[i]);
        if (c >= 'a' && c <= 'z') {
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                vowel1++;
            } else {
                consonant1++;
            }
        }
    }

for (int i = 0; i < len2; i++) {
        char c = tolower(word2[i]);
        if (c >= 'a' && c <= 'z') {
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                vowel2++;
            } else {
                consonant2++;
            }
        }
    }

double resultcalc = dist_calc(vowel2,vowel1,consonant2,consonant1);

 return 0;
 }
