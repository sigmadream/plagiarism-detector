#include <stdio.h>
#include <math.h>
#include <string.h>

int CountVowels(const char word[]) {
    int x = 0;

    for (int i = 0; word[i] != '\0'; i++) {
        char c = word[i];
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
            if (strchr("aeiouAEIOU", c)) {
                x++;
            }
        }
    }

    return x;
}

int CountConsonants(const char word[]) {
    int y = 0;

    for (int i = 0; word[i] != '\0'; i++) {
        char c = word[i];
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
            if (!strchr("aeiouAEIOU", c)) {
                y++;
            }
        }
    }

    return y;
}

int main() {
    char word1[41];
    char word2[41];
    scanf("%s", word1);
    scanf("%s", word2);

    int x1 = CountVowels(word1);
    int y1 = CountConsonants(word1);
    int x2 = CountVowels(word2);
    int y2 = CountConsonants(word2);

    double distance = sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));

    printf("%.3lf\n", distance);

    return 0;
}
