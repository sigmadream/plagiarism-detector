//
//  main.c
//  Lab5
//
//  Created by Sandoval Reyes Luis Armando on 2023/10/12.
//

#include <stdio.h>
#include <ctype.h>
#include <math.h>

int main(int argc, const char * argv[]) {
    char word1[100]; char *pointer1 = word1;
    char word2[100]; char *pointer2 = word2;
    int x1=0; int y1=0;
    int x2=0; int y2=0;
    float distance = 0;
    
    scanf("%s", word1);
    scanf("%s", word2);
    
    //65-90; 97-122;
    
    
    while((*pointer1>=65 && *pointer1<=90)||((*pointer1>=97 && *pointer1<=122))){
        if ((toupper(*pointer1) == 'A')||(toupper(*pointer1) == 'E')||(toupper(*pointer1) == 'I')||(toupper(*pointer1) == 'O')||(toupper(*pointer1) == 'U'))
        {
            x1++;
        }
        else{
            y1++;
        }
        pointer1++;
    }
    
    while((*pointer2>=65 && *pointer2<=90)||((*pointer2>=97 && *pointer2<=122))){
        if ((toupper(*pointer2) == 'A')||(toupper(*pointer2) == 'E')||(toupper(*pointer2) == 'I')||(toupper(*pointer2) == 'O')||(toupper(*pointer2) == 'U'))
        {
            x2++;
        }
        else{
            y2++;
        }
        pointer2++;
    }
   
    distance = sqrt(pow((x2-x1),2)+pow((y2-y1),2));
    printf("%.3f", (float)distance);
    
    return 0;
}
