#include <stdio.h>
#include <string.h>
#include <math.h>

int main()
{
    char word1[41];
    char word2[41];

    scanf("%s\n%s", word1, word2);


    int x1 = 0, x2 = 0, y1 = 0, y2 = 0;

    for (int i = 0; i < 41; ++i) {
        char c = word1[i];
        if (c == '\0') {
            break;
        }
        else
            if (c == 'a' || c =='e' || c == 'i' || c == 'o' || c =='u' || c == 'A' || c =='E' || c == 'I' || c == 'O' || c =='U')
                x1++;
            else
                y1++;

    }

    for (int i = 0; i < 41; ++i) {
        char c = word2[i];
        if (c == '\0') {
            break;
        }
        else
            if (c == 'a' || c =='e' || c == 'i' || c == 'o' || c =='u' || c == 'A' || c =='E' || c == 'I' || c == 'O' || c =='U')
                x2++;
            else
                y2++;

    }

    double sqsum = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
    printf("%.3f", sqrt(sqsum));

    return 0;

}
