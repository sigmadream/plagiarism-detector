#include <stdio.h>
#include <string.h>
#include <math.h>

int main()
{
    char word1[40]; 
    char word2[40]; 
    scanf("%s %s", word1, word2);

    int len1 = strlen(word1);
    int len2 = strlen(word2);
    int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
    char vowels[] = "aeiouAEIOU";

    for (int i = 0; i < len1; ++i) {
        if (strchr(vowels, word1[i]) != NULL )
            x1++;
        else
            y1++;
    }
        for (int j = 0; j < len2; ++j) {
        if (strchr(vowels, word2[j]) != NULL )
            x2++;
        else
            y2++;
    }
    double distance = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
    printf("%.3f\n", distance);

    return 0;
}
