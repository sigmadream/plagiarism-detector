#include <stdio.h>
#include <math.h>

// Function to calculate the distance between two points in a 2D plane
double calculateDistance(int x1, int y1, int x2, int y2) {
    int dx = x1 - x2;
    int dy = y1 - y2;
    return sqrt(dx * dx + dy * dy);
}

int main() {
    char word1[41];
    char word2[41];

    // Read two words from standard input
    if (fgets(word1, sizeof(word1), stdin) == NULL) {
        fprintf(stderr, "Error reading the first word\n");
        return 1;
    }
    if (fgets(word2, sizeof(word2), stdin) == NULL) {
        fprintf(stderr, "Error reading the second word\n");
        return 1;
    }

    // Calculate the number of vowels and consonants for both words
    int x1 = 0, y1 = 0, x2 = 0, y2 = 0;

    for (int i = 0; word1[i]; i++) {
        if (word1[i] == 'A' || word1[i] == 'E' || word1[i] == 'I' || word1[i] == 'O' || word1[i] == 'U' ||
            word1[i] == 'a' || word1[i] == 'e' || word1[i] == 'i' || word1[i] == 'o' || word1[i] == 'u') {
            x1++;
        } else if ((word1[i] >= 'A' && word1[i] <= 'Z') || (word1[i] >= 'a' && word1[i] <= 'z')) {
            y1++;
        }
    }

    for (int i = 0; word2[i]; i++) {
        if (word2[i] == 'A' || word2[i] == 'E' || word2[i] == 'I' || word2[i] == 'O' || word2[i] == 'U' ||
            word2[i] == 'a' || word2[i] == 'e' || word2[i] == 'i' || word2[i] == 'o' || word2[i] == 'u') {
            x2++;
        } else if ((word2[i] >= 'A' && word2[i] <= 'Z') || (word2[i] >= 'a' && word2[i] <= 'z')) {
            y2++;
        }
    }

    // Calculate and print the distance
    double distance = calculateDistance(x1, y1, x2, y2);
    printf("%.3lf\n", distance);

    return 0;
}

