#include <stdio.h>
#include <math.h>

float calculate_distance(char word1[], char word2[]) {
    int vowels1 = 0, consonants1 = 0;
    int vowels2 = 0, consonants2 = 0;

    for (int i = 0; word1[i] != '\0'; i++) {
        if (word1[i] == 'A' || word1[i] == 'E' || word1[i] == 'I' || word1[i] == 'O' || word1[i] == 'U' ||
            word1[i] == 'a' || word1[i] == 'e' || word1[i] == 'i' || word1[i] == 'o' || word1[i] == 'u') {
            vowels1++;
        } else if ((word1[i] >= 'A' && word1[i] <= 'Z') || (word1[i] >= 'a' && word1[i] <= 'z')) {
            consonants1++;
        }
    }

    for (int i = 0; word2[i] != '\0'; i++) {
        if (word2[i] == 'A' || word2[i] == 'E' || word2[i] == 'I' || word2[i] == 'O' || word2[i] == 'U' ||
            word2[i] == 'a' || word2[i] == 'e' || word2[i] == 'i' || word2[i] == 'o' || word2[i] == 'u') {
            vowels2++;
        } else if ((word2[i] >= 'A' && word2[i] <= 'Z') || (word2[i] >= 'a' && word2[i] <= 'z')) {
            consonants2++;
        }
    }

    float distance = sqrt(pow(vowels2 - vowels1, 2) + pow(consonants2 - consonants1, 2));
    return roundf(distance * 1000.0) / 1000.0;
}

int main() {
    char word1[41], word2[41];

    scanf("%s", word1);
    scanf("%s", word2);

    float distance = calculate_distance(word1, word2);
    printf("%.3f\n", distance);

    return 0;
}
