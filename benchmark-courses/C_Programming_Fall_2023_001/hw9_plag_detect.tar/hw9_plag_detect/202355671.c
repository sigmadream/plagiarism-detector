#include <stdio.h>
#include <math.h>
double x1 = 0, y = 0, x2 = 0, y2 = 0;
char a[100], b[100];
void Calculate_A(){
    for(int i=0; i<60; i++){
        if (a[i] >= 'A' && a[i] <= 'Z'){
            a[i] = a[i] - 'A' + 'a';
        }
        if (a[i] <'a' || a[i] > 'z'){
            break;
        }
        if (a[i]=='a'){
            x1++;
        }
        else if (a[i]=='e'){
            x1++;
        }
        else if (a[i]=='i'){
            x1++;
        }
        else if (a[i]=='o'){
            x1++;
        }
        else if (a[i]=='u'){
            x1++;
        }
        else{
            y++;
        }
    }
}
void Calculate_B(){
    for(int i=0; i<60; i++){
        if (b[i] >= 'A' && b[i] <= 'Z'){
            b[i] = b[i] - 'A' + 'a';
        }
        if(b[i] <'a' || b[i] > 'z'){
            break;
        }
        if (b[i]=='a' ){
            x2++;
        }
        else if (b[i]=='e'){
            x2++;
        }
        else if (b[i]=='i'){
            x2++;
        }
        else if (b[i]=='o'){
            x2++;
        }
        else if (b[i]=='u'){
            x2++;
        }
        else{
            y2++;
        }
    }
}
int main(){
    fgets(a, 100, stdin);
    fgets(b, 100, stdin);
    Calculate_A();
    Calculate_B();
    printf("%0.3lf\n", sqrt(pow(x1-x2, 2) + pow(y-y2, 2)));
    return 0;
}
