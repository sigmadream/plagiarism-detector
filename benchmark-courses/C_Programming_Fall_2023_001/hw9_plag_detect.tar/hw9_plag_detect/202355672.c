#include <stdio.h>
#include <string.h>
#include <math.h>


int main()
{

    char str_1[41];
    char str_2[41];

    scanf("%s\n%s", str_1, str_2);

    size_t len_1 = strlen(str_1);
    int x_1 =0, y_1 =0;

    for (int i=0; i<len_1; ++i) {
        char c =str_1[i];
        if (c == 'a' ||c == 'e' ||c == 'i' ||c == 'o' ||c == 'u'
        || c =='A' ||c == 'E' ||c == 'I' ||c == 'O' ||c == 'U')
            x_1++;
        else
            y_1++;
    }

    size_t len_2 = strlen(str_2);
    int x_2 =0, y_2 =0;

    for (int i=0; i<len_2; ++i) {
        char d =str_2[i];
        if (d == 'a' ||d == 'e' ||d == 'i' ||d == 'o' ||d == 'u'
        || d =='A' ||d == 'E' ||d == 'I' ||d == 'O' ||d == 'U')
            x_2++;
        else
            y_2++;
    }
    double sqsum = (y_2 - y_1) * (y_2 - y_1) + (x_2 - x_1) * (x_2 - x_1);
    printf("%.3f", sqrt(sqsum));



    return 0;
}
