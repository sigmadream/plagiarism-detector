#include <stdio.h>
#include <math.h>


double calculateDistance(int x1, int y1, int x2, int y2) {
    int dx = x1 - x2;
    int dy = y1 - y2;
    return sqrt(dx * dx + dy * dy);
}

int main() {
    char word1[41], word2[41];


    scanf("%s", word1);
    scanf("%s", word2);

    int x1 = 0, y1 = 0, x2 = 0, y2 = 0;

    
    for (int i = 0; word1[i] != '\0'; i++) {
        char c = word1[i];
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' ||
            c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            x1++;
        } else if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
            y1++;
        }
    }

    for (int i = 0; word2[i] != '\0'; i++) {
        char c = word2[i];
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' ||
            c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            x2++;
        } else if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
            y2++;
        }
    }

  
    double result = calculateDistance(x1, y1, x2, y2);

    printf("%.3lf\n", result);

    return 0;
}


