#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>


int main()
{
    char word1[50], word2[50], c;
    int x = 0, y = 0;
    double d;
    scanf("%s \n %s", &word1, &word2);

    for(int i = 0; i < strlen(word1); i++)
    {
        c = tolower(word1[i]);
        if(c =='a'|| c == 'e' || c == 'o' || c == 'i' || c == 'u')
            x++;
        else
            y++;
    }
    x = 0-x;
    y = 0-y;
    for(int i = 0; i < strlen(word2); i++)
    {
        c = tolower(word2[i]);
        if(c =='a'|| c == 'e' || c == 'o' || c == 'i' || c == 'u')
            x++;
        else
            y++;
    }
    d = sqrt((x*x)+(y*y));
    printf("%.3lf", d);
}
