#include <stdio.h>
#include <math.h>

double calculate_distance(int x1, int y1, int x2, int y2) {
    return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

int word_length(char *word) {
    int length = 0;
    while (word[length] != '\0')
        length++;
    return length;
}

void count_vowels_consonants(char *word, int *vowel_count, int *consonant_count) {
    *vowel_count = 0;
    *consonant_count = 0;

    for (int i = 0; word[i] != '\0'; i++) {
        char current_char = word[i];
        if ((current_char >= 'A' && current_char <= 'Z') || (current_char >= 'a' && current_char <= 'z')) {
            // Check if the character is a vowel
            if (current_char == 'A' || current_char == 'E' || current_char == 'I' || current_char == 'O' || current_char == 'U' ||
                current_char == 'a' || current_char == 'e' || current_char == 'i' || current_char == 'o' || current_char == 'u') {
                (*vowel_count)++;
            } else {
                (*consonant_count)++;
            }
        }
    }
}

int main() {
    char word1[40], word2[40];
    int x1, y1, x2, y2;
    int vowel_count1, consonant_count1, vowel_count2, consonant_count2;

    scanf("%s", word1);
    scanf("%s", word2);

    int len1 = word_length(word1);
    int len2 = word_length(word2);

    count_vowels_consonants(word1, &vowel_count1, &consonant_count1);
    count_vowels_consonants(word2, &vowel_count2, &consonant_count2);

    x1 = vowel_count1;
    y1 = consonant_count1;
    x2 = vowel_count2;
    y2 = consonant_count2;

    double distance = calculate_distance(x1, y1, x2, y2);

    printf("%.3lf\n", distance);

    return 0;
}
