#include <stdio.h>
#include <string.h>
#include <math.h>

int main()
{
    char str1[41], str2[41];

    fgets(str1, 41, stdin);
    fgets(str2, 41, stdin);

    int v1 = 0, c1 = 0, v2 = 0, c2 = 0;

    for(int i = 0; i < strlen(str1); i++){
        if('a' <= str1[i] && str1[i] <= 'z' || 'A' <= str1[i] && str1[i] <= 'Z'){
            if(str1[i] == 'a' || str1[i] == 'e' || str1[i] == 'u' || str1[i] == 'i' || str1[i] == 'o' || str1[i] == 'I' || str1[i] == 'A' || str1[i] == 'E' || str1[i] == 'U' || str1[i] == 'O'){
                v1++;
            }
            else{
                c1++;
            }
        }
    }
    for(int i = 0; i < strlen(str2); i++){
        if('a' <= str2[i] && str2[i] <= 'z' || 'A' <= str2[i] && str2[i] <= 'Z'){
            if(str2[i] == 'a' || str2[i] == 'e' || str2[i] == 'u' || str2[i] == 'i' || str2[i] == 'o'|| str2[i] == 'I' || str2[i] == 'A' || str2[i] == 'E' || str2[i] == 'U' || str2[i] == 'O'){
                v2++;
            }
            else{
                c2++;
            }
        }
    }



    //printf("%d %d\n", v1, c1);
    //printf("%d %d\n", v2, c2);

    printf("%.3f", sqrt(pow(v1-v2, 2) + pow(c1-c2, 2)));


    //double len = sqrt(v1 + c1);
    //printf("%.3f", len);
    
    return 0;
}
