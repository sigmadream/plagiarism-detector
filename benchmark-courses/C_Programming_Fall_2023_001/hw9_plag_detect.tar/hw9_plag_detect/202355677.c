#include <stdio.h>
#include <math.h>
#include <string.h>






int main()
{
    char word1[41];
    char word2[41];



    scanf("%s \n %s", word1, word2);

    int num_vowel1 = 0;
    int num_consonant1 = 0;
    for (int i = 0; i < strlen(word1); i++)
    {
        char c = word1[i];
        if ( c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
            num_vowel1++;
        else
            num_consonant1++;
    }


    int num_vowel2 = 0;
    int num_consonant2 = 0;
    for (int i = 0; i < strlen(word2); i++)
    {
        char c = word2[i];
        if ( c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
            num_vowel2++;
        else
            num_consonant2++;
    }

    int x = (num_vowel1 - num_vowel2)*(num_vowel1 - num_vowel2);
    int y = (num_consonant1- num_consonant2)*(num_consonant1- num_consonant2);









    printf("%.3lf\n", sqrt(x+y));

    return 0;
}


