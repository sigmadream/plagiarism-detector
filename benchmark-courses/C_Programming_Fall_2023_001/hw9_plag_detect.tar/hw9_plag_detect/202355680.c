#include <stdio.h>
#include <math.h>

double x, y, x2, y2, x3, y3;
char ch[1022];
char vow[] = {'a', 'e', 'u', 'i', 'o'};

void func()
{
	x = 0;
	y = 0;
	for(int i = 0; i < 50; ++i)
	{
		if('A' <= ch[i] && ch[i] <= 'Z')
		{
			ch[i] = ch[i] - 'A' + 'a';
		}
		int ok = 0;
		for(int j = 0; j < 5; ++j)
		{
			if(ch[i] == vow[j])
				ok = 1;
		}
		if(ok)
			x++;
		else
		if('a' <= ch[i] && ch[i] <= 'z')
		{
			y++;
		}
	}
}

int main()
{
	for(int i = 0; i < 50; ++i)
	{
		ch[i] = 0;
	}
	scanf("%100s", &ch);
	func();
	x2 = x;
	y2 = y;
	for(int i = 0; i < 50; ++i)
	{
		ch[i] = 0;
	}
	scanf("%100s", &ch);
	func();
	x3 = x;
	y3 = y;
	for(int i = 0; i < 50; ++i)
	{
		ch[i] = 0;
	}
	scanf("%100s", &ch);
	func();
	double a = sqrt(pow(x-x2, 2)+pow(y-y2, 2));
	double b = sqrt(pow(x-x3, 2)+pow(y-y3, 2));
	double c = sqrt(pow(x3-x2, 2)+pow(y3-y2, 2));
	double s = (a+b+c)/2;
	printf("%.3f", sqrt(s*(s-a)*(s-b)*(s-c)));
}
