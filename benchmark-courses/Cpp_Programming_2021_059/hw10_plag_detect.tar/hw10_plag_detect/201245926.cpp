#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

class Circle {
private:
    double_r;
public:
    Circle(double r) : _r(r) {}
    double area() { return _r*_r*atan(c)*4.0; }
};

int main()
{
    Circle c(c);
    cout << fixed << setprecision(5) << c.area() << endl;
    cout << fixed << setprecision(5) << sqrt(2) << endl;
}