#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

class Shape
{
private:
    double _a;
    double _b;

public:
    Shape(double a) : _a(a) {}
    Shape(double a, double b) : _a(a), _b(b) {}
    double a() { return _a; }
    double b() { return _b; }
    virtual double area() = 0;
};

class Circle : public Shape
{
public:
    Circle(double a) : Shape(a) {}
    double area() { return a() * a() * atan(1) * 4.0; }
};

class Rectangle : public Shape
{
public:
    Rectangle(double a, double b) : Shape(a, b) {}
    double area() { return a() * b(); }
};

class Triangle : public Shape
{
public:
    Triangle(double a) : Shape(a) {}
    double area() { return a() * a() * sqrt(3) / 4.0; }
};

int main()
{
    int n = 0;
    char type;
    double a, b;
    cin >> n;
    double sum = 0;

    for (int i = 0; i < n; i++)
    {
        cin >> type;
        if (type == 'R')
        {
            cin >> a >> b;
        }
        else
        {
            cin >> a;
        }

        if (type == 'C')
        {
            sum += Circle(a).area();
        }
        if (type == 'R')
        {
            sum += Rectangle(a, b).area();
        }
        if (type == 'T')
        {
            sum += Triangle(a).area();
        }
    }

    cout << fixed << setprecision(2) << sum << endl;
}