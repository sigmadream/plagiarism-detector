#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
using namespace std;

class Shape {
public:
	Shape(double n): num(n) {}
	double number() {return num;}
	virtual double area(){
		return 0;
	}	
private:
	double num;
};

class Circle: public Shape {
public:
	Circle(double n): Shape(n){}
	double area(){
		double num1 = number();
		return num1 * num1 * atan(1) * 4.0;
	}
};

class Triangle: public Shape {
public:
	Triangle(double n): Shape(n){}
	double area(){
		double num2 = number();
		return num2 * num2 * sqrt(3) / 4;
	}
	
};

class Rectangle {
private:
	double weight, height;
public:
	Rectangle(double n, double m){
		weight = n;
		height = m;
	}
	double area(){
		return weight * height;
	}
};

int main(){
	
	
	
	int n;
	cin >> n;
	double sum;
	if (n<0 || n>500)
	return 0;
	
	for (int i = 0; i < n; i++)
    {
        string s;
		cin >> s;
        if (s == "C")
        {
            double radius;
			cin >> radius;
			Circle c(radius);
			double result = c.area();
			sum = sum + result;
			     
        }else if (s == "T")
        {
            double length;
			cin >> length;
			Triangle t(length);
			double result = t.area();
			sum = sum + result;
			
        }else if (s == "R")
        {
            double length, width;
			cin >> length >> width;
			Rectangle r(length,width);
			double result = r.area();
			sum = sum + result;
			
        }else{
            cout << "[error]invalid shape: " << s << endl;
        }
}
	
	cout << fixed << setprecision(2) << sum << endl;
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

