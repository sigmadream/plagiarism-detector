#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>

using namespace std;

class Shape {
public:
    virtual double area() = 0;
    virtual double area(vector<Shape *>) = 0;
};

class Circle: public Shape {
private:
    double _r;
public:
    Circle() {}
    Circle (double r): _r(r) {}
    double area() { return M_PI * _r * _r; }
    double area(vector <Shape *> shapeVector) {
        double answer = 0;
        for (Shape * s: shapeVector) answer += s->area();
        return answer;
    }
};

class Triangle: public Shape {
private:
    double _s;
public:
    Triangle() {}
    Triangle (double s): _s(s) {}
    double area() { return sqrt(3) / 4 * _s * _s; }
    double area(vector <Shape *> shapeVector) {
        double answer = 0;
        for (Shape * s: shapeVector) answer += s->area();
        return answer;
    }
};

class Rectangle: public Shape {
private:
    double _w, _h;
public:
    Rectangle() {}
    Rectangle (double w, double h): _w(w), _h(h) {}
    double area() { return _w * _h; }
    double area(vector <Shape *> shapeVector) {
        double answer = 0;
        for (Shape * s: shapeVector) answer += s->area();
        return answer;
    }
};

vector<Shape *> read(istream &in) {
    int N;
    char shape;
    vector <Shape *> shapeVector;
    cin >> N;
    for (int i = 0; i < N; i++) {
        cin >> shape;
        if (shape == 'C') {
            double r;
            cin >> r;
            Circle * C = new Circle(r);
            shapeVector.push_back(C);
        }
        else if (shape == 'R') {
            double w, h;
            cin >> w >> h;
            Rectangle * R = new Rectangle(w, h);
            shapeVector.push_back(R);
        }
        else if (shape == 'T') {
            double s;
            cin >> s;
            Triangle * T = new Triangle(s);
            shapeVector.push_back(T);
        }
    }
    return shapeVector;
}

int main(void) {
    vector <Shape *> shapeVector = read(cin);
    cout << fixed << setprecision(2) << shapeVector[0]->area(shapeVector) << endl;
    return 0;
}
