#include <cstdio>
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

class Shape{
	public:
		double w, h, r, a;
		char sh;
		virtual double area() = 0;

};
class Circle : public Shape{
	public:
	Circle(){
	}
	Circle(double r_){
		r = r_;
	}
	double area(){
		return r*r*3.141592;
	}
};
class Rectangle : public Shape{
public:
	Rectangle(){
	}
	Rectangle(int a, int b){
		w = a;
		h = b;
	}
	double area(){
		return w*h;
	}
};
class Triangle : public Shape{
	public:
		Triangle(){
		}
		Triangle(double T){
			a = T;
		}
		double area(){
			return (a*a*sqrt(3)/4);
		}
};

int main(){
	int N=0, i=0;
	double k_, k__, sum = 0;
	char c;
	Circle C;
	Rectangle R;
	Triangle T;
	scanf("%d", &N);
	while(cin >> c >> k_){
		if (c == 'R') {
			Shape *p;
			p = &R;
			cin >> k__; 
			p->w = k_; p->h = k__;
			sum += p->area();
		}
		else if(c == 'C'){
			Shape *p;
			p = &C;
			p->r = k_;
			sum += p->area();
		}
		else {
			Shape *p;
			p = &T;
			p->a = k_;
			sum += p->area();
		}
		i++;
		if(i == N) break;
	}

	cout << round(sum*100) / 100;
}
