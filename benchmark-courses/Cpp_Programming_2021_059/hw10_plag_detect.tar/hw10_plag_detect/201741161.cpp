#define _USE_MATH_DEFINES
#include<iostream>
#include<vector>
#include<string>
#include<cmath>

using namespace std;

double sum;

class Shape{
    char _type;
public:
    Shape(char c): _type(c){}
    char get_t(){ return _type;}
    virtual double area(){
        return 0;
    }
};
class Circle : public Shape{
    double _x;
public:
    Circle(char c, double x): Shape(c), _x(x) {}
    double area(double x){
        return x * x * atan(1) * 4;
    }
};
class Rectangle : public Shape{
    double _x, _y;
public:
    Rectangle(char c, double x, double y): Shape(c), _x(x), _y(y) {}
    double area(double x, double y){
        return x * y;
    }
};
class Triangle : public Shape{
    double _x;
public:
    Triangle(char c, double x): Shape(c), _x(x) {}
    double area(double x){
        return x * x * sqrt(3) / 4.0;
    }
};

istream& read(istream& in, char t){
    double x, y;
    if(t == 'C'){
        in >> x;
        Circle c('C', x);
        sum += c.area(x);
    }
    else if(t == 'T'){
        in >> x;
        Triangle t('T', x);
        sum += t.area(x);
    }
    else if(t == 'R'){
        in >> x >> y;
        Rectangle r('R', x, y);
        sum += r.area(x, y);
    }
    return in;
}
double round_digit(double num, int d) { double t = pow(10, d - 1); return round(num * t) / t; }

int main(){
    int n;
    char t;
    vector<Shape *> v;
    cin >> n;
    for(int i = 0; i < n; i++){
        cin >> t;
        read(cin, t);
    }
    cout << round(sum * 100) / 100;
}