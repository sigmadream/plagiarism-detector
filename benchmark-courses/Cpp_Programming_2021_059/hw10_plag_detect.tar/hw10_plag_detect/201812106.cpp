#include <iostream>
#include <cmath>
#include <vector>
using namespace std;
int n;
double ans;
class Shape {
private:
	vector<Shape *> read(istream& in);
	double area(vector<Shape *>);
};
class Rectangle : public Shape{
private:
	double w, h;
public:
	vector<Rectangle> read(istream& in) {
		vector<Rectangle> v;
		Rectangle u;
		in >> (u.w) >> (u.h);
		v.push_back(u);
		return v;
	}
	double area(vector<Rectangle> v) {
		return (v[0].w) * (v[0].h);
	}
};

class Triangle : public Shape {
private:
	double d;
public:
	vector<Triangle> read(istream& in) {
		vector<Triangle> v;
		Triangle u;
		in >> (u.d);
		v.push_back(u);
		return v;
	}
	double area(vector<Triangle> v) {
		return (v[0].d) * (v[0].d) * sqrt(3) / 4.0;
	}
};

class Circle : public Shape {
private:
	double r;
public:
	vector<Circle> read(istream& in) {
		vector<Circle> v;
		Circle u;
		in >> (u.r);
		v.push_back(u);
		return v;
	}
	double area(vector<Circle> v) {
		return (v[0].r) * (v[0].r) * atan(1) * 4.0;
	}
};

int main() {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		char s;
		cin >> s;
		if (s == 'R') {
			Rectangle R;
			ans += R.area(R.read(cin));
		}
		else if (s == 'T') {
			Triangle T;
			ans += T.area(T.read(cin));
		}
		else {
			Circle C;
			ans += C.area(C.read(cin));
		}
	}
	printf("%.2lf", ans);
}