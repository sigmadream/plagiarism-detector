#include <cstdio>
#include <cmath>
#include <iostream>
using namespace std;

class Shape {
	public:
		virtual double area() const = 0;
};

class Circle : public Shape {
	public:
		Circle(double c) : Shape() {
			this -> c = c;
		}
		double area() const override {return 0;}
		double cal_c() {
			return c*c*atan(1)*4.0;			
		}
	
	private:
		double c;
};

class Rectangle : public Shape {
	public:
		Rectangle(double r1, double r2) : Shape() {
			this -> r1 = r1;
			this -> r2 = r2;
		}
		double area() const override {return 0;}
		double cal_r() {
			return r1*r2;			
		}

	
	private:
		double r1;
		double r2;
};

class Triangle : public Shape {
	public:
		Triangle(double t) : Shape() {
			this -> t = t;
		}
		double area() const override {return 0;}
		double cal_t() {
			return t*t*sqrt(3.0)/4.0;			
		}
	
	private:
		double t;
};



int main()
{
	int N, i;
	double len1, len2, sum = 0;
	char S;
	
	cin >> N;

	if (N > 0 && N < 500) {
		for ( i = 0; i < N; i++ ) {
			cin >> S;
			
			switch (S)
			{
				case 'C' : {
					cin >> len1;
					Circle std(len1);
					sum += std.cal_c();
					break;
				}
				case 'R' : {
					cin >> len1;
					cin >> len2;
					Rectangle std(len1, len2);					
					sum += std.cal_r();
					break;
				}
				case 'T' : {
					cin >> len1;
					Triangle std(len1);
					sum += std.cal_t();
					break;
				}
				
				default:
					break;
			}
			
		}
	}
	
	cout << fixed;
	cout.precision(2);
	cout << sum;

}
