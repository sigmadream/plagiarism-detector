#include<iostream>
#include<iomanip>
#include<cmath>
#include<string>
#include<vector>

using namespace std;

class Shape
{
private:
    double length;

public:
    Shape(double length):length(length)
    {}
    virtual double area() const =0;
    double Showlength() const
     {return length;}
};

class Circle : public Shape
{
public :
    Circle(double length) : Shape(length)
    {}
    virtual double area() const
    {return Showlength()*Showlength()*atan(1)*4.0;}

};

class Triangle : public Shape
{
public :
    Triangle(double length) : Shape(length)
    {}
    virtual double area() const
    {return Showlength()/2*sqrt(3)*Showlength()/2;}

};

class Rectangle : public Shape
{
private:
    double height;    
public : 
    Rectangle(double length,double height):Shape(length),height(height)
    {}
    virtual double area() const
    {return Showlength()*height;}
};

int main(void)
{
    int howcount;
    cin>>howcount;
    double l,h;

    string s;

    vector<Shape * > record;

    for(int i=0;i<howcount;i++)
    {   
        cin>>s;
        if(s=="C")
        {
            cin>>l;
            record.push_back(new Circle(l));
        }
        else if(s=="R")
        {
            cin>>l;
            cin>>h;
            record.push_back(new Rectangle(l,h));
        }
        else if(s=="T")
        {
            cin>>l;
            record.push_back(new Triangle(l));
        }
        else
        {
            cout<<"not"<<endl;
        }
    }

    double sum=0;
    for(Shape* i : record)
    {
        sum+=i->area();
    }
    cout<<fixed<<setprecision(2)<<sum<<endl;
    
}