#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;


class Shape {
	private:
		double _n;
	public:
		Shape(double n = 0) : _n(n) {}
		double n() {return _n;}
		double n(double k) { return _n = k;}
		virtual double area() { return 0; }
		
};

class Circle: public Shape {
	public:
		Circle(double n = 0) : Shape(n) {}
		virtual double area() { return n()*n()*atan(1)*4.0; }
};

class Triangle: public Shape {
	public:
		Triangle(double n = 0) : Shape(n) {}
		virtual double area() { return sqrt(3)/4.0 * n() * n(); }
};

class Rectangle: public Shape {
	private:
		double _w;
	public:
		Rectangle(double n = 0) : Shape(n) {}
		double w() { return _w; }
		double w(double t) { return _w = t;}
		virtual double area() { return n() * w(); }
};


int main()
{
	int n;
	double sum_area = 0.0;
	
	cin >> n;
	
	while (n--){
		char word;
		double l = 0;
		double w;
		cin >> word;
		
		if (word == 'C') {
			cin >> w;
			Circle c;
			c.n(w);
			sum_area = sum_area + c.area();
		}
		else if (word == 'R') {
			cin >> w >> l;
			Rectangle r;
			r.n(w);
			r.w(l);
			sum_area = sum_area + r.area();
		}
		else 
		{
			cin >> w;
			Triangle t;
			t.n(w);
			sum_area = sum_area + t.area();	
		}
			
	}
	
	cout << fixed << setprecision(2) << sum_area << endl;

}
