#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
using namespace std;

class Shape {
private:
	double _r;
public:
	Shape (double r) : _r(r) {}
	double r() {return _r; }
	virtual double area() {return _r*_r; }
};

class Circle: public Shape {
public:
	Circle (double r) : Shape(r) {}
	double area() {return r()*r()*atan(1)*4.0; }
};

class Rectangle: public Shape {
private:
	double _l;
public:
	Rectangle (double r, double l) : Shape(r), _l(l) {}
	double area() {return r()*_l; }
};

class Triangle: public Shape {
public:
	Triangle (double r): Shape(r) {}
	double area() {return r()*r()*sin(atan(1)*4.0/3.0)/2; }
};

int main()
{
	int n;
	cin >> n;
	
	char a;
	double r, l, result = 0.0;
	
	for(int i=0; i < n; i++)
	{
		cin >> a;
		if(a == 'C')
		{
			cin >> r;
			Circle C(r);
			result += C.area();
		}
		else if(a == 'R')
		{
			cin >> r >> l;
			Rectangle R(r, l);
			result += R.area();
		}
		else
		{
			cin >> r;
			Triangle T(r);
			result += T.area();
		}
	}
	cout << fixed << setprecision(2) << result << endl;
}
