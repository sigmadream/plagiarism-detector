#define _USE_MATH_DEFINES
#include <cstdio>
#include <math.h>
int main() {
	
	int N=0;
	char s[100];
	
	double k=0;
	double rec=0;
	double count=0;
	double root=sqrt(3.0);
	scanf("%d",&N);
	int i=0;
	
	for(i=0; i<N; i++){
		scanf("%s",&s[i]);
		
	
		if(s[i]=='C') {
			scanf("%lf",&k);
			count=count+(k*k*M_PI);
		}
		else if(s[i]=='T') {
			scanf("%lf",&k);
			count=count+(((root*k)/4.0)*k);
		}
		else {
			scanf("%lf",&k);
			scanf("%lf",&rec);
			
			count=count+(k*rec);
		}
		
	
	}
	
	printf("%.2f",count);
	
	
	
	
	return 0;
}
