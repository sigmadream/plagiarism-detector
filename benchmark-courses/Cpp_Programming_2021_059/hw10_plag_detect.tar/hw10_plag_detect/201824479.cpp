#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
using namespace std;

class Shape {
public:
    virtual double area()=0;
};

class Circle : public Shape {
private:
    double _r;
public:
    Circle(double r): _r(r) {}
    double area() { return _r*_r* atan(1) *4.0; }
};

class Triangle : public Shape {
    double _r;
public:
    Triangle(double r): _r(r) {}
    double area() { return _r * _r * sqrt(3) / 4; }
};

class Rectangle : public Shape {
private:
    double _w, _h;
public:
    Rectangle(double w, double h): _w(w), _h(h) {}
    double area() { return _w * _h; } 
};

int main() {
    int n;
    double val=0;
    cin >> n;
    char c;
    double d, dd;
    vector<char> v;
    vector<double> vv, vvv;
    for (int i =0; i < n;i++) {
        cin >> c;
        if (c == 82) {
            cin >> d >> dd;
            vvv.push_back(dd);
        }
        else cin >> d;
        v.push_back(c);
        vv.push_back(d);
    }
    int cnt=0;
    for (int i=0; i<n; i++) {
        if (v[i] == 67) {
            Circle c(vv[i]);
            val += c.area();
        }
        else if (v[i] == 84) {
            Triangle t(vv[i]);
            val += t.area();
        }
        else {
            Rectangle r(vv[i], vvv[cnt]);
            val += r.area();
            cnt++;
        }
    }
    cout << fixed;
    cout.precision(2);
    cout << val;
}

