#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
using namespace std;

class Shape{
public:
    virtual double area()=0;
private:
    
};
class Circle:public Shape{
public:
    Circle(double r = 0):radius(r){}
    double area(){
        return radius*radius*3.141592;
    }
    void ir(double r){ radius = r;}

private:
    double radius;
};
class Rectangle:public Shape{
public:
    Rectangle(double w = 0, double h = 0):width(w), height(h){}
    double area(){
        return width*height;
    }
    void iwh(double w, double h){ width = w, height = h;}
private:
    double width;
    double height;
};
class Triangle:public Shape{
public:
    Triangle(double l = 0):length(l){}
    double area(){
        return (sqrt(3)*length*length)/4;
    }
    void il(double l){ length = l; }
private:
    double length;
};
int main(){
    int N;
   cin >> N;
    vector<char> c1(N);
    vector<double> tmp(2);
    double sum = 0;
    for(int i = 0; i < N; i++){
        cin >> c1[i];
        if(c1[i]=='R'){
            cin >> tmp[0] >> tmp[1];
            Rectangle r(tmp[0], tmp[1]);
            sum += r.area();
        }
        else if(c1[i]=='C'){
            cin >> tmp[0];
            Circle c(tmp[0]);
            sum+= c.area();
        }
        else if(c1[i]=='T'){
            cin >> tmp[0];
            Triangle t(tmp[0]);
            sum += t.area();
        }
    }
    cout<<fixed;
    cout.precision(2);
    cout << sum << endl;
}