#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
using namespace std;

class Shape{
    virtual double area() = 0;
public:

};

class Circle : public Shape {
    double _r;
public:
    Circle(double r) :_r(r) {}
    double area() { return _r*_r*atan(1)*4.0;}
};

class Rectangle : public Shape {
    double _x, _y;
public:
    Rectangle(double x, double y) : _x(x), _y(y) {}
    double area() { return _x * _y;}

};

class R_Triangle : public Shape {
    double _s;
public:
    R_Triangle(double s) : _s(s) {}
    double area() {return (_s*sqrt(3))*(_s/2)/2;}
};

/*
    vector<Shape *> read(istream& in){
    char type;
    double leng;
    in >> type >> leng;
    if(type 'C')
        vector<Circle> a(leng);
    else if(type == "R")
        vector<Rectangle> a(leng);
    else(type == "T")
        vetor<
}

*/



int main()
{
    int num;
    char type;
    double sum =0;
    cin >> num;
    for(int i=0; i<num ; i++){
        double leng1=0, leng2=0;
        
        cin >> type;
        if(type == 'C'){
            cin >> leng1;
            sum = sum + Circle(leng1).area();
        }
        else if(type == 'R'){
            cin >> leng1 >> leng2;
            sum = sum + Rectangle(leng1, leng2).area();
        }
        else{
            cin >>leng1;
            sum = sum + R_Triangle(leng1).area();
        }
    }

    cout << fixed << setprecision(2) << sum << endl;
}