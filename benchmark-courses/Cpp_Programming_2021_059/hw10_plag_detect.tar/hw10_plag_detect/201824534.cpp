#include<iostream>
#include<iomanip>
#include<cmath>

using namespace std;
const double PI = 3.141592;

class Shape{
private:
    double a;
public:
    Shape(double n=0) : a(n) {}
    virtual double area(double p) = 0;
};

class Circle : public Shape{
public:
    Circle(double n=0) : Shape(n) {}
    double area(double C){
        return PI*C*C;
    }
};

class Triangle : public Shape{
public:
    Triangle(double n=0) : Shape(n) {}
    double area(double T) {
        return (sqrt(3)/4)*T*T;
    }
};

class Rectangle : public Shape{
public:
    Rectangle(double n=0) : Shape(n) {}
    double area(double R) {
        return R;
    }
};

int main(){
    int ctrl;
    char det_s;
    double sum=0, det_val1, det_val2, C, T, R1,R2;

    Circle c;
    Triangle t;
    Rectangle r;

    cin >> ctrl;
    for(int i=0;i<ctrl;i++){
        C = T = R1 = R2 = 0;
        cin >> det_s;
        if(det_s =='R')
            cin >> det_val1 >> det_val2;
        else
            cin >> det_val1;
        if(det_s == 'C')
            C = det_val1;
        if(det_s == 'T')
            T = det_val1;
        if(det_s == 'R'){
            R1 = det_val1;
            R2 = det_val2; 
        }
        if(C!=0 && T==0 && R1==0)
            sum = sum + c.area(C);
        if(C==0 && T!=0 && R1==0)
            sum = sum + t.area(T);
        if(C==0 && T==0 && R1!=0)
            sum = sum + r.area(R1*R2);
    }

    cout << fixed << setprecision(2) << sum << endl;
}