#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

class Shape
{
public:
	virtual double area() = 0;

};

class Circle : public Shape
{
private:
	double _r;

public:
	Circle(double r = 0) : _r(r) {}
	double area() { return _r * _r * std::atan(1) * 4.0; }

};

class Rectangle : public Shape
{
private:
	double width;
	double height;

public:
	Rectangle(double w = 0, double h = 0) : width(w), height(h) {}
	double area() { return width * height; }

};

class Triangle : public Shape
{
private:
	double _l;

public:
	Triangle(double l = 0) : _l(l) {}
	double area() { return std::sqrt(3) * _l * _l / 4.0; }

};

//std::vector<Shape*> read(std::istream& in);
//double area(std::vector<Shape*> shapes);
//
//std::vector<Circle> circBox;
//std::vector<Rectangle> rectBox;
//std::vector<Triangle> triBox;

int main()
{
	int n;
	std::cin >> n;

	double result = 0.0;

	for (int i = 0; i < n; i++)
	{
		char command;
		std::cin >> command;

		if (command == 'C')
		{
			double r;
			std::cin >> r;
			Circle temp(r);
			result += temp.area();
		}
		else if (command == 'R')
		{
			double w, h;
			std::cin >> w >> h;
			Rectangle temp(w, h);
			result += temp.area();
		}
		else if (command == 'T')
		{
			double l;
			std::cin >> l;
			Triangle temp(l);
			result += temp.area();
		}

		std::cin.ignore();
	}

	std::cout << std::fixed << std::setprecision(2) << result << std::endl;

	return 0;
}

//std::vector<Shape*> read(std::istream& in)
//{
//	int n;
//	in >> n;
//
//	int cIdx = 0;
//	int rIdx = 0;
//	int tIdx = 0;
//
//	std::vector<Shape*> shapes;
//
//	for (int i = 0; i < n; i++)
//	{
//		char selectedShape;
//		in >> selectedShape;
//
//		switch (selectedShape)
//		{
//		case 'C':
//			double r;
//			in >> r;
//			circBox.push_back(Circle(r));
//			shapes.push_back(&circBox[cIdx]);
//			cIdx++;
//			break;
//
//		case 'R':
//			double w, h;
//			in >> w >> h;
//			rectBox.push_back(Rectangle(w, h));
//			shapes.push_back(&rectBox[rIdx]);
//			rIdx++;
//			break;
//
//		case 'T':
//			double l;
//			in >> l;
//			triBox.push_back(Triangle(l));
//			shapes.push_back(&triBox[tIdx]);
//			tIdx++;
//			break;
//
//		default:
//			break;
//		}
//
//		in.ignore();
//	}
//
//	return shapes;
//}
//
//double area(std::vector<Shape*> shapes)
//{
//	double sum = 0.0;
//
//	for (int i = 0; i < shapes.size(); i++)
//	{
//		sum += shapes[i]->area();
//	}
//
//	return sum;
//}