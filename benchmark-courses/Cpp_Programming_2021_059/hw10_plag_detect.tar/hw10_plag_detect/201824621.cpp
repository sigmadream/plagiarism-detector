#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

class Shape {
public:
    Shape(double r) : _r(r) {}
    Shape(double width, double height) : _width(width), _height(height) {}
    double radius() { return _r; }
    double width() { return _width; }
    double height() { return _height; }
    virtual double area() = 0;
private:
    double _width;
    double _height;
    double _r;
};

class Rectangle : public Shape{
public:
    Rectangle(double width, double height) : Shape(width, height) {} 
    double area();
};

class Circle : public Shape{
public:
    Circle(double r) : Shape(r) {}
    double area();
};

class Triangle : public Shape{
public:
    Triangle(double r) : Shape(r) {}
    double area();
};

double Rectangle::area() {
    return this->width() * this->height();
}

double Circle::area() {
    return this->radius() * this->radius() * atan(1) * 4.0;
}

double Triangle::area() {
    double p = (3 * this->radius()) / 2;
    return sqrt(p * (p - this->radius()) * (p - this->radius()) * (p - this->radius()));
}

vector<Shape *> read(istream& in) 
{
    int n;
    in >> n;

    vector<Shape *> shapes;
    
    while (n--) {
        char type;
        in >> type;
        if (type == 'C') {
            double r;
            in >> r;
            Circle *c = new Circle(r);
            shapes.push_back(c);
        }
        else if (type == 'T') {
            double r;
            in >> r;
            Triangle *t = new Triangle(r);
            shapes.push_back(t);
        }
        else if (type == 'R'){
            double x,y;
            in >> x >> y;
            Rectangle *r = new Rectangle(x,y);
            shapes.push_back(r);
        }
    }
    return shapes;
}

double area(vector<Shape *> shapes)
{
    double area = 0;
    for (int i = 0; i < shapes.size(); i++) {
        area += shapes[i]->area();
    }
    return area;
}

int main()
{
    vector<Shape *> shapes = read(cin);
    
    cout << fixed << setprecision(2) << area(shapes) << endl;
}