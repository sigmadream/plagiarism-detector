#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <string>
using namespace std;

class Shape {
private:
    double _width, _height;
public:
    Shape(double w = 0.0) {
        _width = w;
    }

    double width() { return this->_width; }

    virtual double area() = 0;
};

class Circle: public Shape {
public:
    Circle(double w = 0.0) : Shape(w) {}

    double area() {
        return (width() * width() * 4.0 * atan(1));
    }
};

class Rectangle: public Shape {
private:
    double _height;
public:
    Rectangle(double w = 0.0, double h = 0.0) : Shape(w) {
        _height = h;
    }

    double area() {
        return _height * width();
    }
};

class Triangle: public Shape {

public:
    Triangle(double w = 0.0) : Shape(w) {}

    double area() {
        double p= width() * 3 / 2;

        return (sqrt(p *( p-width()) *( p-width()) *( p-width())));
    }
};

 vector<Shape *> read(istream &in) {
        vector<Shape *> shapes;

        int n;
        in >> n;

        int i = 0;
        double width, height;
        string type;
        while(n--) {
            in >> type;
            in >> width;
            
            if(type == "R") {
                in >> height;
                Rectangle *rec = new Rectangle(width, height);
                shapes.push_back(rec);
            } else if(type == "C") {
                Circle *cir = new Circle(width);
                shapes.push_back(cir);
            } else {
                Triangle *tri = new Triangle(width);
                shapes.push_back(tri);
            }
            i++;
        }

        return shapes;
    }

int main() {
    vector<Shape *> shapes;

    shapes = read(cin);

    double areaSum = 0;
    for(int i = 0; i < shapes.size(); i++) {
        areaSum += shapes[i]->area();
    }



    cout << fixed << setprecision(2) << areaSum << endl;
}       