#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <cmath>

using namespace std;

class Shape {
private:
    double l1,l2;
public:
    Shape(double n1, double n2): l1(n1), l2(n2) {}
    double width() {return l1;}
    void width(double n) {l1 = n;}
    double height() {return l2;};
    void height(double n) {l2 = n;};
    virtual double area() = 0;
};

class Circle: public Shape {
public:
    Circle(double n1, double n2=0): Shape(n1,n1) {}
    double area() {return width()*width()*atan(1)*4.0;}
};

class Triangle: public Shape {
public:
    Triangle(double n1, double n2=0): Shape(n1, (n2==0)? n1*sqrt(3)*((double)1/2): n2) {}
    double area() {return width()*height()*((double)1/2);}
};

class Rectangle: public Shape {
public:
    Rectangle(double n1, double n2=0): Shape(n1, (n2==0)? n1: n2) {}
    double area() {return width()*height();}
};

vector<Shape *> read(istream& in) {
    
    char c;
    in.get(c); getchar();
    int N = c-'0';
    vector<string> strs;
    string buf;
    for(int i=0;i<N;i++) {
        getline(in,buf);
        strs.push_back(buf);
    }
    
    vector<Shape*> V;
    for(string b:strs) {
        char shp = b[0];
        double l[2]={0,0};
        for(int i=1;i<b.length();i++) {
            if (b[i]>='0' && b[i]<='9') {
                int j;
                
                for(j=1;i+j<b.length() && b[i+j] != ' ';j++) {}
                
                if (l[0] == 0) 
                    l[0] = stod(b.substr(i,i+j));
                else 
                    l[1] = stod(b.substr(i,i+j));
                
                i = i+j;
            }
        }
        if (shp == 'C'){
            V.push_back(new Circle(l[0]));
        //    cout << "Circle: " << V.back()->width() << " " << V.back()->height() << endl;
        }
        
        else if (shp == 'R'){
            V.push_back(new Rectangle(l[0],l[1]));
        //    cout << "Rectangle: " << V.back()->width() << " " << V.back()->height() << endl;
        }
        else if (shp == 'T'){
            V.push_back(new Triangle(l[0],l[1]));
        //    cout << "triangle: " << V.back()->width() << " " << V.back()->height() << endl;
        }
    }
    
    return V;
}

int main() 
{
    vector<Shape*> V = read(cin);
    double sum = 0;
    for(Shape *p: V) {
    //    cout << p->area() << endl;
        sum += p->area();
    }
    cout << fixed << setprecision(2) << sum << endl;
}