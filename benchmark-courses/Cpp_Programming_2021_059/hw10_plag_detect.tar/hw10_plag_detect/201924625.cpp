#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <string>

const double tr_ar_const = sqrt(3) / 4.0;
const double pi = atan(1) * 4.0;

using namespace std;

class Shape
{
public:
    Shape(double r) : _r(r) {}
    Shape(double width, double height) : _width(width), _height(height) {}
    double radius() { return _r; }
    double width() { return _width; }
    double height() { return _height; }
    virtual double area() = 0;

private:
    double _width;
    double _height;
    double _r;
};

class Rectangle : public Shape
{
public:
    Rectangle(double width, double height) : Shape(width, height) {}
    double area();
};
double Rectangle::area()
{
    return width() * height();
}

class Circle : public Shape
{
public:
    Circle(double r) : Shape(r) {}
    double area();
};
double Circle::area()
{
    return radius() * radius() * pi;
}

class Triangle : public Shape
{
public:
    Triangle(double r) : Shape(r) {}
    double area();
};
double Triangle::area()
{
    return radius() * radius() * tr_ar_const;
}

vector<Shape *> read(istream &in)
{
    int n;
    in >> n;
    string s;
    double a, b;
    vector<Shape *> vec;
    while (n--)
    {

        in >> s;
        // cout << s << endl;
        if (s == "R")
        {
            in >> a >> b;

            // cout << a << " " << b << endl;
            vec.push_back(new Rectangle(a, b));
        }
        else
        {
            in >> a;
            if (s == "C")
                vec.push_back(new Circle(a));
            else
                vec.push_back(new Triangle(a));
        }
    }
    return vec;
}
double area(vector<Shape *> arr)
{
    int sz = arr.size();
    double Area = 0.0;
    while (sz--)
    {
        Area += arr[sz]->area();
    }
    return Area;
}
int main()
{
    vector<Shape *> arr = read(cin);
    cout << fixed << setprecision(2) << area(arr);
}