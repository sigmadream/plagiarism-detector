#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
using namespace std;

class Shape{
    protected:
        double r;
    public:
        Shape(double r):r(r){}
        virtual double area()=0;

};
class Circle: public Shape{
    public:
    Circle(double r):Shape(r){}
    double area(){
        return (r*r*(atan(1)*4.0));
    }


};
class Rectangle: public Shape{
    private:
        double l;
    public:
    Rectangle(double r,double l):Shape(r),l(l){}
    double area(){
        return (r*l);
    }
};
class Triangle : public Shape{
    public:
    Triangle(double r):Shape(r){}
    double area(){
        return ((r * ((sqrt(3)/2)*r))/2);
    }
};

int main(){
    int n;
    cin>>n;

    vector<Shape *> shape;

    for(int i=0;i<n;i++){
        char ch;
        double r;
        cin>>ch>>r;
        
        if(ch=='C'){
            Circle * c = new Circle(r);
            shape.push_back(c);
        }else if(ch=='T'){
            Triangle * t =new Triangle(r);
            shape.push_back(t);
        }else{
            double l;
            cin>>l;
            Rectangle * rt = new Rectangle(r,l);
            shape.push_back(rt);
        }
    }
    double sum=0;

    for(Shape * sp :shape){
        sum+=sp->area();
    }

    cout<< fixed << setprecision(2)<<sum<<endl;

}