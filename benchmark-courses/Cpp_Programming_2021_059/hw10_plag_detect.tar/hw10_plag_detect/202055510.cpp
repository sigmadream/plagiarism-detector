#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>
#include <string>

using namespace std;

class Shape{
	public:
		virtual double area(vector<Shape *>) = 0;
};

class Circle : public Shape{
	private:
		double _r;
	
	public:
		Circle(double r) : _r(r) {}
		double area(vector<Shape *>){
			return _r*_r*atan(1)*4.0;
		}
};

class Rectangle : public Shape{
	private:
		double _w;
		double _h;
	
	public:
		Rectangle(double w, double h) : _w(w), _h(h) {}
		double area(vector<Shape *>){
			return _w*_h;
		}
};

class Triangle : public Shape{
	private:
		double _h;
	
	public:
		Triangle(double h) : _h(h) {}
		double area(vector<Shape *>){
			return _h * _h * sqrt(3) / 4;
		}
};

vector<Shape *> read(istream& in){
	int n;
	in >> n;
	
	vector<Shape *>v;
	
	for(int i = 0; i < n; i++){
		string s;
		in >> s;
		if (s == "C") {
			double d;
			in >> d;
			Circle * c = new Circle(d);
			v.push_back(c);
		}
		else if(s == "T"){
			double d;
			in >> d;
			Triangle * t = new Triangle(d);
			v.push_back(t);
		}
		else{
			double d1, d2;
			in >> d1 >> d2;
			Rectangle * r = new Rectangle(d1, d2);
			v.push_back(r);
		}
	}
	
	return v;
}

int main(){
	vector<Shape *> arr = read(cin);
	
	double sum = 0;
	
	for(Shape* s: arr){
		sum += s->area(arr);
	}
	
	cout << fixed << setprecision(2) << sum << endl;
}
