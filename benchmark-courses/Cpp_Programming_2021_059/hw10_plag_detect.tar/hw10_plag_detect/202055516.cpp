#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <string>

class Shape
{
public :
    virtual double area() {return 0;}
};

class Circle : public Shape
{
private :
    double _r;
public :
    Circle(double r) : _r(r) {}
    double area() { return _r*_r*atan(1)*4.0;}
};

class Rectangle : public Shape
 {
private :
    double _w;
    double _h;
public :
    Rectangle(double w, double h) : _w(w), _h(h) {}
    double area() { return _w*_h;}
};

class Triangle : public Shape
{
private :
    double _len;
public :
    Triangle(double len) : _len(len) {}
    double area() { return _len*_len*sqrt(3)/4;}
};


int main()
{
    int num_input = 0;
    std::cin>>num_input;
    std::string s;
    double l,h;
    std::vector<std::string> str;
    std::vector<std::string> shape = {"C", "T", "R"};
    std::vector<double> length;
    Shape *shp[num_input];
    int j=0;
    for(int i=0; i< num_input;i++)
    {
        while(std::cin>>s)
        {
            str.push_back(s);
            j++;
        }
    }
    double add=0;
    for(int i=0; i< j-1;i++)
    {
        if(!str[i].compare(shape[0]))
        {
            shp[i] = new Circle(std::stod(str[i+1]));
            add += shp[i] ->area();
            i++;
        } else if(!str[i].compare(shape[1]))
        {
            shp[i] = new Triangle(std::stod(str[i+1]));
            add += shp[i] ->area();
            i++;
        } else if(!str[i].compare(shape[2]))
        {
            shp[i] = new Rectangle(std::stod(str[i+1]), std::stod(str[i+2]));
            add += shp[i] ->area();
            i += 2;
        }
    }
    std::cout << std::fixed << std::setprecision(2) << add;
}
