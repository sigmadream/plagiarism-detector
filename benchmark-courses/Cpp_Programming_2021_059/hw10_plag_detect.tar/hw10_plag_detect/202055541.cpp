#include <iostream>
#include<vector>
#include<cmath>
#define _USE_MATH_DEFINES
using namespace std;
    vector<char> shape(100);
    vector<double> num(100);
    vector<double> sum(100);
    vector<double> rec(100);
    vector<double> rec_sum(100,0);


class hello{ 
public:

    int n;
    int rn;
    
    double pi = 3.14159265358979;
    double answer=0;


    double  circle(int r) {
       return  (double) r* r * pi ;
    }
    double rectangle(int a , int b) {
        return (double) a * b ;
    }
    double triangle(int a) {
        return  (double) a * a * sqrt(3)/4;
    }



    void figure() {

        for (int i = 0; i <= n - 1; i++) {
            if (shape[i] == 'C') {
                sum[i] = circle(num[i]);
          

            }
         
            else if (shape[i] == 'T') {
                sum[i] = triangle(num[i]);
             
            }
        }

       int a = 0;
       int b = 0;
        for (int i = 0; i <= n-1; i++) {
            if (shape[i] == 'R') {
                rec_sum[b] = rectangle(rec[a], rec[a + 1]);
                a = a+2;
                b = b + 1;
             
            }
        }


    }

   void result() {
        for (int i = 0; i <= n-1 ; i++) {
            answer += sum[i];           
         }
        for (int i = 0; i <= rn; i++) {
            answer += rec_sum[i];
            }

        cout << fixed;
        cout.precision(2);
        cout << answer << endl;
     
    }


};



int main() {
    int n;
    cin >> n;
    int rn = 0;


    for (int i = 0; i <= n - 1; i++) {
        int a = 0;
        cin >> shape[i] ;
        if (shape[i] == 'C') {
            cin >> num[i];
        }
        else if (shape[i] == 'R') {
            cin >> rec[a] >> rec[a+1];
            a = a + 2;
            rn += 2;
        }
        else if (shape[i] == 'T') {
            cin >> num[i];
        }
    }

   

    hello w = { n , rn };
    w.figure();
    w.result();

 
    return 0;
}


