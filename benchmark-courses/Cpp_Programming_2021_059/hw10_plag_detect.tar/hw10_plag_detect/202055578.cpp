#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

class Shape{
	public:
		Shape(double n = 0) : r(n) {}
	private:
		double r;	
};

class Circle:public Shape{
	private:
		double _r;
	public:
		Circle(double n =0):Shape(n) {_r = 0;}
		double area(double n){
			_r = n - 48;
//			cout << "_n : " << n << endl;
//			cout << "_r : " << _r << endl;
			return (atan(1) * 4.0 * _r * _r ) ;
		}
};

class Rectangle:public Shape{
	private:
		double _r;
	public:
		Rectangle(double n =0):Shape(n) {_r = 0;}
		double area(double n){
			_r = n - 48;
//			cout << "_n : " << n << endl;
//			cout << "_r : " << _r << endl;
			return ( _r * _r);
		}
};

class Triangle:public Shape{
	private:
		double _r;
	public:
		Triangle(double n =0):Shape(n) {_r = 0;}
		double area(double n){
			_r = n - 48;
//			cout << "_n : " << n << endl;
//			cout << "_r : " << _r << endl;
			return (sqrt(3) / 4 * _r * _r);
		}
};


int main(){
	int x;
	cin >> x;
	
	char a[x*2];
	int i = 0;
	while(cin>>a[i]){
		i++;
	}
	double sum = 0;
	for (int l = 0 ; l < i ;l++){
		if (a[l] == 'C'){
			Circle c ;
			
			sum += c.area(a[l+1]);
//			cout << "c" <<sum << endl;
			
		}
		if (a[l] == 'T'){
			
			Triangle t;
			sum += t.area(a[l+1]);
//			cout << "t" <<sum << endl;
			
		}
		if (a[l] == 'R'){
			Rectangle r;
			sum += r.area(a[l+1]);
//			cout << "r" <<sum << endl;
			
		}
	}
	cout <<fixed << setprecision(2) << sum << endl;

}
