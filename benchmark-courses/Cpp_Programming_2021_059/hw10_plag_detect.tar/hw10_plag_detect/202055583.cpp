#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
using namespace std;

class Shape {
protected:
	int x, y;

public:
	void setOrigin(int x, int y){
		this -> x=x ;
		this -> y=y;
	}
	virtual double getArea();
};

class Rectangle : public Shape{
private:
	double width, height;
public:
	void setWidth(int w){
		width = w;
	}
	void setHeight(int h){
		height = h;
	}
	double getArea(){
		return width * height;
	}
};

class Triangle : public Shape{ 
private:
	double length;
public:
	void setLength(int l){
		length = l;
	}
	double getArea(){
		return sqrt(3)/4*length*length;
	}
};

class Circle : public Shape{
private:
	double radius;
public:
	void setRadius(int r){
		radius = r;
	}
	double getArea(){
		return radius*radius*atan(1)*4.0;
	}
};

int main()
{   

}
