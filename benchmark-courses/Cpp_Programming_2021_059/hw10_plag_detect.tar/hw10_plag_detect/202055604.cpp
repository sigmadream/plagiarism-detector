#include <iostream>
#include <iomanip>
#include <cmath>
#include<cstdio>
using namespace std;


class Shape {
  private:
    double shapeArea;

  public:

    void setArea(double anArea) {
        shapeArea = anArea;
    }

    // Accessor
    double getArea() {
        return shapeArea;
    }
};




class Circle : public Shape {
  private:
    double _r;
  public:
    Circle(double r) : _r(r) {}
    void area() {
        setArea( _r*_r*atan(1)*4.0);
    };

};

class Triangle : public Shape {
  private:
    double _t;
  public:
    Triangle(double t) : _t(t) {}
    void area() {
        setArea( _t*_t/4*sqrt(3));
    };

};

class Rectangle : public Shape {
  private:
    double _s1;
    double _s2;
  public:
    Rectangle(double s1,double s2) : _s1(s1),_s2(s2) {}
    void area() {
        setArea( _s1*_s2);
    };

};

int main() {

    int lines;
    scanf("%d",&lines);

    double ans = 0;


    for(int j = 0;j<lines*2;j++){
        char type;
        double d1 = 0 ;
        double d2 = 0;
        scanf("%c",&type);

        if(type == 'R'){
            scanf("%lf %lf",&d1,&d2);
            Rectangle R(d1,d2);
            R.area();
            ans = ans + R.getArea();
            //cout << fixed << setprecision(2) << R.getArea() << endl;
        }
        if(type == 'T'){
            scanf("%lf",&d1);
            Triangle T(d1);
            T.area();
            ans = ans + T.getArea();
            //cout << fixed << setprecision(2) << T.getArea() << "t"<<endl;
        }
        if(type == 'C'){
            scanf("%lf",&d1);
            Circle c(d1);
            c.area();
            ans = ans + c.getArea();
            //cout << fixed << setprecision(2) << c.getArea() << endl;
        }


    }
    cout << fixed << setprecision(2) << ans << endl;

}




