#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <string>

using namespace std;
class Shape {
public:
    Shape(double r) : _r1(r), _r2(r) {}
    void Set_Val1(double r){ _r1=r; }
    void Set_Val2(double r){ _r2=r; }
    double Val1() { return _r1; }
    double Val2() { return _r2; }
    virtual double Area(){
        return _r1;
    }
private:
    double _r1, _r2;
};

class Circle : public Shape {
public:
    Circle(double r) : Shape(r) {}
    void Set_val(double r){
        Set_Val1(r);
    }
    double Area() {
        return Val1()*Val1()*atan(1)*4.0;
    }
};
class Triangle : public Shape {
public:
    Triangle(double r) : Shape(r) {}
    void Set_val(double r){
        Set_Val1(r);
    }
    double Area() {
        return Val1()*Val1()*sqrt(3)/4.0;
    }
};
class Rectangle : public Shape {
public:
    Rectangle(double r) : Shape(r) {}
    void Set_val(double r1, double r2){
        Set_Val1(r1);
        Set_Val2(r2);
    }
    double Area() {
        return Val1()*Val2();
    }

};

int main(){
    Circle c = Circle(0);
    Triangle t = Triangle(0);
    Rectangle r = Rectangle(0);
    string ch;

    string input;
    string first_input;
    int num;
    double val1, val2, sum=0;

    getline(cin,first_input);
    num=atoi(first_input.c_str());


    for(int i=0;i<num;i++){
        getline(cin, ch, ' ');
        if(ch=="C"){
            getline(cin, input);
            val1=stof(input);
            c.Set_val(val1);
            sum+= (&c)->Area();
        }
        else if(ch=="T"){
            getline(cin, input);
            val1=stof(input);
            t.Set_val(val1);
            sum+= (&t)->Area();
        }
        else{
            getline(cin, input, ' ');
            val1=stof(input);
            getline(cin, input);
            val2=stof(input);
            r.Set_val(val1, val2);
            sum+= (&r)->Area();
        }
    }
    cout << fixed << setprecision(2) << sum << endl;

}
