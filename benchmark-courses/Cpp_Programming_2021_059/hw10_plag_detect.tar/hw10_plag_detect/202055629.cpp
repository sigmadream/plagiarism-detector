#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

class Shapes{
    double x, y;
public:
    Shapes(double n = 0, double m = 0): x(n), y(m) {}
    double val1(){return x;}
    double val2(){return y;}
    virtual double area() = 0;
};
class Circle : public Shapes{
public:
    Circle(double n) : Shapes(n) {}
    double area(){
        return val1()*val1()*atan(1)*4.0;
    }
};
class Rectangle : public Shapes{
public:
    Rectangle(double n, double m) : Shapes(n,m){}
    double area(){
        return val1()*val2();
    }
};
class Triangle : public Shapes{
public:
    Triangle(double n) : Shapes(n){}
    double area(){
        return sqrt(3)* val1()* val1() * 0.25;
    }
};

int main()
{
    int N;
    cin >> N;
    vector<Shapes* > sh;
    for(int i = 0; i < N; i++){
        double n=0.0, m=0.0;
        char ch;
        cin >> ch;
        if(ch == 'C'){
            cin >> n;
            sh.push_back(new Circle(n)); 
        }else if (ch == 'R'){
            cin >> n >> m;
           sh.push_back(new Rectangle(n,m));
        }else{
            cin >> n;
            sh.push_back(new Triangle(n));
        }
    }
    double Area = 0;
    for(int i = 0; i<N; i++){
        Area += sh[i]->area();
    }
    cout << fixed << setprecision(2) << Area;

}