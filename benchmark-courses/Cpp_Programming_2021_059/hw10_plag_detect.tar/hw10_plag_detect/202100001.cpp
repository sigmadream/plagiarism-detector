#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

class Shape
{
public:
    virtual double calArea() {return 0;}
};

class Circle: public Shape
{
private:
    double radius;
public:
    Circle(double r) : radius(r) {}
    double calArea() {return radius*radius*atan(1)*4.0;}
};

class Triangle: public Shape
{
private:
    double length;
public:
    Triangle(double l) : length(l) {}
    double calArea() {return (sqrt(3)/4.0)*length*length;}
};

class Rectangle: public Shape
{
private:
    double width, height;
public:
    Rectangle(double w, double h) : width(w), height(h) {}
    double calArea() {return width*height;}
    
};

vector<Shape *> read(istream& in, int n) {
    vector<Shape *> shapes;
    char s;
    double l, w, h;
    for (int i = 0; i < n; i++)
    {
        in >> s;
        if (s == 'C')
        {
            cin >> l;
            shapes.push_back(new Circle(l));
        }else if (s == 'T')
        {
            cin >> l;
            shapes.push_back(new Triangle(l));
        }else if (s == 'R')
        {
            cin >> w >> h;
            shapes.push_back(new Rectangle(w, h));
        }else{
            cout << "invalid shape: " << s << endl;
        }
}
    return shapes;
}

double area(vector<Shape *> shapes) {
    double totalArea = 0;
    for (auto &shape : shapes)
    {
        totalArea += shape->calArea();
    }
    return totalArea;
}

int main()
{
    vector<Shape *> shapes;
    int num;
    cin >> num;
    shapes = read(cin, num);
    double totalArea = area(shapes);
    cout << fixed << setprecision(2) << totalArea << endl;
}