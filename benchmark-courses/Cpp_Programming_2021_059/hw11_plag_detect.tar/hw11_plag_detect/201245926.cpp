#include <iostream>
using namespace std;

class Int {
    int_n;
public:
    Int(int n = 0): _n(n) {
        cout << "making Int(" << n << ").." << endl;
    }
    Int(const Int &i): _n(i._n) {
        cout << "calling the copy constructor for Int(" << i._n << ")" << endl;  
    }
    int get() {
        return _n;
    }
};

Int next(Int n)
{
    return int(n.get() + 1);
}

int main()
{
    Int a(3);
    Int b = next(a);
}

