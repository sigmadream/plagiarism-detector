#include <iostream>
using namespace std;

class IntStack
{
    int *_stack;
    int _size;
    int _now = -1;

public:
    IntStack(const int size)
    {
        this->_stack = new int[size];
        this->_size = size;
    }
    ~IntStack()
    {
        delete this->_stack;
    }
    const IntStack &operator=(const IntStack &s)
    {
        if (_stack)
            delete[] _stack;
        _now = s._now;
        _size = s._size;
        _stack = new int[_size];
        for (int i = 0; i < _size; ++i)
            _stack[i] = s._stack[i];
        return *this;
    }
    bool isEmpty()
    {
        if (this->_now < 0)
        {
            return true;
        }
        return false;
    }
    bool isFull()
    {
        if (this->_size == this->_now)
        {
            return true;
        }
        return false;
    }
    void push(int data)
    {
        if (!isFull())
        {
            this->_stack[++this->_now] = data;
        }
    }
    int pop()
    {
        if (!isEmpty())
        {
            return this->_stack[this->_now--];
        }
        return 0;
    }
    int show()
    {
        int n = 0;
        for (int i = 0; i <= this->_now; i++)
        {
            n = n * 10 + this->_stack[i];
        }
        return n;
    }
};

int rev(IntStack stack)
{
    int rev_n = 0;
    while (!stack.isEmpty())
    {
        rev_n = rev_n * 10 + stack.pop();
    }
    return rev_n;
}

int sub(int a, int b)
{
    if (a < b)
    {
        return b - a;
    }
    return a - b;
}

int main()
{
    int sz = 0, n = 0;

    cin >> sz;

    int sz_b = sz / 2;
    int sz_a = sz - sz_b;

    IntStack A = IntStack(sz_a);
    IntStack B = IntStack(sz_b);

    for (int i = 0; i < sz; i++)
    {
        cin >> n;
        if (i % 2)
        {
            B.push(n);
        }
        else
        {
            A.push(n);
        }
    }

    IntStack dummy_A = A;
    IntStack dummy_B = B;

    cout << sub(rev(dummy_A), rev(dummy_B)) << endl;
}