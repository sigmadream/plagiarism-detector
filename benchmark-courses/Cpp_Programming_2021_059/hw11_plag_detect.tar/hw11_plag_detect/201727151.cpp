#include <iostream>
using namespace std;

class IntStack {
private:
    int * _stack;
    int _size;
    int _top;
public:
    IntStack(const int size): _size(size), _top(-1) { _stack = new int[_size]; }
    ~IntStack() { delete[] _stack; };
    
    bool isEmpty() { return _top == -1; }
    bool isFull() { return _top == _size - 1; }
    void push(int data) { _stack[++_top] = data; }
    int pop() { return _stack[_top--]; }
};

int main(void) {
    int N, data;
    cin >> N;
    IntStack intStack(N);
    for (int i = 0; i < N; i++) {
        cin >> data;
        intStack.push(data);
    }
    
    int odd = 0;
    int even = 0;
    for (int i = 1; i <= N; i++) {
        if (i % 2 == 0) odd = odd * 10 + intStack.pop();
        else even = even * 10 + intStack.pop();
    }
    int diff = odd > even ? odd - even : even - odd;
    cout << diff;
}
