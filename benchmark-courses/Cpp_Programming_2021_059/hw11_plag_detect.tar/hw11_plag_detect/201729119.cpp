#include <cstdio>
#include <iostream>
#include <vector>
#include <string>
using namespace std;
class IntStack{
	int *_data;
	int _top, _size;
public:
	IntStack(const int size){
		_data = new int[size];
		_size = size;
	}
	~IntStack(){
		delete[] _data;
	}
	bool isEmpty();
	bool isFull();
	void push(int data){
		_data[--_size] = data;
	}
	int pop(){
		static int i = 0;
		return _data[i++];
	}
	
};



int main(){
	int k, i=0;
	int sum1 = 0, sum2 = 0;
	int size;
	cin >> size;
	IntStack S(size);
	while(cin >> k){
		S.push(k);
		i++;
		if (i == size) break;
	}
	for(int i = 0; i < size; i++){
		if (i%2 == 0 )sum1 = sum1*10 + S.pop();
		else sum2 = sum2*10 + S.pop();
	}
	cout << sum1 - sum2;

	
	

}

