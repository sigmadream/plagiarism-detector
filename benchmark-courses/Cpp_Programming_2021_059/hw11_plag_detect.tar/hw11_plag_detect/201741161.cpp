#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
using namespace std;

vector<int> v;
const int MAX = 10;
class IntStack {
private:
	int *_data;
	int _top, _size;
public:
	IntStack(int size=MAX);
	~IntStack();
	IntStack(const IntStack&);
	bool IsFull();
	bool IsEmpty();
	void Push(int d);
	int Pop();
};

IntStack::IntStack(int size): _top(0), _size(size){
	_data = new int[size];
}
IntStack::	~IntStack() {
	delete[] _data;
}
IntStack::IntStack(const IntStack& s): _top(s._top), _size(s._size){
	_data = new int[_size];
	for(int i = 0; i < _size; i++)
	_data[i] = s._data[i];
}
bool IntStack::IsFull(){
	return _top == _size;
}

bool IntStack::IsEmpty(){
	return _top == 0;
}

void IntStack::Push(int d){
	if(!IsFull())
		_data[_top++] = d;
}

int IntStack::Pop(){
	if(IsEmpty())
		return -1;
	else
		return _data[--_top];
}
void revPrint(IntStack s){
	while(!s.IsEmpty())
		cout << s.Pop() << endl;
}
void pushback(IntStack s){
	while(!s.IsEmpty())
		v.push_back(s.Pop());
}
int Pow(int p, int n) {
    int rslt = 1;
    while (n--) rslt *= p;
    return rslt;
}


int form_new_num(vector<int> a){
    int n1 = 0, n2 = 0;

    int s = a.size() / 2;
    if(a.size() % 2 == 1){
        for(int i = 0; i < s; i++){
            n1 += a[2*i] * Pow(10, s - i);
            n2 += a[2*i + 1] * Pow(10, s - i - 1);
        }
        n1 += a[a.size() - 1];
    }
    if(a.size() % 2 == 0){
        for(int i = 0; i < s; i++){
            n1 += a[2*i] * Pow(10, s - i - 1);
            n2 += a[2*i + 1] * Pow(10, s - i - 1);
        }
    }
    return abs(n1 - n2);
}
int main(){
	int x, n;
	IntStack s;
    cin >> n;
    for(int i = 0; i < n; i++){
        cin >> x;
        s.Push(x);
    }
    pushback(s);
    cout << form_new_num(v) << '\n';
}