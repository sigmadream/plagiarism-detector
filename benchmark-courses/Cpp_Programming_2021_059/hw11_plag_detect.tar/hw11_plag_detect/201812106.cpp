#include <iostream>
using namespace std;
class IntStack {
private:
	int* stack;
	int Csize;
	int Msize;
public:
	IntStack(const int size) {
		Csize = 0;
		stack = new int[size];
		Msize = size;
	}
	~IntStack() {
		delete[] stack;
	}
	bool isEmpty() {
		return (Csize == 0);
	}
	bool isFull() {
		return (Csize == Msize);
	}
	void push(int data) {
		if (isFull()) return;
		stack[++Csize] = data;
	}
	int pop() {
		if (isEmpty()) return -1;
		else return stack[Csize--];
	}
};
int main() {
	int n;
	cin >> n;
	IntStack st(n);
	for (int i = 1; i <= n; i++) {
		int x;
		cin >> x;
		st.push(x);
	}
	int l = 0, r = 0;
	while (!st.isEmpty()) {
		if (n % 2 == 0) {
			l *= 10;
			l += st.pop();
		}
		else {
			r *= 10;
			r += st.pop();
		}
		n -= 1;
	}
	cout << abs(l - r);
}