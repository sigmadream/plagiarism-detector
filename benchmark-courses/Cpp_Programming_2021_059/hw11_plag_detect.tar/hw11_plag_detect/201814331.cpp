#include <cstdio>
#include<cmath>
#include <iostream>
using namespace std;

int N;
int *ptr;

class IntStack {
	public :
		IntStack (const int size) {
			MaxSize = size;
    		stack = new int[MaxSize];
    		top = -1;
		}
		~IntStack() {
			delete ptr;
		}
 		bool isEmpty() {
    		if(top == -1) return 1;
    	else return 0;
		}
		bool isFull() {
    		if(top == MaxSize-1) return 1;
    		else return 0;
		}
		void push(int data) {
    		if(isFull() == 1);
    		else stack[++top] = data;
		}
		int pop() {
    		if(isEmpty() == 1);
    		else return stack[top--];
    		return 0;
		}
	private:
    	int top, MaxSize;
    	int *stack;
};


int main() {
	int i, a, oddstep = 0, evenstep = 0, oddnum[50], evennum[50], num1 = 0, num2 = 0;
	
	cin >> N;

	IntStack IS(N);	
	//IntStack *ptr = new IntStack(N);
	
	if (N > 0 && N < 500) {
		for ( i = 0; i < N; i++ ) {
			cin >> a;
			IS.push(a);
		}
		
		for ( i = 0; i < N; i++ ) {
			if (i % 2 == 1) {
				//cout << "pop is " << IS.pop() << "\n";
				oddnum[oddstep] = IS.pop();
				//cout << "oddnum : " << oddnum[oddstep] << "\n";
				oddstep++;					
			}
			else {
				//cout << "pop is " << IS.pop() << "\n";
				evennum[evenstep] = IS.pop();
				//cout << "evennum : " << evennum[evenstep] << "\n";
				evenstep++;				
			}
		}
		
		for ( i = 0; i < oddstep; i++ )
			num1 += oddnum[i] * pow(10, oddstep-i-1);
		for ( i = 0; i < evenstep; i++ )
			num2 += evennum[i] * pow(10, evenstep-i-1);		
				
		if ( num1 > num2 )
			cout << num1 - num2;
		else
			cout << num2 - num1;
	
	}
	
}
