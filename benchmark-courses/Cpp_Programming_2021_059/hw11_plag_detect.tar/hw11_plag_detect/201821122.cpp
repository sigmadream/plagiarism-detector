#include<iostream>
#include<cmath>

using namespace std;

class IntStack
{
private:
    int *_data;
    int top,size;

public:
    IntStack(const int size):top(0),size(size)
    {
        _data=new int[size];
    }
    IntStack(const IntStack &copy):top(copy.top),size(copy.size)
    {
        _data=new int[size];
        for(int i=0;i<size;++i)
        {
            _data[i]=copy._data[i];
        }
    }
    ~IntStack()
    {   
        delete []_data;
    }
    bool isEmpty()
    {
        return top==0;
    } 
    bool isFull()
    {
        return top==size;
    }
    void push(int data)
    {
        if(! isFull())
        {
            _data[top++]=data;
        }
    }
    int pop()
    {
        if(!isEmpty())
        {
            return _data[--top];
        }
        else return -1;
    }
};

int main(void)
{
    int numcount;
    cin>>numcount;

    if(numcount<2||numcount>100) return 0;
    IntStack s(numcount);

    int n;

    for(int i=0;i<numcount;i++)
    {
        cin>>n;
        s.push(n);
    }

    int a=0,b=0;
    for (int i=0;i<numcount;i++)
    {
        if(i%2==0) a=a*10+s.pop();
        else b=b*10+s.pop();
    }

    cout<<abs(a-b)<<endl;
}