#include <iostream>
#include <cmath>

#define MAX 100

using namespace std;

inline void error(char* x) {
	cout << x;
	exit(1);
}

template <typename T>
class IntStack {
	int top, _size;
	T * save;
	public:
		IntStack(const int size) {
			_size = size;
			save = new T[_size];
			top = -1;
		}
		~IntStack() { 
		delete[] save; 
		}
		bool isEmpty() {
			return top == -1;
		};
		bool isFull() {
			return top == _size-1;
		};
		void push(const T& data) {
			if (isFull()) error((char *)"isFull error");
			save[++top] = data;
		}
		T pop() {
			if (isEmpty()) error((char *)"isEmpty error");
			return save[top--];
		};
		
		void print() {
			for (int i = 0; i< top + 1; i++ )
			{
				cout << save[top - i] << endl;
			}
		}
};


int main() {
	IntStack<int> st(MAX);
	int n;
	cin >> n;
	
	int oddnum = 0;
	int evennum = 0;
	
	int x;
	
	int i;
	for (i=0; i<n; i++) {
		cin >> x;
		st.push(x);
	}
	
	i--;
	
	while(i>=0) {
		if (i%2 == 1) oddnum += st.pop() * pow(10, i/2);
		else evennum += st.pop() * pow(10, (i+1)/2);
		
		i--;
	}

	
	cout << abs(oddnum-evennum);	
	
}
