#include <iostream>
using namespace std;

class IntStack {
private:
	int _top, _size;
	int *_data;
public:
	IntStack(const int size): _top(0), _size(size) {
		_data = new int[size];
	}
	IntStack(const IntStack&s): _top(s._top), _size(s._size) {
		_data = new int[_size];
		
		for(int i=0; i<_size; i++)
			_data[i] = s._data[i];
	}
	~IntStack() {
		delete [] _data;
	}
	bool isEmpty() {
		return _top==0;
	}
	bool isFull() {
		return _top==_size;
	}
	void push(int data) {
		if(!isFull())
			_data[_top++] = data;
	}
	int pop() {
		if(!isEmpty())
			return _data[--_top];
		else
			return -1;
	}
};

int main()
{
	int num, n, odd = 0, even = 0, result;
	
	cin >> num;
	IntStack a(num);
	
	while(cin >> n)
		a.push(n);
	
	for(int i=0; i<num; i++){
		if(i%2==0){
			odd *= 10;
			odd += a.pop();
		}
		else{
			even *= 10;
			even += a.pop();
		}
	}
	result = odd-even;
	
	if(result<0)
		result *= -1;
	
	cout << result << endl;
}
