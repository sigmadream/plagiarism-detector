#include <stdio.h>
#include <math.h>

int main(){
	int many;
	scanf("%d",&many); //��Է¹�����?
	int a[100];
	int i=0;
	
	while(scanf("%d",&a[i])==1){
		i++;
	}
	int k=0;
	int first[100];
	int second[100];
	int firstnum=0;
	int secondnum=0;
	int x=0;
	int y=0;
	for(k=many-1; k>=0; k=k-2){
		first[x]=a[k];
		firstnum++;
		x++;
		}
		
	for(k=many-2; k>=0; k=k-2){
		second[y]=a[k];
		secondnum++;
		y++;
		}
	
	int n=0;
	int nbasu=firstnum-1;
	int firstsum=0;
	
	int m=0;
	int mbasu=secondnum-1;
	int secondsum=0;
	
	for(n=0; n<firstnum; n++){
		firstsum=firstsum+(first[n]*(pow(10,nbasu)));
		nbasu--;
	}
	

	for(m=0; m<secondnum; m++){
		secondsum=secondsum+(second[m]*(pow(10,mbasu)));
		mbasu--;
	}
	
	
	
	
	int result;
	result= firstsum-secondsum;
	if(result<0) printf("%d",-result);
	else printf("%d",result);

	

	
	
	
	
	
	
	
	return 0;
}
