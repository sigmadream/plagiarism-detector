#include <iostream>
#define SIZE 100
#include <stack>
using namespace std;

class Intstack {
    int* _data= new int[SIZE];
    int _top,_size,num1,num2;
    stack<int> st;
public:
    Intstack(int a);
    Intstack(const Intstack &i);
    bool isFull();
    bool isEmpty();
    void push(int d);
    int pop();
    void rev();
    void print();
    ~Intstack();
};

Intstack::Intstack(int a): _top(0), _size(a), num1(0), num2(0) {}
Intstack::Intstack(const Intstack &i): _top(i._top), _size(i._size), num1(i.num1), num2(i.num2) {}

bool Intstack::isFull() {
    return _top == _size;
}

bool Intstack::isEmpty() {
    return _top == 0;
}

void Intstack::push(int d) {
    if(!isFull()) _data[_top++] = d;
}

int Intstack::pop() {
    if(!isEmpty())
        return _data[--_top];
    else 
        return -1;
}

void Intstack::rev() {
    for (int i = 0; i < _top;i++) 
        st.push(_data[i]);
    for (int i = 0; i < _top;i++) {
        if (i%2==0) {
            num1 = num1 *10 + st.top();
        }
        else num2 = num2 * 10 + st.top();
        
        st.pop();
    }
}

void Intstack::print() {
    cout << num1 - num2;
}

Intstack::~Intstack() {
    delete[]_data;
}

int main() {
    int x,sz;
    cin >> sz;
    Intstack s(sz);
    
    for (int i = 0; i < sz; i++) {
        cin >> x;
        s.push(x);
    }
    s.rev();
    s.print();
    s.~Intstack();
}

