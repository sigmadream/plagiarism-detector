#include <iostream>
using namespace std;

class IntStack{
public:
    IntStack(int size):_top(0), _size(size){
        _data = new int[size];
    }
/*    IntStack(const IntStack& s): _top(s._top), _size(s._size){
        _data = new int[_size];
    }*/
    ~IntStack(){
        delete[] _data;
    }
    bool isfull(){
        return _top==_size;
    };
    bool isempty(){
        return _top==0;
    }
    void push(int d){
        if(! isfull())
            _data[_top++] = d;
    }
    int pop(){
        if(! isempty())
            return _data[--_top];
        else 
            return -1;
    }
private:
    int *_data;
    int _top, _size;
};
long long int pot(int i){
    if(i==0) return 1;
    return pot(i-1) * 10;
}
int abs(int x, int y){
    if (x >= y) return x-y;
    return y-x;
}
int diff(IntStack s, int sz){
    int n1 = 0, n2 = 0;
    int i = 0;
    int half = sz / 2, h1 = half, h2 = half;
    while(!s.isempty()){
        if(i%2==0){
            if(sz % 2 == 0){
                n1 += s.pop()*pot(h1-1);
                i++;
                h1--;
            }
            else{
                n1 += s.pop()*pot(h1);
                i++;
                h1--;
            }
        }
        else{
            if(sz % 2 == 0){
                n2 += s.pop()*pot(h2-1);
                i++;
                h2--;
            }
            else{
                n2 += s.pop()*pot(h2-1);
                i++;
                h2--;
            }
        }
    }
    return abs(n1, n2);
}
int main(){
    int x;
    int i = 0, sz;
    cin >> sz;
    IntStack s(sz);
    while (cin >> x){
        s.push(x);
        i++;
    }
    cout << diff(s, sz) << endl;
    s.~IntStack();

}
