#include<iostream>
using namespace std;
const int MAX = 100;

class IntStack {
public:
    IntStack(int size=MAX);
    IntStack(const IntStack&);
    ~IntStack();
    bool IsFull();
    bool IsEmpty();
    void Push(int d);
    int Pop();
    void getnum();
    int result();
    void print();
private:
    int *_data;
    int _top, _size;
};

IntStack::IntStack(int size): _top(0), _size(size){
    _data = new int[size];
}

IntStack::IntStack(const IntStack &s): _top(s._top), _size(s._size){
    _data = new int[_size];
    for (int i =0; i< _size; i++){
        _data[i] = s._data[i];
    }
}
IntStack::~IntStack(){
    delete[] _data;
}

bool IntStack::IsFull() {
    return _top == _size;
}

bool IntStack::IsEmpty(){
    return _top == 0;
}

void IntStack::Push(int d) {
    if (! IsFull())
    _data[_top++] =d;
}

int IntStack::Pop(){
    if (IsEmpty())
        return -1;
    else
        return _data[--_top];
}

void IntStack::getnum(){
    int x;
    while(! IsFull()){
        cin >> x;
        Push(x);
    }
}

int IntStack::result(){
    int num1 =0, num2 = 0;
    int power = 1;
    while(! IsEmpty()){
        num1 = num1 + Pop()*power;
        if (! IsEmpty()) num2 = num2 + Pop()*power;
        power = power*10;
    }
    int result = num1 - num2;
    if(result <0) result = result * (-1);
    return result;
}

void IntStack::print(){
    for(int i=0; i< _size; i++){
        cout << _data[i] << endl;
    }
}

void revsequece(IntStack &s, IntStack &a){
    while (! a.IsFull()){
        a.Push(s.Pop());
    }
} // 얘는 왜 class에 안있어도 되지? --> class 안에 안있으므로 destructor 실행 X (아마도??)



int main(){
    int sz;
    cin >> sz;
    IntStack s(sz);
    IntStack a(sz);
    s.getnum(); // method로 !!! class 밖의 function으로 하면 error! (destructor or value copy)
    revsequece(s, a);
    
    cout << a.result() << endl;
}