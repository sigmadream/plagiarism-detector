#include <iostream>
using namespace std;

class IntStack{
private:
    int *_data;
    int _size;
public:
    int _top;
    IntStack(int size = 0);
    IntStack(const IntStack& s);
    ~IntStack();
    bool isEmpty();
    bool isFull();
    void push(int data);
    int pop();
};

IntStack::IntStack(int size) : _top(0),_size(size){
    _data = new int[size];
}

IntStack::IntStack(const IntStack& s) : _top(s._top), _size(s._size) {
    _data = new int[_size];
    for (int i = 0; i < _size; ++i)
    _data[i] = s._data[i];
}

IntStack::~IntStack(){
    delete[] _data;
}

bool IntStack::isEmpty(){
    return _top == 0;
}

bool IntStack::isFull(){
    return _top == _size;
}

void IntStack::push(int data){
    if(!isFull())
        _data[_top++] = data;
}

int IntStack::pop(){
    if(!isEmpty())
        return _data[--_top];
    else
        return -1;
}

void store(IntStack s, int a[], int sz){
    for(int j=0;j<sz;j++)
        a[j] = s.pop();
}

int difference(int a[], int sz){
    int n1=0,n2=0,k1=1,k2=1;
    for(int j=sz-1;j>=0;j--){
        if(j%2==0){
            n1 = n1 + k1*a[j];
            k1 = k1*10;
        }
        else{
            n2 = n2 + k2*a[j];
            k2 = k2*10;
        }
    }
    return n1-n2;
}

int main(){
    int x,y;
    cin >> x;
    int a[x];
    IntStack s(x);

    while (cin >> y){
        s.push(y);
        if(s.isFull())
            break;
    }

    store(s,a,x);
    cout << difference(a,x) <<endl;
}