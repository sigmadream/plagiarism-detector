#include <iostream>
#include <stack>

#define STACK_MAX_SIZE 99

class IntStack
{
private:
	int* _value;
	int _size;
	int _top;

public:
	IntStack(int size = STACK_MAX_SIZE);
	IntStack(const IntStack& s);
	~IntStack();
	bool isEmpty();
	bool isFull();
	void push(int data);
	int pop();

};

void stackReverse(IntStack& s);


//////////// main ////////////
//////////////////////////////

int main()
{
	int n;
	std::cin >> n;

	IntStack inputStack(n);

	for (int i = 0; i < n; i++)
	{
		int inputNum;
		std::cin >> inputNum;
		
		inputStack.push(inputNum);
	}

	stackReverse(inputStack);
	IntStack oddIndexStack((n + 1) / 2);
	IntStack evenIndexStack((n + 1) / 2);

	for (int i = 0; i < n; i++)
	{
		if (i % 2 == 0)
		{
			evenIndexStack.push(inputStack.pop());
		}
		else
		{
			oddIndexStack.push(inputStack.pop());
		}
	}

	int num1 = 0;
	int num2 = 0;

	while (!oddIndexStack.isEmpty())
	{
		num1 = num1 * 10 + oddIndexStack.pop();
	}

	while (!evenIndexStack.isEmpty())
	{
		num2 = num2 * 10 + evenIndexStack.pop();
	}

	if (num1 < num2)
	{
		int temp = num1;
		num1 = num2;
		num2 = temp;
	}

	std::cout << num1 - num2 << std::endl;

	return 0;
}

//////////////////////////////
//////////////////////////////

IntStack::IntStack(int size) : _size(size), _top(0)
{
	_value = new int[_size];
}

IntStack::IntStack(const IntStack& s) : _size(s._size), _top(s._top)
{
	_value = new int[_size];
	for (int i = 0; i < _size; i++)
	{
		_value[i] = s._value[i];
	}
}

IntStack::~IntStack()
{
	delete[] _value;
}

bool IntStack::isEmpty()
{
	return _top == 0;
}

bool IntStack::isFull()
{
	return _top == _size;
}

void IntStack::push(int data)
{
	if (isFull())
	{
		std::cout << "Stack is full.\n";
	}
	else
	{
		_value[_top] = data;
		_top++;
	}
}

int IntStack::pop()
{
	int val = _value[_top - 1];
	_top--;

	return val;
}

void stackReverse(IntStack& s)
{
	IntStack copyStack = s;
	while (!s.isEmpty())
	{
		s.pop();
	}

	while (!copyStack.isEmpty())
	{
		s.push(copyStack.pop());
	}
}