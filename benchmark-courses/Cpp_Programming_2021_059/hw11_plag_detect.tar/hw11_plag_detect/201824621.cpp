#include <iostream>

using namespace std;

class IntStack
{
public:
    IntStack(const int size);
    IntStack(IntStack&);
    ~IntStack();
    bool isEmpty();
    bool isFull();
    void push(int data);
    int pop();
private:
    int * _data;
    int _size;
    int _top;
};

IntStack::IntStack(const int size): _size(size), _top(0) {
    _data = new int[size];
}

IntStack::IntStack(IntStack &s): _size(s._size), _top(s._top) {
    _data = new int[_size];
    for (int i = 0; i < _size; i++) {
        _data[i] = s._data[i];
    }
}

IntStack::~IntStack() {
    delete [] _data;
}

bool IntStack::isEmpty() {
    return _top == 0;
}

bool IntStack::isFull() {
    return _top == _size;
}

void IntStack::push(int data) {
    if (! isFull()) {
        _data[_top++] = data;
    }
}

int IntStack::pop() {
    if (! isEmpty()) {
        return _data[--_top];
    }
    else {
        return -1;
    }
}

int interleave(IntStack s) {
    int counter = 0, first = 0, second = 0;
    while (!s.isEmpty()) {
        if (counter % 2 == 0) {
            first += s.pop();
            first *= 10;
        }
        else {
            second += s.pop();
            second *= 10;
        }
        counter++;
    }
    int diff = first / 10 - second / 10;
    return abs(diff);
}

int main()
{
    IntStack s(100);
    int n,x;
    cin >> n;
    
    while (n--) {
        cin >> x;
        s.push(x);
    }

    cout << interleave(s) << endl;

}