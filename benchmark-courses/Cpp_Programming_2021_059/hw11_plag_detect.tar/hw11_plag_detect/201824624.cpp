#include <iostream>
#include <math.h>
using namespace std;

const int MAX = 100;

class IntStack {
public:
    IntStack(int size = MAX);
    IntStack(const IntStack &s);
    ~IntStack();
    bool IsEmpty();
    bool IsFull();
    void Push(int d);
    int Pop();
    int Calculate();
private:
    int *_data;
    int _top, _size;
};

IntStack::IntStack(int size): _top(0), _size(size) {
    _data = new int[size];
}

IntStack::IntStack(const IntStack &s): _top(s._top), _size(s._size) {
    _data = new int[_size];
    for(int i = 0; i < _size; i++)
        _data[i] = s._data[i];
}

IntStack::~IntStack() {
    delete [] _data;
}

bool IntStack::IsFull() {
    return _top == _size;   
}

bool IntStack::IsEmpty() {
    return _top == 0;
}

void IntStack::Push(int d) {
    if(!IsFull())
        _data[_top++] = d;
}

int IntStack::Pop() {
    if(IsEmpty())
        return -1;
    else
        return _data[--_top];
}

int IntStack::Calculate() {
    int retnum = 0;

    for(int i = 0; i < _top; i++)
        retnum = 10*retnum + _data[i];
        
    return retnum;
}

int revCal(IntStack s) {
    IntStack oddnum;
    IntStack evennum;

    int i = 0;
    while(! s.IsEmpty()) {
        int num = s.Pop();

        if(i % 2 == 1) {
            oddnum.Push(num);
        } else {
            evennum.Push(num);
        }
        i++;
    }

    int n1 = evennum.Calculate();
    int n2 = oddnum.Calculate();

    return abs(n1 - n2); 
}

int main() {
    int n;
    cin >> n;
    IntStack is(n);

    int num;
    while(n--) {
        cin >> num;
        is.Push(num);
    }

    cout << revCal(is) << endl;
}
