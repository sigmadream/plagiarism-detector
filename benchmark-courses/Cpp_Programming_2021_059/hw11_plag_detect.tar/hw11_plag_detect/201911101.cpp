#include <iostream>

using namespace std;

class IntStack {
public:
    IntStack(const int size);
    ~IntStack();
    IntStack(const IntStack &s); //copy constructor
    const IntStack& operator = (const IntStack& s); // assignment operator
    bool IsFull();
    bool IsEmpty();
    void Push(int data);
    int Pop();
    int rev_difference();
private:
    int *_data;
    int _top, _size;
};

IntStack::IntStack(const int size): _top(0), _size(size) {
    _data = new int[_size]; // memory allocation
}

IntStack::~IntStack() {
    delete[] _data; // memory deallocation
}

// deep copy
IntStack::IntStack(const IntStack &s): _top(s._top), _size(s._size) {
    _data = new int[_size];
    for (int i=0;i<_size;++i)
        _data[i] = s._data[i];
}

const IntStack& IntStack::operator = (const IntStack &s) {
    if (_data) delete [] _data;
    _top = s._top;
    _size = s._size;
    _data = new int[_size];
    for (int i = 0; i < _size; ++i) _data[i] = s._data[i];
    return *this;
}

bool IntStack::IsFull() {return _top == _size;}
bool IntStack::IsEmpty() {return _top == 0;}

void IntStack::Push(int data) {
    if(!IsFull())
        _data[_top++] = data;
}

int IntStack::Pop() {
    if(!IsEmpty())
        return _data[--_top];
    else
        return -1;
}

int IntStack::rev_difference() {
    int N1=0, N2=0;
    IntStack S(*this);
    for (int i=0;i<_top;i++) {
        if (i%2==0)
            N1 = 10*N1 + S.Pop();
        else
            N2 = 10*N2 + S.Pop();
    }
    return N1 > N2? N1-N2: N2-N1;
}

int main() {
    int sz;
    cin >> sz;
    IntStack s(sz);
    int n;
    while(cin >> n) s.Push(n);

    cout << s.rev_difference();
}