#include <iostream>
#include <stack>
using namespace std;

class IntStack
{
    int _size;
    stack<int> mystack;

public:
    IntStack(const int size = 0);
    IntStack(const IntStack &i) : mystack(i.mystack), _size(i._size)
    {
    }
    // ~IntStack();
    int pop()
    {
        int o = mystack.top();
        mystack.pop();
        _size--;
        return o;
    };
    stack<int> get();
    bool isEmpty()
    {
        if (_size == 0)
            return true;
        else
            return false;
    }
    bool isFull()
    {
        if (_size == mystack.size())
            return true;
        else
            return false;
    };
    void push(int data)
    {
        mystack.push(data);
        _size++;
    }
};

IntStack::IntStack(const int size)
{
    _size = size;
}

int toInt(IntStack st)
{
    IntStack e;
    int i = 0;
    while (!st.isEmpty())
    {
        e.push(st.pop());
    }

    int k = 0;
    while (!e.isEmpty())
    {
        int y = e.pop();
        i = i * 10 + y;
        k++;
    }
    return i;
}

int min(int a, int b)
{
    if (a > b)
        return b;
    else
        return a;
}

int max(int a, int b)
{
    if (a < b)
        return b;
    else
        return a;
}

int main()
{
    IntStack a, b, c;
    int n, d;
    cin >> n;
    while (n--)
    {
        cin >> d;
        a.push(d);
    }
    bool t = false;
    while (!a.isEmpty())
    {

        if (t)
            b.push(a.pop());
        else
            c.push(a.pop());
        t = !t;
    }
    IntStack cc(c), bb(b);
    int gb = toInt(bb), gc = toInt(cc);
    cout << max(gb, gc) - min(gb, gc);
}