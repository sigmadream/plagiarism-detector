#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

vector<int> vec;
int N;

class Instack{
    public:
        Instack(int size):size(size){
            arr = new int[size];
        }
        Instack(const Instack &rhs):size(rhs.size),top(rhs.top){
            arr = new int[size];
            for(int i=0;i<N;i++){
                arr[i] = rhs.arr[i];
            }
        }
        ~Instack(){
            delete[] arr;
        }
        bool isEmpty(){
            return top==-1;
        }
        bool isFull(){
            return ((size-1)==top);
        }
        void push(int data){
            top++;
            arr[top]=data;
        }
        int pop(){
            return arr[top--];
        }
    private:
        int * arr;
        int top=-1;
        int size;
};



int main(){
    cin>>N;

    Instack A(N);
    int rst=0;

    for(int i=0;i<N;i++){
        int num;
        cin>>num;
        A.push(num);
    }

    Instack B(N);

    while(!A.isEmpty()){
        int num = A.pop();
        B.push(num);
    }
    int i=0,j=0; // 두개의 결과
    int k=0; // 반복횟수 카운트
    int r=1; // 첫번째 시퀀스 자릿수
    int l=1; // 두번째 시퀀스 자릿수
    while(!B.isEmpty()){
        int num = B.pop();
        
        if(k%2==0){
            i+=(num*r);
            r*=10;
        }else{
            j+=(num*l);
            l*=10;
        }
        k++;
    }
   
    rst = abs(i-j);
    cout<<rst;
}