#include <iostream>

using namespace std;

class IntStack{
	private:
		int * _data;
		int _top, _size;
		
	public:
		IntStack(const int size): _top(0), _size(size){
			_data = new int[size];
		}
		
		IntStack(const IntStack& is): _top(is._top), _size(is._size){
			_data = new int[_size];
			for (int i = 0; i < _size; i++){
				_data[i] = is._data[i];
			}
		}
		
		~IntStack(){
			delete [] _data;
		}
		
		bool isEmpty(){
			return _top == 0;
		}
		
		bool isFull(){
			return _top == _size;
		}
		
		void push(int data){
			if(!this->isFull()){
				_data[_top++] = data;
			}
		}
		
		int pop(){
			if(!this->isEmpty()){
				return _data[--_top];
			}
			else{
				return -1;
			}
		}
};

int main(){
	int n;
	cin >> n;
	IntStack s1(n);
	
	int k;
	while(cin >> k){
		s1.push(k);
	}
	
	IntStack s2(s1);
	
	int n1, n2 = 0;
	int chk = 1;
	
	for(int i = 0; i < n; i++){
		if(chk){
			n1 *= 10;
			n1 += s2.pop();
			chk = 0;
		}
		else{
			n2 *= 10;
			n2 += s2.pop();
			chk = 1;
		}
	}
	
	if(n1 > n2)
		cout << n1-n2 << endl;
	else
		cout << n2-n1 << endl;
}
