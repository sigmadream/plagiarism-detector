#include <iostream>
using namespace std;

class IntStack {
    int *_data;
    int _top, _size;
public:
    IntStack(const int size)
    {
        _data = new int[size];
        _size = size;
        _top = 0;
    }

    IntStack(const IntStack& s) : _top(s._top), _size(s._size) {
        _data = new int[_size];
        for (int i = 0; i < _size; ++i)
            _data[i] = s._data[i];
    }

    ~IntStack()
    {
        delete [] _data;
    }

    bool IsFull()
    {
        return _top ==_size;
    }

    bool IsEmpty()
    {
        return _top==0;
    }

    void Push(int data)
    {
        if(!IsFull())
            _data[_top++] = data;
    }

    int pop()
    {
        if(!IsEmpty())
            return _data[--_top];
        else
            return -1;
    }

    const IntStack& revStack(const IntStack & s)
    {
        if(_data) delete[] _data;
        _top = s._top;
        _size = s._size;
        int j=0;
        for (int i=_size-1; i>=0;i--)
        {
            _data[j] = s._data[i];
            j++;
        }
        return *this;
    }

    int interStack(const IntStack & s, int start)
    {
        int addUp = 0;
        for (int i=start; i<_size;i+=2)
        {
            addUp *= 10;
            addUp += _data[i];
        }
        return addUp;
    }
};

int printDiff(int t1, int t2)
    {
        if(t1 > t2)
            return t1 - t2;
        else
            return t2 - t1;
    }

int main()
{
    int numInput, i=0, intInput;
    cin >>numInput;
    IntStack s(numInput);
    while(i++<numInput)
    {
        cin >>intInput;
        s.Push(intInput);
    }
    IntStack t(s);
    t = t.revStack(s);
    int t1 = t.interStack(t,0);
    int t2 = t.interStack(t, 1);
    cout <<printDiff(t1,t2) <<endl;
}
