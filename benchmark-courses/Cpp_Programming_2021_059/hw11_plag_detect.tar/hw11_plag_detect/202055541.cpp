#include <iostream>
#include<stack>
#include<math.h>

using namespace std;
stack <int> s;

class IntStack {
	int n;

public:
	IntStack( int size) {
		size = n;
	}

	~IntStack() {

	}

	bool isEmpty() {
		if (s.empty()) {
			//printf("empty");
			return 1;
		}
		else {
			//printf("not empty");
			return 0;
		}
	}

	bool isFull() {
		if (s.top() == 0) {
			return 0;
		}
		else {
			return 1;
		}
	}

	void push(int data) {
		s.push(data);
	}


	int pop() {
		int a=s.top();
		s.pop();
		//printf("%d " , a);
		return a;
	}

};


int main() {
	int n;
	int data;
	int res1 = 0, res2 = 0;
	scanf("%d", &n);

	IntStack* a = new IntStack(n);

	for (int i = 0; i < n; i++) {
		scanf("%d", &data);
		a->push(data);
	}

	int a1, a2;

	int i = 1;

	if (n % 2 == 0) {
		a1 = (n + 2) / 2;
		a2 = (n + 2) / 2 - 1;
		while (1) {
			if ((a->isEmpty()) == 1) {
				printf("%d", res1/10 - res2);
				break;
			}
			else {
				res1 += a->pop() * pow(10, a1 - i);
				res2 += a->pop() * pow(10, a2 - i);
			}
			i += 1;
		}
	}
	
	else {
		a1 = (n + 1) / 2;
		a2 = (n + 1) / 2;
		while (1) {
			if ((a->isEmpty()) == 1) {
				break;
			}
			res1 += a->pop() * pow(10, a1 - i);
			
			if ((a->isEmpty()) == 1) {
				break;
			}
			res2 += a->pop() * pow(10, a2 - i);
			
			i += 1;
		}
		printf("%d", res1- res2/10);
	}
	
	
		
	
	//printf("res1 : %d \n res2 : %d", res1, res2);
	
	delete a;



}