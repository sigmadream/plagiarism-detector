#include <iostream>
using namespace std;
const int MAX = 10;

class Stack {
public : 
    Stack(int size = MAX);
    Stack(const Stack&);
    ~Stack();
    bool IsFull();
    bool IsEmpty();
    void Push(int d);
    int Pop();
private:
    int *_data;
    int _top, _size;
};

Stack::Stack(int size): _top(0), _size(size){
    _data = new int[size];
}

Stack::Stack(const Stack &s): _top(s._top), _size(s._size){
    _data = new int[_size];
    for (int i = 0; i < _size; ++i)
        _data[i] = s._data[i];
}

Stack::~Stack() {
    delete[] _data;
}

bool Stack::IsEmpty() {
    return _top ==0;
}

void Stack::Push(int d){
    if(! IsFull())
        _data[_top++] = d;
}

int Stack::Pop() {
    if (IsEmpty())
        return -1;
    else 
        return _data[--_top];
}

void revPrint(Stack s){
    while (! s.IsEmpty())
        cout << s.Pop() << endl;
}

int main() {
    int x;
    Stack s;
    while (cin >>x){
        s.Push(x);
    }
    revPrint(s);
    
}