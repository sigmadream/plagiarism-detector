#include <iostream>
#include <cstdio>
#include<vector>
#include<cstdlib>
using namespace std;

class IntStack {
    int *s_mem;
    int top;
    int sizer;
  public:
    IntStack(const int size): sizer(size) {
        top = -1;
        s_mem = new int[sizer];
    } // a constructor

    ~IntStack() {
        delete s_mem;
    };

    bool isEmpty() {
        if (top == -1)
            return true;
        else
            return false;

        };
    bool isFull() {
        if (top >= sizer)
            return true;
        return false;
    };

    void push(int item){
    if (isFull()) 0;
    else s_mem[++top] = item;
    }
    int pop(){
        int j = s_mem[top];
        top--;
        return j;
    };// pops and returns the top element


};
int reversed(int n){
    int reversedNumber = 0;
while(n != 0) {

        int remainder = n%10;
        reversedNumber = reversedNumber*10 + remainder;
        n /= 10;
    }
    return reversedNumber;
}

int main() {
    int a;
    scanf("%d",&a);

    IntStack odd(a/2 );
    IntStack even((a+1)/2);
    for(int j = 0;j<a;j++){
        int b;
        scanf("%d",&b);
        if(j % 2 == 0){
            even.push(b);
        }
        else{
            odd.push(b);
        }
    }

    int eve = 0;
    int epower = 1;
    int ody = 0;
    int opower = 1;
    for(int j =0 ;j<(a+1)/2;j++){
        eve = eve + even.pop()*epower;
        epower = epower * 10;
    }

    for(int j =0 ;j<a/2;j++){
        ody = ody + odd.pop()*opower;
        opower = opower * 10;
    }
    printf("%d",abs(reversed(eve)-reversed(ody)));

}
