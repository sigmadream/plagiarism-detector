#include <iostream>
#define SIZE 10
using namespace std;

class IntStack {
public:
    IntStack(int size = SIZE);
    IntStack(const IntStack& s);
    const IntStack& operator = (const IntStack& s);
    ~IntStack();
    bool isFull();
    bool isEmpty();
    void push(int d);
    int pop();
private:
    int *_data;
    int _top, _size;
};

IntStack::IntStack(const int size) : _top(0), _size(size) {
    _data = new int[size];
}
IntStack::IntStack(const IntStack& s) : _top(s._top), _size(s._size) {
    _data = new int[_size];
    for (int i = 0; i < _size; ++i)
        _data[i] = s._data[i];
}
const IntStack& IntStack::operator = (const IntStack &s) {
    if (_data)
        delete [] _data;
    _top = s._top;
    _size = s._size;
    _data = new int[_size];
    for (int i = 0; i < _size; ++i)
        _data[i] = s._data[i];
    return *this;
}
IntStack::~IntStack() {
    delete [] _data;
}

bool IntStack::isFull() {
    return _top == _size;
}
bool IntStack::isEmpty() {
    return _top == 0;
}
void IntStack::push(int data) {
    if (! isFull())
    _data[_top++] = data;
}
int IntStack::pop() {
    if (! isEmpty())
        return _data[--_top];
    else
        return -1;
}
int formnum(IntStack s){
    int button=1, result=0;
    while(!s.isEmpty()){
        if(button==1){
            result*=10;
            result+=s.pop();
            button=0;
        }
        else{
            s.pop();
            button=1;
        }
    }
    return result;

}

int main()
{
    int x, num1, num2;
    cin >> x;
    IntStack s(x);
    IntStack t;
    while (cin >> x) {
        s.push(x);
    }
    t = s;
    t.pop();
    num1 = formnum(s);
    num2 = formnum(t);
    if(num1>num2){
        printf("%d", formnum(s)-formnum(t));
    }
    else{
        printf("%d", formnum(t)-formnum(s));
    }
    return 0;
}
