#include <iostream>
#include <vector>
using namespace std;


class IntStack {
    int _size, _top;
    int* _data;
public:
    IntStack(int size = 0);
    ~IntStack();
    IntStack(const IntStack &S);
    const IntStack& operator= (const IntStack& S);
    bool isfull();
    bool isempty();
    void push( int d);
    int pop();
    void Rev();
    int getSize();
    int* getData();
};
IntStack::IntStack(int size): _size(size), _top(0) {
    _data = new int[_size];
}
IntStack::~IntStack(){
    delete[] _data;
}
IntStack::IntStack(const IntStack& S): _size(S._size), _top(S._top){
    _data = new int[_size];
    for(int i = 0; i<_size; i++)
        _data[i] = S._data[i];
}
const IntStack& IntStack::operator=(const IntStack& S){
    if(_data) delete[] _data;
    _top = S._top;
    _size = S._size;
    _data = new int[_size];
    for(int i = 0; i<_size; i++)
        _data[i] = S._data[i];
    return *this;
}
bool IntStack::isfull(){
    return _top == _size;
}
bool IntStack::isempty(){
    return _top == 0;
}
void IntStack::push(int d){
    if(!isfull())
        _data[_top++] = d;
}
int IntStack::pop(){
    if(!isempty())
        return _data[--_top];
    else        
        return -1;
}
int IntStack::getSize(){
    return _size;
}
int* IntStack::getData(){
    return _data;
}
void IntStack::Rev(){
    int *temp = new int[_size];
    for(int i = 0; i < _size; i++){
        temp[i] = _data[_size-1-i];
    }
    delete[] _data;
    _data = new int[_size];
    for(int i = 0; i < _size; i++)
        _data[i] = temp[i];
}
void PrintRev(IntStack C){
    int x=0,y=0;
    int *data = C.getData();
    for(int i = 0;i<C.getSize(); i++){
        if(i%2)
            y = y*10 + data[i];
        else
            x = x*10 + data[i];
    }
    if(x-y>=0) cout << x-y;
    else cout << y-x;
}

int main(){
    int size, x;
    cin >> size;
    IntStack s(size);
    while(cin >> x){
        s.push(x);
        if(s.isfull()) break;
    }
    s.Rev();
    IntStack C;
    C = s;
    PrintRev(C);
}