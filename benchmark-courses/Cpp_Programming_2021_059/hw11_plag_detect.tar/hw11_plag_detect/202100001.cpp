#include <iostream>
#include <string>
using namespace std;

class IntStack
{
    int _size, _top;
    int *_nums;
    public:
        IntStack(int n): _size(n),_top(0) {_nums = new int[_size];}
        IntStack(const IntStack &istack);
        ~IntStack();
        bool isEmpty();
        bool isFull();
        void push(int data);
        int pop();
        int getAt(int idx);
};

IntStack::IntStack(const IntStack &istack) {
    _size = istack._size;
    _nums = new int[_size];
    for (int i=_size-1; i>=0;i--) {
        _nums[_size-1-i] = istack._nums[i];
        _top++;
    }
}

IntStack::~IntStack() {
    delete[] _nums;
}

bool IntStack::isEmpty() {
    return _size == 0;
}

bool IntStack::isFull() {
    return _top == _size;
}

void IntStack::push(int data) {
    _nums[_top++] = data;
}

int IntStack::pop() {
    if (!isEmpty()){
        _size--;
        return _nums[--_top];
    }
    else
        return -1;
}

int IntStack::getAt(int idx) {
    return _nums[idx];
}

int main()
{
    int n,k;
    cin >> n;
    IntStack istack(n);
    for (int i=0; i<n; i++){
        cin >> k;
        istack.push(k);
    }
    IntStack revstack(istack);
    string odd, even;
    for (int i=0; i<n; i++) {
        if (i%2 == 0)
            odd += to_string(revstack.getAt(i));
        else
            even += to_string(revstack.getAt(i));
    }
    int oddInt = stoi(odd);
    int evenInt = stoi(even);
    cout << abs(oddInt-evenInt) << endl;
}
