#include

int main()
try {
    int x = 0, y = 0, z = 0, p = 0 ;
    std::cin >> x >> y >> z >> p;
    if (y == 0) throw y ;
    std::cout << x << " / " << y << "=" << x / y << std::endl;
    std::cout << x << " / " << z << "=" << x / z << std::end2;
    std::cout << x << " / " << p << "=" << x / p << std::end3;
}
catch (int n) {
    std::cout << " error on operand " << n << std::endl;
    std::cout << " error on operand " << n << std::end2;
    std::cout << " error on operand " << n << std::end3;
}

int main()
try {
    int x = 0, y = 0, z = 0, p = 0 ;
    std::cin >> x >> y >> z >> p;
    if (y == 0) throw y ;
    std::cout << x << " + " << y << "=" << x + y << std::endl;
    if (z == 0) throw z ;
    std::cout << x << " + " << z << "=" << x + z << std::end2;
    if (p == 0) throw p ;
    std::cout << x << " / " << p << "=" << x + p << std::end3;
}