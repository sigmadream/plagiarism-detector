#include <iostream>
using namespace std;

class IntSet
{
    int ns[100];
    int size;

public:
    IntSet(int ns[], int size)
    {
        this->size = size;
        for (int i = 0; i < size; i++)
        {
            this->ns[i] = ns[i];
        }
    }
    void map(int n, char op)
    {
        int now = 0;

        try
        {
            if (op == '/' || op == '%')
                for (int i = 0; i < this->size; i++)
                    if (this->ns[i] == 0)
                        throw op;

            for (int i = 0; i < this->size; i++)
            {
                if (op == '+')
                    *(this->ns + now) += n;
                if (op == '-')
                    this->ns[now] = n - this->ns[now];
                if (op == '*')
                    *(this->ns + now) *= n;
                if (op == '/')
                    this->ns[now] = n / this->ns[now];
                if (op == '%')
                    this->ns[now] = n % this->ns[now];
                now++;
            }
            print(cout);
        }
        catch (char n)
        {
            cout << "error in " << n << endl;
        }
    }
    void print(ostream &out)
    {
        for (int i = 0; i < this->size; i++)
        {
            out << this->ns[i] << " ";
        }
        out << endl;
    }
};

int main()
{
    int num;
    char op;
    int num_list[100], size = 0;

    cin >> num >> op;

    do
    {
        cin >> *(num_list + size++);
    } while (getc(stdin) == ' ');

    IntSet myset = IntSet(num_list, size);
    myset.map(num, op);
}