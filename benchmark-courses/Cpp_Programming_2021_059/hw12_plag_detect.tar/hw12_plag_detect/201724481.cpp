#include <iostream>
#include <cstring>
using namespace std;

class IntSet{
private:
	int array[100],sz;
public:
	IntSet(int ns[], int size){
		sz = size;
		for(int i=0; i<size; i++)
			array[i] = ns[i];
	}
	void map(int n, char op){
		switch(op){
			case '+':
				for(int i=0; i<sz; i++)
					array[i] += n;
				break;
			case '-':
				for(int i=0; i<sz; i++)
					array[i] -= n;
				break;
			case '/':
				for(int i=0; i<sz; i++)
					array[i] /= n;
				break;
			case '*':
				for(int i=0; i<sz; i++)
					array[i] *= n;
				break;
			case '%':
				for(int i=0; i<sz; i++)
					array[i] %= n;
				break;
		}
	}
	void print(ostream &out){
		for(int i=0; i<sz; i++)
			out << array[i] << " ";
	}
};

int main()
try{
	int a, arr[100], i=0, size=0, cnt=0;
	char b;
	cin >> a >> b;	
	
	while(cin >> arr[i]){
		i++;
		size++;
		if(arr[i]==0)
			cnt++;
	}
	if(cnt!=0 && (b=='/' || b=='%')) throw b;
	IntSet first(arr,size);
	first.map(a,b);
	first.print(cout);
}
catch (char n){
	cout << "error in " << n << endl;
}



