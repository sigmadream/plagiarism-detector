#include <cstdio>
#include <iostream>
#include <vector>
#include <string>

using namespace std;

class IntSet{
	int *numset, _size;
	public:
		IntSet(int ns[], int size){
			numset = new int[size];
			_size = size;
			for(int i = 0; i <_size; i++) {
				numset[i] = ns[i];
			}
		}
		void map(int n, char op){
			for(int i = 0; i<_size; i++){
				if (op == '+') numset[i] += n;
				else if(op == '-') numset[i] -= n;
				else if(op == '/') {
					if (numset[i] == 0) throw op;
					else numset[i] /= n;
				}
				else if(op == '%') {
					if (numset[i] == 0) throw op;
					else numset[i] %= n;
				}
			}
		}
		void print(){
			for(int i=0; i<_size; i++) cout << numset[i];
		}
};

int main(){
	int k, op_num;
	int size=0, i=0;
	char cal;
	int num_set[100];
	cin >> op_num >> cal;
	while(cin >> k){
		num_set[i] = k;
		i++;
		size++;
	}
	IntSet set(num_set, size);
	try{
		set.map(op_num, cal);
		set.print();
	}
	catch(char c){
		cout << "error in" << c;
	}
	
}

