#include<iostream>
#include<string>
#include<exception>
#include<vector>
#include<cstdlib>

using namespace std;

class IntSet{
    int _ns[100];
    int _size;
public:
    IntSet(int ns[], int s){
        for(int i = 0; i < s; i++){
            _ns[i] = ns[i];
        }
        _size = s;
    }
    void map(int n, char op){
        switch (op)
        {
            case '+':
                for(int i = 0; i < _size; i++){
                    _ns[i] += n;
                }
                break;
            case '-':
                for(int i = 0; i < _size; i++){
                    _ns[i] = n - _ns[i];
                }
                break;
            case '*':
                for(int i = 0; i < _size; i++){
                    _ns[i] *= n;
                }
                break;
            case '/':
                try{
                    for(int i = 0; i < _size; i++){
                        if(_ns[i] == 0)
                            throw op;
                        else 
                            _ns[i] = n / _ns[i];
                    }
                }
                catch(char c){
                    cout << "error in " << c;
                    exit(1);
                }
                break;
            case '%':
                try{
                for(int i = 0; i < _size; i++){
                    if(_ns[i] == 0) 
                        throw op;
                    else 
                        _ns[i] = n % _ns[i];
                }
            }
                catch(char c){
                    cout << "error in " << c;
                    exit(1);
                }
                break;
            default:
                break;
        }
    }
    void Print(ostream& out){
        for(int i = 0; i < _size; i++){
            out << _ns[i] << ' ';
        }
    }
};

int main(){
    int nums[100];
    int n, input_n, idx = 0;
    char o;
    cin >> n >> o;
    while(cin >> input_n){
        nums[idx] = input_n;
        idx++;
    }
    IntSet a(nums, idx);
    a.map(n, o);
    a.Print(cout);
}
