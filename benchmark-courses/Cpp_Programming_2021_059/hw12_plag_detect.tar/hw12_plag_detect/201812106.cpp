#include <bits/stdc++.h>
using namespace std;
class IntSet {
private:
	int* s;
	int sz;
	int err;
public:
	IntSet(int ns[], int size) {
		s = new int[size];
		sz = size;
		err = 0;
		for (int i = 0; i < size; i++) {
			s[i] = ns[i];
		}
	}
	void map(int n, char op) {
		try {
			for (int i = 0; i < sz; i++) {
				if (op == '+') {
					s[i] += n;
				}
				else if (op == '-') {
					s[i] = n - s[i];
				}
				else if (op == '*') {
					s[i] *= n;
				}
				else if (op == '/') {
					if (s[i] == 0) {
						throw op;
					}
					s[i] = n / s[i];
				}
				else if (op == '%') {
					if (s[i] == 0) {
						throw op;
					}
					s[i] = n % s[i];
				}
			}
		}
		catch (char x) {
			cout << "error in " << op << "\n";
			err = 1;
		}
	}
	void print(ostream &out) {
		if (!err) {
			for (int i = 0; i < sz; i++) {
				out << s[i] << " ";
			}
		}
	}
};
int main() {
	int n;
	char op;
	cin >> n >> op;
	int cnt = 0, a[111] = { 0 }, x;
	while (cin >> x) {
		a[cnt++] = x;
	}
	IntSet S(a, cnt);

	S.map(n, op);
	S.print(cout);
}