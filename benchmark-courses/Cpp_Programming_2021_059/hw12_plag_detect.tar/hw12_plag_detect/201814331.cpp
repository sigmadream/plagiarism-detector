#include <cstdio>
#include <iostream>
using namespace std;

int nn[100];

class IntSet {
	public :	
		IntSet(int nn[], int size) {
			MaxSize = size;
		}
		void map(int n, char op) {
			for ( i = 0; i < MaxSize; i++ ) {
				switch (op)
				{
					case '+' : {
						nn[i] = n + nn[i];
						break;
					}
					case '-' : {
						nn[i] = n - nn[i];
						break;
					}
					case '*' : {
						nn[i] = n * nn[i];
						break;
					}
					case '/' : {
						if (nn[i] == 0) {
							cout << "error in " << op;
							error++;
							break;
						}
						else {
							nn[i] = n / nn[i];
							break;							
						}
					}
					case '%' : {
						if (nn[i] == 0) {
							cout << "error in " << op;
							error++;
							break;
						}
						else {
							nn[i] = n % nn[i];
							break;							
						}
					}
					default:
						break;								
				}
				
				if ( error != 0 )
					break;
			}
		}
		void print() {
			if ( error == 0 ) {
				for ( i = 0; i < MaxSize; i++ ) {
					cout << nn[i] << " ";
				}
			}

		}
		
	private:
		int i, MaxSize, step = 0, error = 0;
};


int main() {
	int i = 0, f_n;
	char op;

	cin >> f_n;
	cin >> op;

	while (cin >> nn[i]) {
		i++;

		if ( i >= 100 ) 
			break;	
	}

	IntSet std(nn, i);
	std.map(f_n, op);
	std.print();	
}
