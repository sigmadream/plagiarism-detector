#include<iostream>

using namespace std;

class IntSet
{
private:
    int *_data;
    int size;

public:
    IntSet(int ns[], int size) : size(size)
    {
        _data=new int[size];
        for(int i=0;i<size;i++)
        {
            _data[i]=ns[i];
        }
    }
    void map(int n,char op)
    {
        try
        { 
            for(int i=0;i<size;i++)
            {
                switch(op){
                    case '+':
                            _data[i]+=n;
                            break;
                    case '-':
                            _data[i]=n-_data[i];
                            break;
                    case '*':
                            _data[i]=n*_data[i];
                            break;
                    case '/':
                            if(_data[i]==0) throw op;
                            _data[i]=n/_data[i];
                            break;
                    case '%':
                            if(_data[i]==0) throw op;
                            _data[i]=n%_data[i];
                            break;                                
                }
            }   
        }
        catch(char op){
            cout<<"error in "<<op<<endl;
            throw -1;
        }
    }
    void print()
    {
        for(int i=0;i<size;i++)
        {
            cout<<_data[i]<<' ';
        }
    }
    ~IntSet()
    {
        delete []_data;
    }

};

int main(void)
{   
    int n;
    char op[2]; 
    int num[100];
    int i=0;

    cin>>n>>op;
 
    while(cin>>num[i])
    {
        i=i+1;
    }

    IntSet a(num,i);
    try{
        a.map(n,op[0]);
        a.print();
    }
    catch(int ans)
    {
        return 0;
    }
    
}