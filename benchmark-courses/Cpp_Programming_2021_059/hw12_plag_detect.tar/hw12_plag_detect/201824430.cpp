#include <iostream>
#include <vector>
using namespace std;

int n[100000];

class IntSet {
	int _size;
	int _ns[100000];
	char _error_in;
	bool _flag;
	public:
		IntSet(int ns[], int size){
			_size = size;
			for (int i=0; i<_size; i++){
				_ns[i] = ns[i];
			}
		}
		
		void map(int n, char op){
			_flag = 0;
			
			if (op == '+'){
				for (int i=0; i<_size; i++){
					_ns[i] = n + _ns[i];
				}
			}
			
			else if (op == '-'){
				for (int i=0; i<_size; i++){
					_ns[i] = n - _ns[i];
				}
			}
			
			else if (op == '/') {
				for (int i=0; i<_size; i++){
					try {
						if (_ns[i] == 0) throw op;
						_ns[i] = n / _ns[i];
					}
					catch (char n){
						_error_in = n;
						_flag = 1;
					}
				}
			}
			
			else if (op == '*') {
				for (int i=0; i<_size; i++){
					_ns[i] = n * _ns[i];
				}
			}
			
			else if (op == '%') {
				for (int i=0; i<_size; i++){
					try {
						if (_ns[i] == 0) throw op;
						_ns[i] = n % _ns[i];
					}
					catch (char n){
						_error_in = n;
						_flag = 1;
					}
				}
			}
		}
		
		void print(){
			if (!_flag) {
				for (int i=0; i<_size; i++){
					cout << _ns[i] << " ";
				}
			}
			else {
				cout << "error in " << _error_in; 
			}
		}
};

int main() {
	int N;
	char op;
	int i=0;
	int k;
	
	cin >> N >> op;
	
	while (cin >> k){
		n[i] = k;
		i++;
	}
	
	
	
	IntSet c(n, i);
	
	c.map(N , op);
	
	c.print();
	
	
}
