#include <iostream>
#include <cstdlib>
using namespace std;

class IntSet {
private:
	int *_ns;
	int _size;
public:
	IntSet (int ns[], int size) {
		_ns = (int*) malloc(sizeof(int) * size);
		_size = size;
		for(int i=0; i<_size; i++)
			_ns[i] = ns[i];
	}
	void plus (int n) {
		for(int i=0; i<_size; i++)
			_ns[i] = n + _ns[i];
	}
	void minus (int n) {
		for(int i=0; i<_size; i++)
			_ns[i] = n - _ns[i];
	}
	void multi (int n) {
		for(int i=0; i<_size; i++)
			_ns[i] = n * _ns[i];
	}
	void divide (int n) {
		for(int i=0; i<_size; i++){
			if(_ns[i] == 0)
				throw '/';
			_ns[i] = n / _ns[i];
		}
	}
	void mod (int n) {
		for(int i=0; i<_size; i++){
			if(_ns[i] == 0)
				throw '%';
			_ns[i] = n % _ns[i];
		}
	}
	void map (int n, char op) {
		switch(op) {
		case '+':
			plus(n);
			break;
		case '-':
			minus(n);
			break;
		case '*':
			multi(n);
			break;
		case '/':
			divide(n);
			break;
		case '%':
			mod(n);
			break;
		default:
			_size = 0;
			cout << "Wrong operator" << endl;
		}
	}
	void print (ostream &out) {
		for (int i=0; i<_size; i++)
			out << _ns[i] << " ";
		out << endl;
		free(_ns);
	}
};

int main()
try {
	int i=0, n, a[100];
	char op;
	
	cin >> n >> op;
	
	while(i<100 && cin >> a[i])
		i++;
	
	IntSet num(a, i);
	
	num.map(n, op);
	num.print(cout);
}
catch(char a) {
	cout << "error in " << a << endl;
}
