#include <cstdio>

int main(){
	
	int cal;
	int pri=0;
	int num[100];
	char x[10];
	scanf("%d",&cal);
	scanf("%s", &x);
	int i=0;
	while(scanf("%d",&num[i])==1){
		i=i+1;
	} //�ؿ� ���� �Է¹� 
	//i�� �Է¹޴°� ����.
	int after[100];
	int error=0;
	if(x[0]=='+'){
		for(int q=0; q<i; q++){
			after[q]=(cal+num[q]);
		}
	} 
	else if(x[0]=='-'){
		for(int q=0; q<i; q++){
			after[q]=(cal-num[q]);
		}
	} 
	
	else if(x[0]=='*'){
		for(int q=0; q<i; q++){
			after[q]=(cal*num[q]);
		}
	} 
	
	else if(x[0]=='/'){
		for(int q=0; q<i; q++){
			if(num[q]==0){
				error=1;
				break;
			}
			after[q]=(cal/num[q]);
		}
	} 
	
	else if(x[0]=='%'){
		for(int q=0; q<i; q++){
			if(num[q]==0){
				error=2;
				break;
			}
			after[q]=(cal%num[q]);
		}
		
	} 

	
	if (error==0){
		for(pri=0; pri<i; pri++){
			printf("%d ",after[pri]);
	}
	}
	else if(error==1) printf("error in /");
	
	else if(error==2) printf("error in %%");
	

	return 0;
	
}
