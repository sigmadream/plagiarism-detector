#include <iostream>

class IntSet {
    int nums[100];
    int idx,flag,check;
public:
    IntSet(int ns[], int size) {
        flag =0;
        check = 0;
        idx = size;
        for (int i=0; i<idx;i++) {
            nums[i] = ns[i];
            if (ns[i] == 0) {
                flag =1;
            }
        }
    }
    void map(int n, char op) 
    try {
        if (op == 43) {  // +
            for (int i=0; i<idx;i++) {
                nums[i] = nums[i] + n;
            }
        }
        else if (op == 42) {   // *
            for (int i=0; i<idx;i++) {
                nums[i] = nums[i] * n;
            }
        }
        else if (op == 45) {  // -
            for (int i=0; i<idx;i++) {
                nums[i] = n - nums[i];
            }
        }
        else if (op == 47) {  // /
            if (flag == 1) {
                throw op;
            }
            else {
                for (int i=0; i<idx;i++) {
                    nums[i] = n / nums[i];
                }
            }
        }
        else if (op == 37) { // %
            if (flag == 1) {
                throw op;
            }
            else {
                for (int i=0; i<idx;i++) {
                    nums[i] = n % nums[i];
                }
            }
        }
    }
    catch (char ope) {
        std::cout << "error in " << ope << std::endl;
        check =1;
    }
    void print(std::ostream &out) {
        if (check == 0) {
            for (int i=0; i<idx -1;i++) {
                std::cout << nums[i] << " ";
            }
            std::cout << nums[idx-1];
        }
    }
};

int main() {
    int val,x,sz=0;
    int num[100];
    char opera;
    std::cin >> val >> opera;
    while (std::cin >> x) {
        num[sz++] = x;
    }
    
    IntSet i(num, sz);
    i.map(val, opera);
    i.print(std::cout);
}


