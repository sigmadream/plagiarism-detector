#include <iostream>
#include <exception>
using namespace std;

class IntSet{
public:
    IntSet(int ns[], int size):nso(ns), sz(size){}
    void map(int n, char op){
        for(int i = 0; i < sz; i++){
            switch(op){
                case('+'):
                    nso[i] = n + nso[i];
                    break;
                case('-'):
                    nso[i] = n - nso[i];
                    break;
                case('*'):
                    nso[i] = n * nso[i];
                    break;
                case('/'):
                    if(nso[i] == 0) throw op;
                    nso[i] = n / nso[i];
                    break;
                case('%'):
                    if(nso[i] == 0) throw op;
                    nso[i] = n % nso[i];
                    break;
            }
        }
    }
    void print(ostream& out){
        for(int i = 0; i < sz; i++){
            out << nso[i] << " ";
        }
    }
private:
    int * nso;
    int sz;
};

int main()try{
    int n, x, sam[100], i = 0;
    char op;
    cin >> n >> op;
    while(cin >> x){
        sam[i] = x;
        i++;
    }
    IntSet s(sam, i);
    s.map(n, op);
    s.print(cout);
}
catch(char op){
    cerr << "error in " << op << endl;
    exit(1);
}

