#include<iostream>
using namespace std;

class IntSet{
    int stand; // 기준 값
    int *ns; //S
    int size; // 배열 크기
public:
    IntSet(int _stand = 0, int _size=0):stand(_stand), size(_size){
        ns = new int[size];
        for(int i=0; i<size; i++){
            ns[i] = stand;
        }
    }

    void map(int *n, char op){
        for(int i=0;i<size;i++){
            switch(op){
                case '+': ns[i]=ns[i]+n[i]; break;
                case '-': ns[i]=ns[i]-n[i]; break;
                case '*': ns[i]=ns[i]*n[i]; break;
                case '/':
                    if(n[i]==0) throw op;
                    ns[i]=ns[i]/n[i]; break;
                case '%':
                    if(n[i]==0) throw op;
                    ns[i]=ns[i]%n[i]; break;
            }
        }
    }

    void print(ostream &out){
        for(int i =0; i<size; i++){
            out << ns[i] << ' ';
        }
    }
};



int main()
try{
    int stand;
    char type;
    int input;
    int x[100];
    int i = 0;
    int size =0;
    cin >> stand >> type;

    while(cin >> input){
        x[i++] = input;
        size++;
    }
    IntSet a(stand, size);
    a.map(x, type);
    a.print(cout);
}

catch (char op){
    cout << "error in " << op << endl;
}