#include <iostream>
#include <exception>
#include <cstdlib>

using namespace std;

class IntSet{
public:
    IntSet(int ns[], int size){
        sz = size;
        for(int i=0;i<sz;i++)
            s[i] = ns[i];
    }
    void map(int n, char op){
        switch(op) {
            case '+':
                for(int i=0;i<sz;i++)
                    s[i] = n + s[i];
                break;
            case '-':
                for(int i=0;i<sz;i++)
                    s[i] = n - s[i];
                break;
            case '*':
                for(int i=0;i<sz;i++)
                    s[i] = n * s[i];
                break;
            case '/':
                for(int i=0;i<sz;i++){
                    if(s[i]==0) throw op;
                    s[i] = n / s[i];
                }
                break;
            case '%':
                for(int i=0;i<sz;i++){
                    if(s[i]==0) throw op;
                    s[i] = n % s[i];
                }
                break;
        }
    }
    void print(ostream &out){
        for(int i=0;i<sz;i++)
            out << s[i] << " "; 
    }
private:
    int s[100];
    int sz;
};

int main() try{
    int ss[100];
    int v1,v2,j=0;
    char o = '.';
    cin >> v1;
    cin >> o;
    while(cin >> v2){
        ss[j++] = v2;
    }
    IntSet a(ss,j);
    a.map(v1,o);
    a.print(cout);
}
catch(char o){
    cerr << "error in " << o << endl;
    exit(1);
}