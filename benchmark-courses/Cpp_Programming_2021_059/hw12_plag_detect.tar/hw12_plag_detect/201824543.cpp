#include <iostream>

class IntSet
{
private:
	int* _set;
	int _size;

public:
	IntSet(int ns[], int size);
	IntSet(const IntSet& copy);
	IntSet& operator=(const IntSet& copy);
	~IntSet();
	void map(int n, char op);
	void print(std::ostream& out);

};

//////////// main ////////////
//////////////////////////////

int main()
{
	try {
		int operandNum;
		char operatorSymbol;

		std::cin >> operandNum >> operatorSymbol;

		int numSet[100] = { 0, };

		int setSize = 0;
		int inputNum;
		while (std::cin >> inputNum)
		{
			numSet[setSize] = inputNum;
			setSize++;
		}

		IntSet mySet(numSet, setSize);
		mySet.map(operandNum, operatorSymbol);
		mySet.print(std::cout);
	}
	catch (char op)
	{
		std::cout << "error in " << op << std::endl;
	}

	return 0;
}

//////////////////////////////
//////////////////////////////

IntSet::IntSet(int ns[], int size) : _size(size)
{
	_set = new int[size];
	for (int i = 0; i < size; i++)
	{
		_set[i] = ns[i];
	}
}

IntSet::IntSet(const IntSet& copy) : _size(copy._size)
{
	_set = new int[copy._size];
	for (int i = 0; i < _size; i++)
	{
		_set[i] = copy._set[i];
	}
}

IntSet& IntSet::operator=(const IntSet& copy)
{
	if (this != &copy)
	{
		delete[] _set;

        _size = copy._size;
        _set = new int[_size];
        for (int i = 0; i < _size; i++)
        {
            _set[i] = copy._set[i];
        }
    }

	return *this;
}

IntSet::~IntSet()
{
	delete[] _set;
}

void IntSet::map(int n, char op)
{
	switch (op)
	{
		case '+':
			for (int i = 0; i < _size; i++)
			{
				_set[i] = n + _set[i];
			}
			break;

		case '-':
			for (int i = 0; i < _size; i++)
			{
				_set[i] = n - _set[i];
			}
			break;

		case '*':
			for (int i = 0; i < _size; i++)
			{
				_set[i] = n * _set[i];
			}
			break;

		case '/':
			for (int i = 0; i < _size; i++)
			{
				if (_set[i] == 0)
				{
					throw op;
				}
				else
				{
					_set[i] = n / _set[i];
				}
			}
			break;

		case '%':
			for (int i = 0; i < _size; i++)
			{
				if (_set[i] == 0)
				{
					throw op;
				}
				else
				{
					_set[i] = n % _set[i];
				}
			}
			break;

		default:
			break;
	}
}

void IntSet::print(std::ostream& out)
{
	for (int i = 0; i < _size; i++)
	{
		out << _set[i] << " ";
	}
	out << std::endl;
}
