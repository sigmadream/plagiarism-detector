#include <iostream>
#define MAX 100
using namespace std;

class IntSet{
public:
    IntSet(int ns[], int size);
    void Map(int n, char op);
    void Print(ostream &out);
private:
    int _ns[MAX];
    int _size;
};

IntSet::IntSet(int ns[], int size) {
    _size = size;

    for(int i = 0; i < size; i++) {
        _ns[i] = ns[i];
    }
}

void IntSet::Map(int n, char op) {
    for (int i = 0; i < _size; i++){
        switch(op) {
            case '+': _ns[i] += n; 
                break;
            case '-': _ns[i] = n - _ns[i]; 
                break;
            case '*': _ns[i] *= n; 
                break;
            case '/': 
                if (_ns[i] == 0) 
                    throw op; 
                _ns[i] = n / _ns[i]; 
                break;
            case '%': 
                if (_ns[i] == 0) 
                    throw op; 
                _ns[i] = n % _ns[i]; 
                break;
        }
    }
}

void IntSet::Print(ostream &out) {
    for (int i = 0; i < _size; i++) {
        out << _ns[i] << " ";
    }
}

int main()
try {
    int n;
    char c;
    cin >> n >> c;
    int i = 0, t;
    int a[MAX];
    while (cin >> t) {
        a[i] = t;
        i++; 
    }
    IntSet nums(a, i);
    nums.Map(n,c);
    nums.Print(cout);
} catch (char c) {
    cout << "error in " << c << endl;
}
