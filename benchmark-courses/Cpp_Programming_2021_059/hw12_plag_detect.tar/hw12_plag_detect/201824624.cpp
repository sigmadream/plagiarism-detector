#include <iostream>
#include <exception>
using namespace std;

class IntSet {
    int *ns, size;

    public:
        IntSet(int *arr, int sz);
        ~IntSet();
        void Map(int n, char op);
        void Print(ostream &out);
};

IntSet::IntSet(int *arr, int sz): size(sz) {
    ns = new int[size];
    for(int i = 0; i < size; i++) {
        ns[i] = arr[i];
    }
}

IntSet::~IntSet() { delete[] ns; }

void IntSet::Map(int n, char op) {
    for(int i = 0; i < size; i++) {
        int cur = ns[i];
        int cn = n;

        switch(op) {
            case '+': cn += cur; break;
            case '-': cn -= cur; break;
            case '*': cn *= cur; break;
            case '/': {
                if(cur == 0) throw op;
                cn /= cur;
            }; break;
            case '%': {
                if(cur == 0) throw op;
                cn %= cur;
            }; break;
        }

        ns[i] = cn;
    }
}

void IntSet::Print(ostream &out) {
    for(int i = 0; i < size; i++)
        cout << ns[i] << " ";
}


int main() try {
    int num;
    char op;
    cin >> num >> op;

    int arr[100], arrNum, i = 0;
    while(cin >> arrNum)
        arr[i++] = arrNum;

    IntSet init(arr, i);
    init.Map(num, op);
    init.Print(cout);
}
catch (char c) {
    cout << "error in " << c << endl;
    exit(1);
}
catch (exception &e) {
    cerr << "Error: " << e.what() << endl;
    exit(2);
}