#include <iostream>
#include <cstdlib>
#include <exception>

using namespace std;

class IntSet {
    int *_ns;
    int _size;
public:
    IntSet(int ns[], int size); // make an integer set containing ns of size
    void map(int n, char op); // map (n op) onto every integer
    void print(ostream &out); // prints the elements in sequence
};

IntSet::IntSet(int ns[], int size): _ns(ns), _size(size) {}

void IntSet::map(int n, char op) {
    
    if (op == '+') {
        for(int i=0;i<_size;i++) _ns[i] += n;
    }
    
    else if (op == '-') {
        for(int i=0;i<_size;i++) _ns[i] =  n - _ns[i];
    }

    else if (op == '*') {
        for(int i=0;i<_size;i++) _ns[i] *= n;
    }
    
    else if (op == '/') {
        for(int i=0;i<_size;i++) {
            if (_ns[i] == 0) throw 1;
            else _ns[i] = n / _ns[i];
        }
    }
    
    else if (op == '%') {
        for(int i=0;i<_size;i++) {
            if (_ns[i] == 0) throw 2;
            else _ns[i] = n % _ns[i];
        }
    }
}

void IntSet::print(ostream &out) {
    for(int i=0;i<_size;i++) {
        out << _ns[i] << (i == _size-1? "" :" ");
    }
}

int main()
try {
    int n1;
    char op;
    cin >> n1 >> op;

    int ns[100];
    int n2;

    int i = 0;
    while(cin >> n2) {
        ns[i] = n2;
        i+=1;
    }

    IntSet IS(ns,i);
    IS.map(n1, op);
    IS.print(cout);
}

catch(int n) {
    cout << "error in " << (n == 1? '/': '%');
    exit(1);
}