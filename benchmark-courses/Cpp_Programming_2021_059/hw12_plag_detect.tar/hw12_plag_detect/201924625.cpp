#include <iostream>
#include <string>
using namespace std;

int arr[100000];
int sz = 0;
class IntSet
{
    int *a;
    int size;

public:
    IntSet(int ns[], int _size) : a(ns), size(_size) {}

    void map(int n, char op)
    {
        int b;
        while (cin >> b)
        {
            if (op == '/')
            {
                if (b == 0)
                    throw op;
            }

            if (op == '%')
            {
                if (b == 0)
                    throw op;
            }
            if (op == '/')
                *(a + sz) = n / b;
            if (op == '+')
                *(a + sz) = n + b;
            if (op == '-')
                *(a + sz) = n - b;
            if (op == '*')
                *(a + sz) = n * b;
            if (op == '%')
                *(a + sz) = n % b;
            size++;
            sz++;
        }
    }

    void print(ostream &out)
    {
        for (int i = 0; i < size; i++)
        {
            out << *(a + i) << ' ';
        }
    }
};

int main()
try
{
    //IntSet(int ns[], int size);
    int _size;
    int ns[100000];
    int x;
    string s;
    cin >> x >> s;
    char c = s[0];
    IntSet setA(arr, sz);
    setA.map(x, c);
    setA.print(cout);
}
catch (char n)
{
    cout << "error in "<< n << endl;
}