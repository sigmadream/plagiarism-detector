#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class IntSet{
    public:
        IntSet(int na[], int size){ 
            for(int i=0;i<size;i++){
                vec.push_back(na[i]);
            }
        }
        void map(int n, char op){
            if(op == '+'){
                for(int &i:vec){
                    i=n+i;
                }
            }
            else if(op == '-'){
                for(int &i:vec){
                    i=n-i;
                }
            }
            else if(op == '*'){
                for(int &i:vec){
                    i=n*i;
                }
            }
            else if(op == '/'){
                for(int &i:vec){
                    if(i==0) throw '/';
                    i = n/i;
                }
            }
            else if(op =='%'){
                for(int &i:vec){
                    if(i==0) throw '%';
                    i = n%i;
                }
            }
        }

        void print(ostream &out){
            for(const int i:vec){
                out<<i<<" ";
            }
            out<<endl;
        }
    private:
        vector<int> vec;
};
int main(){
    int n;
    char o;

    cin>>n>>o;

    int size =0;
    int arr[101];

    while(cin>>arr[size]){size++;}
    
    IntSet intset(arr,size);

    try{ 
        intset.map(n,o);
    }
    catch(char ch){
        cout<<"error in "<<ch<<endl;
        return 0;
    }

    intset.print(cout);
}