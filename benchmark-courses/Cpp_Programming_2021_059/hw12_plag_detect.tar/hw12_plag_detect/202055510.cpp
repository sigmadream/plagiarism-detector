#include <iostream>
using namespace std;

class Intset{
	private:
		int _set[100];
		int _sz;
	
	public:
		Intset(int ns[], int size){
			_sz = size;
			for(int i = 0; i < _sz; i++){
				_set[i] = ns[i];
			}
		}
		
		void map(int n, char op){
			for(int i = 0; i < _sz; i++){
				switch(op){
					case '+':
						_set[i] = n + _set[i];
						break;
					case '-':
						_set[i] = n - _set[i];
						break;
					case '*':
						_set[i] = n * _set[i];
						break;
					case '/':
						if(_set[i] == 0){
							throw op;	
						}
						_set[i] = n / _set[i];
						break;
					case '%':
						if(_set[i] == 0){
							throw op;
						}	
						_set[i] = n % _set[i];
						break;
				}
			}
		}
		
		void print(ostream &out){
			for(int i = 0; i < _sz; i++){
				out << _set[i] << " ";
			}
		}
};

int main(){
	int n;
	char op;
	
	cin >> n >> op;
	
	int list[100];
	int sz = 0;
	
	while(cin >> list[sz++]);
	
	Intset s1(list, sz-1);
	try{
		s1.map(n, op);
		s1.print(cout);
	}
	catch (char oper){
		cout << "error in " << oper;
	}
}
