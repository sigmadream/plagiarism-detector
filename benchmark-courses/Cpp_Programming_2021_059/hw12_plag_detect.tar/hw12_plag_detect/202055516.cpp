#include <iostream>
#include <cstdlib>
#include <exception>
using namespace std;

class IntSet
{
public :
    IntSet(int ns[], int size) { ints = ns; setSize = size;}

    void map(int n, char op)
    {

        for(int i=0; i<setSize; i++)
        {
            switch (op)
            {
            case '+': ints[i] += n; break;
            case '-': ints[i] -= n; break;
            case '*': ints[i] *= n; break;
            case '/': if (ints[i]==0) throw op; ints[i] = n/ints[i]; break;
            case '%': if (ints[i]==0) throw op; ints[i] =n%ints[i]; break;
            }
        }
    }

    void print(ostream &out)
    {
        for(int i=0; i<setSize; i++)
        {
            out << ints[i] <<" ";
        }
    }
private :
    int *ints;
    int setSize;
};

int main()
{
    int operand;
    char op;
    cin >> operand >>op;
    int nums[100];
    int x, i=0;
    while (cin >> x) {
        nums[i++] = x;
    }
    int sz = i;

    int newSet[sz];

    for(int i=0; i<sz; i++)
    {
        newSet[i] = nums[i];
    }

    IntSet intset(newSet, sz);
     try {
        intset.map(operand, op);
     }
    catch (char op)
    {
        cerr << "error in " << op << endl;
        exit(1);
    }
    catch (exception e)
    {
        cerr << "error in " << e.what() << endl;
        exit(2);
    }
    intset.print(cout);
     return 0;

}
