#include<iostream>	
#include<map>
#include<vector>
using namespace std;

map<  int , char > m;

vector<int> before(100);
vector<int> after(100);

class IntSet {
public:
	

	int map(int n, int m, char op) {
		for (int i = 0; i < n; i++) {
			if (before[i] <= 0) {
				printf("error in %c", op);
				break;
			}
		}

		if (op == '*') {
			for (int i = 0; i < n; i++) {
				after[i] = m * before[i];			
			}
		}
		else if (op == '/') {
			for (int i = 0; i < n; i++) {
				after[i] = m / before[i];
			}
		}
		else if (op == '-') {
			for (int i = 0; i < n; i++) {
				after[i] = m - before[i];
			}
		}
		else if (op == '+') {
			for (int i = 0; i < n; i++) {
				after[i] = m + before[i];
			}
		}
		else if (op == '%') {
			for (int i = 0; i < n; i++) {
				after[i] = m % before[i];

			}
		}
		return 0; 
	}

	

	void print(int n , char op) {	
		for (int i = 0;  i < n;  i++) {
			printf("%d ", after[i] );
		}
	}


};





int main(void) {

	int num;
	char b;

	scanf("%d  ", &num );
	scanf("%c  ", &b);

	m.insert(pair<int , char>(num , b));


	int a;
	int i = 0;
	int size = 0;
	while (scanf("%d ", &a) != EOF) {
		before[i] = a;
		i += 1;
		size += 1;
	}
	
	
	
	IntSet s;
	s.map(size, num , m[num] );
	s.print(size , b);



	return 0;
}