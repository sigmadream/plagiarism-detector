#include <iostream>

class calcul
{
	private:
	int y[100] = {-1,};
	int y_size = 0;
	int print_stat = 0;
	
	
	public:	
	void IntSet(int ns[], int size) // make an integer set containing ns of size
	{
		int i = 0;
		while(i<size)
		{
			y[i] = ns[i];
			i = i + 1;
		}
		y_size =size;
	} 
	
	void map(int n, char op) // map (n op) onto every integer
	{
		try
		{
			int i = 0;
			if(op == '+')
			{
				while(i<y_size)
				{
					y[i] = n + y[i];
					i = i + 1;
				}
			}
			else if(op == '-')
			{
				while(i<y_size)
				{
					y[i] = n - y[i];
					i = i + 1;
				}		
			}
			else if(op == '*')
			{
				while(i<y_size)
				{
					y[i] = n * y[i];
					i = i + 1;
				}		
			}
			else if(op == '/')
			{
				while(i<y_size)
				{
					if (y[i] == 0) throw op;
					y[i] = n / y[i];
					i = i + 1;
				}		
			}
			else if(op == '%')
			{
				while(i<y_size)
				{
					if (y[i] == 0) throw op;
					y[i] = n % y[i];
					i = i + 1;
				}		
			}
		}
		catch (char op) 
		{
			printf("error in %c", op);
			print_stat = -1;
		}
	}
	
	void print(void) // prints the elements in sequence
	{
		if(print_stat == 0)
		{
		
		int i = 0;
		while(i<y_size-1)
		{
			printf("%d ", y[i]);
			i= i + 1;
		}
		printf("%d", y[i]);
	}
	}
};





int main()
{
	int x = 0, y[100] = {-1,};
	char oper;
	
	std::cin >> x >> oper;
	std::cin >> y[0];
	int i = 1;
	while(getc(stdin) == ' ')
	{
		std::cin >> y[i];
		i = i + 1;
	}
	int y_size = i;
	i = 0;
	
	calcul set1;
	set1.IntSet(y, y_size);
	set1.map(x, oper);
	set1.print();
	
}

