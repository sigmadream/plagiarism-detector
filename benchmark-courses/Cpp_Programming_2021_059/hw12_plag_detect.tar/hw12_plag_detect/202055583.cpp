
#include <iostream>
#include <cstdlib>
#include <cassert>

using namespace std;

int main(){
    int a;
    char b;
    int x, y, z;

    cin >> a >> b;
    cin >> x >> y >> z;
    
    if (b=='+')
        cout << a+x << " " << a+y << " " << a+z <<endl;
    if (b=='-')
        cout << a-x << a-y << a-z <<endl;
    if (b=='*')
        cout << a*x << a*y << a*z <<endl;
    if (b=='%')
        try{
            if (x==0 || y==0 || z==0) throw b;
        }catch(char b){
            cout << "error in" << b << endl;
        }
    if (b=='/')
        try{
            if (x==0 || y==0 || z==0) throw b;
        }catch(char b){
            cout << "error in" << b << endl;
        }
    
}
