#include <iostream>
#include <cstdio>
#include<vector>
#include<cstdlib>
using namespace std;


class IntSet {
    int *_ns;
    int _size;
  public:
    IntSet(int ns[],int size): _ns(ns),_size(size){
        _ns[_size] = {0,};
    };

    void print() {
        for(int i = 0; i<_size; i++) {
            printf("%d ",_ns[i]);
        }
    }

};


void mapper(int a,int b,char c) {

    if(c == '+') {
        printf("%d ",a+b);
    }
    if(c == '-') {
        printf("%d ",a-b);
    }

    if(c == '/') {
        try{
            if(b == 0) throw b;
            if(b != 0){
                printf("%d ",a/b);
            }
        }
        catch(int exe){
            printf("error in /");
        }

    }

    if(c == '*') {
        printf("%d ",a*b);
    }

    if(c == '%') {
        try{
            if(b == 0) throw b;
            if(b != 0){
                printf("%d ",a%b);
            }
        }
        catch(int exe){
            printf("error in %");
        }

    }
}
int main() {



    int scale;
    char oper;
    scanf("%d %c",&scale,&oper);


    int nums;
    while(scanf("%d",&nums)!=EOF) {

        mapper(scale,nums,oper);
    }


}
