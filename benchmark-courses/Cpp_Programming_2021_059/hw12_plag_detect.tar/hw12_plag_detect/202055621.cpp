#include <iostream>
using namespace std;
class IntSet{
public:
    IntSet(int size = 0);
    IntSet(int ns[], int size){
        _size = size;
        for (int i = 0; i < size; i++)
            _data[i] = ns[i];
    };
    void Map(int n, char op){
        switch(op){
        case '+':
            Addmap(n);
            break;
        case '-':
            Submap(n);
            break;
        case '*':
            Mulmap(n);
            break;
        case '/':
            Divmap(n);
            break;
        case '%':
            Remmap(n);
            break;
        }
    };
    void Addmap(int n){
        for(int i =0; i<_size;i++)
            _data[i]=n+_data[i];
    }
    void Submap(int n){
        for(int i =0; i<_size;i++)
            _data[i]=n-_data[i];
    }
    void Mulmap(int n){
        for(int i =0; i<_size;i++)
            _data[i]=n*_data[i];
    }
    void Divmap(int n){
        for(int i =0; i<_size;i++){
            if(_data[i]==0)
                throw '/';
            _data[i]=n/_data[i];
        }
    }
    void Remmap(int n){
        for(int i =0; i<_size;i++){
            if(_data[i]==0)
                throw '%';
            _data[i]=n%_data[i];
        }
    }
    void Print(){
        for(int i =0; i<_size;i++)
            cout << _data[i] << ' ';
    };
private:
    int _data[100];
    int _size;
};


int main()
try{
    char op_find[10];
    int first_n;
    int n_list[100];
    cin >> first_n;
    cin.getline(op_find, 10);
    int sz=0;
    int num;
    while(cin >> num){
        n_list[sz]=num;
        sz++;
    }
    IntSet a(n_list,sz);
    a.Map(first_n,op_find[1]);
    a.Print();
}
catch (char op) {
    cout << "error in " << op << endl;
}
