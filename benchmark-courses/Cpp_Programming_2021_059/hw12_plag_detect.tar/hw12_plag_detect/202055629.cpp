#include <iostream>
#include <string>
#define MAX 100
using namespace std;

class IntSet{
    int *_ns;
    int _size;
public:
    IntSet();
    IntSet(int *ns, int size);
    void Map(int n, char op);
    void Print(ostream& out);
    void Add(int n);
    void Subtr(int n);
    void Mul(int n);
    void Div(int n);
    void Mod(int n);

};
IntSet::IntSet(): _size(0){}
IntSet::IntSet(int *ns, int size): _size(size){
    _ns = new int[_size];
    for(int i = 0; i < _size; i++)
        _ns[i] = ns[i];
}
void IntSet::Map(int n, char op){
    switch (op) {
        case '+':
            Add(n);
            break;
        case '-': 
            Subtr(n);
            break;
        case '*':
            Mul(n);
            break;
        case '/':
            Div (n);
            break;
        case '%': 
            Mod(n);    
            break;
    }
}
void IntSet::Print(ostream& out){
    for(int i = 0; i < _size; i++)
        out << _ns[i] << " ";   
}
void IntSet::Add(int n){
    for(int i = 0; i < _size; i++)
        _ns[i] = _ns[i] + n;
}
void IntSet::Subtr(int n){
    for(int i = 0; i < _size; i++)
        _ns[i] = n - _ns[i];
}
void IntSet::Mul(int n){
    for(int i = 0; i < _size; i++)
        _ns[i] = _ns[i] * n;
}
void IntSet::Div(int n){
    for(int i = 0; i < _size; i++){
        if(_ns[i] == 0) 
            throw '/';
        else
            _ns[i] = n / _ns[i];
    }
}

void IntSet::Mod(int n){
    for(int i = 0; i < _size; i++){
        if(_ns[i] == 0) 
            throw '%';
        else
            _ns[i] = n % _ns[i];
    }
}

int main()
try{
    int ns[MAX];
    int x, n, i=0;
    char op;
    cin >> n >> op;
    while(cin >> x)
        ns[i++] = x;
    IntSet S(ns, i);
    S.Map(n,op);
    S.Print(cout);
}catch(char ch){
    cout << "error in " << ch;
}