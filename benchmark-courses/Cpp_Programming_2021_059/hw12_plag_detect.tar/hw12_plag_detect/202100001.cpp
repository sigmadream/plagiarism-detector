#include <iostream>

using namespace std;

class IntSet
{
    public:
        IntSet(int ns[], int size);
        void map(int n, char op);
        void print(ostream &out);
    private:
        int *_ns;
        int _size;
};
IntSet::IntSet(int ns[], int size) {
    _ns = new int[size];
    _size = size;
    for (int i=0; i<size; i++)
        _ns[i] = ns[i];
}
void IntSet::map(int n, char op) {
    for (int i=0; i<_size; i++) {
        switch (op) {
            case '+': _ns[i] = n + _ns[i]; break;
            case '-': _ns[i] = n - _ns[i]; break;
            case '*': _ns[i] = n * _ns[i]; break;
            case '/':
                      if (_ns[i]==0) throw n;
                      _ns[i] = n / _ns[i];
                      break;
            case '%':
                      if (_ns[i]==0) throw n;
                      _ns[i] = n % _ns[i];
                      break;
        }
    }
}
void IntSet::print(ostream &out) {
    out << _ns[0];
    for (int i=1; i<_size; i++) {
        out << " " << _ns[i];
    }
    out << endl;
}
int main()
{
    int size, n, num;
    char op;
    cin >> n >> op;
    int ns[100];
    int i = 0;
    while(cin >> num) {
        ns[i] = num;
        i++;
        size++;
    }
    IntSet myset(ns, size);
    try{
        myset.map(n, op);
    }
    catch (int n) {
        cout << "error in " << op << endl;
        exit(1);
    }
    myset.print(cout);
}
