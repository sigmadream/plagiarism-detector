#include<iostream>
#include<vector>
using namespace std;

int round(vector<int> w) {
    int sz = w.size();
    if (sz == 2)
    {
        if(w[0] > w[1])
            return w[0] - w[1]/2;
        else
            return w[1] - w[0]/2;
    }
    vector<int> nxtW;
    for (int i = 0; i < sz/2; i++)
    {
        int a = w[2*i];
        int b = w[2*i+1];
        int tmpVal;
        if (a > b)
            tmpVal = a - b/2;
        else
            tmpVal = b - a/2;
        nxtW.push_back(tmpVal);
    }
    return round(nxtW);
}
int main()
{
    vector<int> inp;
    int n, res;
    while(cin >> n)
        inp.push_back(n);
    res = round(inp);
    cout << res << endl;
}