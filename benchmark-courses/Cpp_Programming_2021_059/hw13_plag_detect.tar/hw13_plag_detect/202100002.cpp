#include <iostream>
#include <vector>
using namespace std;

int round(vector<int> v) {
    while(v.size() != 1) {
        vector<int> temp;    
        int i = 0;
        while (i < v.size()) {
            if (v[i] > v[i+1]) {
                temp.push_back(v[i] - v[i+1] / 2);            
            }
            else {
                temp.push_back(v[i+1] - v[i] / 2);            
            }
            i += 2;                
        }    
        v = temp;
    }
    return v[0];
}

int main() {
    vector<int> v;
    int t;
    while (cin >> t) {
        v.push_back(t);    
    }
    cout << round(v) << endl;
}

