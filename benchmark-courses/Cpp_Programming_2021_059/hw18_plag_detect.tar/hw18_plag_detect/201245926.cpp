#include <iostream>
#include <cctype>
using namespace std;

string maskdigit(sting s) {
    for (int i = 0; i < s.length(); ++i)
        if (isdigit(s.at(i))) s[i] = '+';
    return s;
}

int main() {
    string s = "I am 24 years old.";
    cout << maskdigit(s) << endl;
}

