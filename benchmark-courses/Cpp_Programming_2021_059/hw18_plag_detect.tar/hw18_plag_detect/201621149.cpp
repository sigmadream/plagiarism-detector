#include <iostream>
#include <string>
#include <cctype>
using namespace std;

const int SIZE = 10000;
template <class T>
class RankingBag
{
public:
    RankingBag(int size = SIZE);
    RankingBag(const RankingBag<T> &s);
    const RankingBag<T> &operator=(const RankingBag<T> &s);
    ~RankingBag();
    bool isfull();
    bool isempty();
    void Pushback(T obj);
    T pop();
    T Elem(int i);
    int Ranking(T obh);
    void show();

private:
    T *_data;
    int _top, _size;
};

template <class T>
RankingBag<T>::RankingBag(int size) : _top(0), _size(size)
{
    _data = new T[size];
}
template <class T>
RankingBag<T>::RankingBag(const RankingBag<T> &s) : _top(s._top), _size(s._size)
{
    _data = new T[_size];
    for (int i = 0; i < _size; ++i)
        _data[i] = s._data[i];
}

template <class T>
const RankingBag<T> &RankingBag<T>::operator=(const RankingBag<T> &s)
{
    delete[] _data;
    _top = s._top;
    _size = s._size;
    _data = new T[_size];
    for (int i = 0; i < _size; ++i)
        _data[i] = s._data[i];
}
template <class T>
RankingBag<T>::~RankingBag()
{
    delete[] _data;
}

template <class T>
bool RankingBag<T>::isfull()
{
    return _top == _size;
}
template <class T>
bool RankingBag<T>::isempty()
{
    return _top == 0;
}
template <class T>
void RankingBag<T>::Pushback(T obj)
{
    if (!isfull())
        _data[_top++] = obj;
}

template <class T>
T RankingBag<T>::pop()
{
    if (!isempty())
        return _data[--_top];
    else
        throw -1; // raising an exception (for stack is empty)
}

template <class T>
T RankingBag<T>::Elem(int i)
{
    if (!isempty())
        return _data[i];
    else
        throw -1; // raising an exception (for stack is empty)
}

template <class T>
int RankingBag<T>::Ranking(T obj)
{
    int Rank = 1;
    for (int i = 0; i < _top; i++)
    {
        if (obj < Elem(i))
            Rank++;
    }
    return Rank;
}

template <class T>
void RankingBag<T>::show()
{
    for (int i = 0; i < _top; i++)
    {
        cout << _data[i] << " ";
    }
    cout << endl;
}

int main(void)
{
    while (!cin.eof())
    {
        if (cin.eof())
            return 0;
        string first_word;
        string word;
        RankingBag<string> myStrBag = RankingBag<string>();
        RankingBag<int> myIntBag = RankingBag<int>();
        bool isNum = false;

        cin >> first_word;

        if (isdigit(first_word[first_word.length() - 1]))
            isNum = true;

        do
        {
            cin >> word;
            if (isNum)
                myIntBag.Pushback(stoi(word));
            else
                myStrBag.Pushback(word);

            if (cin.eof())
            {
                return 0;
            }

        } while (getc(stdin) == ' ' && !cin.eof());

        if (isNum)
        {
            // myIntBag.show();
            cout << myIntBag.Ranking(stoi(first_word)) << endl;
        }
        else
        {
            // myStrBag.show();
            cout << myStrBag.Ranking(first_word) << endl;
        }
    }
}
