#include <cstdio>
#include <iostream>
#include <vector>
#include <string>
#include <cctype>

using namespace std;

template <class T>
class RankingBag{
	T K;
	int num_;
	int rank;
	public:
		void Pushback(T obj){
			K = obj;
		}
		
		T Elem(int i){
			
		}
		
		int Ranking(T obj){
			rank = 1;
			num_ = obj[0];
			for(int i = 0; i < obj.size(); i++){
					if(isblank(obj[i])){
						i += 1;
						if(num_ < int(obj[i])) rank += 1;
					}	
			}
			return rank;
		}
};



int main(){
	vector<string> S;
	string k;
	int i = 0;
	vector<int> num;
	RankingBag<string> rank_;
	while(getline(cin, k)){
		rank_.Pushback(k);
		num.push_back(rank_.Ranking(k));
	}
	for(int i = 0; i < num.size(); i++){
		cout << num[i] << endl;
	}
	
}

