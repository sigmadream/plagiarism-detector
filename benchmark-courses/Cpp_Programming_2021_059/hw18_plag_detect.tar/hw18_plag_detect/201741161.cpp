#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cctype>
#include <sstream>

using namespace std;

template <class T>
class RankingBag{
    vector<T> _v;
public:
    void Pushback(T obj);
    T Elem(int i);
    int Ranking(const T obj);
    string GetS(){return _v[0];}
    int GetI(){return _v[0];}
    void Clear(){_v.clear();}
};
template <class T>
void RankingBag<T>::Pushback(T obj){
    _v.push_back(obj);
}
template <class T>
T RankingBag<T>::Elem(int i){
    vector<T> tmp;
    for(int k = 0; k < _v.size(); k++){
        tmp.push_back(_v[k]);
    }
    sort(tmp.begin(), tmp.end());
    for(int j = 0; j < tmp.size(); j++){
        if(i - 1 == j)
            return tmp[j];
    }
}
template <class T>
int RankingBag<T>::Ranking(const T obj){
    vector<T> tmp;
    T temp;
    for(int k = 0; k < _v.size(); k++){
        tmp.push_back(_v[k]);
    }
    for (int i = 0; i < _v.size() - 1; i++)
    {
        for (int j = 0; j < _v.size() - 1 - i; j++)
        {
            if (tmp[j] < tmp[j + 1])
            {
                temp       = tmp[j];
                tmp[j]     = tmp[j + 1];
                tmp[j + 1] = temp;
            }
        }
    }
    for(int j = 0; j < tmp.size(); j++)
        if(obj == tmp[j])
            return ++j;
    return 0;
}

int main(){
    RankingBag<int> irank;
    RankingBag<string> srank;
    string line;
    string s;
    vector<int> iv;
    vector<string> sv;
    while(getline(cin, line)){
        istringstream ins(line);
        if(!isalpha(line[0])){
            while(ins >> s){
                int num = stoi(s);
                irank.Pushback(num);
            }
            int num2 = irank.GetI();
            cout << irank.Ranking(num2) << endl;
            irank.Clear();
        }
        else{
            while(ins >> s){
                srank.Pushback(s);
            }
            string s2 = srank.GetS();
            cout << srank.Ranking(s2) << endl;
            srank.Clear();
        }
        
    }
}
