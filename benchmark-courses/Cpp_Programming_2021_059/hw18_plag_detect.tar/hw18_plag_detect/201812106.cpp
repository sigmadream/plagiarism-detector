#include <bits/stdc++.h>
using namespace std;
string tmp;
char s[1010101];
template <typename T>
int foo(T a, T b) {
	return a < b;
}
template<>
int foo(char* a, char* b) {
	return strcmp(a, b) == -1;
}
template <typename T>
class RankingBag {
private:
	T* data;
	int len;
public:
	RankingBag() {
		data = new T[10005];
		len = 0;
	}
	void Pushback(T obj) {
		data[len++] = obj;
	}
	T Elem(int i) {
		return data[i];
	}
	int Ranking(T obj) {
		int cnt = 0;
		for (int i = 0; i < len; i++) {
			if (foo(obj, data[i])) cnt++;
		}
		return cnt + 1;
	}
};
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	while (getline(cin, tmp)) {
		memset(s, 0, sizeof(s));
		strcpy(s, tmp.c_str());
		int len = strlen(s);
		int chk = 0;
		for (int i = 0; i < len; i++) {
			if (s[i] == '+' || s[i] == '-') {
				chk = 1;
			}
		}
		if (chk == 0) {
			RankingBag<char*> bag;
			char *ptr = strtok(s, " ");
			while (ptr != NULL) {
				bag.Pushback(ptr);
				ptr = strtok(NULL, " ");
			}
			cout << bag.Ranking(bag.Elem(0)) << "\n";
		}
		else {
			RankingBag<int> bag;
			char *ptr = strtok(s, " ");
			char *end;
			while (ptr != NULL) {
				double num = 0;
				if (ptr[0] == '+') {
					num = stoi(ptr + 1);
				}
				else if (ptr[0] == '-') {
					num = -stoi(ptr + 1);
				}
				else {
					num = stoi(ptr);
				}
				bag.Pushback(num);
				ptr = strtok(NULL, " ");
			}
			cout << bag.Ranking(bag.Elem(0)) << "\n";
		}
	}
}