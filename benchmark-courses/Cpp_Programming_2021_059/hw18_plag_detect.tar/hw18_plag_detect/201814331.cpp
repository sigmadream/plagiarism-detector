#include <cstdio>
#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int i = 0, j = 0, k = 0;

template <typename T>
class RankingBag
{
	public : 
		RankingBag(T bag)
			: Bag(bag) {};
		void Pushback(T obj) { // �� ������ obj �о�ֱ�
			for ( j = 0; j < obj.length(); ++j )
				if ( isdigit(obj.at(j)) ) Bag[j] = '*';
		}
		T Elem(int i) { // i-th ��ü�� ��ȯ

			return Bag[i];
		}
		int Ranking(T obj) { // obj ������ ��ȯ	
			int cnt;
			int rank[obj.length()];

			for ( j = 0; j < obj.length(); j++ ) {
				cnt = 0;

				for ( k = 0; k < obj.length(); k++ )
					if (Bag[j] < Bag[k]) cnt++;

				rank[j] = cnt + 1;
			}
			
			return rank[0];
		}
	
	private : 
		T Bag;
};

/*string maskdigit(string s) {
	for (int i = 0; i < s.length(); ++i)
		if (isdigit(s.at(i))) s[i] = '*';
		
	return s;
}*/


int main()
{
	int step, print[10000];
	string s, m;
	
	i = 0;
	while(1) {
	
		while (getline(cin, s))
		{
		RankingBag<string> std(m);
		std.Pushback(s);
		//std.Elem();
		print[i] = std.Ranking(s);
		i++;
		}
		
		break;

	}

	step = i;
	for ( i = 0; i < step; i++ )
		cout << print[i] << endl;

}
