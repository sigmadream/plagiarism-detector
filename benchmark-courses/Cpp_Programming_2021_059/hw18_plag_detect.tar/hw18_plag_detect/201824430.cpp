#include <iostream>
#include <cctype>
#include <algorithm>
#include <cstring>
#include <sstream>

using namespace std;

template <typename T>
class RankingBag {
	T* data;
	int capacity;
	int length;
	public:
		RankingBag(int n = 1) : data(new T[n]), capacity(n), length(0) {}
		
		void PushBack(T obj) {
			if (capacity <= length) {
				T* temp = new T[capacity * 2];
				for (int i = 0; i < length; i++) {
					temp[i] = data[i];
				}
				delete[] data;
				data = temp;
				capacity *= 2;
			}
			
			data[length] = obj;
			length++;
		}
		
		T Elem(int i) {
			return data[i];
		}
		
		int Ranking(T obj) {
			int index;
			sort(data, data+capacity);
			for (int i=0; i < capacity;i++){
				if (data[i] == obj) {
					index = i;
				}
			}
			
			return capacity - index;			
		}
};

int main(){
	int n = 0;
	RankingBag<string> StrRank[10000];
	RankingBag<int> IntRank[10000];
	string line;
	string input; 
	while(getline(cin,line)){
		stringstream ss(line);
		while (ss >> input)
		{
			if (isalpha(input[0])){
				StrRank[n].PushBack(input);
			}
			else {
				const char* c = input.c_str();
				int num = atoi(c);
				IntRank[n].PushBack(num);
			}
		}
		if (isalpha(input[0])){
		 	cout << StrRank[n].Ranking(StrRank[n].Elem(0)) << endl;
		}
		else {
			cout << IntRank[n].Ranking(IntRank[n].Elem(0)) << endl;
		}
		n++;
	}
	
	return 0;
		
}
