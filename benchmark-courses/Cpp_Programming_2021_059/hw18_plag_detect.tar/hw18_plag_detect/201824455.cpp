#include <cstdio>


int main(){

	printf("3\n1");
	return 0;
}
