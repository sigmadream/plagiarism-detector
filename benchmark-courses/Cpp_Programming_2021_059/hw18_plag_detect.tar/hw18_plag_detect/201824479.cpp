#include <iostream>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

template <class T>
class RankingBag {
    vector<T> v;
    int val;
public:
    RankingBag(): val(1) {}
    void Pushback(T obj);
    T Elem(int i);
    int Ranking(T obj);
    void Clear() {
        v.clear();
    }
};

template <class T>
void RankingBag<T>::Pushback(T obj) {
    v.push_back(obj);
}

template <class T>
T RankingBag<T>::Elem(int i) {
    return v[i];
}

template <class T>
int RankingBag<T>::Ranking(T obj) {
    
    for (int i =1;i<v.size();i++) {
        if (v[i] > obj) {
            val++;

        }
    }
    return val;
}


int main() {
    
    string s;
    while (getline(cin,s)) {
        if (isdigit(s.back())) {
            RankingBag<int> r;
            string ss;
            istringstream ins(s);
            
            while (ins >> ss) {
            
                int n;
                stringstream plz;
                plz << ss;
                plz >> n;
            
                r.Pushback(n);
            }
            int num;
            num = r.Elem(0);
            cout << r.Ranking(num) << endl;
            r.Clear();
        }
        else {
            RankingBag<string> r;
            string ss;
            istringstream ins(s);
            while (ins >> ss) {
                r.Pushback(ss);
            }
            ss = r.Elem(0);
            cout << r.Ranking(ss) << endl;
            r.Clear();
        }

    }
    
}

