#include <iostream>
#include <vector>
#include <string>
#include <cctype>
#include <sstream>
#include <algorithm>
using namespace std;
int pot(int i){
    if(i == 0)
        return 1;
    return pot(i-1) *10;
}
template <class T>
class RankingBag{
    vector<T> s;
public:
    void Renew(){ s.clear(); }
    void Pushback(T obj){ s.push_back(obj); }
    T Elem(int i){ return s[i]; }
    int Ranking(T obj){
        int cnt = 1;
        T samp[10000];
        for(int i = 0; i < s.size(); i++)
            samp[i] = s[i];
        sort(samp, samp + s.size());
        for(int i = s.size()-1; i >=0; i--){
            if(obj == samp[i])
                break;
            cnt++;
        }
        return cnt;
    }
};
int main(){
    string y;
    RankingBag<int> is;
    RankingBag<string> ss;
    while(getline(cin, y)){
        if(islower(y.at(0))){
            istringstream iss(y);
            string stringbuffer;
            while(getline(iss, stringbuffer, ' '))
                ss.Pushback(stringbuffer);
            cout << ss.Ranking(ss.Elem(0)) << endl;
            ss.Renew();
        }
        else if(isdigit(y.at(0)) || y.at(0) == '+' || y.at(0) == '-'){
            istringstream iss(y);
            string stringbuffer;
            int tmp = 0;
            while(getline(iss, stringbuffer, ' ')){
                if(stringbuffer.at(0) == '+'){
                    for(int i = 1; i < stringbuffer.length(); i++)
                        if(stringbuffer.at(i) != '\0')
                            tmp += pot(stringbuffer.length()-i-1) * (int(stringbuffer.at(i)) - 48);
                }
                else if(stringbuffer.at(0) == '-'){
                    for(int i = 1; i < stringbuffer.length(); i++)
                        if(stringbuffer.at(i) != '\0')
                            tmp -= pot(stringbuffer.length()-i-1) * (int(stringbuffer.at(i)) - 48);
                }
                else{
                    for(int i = 0; i < stringbuffer.length(); i++)
                        if(stringbuffer.at(i) != '\0')
                            tmp += pot(stringbuffer.length()-i-1) * (int(stringbuffer.at(i)) - 48);
                }
                is.Pushback(tmp);
                tmp = 0;
            }
            cout << is.Ranking(is.Elem(0)) << endl;
            is.Renew();
        }
    }
}
