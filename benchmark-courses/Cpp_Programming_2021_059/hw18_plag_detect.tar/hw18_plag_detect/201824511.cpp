#include<iostream>
#include<cctype>
#include<sstream>
#include<string>
#include<fstream>

using namespace std;
template <typename T>  //입력 line의 first obj를 저장
class RankingBag{
    string input;
public:
    RankingBag(string _input=""):input(_input){}
 // 입력한 원소 1개 값을 받아서 input에 저장
    void Pushback(T obj){
        stringstream iss;
        iss << obj;
        string var;
        var = iss.str();
        input = input + ' ' + var;
    }

    void Pop(){
        input = "";
    }
 // rankingbag의 string의 i번째 단어 or 글짜 반환( 주의 배열 값이 아님!! 즉 at()이 아님 )
    T Elem(int i){ 
        istringstream iss;
        iss.str(input);
        T var;
        T result;   //?? 왜됨?
        int loop = 0;
        while(iss >> var){
            if(loop == i) result = var;
            loop++;
        }
        return result;
    }
    // first 값을 받아서 ranking 을 한다.
    int Ranking(T obj){
        istringstream iss;
        iss.str(input);
        T var;
        int rank=1;
        while(iss >> var){
            if(obj < var) rank += 1;
        }
        return rank;
    }
};

int main(){
    RankingBag<int> a;
    RankingBag<string> b;
    string input;
    ofstream fout("out.txt");
    while(getline(cin, input)){
        if(islower(input.at(0)) ){
            string var;
            istringstream iss;
            iss.str(input);
            while(iss >> var){
                b.Pushback(var);
            }
            string first = b.Elem(0);
            int result = b.Ranking(first);
            cout << result << endl;
            b.Pop();
        }
            
        else{
            int var;
            istringstream iss;
            iss.str(input);
            while(iss >> var){
                a.Pushback(var);
            }
            int first = a.Elem(0);
            int result = a.Ranking(first);
            cout << result << endl;
            a.Pop();
        }
    }
}