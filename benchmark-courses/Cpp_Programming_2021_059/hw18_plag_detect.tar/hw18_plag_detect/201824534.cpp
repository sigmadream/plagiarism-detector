#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
const int SIZE = 100;

template <typename T>
class RankingBag{
public:
    T temp;
    RankingBag(){
        temp = data[0];
    };
    void Pushback(T obj);
    T Elem(int i);
    int Ranking(T obj);
private:
    int k=0;
    T data[SIZE];
};

template <typename T>
void RankingBag<T>::Pushback(T obj){
    data[k++] = obj;
}

template <typename T>
T RankingBag<T>::Elem(int i){
        return data[i];
}

template <typename T>
int RankingBag<T>::Ranking(T obj){
    temp = obj;
    sort(data, data+k,greater<T>());
    for(int i = 0; i<k;i++){
        if(sizeof(*data)==4){
            if(data[i] == temp)
                return i+1;
            return 0;
        }
        else{
            if(data[i] == temp)
                return i+1;
            return 0;
        }
    }
}

int main(){
    int x1,p[SIZE];
    string x2,q[SIZE];
    RankingBag<int> n;
    RankingBag<string> s;

    while(1){
        while(cin>>x1||cin>>x2){
            n.Pushback(x1);
            s.Pushback(x2);    
        }
        cout << n.Ranking(n.temp) << endl;
        if(EOF) break;
    }
}