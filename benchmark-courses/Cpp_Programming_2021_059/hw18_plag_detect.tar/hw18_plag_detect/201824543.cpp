#include <iostream>
#include <string>
#include <cctype>
#include <sstream>

#define DATA_MAX_SIZE 10000

template <class T>
class RankingBag
{
private:
	T* data;
	int top;

public:
	RankingBag();
	~RankingBag();
	void Pushback(T obj);
	T Elem(int i);
	int Ranking(T obj);
};

int main()
{
	std::string inputLine;

	while (getline(std::cin, inputLine))
	{
		if (isalpha(inputLine[0]))
		{
			RankingBag<std::string> strBag;
			std::istringstream ins(inputLine);
			std::string s;

			while (ins >> s)
			{
				strBag.Pushback(s);
			}

			std::string temp = strBag.Elem(0);
			int strRank = strBag.Ranking(temp);

			std::cout << strRank << std::endl;
		}
		else if (isdigit(inputLine[0]) || inputLine[0] == '+' || inputLine[0] == '-')
		{
			RankingBag<int> intBag;
			std::istringstream ins(inputLine);
			std::string s;

			while (ins >> s)
			{
				int pushTemp = std::stoi(s);
				intBag.Pushback(pushTemp);
			}

			int temp = intBag.Elem(0);
			int intRank = intBag.Ranking(temp);

			std::cout << intRank << std::endl;
		}
	}

	return 0;
}

template <class T>
RankingBag<T>::RankingBag() : top(0)
{
	data = new T[DATA_MAX_SIZE];
}

template <class T>
RankingBag<T>::~RankingBag()
{
	delete[] data;
}

template <class T>
void RankingBag<T>::Pushback(T obj)
{
	data[top] = obj;
	top++;
}

template <class T>
T RankingBag<T>::Elem(int i)
{
	return data[i];
}

template <class T>
int RankingBag<T>::Ranking(T obj)
{
	int rank = 1;

	for (int i = 0; i < top; i++)
	{
		if (data[i] > obj)
		{
			rank++;
		}
	}

	return rank;
}