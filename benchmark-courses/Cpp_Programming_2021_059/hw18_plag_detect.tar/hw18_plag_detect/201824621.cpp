#include <iostream>
#include <vector>
#include <cctype>
#include <sstream>

using namespace std;

template<class T>
class RankingBag {
public:
    void Pushback(T obj);
    T Elem(int j);
    int Ranking(T obj);
private:
    vector<T> bag;
};

template<class T>
void RankingBag<T>::Pushback(T obj) {
    bag.push_back(obj);
}

template<class T>
T RankingBag<T>::Elem(int j) {
    if (j > -1 && j < this->bag.size()) {
        return this->bag[j];
    }
    else {
        throw j;
    }
}

template<class T>
int RankingBag<T>::Ranking(const T obj) {
    int rank = 1;
    for (int i = 0; i < bag.size(); i++) {
        if (bag[i] > obj) 
            rank++;
    }
    return rank;
}

bool is_number(string s) {
    for (int i = 0; i < s.length(); i++) {
        if (isdigit(s.at(i))) {
            return true;
        }
    }
    return false;
}

int main()
{
    string line;
    while(getline(cin,line)) {
        istringstream ins(line);
        string s;
        ins >> s;
        if (is_number(s)) {
            RankingBag<int> r;
            r.Pushback(stoi(s));
            while (ins >> s) {
                r.Pushback(stoi(s));
            }
            int f = r.Elem(0);
            cout << r.Ranking(f) << endl;
        }
        else {
            RankingBag<string> r;
            r.Pushback(s);
            while (ins >> s) {
                r.Pushback(s);
            }
            string f = r.Elem(0);
            cout << r.Ranking(f) << endl;
        }
    }
}
