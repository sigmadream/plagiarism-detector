#include <iostream>
#include <cctype>
#include <string>
#include <vector>
#include <sstream>
using namespace std;

template<class T>
class RankingBag {
    vector<T> list;
    int _rank;
public:
    int Ranking(T obj);
    
    void Pushback(T obj) {
        list.push_back(obj);
    }

    T Elem(int i) {
        if(i > -1 && i < list.size()) 
            return list[i];
        else throw i;
    }

};

template<class T>
int RankingBag<T>::Ranking(T obj) {
    int rank = 1;

    for(int i = 0; i < list.size(); i++) 
        if(obj < list[i]) rank++;

    return rank;
}

int main() {
    string l;

    while(getline(cin, l)) {
        istringstream ins(l);
        string str;
        ins >> str;

        if(isdigit(str.at(0)) || 
            ((str.at(0) == '-' || str.at(0) == '+') && isdigit(str.at(1)))
        ) {
            RankingBag<int> bag;
            bag.Pushback(stoi(str));

            while(ins >> str) 
                bag.Pushback(stoi(str));

            int r = bag.Elem(0);
            cout << bag.Ranking(r) << endl;
        } else {
            RankingBag<string> bag;
            bag.Pushback(str);

            while (ins >> str)
                bag.Pushback(str);

            string f = bag.Elem(0);
            cout << bag.Ranking(f) << endl;
        }
    }
}
