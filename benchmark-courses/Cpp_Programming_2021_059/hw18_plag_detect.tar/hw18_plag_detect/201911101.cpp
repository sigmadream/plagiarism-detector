#include <iostream>
#include <cctype>
#include <string>
#include <sstream>
#include <vector>
using namespace std;

const unsigned int MAX = 10000;

template <class T>
class RankingBag {
public:
    RankingBag() {;}
    void Pushback(T obj); // pushes obj into the bag
    T Elem(int i); // returns the i-th object
    int Ranking(T obj); // returns the ranking of obj
private:
    vector<T> v;
};

template <class T>
void RankingBag<T>::Pushback(T obj) {
    v.push_back(obj);
}

template <class T>
T RankingBag<T>::Elem(int i) {
    return v.at(i);
}

template <class T>
int RankingBag<T>::Ranking(T obj) {
    int res = 1;
    for(T n: v){
        if (n > obj) res++;
    }
    return res;
}

bool islinedigit(string line) {
    return (isdigit(line.at(0)) || isdigit(line.at(1)));
}


int main() {
    string line;
    while(getline(cin, line)) {
        istringstream ins(line);
        if (islinedigit(line)) {
            RankingBag<int> Bag;
            int n;
            while(ins >> n)
                Bag.Pushback(n);
            cout << Bag.Ranking(Bag.Elem(0)) << endl;
        }
        else {
            RankingBag<string> Bag;
            string s;
            while(ins >> s)
                Bag.Pushback(s);
            cout << Bag.Ranking(Bag.Elem(0)) << endl;
        }
    }
}