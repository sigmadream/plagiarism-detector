#include <iostream>
#include <cctype>
using namespace std;

template <class T>
class SubSet
{
    T arr[10001];
    int size;

public:
    SubSet(int _size = 0) : size(_size) {}
    void Pushback(T obj)
    {
        arr[size++] = obj;
    }
    T Elem(int i)
    {
        if (size == 0)
            throw -1;
        return arr[i];
    }
    int Ranking(T obj)
    {
        int great = 1;
        for (int i = 1; i < size; i++)
        {
            if (arr[0] < arr[i])
                great++;
        }
        return great;
    }
    int GetSize() { return size; }
};

bool type_check(string s)
{
    int size = s.size();
    int num = 0, cha = 0, let = 0;
    for (char t : s)
    {
        if (t == ' ')
        {
        }
        else if (t == '-' || t == '+')
            cha++;
        else if (t <= '9' && t >= '0')
            num++;
        else
            let++;
    }
    if (let == 0)
    {
        return true; //number;
    }
    return false;
}

void convertInt(SubSet<int> *a, string s)
{
    int size = s.size();
    int y = 0;
    bool neg = false;
    for (char t : s)
    {
        if (t == ' ')
        {
            if (neg)
                y *= -1;
            a->Pushback(y);
            y = 0;
            neg = false;
        }
        else if (t == '+')
        {
            neg = false;
        }
        else if (t == '-')
        {
            neg = true;
        }
        else
        {
            y = y * 10 + (t - '0');
        }
    }
    if (neg)
        y *= -1;
    a->Pushback(y);
}

void convertString(SubSet<string> *a, string s)
{
    int size = s.size();
    string y = "";
    for (char t : s)
    {
        if (t == ' ')
        {
            a->Pushback(y);
            y = "";
        }
        else
        {
            y += t;
        }
    }
    a->Pushback(y);
}

int main()
try
{
    string s;
    while (getline(cin, s))
    {
        if (type_check(s))
        {
            // convert
            SubSet<int> ss;
            convertInt(&ss, s);
            cout<<ss.Ranking(ss.Elem(0))<<endl;
        }
        else
        {
            // convert
            SubSet<string> ss;
            convertString(&ss, s);
            cout<<ss.Ranking(ss.Elem(0))<<endl;
        }
    }
}
catch (int t)
{
    cout << "error in " << endl;
}