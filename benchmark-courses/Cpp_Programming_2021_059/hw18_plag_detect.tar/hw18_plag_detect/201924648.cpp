#include <iostream>
#include <vector>
#include <cctype>
#include <string>

using namespace std;

template <typename T>
class RankingBag{
    public:
        void Pushback(T obj){
            if(bag.empty()){
                firstvalue = obj;
            }
            bag.push_back(obj);
        }

        T Elem(int i){
            return bag.at(i);
        }
        int Ranking(T obj){
            int rank=1;

            for(size_t i =1; i<bag.size();i++){
                if(obj<bag[i]){
                    rank++;   
                }
            }
            return rank;
        }
    private:
        vector<T> bag;
        T firstvalue;
};

int main(){
    vector<string> vec;
    string str;
    
    while(getline(cin,str)){ 
        RankingBag<int> bag1;
        RankingBag<string> bag2;
        str+=' '; //반복문 최적화
        string temp="";
        for(auto itr :str){
            if(itr!=' '){
                temp+=itr;
            }else{
                vec.push_back(temp);
                temp.clear();
            }
        }

        if(isdigit(str[0])||isdigit(str[1])){
            for(auto i:vec){
                bag1.Pushback(stoi(i));
            }
            cout<<bag1.Ranking(bag1.Elem(0))<<endl;
        }else{
            for(auto i:vec){
                bag2.Pushback(i);
            }
            cout<<bag2.Ranking(bag2.Elem(0))<<endl;
        }
        str.clear();
        vec.clear();
    }
}