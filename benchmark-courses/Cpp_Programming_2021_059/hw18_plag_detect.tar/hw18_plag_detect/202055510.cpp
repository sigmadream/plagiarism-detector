#include <iostream>
#include <cctype>
#include <string>
#include <vector>
#include <sstream>
#include <cstdlib>

using namespace std;

template <class T>
class RankingBag{
	private:
		vector<T> v;
		
	public:
		void Pushback(T obj){
			v.push_back(obj);
		}
		
		T Elem(int i){
			return v[i];
		}
		
		int Ranking(const T& obj){
			int rank = 1;
			for(int i = 0; i < v.size(); i++){
				if(obj < v[i]){
					rank++;
				}
			}
			return rank;
		}
};

int main(){
	string s;
	while(getline(cin, s)){
		RankingBag<string> Rs;
		RankingBag<int> Ri;
		istringstream iss(s);
		int is_int = 0;
		while(iss >> s){
			if(isdigit(s.at(0)) || s.at(0) == '+' || s.at(0) == '-'){
				int a = stoi(s);
				Ri.Pushback(a);
				is_int = 1;
			}
			else{
				Rs.Pushback(s);
			}
		}
		if(is_int){
			cout << Ri.Ranking(Ri.Elem(0)) << endl;
		}
		else{
			cout << Rs.Ranking(Rs.Elem(0)) << endl;
		}
	}
}
