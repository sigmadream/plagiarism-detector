#include <iostream>
#include <cctype>
#include <vector>
#include<sstream>
using namespace std;

template <class T>
class RankingBag
{
public :
    RankingBag() {vec.clear();}

    void Pushback (T obj)
    {
        vec.push_back(obj);
    }

    T Elem(int i)
    {
        return vec[i];
    }

    int Ranking(T obj)
    {
        int rankNum=0;
        for(int i=0; i<vec.size(); i++)
        {
            if(obj < vec[i])
                rankNum++;
        }
        return ++rankNum;
    }

private:
    vector<T> vec;
};

int main()
{
    string s;
    vector<int> ranking;
    while(getline(cin, s))
    {
        if(isdigit(s[0])||isdigit(s[1]))
        {
            RankingBag<int> bag;
            istringstream ins(s);
            string buffer;
            while (getline(ins, buffer, ' '))
            {
                int num=0;
                if(isdigit(buffer[0]))
                {
                    for(int i=0; i<buffer.size();i++)
                    {
                        num = num*10 + stoi(buffer);
                    }
                    bag.Pushback(num);
                }
                else if(buffer[0] == '-'|| buffer[0] == '+')
                {
                    for(int i=1; i<buffer.size();i++)
                    {
                        num = num*10 + stoi(buffer);
                    }
                    if(buffer[0] == '-')
                        num*=-1;
                    bag.Pushback(num);
                }
            }
            int first = bag.Elem(0);
            ranking.push_back(bag.Ranking(first));
        }
        else
        {
            RankingBag<string> bag;
            istringstream ins(s);
            string buffer;
            while (getline(ins, buffer, ' '))
            {
                bag.Pushback(buffer);
            }
            string first = bag.Elem(0);
            ranking.push_back(bag.Ranking(first));
        }
    }
    for(int i=0; i<ranking.size();i++)
    {
        cout << ranking[i] <<endl;
    }
}
