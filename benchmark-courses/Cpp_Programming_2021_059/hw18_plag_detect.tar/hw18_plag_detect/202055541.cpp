#include<iostream>
#include<string>
#include<list>
#include<cctype>
#include<sstream>
#include<vector>

using namespace std;

template <typename T>
class RankingBag {
public:
list <T> L;

   
void Pushback(T hi) {
    istringstream ss(hi);
    string buf;

    if ( isdigit(hi[0])  ) // ���ڿ��϶�
    {
        while (getline(ss, buf , ' ')){
            L.push_back(buf);
           // cout << buf << endl;
        }  
      //  cout << "hi hello" << endl;
    }

    else // ���ڿ��϶� 
    {
        while (getline(ss, buf, ' ')) {
            L.push_back(buf);
            //cout << buf << endl;
        }
        //cout << "bye" << endl;
    }

    }
T Elem() {
    T find = L.front();
    L.sort();
    L.reverse();
    return find;
}

int Ranking(T obj) {
    int num = 0;
    while (1) {
        if ( L.front() == obj) {
            return num+1;
            break;
        }
        L.pop_front();
        num++;
    }
}

};






int main(void) {
    char ans[100];
    char a[1000];
    RankingBag<string> R;
    //RankingBag<int> R;

    
    int i = 0;
    while ( !cin.eof() ) {
        cin.getline(a, 1000);
         R.Pushback(a);
        // ans[i] = R.Ranking(R.Elem());
         cout << R.Ranking(R.Elem()) << endl;
         R.L.clear();
         i++;
    }

/*
    int r = 0;
    while (1) {
        cout << ans[r] << endl;
        r++;
    }
    */


    
    return 0;
}
