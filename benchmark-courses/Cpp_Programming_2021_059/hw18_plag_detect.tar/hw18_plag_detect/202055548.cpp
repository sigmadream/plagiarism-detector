#include <iostream>
#include <cstdio>

int main()
{
	char in;
	char subject;
	int i_char = 0;
	int ready_voca = 0;
	int count = 0;
		
		while(std::cin.get(in))
		{
			if(i_char == 0)
			{
				if((in == '+')|(in=='-'))
				{
					i_char = -1;
				}
				else subject = in;
			}
			if(ready_voca == 1)
			{
				char relative = in;
				if(relative > subject)
				{
					count += 1;
				}
				ready_voca = 0;
			}	
			if(in == ' ') //blank 
			{
				ready_voca = 1;
			}
			if(in == '\n') //end
			{
				std::cout<<count+1<<'\n';
				i_char = 0;
				ready_voca = 0;
				count = 0;
				continue;
			}		
			i_char = i_char + 1;
		}
}
