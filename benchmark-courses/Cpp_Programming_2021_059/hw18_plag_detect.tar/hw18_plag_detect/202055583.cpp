#include <iostream>
#include <cctype>
#include <string>
#include <sstream>
using namespace std;

string maskdigit (string s) {
    for (int i = 0; i < s.length(); ++i)
        if(isdigit(s.at(i))) s[i]='*';
    return s;
}

int main() {
    string line = "Do you know C++20, a descendant of C++0x?";
    string s;
    istringstream ins(line);
    while (ins >> s)
        cout << maskdigit(s) <<endl;
}

