#include <iostream>
#include <cctype>
#include <string>
#include<vector>
#include <algorithm>
#include<typeinfo>

using namespace std;
int stoooi(string a){
    if(a[0]=='-'){
        return stoi(a.substr(1))*-1;
    }
    if(a[0]=='+'){
        return stoi(a.substr(1));
    }
    else{
        return stoi(a);
    }
}

vector<int> vectoint(vector<string>vec){
    vector<int>newvec;
    for(int i =0;i<vec.size();i++){
        if(vec[i][0] =='+'){
            newvec.push_back(stoi(vec[i].substr(1)));
        }
        if(vec[i][0] =='-'){
            newvec.push_back(stoi(vec[i].substr(1))*(-1));
        }
        else{
            newvec.push_back(stoi(vec[i]));
        }
    }
    return newvec;
}



template <typename T>
void showvec_rev(vector<T>vec){
    for(int i = vec.size()-1;i>=0;i--){
        cout << vec[i] << endl;
    }
}



template <typename T>
T vec_init(vector<T>vec){
    return vec[0];
}

template <typename T>
void vecsort(vector<T>vec){
    sort(vec.begin(),vec.end());
}

template <typename T>
void vec_idx(vector<T>vec,T something){
    for(int i = vec.size()-1;i>=0;i--){
        if(something == vec[i]){
            cout << vec.size()-i << endl;
            break;
        }
    }
}

template <typename T>
void runner(vector<T>stvec){

    T a = vec_init(stvec);
    if(isalpha(a[1]) != 2){
        vector<int>stvec2 = vectoint(stvec);
        sort(stvec2.begin(),stvec2.end());
        //showvec_rev(stvec);
        vec_idx(stvec2,stoooi(a));
    }
    else{
        sort(stvec.begin(),stvec.end());
        //showvec_rev(stvec);
        vec_idx(stvec,a);
    }

}

int main() {

    string a;
    vector<string>sample;
    while(!cin.eof()){
        cin >> a;
        sample.push_back(a);
        if(cin.get() == '\n' | cin.eof()){
            runner(sample);
            sample = {};

        }
    }







}
