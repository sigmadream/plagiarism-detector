#include <iostream>
#include <sstream>
#include <cctype>
#include <string>
using namespace std;

const int SIZE = 20;

template <class T>
class RankingBag {
public:
    RankingBag(int size = SIZE);
    RankingBag(const RankingBag <T>& s);
    ~RankingBag();
    bool IsFull();
    void Clear();
    void Pushback(T obj);
    int Ranking(T obj);
    T Elem(int i);
private:
    T *_data;
    int _top, _size;
};

template <class T>
RankingBag<T>::RankingBag(const int size) : _top(0), _size(size) {
    _data = new T[size]();
}

template <class T>
RankingBag<T>::RankingBag(const RankingBag<T>& s) : _top(s._top), _size(s._size) {
    _data = new T[_size];
    for (int i = 0; i < _size; ++i)
        _data[i] = s._data[i];
}

template <class T>
RankingBag<T>::~RankingBag() {
    delete [] _data;
}

template <class T>
bool RankingBag<T>::IsFull() {
    return _top == _size;
}


template <class T>
void RankingBag<T>::Clear() {
    _top = 0;
}

template <class T>
void RankingBag<T>::Pushback(const T obj) {
    if (! IsFull())
        _data[_top++] = obj;
}

template <class T>
T RankingBag<T>::Elem(int i) {
    if (i<_top)
        return _data[i];
    else
        throw -1;
}


template <class T>
int RankingBag<T>::Ranking(T obj){
    int is_num =0;
    for(int i=0; i<obj.length();i++){
        if(isdigit(obj.at(i))){
            is_num=1;
        }
    }
    int ranking = 1;
    if(is_num){
        int int_obj=0;
        stringstream ssInt1(obj);
        ssInt1 >> int_obj;
        for(int j=0; j<_top;j++){
            int ival=0;
            stringstream ssInt2(_data[j]);
            ssInt2 >> ival;
            if(int_obj<ival)
                ranking+=1;
        }
    }
    else{
        for(int j=0;j<_top;j++){
            if(obj < _data[j])
                ranking+=1;
        }
    }


    return ranking;

}

int main()
{
    string x;
    string s;

    RankingBag<string> bag;
    while (getline(cin, x)) {
        istringstream ins(x);
        while(ins >> s){
            bag.Pushback(s);
        }
        cout << bag.Ranking(bag.Elem(0)) << endl;
        bag.Clear();
    }
    return 0;
}
