#include <iostream>
#include <cctype>
#include <vector>
#include <sstream>

using namespace std;

template<class T>
class RankingBag{
    vector<T> _data;
    int _size, _top;
public:
    RankingBag(int size = 0): _size(size), _top(0)   {}
    ~RankingBag(){
        _data.clear();
    }
    T Elem(int i){
        return _data[i];
    }
    void Pushback(T obj){
        _data.push_back(obj);
    }
    int Ranking(const T &obj){
        int rnk = 0;
        for(int i = 0; i< _data.size(); i++){
            if(obj < _data[i])
                rnk++;
        }
        return rnk+1;
    }
};
int main(){
    string str;
    while(getline(cin, str)){
        istringstream ss(str);
        if(isdigit(str[0]) || str[0] == '+' || str[0] == '-' ){
            RankingBag<int> Rint;
            int num;
            while(ss>>num)
                Rint.Pushback(num);
            cout << Rint.Ranking(Rint.Elem(0)) << endl;
        }else{
            RankingBag<string> Rstr;
            string temp;
            while(ss>>temp)
                Rstr.Pushback(temp);
            cout << Rstr.Ranking(Rstr.Elem(0)) << endl;
        }
    }
}
