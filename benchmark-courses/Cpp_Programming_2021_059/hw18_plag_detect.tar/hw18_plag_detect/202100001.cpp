#include <iostream>
#include <string>
#include <sstream>
#include <cctype>
using namespace std;

template<class T> class RankingBag {
public:
    RankingBag() : size(0) {}
    void Pushback(T obj);
    T Elem(int i);
    int Ranking(T obj);
    int getSize() {return size;}
private:
    T _elems[100];
    int size;
};

template<class T> void RankingBag<T>::Pushback(T obj) {_elems[size++] = obj;}

template<class T> T RankingBag<T>::Elem(int i) {return _elems[i];}

template<class T> int RankingBag<T>::Ranking(T obj){
    int index = 0;
    for (int i = 1; i < size; i++) {
        if (_elems[i] > obj)
            index++;
    }
    return index + 1;
}

int main() {
    string line;
    while (getline(cin, line)) {
        int rank;
        RankingBag<string> strElements;
        RankingBag<int>    intElements;
        istringstream iss(line);
        string s;
        bool isString = false;
        if (isalpha(line.at(0)))
            isString = true;
        while (getline(iss, s, ' ')) {
            if (isString)
                strElements.Pushback(s);
            else {
                int e;
                stringstream ss;
                ss << s;
                ss >> e;
                intElements.Pushback(e);
            }
        }
        if (isString) {
            string top = strElements.Elem(0);
            rank = strElements.Ranking(top);
        } else {
            int top = intElements.Elem(0);
            rank = intElements.Ranking(top);
        }
        cout << rank << endl;
    }
}