#include <bits/stdc++.h>
using namespace std;

template <class T>
class RankingBag
{
private : 
    T *arr;
    int arrlen;
public:
    RankingBag(): arrlen(0) {
        arr=new T[10000];
    }
    void Pushback(T obj) {
        arr[arrlen++]=obj;
    }
    T Elem(int i) {
        return arr[i-1];
    }    
    int Ranking(T obj) {   
        int ranking=1;
        for(int i=0;i<arrlen;i++) {
            if(obj<arr[i])
                ranking++;
        }
        return ranking;
    }
    void clear() {
        arrlen=0;
    }
};

int main(void)
{   
    string tmp;
    ostringstream buf;
    int num=0;
    int sign=1;

    while(getline(cin,tmp)) {
        if(isalpha(tmp[0])) {
            RankingBag<string> a;
            for(int i=0;i<tmp.length();i++) {
                if(isalpha(tmp[i]))
                    buf<<tmp[i];
                else {
                    a.Pushback(buf.str());
                    buf.str("");
                }
            }
            if(buf.str()!="") {
                a.Pushback(buf.str());
                buf.str("");
            }   
            cout<<a.Ranking(a.Elem(1))<<endl;
            a.clear();
        }
        else {
            sign=1;
            num=0;
            RankingBag<int> b;
            for(int i=0;i<tmp.length();i++) {
                if(isdigit(tmp[i]))
                    num=num*10+(tmp[i]-'0');
                else if(tmp[i]=='-')
                    sign=-1;
                else if(tmp[i]=='+')
                    sign=1;
                else {
                    b.Pushback(num*sign);
                    num=0;
                    sign=1;
                }
            }
            if(num!=0)
                b.Pushback(num*sign);
            cout<<b.Ranking(b.Elem(1))<<endl;
            b.clear();
        }
    }
}

