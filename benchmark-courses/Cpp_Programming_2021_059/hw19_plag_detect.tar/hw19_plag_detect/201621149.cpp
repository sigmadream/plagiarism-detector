#include <iostream>
#include <string>
#include <vector>
#include <cctype>

using namespace std;

class VoteBox
{
    vector<string> namelist;
    vector<int> namecount;

    vector<int> showing_n;
    int sz = 0;
    int max_num = 1;

public:
    VoteBox() {}
    void put(string word)
    {
        string up_word = uping(word);
        if (!check(up_word))
        {
            namelist.push_back(up_word);
            namecount.push_back(1);
            showing_n.push_back(0);
            sz++;
        }
    }
    bool check(string word)
    {
        for (int i = 0; i < sz; i++)
        {
            if (word == namelist[i])
            {
                if (max_num < ++namecount[i])
                    max_num = namecount[i];
                return true;
            }
        }
        return false;
    }
    string uping(string word)
    {
        string out_word = "";
        for (int i = 0; i < word.length(); i++)
        {
            if (islower(word[i]))
            {
                out_word += toupper(word[i]);
            }
            else
            {
                out_word += word[i];
            }
        }
        return out_word;
    }
    void show()
    {
        test();
        for (int i = 0; i < sz; i++)
        {
            for (int j = 0; j < sz; j++)
            {
                if (showing_n[j] == i)
                {
                    if (namecount[j] == max_num)
                        cout << namelist[j] << " " << max_num << endl;
                }
            }
        }
    }
    void test()
    {
        for (int i = 0; i < sz; i++)
        {
            for (int j = 0; j < sz; j++)
                if (namelist[i] > namelist[j])
                    showing_n[i]++;
        }
    }
};

int main()
{
    VoteBox MyBox;
    string in_word;
    do
    {
        cin >> in_word;
        MyBox.put(in_word);
    } while (getc(stdin) == ' ');
    MyBox.show();
}