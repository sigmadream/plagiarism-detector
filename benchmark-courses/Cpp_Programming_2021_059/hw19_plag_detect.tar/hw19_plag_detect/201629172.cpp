
#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <stack>
#include <vector>
#include <set>
#include <cstring>
#include <algorithm>
#include <cctype>


using namespace	std;

/*
 *  한줄씩 입력을 받아야함
 *  인풋값이 몇번 반복됬는지 파악해야
 *  그렇다면 어떤 자료형을 쓰는게 가장 편할까??
 *  같은 자료형이 있다면 기억해야하는데, map 이 편할지도 모른다 .
 *
 * 1. stack을 채운다
 * 2. stack의 원소들중에서 중복되는것들을 파악한다.
 * 3. 프린트한다??
 * 4. 문제가 뭐냐면, 중복인 문자열이 map에 들어오면, map에 계속해서 pair가 생기는 문제??
 * 5. duplicate 함수에서 반복문 돌릴때, 그 조건을 어떻게 하는게 좋을까??
 * 6. 연산면에서도 비효율적인 부분이 큰 것 같다.
 */

void		read_line(istream& cin, vector<string>& strs);
ostream&	print_elems(ostream& out, map<string, int> p);
map<string,int>	make_map(vector<string>& strs);
//map<int, string> change_map(map<string, int> m);
int mytoupper(int c)
{
if ((c >= 'a') && (c <= 'z'))
{
c = c - 'a' + 'A';
}
return c;
}

int		main()
{
	vector<int> cnts;
	vector<string> strs;
	read_line(cin, strs);
	print_elems(cout, make_map(strs)) << endl;
}

void		read_line(istream& cin, vector<string>& strs)
{
	string buf;
	getline(cin, buf);
	istringstream in(buf);
	string s;
	while (in >> s)
	{
		for(int i = 0; i < s.size(); i++)
		{
			s[i] = mytoupper(s[i]);
		}
		strs.push_back(s);
	}
}

// 반복문 돌릴때 통일해야할듯 .. 벡터쓸껀지 아니면 맵 쓸껀지 ...
// p는 주소값인가 ??
// 섞어 쓰면 안됨
// 1. map을 만든다 -> 중복되는 놈들때문에, 한번에 못만듬 -> 내가봤을땐, key, value값 다 만들어놓고 그다음에 map 만들어야 될것 같은데?
// 2.벡터에서 중복된것 빼고 아님 set 써도 되니까 중복을 제외한 종류가 몇개인지 파악한다
// 3. 이 종류만큼 2차원 배열을 만들어라-> 여기서 맵을 만들면 될듯 ㅎㅎㅎㅎ
// 4.첫번쨰 인덱스와 같다면, 두번째 인덱스에 +1 하면된다.

map<string,int>	make_map(vector<string>& strs)
{
	int i = 0;
	int j = 0;
	int jj = 0;
	int k = 0;
	int cnt = 0;
	int value = 0;
	vector<string>::iterator p;
	set<string>::iterator s;
	set<string> sets;
	map<string, int> dict;
	vector<string> temp;

	for (p = strs.begin(); p != strs.end(); ++p)
	{
		sets.insert(strs[i]);
		i++;
	}
	for (s=sets.begin(); s != sets.end() ; ++s)
	{
		temp.push_back(*s);
		j++;
	}

	while (jj < j)
	{
		cnt = 0;
		k = 0;
		for (p = strs.begin(); p != strs.end(); ++p)
		{
			if (temp[jj] == strs[k])
				++cnt;
			if (k != 6)
			    ++k;
		}
		dict.insert(pair<string, int>(temp[jj] , cnt));
		jj++;
	}
	return dict;

}

/*
map<int, string> change_map(map<string, int> m)
{
120         map<int, string> temp;
	map<int, string> temp;

	map<string, int>::iterator n;

	for (n = m.begin(); n != m.end() ; ++n)
	{
		temp.insert(pair<int, string>(n -> second, n -> first));
	}
	return temp;

}
*/

ostream&	print_elems(ostream& out, map<string, int> p)
{
	int num = 0;
	int cnt = 0;
	map<string, int>::iterator m;
	int temp = 0;
	for (m = p.begin(); m != p.end(); m++)
	{
		if (temp < m -> second)
		{
			temp = m -> second;
			num++;
		}

	}
	for (m = p.begin(); m != p.end(); m++)
	{
		if (m -> second == temp && m -> second != 0)
		{
			out << m -> first << " " << m -> second << ( cnt != num - 1 ? "" : "\n");
			cnt++;
		}
	}
	return out;
}
