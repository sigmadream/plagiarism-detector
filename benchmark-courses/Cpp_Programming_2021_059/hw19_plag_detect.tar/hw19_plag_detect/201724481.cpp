#include <cctype>
#include <bits/stdc++.h>
#include <map>
using namespace std;
const int BUF_SIZE = 100;

int main(){
	
	map<string, int> mapp;
	string buf, str1, str2;
	getline(cin, buf);
	istringstream in(buf);
	string s;
	
	while (in >> s){
		string str1 = s;
		for (int i=0; i < str1.size(); i++)
			str1[i]=tolower(str1[i]);
		s = str1;
		if(mapp.insert({s,1}).second==false)
			mapp[s]++;
	}
	
	typename map<string, int>::iterator p;
	p=mapp.begin();
	p++;
	int MAX = p->second, count=1;
	
	
	for (p; p!=mapp.end();p++)                    
		if (MAX < p->second){
			MAX = p->second;
			count = 0; //count�� �ʱ�ȭ(��ū���� ã�ƿԴ�) 
		}
		else if (MAX == p->second){
			count++;  //�Ȱ��� MAX���� ���� ���� 
		}

			
	for(p=mapp.begin(); p!=mapp.end(); p++)
		if(count==0){
			if (p->second == MAX){
				cout << p->first << " " << p->second << endl;
			}
		}
		else{
			if (p->second == MAX){
				string str2 = p->first;
				for (int i=0; i < str2.size(); i++)
					str2[i]=toupper(str2[i]); 
				cout << str2 << " " << p->second << endl;
			}
		}
}

