#include <bits/stdc++.h>
using namespace std;

void low_to_up(vector<string>& v){
        for(int i = 0; i < v.size(); i++){
            transform(v[i].begin(), v[i].end(),
            v[i].begin(), ::toupper);
        }
    }
map<string,int> ranking(vector<string>& v){
    int max;
    map<string, int> buf;
    map<string, int> rank_;
    for(int i = 0; i < v.size(); i++){
        buf[v[i]] = 1;
        for(int j = i+1; j < v.size();){
            if (v[i] == v[j]) {
                buf[v[i]] += 1;
                v.erase(v.begin() + j);
                }
            else { j++; }
        }
    }
    auto p = buf.begin();
    max = p->second;
    rank_[p->first] = p->second;
    for(p; p != buf.end(); p++){
        if(p->second == max){
            rank_[p->first] = p->second;
            max = p->second;
        }
        else if(p->second > max){
            rank_.clear();
            rank_[p->first] = p->second;
            max = p->second;
        }
    }
    return rank_;
}

int main(){
    vector<string> S;
    string k;
    map<string,int> RANK;
    while(cin >> k){
        S.push_back(k);
    }
    low_to_up(S);
    RANK = ranking(S);
    for(auto p = RANK.begin(); p != RANK.end(); p++){
        cout << p->first << " " << p->second << endl;
    }
    
}