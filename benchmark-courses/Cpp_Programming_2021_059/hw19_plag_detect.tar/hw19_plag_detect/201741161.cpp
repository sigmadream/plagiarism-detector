#include <bits/stdc++.h>
#define pp pair<string, int>

using namespace std;

int toupper(int c){
	if (c >= 'a' && c <= 'z')
		c = c - 'a' + 'A';
	return c;
}

bool cmp(const pp& a, const pp& b){
	if(a.second == b.second)
		return a.first < b.first;
	return a.second > b.second;
}

int main(){
	map<string, int> m;
	string line;
	getline(cin, line);
	for(int i = 0; i < line.length(); i++)
		line[i] = toupper(line[i]);
	istringstream in(line);
	string word;
	while(in >> word)
		m[word]++;
	vector<pp> vec(m.begin(), m.end());
	sort(vec.begin(), vec.end(), cmp);
	for(auto num : vec){
		if(vec[0].second != num.second)
			break;
		cout << num.first << ' ' << num.second << '\n';
	}
}

