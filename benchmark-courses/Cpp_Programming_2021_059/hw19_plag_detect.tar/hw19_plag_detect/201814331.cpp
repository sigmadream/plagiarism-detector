#include <cstdio>
#include <map>
#include <iostream>
#include <string>
using namespace std;

map<int, string> m;

bool cmp(const pp& a, const pp& b) {
	if (a.second == b.second) return a.first < b.first;
	return a.second < b.second;
}

/*class map {
	public :
			map (string word) {
				map<int, string> m;
				
				
				
				m.insert(pair<int, string>);			
			}
	private:

};*/


int main() {
	int i = 0, j, k = 0, step = 0;
	//String[] a = new String[1000];
	string a[1000];
	
	//while ( cin.getline(a, 1000) )
	while ( 1 )
	{
		cin >> a[i];
		
		/*if ( a[i] == '\n' )
			break;*/
		
		cout << a[i] << endl;
		
		i++;
		
		if ( i == 1000 )
			break;
	}

	int max = i;
	string b[i-1];
	string c[i-1];
	
	for ( i = 0; i <= max; i++ )
	{
		b[i] = a[i];
	}

	/*for ( i = 0; i <= max; i++ )
	{
		cout << b[i] << endl;
	}*/

	cout << "done!" << endl;

	vector<pp> vec( m.begin(), m.end() );
	sort(vec.begin(), vec.end(), cmp);
	
	
	//map std(a);
	
}
