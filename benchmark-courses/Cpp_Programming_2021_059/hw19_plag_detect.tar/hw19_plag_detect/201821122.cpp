#include<bits/stdc++.h>

using namespace std;

void read_line(istream &cin,vector<string>& stk);
void make_map_ranking(map<string,int>& smap,vector<string>& stk);
void Ranking(map<string,int> & samp);


int main()
{
    vector<string> str_vector;
    read_line(cin,str_vector);

    map<string, int> str_map;
    make_map_ranking(str_map,str_vector);

    Ranking(str_map);


       
}

void read_line(istream &cin,vector<string>&stk)
{
    string buf;
    getline(cin,buf);
    transform(buf.begin(),buf.end(),buf.begin(),(int (*)(int))toupper);
    istringstream in(buf);
    string s;

    while(in>>s) 
    {   
        stk.push_back(s);
    }
}

void make_map_ranking(map<string,int>& smap,vector<string>& stk)
{
    for(string i:stk)
    {
        if(smap.find(i)==smap.end())
        {
            smap[i]=1;
        }
        else
        {
            smap[i]=smap[i]+1;
        }
    }
}

void Ranking(map<string,int> & samp)
{
    int maxcount=0;
    map<string, int>::iterator p;
    for(p=samp.begin();p!=samp.end();++p)
    {
        if(p->second>maxcount) maxcount=p->second;
    }
    for(auto p:samp)
    {
        if(p.second==maxcount)
        {
            cout<<p.first<<" "<<p.second<<endl;
        }
        
    }

}