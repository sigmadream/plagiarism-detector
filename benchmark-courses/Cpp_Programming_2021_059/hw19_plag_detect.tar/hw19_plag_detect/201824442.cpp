#include <bits/stdc++.h>
using namespace std;

void upperchange(string &s)
{
	for(int i=0; i<s.length(); i++)
		if(islower(s.at(i)))
			s[i] -= 32;
}

int maxnumber(map<string, int> p)
{
	int maxnum = 0;
	for(map<string, int>::iterator a=p.begin(); a!=p.end(); a++)
		if((a->second) > maxnum)
			maxnum = a->second;
	return maxnum;
}

int main()
{
	map<string, int> word;
	string line;
	
	int count;
	while(cin >> line) {
		upperchange(line);
		if(word.empty() || word.find(line)==word.end())
			word[line] = 1;
		else
			word[line] += 1;
	}
	count = maxnumber(word);
	for(map<string, int>::iterator p = word.begin(); p != word.end(); p++)
		if((p->second) == count)
			cout << p->first << " " << p->second << endl;
}
