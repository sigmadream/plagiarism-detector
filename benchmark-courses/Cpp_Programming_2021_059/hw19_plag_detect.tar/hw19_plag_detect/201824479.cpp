#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;

class Favorite {
	vector<string> v;
	map<string, int> mm;
	int i, x, max;
public:
	Favorite() : i(0), x(0), max(1) {}
	void push(string str) {
		for (int j = 0; j < str.size(); j++) {
			str[j] = toupper(str[j]);
		}
		v.push_back(str);
		i++;
	}
	void mapping() {
		for (int j = 0; j < i;j++) {
			if (!(mm.count(v[j]))) {
				mm[v[j]] = 1; 
			}
			else {
				x = mm.find(v[j])->second;
				mm[v[j]] = ++x;
				if (x > max) 
					max = x;
			}
		}
	}
	void print() {
		for (auto p : mm) {
			if (p.second >= max)
				cout << p.first << " " << p.second << endl;
		}
	}
};

int main() {
	string s;
	Favorite f;
	while (cin >> s) {
		if (s == ".") 
			break;
		f.push(s);
	}
	f.mapping();
	f.print();
}


