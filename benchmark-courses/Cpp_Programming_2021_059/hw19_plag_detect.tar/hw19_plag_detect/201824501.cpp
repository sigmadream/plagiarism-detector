#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <set>
using namespace std;

int main(){
    vector<string> s1;
    string buf;
    getline(cin, buf);
    for(int i = 0; i < buf.size(); i++){
        buf[i] = toupper(buf[i]);
    }
    istringstream in(buf);
    for(string s; in >> s;){
        s1.push_back(s);
    }

    set<string> se;
    for(int i = 0; i < s1.size(); i++){
        se.insert(s1[i]);
    }

    map<string, int> vote;
    for(string str : se){
        vote.insert({ str, 0 });
    }

    for(int i = 0; i < s1.size(); i++){
        vote[s1[i]]++;
    }

    vector<string> win;
    int wini = 0;
    for(string str : se){
        if(wini <= vote[str]){
            if(wini < vote[str])
                win.clear();
            win.push_back(str);
            wini = vote[str];
        }
    }

    for(int i = 0; i < win.size(); i++){
        cout << win[i] << " " << wini << endl;
    }
}
