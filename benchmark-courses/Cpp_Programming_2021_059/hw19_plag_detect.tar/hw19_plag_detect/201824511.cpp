#include<iostream>
#include<string>
#include<sstream>
#include<map>
using namespace std;

class Ranking{
    string s;
    map<string,int> m;
public:
    Ranking(const string& _s = ""): s(_s){}
    void Get(){
        getline(cin,s);
    }
    void Capital(){
        int sz = s.size();
        for(int i = 0; i < sz; i++){
            s[i] = toupper(s[i]);
        }
    }
    void Make(){
        istringstream iss(s);
        string index;
        while(iss >> index){
            if(m.find(index) == m.end())
                m[index] = 1;
            else
                m[index]++;
        }
    }
    void TopPrint(){
        int max = 0;
        for(auto p = m.begin(); p != m.end(); ++p){
            if(p->second > max) 
                max = p->second;
        }
        for(auto p = m.begin(); p != m.end(); ++p){
            if(p->second == max)
                cout << p->first << " " << p->second << endl;
        }
    }
};

int main(){
    Ranking a;
    a.Get();
    a.Capital();
    a.Make();
    a.TopPrint();
}
