#include <bits/stdc++.h>
using namespace std;

int main(){
    int n=1;
    map<string, int> m;
    vector<string> v;
    string s,t;
    m.insert(pair<string,int>("=",0));
    map<string,int>::iterator p;
    while(cin >> s){
        for(char& a : s) a = toupper(a);
        p = m.find(s);
        if(p!=m.end()){
            p->second++;
        }
        else{
            m.insert(pair<string,int>(s,1));
        }
    }
    for(p = m.begin();p!=m.end();p++){
        if(p->second > n){
            v.clear();
            n = p->second;
            t = p->first;
        }
        if(p->second == n){
            v.push_back(p->first);
        }
    }
    if(v.size()==0)
        cout << t << " " << n << endl;
    else{
        for(int i = 0;i<v.size();i++)
            cout << v[i] << " " << n << endl;
    }
}