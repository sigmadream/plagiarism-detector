#include <iostream>
#include <sstream>
#include <string>
#include <algorithm>
#include <utility>
#include <map>
#include <cctype>

class CountSurvey
{
private:
	std::map<std::string, int> vote;

public:
	CountSurvey();
	~CountSurvey();
	void survey();
	void printResult();

};

int main()
{
	CountSurvey mySurvey;
	
	mySurvey.survey();
	mySurvey.printResult();

	return 0;
}

CountSurvey::CountSurvey()
{
}

CountSurvey::~CountSurvey()
{
}

void CountSurvey::survey()
{
	std::string inputLine;
	std::getline(std::cin, inputLine);
	std::istringstream buf(inputLine);
	std::string word;

	while (buf >> word)
	{
		std::transform(word.begin(), word.end(), word.begin(), (int(*)(int))std::toupper);
		if (vote.find(word) == vote.end())
		{
			vote.insert({ word,1 });
		}
		else
		{
			vote[word]++;
		}
	}
}

void CountSurvey::printResult()
{
	int maxVoted = 0;

	for (auto p = vote.begin(); p != vote.end(); p++)
	{
		maxVoted = std::max(maxVoted, p->second);
	}

	for (auto p = vote.begin(); p != vote.end(); p++)
	{
		if (p->second == maxVoted)
		{
			std::cout << p->first << " " << p->second << std::endl;
		}
	}
}