#include <bits/stdc++.h>
using namespace std;

string to_upper(string s) 
{
    string rev;
    for (char ch : s) {
        if (islower(ch)) {
            rev += toupper(ch);
        }
        else {
            rev += ch;
        }
    }
    return rev;
}

int main()
{
    map<string, int> m;

    string line;
    getline(cin,line);

    istringstream ins(line);

    string word;
    while (ins >> word) {
        string uword = to_upper(word);
        if (m.find(uword) == m.end()) {
            m[uword] = 1;
        }
        else {
            m[uword] += 1;
        }
    }

    queue<pair<string, int>> q;

    for (auto p: m) {
        if (q.empty()) {
            q.push(p);
            continue;
        }

        if (p.second > q.front().second) {
            while (!q.empty())
                q.pop();
            q.push(p);
        }
        else if (p.second == q.front().second) {
            q.push(p);
        }
    }

    while (!q.empty()) {
        pair<string, int> p = q.front();
        cout << p.first << " " << p.second << endl;   
        q.pop();
    }
}
