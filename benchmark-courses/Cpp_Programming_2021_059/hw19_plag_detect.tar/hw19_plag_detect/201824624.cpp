#include <iostream>
#include <sstream>
#include <string>
#include <queue>
#include <algorithm>
#include <numeric>
#include <map>
using namespace std;

void read_line(istream& cin, queue<string>& que) {
    string buf;
    getline(cin, buf);
    istringstream in(buf);
    string str;
    while(in >> str) {
        string masked;
        transform(str.begin(), str.end(), back_inserter(masked),
            [](char c) {
                return toupper(c);
            }
        );

        que.push(masked);
    }
}

map<string, int> mapping(queue<string> que) {
    map<string, int> ranking;
    map<string, int> ret;

    while(!que.empty()) {
        string str = que.front();
        ranking[str] += 1;
        que.pop();
    }

    int max = max_element(ranking.begin(), ranking.end(),
        [](const pair<string, int>& lhs, const pair<string, int>& rhs) {
            return lhs.second < rhs.second;
        }
    )->second;

    for(auto r: ranking) {
        if(max == r.second) {
            ret[r.first] = r.second;
        }
    }

    return ret;
}

int main() {
    queue<string> q;
    read_line(cin, q);

    map<string, int> rank;
    rank = mapping(q);

    for(auto r: rank) 
        cout << r.first << " " << r.second << endl;

    return 0;
}
