#include <bits/stdc++.h>
using namespace std;

void read_line(istream& in, list<string> &words) {
    string line;
    getline(in, line);

    istringstream ins(line);
    string s;
    while(ins >> s) {
        string t;
        transform(s.begin(), s.end(), back_inserter(t),
                [](char c) {return islower(c)? c+='A'-'a': c;});
        words.push_back(t);
    }
}

class Favorite: map<string, int> {
private:
    map<string, int> _tel;
public:
    Favorite(list<string> words) {
        for(string s: words) {
            if(!_tel[s]) {
                _tel[s] = 1;
            }
            else {
                _tel[s] += 1;
            }
        }
    }

    int numofmost() {
        int res = 0;
/*        for(map<string, int>::iterator p = _tel.begin();p != _tel.end();p++) {
            res = (p->second > res)? p->second: res;
        }*/
        for(auto m:_tel) {
            res = (m.second > res)? m.second: res;
        }
        return res;
    }

    void print_favorite(ostream& out) {
        for(auto m:_tel) {
            int max = numofmost();
            if(m.second == max)
                out << m.first << " " << m.second << endl;
        }
    }
};

int main() {
    list<string> words;
    read_line(cin, words);
    Favorite F(words);

    F.print_favorite(cout);
}