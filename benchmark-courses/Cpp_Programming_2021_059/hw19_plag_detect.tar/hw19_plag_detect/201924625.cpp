#include <bits/stdc++.h>
using namespace std;

// class Vote
// {
//     Vote(string _str = "", int n = 0) : str(_str), vote(n) {}

// private:
//     string str;
//     int vote;
// };

string caseUnsensitive(string s)
{
    for (char &c : s)
    {
        if ('a' <= c && c <= 'z')
        {
            c = c - 'a' + 'A';
        }
    }
    return s;
}

int main()
{
    // map<string, int> tel = {{"woo", 3518}, {"help", 2000}, {"phone", 1140}};
    // set<int> myset;
    map<string, int> votemap;
    string s;
    int maxval = 0;
    vector<string> v;
    while (cin >> s)
    {
        string ss = caseUnsensitive(s);
        votemap[ss]++;
        if (votemap[ss] > maxval)
        {
            maxval = votemap[ss];
            v.clear();
            v.push_back(ss);
        }
        else if (votemap[ss] == maxval)
        {
            v.push_back(ss);
        }
        else
        {
        }
    }
    for (string sss : v)
    {
        cout << sss << ' ' << maxval << endl;
    }
    // for (auto p : tel)
    //     cout << p.first << "\t" << p.second << endl;
    //  operator int() { return getNr(); }
}
//map