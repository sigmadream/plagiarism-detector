#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <map>
#include <sstream>

using namespace std;
class favorite{
    public:
    favorite(const vector<string> &vec){
        for(string str : vec){
            auto p = vote.insert({str,1});
            if(p.second==false){
                p.first->second++;
            }
        }
    }

    void printRanking(ostream &os){
        int max_value = 1; //가장 인기있는 값을 저장한다.
        for(auto p : vote){  //max_value 초기화
            if(p.second>max_value){
                max_value=p.second;
            }
        }
        
        for(auto p : vote){  //max_value에 해당되면 출력
            if(p.second == max_value){
                os<<p.first<<" "<<p.second<<endl;
            }
        }
    }

    private:
        map<string,int> vote;
};

int main(){
    string input;
    getline(cin,input);
    istringstream sst(input);
    string str;
    vector<string> vec;

    while(sst>>str){
        transform(str.begin(),str.end(),str.begin(),::toupper);
        vec.push_back(str);
        str.clear();
    }

    favorite F(vec);
    F.printRanking(cout);

}