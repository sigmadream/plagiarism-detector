#include <bits/stdc++.h>
using namespace std;

string lower_to_upper(string s)
{
    string upper;
    for(int i=0; i <s.size(); i++)
    {
        if(islower(s.at(i)))
            upper +=toupper(s.at(i));
        else
            upper += s.at(i);
    }
    return upper;
}

void count_votes(map<string, int> &votes)
{
    string candidate;
    while(cin >> candidate)
    {
        candidate = lower_to_upper(candidate);

        votes[candidate] +=1;
        /*if(votes.find(candidate) != votes.end())
            votes[candidate] +=1;
        else
            votes.insert(pair<string, int>(candidate, 1));*/
    }

}


int main()
{
    map<string, int> votes ={};
    count_votes(votes);

    int votes_num=0;

    for (auto p: votes)
    {
        if(p.second > votes_num)
            votes_num = p.second;
    }

    for (auto p: votes)
    {
        if(p.second == votes_num)
            cout << p.first << " " <<p.second<<endl;
    }

}
