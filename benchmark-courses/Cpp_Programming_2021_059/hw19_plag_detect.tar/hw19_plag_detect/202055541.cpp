#include<iostream>	
#include<vector>
#include<string>
#include<cstring>
#include<sstream>
#include<algorithm>
#include<map>
using namespace std;


bool cmp(pair<string, int> left, pair<string, int> right) {
	return left.second > right.second;
}



int main() {
	map<string, int> m;
	string str;
	vector<string> x;
	x.clear();
	vector <pair<string, int>> v;



	int i = 0;
	getline(cin, str);
	istringstream ss(str);
	string stringBuffer;
	while (getline(ss, stringBuffer, ' ')) {
		//cout << stringBuffer << endl;
		x.push_back(stringBuffer);
		transform(x[i].begin(), x[i].end(), x[i].begin(), ::toupper);
		i++;
	}




	int size = x.size()-1;


	for (int i = 0; i < size; i++) {
		int cou = count(x.begin(), x.end(), x[i]);
		//cout << "cou :" <<cou << endl;
		//cout << "x :" << x[i] << endl;
		if (cou > 1) {
			m.insert(pair<string, int>(x[i], cou));
			//cout << "x :" << x[i] << endl;
		}
	}

	copy(m.begin(), m.end(), back_inserter<vector<pair<string, int>>>(v));
	sort(v.begin(), v.end(), cmp);

	vector <pair<string, int>> ::iterator iter;
	iter = v.begin();
	int first = iter->second;
	for (iter = v.begin(); iter != v.end(); iter++) {
		if (first == iter->second) {
			cout << iter->first << " " << iter->second << endl;
		}
	}



	return 0;

}