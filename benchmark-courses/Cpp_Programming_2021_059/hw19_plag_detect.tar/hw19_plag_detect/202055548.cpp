#include <string>
#include <iostream>
using namespace std;

string upper(string str)
{
	int i = 0;
	while(str[i] != 0)
	{
		if(('a' <=str[i]) & (str[i] <= 'z'))
		{
			str[i] = str[i] + 'A' - 'a';
		}
		i += 1;
	}
	return str;
};

int main()
{
	char inp[1000] = {0,};
	int sz = sizeof inp/ sizeof * inp;
	string diction[1000];
	int dic_count[1000] = {0,};
	int dic_type_count = 0;
	string str1;

	cin.getline(inp, sz);
	int search = 0;
	int exter = 0;
	
	while(1)
	{
		while(1)
		{
			if(inp[search] == ' ')
			{
				search += 1;
				break;
			}
			if(inp[search] == 0)
			{
				exter = 1;
				break;
			}
			 str1.push_back(inp[search]);
			search += 1;
		}
		
		if(exter == 1)
		{
			break;
		}
		str1 = upper(str1);
		int found_on_dic = 0;
		int i = 0;
		while(i<dic_type_count)
		{
			if(str1.compare(diction[i]) == 0)
			{
				dic_count[i] += 1;
				found_on_dic = 1;
				break;
			}
			i += 1;
		}		
		if(found_on_dic == 0)
		{
			diction[dic_type_count] = str1;
			dic_count[dic_type_count] += 1;
			dic_type_count += 1;
		}
		str1.clear();
	}
	
	int i = 0;
	int max = 0;
	while(i<dic_type_count)
	{
		if(dic_count[i] > max)
		{
			max = dic_count[i];
		}
		i += 1;
	}
	
	i = 0;
	while(i<dic_type_count)
	{
		if(dic_count[i] == max)
		{
			cout<<diction[i]<<' '<<max<<'\n';
		}
		i += 1;
	}
	
}
