#include <iostream>
#include <string>
#include <map>

using namespace std;
int main()
{
 map<string, int> votes;
 string input;
 int max_num=0, num;
 while(cin >> input){
  for(int i=0;i<input.size();i++){
   input[i]=toupper(input[i]);
  }
  if(votes.count(input)){
   num=votes.find(input)->second+1;
   if(max_num<num)
    max_num=num;
   votes.find(input)->second=num;
  }
  else{
   if(max_num<1)
    max_num=1;
   votes.insert(make_pair(input,1));
  }
 }
 for (auto data: votes){
  if(data.second == max_num)
   cout << data.first << " " << data.second << endl;
 }
}
