#include<bits/stdc++.h>
using namespace std;

void read_line(istream& in, map<string,int> &votes);
ostream& find_max(ostream& out, map<string,int> &votes);
int main(){
    map<string,int> votes;
    read_line(cin, votes);
    find_max(cout,votes);
}
void read_line(istream& in, map<string,int> &votes){
    string buf;
    getline(cin, buf);
    istringstream sin(buf); 
    string s;
    map<string,int>::iterator m;
    while(sin >>s){
        transform(s.begin(), s.end(),s.begin(), ::toupper);
        if(votes.count(s)>0){
            m = votes.find(s);
            m->second +=1;
        }else
            votes.insert(make_pair(s,1));
    }
}
ostream& find_max(ostream& out,map<string,int> &votes){
    map<string, int> MaxVal;
    map<string, int>::iterator m = votes.begin();
    for(auto p = votes.begin(); p != votes.end(); ++p){
        if(p->second > m->second)
            m = p;
    }
    for(auto p = votes.begin(); p!=votes.end(); ++p){
        if(p->second == m->second)
            MaxVal.insert(make_pair(p->first, p->second));
    }
    for(auto p = MaxVal.begin(); p!=MaxVal.end(); ++p){
        out << p->first << " " << p->second << endl;
    }
    return out;
}
