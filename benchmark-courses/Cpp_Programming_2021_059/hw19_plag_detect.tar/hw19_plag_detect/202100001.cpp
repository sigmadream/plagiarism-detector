#include <bits/stdc++.h>
using namespace std;

class voteBox {
private:
    map<string, int> votes;
    list<string> tops;

public:
    void AddVote(string vote);
    void CalcTopVotes();
    void PrintTopVotes();

};

void voteBox::AddVote(string vote) {
    string bigVote;
    for (auto & c: vote)
        bigVote += toupper(c);
    map<string, int>::iterator iter;
    iter = votes.find(bigVote);
    if (iter != votes.end())
        votes[bigVote] = iter->second+1;
    else
        votes[bigVote] = 1;
}

void voteBox::CalcTopVotes() {
    int topNum = 0;
    for (auto v: votes) {
        if (v.second > topNum) {
            tops.clear();
            topNum = v.second;
            tops.push_back(v.first);
        } else if (v.second == topNum) {
            list<string>::iterator iter;
            iter = tops.begin();
            for (auto t: tops) {
                if (v.first > t) {
                    tops.insert(iter,v.first);
                    break;
                }
                iter++;
            }
        }
    }
    tops.reverse();
}

void voteBox::PrintTopVotes() {
    for (auto v: tops)
        cout << v << " " << votes[v] << endl;
}

int main()
{
    voteBox vbox;
    string vote;
    while (cin >> vote)
        vbox.AddVote(vote);
    vbox.CalcTopVotes();
    vbox.PrintTopVotes();
}