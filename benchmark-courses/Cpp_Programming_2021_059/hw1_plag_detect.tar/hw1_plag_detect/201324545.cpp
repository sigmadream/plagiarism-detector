#include <cstdio>

int get_int(){
    int B;
    printf("Enter B: ");
    scanf("%d", &B);
    return B;
}
int main(){
    int B =get_int();
    int Agripa =1;
    
    
    while(B>=Agripa){
        Agripa = Agripa*2;
    }
    printf(" Answer : %d\n", Agripa);
}

    
