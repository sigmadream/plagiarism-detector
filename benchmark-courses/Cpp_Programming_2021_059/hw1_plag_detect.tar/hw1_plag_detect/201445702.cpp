#include <cstdio>
#include <cmath>

int get_int() {
    int n = 0;
    scanf("%d", &n);
    return n;
}

int main() {
    int B = get_int();
    int k = -1;
    while (1) {
        ++k;
        int beforePow = pow(2, k);
        int afterPow = pow(2, k+1);

        if ( beforePow < B )
            if ( B < afterPow)
            {
                printf("%d\n", afterPow);
                break;
            }
            else {
                continue;
            }
            else {
                continue;
            }
    }
    
}
