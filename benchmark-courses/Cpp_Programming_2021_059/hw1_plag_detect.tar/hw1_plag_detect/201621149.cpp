#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>

int two_square()
{
    int n;
    int outnum = 2;
    scanf("%d", &n);
    while (outnum <= n)
    {
        outnum *= 2;
    }
    return outnum;
}

int main()
{
    printf("%d\n", two_square());
    return 0;
}
