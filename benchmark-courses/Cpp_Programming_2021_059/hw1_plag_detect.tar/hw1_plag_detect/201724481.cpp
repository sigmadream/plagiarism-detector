#include <stdio.h>

int B = scanf("%d",&B);

int theanswer()
{
	int a =1;
	while(a<B){
		a = a*2;
		

	}
	return a;
	
}
 
int main()
{
	
	int A = theanswer();
	printf("%d", A);
	return 0;
}
