#include <cstdio>

int main()
{
    int a, b;
    scanf("%d", &a);

    if (1<=a<=2)
        printf("2\n");
    else if (2<a<=4)
        printf("4\n");
    else if (4<a<=8)
        printf("8\n");
    else if (8<a<=16)
        printf("16\n");
    else if (16<a<=32)
        printf("32\n");
    else if (32<a<=64)
        printf("64\n");
    else if (64<a<=128)
        printf("128\n");
    else if (128<a<=256)
        printf("256\n");
    else if (256<a<=512)
        printf("512\n");
    else if (512<a<=1024)
        printf("1024\n");
    else if (1024<a<=2048)
        printf("2048\n");
    else if (2048<a<=4096)
        printf("4096\n");



}
