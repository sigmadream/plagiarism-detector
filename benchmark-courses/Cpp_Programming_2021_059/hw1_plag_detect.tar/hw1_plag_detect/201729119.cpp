#include <cstdio>

int main(){
	int B=0, bin = 1;
	
	scanf("%d", &B);
	
	if(B == 1) {printf("2"); return 0;}
	else {
		while(1){
			if(B+1>bin){
				bin = bin*2;
			}
			else break;
		}
	}
	printf("%d", bin);
}
