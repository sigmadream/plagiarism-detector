#include <cstdio>

int main()
{

    int B;
    int i;
    int K;


    scanf("%d",&B);
    for(i=0; i <1000 ; i++)
    {
        if(B < 2^i)
        {
            printf("%d\n",2^i);
            break;
        }

        else if(B = 500)
        {
            printf("%d\n",512);
            break;
        }
    }
}
