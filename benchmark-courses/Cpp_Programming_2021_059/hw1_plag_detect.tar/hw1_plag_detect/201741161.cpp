#include <cstdio>
#include <math.h>
int bigger_2pow(int a){
	int p = 0;
	while(a >= pow(2, p)){
		p++;
	}
	return pow(2, p);
}
int main()
{
	int x;
	scanf("%d", &x);
	printf("%d", bigger_2pow(x));
}
