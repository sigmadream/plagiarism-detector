#include <cstdio>
int main() {
	int b;
	scanf("%d", &b);
	long long ret = 1;
	while (ret <= b) {
		ret *= 2;
	}
	printf("%lld", ret);

}