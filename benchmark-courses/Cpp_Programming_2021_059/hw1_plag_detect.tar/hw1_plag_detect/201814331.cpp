//201814331 Haemin Lee 
#include <cstdio>

int get(int B)
{
	int n = 1;
	
	if(B < 31)
	{
		for(int i = 0; i < B; i++)
		{
			n = n *2;
		}		
	}
	else
	{
		n = 512;
	}

	
	return n;
}

int main()
{
	int B, result;
	
	scanf("%d", &B);
	
	result = get(B);
	
	printf("%d\n", result);
}
