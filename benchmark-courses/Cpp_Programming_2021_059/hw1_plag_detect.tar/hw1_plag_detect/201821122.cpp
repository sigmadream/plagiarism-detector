#include<cstdio>


int power_two(int n)
{
    int a=1;

    while(a<n||a==n)
    {
        a=a*2;
    }

    return a;
}

int main()
{

    int n;
    scanf("%d",&n);


    printf("%d",power_two(n));

    return 0;
}

