#include <cstdio>

int find_2(int num){
	int two=1;
	while (two<=num) {
		two*=2;
	}
	return two;
}

int main(){
	int input_num=0;
	scanf("%d", &input_num);
	int answer=find_2(input_num);
	printf("%d\n",answer);
}
