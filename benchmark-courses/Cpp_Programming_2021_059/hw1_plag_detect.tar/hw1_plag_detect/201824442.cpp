#include <cstdio>

int get_int()
{
	int n;
	scanf("%d", &n);
	return n;
}

int squ_2(int n)
{
	int i = 0;
	int ret_val = 1;
	while(i < n){
		ret_val *= 2;
		i++;
	}
	return ret_val;
}

int main()
{
	int a = get_int();
	int i = 0;
	while(squ_2(i) <= a){
		i++;
	}
	printf("%d\n", squ_2(i));
}
