#include <stdio.h>

int main()
{
	int a;
	scanf("%d", &a);
	int num=1;
	for(int i=1;i<10;i++)
	{
		if (num>a)
		{
		printf("%d",num);
		break;
		}
		else
		num*=2;
	}
	return 0;
}
