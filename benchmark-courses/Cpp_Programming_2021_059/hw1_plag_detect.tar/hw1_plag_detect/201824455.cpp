#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int i = 0;
	int n;
	int num=1;
	scanf("%d", &n);
	while(i<10){
		num= num*2;
		if(num>n){
			printf("%d\n",num);
			break;
		}
		
		i=i+1;
	}
	 
	 return 0;
}
