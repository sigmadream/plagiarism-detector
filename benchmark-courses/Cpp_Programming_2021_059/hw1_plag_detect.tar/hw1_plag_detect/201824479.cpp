#include <cstdio>

int get_int() {
	int n;
	scanf("%d", &n);
	return n;
}

int get_answer(int a) {
	int pow = 2;
	while (pow <= a) {
		pow = pow * 2;
	}
	return pow;
}

int main() {
	int a, b;
	a = get_int();
	b = get_answer(a);
	printf("%d\n",b);
}
