# include <cstdio>

int power_of_2(int input){

    int a=1;
    for(int i=0;i<input;i++){
        a=a*2;
    }
    return a;
}
int main(){

    int input, count;
    count=0;
    scanf("%d", &input);
    while(1){
        if(input<power_of_2(count)) break;
        else count=count+1;
    }
    printf("%d", power_of_2(count));

}
