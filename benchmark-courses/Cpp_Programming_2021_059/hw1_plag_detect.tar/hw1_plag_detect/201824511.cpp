#include<cstdio>

int get_int()
{
	int n;
	scanf("%d", &n);
	return n;
}

int main()
{
	int a= get_int();
	int i=1;
	while(a>=i){
		i*=2;
	}
	printf("%d",i);
}