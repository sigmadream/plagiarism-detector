#include <cstdio>

int get_int() {
   int n;
   scanf("%d", &n);
   return n;
}

int get_answer(int a) {
   int k = 2;
   while (k <= a) {
      k = k * 2;
   }
   return k;
}

int main() {
   int a, b;
   a = get_int();
   b = get_answer(a);
   printf("%d\n",b);
}
