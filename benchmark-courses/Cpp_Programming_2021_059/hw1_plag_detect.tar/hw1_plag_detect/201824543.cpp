#include <cstdio>

int least_squared_num()
{
    int n;
    scanf("%d", &n);

    int squared_num = 1;

    while (squared_num <= n)
    {
        squared_num *= 2;
    }

    return squared_num;
}

int main()
{
    int answer = least_squared_num();

    printf("%d\n", answer);
}
