#include <cstdio>

int main()
{
    int a;
    int b;
    int n=2^b;
    scanf("%d", &a);
    for(b=1;a<n;b++){
        return 0;
    }
    printf("%d\n",n);
}