#include <cstdio>

int power(int base, int exp)
{
    if (exp == 0){
        return 1;
    }
    int pow = 1;
    while (exp != 0)
    {
        pow *= base;
        exp -= 1;
    }
    return pow;
}

int get_int()
{
    int n;
    scanf("%d",&n);
    return n;
}

int upper(int n)
{
    int exp = 0;
    while (power(2,exp) <= n)
    {
        exp += 1;
    }

    return power(2,exp);
}

int main()
{
    int n = get_int();
    n = upper(n);
    printf("%d\n",n);
}