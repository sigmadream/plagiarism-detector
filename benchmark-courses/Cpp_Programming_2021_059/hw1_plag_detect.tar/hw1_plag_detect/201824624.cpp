#include <cstdio>

int get_int()
{
    int n = 0;
    scanf("%d", &n);
    return n;
}

int calculate_index(int a)
{
    int input_number = a;

    int i = 0;
    while(1)
    {
        if(input_number == 1)
            break;

        input_number = input_number / 2;
        i++;
    }

    return i;
}

int calculate_power(int a)
{
    int return_value = 1;

    int i = 0;
    while(1)
    {
        return_value = return_value*2;
        i++;

        if(i == a + 1)
            break;
    }

    return return_value;
}

int main()
{
    int input_value = get_int();
    int print_value = 0;
    
    if(input_value == 0) {
        print_value = 1;
    } else {
        int index = calculate_index(input_value);
        print_value = calculate_power(index);
    }

    printf("%d", print_value);

    return 0;
}