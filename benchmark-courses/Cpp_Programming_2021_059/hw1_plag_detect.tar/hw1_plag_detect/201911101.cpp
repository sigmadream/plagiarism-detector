#include <cstdio>

int get_int()
{
	int n;
	scanf("%d",&n);
	return n;
}

int main()
{
	int B = get_int();
	int n = 2;
	while(n<=B) {
		n*=2;
	}
	printf("%d",n);
}
