#include <cstdio>
#define mod 1000000007

using namespace std;
int b;
int finder(long long a)
{
	if(a > b){
		return a;
	}
    return finder(a*2);
}
int main()
{
    scanf("%d", &b);
    printf("%d",finder(1));
    return 0;
}
