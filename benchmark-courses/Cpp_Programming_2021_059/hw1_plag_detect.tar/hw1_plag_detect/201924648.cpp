#include <iostream>


int powerOfTwo(int n)
{
    int result = 1;

    while(1)
    {
        if(result>n)
        {
            break;
        }
        result *=2;
    }

    return result; 
}
int main()
{
    int n=0;
    std::cin>>n;
    std::cout<<powerOfTwo(n);
}