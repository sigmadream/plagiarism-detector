#include <cstdio>

void find_2squared(int num){
	int i = 2;
	while(i <= num)	i*=2;
	printf("%d", i);
}

int main(){
	int B = 0;
	scanf("%d", &B);
	
	find_2squared(B);
}
