#include <cstdio>

int get_int()
{
    int n;
    scanf("%d", &n);
    return n;
}

int get_two_square(int k)
{
    int i = 1;
    int two_square = 1;
    if (k ==0) return 1;
    while(i  <= k)
    {
    i++;
    two_square = two_square * 2;
    }
    return two_square;
}

int main()
 {
    int num = get_int();
    int k =0;
    while(get_two_square(k) < num)
    {
        k++;
    }

    printf("%d", get_two_square(k));
}
