#include <stdio.h>
#include <iostream>
#include <math.h>


int twice(int k) {
	return pow(2, k) ;
}



int main() {
	int k=1, B;
	scanf("%d" , &B);

	while (1) {
		if (twice(k) >= B) {
			break;
		}
		else {
			k = k + 1;
		}
	}
	printf( "%d" , twice(k));
}

