#include<cstdio>

int compare_and_grow(int minimum)
{
	int number = 1;
	while(number <= minimum)
	{
		number = number * 2;
	}
	return number;
};

int main()
{
	int minimum;
	int result;
	scanf("%d", &minimum);
	result = compare_and_grow(minimum);
	printf("%d", result);
}
