#include <cstdio>

int square_two() {
	int t = 1;
	int n ;
	scanf("%d", &n);
	for (t = 1; t <= n; t = t * 2);
	return t;
}

int main() {
	int a = square_two();
	printf("%d", a);
}