#include <cstdio>

int main(){
	int n;
	int power=1;
	scanf("%d", &n);
	while(1){
		power *= 2;
		if (power>n) break;
	}
	printf("%d", power);
}
