#include<cstdio>

int get_int()
{
    int n;
    scanf("%d",&n);
    return n;

}

int mult(int a){
    return a*2;
}

int main()
{
    int b = get_int();
    int init = 1;
    while(1){
        if(init > b)break;
        init = mult(init);
    }
    printf("%d",init);

}

