#include <cstdio>

int get_ans(int num){
    int ans=1;
    while(ans<=num){
        ans=ans*2;
    }
    return ans;
}

int main()
{
    int input_num, res;
    scanf("%d", &input_num);
    res=get_ans(input_num);
    printf("%d\n", res);
    return 0;
}
