#include <cstdio>

int get_int(){
    int x;
    scanf("%d",&x);
    return x;
}

int power_of_two(int p){
    int prod = 1;

    for(int i = 0; i < p ; i++){
        prod = prod *2;
    }
    return prod;
}

int main(){
    int b = get_int();
    int pwr = 0;
    for(int i = 0; 1 ; i++){
        pwr = power_of_two(i);
        if(pwr > b) break;
    }
    printf("%d",pwr);
    return 0;
}