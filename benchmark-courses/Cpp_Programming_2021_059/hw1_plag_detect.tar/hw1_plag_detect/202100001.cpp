#include<iostream>
#include<math.h>

using namespace std;

int MyPower(int n)
{
    return pow(2,n);
}
int main()
{
    int n;
    cin >> n;
    int res = 0;
    int k = 0;
    while(res <= n){
        res = MyPower(k);
        k++;
    }
    cout << res<<endl;

}
