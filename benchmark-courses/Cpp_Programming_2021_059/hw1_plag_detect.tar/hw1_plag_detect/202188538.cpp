#include<cstdio>

int get_int() {
	int n;
	scanf("%d", &n);
	return n;
}

int Powers(int K) {
	int mul = 1;
	while(mul <= K){
		mul *= 2;
	}
	return mul;
}
int main() {
	int B = get_int();
	int C = Powers(B);
	
	printf("%d", C);
}