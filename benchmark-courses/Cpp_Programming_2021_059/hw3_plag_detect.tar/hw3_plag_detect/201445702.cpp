//
//  main.cpp
//  reduce
//
//  Created by 강동기 on 2021/03/24.
//

#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>

class IntBag {
public:
    int x, y;
    
    void reduce(int n) {
        
    }
    
};

int main() {
    char n[100];
    scanf("%[^\n]s", n);
    int sz;
    char *sArr[100] = { NULL, };
    int i = 0;
    int sum;
    char *ptr = strtok(n, " ");
    std::vector<int> v;
    
    while (ptr != NULL)
    {
        sArr[i] = ptr;
        i++;
        ptr = strtok(NULL, " ");
    }
    
    
    for (int i = 0; i < 100; i++)
    {
        if (sArr[i] == NULL)
            sz = i;
    }
    
    for (int i = 0; i < sz; i++)
    {
        sum = (atoi(sArr[i-1]) + atoi(sArr[i])) % 100 ;
        v.push_back(sum);
    }
    
    
}
