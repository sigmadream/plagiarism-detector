#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>
#include <vector>

class IntBag
{
private:
	std::vector<int> _vec;
public:
	IntBag(std::vector<int>& b) {
		_vec = b;
	}
	int Reduce(int sz) {
		--sz;
		for (int i = 0; i < sz; i++) {
			_vec[i] += _vec[i + 1];
			_vec[i] %= 100;
		}
		return sz;
	}
	int returnvector() {
		return _vec[0];
	}
};


int main() {
	int n, sz = 0;
	std::vector<int> v;

	do {
		scanf("%d", &n);
		v.push_back(n);
		++sz;
	} while (getc(stdin) == ' ');

	IntBag mybag = IntBag(v);
	while (sz > 1) {
		sz = mybag.Reduce(sz);
	}

	printf("%d", mybag.returnvector());

}