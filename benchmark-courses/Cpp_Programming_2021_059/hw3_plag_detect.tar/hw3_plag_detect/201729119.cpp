#include <cstdio>
#include <vector>

using namespace std;

class IntBag
{
	public:
		vector<int> v;
};

int main(){
	
	int i, sz;
	int seq[1000]={-1};
	IntBag seq1;
	
	for(i=0;i<1000;i++){
		scanf("%d", &seq[i]);
		if(seq[i] == -1) break;
		seq1.v.push_back(seq[i]);
	}
	
	while(seq1.v.size() != 1){
	sz = seq1.v.size();
	for(i=0;i<sz-1;i++){
		seq1.v.at(i) = (seq1.v.at(i) + seq1.v.at(i+1))%100;
	}
	seq1.v.pop_back();
	
	}
	printf("%d", seq1.v.front());
}
