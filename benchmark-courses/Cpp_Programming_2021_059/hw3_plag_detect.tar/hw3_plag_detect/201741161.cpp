#include <cstdio>
#include <vector>

using namespace std;

class IntBag{
    vector<int> v;
    int arr[101];
public:
    IntBag(){
    	int i = 0, n = 0;
    	for(int k = 0; k < 101;k++)
    		arr[k] = 0;
        while (scanf("%d", &n) != EOF){
            arr[i] = n;
            i++;
        }
        i = 0;
        while(arr[i]){
            v.push_back(arr[i]);
            i++;
        }
    }
    void Reduce(){
        while(v.size() != 1){
            for(int j = 0; j < v.size() - 1; j++)
                v[j] = (v[j] + v[j + 1]) % 100;
            v.pop_back();
        }
        printf("%d", v[0]);
    }
};

int main()
{
    IntBag a;
    a.Reduce();
}
