#include <iostream>
#include <vector>
using namespace std;
class IntBag {
private:
	vector<int> item;
public:
	void reduce() {
		for (int i = 0; i < size() - 1; i++) {
			item[i] = (item[i] + item[i + 1]) % 100;
		}
		item.pop_back();
	}
	void push(int x) {
		item.push_back(x);
	}
	int size() {
		return item.size();
	}
	int getitem(int x) {
		return item[x];
	}
};
int main() {
	int x;
	IntBag Bag;

	while (cin >> x) {
		Bag.push(x);
	}

	while (Bag.size() > 1) {
		Bag.reduce();
	}
	cout << Bag.getitem(0);
}