//201814331 Haemin Lee
#include <cstdio>

int main()
{
	int i = 0, count;
	int num[1000];
	
	while(scanf("%d", &num[i]) == 1)
		i++;
	
	count = i;

	while(count >= 2)
	{
		for(i = 0; i < count; i++)
		{
			num[i] = num[i] + num[i+1];
			
			if (num[i] >= 100)
				num[i] = num[i] % 100;
			
			num[count] = 0;
		}
		count--;		
	}
	
	
	printf("%d", num[0]);
}

