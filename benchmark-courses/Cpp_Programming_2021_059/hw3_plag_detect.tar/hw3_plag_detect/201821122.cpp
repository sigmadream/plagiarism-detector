#include<cstdio>
#include<cstring>

#define INT_MAX 1000
#define LEN_MAX 200

int* getArray(int *arr,int sz);

int main()
{
    char str[LEN_MAX];
    int num_list[INT_MAX];

    int count=0,num=0,i;

    fgets(str,LEN_MAX,stdin);
    str[strlen(str)-1]='\0';

    for(i=0;count<INT_MAX &&str[i];i++){
        if(str[i]!=' '){

            num=num*10+str[i]-'0';

        }else{

        if(num>=0) {
            num_list[count++]=num;
            num=0;
            }

        }

    }
    if(num>=0) num_list[count++]=num;


    int* numarray=num_list;


    printf("%d",getArray(num_list,count)[0]);

}


int* getArray(int*arr,int sz)
{
    if (sz==1)
        return arr;

    int getArr[sz-1];

        for(int i=0;i<sz-1;i++)
        {

            getArr[i]=(arr[i]+arr[i+1])%100;
        }
    sz--;

    return getArray(getArr,sz);
}
