#include <cstdio>
#include <vector>

using namespace std;

long long int arr[1000]={0};

void IntBag(long long int *arr) {
	for (int i=0; i<1000 ; i++) {	
		if (arr[i+2] == 0) {
			arr[i]=(arr[i]+arr[i+1]) % 100;
			arr[i+1]=0;
			break;
		}
		else {
		arr[i]=(arr[i]+arr[i+1]) % 100;	
		}
	}
}

int main(){
	int i;
	
	for (i=0; i<1000; i++){
		scanf("%d", &arr[i]);
		if (arr[i]==0) break;
	}
	
	while (arr[1]!=0){
	IntBag(arr);
	}
	
	printf("%d\n", arr[0]);
}
