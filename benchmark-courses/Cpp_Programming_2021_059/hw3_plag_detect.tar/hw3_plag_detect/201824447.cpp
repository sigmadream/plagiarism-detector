#include <cstdio>

int main() {
	int n, i=0;
	int a[100];
	while(scanf("%d", &n)==1){
	a[i]=n;
	i++;
	}
	for(int k=0; k<i-1; k++)
	{
	for(int j=0; j<=i; j++)
		{
		a[j]+=a[j+1];
		}
	}	
	printf("%d", a[0]%100);
	return 0;
}

