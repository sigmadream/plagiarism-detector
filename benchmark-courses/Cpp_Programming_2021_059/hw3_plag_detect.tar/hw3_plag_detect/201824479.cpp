#include <cstdio>
#include <vector>
#define INT__MAX 1000
using namespace std;


int main() {
    int a[INT__MAX][INT__MAX],k=0,i=0;
    char ch[INT__MAX];
    
    vector<int> v;

    while (true) {
        scanf("%c",&ch[k]);
        if (ch[k++] == '\n')
            break;
    }
    for(int z= 0;z<k-1;z++) {
        int num = 0,isspace=0;
        while (ch[z] != ' ' && ch[z] != '\n') {
            isspace += 1;
            num *= 10;
            num +=(ch[z++]-'0');
        }
        if (isspace != 0)
            a[0][i++] = num;
    }
    
    for (int w =0; w < i-1;w++) {
        for (int z=0; z<i-1-w;z++) {
            a[w+1][z] = (a[w][z] + a[w][z+1]) % 100;
        }

    }
    printf("%d",a[i-1][0]);
}





// int main() {
//     int a[] = {1,2,3,4}, sz = sizeof a/ sizeof *a;
//     vector<int> v;
//     for (int n: a)
//         v.push_back(n);
//     for (int i = sz-1;i>=0;i--) 
//         printf("%d\n", v[i]);
// }