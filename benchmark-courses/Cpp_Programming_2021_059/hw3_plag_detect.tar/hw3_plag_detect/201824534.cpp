#include <cstdio>

const int INT_MAX = 1000;

int reduce(int *a,int sz){
    int k;
    for(k=0;k<sz-1;k++){ 
        a[k] = (a[k]+a[k+1])%100;
    }
    int s = k+1;
    if(s-1>1)
        reduce(a,s-1);
    return a[0];
}

int main() {
    int n,i=0;
    int a[INT_MAX];
    while(scanf("%d",&n)==1){
        a[i++] = n;
    }
    int sz = i;
    int r = reduce(a,sz);
    printf("%d", r);
}