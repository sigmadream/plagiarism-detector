#include <cstdio>
#include <vector>

class IntBag
{
private:
	std::vector<int> bag;

public:
	void input_nums();
	void reduce_bag();
	void print_output();
};

int main()
{
	IntBag myBag;
	myBag.input_nums();
	myBag.reduce_bag();
	myBag.print_output();

	return 0;
}

void IntBag::input_nums()
{
	int n;
	while (scanf("%d", &n) != EOF)
	{
		bag.push_back(n);
	}
}

void IntBag::reduce_bag()
{
	while (bag.size() > 1)
	{
		std::vector<int> tempBag = bag;
		for (int i = 0; i < bag.size() - 1; i++)
		{
			tempBag[i] = (tempBag[i] + bag[i + 1]) % 100;
		}
		tempBag.pop_back();
		bag = tempBag;
	}
}

void IntBag::print_output()
{
	printf("%d", bag[0]);
}