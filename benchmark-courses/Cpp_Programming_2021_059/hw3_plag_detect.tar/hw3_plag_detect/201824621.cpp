#include <cstdio>
#include <vector>
using namespace std;

class IntBag{
private:
    vector<int> array;
public:
    int mod = 100;
    IntBag(vector<int> arr)
    {
        this->array = arr;
    }
    void Reduce()
    {
        int n = this->array.size();
        if (n > 1)
        {
            while (n > 1)
            {
                for(int i =0; i < n-1; i++)
                {
                    this->array[i] = (this->array[i] + this->array[i+1]) % this->mod;
                }
                this->array.pop_back();
                n--;
            }
        }
    }
    void Print()
    {
        if (this->array.size() == 1)
        {
            printf("%d", this->array[0]);
        }
    }
};

int main()
{
    vector<int> n;
    int t;
    while(scanf("%d",&t) == 1)
    {
        n.push_back(t);
    }
    IntBag *bag = new IntBag(n);
    bag->Reduce();
    bag->Print();
}