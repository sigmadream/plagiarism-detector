#include <cstdio>
#include <vector>
using namespace std;

class IntBag {
    private: 
        vector <int> nums;
    public:
        void Initializing(int *arr, int sz) {
            for (int i = 0; i < sz; i++)
                nums.push_back(arr[i]);
        }

        void Reduce() {
            int sz = nums.size();

            while(sz) {
                if(sz == 0)
                    break;
                for (int i = 0; i < sz - 1; i++){
                    nums[i] = (nums[i] + nums[i+1]) % 100;
                }
                sz--;
                nums.pop_back();
            }
        }

        void Printing() {
            printf("%d", nums[0]);
        }
};

int main()
{
    int a[1000];
    int num, i = 0;

    while(scanf("%d", &num) == 1){
        a[i++] = num;
    }

    IntBag Res;
    Res.Initializing(a, i);
    Res.Reduce();
    Res.Printing();

    return 0;
}
