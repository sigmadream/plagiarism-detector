#include <iostream>
#include <vector>
using namespace std;
 
int main() {
   vector<int>v;
   int a;
   int i = 0;
   while(cin>>a){
       v.push_back(a);
      if(cin.get()=='\n'){
         break;
      }
      
      i++;
   }
   
   for (int j = 0;j<i;j++){
      for(int k = 0;k < i-j;k++){
         v[k] = (v[k] + v[k+1])%100;
      
      }
      if(v.size()>1)
      v.pop_back();
   }
   for (int j = 0;j<v.size();j++){
   cout<<v[j]<<" ";
   }
   return 0;
}