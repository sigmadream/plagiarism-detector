#include <cstdio>
#include <vector>

int INT_MAX = 1000;

void sum(int *n, int i) {
    n[i] = (n[i] + n[i+1])%100;
}

int main() {
    int a[INT_MAX] = {0,};
    int i = 0, n=0;
    while (scanf("%d", &n) == 1) {
        a[i] = n;
        i++; 
    }
    int max=i;
    int num[max];

    for(i=max-1;i>=0;i--) {
        num[i] = a[i];
    }
    for(i=max-1;i>0;i--) {
        for(int j=0;j<i;j++) sum(num, j);
    }

    printf("%d", num[0]);
    
}