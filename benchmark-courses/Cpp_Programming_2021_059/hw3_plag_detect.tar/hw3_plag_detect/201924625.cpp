#include <cstdio>
#include <vector>

class IntBag {
	private:
		std::vector<int> v;
	public:
		/*
		Point() {
			x = y = 0; 
		}
		*/
		int size() {
			return v.size();  
		}
		void Reduce () {
			for (int i = 0; i < size() - 1; i++) {
				v[i] = ( v[i] + v[i + 1] ) % 100;
			}
			v.pop_back();
		}
		void Print() {
			printf("%d",v[0]);
		}
		void Push(int a) {
			v.push_back(a);
		}
};

int main() {
	//int a[] = {1, 2, 3, 4}, sz = sizeof a/sizeof *a;
	//std::vector<int> v;
	int a;
	IntBag *intBag = new IntBag();
	while (scanf("%d", &a) == 1)
		intBag -> Push(a);
	while (intBag -> size() != 1) {
		intBag -> Reduce();
	}
	intBag -> Print();
	return 0;
}
