#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
using namespace std;

class IntBag
{
    public:
        IntBag(const string &str){
            string temp="";
            for(auto i:str)
            {
                if(i>='0' && i<='9')
                {
                    temp+=i;
                }
                else{
                     vec.push_back(stoi(temp));
                     temp.clear();
                }
               
            }
        }
        
        void print()
        {
            for(int i:vec)
            {
                cout<<i<<" ";
            }
        }

        void Reduce()
        {
            while(vec.size()>1)
            {
                 int len = vec.size();
                 
                  for(int i=0;i<len-1;i++)
                  {
                     int a = vec[i];
                     int b = vec[i+1];
                     vec[i]= (a+b) % 100;
                  }
                  vec.pop_back();
            }
        }

    private:
        vector<int> vec;

};

int main()
{
    string num;
    getline(cin,num);
    IntBag mybag(num+" ");
    
    mybag.Reduce();
    mybag.print();

    
}