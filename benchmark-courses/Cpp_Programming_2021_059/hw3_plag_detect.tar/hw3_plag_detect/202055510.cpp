#include <cstdio>
#include <vector>

class IntBag{
	private:
		std::vector<int> v;
		
	public:
		IntBag(int arr[1000], int i){
			for(int idx = 0; idx < i; idx++)	v.push_back(arr[idx]);
		}
		void Reduce(){
			while(v.size() != 1){
				for(int i = 0; i < v.size()-1; i++){
					v[i] = (v[i] + v[i+1]) % 100;
				}
				v.pop_back();
			}
			printf("%d\n", v[0]);
		}	
};

int main(){
	int arr[1000];
	int i = 0;
	while(scanf("%d", &arr[i]) == 1)	i++;
	
	IntBag b(arr, i);
	b.Reduce();
}
