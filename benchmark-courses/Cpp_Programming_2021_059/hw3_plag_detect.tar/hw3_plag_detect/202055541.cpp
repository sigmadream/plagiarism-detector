#include <cstdio>

int mod(int a, int b ) {
	return (a + b) % 100;
}



int main() {

	int x, num[1000], i = 0;
	while (scanf("%d", &x) != EOF) {
		num[i++] = x;
	}

	while (1) {
		if (i == 1) {
			printf("%d", num[0]);
			break;
		}
		else {
			for (int k = 0; k < i; k++) {
				num[k] = mod(num[k], num[k + 1]);
			}
		}
		i = i - 1;
	}

	return 0;

}


