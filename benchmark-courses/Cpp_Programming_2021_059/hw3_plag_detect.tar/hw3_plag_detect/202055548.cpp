#include <cstdio>


int main()
{
	int input;
	int number[1000];
	
	int i = 0;
	int j = 0;
	
	while (scanf("%d", &input) == 1) 
	{
		number[i] = input;
		i++;		
	}
	
	int number_of_input = i;
	int number_of_remain = i;
	i = 0;
	
	while(number[1] != 0)
	{
		while(i < number_of_input)
		{	
			number[i] = (number[i] + number[i+1])%100;
			i++;
			if(i == number_of_remain)
			{
				number[i-1] = 0;
				number_of_remain--;
			}
		}
		i = 0;		
	}
	
	printf("%d", number[0]);
}



