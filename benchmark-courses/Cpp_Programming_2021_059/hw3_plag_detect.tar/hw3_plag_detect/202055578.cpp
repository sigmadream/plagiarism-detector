#include <cstdio>
#include <vector>
const int MAX = 1000;
using namespace std;


class IntBag{
    private:
        
    public:
        int Reduce(int n){
            if ( n >= 100){
                n = n%100;
            }
            return n;
            
        }

};

int main(){
    IntBag p;
    int n = 0, i = 0;
    int a[] ={0};
   
    while (scanf("%d", &n)==1) {
        a[i++] = n;  
        if (n >= MAX) break;
    }
    int sz = sizeof a / sizeof *a;
 
    while ( i > 0){
        for (int l = 0 ; l < i ; l++){
            a[l] = a[l] + a[l+1];
            if (a[l] >= 100){
                a[l] = a[l] % 100;
            }
        }
        i--;
    }

    printf("%d",a[0]);
}