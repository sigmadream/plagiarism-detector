#include <cstdio>

#define MAX 50
#define LENGTH 128

int main(){
	char str[LENGTH];
	int num_list[MAX];
	
	int count = 0, num =0, sz = 0, i, tmp;
	
	gets(str);
	
	for (i = 0; count <MAX &&str[i]; i++){
		if (str[i] != ' '){
			num = num*10 + str[i] - '0';
		}
		else{
			if(num > 0){
				num_list[count++] = num;
				num = 0;
			}
		}
	}
	if (num > 0) num_list[count++] = num;
	
	while(count==0){
		for (i=0; i<=count-1; i++){
			
			num_list[i]=(num_list[i]+num_list[i+1])%100;
			
		}
		count--;
	}
	printf("%d", num_list[0]);
		
}

