#include <stdlib.h>
#include <cstdio>
#include <vector>
#include <iostream>
#include <ctime>

using namespace std;


int * getRandom(int a[] ) {
    int i = 0;
    for(i = 0;a[i] != -1;i++){
        a[i] = (a[i]+a[i+1])%100;
        //printf("%d\n",a[i]);
    }
    a[i-1] = -1;

   return a;
}
int main() {
    //int a[], sz = sizeof a/sizeof *a;
    int *p;

   //p = getRandom(a,sz);

   //for ( int i = 0; i < sz; i++ ) {
   //   cout << *(p + i) << endl;
   //}

   int numbs;
   int a[100];
   int counter = 0;
   while(scanf("%d",&numbs)!= EOF){
        a[counter] = numbs;
        counter++;
   }
   a[counter] = -1;
   for(int j = 0;j<counter-1;j++) p = getRandom(a);



   for ( int i = 0; *(p + i)  != -1; i++ ) {
      cout << *(p + i) << endl;
   }
}

