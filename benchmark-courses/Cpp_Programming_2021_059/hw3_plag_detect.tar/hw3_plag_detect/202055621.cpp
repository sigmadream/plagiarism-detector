#include <cstdio>
#include <vector>

struct IntBag{
private:
    std::vector<int> _v, new_v;
public:
    void Input(int n){
        _v.push_back(n);
    }
    void Print(){
        for(int i=0;i<_v.size();i++)
            printf("%d ",_v[i]);
    }
    void Act(){
        for(int i=0;i<_v.size()-1;i++){
            new_v.push_back((_v[i]+_v[i+1])%100);
        }
        _v=new_v;
        new_v.clear();
    }
    void Work(){
        while(_v.size()!=1)
            Act();
    }
};
int main(){
    IntBag v;
    int n;
    while(scanf("%d",&n)==1)
        v.Input(n);
    v.Work();
    v.Print();
}
