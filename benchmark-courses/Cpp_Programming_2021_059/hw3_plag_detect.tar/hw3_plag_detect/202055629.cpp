#include <cstdio>
#include <vector>
using namespace std;
class intBag {
private:
    vector<int> v;
public:
    int Reduce(){
        if(v.size() == 1)
            return v[0] % 100;
        else{
            int size = v.size();
            while(size > 1)
            {
                for(int i = 0; i< size -1; i++){
                    v[i] = (v[i]+v[i+1]) % 100;
                }
                v.pop_back();
                size--;
            }
            return v[0] % 100;
        }
    
    }
    void get_num(int n){
        v.push_back(n);
    }
};
int main () {
    intBag *my = new intBag();
    int n;
    while(scanf("%d" , &n) == 1)
        my->get_num(n);
    printf("%d", my->Reduce());
    return 0;
}