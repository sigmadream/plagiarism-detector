#include <cstdio>
#include <vector>

using namespace std;

class IntBag {
private:
    vector<int> v;
public:
    void addElement(int n) {
        v.push_back(n);
    }

    int reduce(vector<int> v) {
        vector<int> tmpV;
        if (v.size() != 1)
        {
            int flag = 0;
            while(flag < v.size()-1) {
                tmpV.push_back((v[flag]+v[flag+1]) % 100);
                flag++;
            }
        }else{
            return v[0] % 100;
        }
        return reduce(tmpV);
    }

    void printReduce() {
        printf("%d\n", reduce(v));
    }
};
int main()
{
    int n = 0;
    IntBag myVector;
    while (scanf("%d",&n) == 1){
        myVector.addElement(n);
    }
    // myVector.printV();
    myVector.printReduce();
}