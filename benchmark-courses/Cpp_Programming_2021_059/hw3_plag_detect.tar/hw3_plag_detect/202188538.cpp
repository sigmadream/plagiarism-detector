#include<cstdio>
#include<vector>
using namespace std;

class IntBag{
private:
    vector<int> v;
public:
    IntBag(vector<int> exam){
        v = exam; 
    }
    vector<int> Reduce(){
        int i=0;
        vector<int> j;

        while(1){
            if((i+1) == v.size()) break;
            int mod = (v[i]+v[i+1])%100;
            j.push_back(mod);  
            i++;  
        }

        return j;        
    }
};

void ReturnInt(vector<int> exam){
    if(exam.size() == 1){
        printf("%d", exam[0]);
    }
    else{
        IntBag A(exam);
        vector<int> b = A.Reduce();
        ReturnInt(b);
    }
};

int main(){
    vector<int> v;
    int num;

    while(1){
        int input = scanf("%d",&num);
        if(input == EOF) break;
        v.push_back(num);
    }

    ReturnInt(v);

    return 0;
}