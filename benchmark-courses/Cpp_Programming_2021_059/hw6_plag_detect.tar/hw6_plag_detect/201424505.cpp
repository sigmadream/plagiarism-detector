#include<cstdio>

int gcd(int a, int b){
    int tmp, n;

//a에 큰 값을 위치시키기 위한 조건문입니다.
    if(a<b){
        tmp = a;
        a = b;
        b = tmp;
    }
    while(b!=0){
        n = a%b;
        a = b;
        b = n;
    }
    return a;
}

 int main()
 {
 int a, b, res;
 scanf("%d %d", &a, &b);


 res = gcd(a, b);
 printf("%d %d",a+b,res);
 //printf("%d",res);

 }
