//
//  main.cpp
//  sng
//
//  Created by 강동기 on 2021/04/07.
//

#include <iostream>

using namespace std;

class Nat {
    int a;
public:
    Nat(int n) {
        a = n;
    }
    Nat operator += (Nat &m) {
        a += m.a;
        return *this;
    }
    
    int ival() {
        return a;
    }
};

ostream& operator << (ostream &out, Nat &n) {
    return out << n.ival();
}

int main() {
    int a, b;
    cin >> a >> b; // 여기까지가 입력부분
    Nat n(a), m(b); // 클래스 호출
    n += m; // << 가 호출될때, 해당 연산자가 있으면 해당 함수를 오버로딩 한다..?
    m = (b-a);
    cout << n << " " << m << endl;
}

// 흐으으으음........
