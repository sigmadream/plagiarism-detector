#include <iostream>
using namespace std;

class Nat {
	int a;
public:
	Nat(int n) {
		a = n;
	}
	Nat operator +(Nat &m) {
		a += m.a;
		return *this;
	}
	Nat operator ^(Nat &m) {
		a = gcd(a, m.a);
		return *this;
	}
	int ival() {
		return a;
	}
	int gcd(int x, int y) {
		if (x < y) {
			int c = x;
			x = y;
			y = c;
		}
		if (x % y == 0) {
			return y;
		}
		return gcd(x % y, y);
	}
};

ostream& operator <<(ostream& out, Nat& n) {
	return out << n.ival();
}

int main() {
	int a, b;
	cin >> a >> b;
	Nat n(a), m(b);
	Nat sum = n + m;
	Nat gcd = n ^ m;
	cout << sum << " " << gcd << endl;
}
