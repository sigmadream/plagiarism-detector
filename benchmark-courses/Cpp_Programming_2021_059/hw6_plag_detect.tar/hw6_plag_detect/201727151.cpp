#include <iostream>
#include <ostream>

using namespace std;

class Nat{
    int a;
public:
    Nat() {
        
    }
    Nat(int n) {
        a = n;
    }
    
    int ival() {
        return a;
    }
};

istream& operator >>(istream& in, Nat& n) {
    int k;
    in >> k;
    n = Nat(k);
    return in;
}

ostream &operator << (ostream &out, Nat n) {
    return out << n.ival();
}

Nat operator + (Nat& a, Nat& b) {
    Nat *ans = new Nat(a.ival() + b.ival());
    return *ans;
}

Nat operator ^ (Nat &a, Nat &b){
    int i = a.ival(), j = b.ival();
    while(j != 0) {
        int k = i % j;
        i = j;
        j = k;
    }
    Nat *ans = new Nat(i);
    return *ans;
}

int main(void) {
    Nat n, m;
    cin >> n >> m;
    cout << n + m << " " << (n ^ m);
    return 0;
}