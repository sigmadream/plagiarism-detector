#include <cstdio>
#include <iostream>

using namespace std;
class Nat {
int a;
public:
	Nat(int n) {
		a=n;
	}
	Nat operator + (Nat &m){
		a += m.a;
		return *this;
	}
	Nat operator ^ (Nat &m){
		int gcd;
		for(int i = 1; i <= this->a|| i <= m.a; i++){

		if((this->a%i)==0 & (m.a%i)==0){
			gcd = i;
		}
		if((this->a<i)||(m.a<i)) {
			break;
		}
		}
		return gcd;
	}
	int ival(){
		return a;
	}
};

ostream& operator << (ostream &out, Nat &n){
	return out << n.ival();
}

int main(){
	int a, b;
	cin >> a >> b;
	Nat n(a), m(b);
	Nat gcd = n^m;
	Nat plus = n+m;
	cout <<plus << " " << gcd << endl;
	
	return 0;
}
