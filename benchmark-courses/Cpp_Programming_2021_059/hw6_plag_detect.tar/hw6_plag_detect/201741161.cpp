#include <iostream>

using namespace std;

class Nat{
    int a;
public:
    Nat(int n): a(n) {}
    Nat operator +=(Nat &m) {
        a += m.a;
        return *this;
    }
    int ival() {
        return a;
    }
    friend istream& operator>>(istream& in, Nat &n){
        in >> n.a;
        return in;
    }
    friend ostream& operator <<(ostream &out, Nat &n) {
        return out << n.ival();
    }
    friend int operator+(Nat a, Nat b){
        return a.a + b.a;
    }
    Nat gcd(Nat m){
        if(m.a == 0) return *this;
        Nat v(m.a); return v.gcd(a % m.a);
    }
};


int main()
{
    Nat c(0), d(0);
    cin >> c >> d;
    cout << c + d << " ";
    printf("%d", c.gcd(d));
}