#include <iostream>
using namespace std;
int gcd(int x, int y) {
	if (y == 0) return x;
	return gcd(y, x%y);
}
class Nat {
	int a;
public:
	Nat() {
		a = 0;
	}
	Nat(int n) {
		a = n;
	}
	Nat operator +(Nat &m) {
		a += m.a;
		return *this;
	}
	Nat operator ^(Nat &m) {
		a = gcd(a, m.a);
		return *this;
	}
	int ival() {
		return a;
	}
	friend istream& operator>> (istream &is, Nat &m);
};
istream& operator>> (istream &is, Nat &m) {
	return is >> m.a;
}
ostream& operator<< (ostream &os, Nat m) {
	return os << m.ival();
}
int main() {

	Nat n, m;

	cin >> n >> m;

	cout << (n + m) << " " << (n ^ m) << "\n";
}