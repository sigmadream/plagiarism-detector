//201814331 Haemin Lee
#include<cstdio>
#include <iostream>
using namespace std;

class Nat
{
    int a;

public:
    Nat(int n) {
        a = n;
    }
    Nat mulup(Nat &m) {
        return *this;
    }
    int ival() {
       return a;
    }
};

/*istream& operator >> (istream& in, Nat &n) {
	return in >> n.ival();
}*/

int add(int a, int b)
{
	return a + b;
}

int gcd(int a, int b)
{
    if(b == 0)
		return a;
    else
		return gcd(b, a%b);
}


int main(void)
{
    int a, b;
    
    scanf("%d %d", &a, &b);
    
    Nat m(a);
    Nat n(b);
    m.mulup(m);
    n.mulup(n);

    int n1 = m.ival();
    int n2 = n.ival();

    printf("%d %d", add(n1, n2), gcd(n1, n2));
    
}
