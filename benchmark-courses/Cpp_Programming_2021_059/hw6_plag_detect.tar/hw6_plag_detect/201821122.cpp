#include<iostream>

using namespace std;

class Nat
{
private:
    int a;
public:
    Nat(int n):a(n)
    {}
    int ShowNumber()
    {
        return a;
    }
    friend Nat operator+(const Nat&,const Nat&);
    friend Nat operator^(const Nat&,const Nat&);
    friend istream& operator>>(istream& in,Nat &n);
};

Nat operator+(const Nat& num1,const Nat& num2)
{
    Nat num3(num1.a+num2.a);
    return num3;
}
Nat operator^(const Nat& num1,const Nat& num2)
{
    if (num2.a==0) return num1;
    else
    {Nat num3(num1.a%num2.a);
     return num2^(num3);}

}

istream& operator >>(istream& in,Nat &n)
{
    in>>n.a;
    return in;
}

int main(void)
{
    int a,b;
    cin>>a>>b;
    Nat pos1(a);
    Nat pos2(b);

    cout<<(pos1+pos2).ShowNumber()<<' '<<(pos1^pos2).ShowNumber()<<endl;

    return 0;

}
