#include <iostream>
using namespace std;

class Nat {
	int a;
public :
	Nat(int n) {
		a = n;
	}
	Nat operator +=(Nat &m) {
		a += m.a;
		return *this;
	}
	
	Nat gcd(Nat &m) {
		int tmp = a % m.a;
		if (tmp == 0) return *this;
		else {
			Nat n(m.a), k(tmp);
			return n.gcd(k);
			}
		}
	
	int ival() {
		return a;
	}
};


ostream& operator <<(ostream &out, Nat &n) {
	return out << n.ival();
}

int main()
{
	int a, b, tmp, sum, gcd;
	cin >> a >> b;
	if (a < b) {
		tmp = a;
		a = b;
		b = tmp;
	}
	Nat n(a), m(b);
	sum = n.ival() + m.ival();
	n.gcd(m);
	gcd = n.ival();
	
	cout << sum << " " << gcd << endl;
}
