#include <iostream>
using namespace std;

class Nat {
private:
	int a;
public:
	Nat (int n) {
		a = n;
	}
	Nat operator +(Nat m) {
		a = a + m.a;
		return *this;
	}
	Nat operator ^(Nat m) {
		if (m.a == 0)
			return *this;
        Nat n(m.a);
		return n^(a % m.a);
	}
	int ival() {
		return a;
	}
	
};

istream& operator >> (istream& in, Nat &n) {
	int a;
	in >> a;
	Nat temp(a);
	n = temp;
	return in;
}
	
ostream& operator << (ostream &out, Nat &n) {
	return out << n.ival();
}

int main()
{
	Nat n(0), m(0);
	cin >> m >> n;
	Nat sum(m+n), gcd(m^n);
	cout << sum << " " << gcd << endl;
}
