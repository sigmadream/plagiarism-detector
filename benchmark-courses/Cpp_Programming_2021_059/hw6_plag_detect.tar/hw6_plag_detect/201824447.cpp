#include <cstdio>

int main(){
	int a, b, sum;
	scanf("%d %d", &a, &b);
	sum=a+b;
	int gcd=0;
	for(int i=1;i<=a;i++){
		if (a%i==0 && b%i==0)
		gcd=i;
	}
	printf("%d %d",sum,gcd);
	return 0;
}
