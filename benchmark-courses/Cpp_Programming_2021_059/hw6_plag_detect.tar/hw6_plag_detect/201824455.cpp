#include <cstdio>

int main(){
	int a,b;
	scanf("%d",&a);
	scanf("%d",&b);
	int x,y,i;
	x = a+b;
	
	for(i=1; i<=a; i++){
		if (a%i==0 && b%i==0){
			y=i;	
		} 
	}
	printf("%d %d",x,y);
	return 0;
}
