#include <iostream>
using namespace std;

class Nat {
    int a,b;
public: 
    Nat(int n) {
        a = n;
        b = 0;
    }
    // Nat operator +=(Nat &m) {
    //     a += m.a;
    //     return *this;
    // }
    Nat operator +(Nat &c) {
        b = a + c.a;
        return *this;
    }
    Nat operator ^(Nat &c) {
        int temp;
        if (a >= c.a) temp = c.a;
        else temp = a;
        for (int i =temp; i >= 1; i--) {
            if ((a %i ==0) && (c.a % i == 0)) {
                b = i;
                break;
            }
        }
        return *this;
    }
    int ival() {
        return b;
    }
};

// istream& operator >>(istream &in, Nat &n) {
//     int a;
//     in >> a;
//     n.a = a;
//     return *this;
// }

ostream& operator <<(ostream &out, Nat &n) {
    return out << n.ival();
}

int main()
{
    int a, b;
    cin >> a >> b;
    Nat n(a), m(b);
    // j = n + m;
    // cout << j << " " << k << endl;
    n + m;
    m ^ n;
    // m += n;
    cout << n << " " << m << endl;
}