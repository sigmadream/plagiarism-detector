#include <iostream>
using namespace std;

class Nat{

public:
	int a;
    Nat(int n) : a(n){}

    Nat operator+(Nat p){
    Nat R( a + p.a );
    return R;
    }
    Nat operator^(Nat m){
        if (m.a == 0) return *this;
        Nat n(m.a); return n.operator^(a % m.a);
    }
    int ival(){
        return a;
    }

};

ostream& operator <<(ostream &out, Nat &n){
	return out << n.ival();
}
istream &operator >>(istream &in, Nat &n){
	in >> n.a;
	return in;
}


int main(){
    int a,b;
    Nat n(a), m(b);
    cin >> m >> n;
    Nat sum = n + m;
    Nat gcd = n ^ m;

    cout << sum << ' ' << gcd <<endl;
}
