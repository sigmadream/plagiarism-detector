#include <iostream>
using namespace std;

class Nat{
    int a;
public:
    Nat(int n) : a(n){}

    Nat operator+(Nat p){
    Nat R( a + p.a );
    return R;
    }

    Nat operator^(Nat m){
        if (m.a == 0) return *this;
        Nat n(m.a); return n.operator^(a % m.a);
    }
    
    int ival(){
        return a;
    }

};

int main(){
    int a,b;
    cin >> a >> b;
    Nat n(a), m(b);
    Nat sum = n + m;
    Nat gcd = n ^ m;

    cout << sum.ival() << ' ' << gcd.ival() <<endl;
}
