#include <iostream>
using namespace std;

class Nat{
    int a;
public:
    Nat(int n) {
        a = n;
    }
    Nat operator +(Nat m){
        a = a + m.a;
        return *this;
    }
    Nat operator ^(Nat m){
        if (m.a == 0) return *this;
        Nat n(m.a); return m^(a % m.a);
    }
    int val(){
        return a;
    }
};

ostream& operator <<(ostream &out, Nat n){
    return out << n.val();
}

int main(){
    int a,b;
    cin >> a >> b;
    Nat n(a),m(b);
    Nat k = n + m;
    Nat q = n ^ m;
    cout << k.val() << " " << q.val();
}