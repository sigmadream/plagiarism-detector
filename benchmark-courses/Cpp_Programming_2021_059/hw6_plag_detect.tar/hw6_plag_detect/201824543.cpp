#include <iostream>

class Nat {
private:
	int a;

public:
	Nat(int n = 0);
	void modifyMember(int n);
	Nat operator+=(Nat& m);
	int ival();
};

int gcd(int a, int b);
std::istream& operator>>(std::istream& in, Nat& n);
std::ostream& operator<<(std::ostream& out, Nat& n);
Nat operator+(Nat a, Nat b);
Nat operator^(Nat a, Nat b);

////////// main //////////
//////////////////////////

int main()
{
	Nat a, b;
	std::cin >> a >> b;
	Nat c = a + b;
	Nat d = a ^ b;
	std::cout << c << " " << d << std::endl;

	return 0;
}

//////////////////////////
//////////////////////////

Nat::Nat(int n) : a(n)
{
}

void Nat::modifyMember(int n)
{
	a = n;
}

Nat Nat::operator+=(Nat& m)
{
	a += m.a;
	return *this;
}

int Nat::ival()
{
	return a;
}

int gcd(int a, int b)
{
	if (b == 0)
	{
		return a;
	}
	else
	{
		return gcd(b, a % b);
	}
}

std::istream& operator>>(std::istream& in, Nat& n)
{
	int temp;
	in >> temp;
	n.modifyMember(temp);

	return in;
}

std::ostream& operator<<(std::ostream& out, Nat& n)
{
	return out << n.ival();
}

Nat operator+(Nat a, Nat b)
{
	Nat ret(a.ival() + b.ival());
	return ret;
}

Nat operator^(Nat a, Nat b)
{
	Nat ret(gcd(a.ival(), b.ival()));
	return ret;
}