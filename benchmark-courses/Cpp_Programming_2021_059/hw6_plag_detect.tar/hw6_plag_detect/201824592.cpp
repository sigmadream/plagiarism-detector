#include <cstdio>
#include <iostream>
using namespace std;

class Nat {
   int b,a;
public:
   Nat(int n){
      a = n;
   }
   Nat operator += (Nat &m){
      a += m.a;
      return *this;
   }
   Nat gcd(Nat m){
      if(m.a == 0) return *this;
      Nat n(m.a); return n.gcd(a%m.a);
   }
   int ival(){
      return a;
   }
};

ostream& operator <<(ostream & out, Nat n) {
   return out << n.ival();
}

int main() {
   int a, b, c;
   cin >> a >> b;
   c = a + b;
   Nat l(a), m(b), n(c);
   cout << n << " " << l.gcd(m) << endl;

}