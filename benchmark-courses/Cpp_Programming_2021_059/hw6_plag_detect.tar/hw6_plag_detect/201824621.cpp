#include <iostream>
using namespace std;

class Nat {
    int a;
public:
    Nat (int n) {
        a = n;
    }
    Nat operator +=(Nat &m) {
        a += m.a;
        return *this;
    }

    // Nat operator+ (const Nat &a, const Nat &b);

    Nat operator +(Nat b) {
        Nat res(a + b.ival());
        return res;
    }

    Nat operator ^(Nat b) {
        Nat n(a);
        while (b.ival() != 0) {
            Nat t(n.ival() % b.ival());
            n = b;
            b = t;
        }
        return n;
    }
    
    void setval(int n) {
        a = n;
    }

    int ival() {
        return a;
    }
};

istream& operator >> (istream & in, Nat &n) {
    int t;
    in >> t;
    n.setval(t);
    return in;
}

ostream& operator << (ostream &out, Nat &n) {
    return out << n.ival();
}

int main()
{
    Nat a(0),b(0);
    cin >> a >> b;
    Nat gcd = a ^ b;
    Nat sum = a + b;
    cout << sum << " " << gcd;
}