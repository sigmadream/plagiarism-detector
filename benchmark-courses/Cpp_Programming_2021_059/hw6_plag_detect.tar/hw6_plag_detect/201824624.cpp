#include <iostream>
using namespace std;

class Nat {
    int a;
    public: 
        Nat (int n) { a = n; }
        Nat operator +=(Nat &m) {
            a += m.a;
            return *this;
        }
        int ival() {
            return a;
        }

        Nat gcd(Nat m) {
            if(m.a == 0) return *this;
            Nat n(m.a); return n.gcd(a % m.a);
        }
};

ostream& operator << (ostream &out, Nat &n) {
    return out << n.ival();
}

int main() {
    int a, b;
    cin >> a >> b;
    Nat n(a), m(b), sum(a);
    sum += m;
    cout << sum.ival() << " " << m.gcd(n).ival() << endl;
}
