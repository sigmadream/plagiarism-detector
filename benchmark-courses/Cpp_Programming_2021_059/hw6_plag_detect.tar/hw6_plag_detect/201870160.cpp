#include <iostream>
using namespace std; 

class Nat {
	int a, b;


	Nat operator += (Nat &n) {
		n = a+b;
		return *this;
	}
	Nat operator *= (Nat &m){
		m *= a*b;
		return *this;
	}
	int ival() {
		a = a+b;
	}
};

ostream& operator << (ostream &out, Nat &n) {
	return out << n.ival ();
}


int main()
{
	int a, b;
	cin >> a >> b;
	Nat n(a), m(b);

	out <<m << "+" << n << "=" <<m.val() + n.val<< endl;  
	out <<m << "+" << n << "=" <<m + n<< endl;
}
