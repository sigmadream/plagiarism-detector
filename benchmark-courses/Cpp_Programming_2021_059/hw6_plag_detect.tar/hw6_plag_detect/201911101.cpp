#include <iostream>
using namespace std;

class Nat {
private:
    int a;
public:
    Nat(int n) {
        a = n;
    }
    
    Nat operator +=(const Nat &m) {
        a += m.a;
        return *this;
    }

    Nat operator *=(const Nat &m) {
        a *= m.a;
        return *this;
    }
/*
    istream& operator >>(istream &in, Nat &n) {
        Nat m(in); n = m;
        return *this
    }
*/
    int ival() {
        return a;
    }
};

Nat operator +(Nat &n, Nat &m) {
    Nat k(n.ival()+m.ival());
    return k;
}

Nat operator *(Nat &n, Nat &m) {
    Nat k(n.ival()*m.ival());
    return k;
}

Nat operator ^(Nat n, Nat m) {
    if (n.ival()<m.ival()) return m^n;
    else if (m.ival() == 1) return m;
    else if (m.ival() == 0) return n;
    else{
        Nat k(n.ival() % m.ival());
        return m^k;
    }
}

ostream& operator <<(ostream &out, Nat &n) {
    return out << n.ival();
}

int main() {
    int a, b;
    cin >> a >> b;
    Nat n(a), m(b);
    Nat sum = n+m, gcd = n^m; 
    cout << sum << " " << gcd << endl;
}