#include <iostream>

using namespace std;

class Nat
{
    int a;
    public:
Nat(int n)
{
   a=n;
}
Nat operator +=(Nat &m)
{
    a += m.a;
    return *this;
}

 int ival()const 
{
    return a;
}
friend istream& operator>>(istream& in,Nat &n);
};
ostream& operator<<(ostream & out, const Nat &n)
{
    return out << n.ival();
}
istream& operator>>(istream& in,Nat &n)
{
   return in>>n.a;
}
Nat operator%(Nat a,Nat b)
{
    return Nat(a.ival()%b.ival());
}
bool operator<(Nat a,Nat b)
{
    return a.ival()<b.ival();
}
Nat operator+(Nat a, Nat b)
{
    return Nat(a.ival()+b.ival());
}
 Nat operator^(Nat a, Nat b)
{
    if (a<b) swap(a,b);
    if(b.ival()==0) return a;
    return (b^(a%b));
}
int main()
{
    Nat a(0);
    Nat b(0);
    cin>>a>>b;
    
   
    cout<<(a+b)<<" "<<(a^b);
   
    
}
