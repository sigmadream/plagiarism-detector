#include <iostream>
using namespace std;

class Nat {
	int n;
		
	public:
		int chk_val(){
			return n;
		}
		void get_val(int k){
			n = k;
		}
};

istream& operator >> (istream &in, Nat &n){
	int t;
	in >> t;
	n.get_val(t);
	return in;
}

ostream& operator <<(ostream &out, Nat &n){
	return out << n.chk_val();
}

Nat operator +(Nat a, Nat b){
	Nat t;
	t.get_val(a.chk_val() + b.chk_val());
	return t;
}

Nat operator ^(Nat a, Nat b){
	Nat t;
	if(b.chk_val() == 0){
		t.get_val(a.chk_val());
		return t;
	}
	else{
		int tmp = a.chk_val() % b.chk_val();
		a.get_val(b.chk_val());
		b.get_val(tmp);
		return a^b;
	}
}

int main(){
	Nat a, b;
	cin >> a >> b;
	
	Nat c = a+b;
	Nat d = a^b;
	cout << c << " " << d;
}
