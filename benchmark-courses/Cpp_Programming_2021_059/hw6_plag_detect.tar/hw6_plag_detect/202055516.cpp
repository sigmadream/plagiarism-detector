# include <iostream>
using namespace std;

 class Nat {
    int a, b;
public:
    Nat(int n) {
        a = n;
    }

    int ival() {
        return a;
    }

};

ostream& operator <<(ostream &out, Nat &n) {
    return out << n.ival();
}

Nat operator +(Nat &a, Nat &b) {
        return a+b;
    }

Nat operator ^(Nat m, Nat n) {
    if(m.ival() < n.ival()) {
        Nat l = m;
        m = n;
        n = l;
    }
    if (n.ival() == 0) {
        return m;
    }
    Nat l = m;
    m = n;
    n = l.ival() % m.ival();
    return operator ^(m, n);
 }
int main()
{
    int a, b;
    cin >> a >> b;
    Nat n(a), m(b);
    Nat k = a^b;
    cout << a+b << " " << k<<endl;
}
