#include <iostream>
using namespace std;

int gcd(int a, int b) {

	int gcdNum = 0;

	for (int i = 1; i <= a; i++) {
		if (a % i == 0 && b % i == 0) {
			gcdNum = i;
		}
	}
	return gcdNum;

}

class Nat {
	int a;
public:
	Nat(int n) {
		a = n;

	}
	Nat operator +=(Nat& m) {
		a += m.a;
		return *this;

	}
	int ival() {
		return a;

	}

};

ostream& operator <<(ostream& out, Nat& n) {
	return out << n.ival();

}

int main()
{
	int a, b;
	cin >> a >> b;
	Nat n(a), m(b);
	n += m;
	m += n;

	int gcd1=gcd(a, b);

	cout << n << " " << gcd1 << endl;
}
