#include <iostream>
using namespace std;
const int MAX = 10000;


class Nat{
	int a ;
	public:
		Nat (int n){
			a = n;
		}
		int ival(){
			return a;
		}
		
};

	Nat operator +(Nat a , Nat b){
			
			return  a.ival()+b.ival() ;
		}
		
	Nat operator ^(Nat a , Nat b){
		int tmp, n;
		if(a.ival()<b.ival()){
			tmp = a.ival();
		    a = b.ival();
		    b = tmp;
		}
		while(b.ival()!=0){
		    n = a.ival()%b.ival();
		    a = b.ival();
		    b = n;
		}
    return a.ival();
		}
		
	int gcd(int a, int b){
    
	    if(b == 0){
	        return a;
	    }else{
	        return gcd(b, a%b);
	    }
}


ostream& operator << (ostream & out, Nat n ){
	return out << n.ival();
}
//istream& operator >> (istream& in , Nat & n){
//	return  in >> n.ival();
//}



int main(){
	int a , b = 0 ;
	cin >> a >> b ;
	Nat n(a),m(b);
	cout << m + n << " " <<  gcd(n.ival(), m.ival()) << endl;

	
}
