#include <iostream>
 using namespace std;

 class Nat {
 int a;
 public:
 Nat(int n) {
 a = n;
 }
 Nat operator +=(Nat &m) {
 a += m.a;
 return *this;
 }
 int ival() {
 return a;
 }
 };
 
 int gcd(int x, int y){
 	if(y==0){
 		return x;
	}
	else {
		return gcd(y, x%y);
	}
 }

 ostream& operator <<(ostream &out, Nat &n) {
 return out << n.ival();
 }

 int main()
 {
 int a, b;
 cin >> a >> b;
 Nat n(a), m(b);
 n += m;
 cout << n << " " << gcd(a, b) << endl;
 
 }

