#include <iostream>
using namespace std;

class Nat {
 int a;
 public:
 Nat(int n) {
 a = n;
 }
 int ival() {
 return a;
 }
 };

Nat operator +(Nat &n, Nat &m){
    int a= n.ival();
    int b = m.ival();
    return a+b;
}
Nat operator ^(Nat &n, Nat &m){
    int a = n.ival();
    int b = m.ival();
    int temp;
    int n3;
    if(a<b){
        temp = a;
        a = b;
        b = temp;
    }

    while(b!=0){
        n3 = a%b;
        a = b;
        b = n3;
    }
    return a;
}

ostream& operator <<(ostream &out, Nat &n) {
    return out << n.ival();
}
//istream& operator >>(istream& in, Nat &n){
//    in >> n;
//    return in;
//}

int main() {

    int a,b;
    cin >> a >> b;
    Nat n(a);
    Nat m(b);
    Nat sum(n+m);
    Nat gcd(n^m);
    cout << sum << " " << gcd << endl;

}
