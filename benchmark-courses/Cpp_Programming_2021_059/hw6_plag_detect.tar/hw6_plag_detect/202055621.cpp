#include <iostream>
using namespace std;

class Nat{
    int a;
public:
    Nat(int n){
        a=n;
    }
    Nat operator +=(Nat &m){
        a+= m.a;
        return *this;
    }

    int Ival(){
        return a;
    }
};
Nat operator +(Nat &a, Nat &b){
    return a.Ival()+b.Ival();
}
Nat operator ^(Nat &a, Nat &b){
    while(a.Ival() && b.Ival()){
        a.Ival() >= b.Ival() ? a=a.Ival()%b.Ival() : b=b.Ival()%a.Ival();
    }
    return a.Ival() ? a : b;
}

ostream& operator <<(ostream &out, Nat &n){
    return out << n.Ival();
}
int main(){
    int a, b;
    cin >> a >> b;
    Nat m(a), n(b);
    Nat res1 = m+n;
    Nat res2 = m^n;
    cout << res1 << " " << res2 << endl;
}
