#include<iostream>

using namespace std;

class Nat
{
    int a;
public:
    Nat(int n): a(n) {};
    int ival() const { return a; } //
    Nat mulup(const int &n) {
        Nat m(a*n);
        return m;
    }
    void setA(int n) {
        a = n;
    }
};

Nat operator +(const Nat n, const Nat m) {
    Nat k(n.ival()+m.ival()); //
    return k;
}


Nat operator ^(Nat m, Nat n) {
    if(n.ival() == 0)
        return m;
    Nat tmpN(m.ival()%n.ival());
    return n^tmpN;
}

ostream& operator <<(ostream &out, Nat &n) {
    return out << n.ival();
}

istream& operator >> (istream& in, Nat &n) {
    int a = 0;
    in >> a;
    n.setA(a);
    return in;
}
int main()
{
    Nat m(0),n(0);
    cin >> m >> n;
    Nat s = m+n;
    cout << s << " ";
    Nat gcd = m^n;
    cout << gcd << endl;
}
