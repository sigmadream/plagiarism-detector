#include<iostream>
using namespace std;

class Nat{
private:
    int num;    
public:
    Nat(int a){
        num = a;
    }

    int val(){
        return num;
    }

    Nat gcd(Nat m){
        if(m.num == 0) return *this;
        Nat n(m.num); return n.gcd(num % m.num);
    }

    Nat operator + (Nat b){
        num = num + b.num;
        return *this;
    }

    Nat operator ^ (Nat b){
        return gcd(b);
    }

};

ostream& operator << (ostream &out, Nat &n) {
    return out << n.val();
}


int main(){
    int num1, num2;

    cin >> num1 >> num2;
    Nat A(num1);
    Nat B(num2);

    Nat C = A+B;
    Nat D = A^B;

    cout << C << " " << D << endl;

    return 0;
}