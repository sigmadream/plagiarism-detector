#include <iostream>
#include <string>
using namespace std;

class point;
{
    int _x, _y;
public:
    point(int x=0, int y=0): _x(X), _y(y) {}
    int x() { return _x; }
    int x(int n) { return_x = n; }
    int y() { return _y; }
    int y(int n) { return_y = n; }
};

class NamedPoint: public Point
{
    string _name;
public:
    NamedPoint(string name="", int x=0, int y=0): _name(name), point(x, y) {}
    string name() { return_name; }
    string name(string newname) { return _name = newname; }
};

ostream& operator <<(ostream& out, NamePoint p) {
    return out << p.name() << "(" << p.x() << ", " << p.y() << ")";
}

int main()
{
    NamedPoint q("Q", 3, 4);
    cout << q << endl;
}