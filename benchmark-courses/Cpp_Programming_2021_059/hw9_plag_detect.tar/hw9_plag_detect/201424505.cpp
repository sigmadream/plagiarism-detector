#include<stdio.h>

int main(void)
{
 int i,j, a, b;


 scanf("%d %d",&a,&b);

printf("+");
 for (i = 1; i <= a; i++)
 {
  printf("-");
 }
 printf("+");
 printf("\n");
 for (i = 1; i <= b ; i++)
 {
  printf("|");
  for (j = 1; j <= a ; j++)
  {
   printf(" ");
  }
  printf("|\n");//우변
 }
 printf("+");
 for (i = 1; i <= a; i++)
 {
  printf("-");//아랫변
 }
 printf("+");
 return 0;
}
