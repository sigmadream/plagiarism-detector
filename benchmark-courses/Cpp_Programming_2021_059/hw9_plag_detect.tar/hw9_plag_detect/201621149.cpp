#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Point
{
    int _x, _y;

public:
    Point(int x = 0, int y = 0) : _x(x), _y(y) {}
    int x() { return _x; }
    int x(int n) { return _x = n; }
    int y() { return _y; }
    int y(int n) { return _y = n; }
};

class Board : public Point
{
    int sz_x = 0;
    int sz_y = 0;

public:
    Board(int x = 0, int y = 0) : sz_x(x), sz_y(y) { Point(0, 0); }
    void move(int n)
    {
        if (n % 2 == 0)
            x(x() + 1);
        else
            y(y() + 1);
    }
    void mark()
    {
        int x = this->x();
        int y = this->y();

        string mystring = "+";

        for (int i = 0; i < sz_x; i++)
            mystring += "-";
        cout << mystring << "+\n";
        for (int j = 0; j < sz_y; j++)
        {
            string mymystring = "|";
            for (int i = 0; i < sz_x; i++)
            {
                if (i + 1 == x && j + 1 == y)
                    mymystring += ".";
                else
                    mymystring += " ";
            }
            cout << mymystring << "|\n";
        }
        cout << mystring << "+\n";
    }
};

class NamedPoint : public Point
{
    string _name;

public:
    NamedPoint(string name = "", int x = 0, int y = 0) : _name(name), Point(x, y) {}
    string name() { return _name; }
    string name(string newname) { return _name = newname; }
};

ostream &operator<<(ostream &out, NamedPoint p)
{
    return out << p.name() << "(" << p.x() << "," << p.y() << ")";
}

int main()
{
    int a, b;
    cin >> a >> b;
    Board myboard = Board(a, b);
    int n = 0;
    do
    {
        cin >> n;
        myboard.move(n);
    } while (getc(stdin) == ' ');
    myboard.mark();
}