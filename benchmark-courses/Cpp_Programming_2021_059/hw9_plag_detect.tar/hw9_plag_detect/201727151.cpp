#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Point {
    int _x, _y;
public:
    Point(int x=0, int y=0): _x(x), _y(y) {}
    int x() { return _x; }
    int x(int n){return _x=n;}
    int y() { return _y; }
    int y(int n){return _y=n;}
};
class MovingPoint: public Point
{
public:
    MovingPoint(int x=0, int y=0): Point(x, y) {}
    void move(int a) {
        if (a % 2 == 0) x(x() + 1);
        else y(y() + 1);
    }
};

class Board: public vector<vector<int>>
{
    int _w, _h;
    Point _p;
public:
    Board(int w=0, int h=0): _w(w), _h(h) {}
    void mark(int x, int y){
        _p = Point(x, y);
    }
    void display() {
        for (int i = 0; i <= _h + 1; i++) {
            for (int j = 0; j <= _w + 1; j++) {
                if (i == 0 && j == 0) cout << "+";
                else if (i == 0 && j == _w + 1) cout << "+";
                else if (i == _h + 1 && j == 0) cout << "+";
                else if (i == _h + 1 && j == _w + 1) cout << "+";
                else if (i == 0 || i == _h + 1) cout << "-";
                else if (j == 0 || j == _w + 1) cout << "|";
                else if (i == _p.y() && j == _p.x()) cout << ".";
                else cout << " ";
            }
            cout << endl;
        }
    }
};

int n = 0;
int W, H;
string input;
MovingPoint p(0, 0);

int main() {
    cin >> W >> H;
    cin.ignore();
    getline(cin, input);
    for (char c: input) {
        if (c != ' ') n = n * 10 + (c - '0');
        else {
            p.move(n);
            n = 0;
        }
    }
    p.move(n);
    Board b = Board(W, H);
    b.mark(p.x(), p.y());
    b.display();
}

