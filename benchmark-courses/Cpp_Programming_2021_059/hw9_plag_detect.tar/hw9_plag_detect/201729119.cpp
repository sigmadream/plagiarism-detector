#include <cstdio>
#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;

class Point{
	int _x, _y;
	public:
		Point(int x, int y) {_x = x; _y = y;}
		int x() { return _x; }
 		int x(int n) { return _x = n; }
 		int y() { return _y; }
		int y(int n) { return _y = n; }
		
		void print_line(int w, int h){
			int j = 1;
			int i = 0;
			cout << "+";
			while(i < w){
				cout << "-";
				i++;
			}
			cout << "+" << endl;
			while(j <= h){
			if(j == _y){
				cout << "|" << setw(_x) << "." << setw(w-_x+1) << "|" << endl;
			}
			else cout << "|" << setw(w+1) << "|" << endl;
			j++;
			}
			i = 0;
			cout << "+";
			while(i < w){
				cout << "-";
				i++;
			}
			cout << "+" << endl;
		}
		void print(){
			cout << _x;
		}
};

class MovingPoint: public Point{
	public:
		MovingPoint(vector<int> a, int x_=0, int y_=0): Point(x_,y_){
			for(int i = 0; i < a.size();i++){
				if (a[i]%2 == 0) x_ += 1;
				else y_ += 1;
			}
			x(x_);
			y(y_);
		}
};

int main(){
	int w, h;
	int k;
	vector<int> pp;
	scanf("%d%d", &w, &h);
	while(cin >> k)	{
		pp.push_back(k);
	}
	MovingPoint Q(pp);
	Q.print_line(w, h);

}
