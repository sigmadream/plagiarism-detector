#include<iostream>
#include<vector>
#include<string>

using namespace std;
//vector < vector <int> > v;
//vector<int> v2;
class Point{
    int _x, _y;
public:
    Point()
        :_x(0), _y(0){}
    Point(int x, int y)
        : _x(x), _y(y){}
};
class MovingPoint:public Point{
    vector<int> v;
public:
    MovingPoint(){
        int n;
        while(scanf("%d", &n) == 1)
            v.push_back(n);
    }
    void mark(int x, int y){
        int px = 0, py = 0;;
        for(int i = 0; i < v.size(); i++){
            if(v[i] % 2 == 0) px++;
            else if(v[i] % 2 == 1) py++;
        }
        cout << "+";
        for(int i = 0; i < x; i++)
            cout << "-";
        cout << "+" << '\n';
        for(int i = 0; i < y; i++){
            cout << "|";
            for(int j = 0; j < x; j++){
                if(j == px - 1 && i == py - 1){
                    cout << ".";
                    j++;
                }
                cout << " ";
            }
            cout << "|" << '\n';
        }
        cout << "+";
        for(int i = 0; i < x; i++)
            cout << "-";
        cout << "+";
    }
};
class Board : public vector<int>{
    
};
int main(){
    int x, y;
    cin >> x >> y;
    MovingPoint a;
    a.mark(x, y);
}