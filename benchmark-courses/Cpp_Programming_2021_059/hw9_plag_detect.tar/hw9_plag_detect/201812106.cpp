#include <iostream>
#include <vector>
using namespace std;
class Point
{
	int _x, _y;
public:
	Point(int x = 0, int y = 0) : _x(x), _y(y) {}
	int x() { return _x; }
	int x(int n) { return _x = n; }
	int y() { return _y; }
	int y(int n) { return _y = n; }
};

class MovingPoint : public Point
{
public:
	MovingPoint(int x = 0, int y = 0) : Point(x, y) {}
	void Move(int n) {
		if (n % 2 == 0)x(x() + 1);
		else y(y() + 1);
	}
};
class Board : public vector<vector<int> >
{
public:
	Board(int w, int h) {
		this->resize(h);
		for (int i = 0; i < h; i++) {
			(*this)[i].resize(w);
		}
	}
	void mark(int y, int x) {
		(*this)[y - 1][x - 1] = 1;
	}
};
int main() {
	MovingPoint p(0, 0);
	int n, w, h;
	cin >> w >> h;
	while (cin >> n) {
		p.Move(n);
	}
	Board B(w, h);

	B.mark(p.y(), p.x());
	for (int i = 0; i <= h + 1; i++) {
		if (i == 0 || i == h + 1) {
			cout << "+";
			for (int j = 0; j < w; j++) {
				cout << "-";
			}
			cout << "+\n";
		}
		else {
			cout << "|";
			for (int j = 0; j < w; j++) {
				if (B[i - 1][j])
					cout << ".";
				else
					cout << " ";
			}
			cout << "|\n";
		}
	}
}