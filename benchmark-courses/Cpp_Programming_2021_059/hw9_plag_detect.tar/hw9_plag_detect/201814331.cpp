#include <cstdio>
#include <limits.h>
#include <iostream>
using namespace std;

int i, j;

class Point {
	public:
		Point(int p_width, int p_hight) {
			this -> p_width = p_width;
			this -> p_hight = p_hight;
		}
		int p_width, p_hight;
};

class MovingPoint : public Point {
	public:
		MovingPoint(int p_width, int p_hight, int p_x, int p_y) : Point(p_width, p_hight) {
			this -> p_x = p_x;
			this -> p_y = p_y;
		}
	void show() {
		cout << "+";
		for ( i = 0; i < p_width; i++ )
			cout << "-";
		cout << "+" << "\n";
		
		for ( j = 0; j < p_hight; j++ )
		{
			for ( i = 0; i < p_width; i++ )
			{
				if ( i == 0 || i == p_width-1 )
					cout << "|";
				else if ( i == p_x && j == p_y-1 )
					cout << ".";
				else
					cout << " ";	
			}
			cout << "\n";
			
		}
		
		cout << "+";
		for ( i = 0; i < p_width; i++ )
			cout << "-";
		cout << "+";
		
	}
	private :
		int p_x;
		int p_y;
};


int main()
{
	int width, hight, number, even = 0, odd = 0;
	
	cin >> width;
	cin >> hight;
	
	while(scanf("%d", &number) != EOF) // if you stop this, input ctrl Z
	{
		if (number % 2 == 0)
			even++;
		else
			odd++;
	}
	
	MovingPoint std(width, hight, even, odd);
	
	std.show();
}

