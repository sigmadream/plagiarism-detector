#include<iostream>
#include<vector>
#include <iomanip>
#include <sstream>

using namespace std;

class Board : public vector <int>
{
private:
    int x,y;
    int xlen,ylen;

public:
    Board(int xlen,int ylen):x(0),y(0),xlen(xlen),ylen(ylen)
    {}
    void print(){
        for(int i=0;i<size();++i){
            cout<<at(i)<<((size()-1==i)?"\n":" ");
        }
        cout<<x<<" "<<y<<endl;
    }
    void find_xy()
    {   
        int cont=0;
        for(int i=0;i<size();++i)
        {   
            if(at(i)%2==0) cont++;
        }
        x=cont;
        y=size()-cont;
    }

    void mark()
    {
        ostringstream buf;
        char prev=buf.fill('-');
        buf<<"+"<<setw(xlen)<<""<<"+"<<endl;
        buf.fill(prev);
        for(int i=1;i<ylen;i++)
        {   
            if(i==y)
            {
                buf<<"|"<<setw(x-1)<<" "<<"."<<setw(xlen-x)<<" "<<"|"<<endl;
            }
            buf<<"|"<<setw(xlen)<<" "<<"|"<<endl;
        }
        prev=buf.fill('-');
        buf<<"+"<<setw(xlen)<<""<<"+"<<endl;
        buf.fill(prev);
        cout<<buf.str();
    }
    
    
};

void pushall(Board &v,int *a,int size)
{
    for(int j=0;j<size;++j){
        v.push_back(a[j]);
    }
}

int main(void)
{
    int xlen,ylen;
    cin>>xlen;
    cin>>ylen;

    int a[100],i=0;
    while(cin>>a[i])
    {
        i++;
    }
    Board v(xlen,ylen);
    pushall(v,a,i);
    v.find_xy();
    v.mark();
}