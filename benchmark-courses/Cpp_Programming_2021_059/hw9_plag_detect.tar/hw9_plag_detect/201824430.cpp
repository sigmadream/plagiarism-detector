 #include <iostream>
 #include <string>

 using namespace std;


 class Point
 {
 int _x, _y;
 public:
 Point(int x=0, int y=0): _x(x), _y(y) {}
 int x() { return _x; }
 int x(int n) { return _x = n; }
 int y() { return _y; }
 int y(int n) { return _y = n; }
 };

 class MovingPoint: public Point
 {
 int _num;
 public:
 MovingPoint(int num=0, int x=0, int y=0): _num(num), Point(x, y)   {}
  int num(int k) {return _num = k; }
  int num() { return _num; }
  
  int move() {
 	if ((_num % 2) == 0) { return x(x()+1); }
 	else { return y(y()+1); }
 	}
 };


 int main()
 {
 int n[100], t, w, l;
 
 cin >> w >> l;
 
 int i = 0;
 while (cin >> t) {
 	n[i] = t;
 	i++;
 }

MovingPoint p;
 
 for (int j = 0; j<=i; j++) {
 	p.num(n[j]);
 	p.move();
 }

int ansx = p.x() - 1;
int ansy = p.y();
 
/* char plane[l+1][w+1] = {' ',};

plane[ansy][ansx] = '.';



for (int a= 1; a<w+1; a++) {
	plane[0][a] = '-';
	plane[l+1][a] = '-';
}

for (int a = 1; a<= l; a++) {
	plane[a][0] = '|';
	plane[a][w+1] = '|';
}

plane[0][0] = '+'; plane[0][w+1] = '+'; plane[l+1][0] = '+';
plane[l+1][w+1] = '+';


for (int a = 0; a<=l+1; a++) {
	for (int b = 0; b<=w+1; b++) {
		cout << plane[a][b];
	}
	cout << endl;
}*/

	string first_last;
	string mid;
	string ans;
	
	first_last.append("+");
	
	for (int j=0; j<w; j++) {
		first_last.append("-");
	}
	first_last.append("+");
	
	mid.append("|");
	for (int j=0; j<w; j++) {
		mid.append(" ");
	}
	
	mid.append("|");
	
	ans.append("|");
	for (int j=0; j<ansx-1; j++) {
		ans.append(" ");
	}
	
	ans.append(".");
	for (int j=0; j<w-ansx; j++) {
		ans.append(" ");
	}
	
	ans.append("|");
	
	cout << first_last << '\n';
	
	for (int j=0; j<ansy-1; j++) {
		cout << mid << '\n';
	}
	
	cout << ans << '\n';
	
	for (int j=0; j<l-ansy; j++) {
		cout << mid << '\n';
	}
	
	cout << first_last;

 }
