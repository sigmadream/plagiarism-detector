#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Point
{
	int _x, _y;
public:
	Point (int x=0, int y=0): _x(x), _y(y) {}
	int x() {return _x;	}
	int x(int n) {return _x=n; }
	int y() {return _y;	}
	int y(int n) {return _y=n; }
};

class MovingPoint: public Point
{
public:
	MovingPoint (int x=0, int y=0): Point(x, y){}
	void move(int num) {
		if(num%2==0)
			x(x() + 1);
		else
			y(y() + 1);
	}
};

class Board: public vector<vector<int> >
{
	vector<int> _x;
	vector<vector<int> > _y;
public:
	Board () {
		_x.resize(0);
		_y.resize(0);
	}
	Board (int x, int y){
		_x.resize(0);
		_y.resize(0);
		for(int i=0; i < x; i++)
			_x.push_back(0);
		for(int i=0; i < y; i++)
			_y.push_back(_x);
	}
	void mark(int x, int y) {
		_x[x-1] = 1;
		_y[y-1] = _x;
	}
	void print() {
		cout << "+";
		for(int i=0; i<_x.size(); i++)
			cout << "-";
		cout << "+" << endl;
		
		for(int i=0; i<_y.size(); i++) {
			cout << "|";
			for(int j=0; j<_x.size(); j++){
				if(_y[i][j]==1)
					cout << ".";
				else
					cout << " ";
			}
			cout << "|" << endl;
		}
		
		cout << "+";
		for(int i=0; i<_x.size(); i++)
			cout << "-";
		cout << "+" << endl;
	}
};

int main()
{
	int x, y, num;
	MovingPoint p(0, 0);
	
	cin >> x >> y;
	Board b(x, y);
	
	while(cin >> num)
		p.move(num);
	
	
	b.mark(p.x(), p.y());
	b.print();
}
