#include <cstdio>

int main() {
   int n, i=0;
   int a[100];
   int garo,sero;
   scanf("%d",&garo);
   scanf("%d",&sero);
   while(scanf("%d", &n)==1){
   a[i]=n;
   i++;
   }
  
   //i�� �Է¹��� ���ڰ���.
   int k=0;
   int x=0;
   int y=0;
   for(k=0; k<i; k++){
		if (a[k]%2==0) x=x+1;
		else y=y+1;
   } 
   int q=0;
   int w=0;
   int e=0;
   printf("+");
   for(q=0; q<garo; q++){
   		printf("-");
   }
   printf("+\n");
   
   
   for(w=0; w<sero; w++){
   	printf("|");
   	for(e=0; e<garo; e++){
   		if((e==x-1)&&(w==y-1)) printf(".");
		else printf(" ");
	   }
	printf("|\n");
   }
   
   
   
   
   
   
   
   
   
   printf("+");
	for(q=0; q<garo; q++){
   		printf("-");
	}
	printf("+");
   
   
   return 0;
}
