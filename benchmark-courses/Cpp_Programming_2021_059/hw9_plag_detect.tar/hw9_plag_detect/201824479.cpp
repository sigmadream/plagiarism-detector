#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

class Point {
int width,height, _x,_y;
public:
    Point(int x=0, int y=0, int a=0, int b=0): _x(x), _y(y), width(a), height(b) {}
    void set(int a, int b, int x, int y) {
        width = a;
        height = b;
        _x = x;
        _y = y;
    }
    int x() { return _x; }
    int x(int n) { return _x = n; }
    int y() { return _y; }
    int y(int n) { return _y = n; }
    int w() { return width; }
    int w(int n) { return width = n; }
    int h() { return height; }
    int h(int n) { return height = n; }
};

class MovingPoint: public Point {
public:
    void getNum() {
        int a,b,c,x=0,y=0;
        vector<int> v;
        cin >> a >> b;
        while (cin >> c) {
            v.push_back(c);
            if (c%2==0) x++;
            else y++;
        }
    
        set(a,b,x,y);
    }
  
};

void print(MovingPoint p) {
    ostringstream head, space, content;
    char bar = head.fill('-');
    head << "+" << setw(p.w()) << "" << "+" << endl;
    head.fill(bar);
    cout << head.str();
    
    space << "|" << setw(p.w()) << "" << "|" << endl;
    for (int i =0;i<p.y() -1;i++) {
        cout << space.str();
    }
    
    content << "|" << setw(p.x() -1) << "" << "." << setw(p.w() - p.x()) << "" << "|" << endl;
    cout << content.str();
    
    for (int i =0;i<p.h() - p.y();i++) {
        cout << space.str();
    }
    cout << head.str();
}

int main() {
    MovingPoint m;
    m.getNum();
    
    print(m);
}


