#include <iostream>
#include <vector>
using namespace std;
class Point{
    int _x, _y;
public:
    Point(int x=0, int y=0): _x(x), _y(y){}
    int x() { return _x; }
    int x(int n){ return _x = n; }
    int y() { return _y; }
    int y(int n) { return _y = n; }
};
class MovingPoint: public Point{
    vector<int> f;
public:
    void get_f(int n){ f.push_back(n); }
    vector<int> move(){
        for(int i = 0; i < f.size(); i++)
            (f[i]%2==0)?x(x()+1):y(y()+1);
        vector<int> out;
        out.push_back(x());
        out.push_back(y());
        return out;
    }
};
class Board:public vector<vector<int>>{
    int w, h;
public:
    Board(int width, int height) : w(width), h(height){}
    void new_b(Board &b){ // 왜 여기서 가로와 세로 중 작은 값의 크기로 n * n 사이즈의 이차원 행렬이 만들어지는걸까...
        int m = max(w+2, h+2);
        vector<int> r(m);
        for(int i=0;i<m;i++){
            b.push_back(r);
        }
    }
    void b_set(Board &b){
        for(int x = 0; x <= w+1; x++){
            for(int y = 0; y <= h+1; y++)
                if(x==0 || x==w+1)b[x][y] = 2;
                else if(y==0 || y==h+1) b[x][y] = 3;
                else b[x][y] = 0;
        }
        b[0][0] = 1; b[0][h+1] = 1; b[w+1][0] = 1; b[w+1][h+1] = 1;

    }
    void mark(Board &b, int x, int y){
        b[x][y] = 4;
    }
    void print(Board &b){
        for(int y = 0; y <= h+1; y++){
            for(int x = 0; x <= w+1; x++){
                if(b[x][y] == 0) cout << " ";
                else if(b[x][y] == 1) cout << "+";
                else if(b[x][y] == 2) cout << "|";
                else if(b[x][y] == 3) cout << "-";
                else if(b[x][y] == 4) cout << ".";
            }
            cout << endl;
        }
    }
};
int main(){

    MovingPoint mp;
    int n;
    int width, height;
    cin >> width >> height;
    while(cin >> n) mp.get_f(n);
    int tx = mp.move()[0], ty = mp.move()[1] / 2;
    Board b(width, height);
    b.new_b(b);
    b.b_set(b);
    b.mark(b, tx, ty);
    b.print(b);
}