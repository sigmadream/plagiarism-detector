#include <iostream>
#include <vector>
using namespace std;

class Point{
    int _x, _y;
public:
Point(int x=0, int y=0): _x(x), _y(y) {}
    int x() { return _x; }
    int x(int n) { return _x = n; }
    int y() { return _y; }
    int y(int n) { return _y = n; }
};

class MovingPoint : public Point{
    vector<int> input;
public:
    void get_num(){
        int num;
        while(cin >> num){
            input.push_back(num);
        }
    }
    void coor(){
        int sz = input.size();
        for(int i=0; i<sz; i++){
            input[i]%2 == 0 ? x(x()+1): y(y()+1);
        }
    }
};

class Board : public vector<vector<int>>{
    int w, h;
public:
    Board(int _x = 0, int _y = 0) : w(_x), h(_y){}
    void makeboard(Board &v){
        vector<int> b(w);
        for(int i=0;i<h;i++){
            v.push_back(b);
        }
    }
    void mark(Board &v, int corx, int cory){
        v[corx-1][cory-1] = 1;
    }

    void print(Board &v){
        cout << '+';
        for(int i = 0; i<w; i++){
            cout <<'-';
        }
        cout << '+' << endl;

        for(int i = 0 ; i < h; i++ ){
            cout << '|';
            for(int j = 0 ; j < w ; j++){
                if(v[i][j]==0) cout << ' ';
                else cout << '.';
            }
            cout << '|' << endl;
        }
        cout << '+';
        for(int i = 0; i < w; i++){
            cout <<'-';
        }
        cout << '+' << endl;
    }
    
};
int main(){
    int x, y;
    cin >> x >> y;
    MovingPoint a;
    a.get_num();
    a.coor();
    Board v(x,y);
    v.makeboard(v);
    v.mark(v,a.y(),a.x());
    v.print(v);
}