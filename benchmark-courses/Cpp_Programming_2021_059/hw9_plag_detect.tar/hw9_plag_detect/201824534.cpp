#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
using namespace std;

class Point{
    int x,y;
public:
    Point(){
        x = y = 0;
    }
    void mv(int a[], int sz){
        for(int j=0;j<sz;j++){
            if(a[j]%2==0)
                x++;
            else
                y++;
        }
    }

    int xval(){
        return x;
    }
    int yval(){
        return y;
    }
};

int main(){
    Point m;
    int a[100],n,i=0;
    int p,q;
    cin >> p >> q;
    while(cin >> n){
        a[i++] = n;
    }
    m.mv(a,i);
    ostringstream buf;
    char prev1 = buf.fill('-');
    buf << "+" << setw(p) << "" << "+" << endl;
    buf.fill(prev1);
    for(int j=0;j<q;j++){
        if((j+1) == m.yval())
            buf.fill('.');
        buf << "|" << setw(p) << "" << "|" << endl;
    }
    char prev2 = buf.fill('-');    
    buf << "+" << setw(p) << "" << "+" << endl;
    buf.fill(prev2);
    cout << buf.str();
}