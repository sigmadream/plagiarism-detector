#include <iostream>
#include <string>
#include <vector>

class Point
{
private:
	int _x, _y;

public:
	Point(int x = 0, int y = 0) : _x(x), _y(y) {}
	~Point() {}
	int x() { return _x; }
	int x(int n) { return _x = n; }
	int y() { return _y; }
	int y(int n) { return _y = n; }

};

class MovingPoint : public Point
{
public:
	MovingPoint(int x = 0, int y = 0) : Point(x, y) {}
	~MovingPoint() {}
	void moveLocation();
	void printLocation(std::vector<std::vector<char>>& boardCopy);

};

std::vector<std::vector<char>> boardInitialize()
{
	int boardWidth, boardHeight;
	std::cin >> boardWidth >> boardHeight;

	std::vector<std::vector<char>> tempBoard(boardHeight + 2, std::vector<char>(boardWidth + 2, ' '));

	tempBoard[0][0] = '+';
	tempBoard[0][boardWidth + 1] = '+';
	tempBoard[boardHeight + 1][0] = '+';
	tempBoard[boardHeight + 1][boardWidth + 1] = '+';

	for (int i = 1; i < tempBoard.size() - 1; i++)
	{
		tempBoard[i][0] = '|';
		tempBoard[i][boardWidth + 1] = '|';
	}
	for (int j = 1; j < tempBoard[0].size() - 1; j++)
	{
		tempBoard[0][j] = '-';
		tempBoard[boardHeight + 1][j] = '-';
	}

	return tempBoard;
}

int main()
{
	std::vector<std::vector<char>> board = boardInitialize();

	MovingPoint myPoint;
	myPoint.moveLocation();
	myPoint.printLocation(board);

	return 0;
}

void MovingPoint::moveLocation()
{
	int inputNum;
	while (std::cin >> inputNum)
	{
		if (inputNum % 2 == 0)
		{
			int currentLocation = x();
			x(currentLocation + 1);
		}
		else
		{
			int currentLocation = y();
			y(currentLocation + 1);
		}
	}
}

void MovingPoint::printLocation(std::vector<std::vector<char>>& boardCopy)
{
	boardCopy[y()][x()] = '.';
	for (int i = 0; i < boardCopy.size(); i++)
	{
		for (int j = 0; j < boardCopy[0].size(); j++)
		{
			std::cout << boardCopy[i][j];
		}
		std::cout << std::endl;
	}
}