#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

class Board 
{
    int _w;
    int _h;
public:
    Board(int w=0, int h=0): _w(w), _h(h) { }
    int w() { return _w; }
    int w(int n) { return _w = n; }
    int h() { return _h; }
    int h(int n) {return _h = n; }
};

class MovingPoint : public Board
{
    int _x;
    int _y;
public:
    MovingPoint(int w=0, int h=0): Board(w,h) { }
    void mark (int x, int y) {
        _x = x;
        _y = y;
    }
    void print ();
};

void MovingPoint::print() {
    ostringstream buf;

    char prev = buf.fill('-');
    buf << "+" << setw(this->w()) << "" << "+" << endl;
    buf.fill(prev);
    cout << buf.str();
    for (int i = 0; i < this->h(); i++) {
        cout << "|";
        for (int j = 0; j < this->w(); j++) {
            if (j == _x - 1 && i == _y - 1) {
                cout << ".";
            }
            else {
                cout << " ";
            }
        }
        cout << "|" << endl;
    }
    cout << buf.str();
}

int main()
{
    int w, h;
    cin >> w >> h;
    int dir;
    MovingPoint b(w,h);
    int x = 0, y = 0;
    while (cin >> dir) {
        if (dir % 2 == 0) {
            b.mark(++x,y);
        }
        else {
            b.mark(x,++y);
        }
    }
    b.print();
}