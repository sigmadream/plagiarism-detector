#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>
using namespace std;

class Point {
    int _x, _y;
    public: 
        Point() {_x = 0; _y = 0; }
        void IncX() { _x += 1; }
        void IncY() { _y += 1; }
        int GetX() { return _x; }
        int GetY() { return _y; }
};

class MovingPoint: public Point {
    vector<int> v;
    public:
        MovingPoint(vector<int> inputV) { Point(); v = inputV; }

        void Locate() {
            for(int i = 0; i < this->v.size(); i++)
                v[i] % 2 == 0 ? IncX() : IncY();
        }
};

class Board {
    int _w, _h;
    int _x, _y;
    ostringstream buf;

    vector<vector<int>> pt;
public:
    Board(int w, int h) { _w = w, _h = h; }
    void Mark(MovingPoint &p) {
        this->_x = p.GetX();
        this->_y = p.GetY();
    }

    void Frame() {
        char pre = buf.fill('-');
        this->buf << "+" << setw(_w) << "" << "+" << endl;
        this->buf.fill(pre);
    }

    void LocateDir() {
        Frame();
        for(int i = 0; i < this->_h; i++) {
            if(i == _y - 1) {
                buf << "| " << setw(_x-1) << "." << setw(_w-_x+1) << " |" << endl;
            } else {
                buf << "| " << setw(_w) << " |" << endl;
            }
        }
        Frame();
    }

    void Print(ostream &out ) {
        this->LocateDir();

        out << this->buf.str();
    }
};

int main() {
    int w, h;
    cin >> w >> h;

    vector<int> v;
    int num, i = 0;
    while(cin >> num) {
        v.push_back(num);
    }

    MovingPoint movingpoint(v);
    movingpoint.Locate();

    Board board(w, h);
    board.Mark(movingpoint);
    board.Print(cout);

    // cout << movingpoint.GetX() << endl;
    // cout << movingpoint.GetY() << endl;

}