#include <vector>
#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>

using namespace std;

class Point {
    int _x, _y;
public:
    Point(int x=0, int y=0): _x(x), _y(y) {}
    int x() { return _x; }
    int x(int n) { return _x = n; }
    int y() { return _y; }
    int y(int n) { return _y = n; }
};

class Board: Point{
    int size_x, size_y;
public:
    Board(int a, int b): Point(0,0), size_x(a), size_y(b) {}

    void movepoint(vector<int> v) {
        int a=0,b=0;
        for(int n:v) {
            if (n%2==0) {a++;}
            else {b++;}
        }
        x(a); y(b);
    }

    ostream& print(ostream&) {
        ostringstream buf;
        int width = size_x;
        int height = size_y;

        char prev = buf.fill('-');
        buf << "+" << setw(width) << "" << "+" << endl;
        buf.fill(prev);

        for (int i=1;i<=height;i++) {

            if(i == y()) {
                buf << "|";
                for(int j=1; j<=width; j++) {
                    if (j == x()) buf << ".";
                    else buf << " ";
                }
                buf << "|" << endl;
            } 

            else {buf << "|" << setw(width) << "" << "|" << endl;}
        }


        prev = buf.fill('-');
        buf << "+" << setw(width) << "" << "+" << endl;
        buf.fill(prev);

        return cout << buf.str();
    }
};


int main() {
    int size_x,size_y;
    cin >> size_x >> size_y;
    Board B(size_x,size_y);

    int n;
    vector<int> v;
    while(cin >> n) v.push_back(n);

    B.movepoint(v);
    B.print(cout);
}