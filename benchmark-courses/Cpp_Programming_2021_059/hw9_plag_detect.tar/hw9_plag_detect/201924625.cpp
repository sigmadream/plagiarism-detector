#include <iostream>
#include <string>
#include <vector>
using namespace std;
class Point
{
    int _x, _y;

public:
    Point(int x = 0, int y = 0) : _x(x), _y(y) {}
    int x() { return _x; }
    int x(int n) { return _x = n; }
    int y() { return _y; }
    int y(int n) { return _y = n; }
};

class Board : public Point
{
    vector<vector<int>> board;

public:
    // public:
    Board(int h = 0, int w = 0)
    {
        Point(0, 0);
        makeBoard(w + 1, h + 1);
        // cout << "asdf" << endl;
        // printer(h, w);
    }
    // string name() { return _name; }
    // string name(string newname) { return _name = newname; }
    void makeBoard(int w, int h)
    {
        vector<int> _w;
        for (int i = 0; i < w; i++)
            _w.push_back(0);
        for (int i = 0; i < h; i++)
            board.push_back(_w);
    }
    void mark(int _x, int _y)
    {
        board[x()][y()] = 0;
        board[_x][_y] = 1;
        x(_x);
        y(_y);
    }
    void move_x()
    {
        mark(x() + 1, y());
    }
    void move_y()
    {
        mark(x(), y() + 1);
    }
    void printer(int h, int w)
    {

        // cout << "asdf" << endl;
        for (int i = 0; i <= h + 1; i++)
        {
            for (int j = 0; j <= w + 1; j++)
            {
                if (i == 0 || i == h + 1)
                {
                    if (j == 0 || j == w + 1)
                    {
                        cout << "+";
                    }
                    else
                        cout << "-";
                    continue;
                }
                if (j == 0 || j == w + 1)
                {
                    cout << "|";
                    continue;
                }
                if (board[i][j])
                    cout << ".";
                else
                    cout << " ";
            }
            cout << endl;
        }
    }
};

bool even(int a) //x
{
    if (a % 2)
        return true;
    else
        return false;
}
// class NamedPoint : public Point
// {
//     string _name;

// public:
//     NamedPoint(string name = "", int x = 0, int y = 0) : _name(name), Point(x, y) {}
//     string name() { return _name; }
//     string name(string newname) { return _name = newname; }
// };

// ostream &operator<<(ostream &out, NamedPoint p)
// {
//     return out << p.name() << "(" << p.x() << ", " << p.y() << ")";
// }

int main()
{
    int width, heigth;
    cin >> width >> heigth;
    Board b(heigth, width);
    int a;
    while (cin >> a)
    {
        if (even(a))
        {
            b.move_x();
        }
        else
        {
            b.move_y();
        }
    }
    b.printer(heigth, width);
    // b.makeBoard(width, heigth);
    // NamedPoint q("Q", 3, 4);
    // cout
    // << q << endl;
}
// Board vector<vector<int>>.
//