#include <iostream>
#include <vector>

using namespace std;

class Board
{
    public:
        Board(int x,int y)
        {
            matrix.resize(y+2);

            for(int i=0;i<y+2;i++)
            {
                for(int j=0;j<x+2;j++)
                {
                    if(i==0 || i==y+1)
                    {
                        if(j==0 || j ==x+1)
                        {
                            matrix[i].push_back('+');
                        }
                        else
                        {
                            matrix[i].push_back('-');
                        }
                    }
                    else
                    {
                        if(j==0 || j==x+1)
                        {
                            matrix[i].push_back('|');
                        }
                        else
                        {
                            matrix[i].push_back(' ');
                        }
                    }
                    
                }
            }
        }
        void mark(int x,int y)
        {
            matrix[y][x]='.';
        }

        void print()
        {
            for(auto itr : matrix)
            {
                for(char ch : itr)
                {
                    cout<<ch;
                }
                cout<<endl;
            }
        }


    private:
        vector<vector<char>> matrix;
};

class Point
{
    public:
        Point(){}
        Point(int x,int y):x(x),y(y){}
        int getx(){ return x; }   
        int gety(){ return y; }
    protected:
        int x;
        int y;
};

class MovingPoint : public Point
{
    public:
        MovingPoint(int x,int y) : Point(x,y){}
        void move()
        {
            int num;
            while(cin>>num)
            {
              if(num%2==0)
              {
                x++;
              }
              else
              {   
                y++;
              }
            }
        }
};

int main()
{
    int n,m;
    int x=0,y=0;
    

    cin>>n>>m;

    Board board(n,m);
    MovingPoint mp(0,0);
    mp.move();
    board.mark(mp.getx(),mp.gety());
    board.print();
}