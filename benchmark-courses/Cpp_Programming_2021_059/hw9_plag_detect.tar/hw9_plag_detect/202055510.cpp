#include <iostream>
#include <vector>

using namespace std;

class Board : public vector<vector<int>>{
	int _x;
	int _y;
	vector<vector<int>> _v;
	
	public:
		Board(int x, int y) {
			_x = 0;
			_y = 0;
			vector<vector<int>> v(y, vector<int> (x, 0));
			_v = v;
		}
		
		void mark(int x, int y){
			_v[y-1][x-1] = 1;
			
			cout << '+';
			for(int i = 0; i < _v[0].size(); i++)	cout << '-';
			cout << '+' << endl;
			
			for(int i = 0; i < _v.size(); i++){
				cout << '|';
				for(int j = 0; j < _v[0].size(); j++){
					if (_v[i][j] == 1) cout << '.';
					else	cout << ' ';
				}
				cout << '|' << endl;
			}
			
			cout << '+';
			for(int i = 0; i < _v[0].size(); i++)	cout << '-';
			cout << '+' <<endl;
		}
		
		Board move(int n){
			if(n % 2 == 0)	_x++;
			else	_y++;
			return *this;
		}
		
		int x(){
			return _x;
		}
		
		int y(){
			return _y;
		}
		
};


int main(){
	int a, b;
	cin >> a >> b;
	Board B(a, b);
	
	int n;
	while(cin >> n){
		B = B.move(n);
	}
	
	int x = B.x();
	int y = B.y();
	B.mark(x,y);
}
