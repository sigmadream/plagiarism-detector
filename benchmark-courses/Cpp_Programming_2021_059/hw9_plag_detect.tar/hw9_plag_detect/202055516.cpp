#include <iostream>
#include <vector>
#include <iomanip>

class Point
{
    int _x, _y;
    public:
    Point(int x=0, int y=0): _x(x), _y(y) {}
    int x() { return _x; }
    int x(int n) { return _x = n; }
    int y() { return _y; }
    int y(int n) { return _y = n; }
};

class MovingPoint : public Point
{
private:
    int width, height;
public:
    MovingPoint(int x=0, int y=0, int w=0, int h=0) : Point(x, y), width(w), height(h) {};

    std::vector<int> locatePoint(std::vector<int> v, int sz)
    {
        std::vector<int> mark = {x(), 0};
        for(int i=2; i < sz; i++) {
            if(v[i]%2==0)
                mark[0]++;
            else mark[1]++;
        }
        return mark;

    }

    void print(std::ostream& out, std::vector<int> v)
    {
        std::ostringstream buf;
        int w = width, h = height, i=1;
        char prev = buf.fill('-');
        buf << "+" << std::setw(width) << "" << "+" <<std::endl;
        buf.fill(prev);
        while(i < v[1])
        {
            buf << "| " << std::setw(width) << " |" <<std::endl;
            i++;
        }
        i=1;
        buf << "|";
        while(i < v[0])
        {
            buf << " ";
            i++;
        }
        buf << "." ;
        i=1;
        while(i < w-v[0])
        {
            buf << " ";
            i++;
        }
        buf << " |"<<std::endl;
        i=0;
        while(i < h-v[1])
        {
            buf << "| " << std::setw(width) << " |" <<std::endl;
            i++;
        }
        prev = buf.fill('-');
        buf << "+" << std::setw(width) << "" << "+" <<std::endl;
        buf.fill(prev);
        out << buf.str();
    }
};

int main()
{
    int n;
    std::vector<int> vec;
    while(std::cin>>n)
    {
        vec.push_back(n);
    }
   MovingPoint p(0, 0, vec[0], vec[1]);
    int sz = vec.size();
    std::vector<int> point = p.locatePoint(vec, sz);
    p.print(std::cout, point);

}

