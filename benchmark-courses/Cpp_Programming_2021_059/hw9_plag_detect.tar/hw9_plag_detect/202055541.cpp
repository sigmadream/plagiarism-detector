#include <iostream>
#include <vector>
using namespace std;


class set_form {
public:
	int x;
	int y;
	int even;
	int odd;
	vector<vector<char>> form;
	void setx(int set_x) {
		x = set_x;
	}
	void sety(int set_y) {
		y = set_y;
	}
	void seteven(int set_even) {
		even = set_even;
	}
	void setodd(int set_odd) {
		odd = set_odd;
	}
};






class board : public set_form {
public:
	int matrix() {
		set_form b;
		b.form.assign(150, vector<char>(150, ' '));
		b.form[0][0] = '+';
		b.form[0][x + 1] = '+';
		b.form[y + 1][0] = '+';
		b.form[y + 1][x + 1] = '+';

		for (int i = 1; i <= x; i++) {
			b.form[0][i] = '-';
			b.form[y + 1][i] = '-';
		}

		for (int i = 1; i <= y; i++) {
			b.form[i][0] = '|';
			b.form[i][x + 1] = '|';
		}

		b.form[odd][even] = '.';

		for (int i = 0; i <= y + 1; i++)
		{
			for (int j = 0; j <= x + 1; j++) {
				printf("%c", b.form[i][j]);
			}
			printf("\n");
		}

		return 0;
	}
};





int even_or_odd(int x) {
	if (x % 2 == 1) {
		return 1;
	}
	else {
		return 0;
	}
}





int main(void)
{
	board b;
	int x, y;
	int even = 0;
	int odd = 0;
	int num;
	cin >> x >> y;

	while (scanf("%d", &num) != EOF) {
		if (even_or_odd(num) == 1) {
			odd += 1;
		}
		else {
			even += 1;
		}
	}

	b.setx(x);
	b.sety(y);
	b.seteven(even);
	b.setodd(odd);
	b.matrix();
}

