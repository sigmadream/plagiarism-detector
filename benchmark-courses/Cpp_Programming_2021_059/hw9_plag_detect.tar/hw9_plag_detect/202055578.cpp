#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
using namespace std;

class Point{
	int _x , _y ;
public:
	Point (int x = 0 , int y = 0) : _x(x) , _y(y) {	}
	int x(){return _x;}
	int x(int n){return _x = n;}
	int y(){return _y;}
	int y(int n){return _y = n;}	
};

class MovingPoint:public Point {
	int __x , __y ;
	public:
		MovingPoint(int x = 0 , int y = 0) : Point(x,y) { __x = 0 ; __y = 0;	 }
		void mvpnt( int a[] , int i ){
			for (int w = 0 ; w < i ; w++){
			if (a[w] % 2 == 0) __x++;
			else __y++;
			}	
		}
		int x() { return __x ;}
		int y() { return __y;}
		
};





int main(){
	ostringstream buf;
	
	int x, y = 0;
	cin >> x ;
	cin >> y ;
	
	int a[100000];
	int i = 0;
	while(cin>>a[i]){
		i++;
	}
	
	MovingPoint p;
	p.mvpnt(a,i);

//	cout << " x : " << p.x() << endl;
//	cout << " y : " << p.y() << endl;
//	cout <<"i : " << i << endl;
	
	char prev = buf.fill('-');

	buf << "+-" << setw(x-2) << "" << "-+" << endl;
	buf.fill(prev);
	

	for(int l = 0 ; l < p.y()+1 ; l++){
		if (l==p.y()-1){
			buf << "|"<< setw(p.x()-1)<<" "<< "." <<" "<<setw(x-p.x())<<"|" << endl;
		}
		else 
		buf << "|"<<" " << setw(x-1)<<"" <<"|" << endl;
	}	

	
	prev = buf.fill('-');

	buf << "+-" << setw(x-2) << "" << "-+" << endl;
	buf.fill(prev);
	
	cout << buf.str();
	
}
