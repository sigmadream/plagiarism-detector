#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

int main(){
	using namespace std;
	ostringstream buf;
	ostringstream buf1;
	ostringstream buf2;
	int width, height, i;
	scanf("%d", &width);
	scanf("%d", &height);
	char prev = buf.fill('-');
	char prev2 = buf2.fill('-');
	buf << "+-" << setw(width) <<"-+" << endl;
	for (i=0; i<height; i++){
	buf1 << "| " << setw(width) << " |" << endl;
	}
	buf2 << "+-" << setw(width) << "-+" << endl;
	buf.fill(prev);
	buf2.fill(prev2);
	cout << buf.str();
	cout << buf1.str();
	cout << buf2.str();	
}
