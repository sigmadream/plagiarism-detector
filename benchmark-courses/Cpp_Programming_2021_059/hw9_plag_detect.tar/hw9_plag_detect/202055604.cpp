#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include<vector>
#include<cstdio>
using namespace std;




class Point {
    int _x, _y;
  public:
    Point(int x=0, int y=0): _x(x), _y(y) {}
    int x() {
        return _x;
    }
    int x(int n) {
        return _x = n;
    }
    int y() {
        return _y;
    }
    int y(int n) {
        return _y = n;
    }
    void xmove(){
        _x++;
    }
    void ymove(){
        _y++;
    }
};

class MovingPoint: public Point {
  public:


    MovingPoint(int x=0, int y=0): Point(x, y) {}

    void xmove1(){
        xmove();
    }
    void ymove1(){
        ymove();

    }

};


void udfield(int width) {
    ostringstream buf;
    char prev = buf.fill('-');
    buf << "+" << setw(width) << "" << "+" << endl;
    buf.fill(prev);
    cout << buf.str();
}

void hfield(int width, int height,int x,int y) {
    ostringstream buf;
    char prev = buf.fill(' ');
    for(int j =0; j<height; j++) {
        if(j != y-1) {
            buf << "|" << setw(width) << "" << "|" << endl;
            buf.fill(prev);
        } else {
            buf << "|" << setw(x-1) << "";
            buf.fill(prev);
            buf << ".";

            buf << setw(width-x) << "" <<  "|" << endl;
            buf.fill(prev);
        }
    }
    cout << buf.str();
}



int main() {
    std::vector<int>coords;
    int width, height;
    cin >>  width >> height;
    MovingPoint xyaz(0,0);
    int x=0;
    int y=0;
    while(!cin.eof()) {
        int aa;
        cin >> aa;
        coords.push_back(aa);
    }
    coords.pop_back();

    for(int i =0; i<coords.size(); i++) {
        if(coords[i] % 2 == 1){
            y++;
            xyaz.ymove1();
        }
        else{
            x++;
            xyaz.xmove1();
        }
    }
    udfield(width);
    hfield(width, height,xyaz.x(),xyaz.y());
    udfield(width);


}
