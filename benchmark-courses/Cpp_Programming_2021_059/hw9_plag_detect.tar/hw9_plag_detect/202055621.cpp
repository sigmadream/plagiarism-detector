#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <sstream>
#include <string.h>
using namespace std;
class Point
{
    int _x, _y;
public:
    Point(int x=0, int y=0): _x(x), _y(y) {}
    int x() { return _x; }
    int x(int n) { return _x = n; }
    int y() { return _y; }
    int y(int n) { return _y = n; }
};

class MovingPoint: public Point
{
    int m_x=0, m_y=0;
public:
    MovingPoint (int m_x=0, int m_y=0): Point(m_x, m_y) {}
    int x() { return m_x;}
    int y() { return m_y;}
    void move_x_y(int n){
        if(n%2==0) m_x+=1;
        else m_y+=1;
    }
};

class Board{
    vector< vector<int> > v;
    int max_x, max_y;
public:
    void set_x(int n) {max_x = n;}
    void set_y(int n) {max_y = n;}
};


int main(){
    MovingPoint mp(0,0);
    Board board;
    ostringstream buf;
    int a, b, input;
    int dot_line = 0;

    cin >> a >> b;
    board.set_x(a);
    board.set_y(b);
    while(cin >> input){
        mp.move_x_y(input);
    }

    buf << "+" ;
    for(int i =0; i<a;i++) buf << "-";
    buf << "+" << endl;
    for (int j=1;j<b+1;j++){
        if(mp.y()==j) dot_line+=1;
        buf << "|";
        for (int k =0; k<a;k++){
            if(mp.x() == k+1 && dot_line ==1) buf << ".";
            else buf << " ";

        }
        buf << "|";
        buf << endl;
        dot_line=0;
    }
    buf << "+" ;
    for(int i =0; i<a;i++) buf << "-";
    buf << "+" << endl;
    cout << buf.str();
}
