#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Point
{
    int _x, _y;
public:
    Point (const Point &p)
    {
        _x = p._x;
        _y = p._y;
    }
    Point(): _x(0), _y(0) {}
    void AddX() { _x++; }
    void AddY() { _y++; }
    int GetX() {return _x;}
    int GetY() {return _y;}

};
class MovingPoint : public Point
{
    vector <int> _v;
    int len;
public:
    MovingPoint(const vector<int> v): _v(v), len(_v.size()), Point() {}
    Point LastPoint()
    {
        for(int i = 0; i < len; i++)
        {
            if(_v[i]%2)
                AddY();
            else 
                AddX();
        }
        return *this;
    }
};
class Board : public Point
{
    int xc, yc;
public:
    Board(int x, int y, Point p): xc(x), yc(y), Point(p) {}
  
    void Print()
    {
        cout << "+";
        for(int i = 0; i<xc; i++)
            cout << "-";
        cout << "+" << endl;
        for(int yi = 0; yi < yc; yi++)
        {
            cout << "|";
            for(int xi = 0; xi < xc; xi++){
                if ( xi == GetX()-1 && yi == GetY()-1)
                    cout << ".";
                else 
                    cout << " ";
            }
            cout << "|" << endl;
        }

        cout << "+";
        for(int i = 0; i<xc; i++)
            cout << "-";
        cout << "+" << endl;
    }
};
int main()
{
    int x, y, temp;
    vector<int> my_v;
    cin >> x >> y;
    while(cin >> temp)
        my_v.push_back(temp);
    MovingPoint P(my_v);
    Board B(x, y, P.LastPoint());
    B.Print();
}