#include <iostream>
#include <vector>
#include <sstream>
#include <iomanip>
using namespace std;

class Point
{
    public:
        int x = 0;
        int y = 0;
};

class MovingPoint: public Point
{
    public:
        void Move(int n) {
            if (n%2==0)
                x++;
            else
                y++;
        }
};

class Board: public vector<int> {
    private:
        int width, height;
        int _x, _y;
    public:
        Board(int w, int h) {width=w, height=h;}
        void print(ostream& out);
        void mark(int x, int y) {_x=x; _y=y; /*cout << "_x: " << _x << ", _y: " << _y << endl;*/}
};

void Board::print(ostream& out) {
    ostringstream buf;
    char prev = buf.fill('-');
    buf << "+" << setw(width) << "" << "+"<< endl;
    buf.fill(prev);
    for (int i=1; i<=height; i++) {
        buf << "|";
        if (i == _y) {
            for (int j=1; j<=width; j++) {
                if (j == _x)
                    buf << ".";
                else
                    buf << " ";
            }
        } else {
            buf << setw(width) << "";
        }
        buf << "|" << endl;
    }
    prev = buf.fill('-');
    buf << "+" << setw(width) << "" << "+"<< endl;
    buf.fill(prev);

    out << buf.str();
}

int main() {
    int w, h, n;
    vector<int> nums;
    cin >> w >> h;
    while (cin>>n)
        nums.push_back(n);
    MovingPoint p;
    for (int i=0; i<nums.size();i++)
        p.Move(nums[i]);
    Board myBoard(w,h);
    myBoard.mark(p.x, p.y);
    myBoard.print(cout);
}
