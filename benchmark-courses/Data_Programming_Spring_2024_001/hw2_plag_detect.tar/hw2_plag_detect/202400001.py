a = input().upper()
n = ord(a) - ord("A") + 1


def nat(n: int):
    return n**2 + 1


if nat(n) % 26 == 0:
    num = 26
else:
    num = nat(n) % 26

res = chr(num + ord("A") - 1)
print(res)
