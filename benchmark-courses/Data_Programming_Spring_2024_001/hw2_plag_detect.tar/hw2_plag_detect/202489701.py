x = input()
def abc():
    return ord(x) - ord('@')
n = int(abc())**(ord('C') - ord('A')) + (ord('B') - ord('A'))
def csq():
    if n > (ord('Z') - ord('@')):
        return n % (ord('Z') - ord('@'))
    else:
        return n
print(chr(int(csq()) + ord('@')))