# https://park-duck.tistory.com/entry/%EC%95%84%EC%8A%A4%ED%82%A4%EC%BD%94%EB%93%9C%ED%91%9C-ASCII

def transfer(c):
    nat = ord(c)-ord('@')
    n = ((nat**(ord('C')-ord('A')))+(ord('B')-ord('A')))
    t = (ord('Z')-ord('@'))
    if n <= t:
        return chr(n+ord('@'))
    else :
        return chr((n%t)+ord('@'))

c = input().upper()
print(transfer(c))