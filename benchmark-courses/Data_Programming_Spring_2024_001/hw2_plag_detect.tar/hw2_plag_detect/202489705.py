
def char_to_num(c):
    return ord(c) - ord('A') + 1

def num_to_char(n):
    return chr((n - 1) % 26 + ord('A'))

c = input().upper()
num = char_to_num(c)
squared_plus_one = num ** 2 + 1 
result_char = num_to_char(squared_plus_one)

print(f"{result_char}")
