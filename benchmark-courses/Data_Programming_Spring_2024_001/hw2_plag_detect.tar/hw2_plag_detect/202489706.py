mylist = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
          'V', 'W', 'X', 'Y', 'Z']


a = input()
n = mylist.index(a) + ord('B') - ord('A')

def nat(i: int):
    return i * i + ord('B') - ord('A')


if nat(n) % len(mylist) == ord('A') - ord('A'):
    num = len(mylist)
else:
    num = nat(n) % len(mylist)

res = chr(num + ord('@')) # ord('@') = ord('A') - 1
print(res)
