
def nat(upper):
    return ord(upper) - ord("A") + len('A')

def cal(upper):
    num = nat(upper)
    return num ** len('ab') + len('A')

def convert(num):
    if num > ord('[')-ord('A'):
        num = (num-len('A')) % (ord('[')-ord('A')) + len('A')
    return chr(num + ord('A') - len('A'))

def result(upper):
    re = cal(upper)
    re_ = convert(re)
    print(re_)

result(input())