def nat(c):                          # 함수 nat 제작
    logic = (natural ** (num + num)) + num  # n^2 + 1
    return logic

c = input()                     # 인풋값 받기
num = ord('A') - ord('@')       # num = 1
z_to_a = ord('Z') - ord('@')    # z_to_a = 26
natural = ord(c) - ord('@')     # natural = 대문자 알파벳에 대한 자연수 (1~26) 대입

if nat(c) > z_to_a:              # nat(c)이 26보다 크면
    print(chr((nat(c) % z_to_a) + ord('@'))) # 26으로 나눈 나머지값에 맞게 대문자 알파벳의 원래 아스키코드로 변환
else:
    print(chr(nat(c) + ord('@')))    # 26 이하일 경우, 해당 알파벳의 원래 아스키코드로 다시 변환