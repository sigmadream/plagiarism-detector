c = str(input())
x = int(ord('A') - ord('A'))        # 0
y = int(ord('B') - ord('A'))        # 1
z = int(ord('B') - ord('A')) + int(ord('B') - ord('A')) # 2
m = int(ord('Z')) - int(ord('A')) + y   # 26

def nct(c):
    return ord(c) - ord('A') + y

d = nct(c)**z + y

if d % m == 0:
    print('Z')
else:
    result = int(d % m) + ord('@')
    print(chr(result))