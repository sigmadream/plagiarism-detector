#coding: utf-8

c = input()

n = (ord(c)-ord('@'))**len('AA') + len('A')

if n%(ord('Z')-ord('@')) == len(''):
  res = chr(ord('Z'))
else:
  res = chr(n%(ord('Z')-ord('@'))+ord('@'))

print(res)

# 아스키코드와 len을 사용하여 숫자를 사용하지 않고 코드를 작성하였습니다.