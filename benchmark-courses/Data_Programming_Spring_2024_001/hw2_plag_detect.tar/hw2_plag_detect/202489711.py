a = input()

def m(a):
    b = ord(a) - ord('@')
    return b

n = m(a)**(ord('C')-ord('A')) + ord('B') - ord('A')

if n >= (ord('a')-ord('F')):
    n = n%(ord('a')-ord('G'))
else:
    n = n

print(chr(n + ord('@')))

