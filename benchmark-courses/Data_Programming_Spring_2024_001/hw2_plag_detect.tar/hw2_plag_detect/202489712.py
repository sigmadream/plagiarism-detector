                                                             # chr(1) = '\x01' 이므로 ord('\x01')를 써서 '1'을 만듦
                                                             # chr(26) = '\x1a' 이므로 ord('\x1a')를 써서 '26을 만듦

def ctn(i):                                                  # 기준 알파벳 'A'의 자연수를 만들어주기 위한 연산 함수 
    return ord(i) - ord('A') + ord('\x01')                   # ord(i) : Input data 'i' ASCII Code 값 반환
                                                             # ord('A') : 'A' ASCII 값 반환 
                                            
def cta(n):                                                  # 자연수를 다시 대문자 알파벳으로 반환하는 함수
    return chr((n - ord('\x01')) % ord('\x1a') + ord('A'))   # (n - 1) % 26 연산을 통해 숫자를 알파벳으로 변환 

def cal(i):                                                  # Input data(대문자 알파벳) 계산 함수 
    n = ctn(i)                                               # Input data을 자연수로 변환
    result = n*n + ord('\x01')                               # 변환된 자연수 값 제곱, 더하기 1 (숫자 사용 불가로 인해 제곱을 n*n 표현)
    return cta(result)                                       # 계산된 결과를 다시 알파벳으로 변환 
                                            
i = input()                                                  # 대문자 알파벳 입력

print(cal(i))                                                # 상기 함수를 거쳐 최종 계산