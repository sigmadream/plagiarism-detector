input = input()

def nat(input):
  n	=	ord(input) - ord('A')	+	len('a')
  return n

def csq(input):
  n = nat(input)**len('aa') + len('a')
  cut = ord("Z") + len('a') - ord("A")
  if n > cut:
    n = n%cut
    print(chr(n	+	ord('A') - len('a')))
  else:
    print(chr(n	+	ord('A') - len('a')))

csq(input)