# A~Z가 65부터 시작하는게 아니고 1~26으로 대응 시켜야한다. 함수로 정의..?
# 알파벳 대문자를 자연수로 간주하고 n^2+1
# n^2+1을 다시 알파벳 대문자로 변환하되, 27부터는 다시 1로 생각하여 출력. -> 나머지연산자(%)를 이욯하여 반복 실행.
# 자신만의 함수를 이용하여 알파벳 수 계산하고 코드에 숫자가 포함되지 않도록 하기..

def nat_calculate(n):
    return n*n + ord('B')-ord('A')

def input_and_calculate():
    a = input()
    n = ord(a) - ord('A') + ord('B')-ord('A')
    result = nat_calculate(n)
    return result

def num_to_letter(n):
    return chr((n-(ord('B')-ord('A'))) % (ord('Z')-ord('@')) + ord('A'))

result = input_and_calculate()
print(num_to_letter(result))