#include<iostream>
using namespace std;
#define HEAP 10

class Heap{
private:
    int* heap;
    int last;
public:
    Heap(int size): last(0) {heap = new int[size+1];}
    bool isEmpty() {return (last == 0) ? true : false;}
    int getParent(int i) {return (i>1) ? (i/2) : 0;}
    void changeNode(int i, int j);
    void sortUp();    
    void add(int data);
    void sortDown();
    int remove();
};
void Heap :: changeNode(int i, int j){
    int tmp = heap[i];
    heap[i] = heap[j];
    heap[j] = tmp;
}
void Heap::sortUp() {
    int tmp = last, parent;
    while(tmp > 1){
        parent = this->getParent(tmp);
        if (heap[parent] < heap[tmp]) changeNode(tmp, parent);
        else break;
        tmp = parent;
    }
}
void Heap :: add(int data){
    heap[++last] = data;
    this->sortUp();
}

void Heap :: sortDown(){
    int tmp = 1, max;
    while(tmp <= last/2){
        // 왼쪽, 오른쪽 중에 큰 것과 바꾸어야 한다.
        if (2*tmp + 1 > last){ // 오른쪽 child가 존재하지 않는 경우
            if (heap[tmp] < heap[2*tmp]) changeNode(tmp, 2*tmp);
            tmp *= 2;
        }
        else {  // right node 존재
            max = (heap[2*tmp] < heap[2*tmp + 1] ? 2*tmp + 1: 2*tmp);
            if (heap[tmp] < heap[max]) changeNode(tmp, max);
            tmp = max;
        }
    }
}

int Heap :: remove(){
    int result = heap[1];
    changeNode(1, last--);
    sortDown();
    return result;
}

int main(){
    int size;
    cin >> size;
    int *input = new int[size];
    for(int i = 0; i < size; i++) cin >> input[i];
    Heap heap(size);
    for(int i = 0; i < size; i++) heap.add(input[i]);
    for(int i = 0; i < size; i++){
        cout << heap.remove() << ((heap.isEmpty()) ? "" : " ");       
    }
}