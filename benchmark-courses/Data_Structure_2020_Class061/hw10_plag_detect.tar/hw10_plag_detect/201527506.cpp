#include <iostream>
#include <cmath>

using namespace std;

class MaxHeap {
public:
    MaxHeap();
    void insert(int data);
    int lchild(int pos) { return 2*pos + 1; }
    int rchild(int pos) { return 2*pos + 2; }
    int parent(int pos) { return (pos - 1) / 2; }
    int extractMax() { return heap[0]; }
    void Build_Max_Heap(int* heapArray, int heap_size);
    void MaxHeapify(int* heapArray, int i, int heap_size);
    void heapSort(int* heapArray, int heap_size);

private:
    int size;
    int* heap;
};

int main(void) {
	int n;
	cin >> n;
	int* arr = new int[n];
	for(int i=0; i<n; ++i)
		cin >> arr[i];

    MaxHeap M;
    M.heapSort(arr, n);
    for (int i=0; i<n-1; ++i) {
    	cout << arr[i] << ' ';
    }
    cout << arr[n-1];
    return 0;
}


MaxHeap::MaxHeap() {
    heap = NULL;
    size = 0;
}

void MaxHeap::insert(int data) {
    size++;
    int* tmp = new int[size];

    for (int i=0; i < size-1; i++) {
        tmp[i] = heap[i];
    }

    tmp[size-1] = data;
    delete[] heap;
    heap = tmp;
}

void MaxHeap::heapSort(int heapArray[], int heap_size) {
    size = heap_size;
    int n = size;
    Build_Max_Heap(heapArray, heap_size);

    for (int i=n-1; i>=1; i--) {
        swap(heapArray[0], heapArray[i]);
        heap_size = heap_size - 1;
        MaxHeapify(heapArray, 0, heap_size);
    }
}

void MaxHeap::Build_Max_Heap(int* heapArray, int heap_size) {
    int n = size;
    for (int i = int((n-1) / 2); i>=0; i--) {
        MaxHeapify(heapArray, i, heap_size);
    }
    return;
}

void MaxHeap::MaxHeapify(int* heapArray, int i, int heap_size) {
    int max = 0;
    int left = lchild(i);
    int right = rchild(i);
    
    if ((left < heap_size) && (heapArray[left] < heapArray[i])) {
        max = left;
    } else {
        max = i;
    }

    if ((right < heap_size) && (heapArray[right] < heapArray[max])) {
        max = right;
    }

    if (max != i) {
        swap(heapArray[i], heapArray[max]);
        MaxHeapify(heapArray, max, heap_size);
    }
    return;
}


