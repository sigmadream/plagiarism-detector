#include <iostream>

using namespace std;
int n, heap[256];

void heapify(int i)
{ 
	int node = 2 * i;
	if(node < n && heap[node] > heap[node+1]) node++;
	if(heap[i] > heap[node])
	{
		swap(heap[i],heap[node]);
		if(node <= n/2) heapify(node);
	}
}

void heapsort(int i)
{
	swap(heap[1],heap[i]);
	int root = 1;
	int node = 2;
	while(node/2<i)
	{
		node = 2*root;
		if(node < i-1 && heap[node] > heap[node+1]) node++;
		if(node < i && heap[root] > heap[node])
			swap(heap[root],heap[node]);
		root = node;
	}
}

int main() 
{
	scanf("%d",&n);
	for(int i = 1; i <= n; i++)
		scanf("%d",&heap[i]);
	
	for(int i = n/2; i > 0; i--) 
		heapify(i);

	for(int i = n; i > 0; i--)
		heapsort(i);

	for(int j = 1; j <= n; j++)
		if(j!=n) printf("%d ",heap[j]);
		else printf("%d",heap[j]);
}
