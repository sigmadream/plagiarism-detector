#include <iostream>
/*
Author: Chunsu Kim
Number: 201624458
Date: 2020-11-18
Lab 10 heapsort
*/
using namespace std;
int n,heap[100];
class CBTree {
private:
    int* elems, size;
    void InOrderWithIdx(int i, ostream& out) {
        if (i < 0 || i >= size) return;
        InOrderWithIdx(2 * i + 1, out);
        out << elems[i] << endl;
        InOrderWithIdx(2 * i + 2, out);
    }
public:
    CBTree(int sz, int ns[]) :size(sz) {
        elems = new int[sz];
        for (int i = 0; i < sz; i++)
            elems[i] = ns[i];
    }
    void InOrder(ostream& out) {
        InOrderWithIdx(0, out);
    }
    void makeHeap(int n) {
        for (int i = n; i > 0   ; i--)
        {
            int cur = 2 * i;
            if (cur < n && elems[cur] < elems[cur + 1]) cur++;
            if (elems[i] < elems[cur])
            {
                swap(elems[i], elems[cur]);
                if (cur <= n / 2) makeHeap(cur);
            }
        }
    }
    void heapsort(int n) {
        for (int i = n ; i > 0; i--)
        {
            swap(elems[1], elems[i]);
            int root = 1;
            int cur = 2;
            while (cur / 2 < i)
            {
                cur = 2 * root;
                if (cur < i - 1 && elems[cur] < elems[cur + 1]) cur++;
                if (cur < i && elems[root] < elems[cur])
                    swap(elems[root], elems[cur]);
                root = cur;
            }
        }
    }
    void print(int n)
    {
        for (int i = n; i >= 1; i--)
        {
            cout << elems[i]<<" ";
        }
    }
};

int main() {
    cin >> n;
    for (int i = 1; i <= n;i++)
        cin >> heap[i];
    int sz = sizeof heap / sizeof * heap;
    CBTree tree(sz, heap);
    tree.makeHeap(n/2);
    tree.heapsort(n);
    tree.print(n);
    //tree.InOrder(cout);
}
