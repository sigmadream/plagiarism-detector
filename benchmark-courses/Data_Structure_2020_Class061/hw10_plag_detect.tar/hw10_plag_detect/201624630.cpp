#include <bits/stdc++.h>
#include <iostream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main( ) {
	int a;
	int arr[10010];
	
	cin >> a;
	for(int i = 0; i < a; i++){
		cin >> arr[i];
	} // my array
	
	int n = sizeof(arr) / sizeof(arr[0]);
	

	sort(arr,arr+a);
	
	for(int i =a-1; i > 0; i --){
		cout << arr[i] << " ";
}
	cout <<arr[0];


	return 0;
}
