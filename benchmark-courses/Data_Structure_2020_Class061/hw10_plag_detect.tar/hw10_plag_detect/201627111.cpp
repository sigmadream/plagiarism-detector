#include <iostream>

using namespace std;

class CBTree {
private:
    int *elems, size, flag;

public:
    CBTree(int sz): size(sz) {
        elems = new int[sz+1];
        flag = 0;
    }
    void add(int item) {
        int here = ++flag;
        while ((here!=1)&&(item>elems[here/2])){
            elems[here] = elems[here/2];
            here /=2;
        }
        elems[here] = item;

    }

    bool isEmpty() {
        return !(flag);
    }

    /*
    void print(ostream &out) {
        for (int i=1; i<size+1;i++)
            out << "elems[" << i << "] : " <<elems[i] << endl;
    }*/

    int remove() {
        if(isEmpty())
            return -1;
        int pop = elems[1];
        elems[1] = elems[flag--];
        int parent = 1;
        int child;

        while(1) {
            child = parent * 2;
            if ((child +1 <= flag) && (elems[child]<elems[child+1]))
                child++;
            if ((child>flag) || elems[child] < elems[parent])
                break;
            int temp = elems[parent];
            elems[parent] = elems[child];
            elems[child] = temp;
            parent = child;
        }
        return pop;
    }
};

int main() {
    int sz;
    int *ns;
    cin >> sz;                  //get a size from cin
    ns = new int[sz];

    for(int i=0;i<sz;i++) {     //get elements from cin
        cin >> ns[i];
    }

    CBTree tree(sz);

    for (int i=0; i<sz; i++) {  // put elements to the binary tree
        tree.add(ns[i]);
    }

    //tree.print(cout);         // check the binary tree
    
    for (int i=0; i<sz; i++) {  // pop the root of the binary tree
        cout << tree.remove();      
        if (i!=sz-1)
            cout << ' ';
    }

    return 0;
}