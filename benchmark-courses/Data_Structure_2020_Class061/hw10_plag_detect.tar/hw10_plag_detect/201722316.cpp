#include <iostream>

using namespace std;

class Heap
{
public:
    int size = 0;
    int *Heaplist = new int[size];
    Heap add(int data)
    {
        int Cindex;
        int Pindex;
        int tmpdata;
        size++;
        Heaplist[size - 1] = data;
        Cindex = size;
        Pindex = Cindex / 2;
        while (true)
        {
            if (size == 1) break;
            if (Heaplist[Cindex - 1] > Heaplist[Pindex - 1])
            {
                tmpdata = Heaplist[Pindex - 1];
                Heaplist[Pindex - 1] = Heaplist[Cindex - 1];
                Heaplist[Cindex - 1] = tmpdata;
                Cindex = Pindex;
                Pindex = Cindex / 2;
                if (Pindex == 0) break;
            }
            else
                break;
        }
        return *this;
    }
    Heap operator+(int data)
    {
        Heap result = *this;
        return result.add(data);
    }
    int remove()
    {
        int val;
        int index = 1;
        int C1index, C2index;
        int tmpdata;
        val = Heaplist[0];
        Heaplist[0] = Heaplist[size - 1];
        size--;
        while (true)
        {
            int bigger;
            C1index = index * 2;
            C2index = (index * 2) + 1;
            if (C1index > size)
                break;
            else if (C2index > size)
                C2index = C1index;
            if (Heaplist[C1index - 1] > Heaplist[C2index - 1])
                bigger = C1index;
            else
                bigger = C2index;
            if (Heaplist[index - 1] < Heaplist[bigger - 1])
            {
                tmpdata = Heaplist[index - 1];
                Heaplist[index - 1] = Heaplist[bigger - 1];
                Heaplist[bigger - 1] = tmpdata;
                index = bigger;
            }
            else
                break;
        }
        return val;
    }
    ostream &print(ostream &out)
    {
        int repeat = size;
        for (int i = 0; i < repeat - 1; i++)
        {
            out << remove() << ' ';
        }
        out << remove();
        return out;
    }
};

int main()
{
    int num;
    int inputnum;
    Heap HS;
    cin >> num;
    for (int i = 0; i < num; i++)
    {
        cin >> inputnum;
        HS = HS + inputnum;
    }
    HS.print(cout);
}
