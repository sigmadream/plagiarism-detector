#include <iostream>

using namespace std;

class Heap {
private:
    int *elem, MAX_SIZE, count;
public:
    // constructor
    Heap(int sz) : MAX_SIZE(sz){
        elem = new int[sz];
        count = 0;
    }

    void add(int data) {
        // heap is full condition
        if (count == MAX_SIZE)
            return;
        elem[count] = data;

        if (count == 0){
            count++;
            return; 
        }
        int child = count;
        int parent = (count-1)/2;
        while (elem[parent] < elem[child] && child > 0) {
            int temp = elem[child];
            elem[child] = elem[parent];
            elem[parent] = temp;
            child = parent;
            parent = (child-1)/2;
        }
        count++;
    }

    int remove() {
        int rv = elem[0];
        count--;
        // swap last element with first element
        elem[0] = elem[count];
        elem[count] = rv;

        // 힙이 조건 만족하도록 swap
        int parent = 0;
        int child = parent * 2 + 1;
        // left, right child 중 더 큰 값 선택
        if (child + 1 <= count-1) 
            child = (elem[child] > elem[child+1])?child:child+1;
        while(child <= count-1 && elem[parent] < elem[child]) {
            int temp = elem[child];
            elem[child] = elem[parent];
            elem[parent] = temp;
            parent = child;
            child = parent*2 + 1;
            // left, right child 중 더 큰 값 선택
            if (child + 1 <= count-1) {
                 child = (elem[child] > elem[child+1])?child:child+1;
            }
        }
        return rv;
    }

    int size(){
        return count;
    }

    bool isEmpty() {
        return count==0;
    }
};

int main() {
    int n;
    cin >> n;
    Heap heap(n);
    for (int i = 0; i < n; i++) {
        int data;
        cin >> data;
        heap.add(data);
    }

    while(!heap.isEmpty()) {
        cout << heap.remove() << ((heap.isEmpty())?"\n":" ");
    }
    return 0;
}