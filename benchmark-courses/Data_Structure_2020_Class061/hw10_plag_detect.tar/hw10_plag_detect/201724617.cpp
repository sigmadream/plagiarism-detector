#include <iostream>
using namespace std;

class MaxHeap {
private:
    int *elems, maxSize, cntEle;
    void InOrdWithIdx(int i, ostream &out) {
        if (i < 0 || i >= cntEle) return;
        InOrdWithIdx(i * 2 + 1, out);
        out << elems[i];
        if(i<cntEle) out << "=";
        InOrdWithIdx(i * 2 + 2, out);
    }
public:
    MaxHeap(int sz): maxSize(sz) {
        elems = new int[sz];
        cntEle = 0;
    }
    void InOrder(ostream &out) {
        InOrdWithIdx(0, out);
    }

    bool IsEmpty(){
        if(cntEle==0) return true;
        else return false;
    }

    const int Size(){ return maxSize; } // return max size

    void Add(const int n){
        elems[cntEle] = n;
        int tmp = cntEle;
        while(tmp != 0){
            if(tmp%2){ // left child (odd index)
                if(elems[tmp] > elems[(tmp-1)/2]){
                    ChangeEle(elems[(tmp-1)/2], elems[tmp]);
                    tmp = (tmp-1)/2;
                }else break;
            }else{ // right child (even index)
                if(elems[tmp] > elems[(tmp/2)-1]){
                    ChangeEle(elems[(tmp/2)-1], elems[tmp]);
                    tmp = (tmp/2)-1;
                }else break;
            }
        }
        cntEle++;
    }
    const int Remove(){ // remove top element
        if(cntEle<0) exit(-1);
        int retVal = elems[0];
        cntEle--;
        elems[0] = elems[cntEle];
        int tmp = 0;
        while(true){
            if((2*tmp+2 < cntEle) && (elems[2*tmp+1] < elems[2*tmp+2])){
                if(elems[2*tmp+2] > elems[tmp]){
                    ChangeEle(elems[2*tmp+2], elems[tmp]);
                    tmp = 2*tmp+2;
                }else break;
            }else if(2*tmp+1 < cntEle){
                if(elems[2*tmp+1] > elems[tmp]){
                    ChangeEle(elems[2*tmp+1], elems[tmp]);
                    tmp = 2*tmp+1;
                }else break;
            }else break;
        }
        return retVal;
    }
    void ChangeEle(int &a, int &b){
        int tmpVal = a; a = b; b = tmpVal;
    }

    MaxHeap operator +(const int n){ // + operator -> doing add node
        Add(n);
        return *this;
    }
    MaxHeap operator =(MaxHeap h){ // = operator -> just return MaxHeap pointer
        return h;
    }
    friend ostream& operator << (ostream& os, MaxHeap& H); // cout operator

};

ostream& operator << (ostream& os, MaxHeap& H){
    for(int i=1; i<=H.Size(); i++){
        os << H.Remove();
        if(i!=H.Size()) os << " "; // just for blank print.
    }
    return os;
}

int main() {
    int n, k;
    cin >> n; // size of elements

    MaxHeap heap(n);
    for(int i=0; i<n; i++){
        cin >> k; heap = heap + k;
    }

    cout << heap;
}
