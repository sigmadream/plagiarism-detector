#include <iostream>
using namespace std;

class Heap{

private:
  int Heap_size=0;
  int *elems;

public:

  Heap(int sz, int ns[]): Heap_size(sz){
    elems = new int[sz];

    for(int i = 0 ; i< sz;i++){
      elems[i] = ns[i];
    }
    sort(sz);
  }
/*
  void Heap_root(int size, int i){

    int largest = i;

    int l =2*i+1;
    int r =2*i+2;

    if(l < size && this->elems[l] > this->elems[largest])
      largest = l;

    if(r < size && this->elems[r] > this->elems[largest])
      largest = r;

    if(largest != i){
      swap(this->elems[i], this->elems[largest]);
      Heap_root(size, largest);
      }

  }*/

  void sort(int size){
    for(int i=1; i<size;i++){
      if(this->elems[0] <= this->elems[i]){
        swap(this->elems[0],this->elems[i]);
        //Heap_root(size,i);
      }
    }
  }
  

  bool isEmpty(int ns[]){
    return (this->Heap_size == 0);
  }

  void add(int input){
    this->Heap_size++;
    this->elems = new int;
    this->elems[this->Heap_size]=input;
    sort(this->Heap_size);
  }

  int remove(int key){
    int root= this->elems[key];
    for(int i=key;i<this->Heap_size;i++){
      swap(this->elems[i], this->elems[i+1]);
    }
    this->elems[Heap_size]=0;
    this->Heap_size--;
    sort(this->Heap_size);
    return root;
  }
  
  int size(){
    return this->Heap_size;
  }

};


int main() {

  int size;
  int *input;

  cin>>size;

  for(int i=0;i<size;i++){
    cin>>input[i];
  }
  Heap h(size,input);

  for(int i=0;i<size;i++){
    cout<<h.remove(0);
    if(i != size-1)
      cout<<" ";
  }

}