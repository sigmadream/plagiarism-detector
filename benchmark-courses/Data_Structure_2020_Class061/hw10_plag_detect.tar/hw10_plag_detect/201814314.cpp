#include<iostream>

using namespace std;

void test(int n) {cout << "test" << n;}

class CBTree {
private:
    int *elems, size;
    void InOrdWithIdx(int i, ostream &out) {
        if (i<0 || i>= size) return;
        InOrdWithIdx(i*2+1, out);
        out << elems[i] << endl;
        InOrdWithIdx(i*2+2, out);
    }
public:
    CBTree(int sz): size(sz) {
        elems = new int[sz];
        for(int i=0; i<sz; ++i) {
            cin >> elems[i];
            InOrderSort(i);
        }
    }
    void InOrderSort(int i) {
        if(i<0 || i>size) return;
        int temp;
        int j = (i-1) / 2;
        int k = i; 
        while(true){
            if(j<0) break;
            if(elems[k]>elems[j]) {
                temp = elems[k];
                elems[k] = elems[j];
                elems[j] = temp;
                k = j;
            }
            if(j == 0) break;
            j = (j-1)/2;
        }
    }
    void print(ostream &out) {
        for(int i=0; i<size; ++i)
            out << elems[i] << " ";
        out << endl;
    }
    void InOrder(ostream &out) {
        int sz = size;
        for(int i=0; i<sz; ++i){
            out << elems[0] << " ";
            elems[0] = elems[size-1];
            elems[size-1] = -100;
            size--;
            Sorting();
        }
        cout << endl;
    }
    void Sorting() {
        int j=0;
        int k=0;
        int temp;
        while(true) {
            if(j >= size) break;
            if(elems[k] < elems[j]) {
                if(elems[j] > elems[j+1]) {
                    temp = elems[k];
                    elems[k] = elems[j];
                    elems[j] = temp;
                    k = j;
                }
                else {
                    temp = elems[k];
                    elems[k] = elems[j+1];
                    elems[j+1] = temp;
                    k = j + 1;
                }
            }
            j = (j * 2) + 1;
        }
    }
    bool isEmpty() {
        for(int i=0; i<size; ++i)
            if(elems[i] != -100) return false;
        return true;
    }
    int getSize() {
        return size;
    }
    

};

int main() {
    int sz;
    cin >> sz;
    CBTree tree(sz);
    tree.InOrder(cout);
}