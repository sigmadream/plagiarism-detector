#include <iostream>

using namespace std;

class Heap {
private:
  int *elems;
  int hSize;
public:
  Heap(int sz, int ns[]): hSize(0) {
    elems = new int[sz];
    for(int i=0; i<sz; i++) {
      add(ns);
    }
  }

  bool isEmpty() {
    return hSize == 0; // if empty, return 1
  }
  void add(int ns[]) {
    elems[hSize] = ns[hSize];
    moveUp(hSize);
    hSize++;
  }
  void remove() {
    while(1) {
      if(isEmpty()) break;
      else if(hSize > 1) {
        int temp = elems[hSize-1];
        elems[hSize-1] = elems[0];
        elems[0] = temp;  // heap root remove
        moveDown();
      }
      hSize--;
    }
  }
  int size() {
    return hSize;
  }
  void moveUp(int startIdx) {  // sorting start with startIdx
    int tmpSz = startIdx;
    while(tmpSz != 0) {
        int root = elems[(tmpSz-1)/2];
        int child = elems[tmpSz];
        if(root < child) {
          int temp = root;
          elems[(tmpSz-1)/2] = child;
          elems[tmpSz] = temp;
        }
        tmpSz = (tmpSz-1)/2;
    }
  }
  void moveDown() {
    int tmpSz = 0;
    while(1) {
      int nextSz;
      int maxChild;
      int root = elems[tmpSz];
      if((tmpSz*2 + 1) == (hSize - 2)) {
        maxChild = elems[tmpSz*2 + 1];
        nextSz = tmpSz*2 + 1;
      } else if((tmpSz*2 + 1) > (hSize - 2)) {
        break;
      } else {
        if(elems[tmpSz*2 + 1] > elems[tmpSz*2 + 2]) {
          maxChild = elems[tmpSz*2 + 1];
          nextSz = tmpSz*2 + 1;
        } else {
          maxChild = elems[tmpSz*2 + 2];
          nextSz = tmpSz*2 + 2;
        }
      }
      
      if(root < maxChild) {
        int temp = root;
        elems[tmpSz] = maxChild;
        elems[nextSz] = temp;
      }
      tmpSz = nextSz;
    }
  }

  class Iterator {
  private:
    int *curr;
  public:
    Iterator(int *np=nullptr): curr(np) {}

    Iterator& operator =(const Iterator &p) {
      curr = p.curr;
      return *this;
    }
    bool operator >=(const Iterator &p) {
      return this->curr >= p.curr;
    }
    bool operator !=(const Iterator &p) {
      return this->curr != p.curr;
    }
    int operator *() {
      return *curr; // ok
    }
    int* operator --() {
      return curr -= 1;
    }
  };

  Iterator begin() {
    return elems; // ok
  }

  Iterator end(int sz) {
    return elems + sz - 1;
  }

  ostream& print(ostream& out, int sz) {
    for(Iterator p = end(sz); p>=begin(); --p) {
      out << *p << (p != begin()? " ": "\n");
    }
    return out;
  }
};

int main() {
  int num, sz;
  cin >> num;
  int ns[num];
  for(int i=0; i<num; i++) {
    cin >> ns[i];
  }
  sz = sizeof ns / sizeof *ns;

  Heap tree(sz, ns);
  tree.remove();
  tree.print(cout, sz);
}