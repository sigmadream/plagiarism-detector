#include <iostream>
#include <cassert>

using namespace std;

class Node {
    int   data;
    Node *next;
public:
    friend class CBTree;
    Node(int d, Node *n): data(d), next(n) {}
};


class CBTree {
private:
    int *elems, size;
    Node* fst;


public:
    CBTree(): fst(nullptr) {}

    CBTree(int sz): size(sz){
        int total = sz;
        add();

        int *save= new int[total];
        for (int i = 0 ; i < total ; i++){
            save[i] = remove();

        }
        for (int i =total-1 ; i >= 0 ; i--){
            push(save[i]);
        }
        delete elems;
        elems = save;

    }

    void push(int n) {
        Node *prev = fst;
        fst = new Node(n, prev);
    }


    int remove(){
        if(size-1 ==0)
            return elems[0];
        int decrease = size - 1 ;
        int num = elems[0];
        int* temp_elems = new int[decrease];
        elems[0] = elems[decrease];
        recursive();

        for (int i = 0; i<decrease; i++){
            temp_elems[i] = elems[i];
        }
        size -= 1;
        delete elems;
        elems = temp_elems ;
        return num;
    }

    bool isEmpty() {
        return fst == nullptr;
    }

    int* add() {
        int k = size;
        int n;
        elems = new int[size];
        for (int i = 0; i < k; i++) {
            cin >> n;
            elems[i] = n;
            if (i>=1) {
                if (elems[(i - 1) / 2] < elems[i]) {
                    int temp = elems[i];
                    elems[i] = elems[(i - 1) / 2];
                    elems[(i - 1) / 2] = temp;
                }
            }
        }
        recursive();
        return elems;
    }
    void recursive(){
        int cnt =0;
        int com_num= 0;
        while(com_num == cnt){
            for (int i = 0; i < size; i++) {
                if (i>=1) {
                    if (elems[(i - 1) / 2] < elems[i]) {
                        int temp = elems[i];
                        elems[i] = elems[(i - 1) / 2];
                        elems[(i - 1) / 2] = temp;
                        cnt++;
                    }
                    com_num++;
                }
            }
        }
    }

     class Iterator {
        Node *curr;
    public:
        Iterator(Node *np=nullptr): curr(np) {}
        Iterator& operator =(const Iterator &p) {
            curr = p.curr;
            return *this;
        }
        bool operator !=(const Iterator &p) {
            return this->curr != p.curr;
        }
        int operator *() {
            return curr->data;
        }
        Node* operator ++() {
            return (curr = curr->next);
        }
        Iterator operator +(int delta) {
            assert(delta >= 0);
            Node *p = curr;
            while (delta-- > 0) {
                p = p->next;
            }
            return p;
        }
    };

    Iterator begin() {
        return fst;
    }
    Iterator end() {
        return nullptr;
    }

    ostream& print(ostream& out) {
        for (Iterator p = begin(); p != end(); ++p) {
            out << *p << (p + 1 != end()? " ": "\n");
        }
        return out;
    }

};

int main() {
    int k;
    cin >> k;
    CBTree tree(k);
    tree.print(cout);
}
