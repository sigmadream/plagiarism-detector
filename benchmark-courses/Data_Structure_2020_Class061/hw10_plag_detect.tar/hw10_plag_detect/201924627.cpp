#include <iostream>
#include <climits>
using namespace std;

void swapKeys(int *x, int *y) {
	*x += *y;
	*y = *x - *y;
	*x -= *y;
}

class Heap {
private:
	int *arr;
	int max_size, cur_size;
public:
	Heap(int n): max_size(n), cur_size(0) {
		arr = new int[max_size];
	}
	
	int getParentId(int i) {
		return (i - 1) / 2;
	}
	
	int getLeftId(int i) {
		return 2 * i + 1;
	}
	
	int getRightId(int i) {
		return 2 * i + 2;
	}
	
	void add(int k) {
		if(cur_size  == max_size) {
			cerr << "Maximum capacity is reached, cannot add new key.\n";
			return;
		}
		
		cur_size++;
		int i = cur_size - 1;
		arr[i] = k;
		
		while(i != 0 && arr[getParentId(i)] < arr[i]) {
			swapKeys(&arr[i], &arr[getParentId(i)]);
			i = getParentId(i);
		}
	}
	
	int remove() {
		int tmp = arr[0];
		cur_size--;
		arr[0] = arr[cur_size];
		heapify(0);
		return tmp;
	}
	
	void heapify(int i) {
		int l = getLeftId(i), r = getRightId(i);
		int greatest = i;
		
		if(l <= cur_size && arr[l] > arr[greatest]) {
			greatest = l;
		}
		if(r <= cur_size && arr[r] > arr[greatest]) {
			greatest = r;
		}
		
		if(greatest != i) {
			swapKeys(&arr[greatest], &arr[i]);
			heapify(greatest);
		}
	}
	
	bool size() {
		return cur_size;
	}
};

int main() {
	int n, k;
	cin >> n;
	
	Heap h(n);
	
	for(int i = 0; i < n; i++) {
		cin >> k;
		h.add(k);
	}
	
	for(int i = 0; i < n - 1; i++) {
		cout << h.remove() << ' ';
	}
	cout << h.remove();
	
	return 0;
}
