#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>

using namespace std;

class Heap {
    private:
        std::vector<int> result;
        void MaxHeap(int idx){
            int maxVal = idx;
            if ((idx << 1) < result.size() && result[maxVal] < result[idx << 1]){
                maxVal = idx << 1;
            }
            if ((idx << 1) + 1 < result.size() && result[maxVal] < result[(idx << 1) + 1]){
                maxVal = (idx << 1) + 1;
            }
            if (idx != maxVal){
                std::swap(result[idx], result[maxVal]);
                MaxHeap(maxVal);
            }
        };
    public:
        Heap() { result.push_back(0); }
        explicit Heap(vector<int> input) {
            result.push_back(0);
            result.insert(result.end(), input.begin(), input.end());
            for (int i = result.size() / 2; i > 0; --i){
                MaxHeap(i);
            }
        }
        void Add(int value);
        void Remove();
        int TopValue();
        bool IsEmpty();
};

void Heap::Add(int value) {
    this -> result.push_back(value);
    int current = result.size() - 1;
    while (current != 1){
        if (result[current] > result[current >> 1]){
            std::swap(result[current], result[current >> 1]);
            current >>= 1;
        }
        else break;
    }
}

void Heap::Remove() {
    if (result.size() == 1) 
        return;
    std::swap(result[1], result[result.size() -1]);
    result.pop_back();
    int current = 1;
    while (current < result.size()) {
        int maxVal = current;
        if ((current << 1) < result.size() && result[current << 1] > result[maxVal]) {
            maxVal = current << 1;
        }
        if ((current << 1) + 1 < result.size() && result[(current << 1) + 1] > result[maxVal]){
            maxVal = (current << 1) + 1;
        }
        if (maxVal != current){
            std::swap(result[current], result[maxVal]);
            current = maxVal;
        }
        else break;
    }
}

int Heap::TopValue() { return result[1]; }
bool Heap::IsEmpty() { return result.size() <= 1; }

int main() {
    Heap *hp = new Heap();
    vector<int> returnVal;
    int size, input;
    cin >> size;
    for (int i = 0; i < size; i++) {
        cin >> input;
        hp -> Add(input);
    }
    while (!hp -> IsEmpty()) {
        int top = hp -> TopValue(); 
        hp -> Remove();
        returnVal.push_back(top);
    }
    for (int i = 0; i < returnVal.size(); i++) {
        if (i == returnVal.size() -1){
            cout << returnVal[i] << endl;
        }
        else
        {
            cout << returnVal[i] << " ";
        }
        
    }
    return 0;
}
