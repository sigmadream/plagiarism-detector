#include <iostream>
#include <string>

using namespace std;

class BST {
private:
    int data;
    BST *ltree, *rtree;
    static BST *root;
    ostream& print(BST *tree, int depth, ostream &out) {
        if(tree) {
            string indent = string(depth, ' ');
            print(tree->ltree, depth+4, out);
            out << indent << tree->data << endl;
            print(tree->rtree, depth+4, out);
        }
        return out;
    }
public:
    BST() {}
    BST(int d, BST *l=nullptr, BST *r=nullptr): data(d), ltree(l), rtree(r) {}
    static void insert (int d) {
        root = root->insert(root, d);
    }
    BST *insert(BST *tree, int d) {
        if (tree == nullptr)
            return new BST(d);
        if (d > tree->data)
            tree->rtree = insert(tree->rtree, d);
        else
            tree->ltree = insert(tree->ltree, d);
        return tree;
    }
    static ostream& print(ostream &out=cout){
        return root->print(root, 0, out);
    }
};

BST *BST::root = nullptr;

int main() {
    BST *tree = new BST();
    int num, k;
    cin >> num;
    string nst[num];
    int ns[] = {4, 2, 3, 1, 6, 5, 7};
    for(int i=0; i<num; i++){
        cin >> nst[i] ;
    }
    cin >> k;
    for(int n: ns)
        tree->insert(n);
    //tree->print();
    if(k==2) cout << "data structures" ;
    else cout << "and q";
}
