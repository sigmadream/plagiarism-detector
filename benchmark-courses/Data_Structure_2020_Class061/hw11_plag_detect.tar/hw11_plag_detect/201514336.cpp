#include <iostream>
#include <string>

using namespace std;

class BST{
	int data;
	BST *ltree, *rtree;
	static BST *root;
public:
	BST() {}
	BST(int d, BST *l=nullptr, BST *r=nullptr): data(d), ltree(l), rtree(r) {}
	static void insert(int d){
		root = root->insert(root, d);
	}
	BST *insert(BST *tree, int d){
		if (tree == nullptr)
			return new BST(d);
		if (d > tree->data)
			tree->rtree = insert(tree->rtree, d);
		else
			tree->ltree = insert(tree->ltree, d);
		return tree;
	}
	static ostream& print(ostream &out=cout){
		return root->print(root, 0, out);
	}
	ostream& print(BST *tree, int depth, ostream &out){
		if (tree){
			string indent = string(depth, ' ');
			print(tree->ltree, depth+4, out);
			out << indent << tree->data << endl;
			print(tree->rtree, depth+4, out);
		}
		return out;
	}
}; 

BST *BST::root = nullptr;

int main(){
	BST *tree = new BST();
	int ns[] = {4, 1, 2, 3, 6, 5, 7};
	for (int n: ns)
		tree->insert(n);
	tree->print();
}
