#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct et
{
    string value;
    et* left, *right;
};

et* newNode(string v)
{
    et *temp = new et;
    temp->left = temp->right = NULL;
    temp->value = v;
    return temp;
};

int main()
{
	int i, number;
	cin >> number;
	string Tree[number];
	for(i=0;i<number;i++)
		cin >> Tree[i];
	
	/*
	cout << Tree[0].compare(Tree[1])<<endl; // -1 a<b�� �� (�����ʰ� ũ��) 
	cout << Tree[1].compare(Tree[0])<<endl; // 1 b>a�� �� (������ ũ��) 
	cout << Tree[1].compare(Tree[1])<<endl; // 0 �ΰ� ���� 
	cout << Tree[].length() << endl;
	int call;
	cin >> call;
	*/
}
