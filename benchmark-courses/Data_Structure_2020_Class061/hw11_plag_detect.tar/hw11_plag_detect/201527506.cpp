#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int MAX=0;
vector<string> v;

bool in(string s){
    for(int i=0; i<v.size(); ++i){
        if(v[i]==s)
            return true;
    }
    return false;
}

class BST {
	string data;
	BST *ltree, *rtree;
	static BST *root;
public:
	BST() {}
	BST(string d, BST *l=NULL, BST *r=NULL): data(d), ltree(l), rtree(r) {}
	static void insert(string d) {
		root = root->insert(root, d);
	}
	BST *insert(BST *tree, string d) {
		if (tree == NULL)
			return new BST(d);
		if (d > tree->data)
			tree->rtree = insert(tree->rtree, d);
		else
			tree->ltree = insert(tree->ltree, d);
			return tree;
		}
	static ostream& print(ostream &out=cout) {
		return root->print(root, 1, out);
	}
	ostream& print(BST *tree, int depth, ostream &out) {
		if (tree) {
			print(tree->ltree, depth+1, out);
			out << tree->data << " depth=" << depth << endl;
			print(tree->rtree, depth+1, out);
		}
		return out;
	}
    static void get_depth(void){
        return root->get_depth(root, 1);
    }

	void get_depth(BST *tree, int depth) {
		if (tree) {
			get_depth(tree->ltree, depth+1);
            if(depth >= MAX)
                MAX = depth;
            get_depth(tree->rtree, depth+1);
		}
	}

    static void push_by_depth(int target){
        return root->push_by_depth(root, 1, target);
    }

	void push_by_depth(BST *tree, int depth, int target) {
		if (tree) {
			push_by_depth(tree->ltree, depth+1, target);
            if(depth == target){
                if(in(tree->data) == false)
                    v.push_back(tree->data);
            }
            push_by_depth(tree->rtree, depth+1, target);
		}
	}
    static void print_root(void){
        return root->print_root(root);
    }

	void print_root(BST *tree) {
        cout << root->data;
	}
	
	static void push_leaf(void){
		return root->push_leaf(root);
	}
	void push_leaf(BST *tree){
		if(tree){
			push_leaf(tree->ltree);
			if(tree->ltree==NULL && tree->rtree==NULL){
				v.push_back(tree->data);
			}
			push_leaf(tree->rtree);
		}
	}
};

BST *BST::root = NULL ;

int main() {
	BST *tree = new BST();
    int n, k;
    cin >> n;
    string* ns = new string[n];

    for(int i=0; i<n; ++i)
        cin >> ns[i];

    cin >> k;

	for (int i=0; i<n; ++i)
		tree->insert(ns[i]);
    
    tree->get_depth();
	// tree->print();

    if(k <= 0)
        tree->print_root();

    else if(k <= MAX){
        tree->push_by_depth(k);
        sort(v.begin(), v.end());

	    for(int i=0; i<v.size()-1; ++i)
	        cout << v[i] << ' ';
	
	    cout << v[v.size()-1];
    }
    
    else if(k > MAX){
    	tree->push_leaf();
        sort(v.begin(), v.end());

	    for(int i=0; i<v.size()-1; ++i)
	        cout << v[i] << ' ';
	
	    cout << v[v.size()-1];
	}


	return 0;
}
