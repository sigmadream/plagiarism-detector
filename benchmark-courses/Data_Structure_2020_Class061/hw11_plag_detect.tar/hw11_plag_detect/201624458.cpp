#include <iostream>
#include <string>
#include <string.h>
//Chunsu Kim 201624458 Data Structure Lab 11
using namespace std;
class BST {
private:
	string data;
	BST* ltree, * rtree;
	static BST* root;
	int _depth;
	int mydepth;
public:
	//static int _depth;
	BST() {}
	BST(string d, BST* l = nullptr, BST* r = nullptr) :data(d), ltree(l), rtree(r) {
		mydepth = 0;
		_depth = 0;
	}
	static void Insert(string d) {
		root = root->Insert(root, d);
	}
	BST* Insert(BST* tree, string d) {
		if (tree == nullptr)
			return new BST(d);
		const char* c1 = d.c_str();
		const char* c2 = tree->data.c_str();
		if (strcmp(c1, c2) > 0) {
			tree->rtree = Insert(tree->rtree, d);
			tree->mydepth = ++_depth;
		}else {
			tree->ltree = Insert(tree->ltree, d);
			tree->mydepth = ++_depth;
		}
		return tree;
	}
	static ostream& Print(ostream& out = cout) {
		return root->Print(root, 0, out);
	}
	ostream& Print(BST* tree, int depth, ostream& out) {
		if (tree) { //inorder
			string indent = string(depth, ' ');
			Print(tree->ltree, depth + 8, out);
			out << indent << tree->data << endl;
			Print(tree->rtree, depth + 8, out);
		}
		return out;
	}
	BST* Search(BST* tree,int depth) {
		//int depth = 0;
		//BST* tree = root;
		while (!tree) {
			if (depth == tree->mydepth) {
				cout << tree->data;
				return tree;
			}
		}
		return NULL;
	}
};
BST* BST::root = nullptr;
int main() {
	BST* tree = new BST();
	int n;
	cin >> n;
	string* ns = new string[n];
	for (int i=0;i<n;i++)
		cin >> ns[i];
	for (int i=0;i<n;i++)
		tree->Insert(ns[i]);
	//int n2 = sizeof(ns) / sizeof(ns[0]);
	int k;
	cin >> k;
	tree->Search(tree,k);
	//tree->Print();
}