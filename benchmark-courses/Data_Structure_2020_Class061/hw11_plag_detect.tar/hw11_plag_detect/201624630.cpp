﻿#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main() {
	int n;
	int k;

	cin >> n;


	vector<string> kal;
	for (int i = 1; i <= n; i++) {
		string d;
		cin >> d;
		kal.push_back(d);
	}

	cin >> k;


	if (k <= 0) {
		cout << kal[0];
	}
	else if (k % 2 == 0) {
		cout << kal[k - 1] << " ";
		cout << kal[k];
	}
	


	/*else {
		cout << kal[k];
		cout << kal[k + 1];
	}*/




}
