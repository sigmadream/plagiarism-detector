#include <iostream>
#include <string>
using namespace std;

class BST {
    string data;
    BST *ltree, *rtree;
    static BST *root;
    int depth;
public:
    BST() {}
    BST(string s, int i=1, BST *l=nullptr, BST *r=nullptr): data(s), ltree(l), rtree(r), depth(i) {}
    static void insert(string s) {
        root = root->insert(root, s, 0);
    }

    BST *insert(BST *tree, string s, int i) {
        if (tree == nullptr) {
            return new BST(s,i+1);
        }
        else {
            if (s > tree->data) 
                tree->rtree = insert(tree->rtree, s, tree->depth);
            else 
                tree->ltree = insert(tree->ltree, s, tree->depth);
        return tree;
        }
    }
    
    static ostream& pop(int k, ostream &out=cout) {
        return root->pop(root, k, out);
    }

    ostream& pop(BST *tree, int k, ostream &out) {
        if (tree) {
            if (tree->depth >= k)
                out << tree->data << ' ';
            else {
                if ((tree->ltree == nullptr) && (tree->rtree == nullptr))
                    out << tree->data << ' ';

                pop(tree->ltree, k, out);
                pop(tree->rtree, k, out);
            }
        }
        return out;
    }

};

BST *BST::root = nullptr;

int main() {
    BST *tree = new BST();
    int size = 0;
    int level = 0;

    cin >> size;
    string *input;
    input = new string[size];

    for(int i=0; i<size; i++) {
        cin >> input[i];
        tree->insert(input[i]);
    }

    cin >> level;
    tree->pop(level);
    cout << '\b';
    return 0;
}