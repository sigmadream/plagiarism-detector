#include <iostream>
#include <string>
using namespace std;

string a[1000];

int main() {
	int n,m;
	int i,j;
	
	cin >> n;
	
	for(i=0; i<n; i++)
		cin >> a[i];
		
	cin >> m;
	
	if(m==n)	cout << a[m-2] << " " << a[m-1];
	else if(m==1) cout << a[0] << " " << a[1];
	else	cout << a[m-1] << " " << a[m];
	
	return 0;
}
