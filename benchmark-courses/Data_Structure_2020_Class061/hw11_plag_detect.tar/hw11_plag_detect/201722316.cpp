#include <iostream>
#include <string>

using namespace std;

class BST
{
    string data;
    int depth;
    int maxdep = 1;
    BST *ltree, *rtree;
    static BST *root;
    int count = 0;

public:
    BST() {}
    BST(const string &d, int dep, BST *l = nullptr, BST *r = nullptr) : data(d), ltree(l), rtree(r), depth(dep) {}
    static void Insert(const string &d)
    {
        root = root->Insert(root, d, 1);
    }
    BST *Insert(BST *tree, const string &d, int dep)
    {
        if (tree == nullptr)
        {
            return new BST(d, dep);
        }
        if (d > tree->data)
            tree->rtree = Insert(tree->rtree, d, dep + 1);
        else
        {
            tree->ltree = Insert(tree->ltree, d, dep + 1);
        }
        if (dep + 1 > root->maxdep)
        {
            root->maxdep = dep + 1;
        }
        return tree;
    }
    static ostream &Print(int dep, ostream &out = cout)
    {
        if (dep <= 0)
            return root->Printa(root, dep, out);
        else if (dep > root->maxdep)
            return root->Printb(root, dep, out);
        else
            return root->Printc(root, dep, out);
    }
    ostream &Printa(BST *tree, int depth, ostream &out)
    {
        out << root->data;
        return out;
    }
    ostream &Printb(BST *tree, int depth, ostream &out)
    {
        if (tree)
        {
            Printb(tree->ltree, depth, out);
            if (tree->ltree == nullptr && tree->rtree == nullptr)
            {
                if (root->count == 0)
                {
                    out << tree->data;
                }
                else
                {
                    out << " " << tree->data;
                }
                root->count++;
            }
            Printb(tree->rtree, depth, out);
        }
        return out;
    }
    ostream &Printc(BST *tree, int depth, ostream &out)
    {
        if (tree)
        {
            Printc(tree->ltree, depth, out);
            if (tree->depth == depth)
            {
                if (root->count == 0)
                {
                    out << tree->data;
                }
                else
                {
                    out << " " << tree->data;
                }
                root->count++;
            }
            Printc(tree->rtree, depth, out);
        }
        return out;
    }
};

BST *BST::root = nullptr;

int main()
{
    BST *tree = new BST();
    int num;
    string word;
    cin >> num;
    for (int i = 0; i < num; i++)
    {
        cin >> word;
        tree->Insert(word);
    }
    int dep;
    cin >> dep;
    tree->Print(dep);
}
