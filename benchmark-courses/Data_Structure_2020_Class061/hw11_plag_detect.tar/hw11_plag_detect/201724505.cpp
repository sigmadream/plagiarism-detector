#include <string>
#include <iostream>

using namespace std;

class BinaryTree {
private:
    string data;
    BinaryTree *left, *right;
    static int maxDepth;
    static BinaryTree *root;
public:
    // constructor
    BinaryTree() : left(NULL), right(NULL){}
    BinaryTree(string str, BinaryTree *left = NULL, BinaryTree *right = NULL) 
    : data(str), left(left), right(right) {}

    void my_insert(string& str) {
        root = root->my_insert(root, str, 1);
    }
    BinaryTree* my_insert(BinaryTree *tree, const string& str, int depth) {
        if (tree == NULL) {
            maxDepth = (maxDepth>depth)?maxDepth:depth;
            return new BinaryTree(str);
        }
        if (str > tree->data) {
            tree->right = my_insert(tree->right, str, depth+1);
        }
        else {
            tree->left = my_insert(tree->left, str, depth+1);
        }
        return tree;
    }

    void my_print(int k) {
        if (k > maxDepth) 
            print_leave(root);
        else if (k <= 1)
            print_k(root, 1, 1);
        else
            print_k(root, k, 1);
    }

    void print_leave(BinaryTree *current) {  
        if (current == NULL)
            return;

        if (current->left == NULL && current->right == NULL) {
            int static printCnt = 0;
            cout << ((printCnt++)?" ":"") << current->data;
        }
        else  {
            print_leave(current->left);
            print_leave(current->right);
        }
    }
    
    void print_k(BinaryTree *current, int k, int current_depth) {
        if (current == NULL)
            return;
        if (current_depth == k) {
             int static printCnt = 0; 
            cout << ((printCnt++)?" ":"") << current->data;
        } else if (current_depth < k) {
            print_k(current->left, k, current_depth+1);
            print_k(current->right, k, current_depth+1);
        }
    }
};

BinaryTree *BinaryTree::root = NULL;
int BinaryTree::maxDepth = 0;

int main() {
    BinaryTree *tree = new BinaryTree();
    //string list[7] = {"alice", "in", "wonderland", "with", "r", "and", "q"};
    int n, k;
    cin >> n;
    for (int i = 0; i < n; i++) {
        string str;
        cin >> str;
        tree->my_insert(str);
    }
    cin >> k;
    tree->my_print(k);
    return 0;
}