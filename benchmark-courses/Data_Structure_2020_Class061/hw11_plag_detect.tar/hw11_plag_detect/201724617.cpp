#include <iostream>
#include <string>
#include <vector>

using namespace std;

class BST {

private:
    void SetDepth(BST *tree, int* maxDepth, int depth) {
        if (tree) {
            SetDepth(tree->ltree, maxDepth, depth+1);
            if(*maxDepth < depth)
                *maxDepth = depth;
            SetDepth(tree->rtree, maxDepth, depth+1);
        }
    }
    BST *Insert(BST *tree, const string& str) {
        if (tree == nullptr)
            return new BST(str);
        if (str > tree->data)
            tree->rtree = Insert(tree->rtree, str);
        else
            tree->ltree = Insert(tree->ltree, str);
        return tree;
    }
    void GetSameDepth(BST *tree, int* maxDepth, int depth, const int findDepth, vector<string>& vect) {
        if(findDepth <= 0){
            vect.push_back(tree->data);
            return;
        }else if(findDepth > *maxDepth){
            PrintLeaves(tree, depth, vect);
            return;
        }
        if (tree) {
            GetSameDepth(tree->ltree, maxDepth, depth+1, findDepth, vect);
            if(depth == findDepth)
                vect.push_back(tree->data);
            GetSameDepth(tree->rtree, maxDepth, depth+1, findDepth, vect);
        }
    }
    void PrintLeaves(BST *tree, int depth, vector<string>& vect) {
        if (tree) {
            PrintLeaves(tree->ltree, depth+1, vect);
                if(((tree->ltree) == nullptr) && ((tree->rtree) == nullptr))
                    vect.push_back(tree->data);
            PrintLeaves(tree->rtree, depth+1, vect);
        }
    }

private:
    string data;
    BST *ltree, *rtree;
    static BST *root;
    int maxDepth = 0;

public:
    BST() {}
    BST(const string& str, BST *l=nullptr, BST *r=nullptr): data(str), ltree(l), rtree(r) {}
    static void Insert(const string& str) {
        root = root->Insert(root, str);
    }
    void SetDepth() {
        root->SetDepth(root, &maxDepth, 1);
    }
    void GetSameDepth(int findDepth, vector<string>& vect) {
        root->GetSameDepth(root, &maxDepth, 1, findDepth, vect);
    }
};

BST *BST::root = nullptr;

void print(vector<string>& vect){
    for(vector<string>::iterator IT = vect.begin(); IT != vect.end(); ++IT){
        cout << *IT;
        if((IT+1) != vect.end())
            cout << " ";
    }
}

int main() {
    BST *tree = new BST();
    int times;
    cin >> times;

    string strs[times];
    for(int i=0; i<times; i++){
        cin >> strs[i];
    }

    for (string str: strs)
        tree->Insert(str);
    tree->SetDepth();

    int depth;
    cin >> depth;

    vector<string> v; // for using vector.
    tree->GetSameDepth(depth, v); // collect elements at vector

    print(v);
}
