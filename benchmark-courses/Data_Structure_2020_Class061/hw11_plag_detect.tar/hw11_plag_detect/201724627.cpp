#include <iostream>
#include <string>

using namespace std;



class BST {
 string data;
 BST *ltree, *rtree;
 static BST *root;
public:

  bool space = 0;
  BST() {}
  BST(string *d, BST *l=NULL, BST *r=NULL): data(*d), ltree(l), rtree(r){}
  static void Insert(string *d){
    root = root->Insert(root, d);
  }
  BST *Insert(BST *tree, string *d) {
    if (tree == NULL)
     return new BST(d);
    if (*d > tree->data)
      tree->rtree = Insert(tree->rtree, d);
    else
      tree->ltree = Insert(tree->ltree, d);
    return tree;
  }

  static ostream& KeyedPrint(int key,ostream &out=cout) {
    return root->KeyedPrint(root, key, out);
  }
  ostream& KeyedPrint(BST *tree, int key, ostream &out) {
    int depth= GetDepth(root);
    if(tree){
            if(key<=1){
                out<<tree->root->data;
            }else if(key<=depth){
                PrintLevel(key-1,root);
            }else{
                PrintLeaves(root);
            }
      }
    return out;
  }

  void PrintLeaves(BST* ROOT){

  if(ROOT->ltree == NULL && ROOT->rtree == NULL){
    if(space==true)
        cout<<" ";
    cout<<ROOT->data;
    space=1;
    return;
    }

  if(ROOT->ltree != NULL){
    PrintLeaves(ROOT->ltree);
    }
  if(ROOT->rtree != NULL){
    PrintLeaves(ROOT->rtree);
    }
  }

  void PrintLevel(int key, BST* ROOT){
    if(ROOT == NULL)
        return;
    if(key == 0){
        if(space==true)
            cout<<" ";
        cout<<ROOT->data;
        space=1;
        return;
    }
    else{
        PrintLevel(key-1, ROOT->ltree);
        PrintLevel(key-1, ROOT->rtree);
    }


  }

  int GetDepth(BST* ROOT){
    if(ROOT== NULL)
     return 0;

    int left_depth = GetDepth(ROOT->ltree);
    int right_depth = GetDepth(ROOT->rtree);

    if(left_depth > right_depth)
        return left_depth + 1;
    else
        return right_depth + 1;
    }

 };

 BST* BST::root = NULL;

int main(){
  int size;
  string input;
  int key;
  BST *tree = new BST();
  cin>>size;
  string ns[size];
  for(int i=0;i<size;i++){
    cin>>input;
    ns[i]=input;
  }

  for (int i=0;i<size;i++)
    tree->Insert(&ns[i]);

    cin>>key;
    tree->KeyedPrint(key);
}
