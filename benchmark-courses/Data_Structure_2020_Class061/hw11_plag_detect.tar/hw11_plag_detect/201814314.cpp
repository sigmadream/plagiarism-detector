#include <iostream>
#include <string>

using namespace std;

class BST {
	string data;
	BST *ltree, *rtree;
	static BST *root;
	int maxDepth = 0;

public:
	BST() {}
	BST(string d, BST *l=nullptr, BST *r=nullptr): data(d), ltree(l), rtree(r) {}
	static void insert(string d) {
		root = root->insert(root, d);
	}
	BST *insert(BST* tree, string d) {
		if(tree == nullptr)
			return new BST(d);
		if(d > tree->data)
			tree->rtree = insert(tree->rtree, d);
		else
			tree->ltree = insert(tree->ltree, d);
		return tree;
	}
	static ostream& print( int n, int d, ostream &out=cout ) {
		return root->print(root, 0, out, d, n);
	}
	ostream& print(BST* tree, int depth, ostream &out, int d, int n) {
		if(tree) {
			// cout << "depth: " << depth << endl;

			if(d>0 && d<=n) {
				print(tree->ltree, depth+4, out, d, n);
				if((d-1)*4 == depth)
					out << tree->data << " ";
				print(tree->rtree, depth+4, out, d, n);
			}
			else if(d<=0)
				out << root->data << " ";
			else {
				print(tree->ltree, depth+4, out, d, n);
				if(((tree->rtree) == nullptr) 
					&& ((tree->ltree) == nullptr))
					out << tree->data << " ";
				print(tree->rtree, depth+4, out, d, n);
			}
		}
		return out;
	}
	void setDepth(BST* tree, int depth = 0) {
		if(tree) {
			setDepth(tree->ltree, depth+1);
			setDepth(tree->rtree, depth+1);
			if(depth > maxDepth) maxDepth = depth;
		}
	}
	int getDepth() {
		setDepth(root);
		return maxDepth;
	}
};

BST *BST:: root = nullptr;

int main() {
	int n;
	cin >> n;
	BST * tree = new BST();
	string ns[n];
	for(int i=0; i<n; ++i) 
		cin >> ns[i];
	for(string n: ns)
		tree->insert(n);

	int depth;
	cin >> depth;
	int maxDepth = tree->getDepth();
	cout << "maxDempth: " << maxDepth << endl;
	tree->print(maxDepth, depth);
}
