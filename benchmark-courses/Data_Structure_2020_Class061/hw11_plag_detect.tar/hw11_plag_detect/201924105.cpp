#include <iostream>
#include <string>

using namespace std;

class BST {
private:
  string data;
  BST *ltree, *rtree;
  static string str;
  static BST *root;
  static int maxDepth; // start root as 0
  BST *Insert(BST *tree, const string &d) {
    if (tree == nullptr)
      return new BST(d);
    if (d > tree->data)
      tree->rtree = Insert(tree->rtree, d);
    else
      tree->ltree = Insert(tree->ltree, d);
    return tree;
  }
  ostream& Print(BST *tree, int depth, ostream &out, int key) {
    if (tree) {
      Print(tree->ltree, depth+1, out, key);
      if(depth+1 == key)
        str += tree->data + " ";
      Print(tree->rtree, depth+1, out, key);
    }
    if (depth == 0) {
      str = str.substr(0, str.length()-1);
      out << str << endl;
    }
    return out;
  }
  ostream& PrintNode(BST *tree, int depth, ostream &out) {
    if (tree) {
      if((tree->ltree == nullptr) && (tree->rtree == nullptr)) {
        str += tree->data; 
        str += " ";
      }
      PrintNode(tree->ltree, depth+1, out);
      PrintNode(tree->rtree, depth+1, out);
    }
    if (depth == 0) {
      str = str.substr(0, str.length()-1);
      out << str << endl;
    }
    return out;
  }
  void CalcMaxDepth(BST *tree, int depth) {
    if(tree) {
      CalcMaxDepth(tree->ltree, depth+1);
      maxDepth = (maxDepth < depth)? depth: maxDepth;
      CalcMaxDepth(tree->rtree, depth+1);
      maxDepth = (maxDepth < depth)? depth: maxDepth;
    }
    return;
  }
public:
  BST() {}
  explicit BST(const string &d, BST *l=nullptr, BST *r=nullptr): data(d), ltree(l), rtree(r) {}
  static void Insert(string d) {
    root = root->Insert(root, d);
  }
  static ostream& Print(ostream &out, int key) {
    if(key <= 1){
      cout <<  root->data << endl;
      return out;
    } else if(key > maxDepth+1) {
      return root->PrintNode(root, 0, out);
    } else {
      return root->Print(root, 0, out, key);
    }
  }
  static void CalcMaxDepth() {
    root->CalcMaxDepth(root, 0);
    return;
  }
};

BST *BST::root = nullptr;
int BST::maxDepth = 0;
string BST::str = "";

int main() {
  int num, key;
  cin >> num;
  string ns[num];
  for(int i=0; i<num; i++)
    cin >> ns[i];
  cin >> key;

  BST *tree = new BST();
  for (string n: ns)
    tree->Insert(n);
  tree->CalcMaxDepth();

  tree->Print(cout, key);
}
