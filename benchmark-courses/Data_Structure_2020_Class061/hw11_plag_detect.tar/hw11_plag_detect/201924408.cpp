#include <iostream>
#include <string>
using namespace std;

class BST {
    string data;
    BST *ltree, *rtree;
    static BST *root;
public:
    BST() {}
    BST(string d, BST *l=nullptr, BST *r=nullptr): data(d), ltree(l), rtree(r) {}
    static void insert(string d) {
        root = root->insert(root, d);
    }
    BST *insert(BST *tree, string d) {
        if (tree == nullptr)
            return new BST(d);
    if (d > tree->data)
        tree->rtree = insert(tree->rtree, d);
    else
        tree->ltree = insert(tree->ltree, d);
        return tree;
    }
    static ostream& print(ostream &out=cout) {
    return root->print(root, out);
    }
    ostream& print(BST *tree, ostream &out) {
        if (tree) {
            print(tree->ltree, out);
            out << tree->data << " ";
            print(tree->rtree, out);
        }
        return out;
    }
};

BST *BST::root = nullptr;

int main() {
    int k;
    string word;
    cin >> k;
    string *ns = new string[k];
    for (int i = 0; i < k; i++){   
        cin >> word;
        ns[i] = word;
    }
    

    BST *tree = new BST();
    for (int i = 0; i < k; i++)
    {
        tree->insert(ns[i]);
    }
        tree->print();
}