#include <iostream>
#include <string>
#include <vector>
#define MAX 5005

using namespace std;

static int levelOfTree = 0;

class BinarySearchTree;

class BinarySearchTree{
    private:
        int level, size, chkLevel;
        string isLeft, isRight;
        string data;
        BinarySearchTree *ltree, *rtree;
        BinarySearchTree *root;
        vector<string> result;
    public:
        explicit BinarySearchTree(){level = 0;root = nullptr;
        isLeft =""; isRight =""; ltree = nullptr; rtree = nullptr;}
        void makeLeafNode(const string &node);
        void inOrder(BinarySearchTree *current){
            if(current != nullptr){
                inOrder(current -> ltree);
                if(current -> level == this -> chkLevel){
                    result.push_back(current -> data);
                }
                inOrder(current -> rtree);
            }
        }
        void show();
        void calculate(int chkLevel);
        void setSize(int size);void setChkLevel(int chk);
        void retLevelObject();
        void inorderTwo(BinarySearchTree *current){
            if(current != nullptr){
                inorderTwo(current -> ltree);
                if(current -> ltree == nullptr and current -> rtree == nullptr){
                    result.push_back(current -> data);
                }
                inorderTwo(current -> rtree);
            }
        }
};
void BinarySearchTree::show(){inOrder(root);}
void BinarySearchTree::setSize(int size){this -> size = size;}
void BinarySearchTree::setChkLevel(int chk){
    this -> chkLevel = chk;
    if (chkLevel == size){
        inorderTwo(root);
    }
    else if(chkLevel == 0 || chkLevel == -1){
        result.push_back(root -> data);
    }
}

void BinarySearchTree::makeLeafNode(const string &nodeData){
    BinarySearchTree *temp = new BinarySearchTree();
    BinarySearchTree *tmpRoot = nullptr;

    temp -> data = nodeData;
    if(root == nullptr){
        root = temp;
        temp -> level++;
    }else{
        BinarySearchTree *ptr = root;
        while (ptr != nullptr){
                tmpRoot = ptr;
                if (temp -> data < ptr -> data){
                    ptr = ptr -> ltree;
                }else{
                    ptr = ptr -> rtree;
                }
            }
            if(temp -> data < tmpRoot -> data){
                tmpRoot -> ltree = temp;
                temp -> isLeft = "Left";
                temp -> level = tmpRoot -> level + 1;
            }
            else{
                tmpRoot -> rtree = temp;
                temp -> isRight = "Right";
                temp -> level = tmpRoot -> level + 1;
            }
    }
}

void BinarySearchTree::calculate(int chkLevel){
    BinarySearchTree *ptr = root;
    while(ptr != nullptr){
        if(ptr -> ltree != nullptr){
            if(ptr -> level == chkLevel){
                result.push_back(ptr -> data);
            }
            ptr = ptr -> ltree;
        }
        if(ptr -> rtree != nullptr){
            if(ptr -> level == chkLevel){
                result.push_back(ptr -> data);
            }
            ptr = ptr -> rtree;
        }
    }
    for(int i = 0; i < result.size(); i++)
        cout << result[i] << endl;
}

void BinarySearchTree::retLevelObject(){
    string retVal;
    for(int i = 0; i < this -> result.size(); i++){
        retVal += result[i];
        if(i == result.size() - 1){
            
        }
        else
            retVal += " ";
    }
    cout << retVal << endl;
}

int main(){
    BinarySearchTree *heil = new BinarySearchTree();
    string input;int size;int chkLevel;
    cin >> size;
    heil -> setSize(size);
    for(int i = 0; i < size; i++){
        cin >> input;
        heil -> makeLeafNode(input);
    }
    cin >> chkLevel;
    heil -> setChkLevel(chkLevel);
    if (chkLevel == 0 || chkLevel == -1){

    }
    else {
        heil -> show();
    }
    heil -> retLevelObject();
    return 0;
}