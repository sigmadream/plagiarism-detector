#include<iostream>

using namespace std;

class Polynomial;

class Term
{
    friend Polynomial;
public:
    Term *next;
    Term(int coe, int exp, Term *next = NULL){
        this->coe = coe;
        this->exp = exp;
    }
    ~Term(){};
private:
    int coe;
    int exp;
};

class Polynomial
{
private:
    Term *head, *tail;
    int termCnt;
public:
    Polynomial(){
        head=tail=NULL;
        termCnt = 0;
    };
    Polynomial(const Polynomial &p){
        termCnt = p.termCnt;
        head = p.head;
        tail = p.tail;
    }
    Polynomial& operator =(const Polynomial &p){
        termCnt = p.termCnt;
        delete this->head;
        delete this->tail;
        this->head = p.head;
        this->tail = p.tail;
        return *this;
    }
    ~Polynomial(){};
    void print();
    void InsertTerm(Term *term);
    Polynomial operator +(Polynomial p);
    Polynomial operator -(void);
};

void Polynomial::InsertTerm(Term *term){
    if (head == NULL)
    {
        termCnt = 1;
        head = tail = term;
        head->next = NULL;
        tail->next = NULL;
    }else{
        termCnt++;
        tail->next = term;
        tail = term;
        tail->next = NULL;
    }
}

Polynomial Polynomial::operator +(Polynomial p){
    Polynomial pSum;
    Term *h = head;
    Term *ph = p.head;
    while(h != NULL || ph != NULL){
        if (h == NULL)
        {
            pSum.InsertTerm(ph);
            ph = ph->next;
        }else{
            if (ph == NULL)
            {
                pSum.InsertTerm(h);
                h = h->next;
            }else{
                if (h->exp > ph->exp)
                {
                    Term *termP = new Term(h->coe, h->exp);
                    pSum.InsertTerm(termP);
                    h = h->next;
                }else if (h->exp < ph -> exp)
                {
                    Term *termP = new Term(ph->coe, ph->exp);
                    pSum.InsertTerm(termP);
                    ph = ph->next;
                }else{
                    int coe, exp;
                    coe = h->coe + ph->coe;
                    exp = h->exp;
                    if (coe != 0)
                    {
                        Term *termP = new Term(coe, exp);
                        pSum.InsertTerm(termP);
                    }
                    h = h->next;
                    ph = ph->next;
                }
            }
        }
    }
    return pSum;
}

Polynomial Polynomial::operator -(void){
    Polynomial minusP;
    Term *h = head;
    while(h != NULL){
        Term *termP = new Term(-h->coe, h->exp);
        minusP.InsertTerm(termP);
        h = h->next;
    }
    return minusP;
}

void Polynomial::print(){
    cout << termCnt;
    Term *h = head;
    for (int i=0; i < termCnt; i++)
    {
        cout << " " << h->coe << " " << h->exp;
        h = h->next;
    }
    cout << endl;
}

int main(){
    Polynomial p1;
    Polynomial p2;
    int p1n, p2n;
    cin >> p1n;
    for (int i = 0; i < p1n; i++)
    {
        int coe;
        int exp;
        cin >> coe >> exp;
        Term *termP = new Term(coe, exp);
        p1.InsertTerm(termP);
    }
    cin >> p2n;
    for (int i = 0; i < p2n; i++)
    {
        int coe;
        int exp;
        cin >> coe >> exp;
        Term *termP = new Term(coe, exp);
        p2.InsertTerm(termP);
    }
    Polynomial p3 = p1 + (-p2);
    p3.print();
    return 0;
}