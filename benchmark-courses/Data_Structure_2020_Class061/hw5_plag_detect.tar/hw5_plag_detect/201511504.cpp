#include <iostream>
#include <stack>
using namespace std;

int main(){

stack<int> Stack;
int num;
cin >> num;
int arr[num];
for (int i=0; i<num; i++)
{
    cin >> arr[i];
}
for (int i=num-1; i>=0; i--)
{
    Stack.push(arr[i]);
}

int result[num];
while(!Stack.empty()){
int i = 0;
result[i] = Stack.top();
i++;
Stack.pop();
}

if(result[0]==1){
    cout << 1 << endl;
}
else cout << 0 << endl;

return 0;
}
