#include<iostream>
using namespace std;

class Node{
private:
    int data;
    Node* next;
public:
    Node(int d) : data(d){next = NULL;}
    ~Node() {delete[] next;}
    int getData() {return data;}
    Node* getNext() {return next;}
    void setNext(Node* p) { next = p;}
};

class Stack{
private:
    Node* top;
public:
    Stack() {top = NULL;}
    // ~Stack() {delete[] top;}
    bool Empty();
    void Push(int data);
    void print();
    int Pop();
    int Top();
};

bool Stack :: Empty() {return !top;}
void Stack :: Push(int data){
    Node* newNode = new Node(data);
    Node* topPointed = top ? top : NULL;
    newNode->setNext(topPointed);
    top = newNode;
}
int Stack ::  Pop() {
    if (Empty()) return 0;
    int tmp = top->getData();
    top = top->getNext();
    return tmp;
}
int Stack :: Top(){
    return top->getData();
}

bool canMakeInput(int* input, int size){
    Stack stack;
    stack.Push(1);
    int* answer = new int[size];
    int i = 0, j = 2;
    while (i < size){
        if (stack.Top() != input[i]) {
            stack.Push(j++); 
            if (j > size+1) {return false;}
        }
        else  answer[i++] = stack.Pop();
    }
    delete[] answer;
    return true;
}


int main() {
    int size;
    cin >>size;
    int input[size];
    for(int i = 0 ; i < size ; i++)   {
        cin >> input[i];
    }
    if (canMakeInput(input, size)) cout << 1 << endl;
    else cout << 0 << endl;
}