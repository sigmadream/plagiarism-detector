#include <iostream>

using namespace std;

class Node {
public:
	int data;
	Node *next;
public:
	Node(int _data): data(_data), next(NULL){}
};

class Stack {
private:
	Node *top;
	int sz;
public:
	Stack(void): top(NULL), sz(0) {}
	void push(int data);
	int pop(void);
	bool empty(void);
	int Top(void);
	Node* end(){
		return top;
	}
	Node* begin(){
		for(int i=0; i<sz; ++i){
			top = top->next;
		}
		return top;
	}
};

void Stack::push(int data){
	Node *newNode=new Node(data);
	Node *temp = top;
	top=newNode;
	newNode->next=temp;
	sz++;
};

int Stack::Top(void){
	if(top==NULL){
		return -1;
	};
	int tmpData=top->data;
	return tmpData;
};

bool Stack::empty(void){
	if(top == NULL)
		return true;
		
	return false;
}

int Stack::pop(){
	if(top==NULL){
		return -1;
	}
	int tmpData=top->data;
	Node *tmpNode=top;
	top=top->next;
	sz--;
	delete tmpNode;
	return tmpData;
};


bool stackchk(int* input, int* result, int len){
	int c=0;
	
	Stack s;
	for(int i=0; i<len; i++){
		s.push(input[i]);
		while(s.empty() == false && c<len && s.Top() == result[c]){
			s.pop();
			c++;
		}
	}
	
	return c == len;
}

int main(void){
	int n;
	cin >> n;
	
	int* input = new int[n];
	int* result = new int[n];
	
	for(int i=0; i<n; ++i){
		input[i] = i+1;
		cin >> result[i];
	}
	cout << stackchk(input, result, n);
	
	return 0;
	
}

