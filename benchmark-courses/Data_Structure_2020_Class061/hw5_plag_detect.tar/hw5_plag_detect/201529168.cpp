#include <iostream>
#include <algorithm>
#include <iterator>
#include <ctime>
 using namespace std;

 class Range {
 private:
	 int *_ints;
	 int _sz;
 public:
	 typedef int *iterator;
	 Range(int sz): _sz(sz) {
	 	_ints = new int[sz];
	 	for (int i = 0; i < sz; i++)
	 		_ints[i] = i;
	 }
	 iterator begin() {
	 	return _ints;
	 }
	 iterator end() {
	 	return _ints + _sz;
	 }
 };

 int main() {
	int a,b;
        cin >> b;
    	cin >> a;
	srand((unsigned int)time(0));
	int n = rand() % 2;
	cout << n << endl;
 	//for (Range::iterator p = r.begin(); p != r.end(); p++)
 	//	cout << *p << "\n";

 }

