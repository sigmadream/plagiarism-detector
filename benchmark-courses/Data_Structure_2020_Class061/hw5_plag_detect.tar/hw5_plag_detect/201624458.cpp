/*
* Author: Chunsu Kim
* Number: 201624458
* Data structure october 7th
*/

#include <iostream>
#include <algorithm>
#include <iterator>

using namespace std;

class Node {
public:
	friend class Stack;
	Node(int data) {
		this->data = data;
	}
private:
	int data;
	Node* next;
};


class Stack {
private:
	Node* top;
	int* number;
public:
	Stack(int r) {
		number = new int[r];
		for (int i = 0; i < r; i++)
			number[i] = 0;
	}
	void push(int data);
	int pop();
	int isEmpty();
};

void Stack::push(int data) {
	Node* newNode = new Node(data);
	newNode->next = top;
	top = newNode;
}
int Stack::pop() {
	/*if (top == NULL) {
		return 1;
	}
	else {
		cout << 0 << endl;
		return 0;
	}
	*/
	int tempData = top->data;
	Node* tempNode = top;
	top = top->next;
	delete tempNode;
	return tempData;
}

int Stack::isEmpty() {
	return (top == NULL);
}

int main() {
	Stack stack(5);
	stack.push(1);
	stack.push(2);
	stack.push(3);
	stack.push(4);
	cout<<stack.pop()<<" ";
	stack.push(5);
	while (!stack.isEmpty()) {
		cout<<stack.pop()<<" ";
	}
	return 0;
}