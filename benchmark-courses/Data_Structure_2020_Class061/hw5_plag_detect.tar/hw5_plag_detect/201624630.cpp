#include <iostream>
#include <algorithm>
#include <iterator>
#include <stack>

using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int main() {
  int a;
  int n = 0;
  int array[100010];

  cin >> a;
  
  for(int i=0; i < a; i++){
    cin >> array[i];
  } // my array 
  
  
  stack<int> mystack; // my stack 
  
  for(int i = 1; i <= a; i++){
    mystack.push(i);
    while (!mystack.empty() && n < a && mystack.top() == array[n]){ 
            mystack.pop(); 
            n++; 
        } 
  }
  
  if(a == n) cout << 1;
  else cout << 0;
  
  return 0;

}
