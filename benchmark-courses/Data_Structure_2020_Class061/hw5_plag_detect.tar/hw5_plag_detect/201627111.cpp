#include <iostream>
#include <algorithm>
#include <iterator>

using namespace std;

class Range {
private:
	int *_ints;
	int _sz;
public:
	typedef int *iterator;
	Range(int sz): _sz(sz) {
		ints = new int[sz];
		for (int i = 0; i < sz; i++)
			ints[i] = i;
	}
	iterator begin() {
		return _ints;
	}
	iterator end() {
		return _ints + _sz;
	}
};

int main() {
	int len;
	cin >> len >> endl;
	int popped[len];
	Range r(len);
	for(int i=0; i<len; i++)
		cin >> popped[len];
	
	copy(r.begin(), r.end(), ostream_iterator<int>(cout, "\n"));
}