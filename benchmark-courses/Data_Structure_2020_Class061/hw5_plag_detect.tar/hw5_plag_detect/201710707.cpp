#include <iostream>

using namespace std;

int main() {
	int num;
	cin >> num;
	int a[num];
	
	int i,j,k;
	
	for(i=0; i<num; i++) {
		cin >> a[i];
	}
	
	for(i=0; i<num-2; i++) {
		for(j=i+1; j<num-1; j++) {
			for(k=j+1; k<num; k++) {
				if ((a[i] > a[k]) && (a[j] < a[k])) {
					cout<<"0";
					return 0;
				}
			}
		}
	}
	
	cout<<"1";
	return 0;
}
