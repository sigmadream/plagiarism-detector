#include <iostream>

class Node
{
    friend class LinkedList;
    friend class Stack;

public:
    Node(int Num)
    {
        data = Num;
    }

private:
    int data;
    Node *next;
};

class LinkedList
{
private:
    Node *first;

public:
    void insert(int data, Node *p)
    {
        Node *newNode = new Node(data);
        if (first == NULL)
        {
            first = newNode;
            newNode->next = NULL;
        }
        else
        {
            newNode->next = p->next;
            p->next = newNode;
        }
    };
    void Del(Node *p, Node *q)
    {
        if (q == NULL)
            first = first->next;
        else
            q->next = p->next;
        delete p;
    };
};

class Stack
{
private:
    Node *top;

public:
    void push(int data)
    {
        Node *newNode = new Node(data);
        newNode->next = top;
        top = newNode;
    };
    int pop()
    {
        int tmpdata = top->data;
        Node *tmpNode = top;
        top = top->next;
        delete tmpNode;
        return tmpdata;
    };
    int Number()
    {
        return top->data;
    }
};

int main()
{
    int listnum;
    std::cin >> listnum;
    int List[listnum], List2[listnum];
    for (int i = 0; i < listnum; i++)
    {
        std::cin >> List[i];
    }
    int index = 0;
    Stack stc;
    for (int i = 0; i < listnum; i++)
    {
        stc.push(i + 1);
        while (true)
        {
            if (stc.Number() == List[index])
            {
                List2[index] = stc.pop();
                index++;
                if (index == listnum)
                    break;
            }
            else
                break;
        }
    }
    int state = 1;
    for (int i = 0; i < listnum; i++)
    {
        if (List[i] != List2[i])
        {
            state = 0;
            break;
        }
    }
    if (state == 1)
        std::cout << 1;
    else
        std::cout << 0;
    return 0;
}