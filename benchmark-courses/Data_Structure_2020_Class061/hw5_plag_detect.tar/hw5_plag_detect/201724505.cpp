#include <iostream>

using namespace std;

class Node {
	friend class Stack;
private:
	int data;
	Node* next;
public:
	Node(int data) : data(data) {}
};

class Stack {
private:
	Node* top;
public:
	Stack() : top(NULL) {}
	void push(int data); // �� �տ� node insert
	void pop(); // �� ���� element delete, pop�� node�� data return
	bool empty();
	int validStackSequence(int *stackSeq, int *outputSeq, int len);
};

void Stack::push(int data) {
	Node* newNode = new Node(data);
	newNode->next = top;
	top = newNode;
}

void Stack::pop() {
	if (top == NULL)
		return;
	Node* tempNode = top;
	top = top->next;
	delete tempNode;
}

bool Stack::empty() {
	return (top == NULL)?true : false;
}

int Stack::validStackSequence(int* stackSeq, int* outputSeq, int len) {
	int j = 0;
	int returnValue = 0;
	for (int i = 0; i < len; i++) {
		push(stackSeq[i]);
		while (!empty() && j < len && top->data == outputSeq[j]) {
			pop();
			j++;
		}
	}
	if (j == len) 
		returnValue = 1;
	return returnValue;
}

int main() {
	int T;
	cin >> T;
	Stack stack;
	int* stackSeq = new int[T];
	int* outputSeq = new int[T];
	for (int i = 0; i < T; i++) {
		stackSeq[i] = i + 1;
		cin >> outputSeq[i];
	}
	cout << stack.validStackSequence(stackSeq, outputSeq, T) << endl;

	return 0;
}
