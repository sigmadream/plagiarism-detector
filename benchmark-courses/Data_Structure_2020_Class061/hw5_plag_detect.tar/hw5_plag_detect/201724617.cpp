#include <iostream>
using namespace std;

class Node{
	friend class LinkedStack;
	private:
		// Data type start.
		int n;
		// Data type end.
		Node* next;

	public:
	    Node(const int _n):n(_n){}
	    const int getEle(){ return n; }
	    Node* getNode(){ return next; }
};

class LinkedStack{
	private:
		Node* top;
	public:
		LinkedStack(){ top = NULL; }
		~LinkedStack(){
            while(top != NULL){
                Node *tmpNode = top;
                top = top->next;
                delete tmpNode;
            }
		}
		void push(const int n){
            Node *tmpNode = new Node(n);
            tmpNode->next = top;
            top = tmpNode;
		}
		const int pop(){
		    if(top == NULL) return -1; // NULL���� pop �� -1 ���
		    Node *tmpNode = top;
		    top = top->next;
		    return tmpNode->getEle();
		}
		
		Node* begin(){ return top; }
		Node* end(){
			Node *tmpNode = LinkedStack::top;
			while(tmpNode != NULL){
				tmpNode = tmpNode->next;
			}
			return tmpNode;
		}
};

class myIterator{ // myIterator class.
	private:
		Node* Nd;
	public:
		myIterator(Node* n){ Nd = n; }
		
		bool operator != (Node* n){
			if(Nd == n)
				return false;
			else
				return true;
		}
		myIterator& operator ++(int){
			Nd = Nd->getNode();
			return *this;
		}
		const int getValue(){
			return Nd->getEle();
		}
};

int main() {
    int n;
    cin >> n;

    int compArr[n];
    for(int i=0; i<n; i++) cin >> compArr[i];

    LinkedStack LS;

    int index = 0;
    for(int i=1; i<=n; i++){ // �ϴ� �� ����ֱ�
        int delta = 0;
        LS.push(i);
        while(compArr[index] == i-delta){ // ���� �����鼭 ������ �����ϸ� pop.
            LS.pop(); index++; delta++;
            if(index == n) break;
        }
    }
    for(myIterator it = LS.begin(); it != LS.end(); it++){ // ���� ��ü pop.
    	if(it.getValue() != compArr[index]) break;
    	index++;
	}

    if(index == n) cout << 1;
    else cout << 0;

    return 0;

}
