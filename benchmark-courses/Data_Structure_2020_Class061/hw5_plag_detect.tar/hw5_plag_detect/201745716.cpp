#include <iostream>

using namespace std;

int main()
{
	int n;
	cin >> n;
	int array[n];
	for(int i = 0; i < n; i++) {
		cin >> array[i];
	}
	if(array[n-1] != 1) {
		cout << 0;
	}
	else
		cout << 1;
	return 0;
}
