#include<iostream>
#include<algorithm>
#include<iterator>

using namespace std;

class Range {
private:
    int *_ints;
    int _sz;
public:
    typedef int *iterator;
    Range(int sz): _sz(sz) {
    	_ints = new int[sz];
    	for (int i = 0; i < sz; i++)
        	_ints[i] = i;
    }
    iterator begin() {
        return _ints;
    }
    iterator end() {
        return _ints + _sz;
    }
    void inputArray(int* arr) {
    	for (int i=0; i<_sz;i++) {
    		_ints[i] = arr[i];
		}
	}
	int findLast()
	{
		int reNum;
		for(int i=0; i<_sz;i++)	
			if(_ints[i] == _sz)
				return i;
	}
	int isValid(int num)
	{
		if( _ints[num] == _sz - num)
			return 1;
		else
			return 0;
	}
	
};
int main() {
	int inputN;
	int validN;
	int* inputSeq;
	int lastIdx;
	
	cin >> inputN;
    Range r1(inputN);
    Range r2(inputN);
    inputSeq = new int(inputN);
    
    for(int i=0;i<inputN;++i)
    	cin >> inputSeq[i];
    r2.inputArray(inputSeq);
    
    lastIdx = r2.findLast();
    int cnt = 0;
	for (Range::iterator p = r2.begin()+lastIdx; p < r2.end()-1; ++p){
		validN= r2.isValid(lastIdx+cnt+1);
		if(validN == 0) break;
		cnt++;
	}
	
    cout << validN;
}
