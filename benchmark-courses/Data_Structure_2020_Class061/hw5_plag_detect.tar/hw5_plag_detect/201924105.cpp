#include <iostream>
#include <algorithm>
#include <iterator>

using namespace std;

class Node {
  friend class Stack;
private:
  int data;
  Node *next;
public:
  Node(int newData) : data(newData) {}
};

class Stack {
private:
  Node *top;
public:
  void push(int data) {
    Node *newNode = new Node(data);
    newNode->next = top;
    top = newNode;
  }
  int pop() {
    if(top==NULL) ListEmpty();
    int tmpData = top->data;
    Node *tmpNode = top;
    top = top->next;
    delete tmpNode;
    return tmpData;
  }
  void ListEmpty() {
    cout << "List is empty" << endl;
  }
  int getTop() {
    return top->data;
  }
};

class Range {
private:
  int *_ints;
  int _sz;
public:
  typedef int *iterator;
  Range(int sz): _sz(sz) {
    _ints = new int[sz];
    for (int i = 0; i < sz; i++)
      cin >> _ints[i];
  }
  iterator begin() {
    return _ints;
  }
  iterator end() {
    return _ints + _sz;
  }
  bool isInRange(int num) {
    return (num <= _sz) && (num >=1);
  }
  int isValid() {
    int fstNum = *(begin());
    Stack *s = new Stack();
    for(int i=1; i<=fstNum; i++) {
      s->push(i);
    }

    for(int i=1; i<=_sz; i++)
    {
      if(!isInRange(*(_ints + i - 1))) {
        delete s;
        return 0;
      }
      if(*(_ints + i -1) == fstNum)
        s->pop();
      else if(*(_ints + i -1) > fstNum) {
        s->push(*(_ints + i - 1));
        s->pop();
      }
      else {
        if(*(_ints + i - 1) == s->getTop())
          s->pop();
        else {
          delete s;
          return 0;
        }
      }
    }
    delete s;
    return 1;
  }
};

int main() {
  int num, v;
  cin >> num;
  Range r(num);
  // Range::iterator last = r.end();
  // copy(r.begin(), last, ostream_iterator<int>(cout, " "));
  v = r.isValid();
  cout << v;
}