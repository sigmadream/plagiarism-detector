#include <iostream>
#include <algorithm>
#include <iterator>

using namespace std;

class Range {
private:
    int *_ints;
    int _sz;
public:
    typedef int *iterator;
    Range(int sz): _sz(sz) {
        _ints = new int[sz];
        for (int i = 0; i < sz; i++)
            _ints[i] = i+1;
    }

    iterator begin() {
        return _ints;
    }
    iterator end() {
        return _ints + _sz;
    }

    int _get(int k){
        int t = _ints[k-1];
        return t;
    }
    int _input(int k, int num){
        _ints[k-1] = num;

    }


};

ostream& operator<<(ostream& os, Range head)
{   int t;
    cout << head._get(t);
}

int main() {
    int k;
    int km[5];
    int cnt = 0;
    cin >> k;
    Range a(k);
    if( k ==5){
        cin >> km[0]>> km[1]>>km[2]>> km[3]>> km[4];
    }
    else if( k ==3){
        cin >> km[0]>> km[1]>>km[2];
    }
    else if( k ==2){
        cin >> km[0]>> km[1];
    }
    else if( k ==1){
        cin >> km[0];
    }


    for (int i =0 ; i <k; i++){
        if( a._get(i+1) == km[i])
            cnt += 1;
    }
    cout << cnt ;
}

