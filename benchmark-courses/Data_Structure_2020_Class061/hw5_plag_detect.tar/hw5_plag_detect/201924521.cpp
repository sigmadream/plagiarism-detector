#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <iterator>

using namespace std;

int main() {
	int range;
	int stk[100];
	int stkseq = 1;		//�ƹ� ������ ���ٸ� ������ ����
	cin >> range;
	for (int i = 0;i < range;i++) {
		cin >> stk[i];
	}
	int stk_top = 0;

	for (int i = 0;i < range;i++) {
		if (stk[i] > range) {
			stkseq = 0;
			break;
		}

		if (stk[i] > stk_top)
			stk_top = stk[i];
		else if (stk[i] <= stk_top) {
			for (int j = 0;j < i;j++) {
				if (stk[i] == stk[j] - 1) {
					stkseq = 1;
					break;
				}
				else if (stk[i] != stk[j] - 1)
					stkseq = 0;
				else if (stk[i] == stk[j]) {
					stkseq = 0;
					break;
				}
					
			}
		}
		if (stkseq == 0) break;
	}
	cout << stkseq;
}