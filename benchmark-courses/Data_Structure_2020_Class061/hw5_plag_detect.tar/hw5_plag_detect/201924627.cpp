#include <iostream>
#include <vector>
using namespace std;

typedef struct Node {
	int value;
	Node *prev;
} Node;

class Stack {
private:
	Node *head, *tail;
	int len;
public:
	Stack() {
		head = NULL;
		tail = NULL;
		len = 0;
	}
	
	void push(int num) {
		Node *tmp = new Node;
		tmp->value = num;
		tmp->prev = NULL;
		len++;
		
		if(head == NULL) {
			head = tmp;
			tail = tmp;
			tmp = NULL;
		} else {
			tail->prev = tmp;
			tail = tmp;
		}
	}
	
	int pop() {
		if(len == 0) {
			cerr << "No elements to pop.\n";
			return 0;
		}
		Node *prev = new Node;
		Node *cur = new Node;
		cur = head;
		len--;
		
		while(cur->prev != NULL) {
			prev = cur;
			cur = cur->prev;
		}
		
		tail = prev;
		prev->prev = NULL;
		int num = prev->value;
		delete cur;
		return num;
	}
	
	bool isEmpty() {
		return len == 0;
	}
	
	int topValue() {
		return head->value;
	}
};

int main() {
	int size, val;
	vector<int> poped, pushed;
	cin >> size;
	for(int i = 0; i < size; i++) {
		cin >> val;
		poped.push_back(val);
		pushed.push_back(i+1);
	}
	Stack stk;
	for(int i = 0, j = 0; i < size && j < size; i++) {
		if(poped[j] != pushed[i]) {
			stk.push(pushed[i]);
		} else {
			j++;
			while(j < size && !stk.isEmpty() && (poped[i] == stk.topValue())) {
				stk.pop();
				j++;
			}
		}
	}
	cout << stk.isEmpty();
	return 0;
}
