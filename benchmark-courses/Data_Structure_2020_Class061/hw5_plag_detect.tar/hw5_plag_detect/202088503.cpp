#include <iostream>
#include <vector>
#include <stack>
#include <iterator>
#include <algorithm>

using namespace std;

class Stack {
    public:
        bool stackSequence(vector<int> &pushSequence, vector<int> & popSequence);
};
bool Stack::stackSequence(vector<int> &pushSequence, vector<int> & popSequence) { 
            if (!pushSequence.size() && !popSequence.size()) 
                return true; 
            stack<int> tempStack; int rea=0, reb=0; 
            while(true) { 
                if (!tempStack.size() && rea<pushSequence.size()) { 
                    tempStack.push(pushSequence[rea++]); 
                    continue;

                } if (rea < pushSequence.size() && tempStack.top() != popSequence[reb]) { 
                    tempStack.push(pushSequence[rea++]); 
                }
                else { 
                    if (!tempStack.size() || tempStack.top() != popSequence[reb]) 
                        break; 
                    tempStack.pop(); reb++; 
                    } 
            } 
            return rea == pushSequence.size() && reb == popSequence.size(); 
        }

int main(){
    int sz; int input;
    vector<int> pushed;
    vector<int> popped;
    cin >> sz;
    for(int i = 1; i < sz + 1; i++){
        pushed.push_back(i);
    }
    for(int i = 0; i < sz; i++){
        cin >> input;
        popped.push_back(input);
    }
    Stack stack;
    cout << stack.stackSequence(pushed,popped) << endl;
}