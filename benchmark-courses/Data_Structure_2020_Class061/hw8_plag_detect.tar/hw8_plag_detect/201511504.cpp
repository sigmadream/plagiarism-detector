#include <iostream>
#include <algorithm>

using namespace std;

class Node {
    int   data;
    Node *next;
public:
    friend class Stack;
    Node(int d, Node *n): data(d), next(n) {}
};
class Stack {
    int data;
    Node *fst;
public:
    Stack(): fst(nullptr) {}
    void push(int n) {
        Node *prev = fst;
        fst = new Node(n, prev);
    }
    void pop() {
        fst = fst->next;
    }
    int top() {
        return fst->data;
    }
    bool isEmpty() {
        return fst == NULL;
    }

    class Iterator{
        Node *curr;
    public:
        Iterator(Node *np=nullptr): curr(np) {}
        Iterator& operator =(const Iterator& p){
            curr = p.curr;
            return *this;
        }
        bool operator !=(const Iterator& p){
            return this->curr != p.curr;
        }
        bool operator <(const Iterator& p) const{
            return (curr<p.curr);
        }
        int operator *(){
            return curr->data;
        }
        Node* operator ++(){
            return (curr = curr->next);
        }
    };

    Iterator begin() {
        return fst;
    }
    Iterator end(){
        return NULL;
    }

    ostream& print(ostream& out){
        for(Iterator p = begin(); p != end(); ++p){
            out << *p << " ";
        }
        return out;
    }
};

int main() {
    Stack s;
    int num;
    cin >> num;
    int ns[num];
    for(int i=0 ; i<num; i++){
        cin >> ns[i];
    }
    sort(ns, ns+num);
    for(int i=0; i<num; i++){
        cout << ns[i] << " ";
    }
}
