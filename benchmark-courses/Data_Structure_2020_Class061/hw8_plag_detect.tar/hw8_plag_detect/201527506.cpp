#include <iostream>

using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
};

class DLinkedList {
private:
    Node* head;
    int size;
public:
    DLinkedList(){
    	head = NULL;
    	size = 0;
    }
 
    void append(int newElement) {
		Node* newNode = new Node();
		newNode->data = newElement;
		newNode->next = NULL;
		newNode->prev = NULL; 
		if(head == NULL){
			head = newNode;
		}
		else{
			Node* temp = head;
			while(temp->next != NULL)
				temp = temp->next;
			temp->next = newNode;
			newNode->prev = temp;
		}
		size++;
    }

    void push_at(int newElement, int position) {
		Node* newNode = new Node(); 
		newNode->data = newElement;
		newNode->next = NULL;
		newNode->prev = NULL;
		if(position == 1){
			newNode->next = head;
			head->prev = newNode;
			head = newNode;
		}
		else{
			Node* temp = head;
			for(int i = 1; i < position-1; i++) 
				if(temp != NULL) 
					temp = temp->next;
		
			if(temp != NULL){
				newNode->next = temp->next;
				newNode->prev = temp;
				temp->next = newNode;
				if(newNode->next != NULL)
					newNode->next->prev = newNode;  
			}
		}
		size++;
    }

    void PrintList() {
		Node* temp = head;
		int sz = size;
		if(temp != NULL) {
			while(sz > 1) {
				sz--;
				cout<<temp->data<<" ";
				temp = temp->next;
			}
			cout << temp->data;
		}
		cout << endl;
	}
	
	void insert_sort(int n){
		Node* temp = head;
		int pos=1;
		if(temp == NULL){
			append(n);
		}
		else{
			while(temp != NULL){
				if(n < temp->data)
					break;
				temp = temp->next;
				pos++;
			}
			push_at(n, pos);
		}
	}
};

int main() {
	DLinkedList MyList;

	
	int n;
	cin >> n;
	
	int* arr = new int[n];
	for(int i=0; i<n; ++i)
		cin >> arr[i];
	for(int i=0; i<n; ++i)
		MyList.insert_sort(arr[i]);
	MyList.PrintList();
	
	
	return 0; 
}
