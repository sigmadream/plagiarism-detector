#include <iostream>

using namespace std;

void quicksort(int arr[], int size) { 
	int pivot = arr[0];
	 int cursor = 0;
	  for (int i = 1; i < size ; i++) {
	   if (pivot > arr[i]) {
	    cursor++; swap(arr[cursor], arr[i]); 
			}
		}
	
	swap(arr[0], arr[cursor]);
	if (cursor > 0) {
	 quicksort(arr, cursor);
	}
	if (cursor + 1 < size - 1) {
	quicksort(arr + cursor + 1, size - cursor - 1); 
	} 
}

int main(){
	int length; 
	
	int i = 0;
	cin >> length;
	
	int *array = new int[length];
	 
	while(i<length){
		cin >> array[i];
		i++;
	}
	quicksort(array,length);
	for( i = 0; i < length; i++) {
	cout << array[i]; 
	if(i!=length-1) cout << " ";}

}
