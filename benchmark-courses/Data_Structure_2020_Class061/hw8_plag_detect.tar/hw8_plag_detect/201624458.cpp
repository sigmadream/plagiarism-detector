#include <iostream>
#include <cassert>
/*
    Author: Chunsu Kim
    Number: 201624458
    Data: 2020-11-04
    Doudly Linked List -- dllist.cpp
*/
using namespace std;
class Node{
    int data;
    Node* next;
    Node *prev;
public:
    friend class Stack;
    Node(int d, Node* n): data(d), next(n) {}
};

class Stack{
    Node* fst;
public:
    Stack(): fst(nullptr) {}
    void push(int n){
        Node* prev= fst;
        fst= new Node(n,prev);
    }
    void pop() {
        fst=fst->next;
    }
    int top(){
        return fst->data;
    }
    bool isEmpty(){
        return fst == nullptr;
    }

    class Iterator {
        Node *curr;
    public:
        Iterator(Node *np=nullptr): curr(np) {}
        Iterator& operator = (const Iterator &p) {
            curr=p.curr;
            return *this;
        }
        bool operator != (const Iterator &p){
            return this->curr != p.curr;
        }
        Iterator operator+(int delta) {
            assert(delta >= 0);
            Node *p=curr;
            while(delta-- >0 ){
                p = p->next;
            }
            return p;
        }
        int operator *() {
            return curr->data;
        }
        Node *operator ++(){  //postpix
            return (curr = curr->next);
        }
        Node *operator < (const Node &p){
            if(curr.data <= p.data)
            {
                curr->next=p;
                p->prev=curr;
            }
            else
            {
                p->next = curr;
                p=curr->prev;
                curr->next=p->next;
                p->prev=curr->prev;
              
            }
            

        }  
    };
    Iterator begin(){
        return fst;
    }
    Iterator end(){
        return nullptr;
    }

    ostream& print(ostream& out){
        for(Iterator p = begin(); p != end(); p++){
            out << *p << " ";
            //out<<*p<<(p+1 != end()? " " :"\n");
        }
        return out;
    }
};

int main(){
    Stack first;
    Stack second;
    int a;
    cin >> a;
    int array[a]={0};
    for(int i=0;i<a;i++)
    {
        cin>>array[i];
    }
    for(int a: array)
    {
        first.push(a);
    }
    for(int a: array){
        second.push(0);
    }
    
    second.push(first
    

}