﻿#include <iostream>
#include <vector>
#include <iterator>
#include <array>
using namespace std;
void ssort(int a[], int n) {
    int i, j, min, cur;
    for (i = 0; i < n - 1; i++) {
        min = i;
        for (j = i + 1; j < n; j++)
            if (a[j] < a[min])
                min = j;
        cur = a[i];
        a[i] = a[min];
        a[min] = cur;
    }
}

int main() {
    int c;
    int array[10010];
    int i = 0;
    vector<int> newVector;
    vector<int>::iterator ptr; 
    cin >> c;
    for (int i = 0; i < c; i++)
        cin >> array[i];
    
    ssort(array, c);
 


    for (int i = 0; i < c; i++) {
        newVector.push_back(array[i]);
    }

    for (ptr = newVector.begin(); ptr < newVector.end()-1; ptr++) {
            cout << *ptr << " ";
    }
    cout << newVector[c-1];


    return 0;
}