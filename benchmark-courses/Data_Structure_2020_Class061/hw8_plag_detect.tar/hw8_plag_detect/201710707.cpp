#include <iostream>
using namespace std;

int a[100000];

int main()
{
	int n;
	int i,j;
	
	cin >> n;
	
	for(i=0;i<n;i++)
		cin >> a[i];
	
	for(i=0;i<n-1;i++)
		for(j=i+1;j<n;j++)
			if(a[i]>a[j]) {
				int t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
	
	cout<<a[0];			
	for(i=1;i<n;i++)
		cout<<" "<<a[i];
	return 0;
}
