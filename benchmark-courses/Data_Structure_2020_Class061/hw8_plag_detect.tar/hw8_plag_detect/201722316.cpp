#include <iostream>
#include <cassert>

using namespace std;

class DblNode
{
public:
    int data;
    DblNode *next = NULL;
    DblNode *before = NULL;
    DblNode(int dat) { data = dat; }
};

class DblLinkedList
{
public:
    DblNode *first = NULL;
    void Insert(DblNode *p, DblNode *x)
    {
        if (x->next == NULL)
        {
            p->before = x;
            p->next = NULL;
            x->next = p;
        }
        else
        {
            p->before = x;
            p->next = x->next;
            x->next->before = p;
            x->next = p;
        }
    };
    class Iterator
    {

    public:
        DblNode *curr;
        Iterator(DblNode *np = NULL) : curr(np) {}
        Iterator &operator=(const Iterator &p)
        {
            curr = p.curr;
            return *this;
        }
        bool operator!=(const Iterator &p)
        {
            return this->curr != p.curr;
        }
        int operator*()
        {
            return curr->data;
        }
        DblNode *operator++()
        {
            return (curr = curr->next);
        }
        DblNode *Show_Node()
        {
            return curr;
        }
    };
    Iterator begin()
    {
        return first;
    }
    Iterator end()
    {
        return NULL;
    }
    void Input(int dat)
    {
        DblNode *newNode = new DblNode(dat);
        if (first == NULL)
        {
            first = newNode;
        }
        else
        {
            for (Iterator p = begin(); p != end(); ++p)
            {
                if (newNode->data <= *p)
                {
                    if (p.Show_Node()->before == NULL)
                    {
                        newNode->next = first;
                        first->before = newNode;
                        first = newNode;
                        break;
                    }
                    Insert(newNode, p.Show_Node()->before);
                    break;
                }
                if (p.Show_Node()->next == NULL)
                {
                    Insert(newNode, p.Show_Node());
                    break;
                }
            }
        }
    }
    ostream &print(ostream &out)
    {
        for (Iterator p = begin(); p != end(); ++p)
        {
        	if (p.Show_Node()->next == NULL)
                {
                    out << *p;
                    break;
                }
            out << *p << " ";
        }
        return out;
    }
};

int main()
{
    int num, num_data;
    cin >> num;
    DblLinkedList res_list;
    for (int i = 0; i < num; i++)
    {
        cin >> num_data;
        res_list.Input(num_data);
    }
    res_list.print(cout);
    return 0;
}
