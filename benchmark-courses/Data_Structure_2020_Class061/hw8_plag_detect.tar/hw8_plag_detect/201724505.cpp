#include <iostream>

using namespace std;

class Node {
    friend class DLinkedList;
private:
    int data;
    Node *next;
    Node *prev;
public:
    Node() {
        next = NULL;
        prev = NULL;
    }
    Node(int data) : data(data) {}
};

class DLinkedList {
private:
    Node *head;
    Node *tail;
public:
    DLinkedList() {
        head = new Node;
        tail = new Node;
        head->next = tail;
        tail->prev = head;
    }

    void insert(Node* p, int e) {
        Node *newNode = new Node(e);
        newNode->next = p->next;
        p->next->prev = newNode;

        p->next = newNode;
        newNode->prev = p;
    }

    void remove(Node* p) {
        p->prev->next = p->next;
        p->next->prev = p->prev;
    }

    class Iterator {
        friend class DLinkedList;
    private:
        Node *curr;
    public:
        Iterator(Node *np = NULL) : curr(np) {}
        Iterator& operator ==(const Iterator& p) {
            curr = p.curr;
            return *this;
        }
        bool operator !=(const Iterator& p) {
            return this->curr != p.curr;
        }
        int operator *() {
            return curr->data;
        }
        Node* operator ++() {
            return (curr = curr->next);
        }
    };

    Iterator begin() {
        return head->next;
    }

    Iterator end() {
        return tail;
    }

    Node* getLast() {
        return tail->prev;
    }

    void sort() {
        for (Iterator p = begin(); p != end(); ++p) {
            for (Iterator q = begin(); q != p; ++q) {
                if (*q > *p) {
                    insert(q.curr->prev, *p);
                    remove(p.curr);
                    break;
                }
            }
        }
    }
    void print() {
        for (Iterator p = begin(); p != end(); ++p) {
            cout << *p << (p.curr->next != tail?" ":"");
        }
    }
};

int main() {
    DLinkedList list;
    int n;
    cin >> n;
    while(n-- > 0) {
        int num;
        cin >> num;
        list.insert(list.getLast(), num);
    }
    list.sort();
    list.print();
    return 0;
}