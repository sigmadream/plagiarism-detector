#include <iostream>
using namespace std;

class DblLnkList;

class Node{
	friend class DblLnkList;
		int n;
		Node *left, *right;
	public:
		Node(){
			left = NULL; right = NULL;
		}
		Node(const int val){
			n = val;
			left = NULL;
			right = NULL;
		}
};

class DblLnkList{
		Node *first, *last;
	public:
		DblLnkList(){
			first = NULL;
			last = NULL;
		}
		
		void insert(Node* p, const int e){
			Node* tmp = new Node(e);
			if(p == NULL){
				if(first == NULL){
					first = tmp;
					first->left = NULL;
					first->right = NULL;
					last = first;
					return;
				}else{
					tmp->right = first;
					first->left = tmp;
					first = tmp;
					return;
				}
			}
			if(p == last) last = tmp;
			tmp->left = p; tmp->right = p->right;
			if(p->right != NULL) p->right->left = tmp;
			p->right = tmp;
		}
		const int remove(Node *p){
			if(first == NULL) exit(-1);
			if(p == last) last = last->left;
			if(p == first) first = first->right;
			
			int returnVal;
			
			Node *next = p->right, *bef = p->left;
			returnVal = p->n;
			if(next != NULL) next->left = bef;
			if(bef != NULL) bef->right = next;
			
			p->left = NULL; p->right = NULL; delete p;
			return returnVal;
		}
		
		class Iterator{
			Node* curr;
		public:
			Iterator(Node* np = NULL): curr(np){}
			Iterator& operator = (const Iterator& p){
				curr = p.curr;
				return *this;
			}
			bool operator != (const Iterator& p){
				return this->curr != p.curr;
			}
			int operator * () {
				return curr->n;
			}
			Node* operator & () {
				return curr;
			}
			Node* operator ++() {
				return (curr = curr->right);
			}
			Node* operator --(){
				return (curr = curr->left);
			}
		};
		Iterator begin(){
			return first;
		}
		Iterator end(){ // list�� ��. 
			return NULL;
		}
		
		Node* retL(){
			return last;
		}
		
		void sort(){
			for(Iterator it = begin(); it != end(); ++it){ // ��� ���ҿ� ���� 
				for(Iterator its = begin(); its != it; ++its){ // ���� ���Ĳ� 
					if(*its > *it){
						Iterator tmpIts = its; --tmpIts; // ���� Iterator�� ������ ���� ���� �ӽ� Iterator ���. 
						int cins = remove(&it);
						insert(&tmpIts, cins);
						break;
					}
				}
			}
		}
		
		ostream& print(ostream& os){
			for(Iterator it = begin(); it != end(); ++it){
				Iterator tmpIt = it; ++tmpIt; // ���� Iterator�� ������ ���� ���� �ӽ� Iterator ���. 
				os << *it << ( tmpIt != end() ? " " : "\n");
			}
			return os;
		}
};

int main() {
	int n, val;
	cin >> n;
    DblLnkList dll;
    
    for(int i=0; i<n; i++){
    	cin >> val;
    	dll.insert(dll.retL(), val); // last�� �������� ���� (��stack, queue) 
	}
	
	dll.sort();
	dll.print(cout);
	
    return 0;
}
