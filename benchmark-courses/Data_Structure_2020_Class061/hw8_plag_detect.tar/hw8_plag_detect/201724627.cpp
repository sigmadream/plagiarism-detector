#include <iostream>

using namespace std;

class DLList;

class Node{
  friend DLList;
private:
	int data;
	Node *prev;
	Node *next;

public:
	Node(){}

	void set_data(int x){
   data=x;
  }

	void set_prev(Node *x){
    prev=x;
  }

	void set_next(Node *x){
    next=x;
  }

	int get_data(){
    return this->data;
  }

	Node *get_prev(){
    return this->prev;
  }

	Node *get_next(){
    return this->next; 
  }
};

class DLList{
  friend Node;

public:
	Node *head= (Node *)malloc(sizeof(Node));
  Node *rear;
public:

 /* void insert(int x){
    Node* (*select);

    if(head == rear && head->data == 0){
      head->data=x;
      rear->data=x;
      return;
    }else{
      *select=head;

      Node *n=new Node();
		  n->data = x;
      n->next=NULL;
      n->prev=NULL;

      
      if(x > (*select)->data){
        if(*select==head){
          n->prev=NULL;
          (*select)->prev=n;
          n->next=*select;
          head=n;
          return;
        }
        else{
          (*select)->prev->next=n;
          n->prev=(*select)->prev;
          (*select)->prev=n;
          n->next=*select;
          return;
        }
      
      }
      else{
        while(*select != NULL){
          if(*select == rear){
            (*select)->next = n;
              n->prev=(*select);
            rear=n;
            return;
          }else{
            if(x < (*select)->data && x > (*select)->next->data){
              (*select)->next->prev = n;
              n->next=(*select)->next;
              (*select)->next = n;
              n->prev=(*select);
              return;
            }
          }
        }
      
        (*select)=(*select)->next;
      }
    }

  }

  void insert(int x){
    Node* n = (Node *)malloc(sizeof(Node));
    n->data = x;
    n->next=NULL;
    n->prev=NULL;
    Node* select= NULL;
    int found;
    if(this->head==NULL){
      n->next = n->prev =n;
      this->head = n;
    }else if(n->data < this->head->data){
      n->next = this->head;
      n->prev = this->head->prev;
      this->head->prev = n;
      this->head =n;
      this->head->prev->next = this->head;
    }else{
      select = this->head;
      found = 0;
      do{
        if( n->data < select->data){
          found = 1;
          break;
        }else{
          rear = select;
          select = select->next;
        }

      }while(select != this->head);

      if(found == 1){
        n->next = select;
        n->prev = select->prev;
        select->prev->next = n;
        select->prev = n;
      }else{
        n->next = this->head;
        n->prev = this->head->prev;
        this->head->prev->next = n;
        this->head->prev = n;
      }
    }

  }
  */
  void insert(int data){
    Node* n = (Node *)malloc(sizeof(Node));
    Node* select = head;
    
    n->data = data;
    n->next = NULL;
    n->prev = NULL;
  
    if(select==NULL){
        head = n;
        return;
    }
    while((select->data < data) && (select->next != NULL)){
        select = select->next;
    }       
    if(select->next == NULL && select->data < data){
        select->next = n;
        n->prev = select;
        return;
    }
    if(select->prev == NULL){
        head = n;
    }else{
        select->prev->next = n;   
    }
    n->prev = select->prev;
    n->next = select;
    select->prev = n;
    return;
}

	void print_nodes(){
		Node *x=this->head;
		while(x!=NULL)
		{
      if(x->next != NULL){
        cout<<x->get_data()<<" ";
      }else{
        cout<<x->get_data();
      }
			x=x->get_next();
		}
	}
};

int main()
{
	int n,x;
	cin>>n;
  DLList list;
  list.head=NULL;
	for(int i=0;i<n;i++)
	{
		cin>>x;
		list.insert(x);
	}
	list.print_nodes();
	return 0;
}