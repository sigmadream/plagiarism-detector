#include <iostream>
#include <cassert>

using namespace std;

class Node {
    int   data;
    Node *next;
public:
    friend class DblLnkList;
    Node(int d, Node *n): data(d), next(n) {}
};

class DblLnkList {
    Node *fst;
public:
    DblLnkList(): fst(nullptr) {}
    void push(int n) {
        Node *prev = fst;
        fst = new Node(n, prev);
    }
    void pop() {
        fst = fst->next;
    }
    int top() {
        return fst->data;
    }
    bool isEmpty() {
        return fst == nullptr;
    }
    	

    class Iterator {
        Node *curr;
        friend class DblLnkList;
    public:
        Iterator(Node *np=nullptr): curr(np) {}
        Iterator& operator =(const Iterator &p) {
            curr = p.curr;
            return *this;
        }
        bool operator !=(const Iterator &p) {			//!=
            return this->curr != p.curr;
        }
        int operator *() {								//*
            return curr->data;
        }
        Node* operator ++() {							//++(node)
            return (curr = curr->next);
        }
        Iterator operator +(int delta) {				//+
            assert(delta >= 0);
            Node *p = curr;
            while (delta-- > 0) {
                p = p->next;
            }
            return p;
        }
    };

    Iterator begin() {
        return fst;
    }
    Iterator end() {
        return nullptr;
    }

    ostream& print(ostream& out) {
        for (Iterator p = begin(); p != end(); ++p) {
            out << *p << (p + 1 != end()? " ": "\n");
        }
        return out;
    }
    
    void sort() {
    	if( fst == nullptr ) return;
		Iterator p = begin();
    	Iterator a = p;		//newone
    	if( p.curr->next == nullptr ) return;
    	Iterator b = p+1;	//nearest_oldone
		if( *a > *b ) {		//the newone is bigger than the oldone
			fst = b.curr;
			Node *temp = a.curr;
			a.curr->next = b.curr->next;
			b.curr->next = temp;
			b.curr = a.curr->next;
			Node *prev = fst;
			if(b.curr == nullptr) return;
			while( *a > *b ) {
				prev->next = b.curr;
				prev = prev->next;
				temp = a.curr;
				a.curr->next = b.curr->next;
				b.curr->next = temp;
				b.curr = a.curr->next;
				if(b.curr == nullptr) break;
			}
		}
	}
};

int main() {
    DblLnkList s;
    int n;
    cin >> n;
    int array[n];
    int as;
    for(int i = 0; i < n; i++) {
    	cin >> as;
        s.push(as);
		s.sort();
    }
	s.print(cout);
    return 0;
}
