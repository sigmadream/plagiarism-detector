#include <iostream>
#include <cassert>


using namespace std;

int finite=0;

void test(int n) {cout<<"test"<<n<<endl;};

class Node {
    int   data;
    Node *next;
public:
    friend class Stack;
    Node(int d, Node *n): data(d), next(n) {}
};

class Stack {
    Node *fst;
public:
    Stack(): fst(nullptr) {}
    void push(int n) {
        Node *prev = fst;
        fst = new Node(n, prev);
    }
    bool isEmpty() {
        return fst == nullptr;
    }
    void pop() { fst = fst->next; }
    int top() { return fst->data; }
    //------------------------------------------
	void insert(Node* p, int e) {		
		Node *newNode = new Node(e, p);
        Node *q = fst;
        if(p != q) {
            while(true) {
                if(q->next == p) break;
                q = q->next;
            }
            q->next = newNode;
        }
        else push(e);
	}
	void remove(Node *p) {
		Node* q;
		while(true) {
			if(q->next = p) break;
			q = q->next;
		}
		q->next = p->next;
	}
	void sort(Stack st) {
		push(st.top());
        st.pop();
        Iterator last;
		for(Iterator p=st.begin(); p!=st.end(); ++p){
            int check = 0;
            Iterator q = begin();
            Iterator q2 = nullptr;
            Iterator p2 = p;
            while(q != end()) {
                if(*p < *q) {
					insert(q.getCurr(), *p);
                    check = 1;
					break;
				}
                q2 = q;
                ++q;
            }
            if(check == 0) {
                insert(q2.getCurr()->next, *p);
            }
        }
	}
	//----------------------------------
    class Iterator {
        Node *curr;
    public:
        Iterator(Node *np = nullptr): curr(np) {}
        Iterator& operator =(const Iterator &p) {
            curr = p.curr;
            return *this;
        }
        bool operator !=(const Iterator &p) {
            return this->curr != p.curr;
        }
        int operator *() {
            return curr->data;
        }
        Node* operator ++() {
            return (curr = curr->next);
        }
        Iterator operator +(int delta) {
            assert(delta >= 0);
            Node *p = curr;
            while (delta-- > 0) {
                p = p->next;
            }
            return p;
        }
		Node* getCurr() { return curr; }
    };

    Iterator begin() {
        return fst;
    }
    Iterator end() {
        return nullptr;
    }

    ostream& print(ostream& out) {
        for (Iterator p = begin(); p != end(); ++p) {
            out << *p << (p + 1 != end()? " ": "\n");
        }
        return out;
    }
};
int main() {
	int n;
	Stack st1, st2;

    cin >> n;
	int* data = new int[n];
	for(int i=0; i<n; ++i) cin >> data[i];
	for(int i=0; i<n; ++i) st1.push(data[i]);

	st2.sort(st1);
	st2.print(cout);
}
