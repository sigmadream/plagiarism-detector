#include <iostream>
#include <cassert>

using namespace std;

class Node {
  int data;
  Node *next;
  Node *prev;
public:
  friend class DblLnkList;
  Node() {}
  Node(int d, Node *p, Node *n): data(d), prev(p), next(n) {}
};

class DblLnkList {
  Node *header;
  Node *trailer;
public:
  DblLnkList() {
    header = new Node();
    trailer = new Node();
    header->next = trailer;
    trailer->prev = header;
  }
  void insert(Node *p, int e) {
    Node *newNode = new Node(e, p->prev, p);
    p->prev->next = newNode;
    p->prev = newNode;
  }
  int remove(Node *p) {
    int tempData = p->data;
    p->prev->next = p->next;
    p->next->prev = p->prev;
    delete p;
    return tempData;
  }
  void prepend(int e) {
    Node *newNode = new Node(e, header, header->next);
    newNode->next->prev = newNode;
    header->next = newNode;
  }
  void append(int e) {
    insert(trailer, e);
  }

  class Iterator {
    Node *curr;
  public:
    Iterator(Node *np=nullptr): curr(np) {}
    Iterator& operator =(const Iterator &p) {
      curr = p.curr;
      return *this;
    }
    bool operator !=(const Iterator &p) {
      return this->curr != p.curr;
    }
    int operator *() {
      return curr->data;
    }
    Node* operator ++() {
      return (curr = curr->next);
    }
    Iterator operator +(int delta) {
      assert(delta >= 0);
      Node *p = curr;
      while(delta-- > 0) {
        p = p->next;
      }
      return p;
    }
    Node* getCurr() {
      return curr;
    }
  };

  Iterator begin() {
    return header;
  }
  Iterator end() {
    return trailer;
  }

  void sort(DblLnkList b) {
    int bStart;
    Iterator p;
    Iterator q = b.begin() + 1;
    while(q!=b.end()) {
      bStart = b.remove(q.getCurr());
      for(p = this->begin() + 1; p!=this->end(); ++p) {
        if(bStart < *p)
          break;
      }
      this->insert(p.getCurr(), bStart);
      q = b.begin() + 1;
    }
  }

  ostream& print(ostream& out) {
    for(Iterator p = begin() + 1; p!=end(); ++p) {
      out << *p << ((p + 1) != end()? " ": "\n");
    }
    return out;
  }
};

int main(void) {
  DblLnkList fst;
  DblLnkList scnd;

  int num, elem;
  cin >> num;
  if(num > 0) {
    cin >> elem;
    fst.prepend(elem);
    for(int i=1; i<num; i++) {
      cin >> elem;
      scnd.append(elem);
    }

    fst.sort(scnd);
    fst.print(cout);
  }
}
