#include <iostream>
#include <cassert>

using namespace std;

class Node {
    int   data;
    Node *next;
public:
    friend class Stack;
    Node(){}
    Node(int d, Node *n): data(d), next(n) {}
};

class Stack {
    Node *fst;
public:
    Stack(): fst(nullptr) {}
    void push(int n) {
        Node *prev = fst;
        fst = new Node(n, prev);
    }
    int pop() {
        Node* newNode = new Node;
        int m =fst->data;
        newNode = fst;
        fst = fst->next;
        free(newNode);
        return m;
    }
    int top() {
        return fst->data;
    }
    bool isEmpty() {
        return fst == nullptr;
    }
    bool isEmpty(Node *p) {
        return p == nullptr;
    }


    class Iterator {
        Node *curr;
    public:
        Iterator(Node *np=nullptr): curr(np) {}
        Iterator& operator =(const Iterator &p) {
            curr = p.curr;
            return *this;
        }
        bool operator !=(const Iterator &p) {
            return this->curr != p.curr;
        }
        int operator *() {
            return curr->data;
        }
        Node* operator ++() {
            return (curr = curr->next);
        }
        Iterator operator +(int delta) {
            assert(delta >= 0);
            Node *p = curr;
            while (delta-- > 0) {
                p = p->next;
            }
            return p;
        }
        void input(int n){
            curr->data = n;
        }
    };

    Iterator begin() {
        return fst;
    }
    Iterator end() {
        return nullptr;
    }
    void Switch(){
        Node* tmp = fst;
        int n = 1;
        for ( Node* tmp = fst; isEmpty(tmp) != true; tmp= tmp->next){
            for(Node* tmq = fst;isEmpty(tmq->next) != true; tmq= tmq->next){
                if( tmq->data > tmq->next->data){
                    int temp = tmq->next->data;
                    tmq->next->data = tmq->data;
                    tmq->data = temp;
                }
            }
            n++;
        }


    }
    void Sort(int n){
        for (Iterator p = begin(); p != end(); ++p){
            Switch();
        }
    }

    ostream& print(ostream& out) {
        for (Iterator p = begin(); p != end(); ++p) {
            out << *p << (p + 1 != end()? " ": "\n");
        }
        return out;
    }
};

int main() {
    int k, u, x;
    Stack s,v;
    cin >> k;
    int ns[k] = {};
    for(int j = 0 ; j<k; j++){
        cin >> u;
        ns[j] = u;
    }

    for (int n: ns) {
        s.push(n);
    }
    for(int j = 0 ; j<k; j++){
        x = s.pop();
        v.push(x);
        v.Sort(x);


    }
    v.print(cout);
}
