#include <iostream>
#include <list>
#include <algorithm>
#include <vector>
#include <string>
#include <ctype.h>


using namespace std;

class Dbl{
    public:
        Dbl(){size,originSize = 0; arr = new int[size];};
        Dbl(int val):size(0),originSize(val){arr = new int[size];};
        void push(int value);
        void pop();
        void show()const;
        void insertionSort();
    private:
        int *arr;
        int size, originSize;
};
void Dbl::push(int value){
    arr[size] = value;
    size++;
}

void Dbl::show()const{
    for(int i = 0; i < originSize; i++){
        cout << arr[i];
        if(i < originSize-1)
            cout << " ";
    }
}

void Dbl::insertionSort(){
    for(int i = 0; i < originSize - 1; i++){
        int temp = i;
        for(int j = i + 1; j < originSize; j++){
            if(arr[temp] > arr[j]){
                temp = j;
            }
        }
        int tmp = arr[i];
        arr[i] = arr[temp];
        arr[temp] = tmp;
    }
}

int main(){
    int size, input;
    cin >> size;
    Dbl * dbl = new Dbl(size);
    for(int i = 0; i < size; i++){
        cin >> input;
        dbl -> push(input);
    }
    dbl->insertionSort();
    dbl->show();
}