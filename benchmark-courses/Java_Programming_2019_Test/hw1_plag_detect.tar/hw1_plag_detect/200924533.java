import java.util.Scanner;
import java.io.PrintStream;
import java.io.File;
import java.io.FileNotFoundException;

public class Average3 {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in); 
		PrintStream ps = new PrintStream(System.out);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		double average = (a + b + c) / 3.0;
		ps.printf("%.2f\n", average);
		
		ps.close(); 
		sc.close();
	}
}
