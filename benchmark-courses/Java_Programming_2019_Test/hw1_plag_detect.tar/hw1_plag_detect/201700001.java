import java.util.Scanner;
public class Average3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        //double sum = a + b + c;
        //System.out.printf("sum is %f\n", sum);
        double average = (double) (a+b+c)/3;
        System.out.printf("%.2f%n", average);
        //System.out.println("something");
        sc.close();
    }
}