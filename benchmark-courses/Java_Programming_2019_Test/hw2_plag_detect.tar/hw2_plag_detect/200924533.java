import java.util.Scanner;
import java.io.PrintStream;
import java.io.FileNotFoundException;

public class HW01 {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in); 
		PrintStream ps = new PrintStream(System.out);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		int numberOfroot;
		double d = (b*b) - (4*a*c);
		if(d > 0) {
			numberOfroot = 2;
			ps.printf("%d\n", numberOfroot);
		}
		else if( d == 0){
			numberOfroot = 1;
			ps.printf("%d\n", numberOfroot);
		}
		else{
			numberOfroot = 0;
			ps.printf("%d\n", numberOfroot);
		}
		
		ps.close(); 
		sc.close();
	}
}
