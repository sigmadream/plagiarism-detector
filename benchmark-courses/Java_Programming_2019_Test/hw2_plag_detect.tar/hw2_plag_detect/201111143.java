import java.util.Scanner;

public class HW01_Determinant {
	public static void main(String[] args ) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int determinant = b*b - 4*a*c;
		if(determinant>0)
			System.out.printf("%d\n", 2);
		if(determinant==0)
			System.out.printf("%d\n", 1);
		if(determinant<0)
			System.out.printf("%d\n",0);
		sc.close();
	}
}
