import java.util.Scanner;

public class Determinant {

	public static void main(String[] args) {
		int s1,s2,s3;
		Scanner sc = new Scanner(System.in);
		s1 = sc.nextInt();
		s2 = sc.nextInt();
		s3 = sc.nextInt();
		sc.close();
		int equ = (s2*s2)-(4*s1*s3);
		if(equ > 0) {
			System.out.println("2");
		}
		else if(equ == 0) {
			System.out.println("1");
		}
		else System.out.println("0");
	}

}
