import java.util.Scanner;
 
public class HW01 {
	
	public static void main(String[] args) {
			
		Scanner sc = new Scanner(System.in);
		
		int first = sc.nextInt();
		int second = sc.nextInt();
		int third = sc.nextInt();
		
		int root = second*second - 4 * first * third;
		int number;
		
		if(root>0) {
			number = 2;
		}
		else if(root==0) {
			number = 1;
		}
		else {
			number = 0;
		}
		
		System.out.print(number);
		
		sc.close();
		
		;
		
	}
		
}