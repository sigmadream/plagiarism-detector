
import java.io.PrintStream;
import java.util.Scanner;

public class Determinant {

	 
	 public static void main(String[] args){
	  
	  Scanner sc = new Scanner(System.in);
	  PrintStream ps = System.out;
	  
	  int a = sc.nextInt();
	  int b = sc.nextInt();
	  int c = sc.nextInt();
	  
	  int determinant =  (b*b) - 4*a*c;
	  
	  if (determinant > 0){
		  ps.printf("2");
	  } else if (determinant == 0) {
		  ps.printf("1");
	  } else {
		  ps.printf("0");
	  }
	  
	  ps.close();
	  sc.close();
	 }
	 
}
