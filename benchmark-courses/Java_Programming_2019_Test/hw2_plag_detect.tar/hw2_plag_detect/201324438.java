import java.io.PrintStream;
import java.util.Scanner;

public class Determinent {
	static public void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		if(b * b - 4 * a * c > 0)
			ps.println('2');
		if(b * b - 4 * a * c == 0)
			ps.println('1');
		if(b * b - 4 * a * c < 0)
			ps.println('0');
		
		sc.close();
		ps.close();
	}
}
