import java.util.Scanner;
import java.io.PrintStream;

public class Determinant {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		int share = b*b-4*a*c;
		if (share > 0)
			System.out.println(2);
		else if (share == 0)
			System.out.println(1);				
		else
			System.out.println(0);

		sc.close();
	}
}


