import java.util.Scanner;

public class Determinant {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int num3 = sc.nextInt();
		
		double det = (num2*num2) - 4*num1*num3;
		
		
		if (det == 0)
		{
			System.out.println("1");
		}
		else if (det>0)
		{
			System.out.println("2");
		}
		else
		{
			System.out.println("0");
		}
		
		
	}

}
