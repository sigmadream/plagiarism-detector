import java.io.PrintStream;
import java.util.Scanner;

public class Determinant {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double ret = b*b-4*a*c;
		if(ret > 0) {
			ps.println(2);
		}
		else if(ret == 0) {
			ps.println(1);
		}
		else {
			ps.println(0);
		}
	}

}
