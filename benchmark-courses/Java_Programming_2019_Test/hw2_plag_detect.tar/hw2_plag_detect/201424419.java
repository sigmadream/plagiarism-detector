
import java.io.PrintStream;
import java.util.Scanner;

public class Determinant {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
//		PrintStream ps = new PrintStream(System.out);
		int ax2 = sc.nextInt();
		int bx = sc.nextInt();
		int c = sc.nextInt();
		
		
		int determ = (bx*bx) -(4*ax2*c);
		if(determ >0){
			System.out.println(2);
		}else if(determ == 0){
			System.out.println(1);
		}else{
			System.out.println(0);
		}
		
		sc.close();
//		ps.close();

	}

}
