import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class Share {
	public static void main(String[] args) throws FileNotFoundException{
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int share1 = b * b;
		int share2 = 4 * a * c ;
		int share3 = share1 - share2;
		if(share3 > 0) {
			System.out.println("2");
		}
		if(share3 == 0) {
			System.out.println("1");
		}if(share3 < 0) {
			System.out.println("0");
		}
		sc.close();
		
	}
}
