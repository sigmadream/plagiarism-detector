import java.io.PrintStream;
import java.util.Scanner;

public class Determinant{
	public static void main(String[] args) { 
		Scanner sc = new Scanner(System.in);
		int coe_a,coe_b,const_c;
		int x0=0,x1=1,x2=2;
		coe_a=sc.nextInt();
		coe_b=sc.nextInt();
		const_c=sc.nextInt();
		PrintStream ps = System.out;
		int Det = coe_b*coe_b-4*coe_a*const_c;
		if(Det>0) {
			ps.printf("%d%n",x2);
		}
		if(Det==0) {
			ps.printf("%d%n",x1);
		}
		if(Det<0) {
			ps.printf("%d%n",x0);
		}
		ps.close();
		sc.close();
	}
}