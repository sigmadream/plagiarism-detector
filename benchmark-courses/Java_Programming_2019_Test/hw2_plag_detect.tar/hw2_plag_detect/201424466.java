import java.util.Scanner;
import java.io.PrintStream;
 
public class Determinant {
 public static void main(String[] args) {
   Scanner sc = new Scanner(System.in);
  PrintStream ps =System.out;
  int a = sc.nextInt();
  int b = sc.nextInt();
  int c = sc.nextInt();
  double deter =b*b-4*a*c;
  if(deter>0){
  ps.println("2");
  }else if(deter==0){
  ps.println("1");
  }else{
  ps.println("0");
  }

  ps.close(); 
  sc.close();
 }
} 