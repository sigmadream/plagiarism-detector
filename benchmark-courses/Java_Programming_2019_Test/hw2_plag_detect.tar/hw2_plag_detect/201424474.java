import java.io.PrintStream;
import java.util.Scanner;

public class HW1_Determinant {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		while(a == 0) {
			System.out.println("Please, reinput");
			a = sc.nextInt();
			b = sc.nextInt();
			c = sc.nextInt();
		}
		
		
		int Det = b*b - 4*a*c;
		
		if(Det > 0) {
			System.out.println("2");
		}
		else if(Det == 0) {
			System.out.println("1");
		}
		else {
			System.out.println("0");
		}
		
		sc.close();
		ps.close();
		
	}
}
