import java.io.PrintStream;
import java.util.Scanner;

public class Homework01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double D = (b*b-4*a*c);
		if (D > 0)
			System.out.printf("2");
		else if (D == 0)
			System.out.printf("1");
		else
			System.out.printf("0");
		sc.close();
		ps.close();
	}
}