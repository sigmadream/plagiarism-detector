import java.util.Scanner;


public class dfafa {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		int d = b*b - 4*a*c;
		
		if (d<0){
			System.out.print("0");
		}
		else if (d==0){
			System.out.print("1");
		}
		else {
			System.out.print("2");
		}
		sc.close();

	}
}
