import java.util.Scanner;

public class Homework01 {
	public static void main(String[] args) { 
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int Determinant = (b*b-4*a*c);
		sc.close();
		
		if (Determinant == 0){
			System.out.println("1");
		}
		if (Determinant > 0){
			System.out.println("2");
		}
		if (Determinant < 0){
			System.out.println("0");
		}
	}
}