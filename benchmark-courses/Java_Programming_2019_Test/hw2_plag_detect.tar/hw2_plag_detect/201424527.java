
import java.util.*;
import java.io.PrintStream;

public class determinant {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int determ = (b*b) - (4*a*c);
		
		if(determ > 0)
		{
			ps.println(2);
		}
		else if(determ == 0)
		{
			ps.println(1);
		}
		else if(determ < 0)
		{
			ps.println(0);
		}
		sc.close();
		ps.close();
	}
}
