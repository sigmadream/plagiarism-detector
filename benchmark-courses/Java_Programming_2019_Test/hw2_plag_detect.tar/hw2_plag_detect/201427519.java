import java.io.PrintStream;
import java.util.Scanner;

public class Determinant {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int D=6;
		if((b*b-4*a*c)>0){
			D=2;
		}
		else if((b*b-4*a*c)<0){
			D=0;
		}
		else{
			D=1;
		}
		ps.printf("%d",D);
		ps.close();
		
	}

}
