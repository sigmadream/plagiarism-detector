import java.io.PrintStream;
import java.util.Scanner;

public class Derterminant {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int det = b*b - 4*a*c;
		
		if(det > 0)
			System.out.println("2");
		else if(det == 0)
			System.out.println("1");
		else
			System.out.println("0");
		sc.close();
		ps.close();
	}
}
