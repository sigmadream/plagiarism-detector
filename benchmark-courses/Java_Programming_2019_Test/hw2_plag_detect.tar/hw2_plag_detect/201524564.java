import java.util.Scanner;
import java.io.PrintStream;


public class Determinant{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int i = sc.nextInt();
		int j = sc.nextInt();
		int k = sc.nextInt();
		if (D(i,j,k) < 0)
			ps.printf("0");
		else if(D(i,j,k) == 0)
			ps.printf("1");
		else if(D(i,j,k) > 0)
			ps.printf("2");
		sc.close();
	}
	public static int D(int a, int b, int c) {
		int Deter = b*b-4*a*c;
		return Deter;
	}
	
}
