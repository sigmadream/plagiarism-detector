package hw01;

import java.util.Scanner;

public class hw01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double share = (b*b-4*a*c);
		
		if(share == 0) {
			System.out.println(1);
		}
		
		if(share > 0) {
			System.out.println(2);
		}
		
		if(share < 0) {
			System.out.println(0);
			
		}
		
		sc.close();
		
	}

}
