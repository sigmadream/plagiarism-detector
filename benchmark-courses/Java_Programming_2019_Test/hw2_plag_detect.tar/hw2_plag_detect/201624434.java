package project1;
import java.util.Scanner;

public class det {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c,D;
		
		Scanner scan = new Scanner(System.in);  
		a=scan.nextInt();
		b=scan.nextInt();
		c=scan.nextInt();
		D=b*b-4*a*c;
		if(D>0){
			System.out.println("2");
		}
		else if(D==0){
			System.out.println("1");
		}
		else {
			System.out.println("0");
		}
		scan.close();
	}

}
