
import java.io.PrintStream;
import java.util.Scanner;

public class root {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps =System.out;
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double d = b*b-4*a*c;
		int e;
		if (d > 0) e=2;
		else if(d==0) e=1;
		else e=0;
		ps.printf("%d", e);
		ps.close();
		sc.close();
		}
	}
