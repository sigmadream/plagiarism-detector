

import java.util.Scanner;

public class determinant {
	public static void main(String[] args)
	{
		
		
		Scanner sc = new Scanner(System.in);
		
		
		int a = sc.nextInt();
	
		int b = sc.nextInt();
		
		int c = sc.nextInt();
		
		double D = b*b - 4.0*a*c;
		
		
		if (D > 0)
		{
			System.out.println("2");
			
		}
		else if (D == 0)
		{
			System.out.println("1");
			
		}
		else if (D < 0)
		{
			System.out.println("0");
			
		}
		sc.close();
	}
	

}
