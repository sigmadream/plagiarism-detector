package determinant1.java;
import java.util.Scanner;

public class Determinant1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int d = b^2 - 4 * a * c;
		if (d == 0) {
			 System.out.println("1");
		 } else if (d >= 0) {
			 System.out.println("2");
			 
		 } else if (d <= 0) {
			 System.out.println("0");
		 }
		sc.close();
	}
}

