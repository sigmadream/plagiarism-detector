import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintStream;

public class Determinant {
  public static void main(String[] args) throws FileNotFoundException {
	  Scanner sc = new Scanner(System.in);
	  PrintStream ps = System.out;
	  
	  int[] integers = new int[3];
	  for(int i=0; i<3;i++)
	  {
		  integers[i]=sc.nextInt();
	  }
	  int a = integers[0];
	  int b = integers[1];
	  int c = integers[2];
	  
	  int det = b*b-4*a*c;
	  
	  if(det>0){  
		ps.printf("2");
		}else if(det==0){  
			ps.printf("1");  
		}  
		else{  
			ps.printf("0"); 
		}  
	  ps.close();
	  sc.close();
  }
}
