import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza = 0;
		int sum = 0;
		double s_square = 0;
		int cnt = 0;
		double mean = 0;
		double result;
		
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		
		int[] b = new int[sza];
		for(int i = 0; i < sza; i++)
			b[i] = a[i];
		
		if(b[0] % 2 == 0){
			for(int i = 0; i < sza; i+=2){
				sum += b[i];
				cnt ++;
			}
			mean = (double)sum / (double)cnt;
			for(int i = 0; i < sza; i+=2){
				s_square += (b[i] - mean) * (b[i] - mean);
			}
		}
		else {
			for(int i = 1; i < sza; i+=2){
				sum += b[i];
				cnt++;
			}
			mean = (double)sum / (double)cnt;
			for(int i = 1; i < sza; i+=2){
				s_square += (b[i] - mean) * (b[i] - mean);
			}
		}
		
		result = s_square / (cnt - 1);
		
		ps.printf("%.2f\n", result);
		
		sc.close();
	}
}
