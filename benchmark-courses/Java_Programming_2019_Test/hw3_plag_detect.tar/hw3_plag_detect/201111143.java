import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] X = new int[500];
		int szx = 0;
		for (int i = 0; sc.hasNextInt(); szx++, i++)
			X[i] = sc.nextInt();
		int szb=0;
		int[] b = new int[500];
		
		if(X[0]%2==0){
			for(int i=0;2*i<szx; szb++,i++)
				b[i]=X[2*i];
		}
		if(X[0]%2==1){	
			for(int i=0;(2*i+1)<szx;szb++,i++)
				b[i]=X[2*i+1];
		}
		double sum=0;
		for(int i=0;i<szb;i++)
			sum += b[i];
		double y=sum/szb;
		double s=0,s2=0;
		for(int i=0;i<szb;i++)
			s += (b[i]-y)*(b[i]-y);
		s2 =s/(szb-1);
		ps.printf("%.2f",s2);
		sc.close();
	}
}