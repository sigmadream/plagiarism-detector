import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] x = new int[500];
		int szx = 0;
		for(; sc.hasNextInt(); ++szx)
			x[szx] = sc.nextInt();
		
		int[] y = new int[251];
		int szy = 0;
		
		if(x[0]%2==0) {
			for(int i=0; i<szx; i+=2, ++szy)
				y[szy] = x[i];
		} 
		else {
			for(int i=1; i<szx; i+=2, ++szy)
				y[szy] = x[i];
		}
		
		double m_y=0;
		for(int i=0;i<szy;++i)
			m_y += y[i];
		m_y /= szy;
		
		double answer=0;
		for(int i=0;i<szy;++i)
			answer += (y[i]-m_y)*(y[i]-m_y);
		answer /= szy-1;
		
		ps.printf("%.2f%n",answer);
		sc.close();
	}
	
}
