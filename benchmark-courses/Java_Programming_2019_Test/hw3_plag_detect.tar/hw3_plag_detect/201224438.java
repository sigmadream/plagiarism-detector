import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza = 0;
		int szb = 0;
		int sum = 0;
		double ssum =0;
		
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		int c= a[0]%2;
		int[] b= new int[sza];
		for(int i=c; i<sza; i+=2){
			b[szb]=a[i];
			sum +=b[szb];
			szb++;
		}
		double ybar = sum/(double)szb;
		
		for(int i=0; i<szb; i++){
			ssum += (b[i]-ybar)*(b[i]-ybar);
		}
		
		double s = ssum/(szb-1);
		ps.printf("%.2f%n",s);
		sc.close();
	}
}
