import java.io.PrintStream;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[100];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		
		
		int spsz = ( a[0]%2 == 0 && sza %2 == 1) ? (sza/2 + 1) : (sza/2);
		
		
		int[] b = new int[spsz];
		
		int spsum = 0;
		
		if(a[0]%2 == 0)
			for(int i = 0; i< spsz; i++ ){
				b[i] = a[i*2];
				spsum += b[i];
			}
		else
			for(int i = 0; i< spsz; i++ ){
				b[i] = a[i*2 + 1];
				spsum += b[i];
			}
		
		double spmean = (double)spsum/spsz;
		 
		double svar = 0;
		
		for(int i = 0; i< spsz; i++ ){
			svar += (b[i] - spmean)*(b[i] - spmean);
		}
		
		svar /= (spsz - 1);
		
		
		ps.printf("%.2f",svar);
		
		sc.close();
	}	
}