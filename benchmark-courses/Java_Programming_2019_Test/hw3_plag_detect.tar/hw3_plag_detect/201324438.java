import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		float average = 0;
		float sum = 0;
		int sza = 0, count = 0, index;
		
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		
		if(a[0] % 2 == 0) index = 0;
		else index = 1;
	
		for(int i = index; i < sza; i = i + 2){
			average += a[i];
			count++;
		}
		
		average = average / count;

		for(int i = index; i < sza; i = i + 2)
			sum += (a[i] - average) * (a[i] - average);
		sum = sum / (count - 1);

		ps.printf("%.2f%n",sum);
		
		sc.close();
	}
}