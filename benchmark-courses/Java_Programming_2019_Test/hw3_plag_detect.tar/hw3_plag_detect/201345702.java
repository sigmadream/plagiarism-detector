import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		int[] a = new int[10000];
		int sza = 0, szb;
		
		for(int i = 0; sc.hasNextInt(); i++, sza++) {
			a[i] = sc.nextInt();
		}
		
		int[] b;
		if(sza%2 == 1 && a[0]%2 == 0)
			szb = (sza/2)+1;
		else
			szb = (sza/2);
		b = new int[szb];
		for(int i = 0, j = 0; i < sza; ++i) {
			if((a[0]%2 == 1 && i%2 == 1) || (a[0]%2 == 0 && i%2 == 0))
				b[j++] = a[i];
			
		}
		double avg = 0, sqs = 0;
		for(int n : b)
			avg += n;
		avg /= szb;
		for(int n : b) {
			sqs += (n-avg)*(n-avg);
		}
		sqs /= szb-1;
		ps.printf("%.2f%n", sqs);

		sc.close();
	}
}
