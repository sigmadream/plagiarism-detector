import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class Svar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		int[] b = new int[sza];
		for(int i = 0 ; i < sza; i++)
			b[i] = a[i];
		
//		for(int i = 0 ; i < sza; i++)
//			System.out.print(b[i] + " ");
		int count = 0 ;
		int sum = 0;
		double avg = 0.0;
		double result = 0.0;
		if(b[0]%2 == 0){
			for(int i = 0 ; i < sza;i+=2){
				sum+= b[i];
				count++;
			}
			
			avg = (double) sum/count;
			for(int i = 0 ; i < sza;i+=2){
				result += (b[i]-avg)*(b[i]-avg);
			}
			result =  result /(count-1);
			ps.printf("%.2f", result);
		}else{
			for(int i = 1 ; i < sza;i+=2){
				sum+= b[i];
				count++;
			}
			avg = (double)sum/count;
			for(int i = 1 ; i < sza;i+=2){
				result += (b[i]-avg)*(b[i]-avg);
			}
			result =  result /(count-1);
			ps.printf("%.2f", result);
		}
		
		sc.close();
	}
}