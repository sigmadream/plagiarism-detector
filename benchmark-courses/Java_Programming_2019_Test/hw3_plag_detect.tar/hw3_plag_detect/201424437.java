import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		ps.printf("%d elements are read.%n", sza);

		int[] b = new int[sza];
		if (a[0]%2 == 0)
			for (int i = 0; i < sza; i+=2)
				b[i] = a[i];
		int szb = 0;
		int Sum = 0;
		for(int i = 1; i < b.length; i++)
			Sum += b[i];
		int Sumb = (Sum/b[0]);
		
		ps.printf("%2f",Sumb);
		
		float Cal = 0;
		for(int i = 2; i<b.length; i +=2)
			 Cal +=((b[i]-Sumb)*(b[i]-Sumb));
		
		float result = 0;
		result = (Cal/b[0]);
		ps.printf("%2f", result);
		
		ps.printf("array a = %s%n", Arrays.toString(a));
		ps.printf("array b = %s%n", Arrays.toString(b));

		sc.close();
	}
}
