import java.util.ArrayList;
import java.util.Arrays;
import java.io.PrintStream;
import java.util.Scanner;
public class SVar {

    public static int sum(ArrayList<Integer> list) {

         int sum = 0;
        for (int i = 0; i < list.size(); i++){
           sum = sum + list.get(i);
        }

        return sum;
    }


    public static double average(ArrayList<Integer> list) {
        double average = sum(list) / list.size();
        return average;
    }

    public static double variance(ArrayList<Integer> list) {

        double sumMinusAverage = sum(list) - average(list);

        double result = 1/(list.size()-1) * Math.pow(sumMinusAverage, 2);

        return result;
    }

    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<Integer>();
        Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		ps.printf("%d elements are read.%n", sza);

		int[] b = new int[sza];
		for(int i =0; i<sza; i++)
			b[i] = a[i];
		
		ps.printf("And the even integers are:");
		for (int n: a)					 // for every n in array a
			if (n % 2 == 0) 			 // if n is even
				ps.printf(" %d", n);	// print n
		ps.println();
		ps.printf("array a = %s%n", Arrays.toString(a));
		ps.printf("array b = %s%n", Arrays.toString(b));
		ps.println(Arrays.toString(a));
		sc.close();
	}
}
    