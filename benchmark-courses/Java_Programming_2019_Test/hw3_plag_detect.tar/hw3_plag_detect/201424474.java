import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int[] idx = new int[500];
		int szx = 0;
		
		for (int i = 0; sc.hasNextInt(); szx++, i++)
			idx[i] = sc.nextInt();
		
		int[] x = new int[szx];
		
		for (int i = 0; i < szx; i++)
			x[i] = idx[i];
		
		int[] y = new int[szx/2+1];
		int szy = 0;
		
		if (x[0] % 2 == 1)
			for (int i = 0; 2*i+1 <szx; szy++,  i++)
				y[i] = x[2*i+1];
		
		else
			for (int i = 0; 2*i < szx; szy++,  i++)
				y[i] = x[2*i];
		
		int sumy = 0;
		
		for (int i = 0; i < szy; i++)
			sumy += y[i];
		
		double noty = 0.0;
		noty = (double) sumy / szy;
		
		double ssquare = 0.0;
		
		for (int i = 0; i < szy; i++)
			ssquare += (y[i]-noty)*(y[i]-noty);
		
		ssquare /= (szy-1);
		ps.printf("%.2f%n", ssquare);
		
		sc.close();
	}
}
