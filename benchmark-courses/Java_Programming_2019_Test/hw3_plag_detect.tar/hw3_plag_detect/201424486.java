import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class Lab02 {
	 public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 PrintStream ps = System.out;
		 int[] a = new int[10];
		 int sum =0;
		 int sza = 0;
		 double s = 0;
		 double ss = 0;
		 double oddcount = 0;
		 double ave = 0;
		 for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		 
		 int []b = new int[sza];
			for(int i=1; i<sza; i=i+2)
				b[i] = a[i];
				
		
		 
		 for(int j=0; j<sza; j++)
			 sum += b[j];
		 
		 oddcount = sza/2;
		 ave = sum/oddcount;
		 
		 for(int j=1; j<sza; j=j+2){
			 ss = ss + (b[j]-ave)*(b[j]-ave);
		 }
		 s = ss/(sza/2 - 1);
		 ps.printf("%.2f", s);
		 sc.close();
		 }
	 }
