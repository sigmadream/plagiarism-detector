import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza = 0;
		int c = 0;
		int d = 0;
		double avg = 0;
		double s = 0;
		double s2 = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();

		if (a[0] % 2 == 0) {
			for(int i=2; i < sza; i+=2) {
				c += a[i];
				d++;
			}
			avg = c/d;
			for(int i=2; i < sza; i+=2) {
				s += (a[i]- avg)*(a[i]- avg);
			}
			s2 = s/3;
		}
		else{
			for(int i=1; i < sza; i+=2) {
				c += a[i];
				d++;
			}
			avg = c /d;
			for(int i=1; i < sza; i+=2) {
				s += (a[i]- avg)*(a[i]- avg);
			}
			s2 = s/3;
		}
		ps.println();
		ps.printf("%.2f",s2);
		sc.close();
	}
}