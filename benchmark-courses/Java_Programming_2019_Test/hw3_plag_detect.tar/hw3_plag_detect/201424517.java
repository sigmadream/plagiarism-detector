import java.io.PrintStream;

import java.util.Scanner;

public class SVar {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int []a = new int[500];
		int sza = 0;
		for(int i = 0;sc.hasNextInt();sza++,i++)
			a[i] = sc.nextInt();
		int []b = new int[sza];
		for(int i = 0;i<sza;i++)
			b[i] = a[i];

		if(b[0]%2==0){

			int size=0;
			for(int i=0;i<sza;i=i+2,size++);
			int []y = new int[size];

			for(int i=0,j=0;i<sza;i=i+2,j++){
				y[j] = b[i];

			}

			double sum =0;
			for(int i=0;i<size;i++)
				sum+=y[i];

			double mean = sum/size;

			double s = 0;

			for(int i=0;i<size;i++){

				s += (y[i]-mean)*(y[i]-mean)/(size-1);
			};

			ps.printf("%.2f",s);
		};

		if(b[0]%2!=0){

			int size=0;
			for(int i=0;i<sza-1;i=i+2,size++);
			int []y = new int[size];

			for(int i=1,j=0;i<sza;i=i+2,j++){
				y[j] = b[i];

			}

			double sum =0;
			for(int i=0;i<size;i++)
				sum+=y[i];

			double mean = sum/size;

			double s = 0;

			for(int i=0;i<size;i++){

				s += (y[i]-mean)*(y[i]-mean)/(size-1);
			};

			ps.printf("%.2f",s);
		};


		sc.close();





	}

}
