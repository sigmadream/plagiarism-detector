import java.io.PrintStream;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n =0;
		int[] a = new int[10];
		int i = 0,sum = 0,szak = 0;
		while(sc.hasNextInt()){
			n = sc.nextInt();
			a[i++] = n;
		}
		int[] b = new int[i];
		if (i % 2 == 0)
		{
			for (int j = 0; j < i-2 ; szak++){
				j += 2;
				b[j] = a[j];
				sum += b[j];
			}
		}
		else if (i % 2 == 1)
		{
			for (int k = 0; k < i -2; szak++){
				k += 2;
				b[k] = a[k];
				sum += b[k];
			}
		}
		int average = sum / szak;
		int s1 = 0;
		for (int t = 0; t < szak ; ){
			s1 +=(b[t] - average)*(b[t] - average);
		}
		int s2 = s1 / (szak -1);
		ps.printf("%.2f%n", s2);
		sc.close();
	}
}