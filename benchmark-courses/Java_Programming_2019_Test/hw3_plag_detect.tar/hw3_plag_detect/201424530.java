import java.util.Scanner;

public class Svar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] a = new int[10];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		
		int[] b = new int[sza];
		for (int i =0; i <sza; i++)
			b[i] =a[i];
		
		int fv=(b[0]%2);
		int d=0, picksum=0;
		for(int i =fv; i<sza; i=i+2){
			a[d]=b[i];
			picksum+=b[i];
			d++;
		}
		double avg=(double)picksum/d;
		double square=0;
		for (int i=0; i<d; i++){
			square+=(avg-a[i])*(avg-a[i]);
		}
		double s = square/(d-1);
		
		//ps.printf("Yset is:");
		//{for (int n: a){
		//	if (a[0] % 2 == 0){
		//		ps.printf(" %d", a[n+n+1]);
		//	}
		//	else if (a[0] %2 == 1){
		//		ps.printf(" %d", a[n+n]);
		//	}// print n
		//}
		//ps.println();
		//ps.printf("array a = %s%n", Arrays.toString(a));
		//ps.printf("OUTPUT= %.2f \n", output);
		//sc.close();
		System.out.printf("%.2f%n", s);
		sc.close();
	}
}
