import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class Svar1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		
		int[]b = new int[sza];
		for (int i =0; i <sza ; i++)
			b[i]=a[i];
		int numodd=0; 
		int numeven=0;
		float meanodd, meaneven, varodd, vareven,sumodd,sumeven;
		sumodd=0; sumeven=0;varodd=0;vareven=0;float a1=0;float a2=0;
		
		if (b[0]%2==1){
		for (int j=1; j<b.length;j+=2,numodd++){ // for every n in a
			sumodd+= b[j];}
		meanodd=sumodd/numodd;
		for (int j=1; j<b.length;j+=2) // for every n in a
			a1+= (b[j]-meanodd)*(b[j]-meanodd);
		varodd=a1/(numodd-1);
		ps.printf("%.2f",varodd);
		}
		else {
			for (int j=0; j<b.length;j+=2,numeven++){ // for every n in a
				sumeven+= b[j];}
			meaneven=sumeven/numeven;
			for (int j=0; j<b.length;j+=2) // for every n in a
				a1+= (b[j]-meaneven)*(b[j]-meaneven);
			vareven=a1/(numeven-1);
			ps.printf("%.2f",vareven);
			}
		sc.close();
	}
}
