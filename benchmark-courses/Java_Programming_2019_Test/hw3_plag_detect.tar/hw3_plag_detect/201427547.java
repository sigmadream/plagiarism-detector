import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

	public class SVar {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			PrintStream ps = System.out;
			int[] a = new int[500];
			int sza = 0;
			for (int i = 0; sc.hasNextInt(); sza++, i++)
				a[i] = sc.nextInt();
			
			int[] b = new int[sza];
			for (int i = 0; i < sza; i++)
				b[i] = a[i];
			int szb_odd = 0;
			int szb_even = 0;
			for (int i = 0; i < b.length; i++){
				if (i % 2 == 0){
					szb_even++;
				}
				if (i % 2 == 1){
					szb_odd++;
				}
			}
			szb_even = szb_even - 1;
			double var_y = 0;
			double c = 0;

			if(b[0] % 2 == 0){
				double d = 0;
				double y_bar;
				for(int i = 0; i < szb_even; i++){
					d = d + b[2*i +1];
				}
				y_bar = d / szb_even;
				for(int i = 0; i < szb_even; i++){
					c += (b[2*i+1] - y_bar)*(b[2*i+1] - y_bar);
				}
				var_y = c / (szb_even - 1);
				ps.printf("%.2f", var_y);
			}
			else if(b[0] % 2 == 1){
				double d = 0;
				double y_bar;
				for(int i = 0; i < szb_odd; i++){
					d = d + b[i*2];
				}
				y_bar = d / szb_odd;
				for(int i = 0; i < szb_odd; i++){
					c += (b[2*i] - y_bar)*(b[2*i] - y_bar);
				}
				var_y = c / (szb_odd- 1);
				ps.printf("%.2f", var_y);
			}
			sc.close();
			
			
		}
	}
