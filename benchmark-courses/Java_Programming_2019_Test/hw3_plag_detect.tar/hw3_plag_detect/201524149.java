import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza = 0;
		double sum = 0;
		double mean = 0;
		double varsum = 0;
		double var = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		if (a[0] % 2 == 0) {
			for (int i = 0; i < (int) sza; i++)
				if (i % 2 == 0) {
					sum += a[i];
				}
			mean = sum / (int) ((sza / 2)+1);
			//ps.printf(" %f", mean);
			for (int i = 0; i < (int) sza; i++)
				if (i % 2 == 0) {
					varsum+=(mean-a[i])*(mean-a[i]);
				}
			var=varsum/(((sza / 2)+1)-1);
			//ps.printf(" %.2f", varsum);	
			ps.printf("%.2f", var);
		}
		if (a[0] % 2 == 1) {
			for (int i = 0; i < (int) sza; i++)
				if (i % 2 == 1) {
					sum += a[i];
				}
			mean = sum / (int) ((sza / 2));
			//ps.printf(" %f", mean);
			for (int i = 0; i < (int) sza; i++)
				if (i % 2 == 1) {
					varsum+=(mean-a[i])*(mean-a[i]);
				}
			var=varsum/(((sza / 2))-1);
			//ps.printf(" %.2f", varsum);	
			ps.printf("%.2f", var);
		}
		ps.println();

		sc.close();
	}
}