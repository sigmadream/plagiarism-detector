
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] a = new int[500];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		int[] b= new int[sza];
		for(int i=0; i<sza; i++)
			b[i]=a[i];
		int c=(b[0]%2);
		int d=0, sum1=0;
		for(int i = c;i<sza;i=i+2) {
			a[d]=b[i];
			sum1+=b[i];
			d++;
		}
		double avg=(double)sum1/d;
		double sum2=0;
		for(int i=0; i<d; i++) {
			sum2+=(avg-a[i])*(avg-a[i]);
		}
		double s=sum2/(d-1);
		System.out.printf("%.2f%n", s);
		sc.close();
	}
}