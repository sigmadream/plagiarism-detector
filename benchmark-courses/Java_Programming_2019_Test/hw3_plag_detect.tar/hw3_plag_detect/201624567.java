import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza = 0;
		int y_size = 0;
		int y_sum = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		
		int[] b = new int[sza];
		
		for(int i = 0; i < sza; i++)
			b[i]=a[i];
		
		
		
		int sel = 0;
		sel = (b[0]%2); 

		for(int i = sel; i < sza; i = i+2) {
			a[y_size] = b[i];
			y_sum += b[i];
			y_size++;
		}
		double y_bar = 0;
		
		y_bar = (double)y_sum/y_size;
		double answer = 0;
		for(int i = 0; i < y_size; i ++)
			answer += (a[i]-y_bar) * (a[i]-y_bar)/(y_size-1);
		
		
		
		ps.printf("%.2f",answer);
		sc.close(); 
		}
	}