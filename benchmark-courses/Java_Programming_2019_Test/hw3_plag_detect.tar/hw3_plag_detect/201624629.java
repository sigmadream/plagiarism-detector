import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {

	public static void main(String[] args) {

		// Initialization and Declaration
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		int[] b;
		int sza = 0;
		
		// Inserting the values to an array
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		
//		for(int j=0; j != str.length; j++) {
//		    if (j % 2 == 0) { // Even
//		        number.add(str[j]); 
//		    } else { // Odd
//		        name.add(str[j]);
//		    }
//		}
//		
//		for (int i = 0; i < a.length; i++)
//		    if (i%2!=0)
//		        b[i] = a[i]
//
//		
//		b[i] = 
		
		ps.printf("%d elements are added.%n", sza);
		
		// Calculating total with print
		double total = 0;
	      for (int i = 0; i < a.length; i++)
	         total += a[i];
	    ps.printf("Total is %.2f%n", total);
	      
	    // Calculating mean with print
	    double mean = 0;
	    mean = total / sza;
	    ps.printf("Mean is %.2f%n", mean);
	    
	    // Calculating variance before devision
	    double variance_before_division = 0;
	    for (int i = 0; i < sza; i++)
	    		variance_before_division += (a[i] - mean) * (a[i]-mean);
	    
	    // Calculating variance with print
	    double variance = 0;
	    variance = variance_before_division / (sza - 1);
	    ps.printf("Variance is %.3f%n", variance);
	    
	    
	    
	    
		
//		int[] b  = new int[sza];
//		for(int i = 0; i < sza; i++)
//			b[i] = a[i];
//					
//		ps.printf("The even integers are:");
//		for (int n: b)
//			if (n % 2 == 0)
//				ps.printf(" %d", n);
//		
//		ps.println();
//		ps.printf("Array a = %s%n", Arrays.toString(a));
//		ps.printf("Array b = %s%n", Arrays.toString(b));
		sc.close();
		
	}

}
