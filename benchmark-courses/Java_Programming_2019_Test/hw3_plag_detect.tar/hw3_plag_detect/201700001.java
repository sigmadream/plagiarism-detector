import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PrintStream ps = System.out;
        int[] xs = readInts(sc);
        sc.close();
        int[] ys = sample(xs);
//        ps.printf("xs: %s%n", Arrays.toString(xs));
//        ps.printf("ys: %s%n", Arrays.toString(ys));
        double pv = sqsum(xs) / xs.length;
        double sv = sqsum(ys) / (ys.length - 1);
//        ps.printf("%.2f%n", pv);
        ps.printf("%.2f%n", sv);
//        ps.printf("%.3f%n", diff(pv, sv));
    }
    
    private static double diff(double x, double y) {
        return (x > y)? x - y: y - x;
    }

    private static double sqsum(int[] xs) {
        double sum = 0.0;
        double m = mean(xs);
        for (int x: xs)
            sum += Math.pow(x - m, 2);
        return sum;
    }

    private static double mean(int[] xs) {
        double sum = 0.0;
        for (int x: xs)
            sum += x;
        return sum / xs.length;
    }

    private static int[] sample(int[] a) {
        int sz = a.length / 2;
        int first = a[0];
        if (first % 2 == 0 && a.length % 2 == 1)
            sz++;
        int[] b = new int[sz];
        for (int i = first % 2; i < a.length; i += 2)
            b[i/2] = a[i];
        return b;    
    }

    private static int[] readInts(Scanner sc) {
        int[] a = new int[500];
        int i = 0;
        PrintStream ps = System.out;
        for (i = 0; sc.hasNextInt(); i++)
            a[i] = sc.nextInt();
        int[] b = new int[i];
        for (; --i >= 0;)
            b[i] = a[i];
//        ps.println(Arrays.toString(b));
        return b;
    }
}
