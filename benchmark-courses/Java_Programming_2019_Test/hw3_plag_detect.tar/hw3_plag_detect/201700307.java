import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
	//	ps.printf("%d elements are read.%n", sza);

		float sum = 0; 
		int szac = 0;
		
	
		if (a[0] % 2 == 0)
			szac = sza/2+1;
		else if (sza % 2 == 0)
				szac = sza/2+1;
			else szac = sza/2;

	//add one more array to fix the size
		int[] c = new int[szac];


		if (a[0] % 2 == 0) {
				for (int i = 0; i < szac; i++){
					sum = sum + a[2*i];
					c[i] = a[2*i];
				}

		}	else {
				for (int i = 0; i < szac; i++){
					sum = sum + a[2*i+1];
					c[i] = a[2*i+1];

				}
			}
		

		float ave = sum /(szac);
		sum = 0;

		for (int i = 0; i<szac; i++)  
			sum = sum + (c[i]-ave) * (c[i]-ave);


		float sv = sum/(szac-1);


		ps.printf("%.2f", sv);
		sc.close();
		ps.close();
	}
}
