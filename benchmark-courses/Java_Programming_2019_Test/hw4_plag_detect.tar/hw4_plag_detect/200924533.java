import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class HW02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza = 0;
		int sum_y = 0;
		int sum_x = 0;
		double s_square = 0;
		double a_square = 0;
		int cnt = 0;
		double mean_y = 0;
		double mean_x = 0;
		double result = 0;
		double result2 = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		
		int[] b = new int[sza];
		for(int i = 0; i < sza; i++)
			b[i] = a[i];
		// X
		for(int i = 0; i < sza; i++){
			sum_x += b[i];
		}
		
		mean_x = (double)sum_x / (double)sza;
		
		for(int i = 0; i < sza; i++){
			a_square += (b[i] - mean_x) * (b[i] - mean_x); 
		}
		
		result2 = a_square / (double)sza;
		
		// Y
		int c = b[0] % 2;
		
		for(int i = c; i < sza; i+=2){
			sum_y += b[i];
			cnt ++;
		}
		
		mean_y = (double)sum_y / (double)cnt;
		
		for(int i = c; i < sza; i+=2){
			s_square += (b[i] - mean_y) * (b[i] - mean_y);
		}
				
		result = s_square / (double)(cnt - 1);
		
		ps.printf("%.3f\n", Math.abs(result-result2));
		
		sc.close();
	}
}
