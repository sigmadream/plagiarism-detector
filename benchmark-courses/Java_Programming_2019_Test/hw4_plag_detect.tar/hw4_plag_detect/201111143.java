import java.io.PrintStream;
import java.util.Scanner;

public class vard1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int[] X = new int[500];
		int[] b = new int[500];
		int szx=0,szb=0;
		for(int i=0;sc.hasNextInt();szx++,i++)
			X[i]=sc.nextInt();
		if(X[0]%2==0) {
			for(int i=0;2*i<szx;szb++,i++)
				b[i]=X[2*i];
		}
		if(X[0]%2==1) {
			for(int i=0;2*i+1<szx;szb++,i++)
				b[i]=X[2*i+1];
		}
		double sum1=0,_y;
		double sum2=0,_x;
		for(int i=0;i<szb;i++)
			sum1 +=b[i];
		for(int i=0;i<szx;i++)
			sum2 +=X[i];
		_y=sum1/szb;
		_x=sum2/szx;
		double s5,s4=0,s3=0,s2=0,s=0;
		for(int i=0;i<szb;i++)
			s2+=(b[i]-_y)*(b[i]-_y);
		for(int i=0;i<szx;i++)
			s3+=(X[i]-_x)*(X[i]-_x);
		s=s2/(szb-1);
		s4=s3/szx;
		if(s4>s)
			s5=s4-s;
		else
			s5=s-s4;
		
		ps.printf("%.3f",s5);
		sc.close();
	}
}
