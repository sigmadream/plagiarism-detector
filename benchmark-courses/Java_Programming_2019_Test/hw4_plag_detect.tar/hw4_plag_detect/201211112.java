import java.io.PrintStream;
import java.util.Scanner;

public class VarDiff {

	public static void main(String[] args) {
		PrintStream ps = System.out;
		int[] x = new int[500], y = new int[251];
		int szx = init_x(x), szy = init_y(x, y, szx);
		double answer = vardiff(x,y,szx,szy);
		ps.printf("%.3f", abs(answer));
	}
	
	public static int init_x(int[] x) {
		Scanner sc = new Scanner(System.in);
		int sz=0;
		for(; sc.hasNextInt(); sz++)
			x[sz] = sc.nextInt();
		sc.close();
		return sz;
	}
	
	public static int init_y(int[] src, int[] dst, int sz_src) {
		int sz_dst=0;
		if(src[0]%2==0) {
			for(int i=0; i<sz_src; sz_dst++, i+=2)
				dst[sz_dst] = src[i];
		}
		else {
			for(int i=1; i<sz_src; sz_dst++, i+=2)
				dst[sz_dst] = src[i];
		}
		return sz_dst;
	}
	
	public static double mean(int[] a, int sz) {
		double m=0;
		for(int i=0;i<sz;i++)
			m+=a[i];
		return m/sz;
	}
	
	public static double vardiff(int[] x, int[] y, int szx, int szy) {
		double var_x=0, var_y=0;
		double mean_x=mean(x,szx), mean_y=mean(y,szy);
		
		for(int i=0;i<szx;i++)
			var_x+=(x[i]-mean_x)*(x[i]-mean_x);
		var_x/=szx;
		
		for(int i=0;i<szy;i++)
			var_y+=(y[i]-mean_y)*(y[i]-mean_y);
		var_y/=szy-1;
		
		return var_x-var_y;
	}
	
	public static double abs(double d) {
		return d>0 ? d : -d;
	}
}
