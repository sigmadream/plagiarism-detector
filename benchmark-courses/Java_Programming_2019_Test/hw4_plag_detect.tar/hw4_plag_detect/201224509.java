import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class HW02 {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		int sizea = 0;
		for(int i=0; sc.hasNextInt(); sizea++, i++)
			a[i] = sc.nextInt();
		
		double[] insert = new double[sizea];
		for(int j=0; j<sizea; j++)
			insert[j] = a[j];
		
		// Make sample Y
		int sizesample = sizea/2;
		if(insert[0] % 2 == 0 && sizea % 2 != 0)
			sizesample++;
		double[] sample = new double[sizesample];
		for(int i=0; i<sizesample; i++) {
			if(insert[0] % 2 != 0){
				if(2*i < sizea)
					sample[i] = insert[2*i+1];
			}
			else 
				if(2*i < sizea)
					sample[i] = insert[2*i];
		}
		
		
		// Calculation X --> 'a'
		double popul = 0;
		double[] sigma1 = new double[sizea];
		for(int j=0; j<sizea; j++) {
			sigma1[j] = insert[j] / sizea;
			popul += sigma1[j];
		}   
		double total = 0;
		double[] sigma2 = new double[sizea];
		for(int k=0; k<sizea; k++) {
			sigma2[k] =  (insert[k] - popul) * (insert[k] - popul);	
			total += sigma2[k];
		}
		double result = total / sizea;
		
		// Calculation sample Y --> 'b'
		double samplepopul = 0;
		double[] samplesigma1 = new double[sizesample];
		for(int j=0; j<sizesample; j++) {
			samplesigma1[j] = sample[j] / sizesample;
			samplepopul += samplesigma1[j];
		}
		double sampletotal = 0;
		double[] samplesigma2 = new double[sizesample];
		for(int k=0; k<sizesample; k++) {
			samplesigma2[k] =  (sample[k] - samplepopul) * (sample[k] - samplepopul);	
			sampletotal += samplesigma2[k];
		}
		double sampleresult = sampletotal / (sizesample - 1);
		
		double output = (double)(Math.abs(result - sampleresult));
		
		ps.printf("%.3f\n",output);
		
		sc.close();
		ps.close();
		
	}
	
}