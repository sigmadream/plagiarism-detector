import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class VarDiff {
	static int[] readInts() {
		int[] a = new int[500], b = null;
		try {
			Scanner sc = new Scanner(System.in);

			int n = 0, i = 0;
			while (sc.hasNextInt()) {
				n = sc.nextInt();
				a[i++] = n;
			}
			sc.close();

			b = new int[i];
			for (int j = 0; j < i; ++j)
				b[j] = a[j];
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	}

	static int number_is_odd(int[] a) {
		if (a[0] % 2 == 0){
			return 0;
		} else {
			return 1;
		}
	}

	static double variance(int[] a) {
		int odd_or_even = number_is_odd(a);
		double subset_sum = 0;
		double subset_size = 0;
		double y_bar = 0;
		double sum_of_uppercase = 0;
		double s_square = 0;
		int [] b = new int [500];
		int [] c = null;

		if (odd_or_even == 1){
			int i = 0;
			int j = 0;
			for(int n :a){
				if(i % 2 != 0){
					subset_sum += n;
					subset_size++;
					b[j++] = n;
				}
				i++;
			}
		} else if (odd_or_even == 0){
			int i = 0;
			int j = 0;
			for(int n :a){
				if(i % 2 == 0){
					subset_sum += n;
					subset_size++;
					b[j++] = n;
				}
				i++;
			}
		}

		int k = (int)subset_size;
		c = new int[k];
		for (int j = 0; j < k; ++j)
			c[j] = b[j];

		y_bar = subset_sum / subset_size;

		for (int n : c){
			sum_of_uppercase += (n - y_bar) * (n - y_bar);
		}
		s_square = sum_of_uppercase / (subset_size-1);

		return s_square;
	}

	static double population_variance(int[] a) {
		double sum = 0;
		double size = 0;
		double y_bar = 0;
		double sum_of_uppercase = 0;
		double s_square = 0;

		for (int n : a){
			sum += n;
			size++;
		}
		
		y_bar = sum / size;

		for (int n : a){
			sum_of_uppercase += (n - y_bar) * (n - y_bar);
		}
		s_square = sum_of_uppercase / size;

		return s_square;
	}

	public static void main(String[] args){
		
		PrintStream ps = System.out;

		int[] a = readInts();
		double result = variance(a) - population_variance(a);
		
		if (result < 0)
			result = result * (-1);
		
		ps.printf("%.3f%n", result);

		ps.close();
	}
}
