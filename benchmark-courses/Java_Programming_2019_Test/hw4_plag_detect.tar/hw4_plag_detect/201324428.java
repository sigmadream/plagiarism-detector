import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class DiffofVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int[] a = new int[500];

		float average = 0;
		float even_average = 0;
		float oddsquare_variance = 0;
		float evensquare_variance = 0;
		float diff = 0;

		int allarrsize = 0, count = 0, index = 0;

		for (int i = 0; sc.hasNextInt(); allarrsize++, i++){
			a[i] = sc.nextInt();
			even_average += a[i];
			
			if(a[0] % 2 == 0) index = 0;
			else index = 1;
			
			if(i % 2 == index){
				average += a[i];
				count++;
			}	
		}

		average = average / count;
		even_average = even_average / allarrsize;

		for(int i = 0; i < allarrsize; i++){
			evensquare_variance += (a[i] - even_average) * (a[i] - even_average);
			if(i % 2 == index) 
				oddsquare_variance += (a[i] - average) * (a[i] - average);
		}

		evensquare_variance = evensquare_variance / allarrsize;
		oddsquare_variance = oddsquare_variance / (count - 1);

		diff = evensquare_variance - oddsquare_variance;

		if(diff > 0) ;
		else diff = 0 - diff;

		ps.printf("%.3f%n", diff);

		sc.close();
	}
}
