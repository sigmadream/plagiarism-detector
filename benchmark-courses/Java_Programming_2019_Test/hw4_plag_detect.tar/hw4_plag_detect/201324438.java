import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class VarDiff {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int[] a = new int[500];
		int[] b = new int[251];
		
		float average = 0;
		float average_X = 0;
		float Y_variance = 0;
		float X_variance = 0;
		float diff = 0;
		
		int sza = 0, count = 0, index;
		
		for (int i = 0; sc.hasNextInt(); sza++, i++){
			a[i] = sc.nextInt();
			average_X += a[i];
		}
		
		average_X = average_X / sza;
		
		for(int i = 0; i < sza; i++)
			X_variance += (a[i] - average_X) * (a[i] - average_X);
		X_variance = X_variance / sza;
		
		if(a[0] % 2 == 0) index = 0;
		else index = 1;
	
		for(int i = index; i < sza; i = i + 2){
			average += a[i];
			count++;
		}
		
		average = average / count;

		for(int i = index; i < sza; i = i + 2)
			Y_variance += (a[i] - average) * (a[i] - average);
		Y_variance = Y_variance / (count - 1);
		
		diff = X_variance - Y_variance;
		
		if(diff > 0) ;
		else diff = 0 - diff;

		ps.printf("%.3f%n", diff);
		
		sc.close();
	}
}