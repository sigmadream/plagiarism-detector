import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class VarDiff {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int[] a = new int[10];
		int a_len = 0;
		double sum_y = 0.0;
		for (int i = 0; sc.hasNextInt(); ++a_len, ++i)
			a[i] = sc.nextInt();
		
		double y_bar = 0.0;
		double subset_y_sum = 0.0;
		int subset_y_length=0;
		
		if ( a[0]%2==0 ) {
			for(int k=0; k<a_len; ++k) 
				if( k%2==0 ) {					
					sum_y += a[k];
					subset_y_length++;
				}
		
			y_bar = sum_y/subset_y_length;
			
			for(int j=0; j<a_len; ++j)
				if( j%2==0 ) 
					subset_y_sum += (a[j]-y_bar)*(a[j]-y_bar);
		}
		
		else {
			for(int k=0; k<a_len; ++k) 
				if( k%2!=0 ) {					
					sum_y += a[k];
					subset_y_length++;
				}
			
			y_bar = sum_y/subset_y_length;

			for(int j=0; j<a_len; ++j)
				if( j%2!=0 ) 
					subset_y_sum += (a[j]-y_bar)*(a[j]-y_bar);
		}
		
		double sum_s1 = subset_y_sum/(subset_y_length-1);
		ps.printf("s_sum is %.3f%n", sum_s1);
		
		
		
		
		double sum_x=0.0;
		double x_bar = 0.0;
		double subset_x_sum = 0.0;
		int subset_x_length=0;
		
		if ( a[0]%2==0 ) {
			for(int k=0; k<a_len; ++k) 
				if( k%2==0 ) {					
					sum_x += a[k];
					subset_x_length++;
				}
		
			x_bar = sum_x/subset_x_length;
			
			for(int j=0; j<a_len; ++j)
				if( j%2==0 ) 
					subset_x_sum += (a[j]-x_bar)*(a[j]-x_bar);
		}
		
		else {
			for(int k=0; k<a_len; ++k) 
				if( k%2!=0 ) {					
					sum_x += a[k];
					subset_x_length++;
				}
			
			x_bar = sum_x/subset_x_length;

			for(int j=0; j<a_len; ++j)
				if( j%2!=0 ) 
					subset_x_sum += (a[j]-x_bar)*(a[j]-x_bar);
		}
		
		double sum_s2 = subset_x_sum/(subset_x_length);
		

		if (sum_s1>sum_s2)
			System.out.printf("%.3f%n",sum_s1-sum_s2);
		else
			System.out.printf("%.3f",sum_s2-sum_s1);
		
		sc.close();
	}
}