import java.io.PrintStream;
import java.util.Scanner;

public class VarDiff {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int a[] = new int[10];
		int sza = 0, sum=0; 

		for (int i=0;sc.hasNextInt();sza++,i++)
			a[i]=sc.nextInt();


		for (int i=0;i<a.length;i++)
			sum += a[i]; 	

		ps.printf("%.3f",Math.abs(Svar(a, sza)-Var(sum, a, sza)));
	}

	private static double Svar(int[] a, int sza) {

		double[] b = new double[sza]; 
		for(int i=0;i<sza;i++)
			b[i]=a[i];

		double[] c = new double[sza]; 
		for(int i=0;i<sza;i++)
			c[i]=b[i];

		double avg=0;
		int sza1 =0;
		double v=0;
		double sum2=0;

		if (c[0] % 2 ==0){ // if first index is even
			for(int i=0; i<c.length; i++){
				c[0] += c[i];
				i++;
				sza1++;
			}
			avg = (double) c[0] / sza1;

			for(int i=0; i<b.length; i++){
				b[0] += Math.pow(b[i]-avg, 2);
				i++;
			}
			v = b[0] / (sza1-1);
			return v;
		}

		else // if first index is odd
		{
			for(int i=1; i<7; i++){
				c[1] += c[i+2];
				i++;
				sza1++;
			}
			sza1++;
			avg = (double) c[1] / sza1;

			for(int i=1; i<b.length; i++){
				sum2 += Math.pow(b[i]-avg, 2);
				i++;
			}
			v = sum2 / (sza1-1);
			return v;

		}
	}

	private static double Var(int sum, int[] a, int sza) {


		int[] b = new int[sza]; 
		for(int i=0;i<sza;i++)
			b[i]=a[i];

		double avg = (double) sum / b.length;


		double sum2=0;
		double v = 0;
		for(int i=0; i<b.length; i++)
		{

			sum2 += Math.pow(b[i]-avg, 2);
		}
		v = sum2 / b.length;
		return v;
	}

}
