import java.io.PrintStream;
import java.util.Scanner;

public class hw2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sza = 0, szb = 0;
		int[] a = new int[10000], b = new int[10000];
		for(int i = 0 ; sc.hasNextInt() ; ++i, ++sza) {
			a[i] = sc.nextInt();
			if(a[0]%2 == i%2)		b[szb++] = a[i];
		}
		double sv = sol(a,sza) / (sza), pv = sol(b,szb) / (szb-1);
		System.out.printf("%.3f",(sv-pv > 0 ? sv-pv : pv-sv));
		sc.close();
	}
	
	 private static double sol(int[] arr, int sz) {
		double avg = 0, ret = 0;
		for(int i = 0; i < sz ; ++i)
			avg += arr[i];
		avg /= sz;
		for(int i = 0; i < sz ; ++i)
			ret += (arr[i]-avg)*(arr[i]-avg);
		return ret;
	}

}
