
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class VarDiff {
	public static double findSVar(int[] b) {
		int count = 0;
		int sum = 0;
		double avg = 0.0;
		double resultSvar = 0.0;
		if (b[0] % 2 == 0) {
			for (int i = 0; i < b.length; i += 2) {
				sum += b[i];
				count++;
			}
			avg = (double)sum/count;
			for (int i = 0; i < b.length; i += 2) {
				resultSvar += (b[i] - avg) * (b[i] - avg);
			}
			resultSvar = resultSvar / (count - 1);
			
			
		}else{
			for (int i = 1; i < b.length; i += 2) {
				sum += b[i];
				count++;
			}
			avg = (double)sum/count;
			for (int i = 1; i < b.length; i += 2) {
				resultSvar += (b[i] - avg) * (b[i] - avg);
			}
			resultSvar = resultSvar / (count - 1);
			
		}
		return resultSvar;
	}

	public static double findPVar(int[] b){
		int sum = 0;
		double avg = 0.0;
		double resultPvar = 0.0;
		for(int i = 0 ; i < b.length; i++){
			sum += b[i];
		}
		avg = (double) sum/b.length;
		for (int i = 0; i < b.length; i++) {
			resultPvar += (b[i] - avg) * (b[i] - avg);
		}
		resultPvar = resultPvar / b.length;
		return resultPvar;
	}
	
	public static void printVar(double resultSvar,double resultPvar){
//		System.out.printf("%.3f ", resultSvar);
//		System.out.printf("%.3f ", resultPvar);
		if(resultSvar>resultPvar){
			System.out.printf("%.3f", resultSvar-resultPvar);
		}else{
			System.out.printf("%.3f", resultPvar-resultSvar);
		}
	}
	public static int[] readArr() {
		int[]a = new int[500];
		int sza = 0;
		Scanner sc = new Scanner(System.in);
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		int[] b = new int[sza];
		for (int i = 0; i < sza; i++)
			b[i] = a[i];
		sc.close();
		return b;
		
	}

	public static void main(String[] args) throws FileNotFoundException {
		PrintStream ps = System.out;
		int[] b = readArr();
		double resultSvar = 0.0;
		double resultPvar = 0.0;
		resultSvar = findSVar(b);
		resultPvar = findPVar(b);
		printVar(resultSvar, resultPvar);
		
	}

}