import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		int sza = 0;
		double sum1=0;
		double sum2=0;
		for (int i = 0; sc.hasNextInt(); sza++, i++) {
			a[i] = sc.nextInt();
			sum2 +=a[i];
		}
		int[] b = new int[sza];
		int szb = 0;
		if(a[0]%2==0) {
			for(int i = 0; i < sza; i++)
				if(i%2==0) {
					sum1+=a[i];
					b[i/2]=a[i];
					szb +=1;
				}
		}
		if(a[0]%2!=0) {
			for(int i=1; i < sza; i++)
				if(i%2!=0) {
					sum1+=a[i];
					b[(i+1)/2-1]=a[i];
					szb +=1;
				}
		}
		double s3=0;
		double ave1 = (sum2/sza);
		for(int i = 0; i < sza; i++) {
			s3+=((ave1-a[i])*(ave1-a[i]));
			
		}
		
		 double ave=(sum1/szb);
		 double s = 0, s1= 0,s2 = 0, s4 = 0, s5 = 0;
		 s4= s3/(sza);
		 for(int i=0; i < szb; i++)
			 s+=((b[i]-ave)*(b[i]-ave));
		 s2 = s/(szb-1);
		 if(s2<s4) {
			 s5= s4 - s2;
		 }
		 else {
			 s5= s2 - s4;
		 }
		 ps.printf("%.3f%n", s5);
		sc.close();
	}
}