import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class Lab2_SVar {
	private static Scanner sc;

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] temp = new int[500];
		
		int sza = 0;
		
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			temp[i] = sc.nextInt();
		
		int[] X= new int[sza];
		
		X = Arrays.copyOfRange(temp, 0, sza);
	
		boolean isFirstElementEven = X[0] % 2 == 0;
		int[] B = new int[sza];
		int bLength = 0;
		for (int i = 0; i < sza; i++) {
			if (isFirstElementEven) {
				if (i % 2 == 0) {
					B[bLength++] = X[i];
				} else
					continue;
			} else {
				if (i % 2 == 1) {
					B[bLength++] = X[i];
				} else 
					continue;
			}
		}
		
		int[] b = new int[bLength];
		b = Arrays.copyOfRange(B, 0, bLength); 
		
		int sum_X =0;
		int sum_b =0;
		double aver_X=0;
		double aver_b=0;
		for (int i=0; i<X.length; i++) {
			sum_X += X[i];
		}
		for (int i=0; i<b.length; i++) {
			sum_b += b[i];
		}
		aver_b=(double)sum_b / b.length;
		aver_X=(double)sum_X / X.length;
		
		double Son_b=0;
		double Son_X=0;
		double s_b=0;
		double s_X=0;
		
		for (int i=0; i<X.length; i++) {
			Son_X += (X[i]-aver_X)*(X[i]-aver_X);
		}		
		s_X=Son_X/(X.length);
		for (int i=0; i<b.length; i++) {
			Son_b += (b[i]-aver_b)*(b[i]-aver_b);
		}		
		s_b=Son_b/(b.length-1);
		double result=0;
		if(s_b>s_X) {
			result=s_b-s_X;
		}
		else {
			result=s_X-s_b;
		}
		ps.printf("%.3f%n", result);
		
	}
}