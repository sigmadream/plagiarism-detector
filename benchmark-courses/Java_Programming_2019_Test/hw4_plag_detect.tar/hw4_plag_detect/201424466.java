import java.io.PrintStream;
import java.util.Scanner;

public class hw2 {
 public static void main(String[] args) {
  Scanner sc = new Scanner(System.in);
  PrintStream ps = System.out;

  int asize=0,sumodd=0,sumeven=0,ceven=0,codd=0;
  int[] a = new int[500];
  for(int i = 0;sc.hasNextInt();i++) {
   asize++;
   a[i] = sc.nextInt();
  }
  if(a[0]%2 == 0) {
   for(int i =0;i<asize;i++) 
    if(i%2 == 0)
    {
     sumeven += a[i];
     ceven++;
    }
  }
  else {
   for(int j = 0;j<asize;j++)
    if(j%2 == 1) {
     sumodd += a[j];
     codd++;
    }
  }
  double avgodd = (double)sumodd/codd;
  double avgeven = (double)sumeven/ceven;
  //ps.printf("%.2f % .2f%n",avgeven,avgodd);
  double[] seven = new double[ceven];
  double[] sodd = new double[codd];
  double sumsteven=0,sumstodd=0;
  
  for(int k =0;k<codd;k++)
  {
   sodd[k] = sodd[k] + (avgodd-(double)a[k*2+1])*(avgodd-(double)a[k*2+1]);
   sumstodd += sodd[k];
  
  }
  for(int j =0;j<ceven;j++)
  {
   seven[j] =seven[j]+ (avgeven-(double)a[j*2])*(avgeven-(double)a[j*2]);
   sumsteven += seven[j];
  }
  
  
  int bsize=0,sum=0,count=0;
  
  int[] b = new int[500];
  for(int i = 0;i<asize;i++) {
   bsize++;
   b[i] = a[i];
   sum += b[i];
  }
  
  
  double average = (double)sum/bsize;
  double[] seven2 = new double[bsize];
  double[] sodd2 = new double[bsize];
  double sumst=0;
  
  for(int k =0;k<bsize;k++)
  {
   sodd2[k] = sodd2[k] + (average-(double)b[k])*(average-(double)b[k]);
   sumst += sodd2[k];
  
  }
 
  if(b[0]%2 == 0)
  {
   double resulteven = (sumsteven/(double)(ceven-1))-(sumst/(double)(bsize));
   
   if(resulteven >= 0) {
   ps.printf("%.3f%n",resulteven);
   }
   else {
    ps.printf("%.3f%n",-resulteven);
   }
  }
  else
  {
   double resultodd = (sumstodd/(double)(codd-1))-(sumst/(double)(bsize));
   if(resultodd >= 0) {
   ps.printf("%.3f%n", resultodd);
   
   }
   else {
    ps.printf("%.3f%n", -resultodd);}
  }
 }
}
