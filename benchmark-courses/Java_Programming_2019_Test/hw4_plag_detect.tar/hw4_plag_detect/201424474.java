import java.io.PrintStream;
import java.util.Scanner;

public class DOV {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int[] idx = new int[500];
		int szx = 0;
		
		do {
			szx = 0;
			for (int i = 0; sc.hasNextInt(); szx++, i++)
				idx[i] = sc.nextInt();
		} while (szx < 5);
		
		int[] x = new int[szx];
		
		for (int i = 0; i < szx; i++)
			x[i] = idx[i];
		
		int[] y = new int[szx/2+1];
		
		int szy = 0;
		
		if (x[0] % 2 == 1)
		{
			for(int i = 0; 2*i+1 < szx; szy++, i++)
				y[i] = x[2*i+1];
		}
			
		else
		{
			for(int i = 0; 2*i < szx; szy++, i++)
				y[i] = x[2*i];
		}
		///////////////////////////////////////////////////////////
		double noty = 0.0;
		
		for(int i = 0; i < szy; i++)
			noty += (double)y[i];
		
		noty /= (double)szy;
		
		double ssquare = 0.0;
		
		for(int i = 0; i < szy; i++)
			ssquare += (double)((y[i]-noty)*(y[i]-noty));
		
		ssquare /= (double)(szy-1);
		///////////////////////////////////////////////////////////
		double notx = 0.0;
		
		for(int i = 0; i < szx; i++)
			notx += (double)x[i];
		
		notx /= (double)szx;
		
		double pisquare = 0.0;
		
		for(int i = 0; i < szx; i++)
			pisquare += (double)((x[i]-notx)*(x[i]-notx));
		
		pisquare /= (double)szx;
		///////////////////////////////////////////////////////////
		double differ = 0.0;
		
		differ = ssquare - pisquare;
		
		if (differ < 0)
			differ *= (-1);
		
		ps.printf("%.3f%n", differ);
		
		sc.close();
	}
}