import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;
 
public class dffff {
  public static void main(String[] args) {
   Scanner sc = new Scanner(System.in);
   PrintStream ps = System.out;
   int[] a = new int[500];
   int sum =0;
   int ssum =0;
   int sza = 0;
   double v = 0;
   double vv = 0;
   double s = 0;
   double ss = 0;
   double ave = 0;
   double aave =0;
   int r=0;

   double answer = 0;
   for (int i = 0; sc.hasNextInt(); i++) {
   a[i] = sc.nextInt();
    sza++;
   }
  
   int []b = new int[sza];
   if (a[0] % 2 ==0)
   for(int i=0; i<sza; i=i+2)
    b[i] = a[i];
   else
    for(int i=1; i<sza; i=i+2)
     b[i] = a[i];
   
   
   for(int k=0; k<sza; k++) {
    ssum += a[k];
   }
   
   aave = ssum/(sza*1.0);
  
   for(int i=0; i<sza; i++) {
   vv = vv + (a[i]-aave)*(a[i]-aave);
}
   v = vv/(sza)*(1.0);
    
  
   for(int j=0; j<sza; j++)
    sum += b[j];
   
   
   if ( a[0] % 2 == 0)
	   for(int i=0; i<sza; i=i+2)
		   r++;
   else
	   for(int i=1; i<sza; i=i+2)
		   r++;
   
   
   ave = sum/(r*(1.0));
   
   if (a[0] % 2 ==0){
   for(int j=0; j<sza; j = j+2){
    ss = ss + (b[j]-ave)*(b[j]-ave);
   }
   }
   else 
    for(int j=1; j<sza; j = j+2){
    ss = ss + (b[j]-ave)*(b[j]-ave);
    }
   
   s = ss/(r-1);
   answer = v-s;
   
   if (answer > 0)
    ps.printf("%.3f", answer);
   else
    ps.printf("%.3f", (-1)*answer);
   sc.close();
   }
  } 