import java.io.PrintStream;
import java.util.Scanner;

public class VarDiff {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza = 0;
		double c = 0;
		double d = 0;
		double avg = 0;
		double s = 0;
		double s2 = 0;
		double x2 = 0;
		double e = 0;
		double f = 0;
		double avg2 = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();

		for(int i = 0; i < sza; i++) {
			e += a[i];
			f++;
		}
		avg2 = e/f;
		for(int i = 0; i < sza; i++)
			x2 += (a[i]- avg2)*(a[i]- avg2)/f;
		
		if (a[0] % 2 == 0) {
			for(int i=0; i < sza; i+=2) {
				c += a[i];
				d++;
			}
			avg = c/d;
			for(int i=0; i < sza; i+=2) {
				s += (a[i]- avg)*(a[i]- avg);
			}
			s2 = s/(d-1);
		}
		else{
			for(int i=1; i < sza; i+=2) {
				c += a[i];
				d++;
			}
			avg = c /d;
			for(int i=1; i < sza; i+=2) {
				s += (a[i]- avg)*(a[i]- avg);
			}
			s2 = s/(d-1);
		}
			ps.printf("%.3f",Math.abs(x2-s2));
		sc.close();
	}
}