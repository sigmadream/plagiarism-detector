import java.util.Scanner;

public class Svar {
	
	static int[] MakeSample(int[] b,int size) {
		Scanner sc = new Scanner(System.in);
		int []Array = new int[size];
		for(int i=0;i<size;i++)
			Array[i]=b[i];
		sc.close();
		return Array;
	}
	
	static double population(int[] b,int size) {
		double Sum = 0;
		for(int i = 0;i<size;i++) {
			Sum+=b[i];
		}
		double mean2 = Sum/size;
		double o = 0;
		for(int i = 0;i<size;i++)
			o += (mean2-b[i])*(mean2-b[i]);
		double popularvar = o/size;
		return popularvar;
	}
	
	static double VarDifference(int[] b,int size) {
		double results = 0;
		if(b[0]%2==0) {
			double Sumofeven = 0;
			int newsize=0;
			for(int i = 0;i<size;i=i+2,newsize++)
				Sumofeven = Sumofeven+b[i];
			
			double mean = Sumofeven/newsize;
			
			double s = 0;
			for(int i = 0;i<size;i=i+2)
				s += (mean-b[i])*(mean-b[i]);
			
			double samplevar = s/(newsize-1);
			results = samplevar;
			double popularvar = population(b,size);
			if(popularvar-samplevar>=0)
				results = (popularvar-samplevar);
			else
				results = (samplevar - popularvar);			
		}
		else {
			double Sumofodd = 0;
			int newsize=0;
			for(int i = 1;i<size;i=i+2,newsize++)
				Sumofodd = Sumofodd+b[i];
			
			double mean = Sumofodd/newsize;
			
			double s = 0;
			for(int i = 1;i<size;i=i+2)
				s += (mean-b[i])*(mean-b[i]);
			
			double samplevar = s/(newsize-1);
			results = samplevar;
			double popularvar = population(b,size);
			if(popularvar-samplevar>=0)
				results = (popularvar-samplevar);
			else
				results = (samplevar - popularvar);
			
		}
		return results;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int []x = new int[500];
		int size = 0;
		for(int i = 0;sc.hasNextInt();i++,size++)
			x[i] = sc.nextInt();
		int []Sample = MakeSample(x,size);
		System.out.printf("%.3f",VarDifference(Sample,size));
		sc.close();
	}
}
