import java.io.PrintStream;
import java.util.Scanner;

public class HW02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		double sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		int sum = 0;
		double avg = 0;
		double s = 0;
		double r = 0;
		int sum2 = 0;
		double avg2 = 0;
		double o = 0;
		
		if (a[0] % 2 == 0){
			for ( int k = 0; k < sza ; k+=2){
				sum += a[k];
				r++;
			}
			avg = sum / r;
			for ( int k = 0; k < sza ; k+=2){
				s += (a[k]-avg)*(a[k]-avg)/(r-1);
			}
		}
		else {
			for ( int k = 1; k < sza ; k+=2){
				sum += a[k];
				r++;
			}
			avg = sum / r;
			for ( int k = 1; k < sza ; k+=2){
				s += (a[k]-avg)*(a[k]-avg)/(r-1);
			}
		}
		for (int j=0; j < sza ; j++){
			sum2 += a[j];
		}
		avg2 = sum2 / sza;		
		for (int j=0; j < sza ; j++){
			o += (a[j]-avg2)*(a[j]-avg2)/sza;
		}
		if(s-o > 0){
			ps.printf("%.3f%n",s-o);
		}
		else{
			ps.printf("%.3f%n",o-s);
		}
		sc.close();
	}
}
