import java.util.Scanner;

public class Vardiff {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] a = new int[50],b=null;
		int sza = 0,sum0= 0,sum1= 0,su =0;
		double MVar =0,sum = 0,YVar = 0,SVar=0,PVar = 0;
		sza = Xinput(a, sza,sc);
		SVar = compute_SVar( a, b, sza, sum1, su,SVar, YVar);
		PVar = compute_PVar(a, MVar,  sum0,  sum,  sza);
		diff(PVar, SVar);
		sc.close();
	}
	public static int Xinput(int[] X, int size,Scanner sc)
	{
		for (int i = 0; sc.hasNextInt(); size++, i++)
			X[i] = sc.nextInt();
		return size;
	}
	public static double compute_SVar(int[] a,int[] b,int sza,int sum1, int su,double SVar, double YVar)

	{
		if(a[0] % 2 == 0)
		{
			b= new int[(sza+1)/2];
			for(int j =0; j< (sza+1)/2 ; su++,j++)
			{
				b[j] = a[2*j];
				sum1 += b[j];
			}
		}
		if(a[0] % 2== 1)
		{
			b= new int[sza/2];
			for(int k = 0; k < sza/2;su++,k++)
			{
				b[k] = a[2*k+1];
				sum1 += b[k];
			}
		}
		YVar = sum1 / (double)su;
		double sum2 = 0;
		for(int s =0; s < su ; s ++)
		{
			sum2 +=(b[s] - YVar) *(b[s]- YVar);
		}
		SVar = sum2 / (su-1);
		return SVar;
		
	}
	public static void diff(double PVar, double SVar)
	{
		double diff = 0;
		if(PVar >= SVar)
		{
			diff = PVar - SVar;
		}
		else if(PVar < SVar)
		{
			diff = SVar -PVar;
		}
		System.out.printf("%.3f\n", diff);
	}
	public static double compute_PVar(int[] a,double MVar,int sum0,double sum,int sza)
	{
		for (int n = 0; n < sza ; n++)
		{
			sum0 += a[n];
		}
		MVar = sum0 / (double)sza;
		
		for(int m = 0; m < sza ; m++)
		{
			sum += (a[m] - MVar)*(a[m] - MVar);  
		}
		
		double PVar = sum / (double)sza;	
		return PVar;
	}
}