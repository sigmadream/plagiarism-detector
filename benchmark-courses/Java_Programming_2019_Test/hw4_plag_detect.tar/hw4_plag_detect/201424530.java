import java.util.Scanner;

public class VarDiff {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int [] a = new int[100];
		int sza = 0;
		int suma = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++) {
			a[i] = sc.nextInt();
			suma += a[i];
		}

		double avga = (double)suma/sza;
		double squarea = 0;
		for (int i = 0; i < sza ; i++) {
			squarea += (avga-a[i])*(avga-a[i]);
		}
		double u = squarea/sza;

		int[] b = new int[sza];
		for (int i = 0; i < sza; i++)
			b[i] = a[i];


		int fv=(b[0]%2);
		int d=0, picksum = 0;
		for(int i = fv; i < sza; i = i+2) {
			a[d] = b[i];
			picksum+=b[i];
			d++;
		}
		double avgb = (double)picksum/d;
		double squareb = 0;
		for (int i = 0; i < d; i++) {
			squareb +=(avgb-a[i])*(avgb-a[i]);
		}
		double s = squareb/(d-1);

		if(s>u) {
			System.out.printf("%.3f%n", s-u);
			sc.close();
		}
		else if (u>s) {
			System.out.printf("%.3f%n",u-s);
			sc.close();
		}
	}

}

