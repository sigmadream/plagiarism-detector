import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

	public class SVar {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			int[] a = new int[500];
			int sza = 0;
			for (int i = 0; sc.hasNextInt(); sza++, i++)
				a[i] = sc.nextInt();
			int[] b = new int[sza];
			for (int i = 0; i < sza; i++)
				b[i] = a[i];
			System.out.printf("%.3f\n", Math.abs(SampleVariance(b)-PopulationVariance(b)));
		}
		public static double SampleVariance(int[] b){
			int szb = 0;
			double sum_b = 0;
			double x = 0;
			double var_b = 0;
			if (b[0] % 2 == 0){
				for (int i = 0; i < b.length; i = i + 2){
					szb = szb + 1;
					sum_b = sum_b + b[i];
				}
				for (int i = 0; i < b.length; i = i + 2){
					x += (b[i]-(sum_b/szb))*(b[i]-(sum_b/szb));
					
				}
				var_b = x/(szb-1);
			}
			if (b[0] % 2 == 1){
				for (int i = 1; i < b.length; i = i + 2){
					szb = szb + 1;
					sum_b = sum_b + b[i];
				}
				for (int i = 1; i < b.length; i = i + 2){
					x += (b[i]-(sum_b/szb))*(b[i]-(sum_b/szb));
					
				}
				var_b = x/(szb - 1);
			}
			return var_b;
		}
		
		
		public static double PopulationVariance(int[] b){
			int szb = 0;
			double sum_b = 0;
			double x = 0;
			double var_b = 0;
			
				for (int i = 0; i < b.length; i = i + 1){
					szb = szb + 1;
					sum_b = sum_b + b[i];
				}
				for (int i = 0; i < b.length; i = i + 1){
					x += (b[i]-(sum_b/szb))*(b[i]-(sum_b/szb));
					
				}
				var_b = x/szb;
			return var_b;
			
		}
		
		
		
	}
