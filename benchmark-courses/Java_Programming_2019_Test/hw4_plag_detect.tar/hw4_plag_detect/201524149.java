import java.io.PrintStream;
import java.util.Scanner;

public class VarDiff {

	public static void main(String[] args) {
		varDiff1();
	}

	static void varDiff1() {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int[] a = new int[500];
		int sza = 0;
		int samplesza=0;
		double sum = 0;
		double popsum = 0;
		double mean = 0;
		double popmean = 0;
		double varsum = 0;
		double popvarsum = 0;
		double var = 0;
		double popvar = 0;

		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();

		if (a[0] % 2 == 0) {
			for (int i = 0; i < (int) sza; i++) {
				popsum += a[i];
				if (i % 2 == 0) {
					sum += a[i];
					samplesza++;
				}
			}
			popmean = popsum / (int) sza;
			mean = sum / (int) samplesza;
			// ps.printf(" %f", mean);
			for (int i = 0; i < (int) sza; i++) {
				popvarsum += (popmean - a[i]) * (popmean - a[i]);
				if (i % 2 == 0) {
					varsum += (mean - a[i]) * (mean - a[i]);
				}
			}
			popvar = popvarsum / sza;
			var = varsum / (samplesza - 1);
			//ps.printf(" %.3f", popvar);
			ps.printf("%.3f", Math.abs(var - popvar));
		}
		if (a[0] % 2 == 1) {
			for (int i = 0; i < (int) sza; i++) {
				popsum += a[i];
				if (i % 2 == 1) {
					sum += a[i];
					samplesza++;
				}
			}
			popmean = popsum / (int) sza;
			mean = sum / (int) samplesza;
			// ps.printf(" %f", mean);
			for (int i = 0; i < (int) sza; i++) {
				popvarsum += (popmean - a[i]) * (popmean - a[i]);
				if (i % 2 == 1) {
					varsum += (mean - a[i]) * (mean - a[i]);
				}
			}
			popvar = popvarsum / sza;
			var = varsum / (samplesza - 1);
			// ps.printf(" %.2f", varsum1);
			ps.printf("%.3f", Math.abs(var - popvar));
		}

		ps.println();
		sc.close();
	}
}