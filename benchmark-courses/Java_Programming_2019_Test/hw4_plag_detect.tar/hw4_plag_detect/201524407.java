import java.io.PrintStream;
import java.util.Scanner;

public class VarDiff {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza=0;
		for(int i=0; sc.hasNextInt(); sza++, i++)
			a[i]=sc.nextInt();
		int[] b = new int[sza];
		for(int i=0; i<sza; ++i)
			b[i]=a[i];
		int c = (b[0]%2);
		int d=0;
		for(int i=c; i<sza;d++, i=i+2) {
			a[d]=b[i];	
		}

		double Sample_s=Var(a, d);
		double Population_s=Var(b,sza);
		double SVar= Sample_s/(d-1);
		double PVar=Population_s/sza;
		double diff=SVar-PVar;
		ps.printf("%.3f%n", ab(diff));
		sc.close();
	}
	
	public static double Var(int[] Array, int size ) {
		int sum=0;
		double avg,sumsum=0;
		
		for(int i=0; i<size; i++)
			sum += Array[i];
		
		avg=(double)sum/size;
		for(int i=0; i<size; i++) {
			sumsum += (avg-Array[i])*(avg-Array[i]);
		}
		
		return sumsum;
			
	}
	
	public static double ab(double d) {
		if(d>0)
			return +d;
		else
			return -d;
	}
	

}
