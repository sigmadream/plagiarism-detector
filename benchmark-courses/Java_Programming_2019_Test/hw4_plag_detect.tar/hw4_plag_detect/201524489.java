import java.io.PrintStream;
import java.util.Scanner;

public class vardiff {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		int sza=0,szb,count=0;
		
		for(int i=0;sc.hasNextInt();sza++,i++)
			a[i]=sc.nextInt();
		
		if(a[0]%2==0) {
			if(sza%2==0)
				szb=sza/2;
			else
				szb=(int)(sza/2)+1;
		}
		else {
			szb=sza/2;
		}
		
		int[] b = new int[szb];
		
		if(a[0]%2==0) {
			for(int i=0;i<sza;count++,i=i+2)
				b[count]=a[i];
		}
		else {
			for(int i=1;i<sza;count++,i=i+2)
				b[count]=a[i];
		}
		int[] c=new int[sza];
		for (int i=0;i<sza;i++)
			c[i]=a[i];

		ps.printf("%.3f",VARdiff(b,c,szb,sza));
		sc.close();	

	}
	public static double VARdiff(int[] a,int[] c,int size,int psize) {
		double sum=0,ave=0,psum=0,var=0,pave=0,msum=0,pvar=0,pmsum=0;

		for(int i=0;i<size;i++)
			sum=sum+a[i];
		ave=sum/(double)size;
		for(int i=0;i<size;i++)
			psum=psum+((double)a[i]-ave)*((double)a[i]-ave);
		var=psum/(double)(size-1);

		for(int i=0;i<psize;i++)
			msum=msum+c[i];
		pave=msum/(double)psize;
		for(int i=0;i<psize;i++)
			pmsum=pmsum+((double)c[i]-pave)*((double)c[i]-pave);
		pvar=pmsum/(double)(psize);

		double vardiff;
		if(var<pvar)
			vardiff=pvar-var;
		else
			vardiff=var-pvar;

		return vardiff;

	}

}