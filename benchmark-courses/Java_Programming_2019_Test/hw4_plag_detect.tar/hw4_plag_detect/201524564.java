import java.io.PrintStream;
import java.util.Scanner;

public class VarDiff {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] InElement = new int[500];
		int InSize = 0 , SampleSize , Count=0;
		double sampleVar=0, populationVar=0,VarDiff=0,vardiff=0;

		for (int i = 0; sc.hasNextInt(); InSize++, i++)
			InElement[i] = sc.nextInt();	
		int [] Popul_Array =new int[InSize];
		for (int i = 0; i<InSize;i++)
			Popul_Array[i]=InElement[i];
		SampleSize=SIZE_DEF(InElement, InSize);
		
		int[] SampleArray= new int[SampleSize];	
		
		if (InElement[0]%2==0) {			
			for(int i=0 ; i<InSize ; Count++,i=i+2) 
				SampleArray[Count]=InElement[i];
		}
		else {
			for(int i=1; i<InSize ;Count++, i=i+2) 
				SampleArray[Count]=InElement[i];	
		}						
		sampleVar=PYUNCHA_SUM(SampleArray,SampleSize)/(SampleSize-1);
		populationVar=PYUNCHA_SUM(Popul_Array,InSize)/(InSize);
		VarDiff=sampleVar-populationVar;
		if (VarDiff<0)
			vardiff=-VarDiff;
		else 
			vardiff=VarDiff;
		ps.printf("%.3f",vardiff);
		sc.close();
	}
	
	public static double PYUNCHA_SUM(int [] a,int size) 
	{
	
		double sum=0,ave=0,pyunchasum=0;
		for(int i=0;i<size;i++) 
			sum=sum+a[i];
		ave=sum/(double)size;
		for(int i =0; i<size; i++)			
			pyunchasum=pyunchasum+((double)a[i]-ave)*((double)a[i]-ave);
		return pyunchasum;
	}
	
	public static int SIZE_DEF(int[] b, int insize)
	{
		int samplesize=0;
		if(b[0]%2==0) {				
			if(insize%2==0)
				samplesize=insize/2;
			else
				samplesize=(int)(insize/2)+1;
			}
		else {
			samplesize=insize/2;
		}
		return samplesize;
	}
}
