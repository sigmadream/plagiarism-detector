
import java.io.PrintStream;
import java.util.Scanner;

public class hw02_vardiff {
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int asize=0, sumodd=0, sumeven=0, neven=0, nodd=0;
		int[] a = new int[500];
		for(int i = 0;sc.hasNextInt();i++) {
			asize++;
			a[i] = sc.nextInt();
		}
		if(a[0]%2 == 0) {
			for(int i =0;i<asize;i++) 
				if(i%2 == 0)
				{
					sumeven += a[i];
					neven++;
				}
		}
		else {
			for(int j = 0;j<asize;j++)
				if(j%2 == 1) {
					sumodd += a[j];
					nodd++;
				}
		}
		double averageodd = (double)sumodd/nodd;
		double averageeven = (double)sumeven/neven;
		double[] seven = new double[neven];
		double[] sodd = new double[nodd];
		double sumsteven=0,sumstodd=0;
		
		for(int k =0;k<nodd;k++)
		{
			sodd[k] = sodd[k] + (averageodd-(double)a[k*2+1])*(averageodd-(double)a[k*2+1]);
			sumstodd += sodd[k];
		
		}
		for(int j =0;j<neven;j++)
		{
			seven[j] =seven[j]+ (averageeven-(double)a[j*2])*(averageeven-(double)a[j*2]);
			sumsteven += seven[j];
		}
		
		
		int bsize=0,sum=0;
		
		int[] b = new int[500];
		for(int i = 0;i<asize;i++) {
			bsize++;
			b[i] = a[i];
			sum += b[i];
		}
		
		
		double average = (double)sum/bsize;
		double[] seven2 = new double[bsize];
		double[] sodd2 = new double[bsize];
		double sumst=0;
		
		
		
		for(int k =0;k<bsize;k++)
		{
			sodd2[k] = sodd2[k] + (average-(double)b[k])*(average-(double)b[k]);
			sumst += sodd2[k];
		
		}
	
		if(b[0]%2 == 0)
		{
			double reven = (sumsteven/(double)(neven-1))-(sumst/(double)(bsize));
			
			if(reven >= 0) {
			ps.printf("%.3f%n",reven);
			}
			else {
				ps.printf("%.3f%n",-reven);
			}
		}
		else
		{
			double rodd = (sumstodd/(double)(nodd-1))-(sumst/(double)(bsize));
			if(rodd >= 0) {
			ps.printf("%.3f%n", rodd);
			
			}
			else {
				ps.printf("%.3f%n", -rodd);}
		}
		
	}
}

