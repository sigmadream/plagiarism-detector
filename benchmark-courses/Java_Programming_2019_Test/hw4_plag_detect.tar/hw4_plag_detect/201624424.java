import java.io.PrintStream;
import java.util.Scanner;

public class Homework1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		int sza = 0;
		int sum1=0,sum2=0;
		int cnt1=0,cnt2=0;
		double average1=0,average2=0;
		double result1=0;
		double result2=0;
		for (int i = 0; sc.hasNextInt(); sza++, i++){
			a[i] = sc.nextInt();
		}
		int [] b = new int[(sza+1)/2-(a[0]%2)*(sza%2)];
		if(a[0]%2==0){
			for(int i=0;i<(sza+1)/2-(a[0]%2)*(sza%2);i++){
				b[i]=a[2*i];
			}
		}
		else{
			for(int i=0;i<(sza+1)/2-(a[0]%2)*(sza%2);i++){
				b[i]=a[2*i+1];
			}
		}
		for(int n :b){
			sum1+=n;
			cnt1+=1;
		}
		average1=sum1/(double)cnt1;
		for(int n :b){
			result1+=(n-average1)*(n-average1);
		}
		for(int i=0;i<sza;i++){
			sum2+=a[i];
			cnt2+=1;
		}
		average2=sum2/(double)cnt2;
		for(int i=0;i<sza;i++){
			result2+=(a[i]-average2)*(a[i]-average2);
		}
	result1=result1/(cnt1-1);
	result2=result2/cnt2;
	ps.printf("%.3f",Math.abs(result1-result2));
	sc.close();
	}
}
