import java.util.Scanner;
import java.text.DecimalFormat;
 
public class VarDiff {
	public static void main(String[] args){
		double varDiff;
		
		varDiff=getVarDiff();
		System.out.printf( "VarDiff= %05.3f", varDiff);
	}
	
	public static double getVarDiff(){
		int[] pNumbers=new int[500];
		int[] sNumbers=new int[500];
		double pVar, sVar;
		double pDiffSum=0, sDiffSum=0;
		double varDiff;
		int pSize, sSize;		
		
		pSize=getNumbers(pNumbers,sNumbers);
		if(isEven(pNumbers[0])){
			sSize=(pSize+1)/2;
		}
		else{
			sSize=pSize/2;
		}

		pDiffSum=getDiffSum(pNumbers,pSize);
		sDiffSum=getDiffSum(sNumbers,sSize);

		pVar=pDiffSum/(double)pSize;
		sVar=sDiffSum/((double)sSize-1.0);

		varDiff = Math.abs(pVar-sVar);
		return varDiff;
	}
	
	public static boolean isEven(int num){
		return num%2==0;
	}
	
	public static int getNumbers(int[] pNumbers, int[] sNumbers){
		int i,j;
		Scanner scan = new Scanner(System.in);
 
		pNumbers[0]=scan.nextInt();
		if(isEven(pNumbers[0])){
			sNumbers[0]=pNumbers[0];
			for(i=1,j=1;scan.hasNextInt() && i<500;++i){
				pNumbers[i]=scan.nextInt();
				if(i%2==0){
					sNumbers[j++]=pNumbers[i];
				}
			}
		}
		else{
			for(i=1,j=0;scan.hasNextInt() && i<500;++i){
				pNumbers[i]=scan.nextInt();
				if(i%2==1){
					sNumbers[j++]=pNumbers[i];
				}
			}
		}
		scan.close();
		return i;
	}
	
	public static int getSum(int[] numbers,int size){
		int sum=0;
		
		for(int i=0;i<size;++i){
			sum+=numbers[i];
		}
		return sum;
	}
	
	public static double getAver(int[] numbers, int size){
		double aver;
		
		aver=(double)getSum(numbers,size)/(double)size;
		
		return aver;
	}
	
	public static double getDiffSum(int[] numbers,int size){
		double aver,diffSum=0;
		int i;
		
		aver=getAver(numbers,size);
		for(i=0;i<size;++i){
			diffSum+=(numbers[i]-aver)*(numbers[i]-aver);
		}
		return diffSum;
	}
}