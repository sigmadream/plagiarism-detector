import java.util.Scanner;

public class vardiff {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] a = new int[500];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		int[] b= new int[sza];
		int sum1=0;		
		for(int i=0; i<sza; i++) {
			b[i]=a[i];
			sum1+=a[i];
		}

		int d=sza;

		double avg=(double)sum1/d;
		double sum2=0;
		for(int i=0; i<d; i++) {
			sum2+=(avg-a[i])*(avg-a[i]);
		}
		double s1=sum2/d;
		
		int c=(a[0]%2);
		int d1=0; sum1=0;
		for(int i = c;i<d;i=i+2) {
			a[d1]=b[i];
			sum1+=b[i];
			d1++;
		}
		avg=(double)sum1/d1;
		sum2=0;
		for(int i=0; i<d1; i++) {
			sum2+=(avg-a[i])*(avg-a[i]);
		}
		double s2=sum2/(d1-1);
		
		double e;
		if (s1>s2) e=s1-s2;
		else e=s2-s1;

		System.out.printf("%.3f%n", e);
		sc.close();
	}
}