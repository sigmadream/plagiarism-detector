import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[500];
		
		int sza = 0;
		int x_size = 0;
		int x_sum = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		
		int[] b = new int[sza];
		double answerX = 0;
		for(int i = 0; i < sza; i++) {
			b[i]=a[i];
			x_sum+=b[i];
			
		}
		double x_bar = (double)x_sum/sza;
		double xx = 0;
		for(int i = 0; i < sza; i++) {
			xx+=(x_bar-b[i])*(x_bar-b[i]);
		}
		answerX = xx/sza;
		
		
		int sel = 0;
		sel = (b[0]%2); 
		int y_size = 0;
		int y_sum = 0;
		for(int i = sel; i < sza; i = i+2) {
			a[y_size]=b[i];
			y_sum += b[i];
			y_size++;
		}
		
		
		
		double y_bar = 0;
		double sumY=0;
		y_bar = (double)y_sum/y_size;
		for(int i = 0; i < y_size;i++) {
			sumY += (y_bar-a[i])*(y_bar-a[i]);
		}
		double answerY = 0;
		answerY = sumY/(y_size-1);
		ps.printf("%.3f",Math.abs(answerX-answerY));
		//ps.println(Arrays.toString(a));
		
		sc.close(); 
		}
	}