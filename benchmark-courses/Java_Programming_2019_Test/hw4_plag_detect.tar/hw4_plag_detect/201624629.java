import java.io.PrintStream;
import java.util.Scanner;

public class VarDiff {

	public static void main(String[] args) {
		// Initialization and Declaration
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[499]; // array a with maximum 499 number of elements 
		int[] b = new int[250]; // array b with maximum 250 number of odd or even elements from array a
		int size_of_a = 0; // number of inserted elements - X
		int size_of_b = 0; // number of sample elements - Y
		int j = 0; // index of b array

		// Inserting the values to an array
		for (int i = 0; sc.hasNextInt(); size_of_a++, i++)
			a[i] = sc.nextInt();

		if (a[0] % 2 != 0) {
			for(int i = 0 ; i < size_of_a; i++)
				if(i % 2 != 0) {
					b[j++] = a[i];
					size_of_b ++;
				}

		} else if (a[0] % 2 == 0) {
			for(int i = 0 ; i < size_of_a; i++)
				if(i % 2 == 0) {
					b[j++] = a[i];
					size_of_b ++;
				}
		}

		// Calculating total of sample
		double total_of_sample = 0;
		for (int i = 0; i < b.length; i++)
			total_of_sample += b[i];

		// Calculating mean of sample
		double mean_of_sample = 0;
		mean_of_sample = total_of_sample / size_of_b;

		// Calculating sample variance
		double sample_variance = 0;
		double sample_variance_before_division = 0;
		for (int i = 0; i < size_of_b; i++)
			sample_variance_before_division += (b[i] - mean_of_sample) * (b[i] - mean_of_sample);
		sample_variance = sample_variance_before_division / (size_of_b - 1);

		// Calculating total of population
		double total_of_population = 0;
		for (int i = 0; i < a.length; i++)
			total_of_population += a[i];

		// Calculating mean of population
		double mean_of_population = 0;
		mean_of_population = total_of_population / size_of_a;

		// Calculating population variance
		double population_variance = 0;
		double population_variance_before_division = 0;
		for (int i = 0; i < size_of_a; i++)
			population_variance_before_division += (a[i] - mean_of_population) * (a[i] - mean_of_population);
		// Note, we do not need to subtract one from the size of a
		population_variance = population_variance_before_division / (size_of_a);

		// Calculating the difference between sample variance and population variance
		double diff = population_variance - sample_variance;

		// Printing the difference with 3 digit numbers
		ps.printf("%.3f%n", Math.abs(diff));
		sc.close();	
	}
}
