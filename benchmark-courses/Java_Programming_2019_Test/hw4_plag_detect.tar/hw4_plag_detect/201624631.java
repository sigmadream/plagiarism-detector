import java.io.PrintStream;
import java.util.Scanner;

public class VarrDiff {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    PrintStream ps = System.out;
    int size1 = 0; 
    int size2 = 0;
    int[] array1 = new int[499]; 
    int[] array2 = new int[249]; 
  
    for (int i = 0; sc.hasNextInt(); size1++, i++)
      array1[i] = sc.nextInt();

    int j=0;
    
    if (array1[0] % 2 != 0) 
      
      for(int i = 0 ; i < size1; i++) {
        if(i % 2 != 0) {
          array2[j] = array1[i];
          j++;
          size2 ++;
      }
    } else if (array1[0] % 2 == 0) 
      for(int i = 0 ; i < size1; i++) {
        if(i % 2 == 0) {
          array2[j] = array1[i];
          j++;
          size2 ++;
        
      }
    }
 
    double total = 0;
    for (int i = 0; i < array2.length; i++)
      total += array2[i];
        
    double mean = total / size2;
  
    double variance2 = 0;
    double variance1 = 0;
    for (int i = 0; i < size2; i++)
      variance2 += (array2[i] - mean) * (array2[i] - mean);
    variance1 = variance2 / (size2 - 1);
  
    double totpopulation = 0;
    for (int i = 0; i < array1.length; i++)
      totpopulation += array1[i];
    

    double meanpopulation = 0;
    meanpopulation = totpopulation / size1;
  
    double varpopulation = 0;
    double varpopulation2 = 0;
    for (int i = 0; i < size1; i++)
    	  varpopulation2 += (meanpopulation-array1[i]) * (meanpopulation-array1[i]);
    varpopulation = varpopulation2 / (size1);
   
    double diff = varpopulation - variance1;
   
    if ( diff< 0) {
		diff *= -1.000;
	}

    ps.printf("%.3f%n", diff);
    sc.close(); 
  }
}


