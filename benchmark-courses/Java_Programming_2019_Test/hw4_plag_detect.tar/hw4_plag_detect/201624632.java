import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int[] a = new int[499];
		
		int[] b = new int[250];
		int sza = 0;
		int szb = 0;
		int k = 0;
		int t = 0;
		double ave = 0;
		double ari = 0;
		double vri = 0;
		double dve = 0;
		double adi = 0;
		double vdi = 0;
		double diff;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();// for every n in 
		if (a[0] % 2 == 0) {
			for (int i = 0; i < sza; i++) {
				if(i%2 == 0){
					b[szb]=a[i];
					szb++;
				}
			}
			
		}
		else {
			for (int i = 0; i < sza; i++) {
				if (i % 2 != 0) {
					b[szb] = a[i];
					szb ++;
				}
			}
		}
		
		
		if (szb > 0) {
			double sum1 = 0.0;
			for (int j = 0; j < szb; j++) {
				sum1 += b[j];
			}
			ave = sum1 / szb;
		}
		for(k = 0; k < szb; k++) {
			
			ari += (b[k] - ave) * (b[k] - ave);
			
		}
		vri = ari / (szb - 1);
		
		if(sza > 0) {
			double sum2 = 0.0;
			for (int c = 0; c < sza; c++) {
				sum2 += a[c];
			}
			dve = sum2 / sza;
		}
		
		for (t = 0; t < sza; t++) {
			
			adi += (a[t] - dve) * (a[t] - dve);
			
		}
		vdi = adi / sza;
		
		diff = Math.abs(vdi - vri);
		ps.printf("%.3f", diff);
		sc.close();
	}
}