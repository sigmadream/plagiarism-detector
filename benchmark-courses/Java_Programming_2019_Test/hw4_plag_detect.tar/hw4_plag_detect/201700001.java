import java.util.ArrayList;
import java.util.Scanner;

public class VarDiff {

    public static void main(String[] args) throws Exception {
        ArrayList<Integer> list = readInts();
        double svar =  sVariance(list);
        double pvar =  pVariance(list);
        //System.out.printf("%f\n", sVariance(list));
        //System.out.printf("%f\n", pVariance(list));
        System.out.printf("%.3f\n", Math.abs(svar - pvar));
    }

    public static ArrayList<Integer> readInts(){
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> al = new ArrayList<Integer>();
        while (sc.hasNextInt()) {
            al.add(sc.nextInt());
        }
        return al;
    }

    public static double sVariance(ArrayList<Integer> al) {
        int sum = 0;
        double mean = 0;
        double svar = 0;
        int count=0;
        Integer[] a = al.toArray(new Integer[] {});
        if(a[0]%2 ==0){
            for (int i=0;i<a.length ; i+=2){
                sum += a[i];
                count++;
            }
            mean = ((double) sum /count);
            for (int i=0;i<a.length ; i+=2){
                svar +=(Math.pow((a[i]- mean), 2));
            }
            svar /= (count-1);
        }
        else{
            for (int i=1;i<a.length ; i+=2){
                sum += a[i];
                count++;
            }
            mean = ((double) sum /count);
            for (int i=1;i<a.length ; i+=2){
                svar +=(Math.pow((a[i]- mean), 2));
            }
            svar /= (count-1);
        }
        return svar;
    }

    public static double pVariance(ArrayList<Integer> al){
        int sum = 0;
        double mean, pvar = 0;
        Integer[] b = al.toArray(new Integer[] {});
        for (int i=0; i<b.length; i++)
            sum += b[i];
        mean = ((double) sum / b.length);
        for (int i=0;i<b.length;i++){
            pvar += (Math.pow((b[i] - mean), 2));
        }
        pvar = pvar / b.length;
        return pvar;
    }

}