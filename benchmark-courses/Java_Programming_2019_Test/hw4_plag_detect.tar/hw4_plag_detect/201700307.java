import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class SVar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] a = new int[10];
		int sza = 0;
		for (int i = 0; sc.hasNextInt(); sza++, i++)
			a[i] = sc.nextInt();
		 //ps.printf("%d elements are read.%n", sza);
		
		int szab;

		if (a[0] % 2 == 0)
			if (sza % 2 == 0)
				szab = sza/2;
			else szab = sza/2+1;
		else szab = sza/2;


		int[] b = new int[szab];			//add one more array to fix the size
		if (a[0] % 2 == 0)
			for (int i = 0; i < szab; i++)
				b[i] = a[2*i];
		else for (int i = 0; i < szab; i++)
				b[i] = a[2*i+1];
		
		//ps.printf("And the even integers are:");
		//for (int n: b) 					// for every n in a
		//	if (n % 2 == 0) 			// if n is even
		//		ps.printf(" %d", n); 	// print n ps.println();
		//ps.println();
		//ps.printf("array a = %s%n", Arrays.toString(a));
		//ps.printf("array b = %s%n", Arrays.toString(b));

		float ave = 0;
		for (int i = 0; i < szab; i++)
			ave += b[i];
		ave = ave / szab;

		float svar = 0;
		for (int i = 0; i < szab; i++)
			svar += (b[i] - ave) * (b[i] - ave);
		svar = svar / (szab-1);
		
		ave = 0;
		for (int i = 0; i <sza; i++)
			ave += a[i];
		ave = ave /sza;
		
		float pvar = 0;
		for (int i = 0; i <sza; i++)
			pvar += (a[i] - ave) * (a[i] - ave);
		pvar = pvar /sza;
		
		float diff = pvar-svar;
		
		if (diff < 0)
			ps.printf("%.3f%n", -diff);
		else ps.printf("%.3f%n", diff);
		sc.close();
		ps.close();
	}
}