import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Factors {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		
		ArrayList<Integer> f= new ArrayList<>();
		ArrayList<Integer> p= new ArrayList<>();
		int sum=0;
		
		Factors(n, f);
		PFactors(n, p);
		
		sum = SFactors(f, p, sum);	
//		for(int i=0;i<f.size();i++)
//			ps.printf("%d",f.get(i));
//		ps.println();
//		for(int i=0;i<p.size();i++)
//			ps.printf("%d",p.get(i));
		
		ps.printf("%d", sum);
	}

	private static int SFactors(ArrayList<Integer> f, ArrayList<Integer> p, int sum) {
		if(f.size()==0) {
		
		}
		else {
			for(int i=0;i<f.size();i++)
				sum+=f.get(i);
			for(int i=0;i<p.size();i++)
				sum-=p.get(i);
		}
		return sum;
	}

	private static void PFactors(int n, ArrayList<Integer> p) {
		int fcs=2;
		while(n!=1) {
			while(n%fcs!=0)
			{
				fcs++;
			}
			p.add(fcs);
			n=n/fcs;
		}
	}

	private static void Factors(int n, ArrayList<Integer> f) {
		for(int i=2;i<n;i++) {
			if(n%i==0)
				f.add(i);
		}
	}
}
