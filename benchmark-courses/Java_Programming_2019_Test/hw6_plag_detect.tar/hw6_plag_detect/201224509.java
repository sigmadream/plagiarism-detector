import java.io.PrintStream;
import java.util.*;

public class HW03 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> factor = new ArrayList<> ();
		ArrayList<Integer> prime = new ArrayList<> ();
		int number = sc.nextInt();
		int numbersample = number;
		int suma = 0, sumb = 0;
		for(int i=2; i<number; i++)
			if(number % i == 0) {
				factor.add(i);
				suma += i;
			}
		
		int devide = 2;
		while(devide <= numbersample) {
			if(numbersample % devide == 0 && devide != number ) {
				numbersample = numbersample / devide;
				prime.add(devide);
				sumb += devide;
				devide--;
			}
			devide++;
		}
		
		ps.printf("%d\n", suma-sumb);
		
		sc.close();
		ps.close();
		
		
	}
}
