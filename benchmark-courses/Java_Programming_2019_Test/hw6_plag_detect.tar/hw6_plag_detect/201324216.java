import java.io.*;
import java.util.*;

public class Factors {

	static public void main(String args[]) {
		PrintStream ps = System.out;
		Scanner sc = new Scanner(System.in);

		int num = sc.nextInt();

		ArrayList<Integer> fctrs = getFactors(num);
		ArrayList<Integer> primeFctrs = getPrimeFactors(num);
		ps.print(sumArray(fctrs)-sumArray(primeFctrs));
		return;
	}

	private static int sumArray(ArrayList<Integer> fctrs) {
		int sum = 0;
		for(int i = 0 ; i < fctrs.size(); i++) {
			sum += fctrs.get(i);
		}
		return sum;
	}

	private static ArrayList<Integer> getFactors(int num) {
		ArrayList<Integer> fctrs = new ArrayList<>();
		for (int i = 2; i < num; i++) {
			if (num % i == 0)
				fctrs.add(i);
		}
		return fctrs;
	}

	private static ArrayList<Integer> getPrimeFactors(int onum) {
		ArrayList<Integer> primeFctrs = new ArrayList<>();
		int num = onum;
		for(int i = 2 ; num != 1 && i != onum ; ) {
			if(num%i == 0) {
				primeFctrs.add(i);
				num /= i;
			}
			else
				i++;
		}
		return primeFctrs;
	}

}
