import java.io.PrintStream;
import java.util.Scanner;
import java.util.ArrayList;

public class PFactors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		//ps.println("Enter an integers: ");
		ArrayList<Integer> al = new ArrayList<>();
		ArrayList<Integer> bl = new ArrayList<>();
		int x = 0;
		int sumf = 0;
		int sumpf = 0;
		
		x = sc.nextInt();
		
		factors(al, x);
		
		prime_factors(bl, x);
		
//		ps.println(al);
		/*
		printl(ps, al);
		ps.println();
		printl(ps, bl);
		*/
		for (int i = 0; i < al.size(); ++i)
			sumf += al.get(i);
		
		for (int i = 0; i < bl.size(); ++i)
			sumpf += bl.get(i);

//		ps.println();
		ps.printf("%d%n",sumf - sumpf);
		
		sc.close();
		ps.close();
	}

	private static void prime_factors(ArrayList<Integer> bl, int x) {
		int j = 2;
		int y = x;
		while(j <= y){
			if (x % j == 0){
				bl.add(j);
				x = x / j;
			}
			else
				j++;
		}
		if(bl.isEmpty() || bl.get(0) == y){
			bl.clear();
			bl.add(0);
		}
	}
/*
	private static void printl(PrintStream ps, ArrayList<Integer> al) {
		for (int i = 0; i < al.size(); ++i)
			ps.printf("%d%s", al.get(i), i == al.size()-1?"":" ");
	}
*/
	private static void factors(ArrayList<Integer> al, int x) {
		for(int i = 2; i < x; i++)
			if(x % i == 0)
				al.add(i);
		if(al.isEmpty())
			al.add(0);
	}
}
