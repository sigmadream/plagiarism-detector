
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;



public class PFactors {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int count=0;
		int length=20;
		int[] arr = new int[length];


		ArrayList<Integer> number1 = new ArrayList<>();
		ArrayList<Integer> number2 = new ArrayList<>();
		
		
		int valforfac = sc.nextInt();

		valforfac = Math.abs(valforfac);
		
		int FSum = 0;
		for(int i=2; i<valforfac; i++)
		{
			
			if(valforfac % i == 0)
			{
				//number1.add(i);
				
				FSum += i;
			
			}
		}
		String line1 = number1.toString();
		ps.print(line1.replaceAll("^.|.$", "").replace(", ", " "));
	
		
		if (valforfac < 2)
			return;

		do{
			int i = 2; 
			while (valforfac % i != 0)
				i++;
				count++;
				arr[count - 1] = i;
				valforfac = valforfac / i;

		} 
		while (valforfac != 1);
		
		
		
		int PSum = 0;
		if (count == 1) 
		{
			//ps.println( "it is a prime number");
		} 
		else 
		{
			for (int i=0; i<count; i++) 
			{
				//number2.add(arr[i]);
				
				PSum += arr[i];
			}
			
			
			
		}
		String line2 = number2.toString();
		ps.print(line2.replaceAll("^.|.$", "").replace(", ", " "));
		ps.print(FSum - PSum);
		sc.close();
	}
}
