import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Factorization {

	static ArrayList<Integer> find_Fact(ArrayList<Integer> P, int n){
		for(int i = 2; (i <= n) && (i <= n / 2); i++)
			if(n % i == 0) P.add(i);

		return P;
	}
	
	static ArrayList<Integer> find_F(ArrayList<Integer> F, ArrayList<Integer> P){;	
		for(int i = 0; i < P.size(); i++)
			if(find_Fact(F ,P.get(i)).size() == 0)
				F.add(P.get(i));
		return F;
	}
	
	static public void main(String args[]){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		ArrayList<Integer> F = new ArrayList<>();
		ArrayList<Integer> check = new ArrayList<>();
		ArrayList<Integer> P= new ArrayList<>();
		
		int sum_F = 0, sum_P = 0;
		
		int n = sc.nextInt();
		n = Math.abs(n);
		F = find_Fact(F, n);
		check = find_F(F, check);
		
		for(int i = 0; i < check.size(); ){
			if(n == 1) break;
			if(n % check.get(i) == 0){
				P.add(check.get(i));
				n = n / check.get(i);
			}
			else i++;
		}
		
		for(int i = 0; i < P.size(); i++)
			sum_P += P.get(i);
		for(int i = 0; i < F.size(); i++)
			sum_F += F.get(i);
		
		ps.printf("%d\n",sum_F - sum_P);
	}
}