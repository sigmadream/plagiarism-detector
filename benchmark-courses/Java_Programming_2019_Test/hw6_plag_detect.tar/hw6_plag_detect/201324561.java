import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PFactors {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		ArrayList<Integer> al = new ArrayList<Integer> ();
		ArrayList<Integer> bl = new ArrayList<Integer> ();
		int Fsum = 0;
		int Psum = 0;

		int Num = sc.nextInt();
		Num = Math.abs(Num);

		if(Num%2==0)
		{
			for(int i=2; i<Num; i++) {
				if((Num%i)==0) {
					al.add(i);
				}
			}

			for(int j=0;j<al.size();j++)
			{
				Fsum += al.get(j);
			}

			while(Num%2 == 0) {
				Num = Num/2;
				bl.add(2);
			}
			bl.add(Num);

			for(int k=0;k<bl.size();k++)
			{
				Psum += bl.get(k);
			}
			ps.print(Fsum-Psum);
		}
		
		else {
			for(int i=2; i<Num; i++) {
				if((Num%i)==0) {
					bl.add(i);
				}

			}
			for(int j=0;j<bl.size();j++)
			{
				Fsum += bl.get(j);
				Psum += bl.get(j);
			}
			ps.print(Fsum-Psum);
		}
		sc.close();
		ps.close();
	}
}