import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PFactors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int number = sc.nextInt();
		int num1 = factors(number), num2 = Pfactors(number);
		ps.printf("%d",num1 >= num2 ? num1-num2 : num2-num1);
		sc.close();
	}

	private static int Pfactors(int number) {
		int retNum = 0;
		for(int i = 2 ; i < number ; ++i) {
			if(number%i == 0)
				retNum += i;
		}

		return retNum;
	}

	private static int factors(int number) {
		int retNum = 0, i = 2, tNum = number;
		while(tNum != 1) {
			if(tNum%i == 0) {
				retNum += i;
				tNum /= i;
				i = 2;
			}
			else
				i++;
		}
		return retNum == number ? 0 : retNum;
	}
	

}
