import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PFactors {

	private static void findPrimeFactor(ArrayList<Integer> primefactor, int n) {
		int i =2;
		int temp = n;
		while(n != 1){
			if(temp == i) break;
			if(n%i==0){
				primefactor.add(i);
				n = n/i;
				if(n == 1) break;
			}else{
			i++;
			}
		}
	}

	private static void findFactor(ArrayList<Integer> factor, int n) {
		for(int j = 2; j<n; j++){
			if(n%j == 0){
				factor.add(j);
			}
		}
	}
	
	private static int sumFactor(ArrayList<Integer> al){
		int sum = 0;
		for(int i = 0 ; i < al.size(); i++){
			sum+= al.get(i);
		}
		return sum;
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		ArrayList<Integer> factor = new ArrayList<>();
		ArrayList<Integer> primefactor = new ArrayList<>();
		
		int n = Math.abs(sc.nextInt());

		findFactor(factor, n);
		findPrimeFactor(primefactor, n);
		
		int factorsum=sumFactor(factor);
		int primefactorsum=sumFactor(primefactor);
		
		
		int result = factorsum-primefactorsum;
		System.out.println(result);

	}


}