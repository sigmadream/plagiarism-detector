
import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int inputint = Math.abs(sc.nextInt());
		ArrayList<Integer> al = new ArrayList<>();
		ArrayList<Integer> al2 = new ArrayList<>();
		int sum1 = 0; 
		int sum2 = 0;
		for(int i = 2; i<inputint; ++i)
			if(inputint%i==0) {
				al.add(i);
				sum1+=i;
			}
		int inputint1=inputint;
		for(int i = 2; i<inputint; ++i)
			while(inputint1%i==0) { 
				al2.add(i);
				inputint1=inputint1/i;
				sum2+=i;
			}
		
		ps.printf("%d%n", sum1-sum2);
		
		sc.close();
	}

	private static void printf(String string, int sum1) {
		// TODO Auto-generated method stub
		
	}

}