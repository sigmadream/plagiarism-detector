import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class exercise2 {
	private static Scanner sc;

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> Exer2 = new ArrayList<>();
		int number = sc.nextInt();
		number = Math.abs(number);
		int Sum1st = 0;
		for (int i = 2; i < number; i++) {
			if (number % i == 0) {
				Exer2.add(i);
				Sum1st += i;
			} else
				continue;
		}
		int quot = 2;
		int Sum2nd = 0;
		if (number >= 2) {
			while (true) {
				if (number % quot == 0) {
					Sum2nd += quot;
					number = number / quot;
					if (number == 1)
						break;
				} else {
					quot++;
				}
			}
		}
		int result = Sum1st - Sum2nd;
		if (Exer2.size() == 0) {
			result = 0;
		}
//		result=Math.abs(result);
		ps.println(result);
		sc.close();
	}
	
}

// for(int i =0; i<Exer2.size(); i++)
// ps.printf(("%d "), Exer2.get(i));
// int numberOfFactor = 0;
// if (Exer2.size() > 0)
// numberOfFactor = (int) Math.pow(2, Exer2.size() - 1);
// else
// numberOfFactor = 0;