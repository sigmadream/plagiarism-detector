import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PFactors {
   public static void main(String[] args){

      Scanner sc = new Scanner(System.in);
      PrintStream ps = System.out; 
  
      ArrayList<Integer> numbera = new ArrayList<>();
      ArrayList<Integer> numberb = new ArrayList<>();
      int a = sc.nextInt();
      int i=0;
      int lenght = 100000;
      int sum = 0;
      int cnt = 0;
      int[]arr = new int[ lenght];
      int sum2 = 0;
      
      a = Math.abs(a);
      
      if(a > 0)
      { 
         for(i = 2; i <= a / 2; ++i) 
         {
            if (a % i == 0) 
            {                        
               sum += i;   
            }               
         }
         String line = numbera.toString();
         ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
      }   
      
      do{
         i=2;
         while(a%i!=0)
            i++;
         cnt++;
         arr[cnt - 1]=i;
         a = a/i;         
      }
      while(a!=1);
      if(cnt==1){
         //System.out.println(+sum2);      
      }
      else{
         for(i=0;i<cnt;i++){            
            sum2 += arr[i];
          
         }
      }
      String line = numbera.toString();   
      ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
      ps.print(sum-sum2);
      sc.close();
   }   
}
