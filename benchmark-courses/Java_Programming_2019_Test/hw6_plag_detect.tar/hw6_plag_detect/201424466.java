import java.util.Scanner;

public class Prime {
	public static void main(String[] args) {

		Scanner scanner = new Scanner (System.in);
		int number = scanner.nextInt();
		int count= 0;
		int sum_div=0;
		int sum = 0;
		count = number;
		int sum_prime=0;
		for(int i = 2 ; i < number ; i++){

			if((number % i) == 0){
				sum_div = sum_div + i;
			}
		}
		for (int i = 2; i<number; i++) {

			while (count % i == 0) {
				count = count/i;
				sum_prime +=i; 
			}
		}
		System.out.println(sum_div-sum_prime);   
		scanner.close();    
	}
}

