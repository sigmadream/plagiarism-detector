import java.io.PrintStream;
import java.util.*;

public class PFactors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int InputInt = sc.nextInt();
		
		InputInt = Math.abs(InputInt);
		
		ArrayList<Integer> al1 = new ArrayList<>();
		ArrayList<Integer> al2 = new ArrayList<>();
		
		for(int i = 2; i < InputInt; i++) {
			if (InputInt % i == 0) {
				al1.add(i);
			}
		}
		
		int Id = InputInt;
		
		if (!al1.isEmpty()) {
			for(int j = 2; j < al1.get(al1.size()-1) + 1; j++) {
				if(InputInt != j) {
					while (Id % j == 0) {
						Id = Id / j;
						al2.add(j);
					}
				}
				else {
					al1.clear();
					al2.clear();
				}
			}
		}
		
		
		int F = 0;
		int P = 0;
		
		for(int i = 0; i < al1.size(); i++) {
			F += al1.get(i);
		}
		
		for(int i = 0; i < al2.size(); i++) {
			P += al2.get(i);
		}
		
		int Result = F - P;
		
		ps.println(Result);
		
		sc.close();
		ps.close();
	}
}
