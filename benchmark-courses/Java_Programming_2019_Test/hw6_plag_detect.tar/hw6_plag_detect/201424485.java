import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PFactors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> F = new ArrayList<>();
		ArrayList<Integer> P = new ArrayList<>();

		int x = sc.nextInt();
		x = Math.abs(x);

		for (int i=2; i<x; i++)
			if(x % i == 0) 
				F.add(i);
	
		for (int i=2; i<x; i++) 
			while (x % i == 0) {
				P.add(i);
				x = x/i; 
			}	
	
		if (x!=1)
			P.add(x);
		
		int sumF=0;
		int sumP=0;
		
		for (int i:F)
			sumF=sumF+i;
		for (int i:P)
			sumP=sumP+i;
		
		if (F.size() == 0)
			ps.println("0");
		else
			ps.println(sumF-sumP);


		sc.close();		
		ps.close();
    }
}
	