import java.io.PrintStream;
import java.util.Scanner;

public class javaTak {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		PrintStream ps= System.out;
		
		int a = sc.nextInt();
		int b = Math.abs(a);
		int c = b;
		int i = 2;
		
		int sum1 = 0;
		int sum2 = 0;
		
		do {
			if (b%i==0) 
				sum1 += i;
			i++;
			
		} while ( i < b);
					
		int div = 2;
		while(b >= div) {
			if(b%div==0) {
				sum2 += div;
				b = b/div;
			}
			else 
				div++;
		}
		
		if(c==div) {
			sum1 = 0;
			sum2 = 0;
		}
		
		int ans = sum1 - sum2;
		
		ps.println(ans);
		
		sc.close();
	}
}


