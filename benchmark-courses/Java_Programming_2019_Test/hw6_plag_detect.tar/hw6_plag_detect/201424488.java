import java.io.PrintStream;
import java.util.*;

public class Pfactor {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			PrintStream ps = System.out;
			
			ArrayList<Integer> al = new ArrayList<>();
			int n = sc.nextInt();
			int alsum=0,palsum=0;
			
			if(n<0)
				n= -n;
			for(int i=2;i<n;i++) {
				if(n%i == 0){
					al.add(i);
				}
				else;
			}
			for (int i = 0; i < al.size(); ++i) {
				alsum += al.get(i);
			}

			ArrayList<Integer> pal = new ArrayList<>();
			int j=2;
			int c=0;
			
			for(int i=2;i<n+1;i++)
					if(n%i == 0)
						c++; 
			if(c==1)
				pal.add(0);
			else{
			while(n!=1){
				if(n%j==0) {
					n = n/j;
					pal.add(j);
					j=2;
				}
				else
					j++;
			}
			}
			for (int i = 0; i < pal.size(); ++i) {
				palsum += pal.get(i);
			}
			ps.printf("%d",(alsum-palsum));
		}
}
