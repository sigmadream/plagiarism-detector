import java.io.PrintStream;
import java.util.*;

public class PFactors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int num1 = sc.nextInt();
		int num2 = Math.abs(num1);
		int num3 = num1;
		int Fsum = 0;
		int num4 = 2;
		int Psum = 0;
		for(int i=2; i < num2; i++) {
			if((num2%i) == 0) {
				Fsum += i;
			}
		}
		while(num2 >= num4) {
			if(num2 % num4 == 0) {
				Psum += num4;
				num2 = num2/num4;
			}
			else {
				num4++;
			}
		}
		if(num3 == num4) {
			Psum -= num3;
		}
			
		ps.println(Fsum-Psum);
		sc.close();
	}
}