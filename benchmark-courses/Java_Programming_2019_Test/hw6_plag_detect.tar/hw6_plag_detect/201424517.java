import java.util.ArrayList;
import java.util.Scanner;

public class Factors {
	private static int sumofFac(ArrayList<Integer> Factor) {
		int sumF = 0;
		if(Factor.isEmpty()==true)
			return 0;
		for(int i = 0;i<Factor.size();i++) {
			sumF+=Factor.get(i);
			
		}
		return sumF;
	}
	private static ArrayList<Integer> findFac(int a) {
		ArrayList<Integer>Factor = new ArrayList<>();
		for(int i =2;i<a;i++) {
			if(a%i==0)
				Factor.add(i);
		}
		
		return Factor;
	}
	private static ArrayList<Integer> findPri(ArrayList<Integer> al,int i){
		ArrayList<Integer> PriFac = new ArrayList<>();
		int index = 0;
		while(i!=1) {
			if(i%al.get(index)==0) {
				i = i/al.get(index);
				PriFac.add(al.get(index));
			}
			else
				index++;
		}
		return PriFac;
	
	
	}
		
	private static void Print(int value) {
		System.out.println(value);
	}
		

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		ArrayList<Integer> Factor = findFac(a);
	ArrayList<Integer> PriFac = findPri(a, Factor);
	Print(sumofFac(Factor)-sumofFac(PriFac));
	
		sc.close();
	
	}
	private static ArrayList<Integer> findPri(int a, ArrayList<Integer> Factor) {
		ArrayList<Integer> PriFac = new ArrayList<>();
		int index = 0;
		if(Factor.isEmpty()==true)
			return PriFac;
		while(a!=1) {
			if(a%Factor.get(index)==0) {
				a = a/Factor.get(index);
				PriFac.add(Factor.get(index));
			}
			else
				index++;
			
		}
		return PriFac;
	}


	
	
}