import java.io.PrintStream;
import java.util.*;

public class HW03 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int c = x;
		int xsum = 0;
		int psum = 0;
		x = Math.abs(x);
		ArrayList<Integer> al = new ArrayList<>();
		if(1<x && x<100000){
			for (int i = 2; i < x ;i++){
				if( x % i == 0){
					al.add(i);
					xsum += i;
				}
			}
			for (int i = 2; i < x ; i++){
				while( c % i == 0){
					psum += i;
					c /= i;
				}	
			}
		}
		
		
		PrintStream ps = System.out;
		ps.printf("%d", xsum-psum);
		sc.close();
	}
}
