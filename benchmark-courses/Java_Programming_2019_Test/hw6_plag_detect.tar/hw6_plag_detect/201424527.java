import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> F = new ArrayList<Integer>();
		ArrayList<Integer> P = new ArrayList<Integer>();
		
		int factor = sc.nextInt();
		int factors=Math.abs(factor);
		for(int i =2; i< factors ; i++)
		{ 	
			if(factor%i == 0)
			{
				F.add(i);
			}
		}
		for(int j = 2; j <=factors; j++)
		{
			if(factor == j)
			{
			}
			else if( factors % j == 0)
			{
				factors = factors / j;
				P.add(j);
				j = 1;
			}
		}
		
		int sumF = 0;
		int sumP = 0;
		for(int n : F)
		{
			sumF += n;
		}
		for(int k : P)
		{
			sumP += k;
		}
		
		int diff = sumF - sumP;
		if(F.isEmpty()&&P.isEmpty())
		{
			diff = 0;
		}
		
		ps.println(diff);
		sc.close();
	}
}