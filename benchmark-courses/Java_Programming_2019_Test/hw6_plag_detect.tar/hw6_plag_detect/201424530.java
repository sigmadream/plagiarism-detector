import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
//		ps.println("Enter one integers: ");
		ArrayList<Integer> F = new ArrayList<>();
		ArrayList<Integer> P = new ArrayList<>();
		int a = sc.nextInt();
		a = Math.abs(a);
		for (int i=2; i<a; i++) {
			if (a % i == 0) {
				F.add(i);
			}
		} //Array F
		
		
		for (int i=2; i<a/i; i++) {
			while (a % i == 0) {
				a = a/i;
				P.add(i);
			}
		}
		if (a > 1) {
			P.add(a);
		} //Array P
		
		int sumF = 0;
		int sumP = 0;
		for (int i : F) {
			sumF = sumF + i;
		}
		for (int i : P) {
			sumP = sumP +i;
		}
		
		if (F.size() == 0)
			ps.println("0");
		else
			ps.println(sumF-sumP);
		
		
//		String line1 = F.toString();
//		String line2 = P.toString();
//		ps.println(line1.replaceAll("^.|.$", "").replace(", ", " ")); //
//		ps.println(line2.replaceAll("^.|.$", "").replace(", ", " "));
//		ps.println();
		sc.close();
	}
}