import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class e3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> al = new ArrayList<>();
		int n=Math.abs(sc.nextInt());
		int sumF = sumFactors(al, n);
		ArrayList<Integer> al1 = new ArrayList<>();
		int sumP = sumPfactors(al, n);
		ps.println(Math.abs(sumP-sumF));
	}



	private static int sumFactors(ArrayList<Integer> al, int n) {
		int sumF =0;
		for (int i=2; i<n;i++){
			if(n%i==0)
				al.add(i);
		}
		for (int i=0; i<al.size();i++){
			sumF+=al.get(i);
		}
		return sumF;
	}
	private static int sumPfactors(ArrayList<Integer> al, int n) {
		int sumP=0;
		if (al.size()==0){
		}
		else
			for (int i=0;i<=al.size()/2;i++)
				while(n%al.get(i)==0){
					sumP+=al.get(i);
					n=n/al.get(i);
				}
		return sumP;
	}
}

