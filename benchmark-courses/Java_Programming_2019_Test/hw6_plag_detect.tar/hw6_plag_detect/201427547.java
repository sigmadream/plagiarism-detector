import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintStream;
public class PFactors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> al1 = new ArrayList<Integer>();
		ArrayList<Integer> al2 = new ArrayList<Integer>();
		PrintStream ps = System.out;
		int a = (sc.nextInt());
		factor(al1, a);
		if(al1.size() == 0){
			ps.print(0);
			return;
		}
		else{
			prime(al1, al2, a);
		}
		int sum1 = 0;
		int sum2 = 0;
		
		
		for(int i = 0; i < al1.size(); i++){
			sum1 += al1.get(i);
		}
		for(int i = 0; i < al2.size(); i++){
			sum2 += al2.get(i);
		}
		ps.print(Math.abs(sum1 - sum2));
		return;
			
			
			
		}

	private static int prime(ArrayList<Integer> al1, ArrayList<Integer> al2, int a) {
		int b = a;
		for(int j = 0; j <= a/2; j++){

			while(b % al1.get(j) == 0){
				al2.add(al1.get(j));
				b = b / al1.get(j);
			}
			if(b / al1.get(j) < 1){
				break;
			}
		}
		return a;
	}
	

	private static void factor(ArrayList<Integer> al1, int a) {
		for(int i = 2; i < a; i++){
			if(a % i == 0){
				al1.add(i);
			}
		}
	}

}
