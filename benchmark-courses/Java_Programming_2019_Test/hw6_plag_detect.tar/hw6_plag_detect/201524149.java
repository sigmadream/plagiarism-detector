import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PFactors {
	private static Scanner sc;

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		int diff;
		int Psum;
		int Fsum;
		ArrayList<Integer> P = new ArrayList<>();
		ArrayList<Integer> F = new ArrayList<>();
		
		n=Math.abs(n);
		
		factors(n, P);
		pfactors(n, F);

		Psum = sum(n, P);
		Fsum = sum(n, F);
		
		diff = Psum - Fsum;
		ps.println(diff);

	
	}

	static void pfactors(int n, ArrayList<Integer> F) {
		for(int i=2;i<=n;i++) {
			if(n%i==0)
			{
				F.add(i);
				n=n/i;
				i=1;
			}
		}
		if(F.size()==1)
			F.remove(0);
	}

	static void factors(int n, ArrayList<Integer> P) {
		for(int i=2;i<n;i++) {
			if(n%i==0)
				P.add(i);
		}
	}

	static int sum(int n, ArrayList<Integer> P) {
		 int sum=0;
		for(Integer l: P)
			sum+=l;
		return sum;
	}
}