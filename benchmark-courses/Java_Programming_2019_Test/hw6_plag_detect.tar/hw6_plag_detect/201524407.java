import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class PFactors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int num = sc.nextInt();

		ArrayList<Integer> f = Fset(num,sc);
		ArrayList<Integer> p = Pset(num,f);

		sum_sub(f,p,ps);
		
		sc.close();
	}
	public static ArrayList<Integer> Fset(int num, Scanner sc) {
		ArrayList<Integer> f = new ArrayList<>();
		for(int i=2; i<num; i++)
			if(num%i==0)
				f.add(i);
		return f;
	}
	public static ArrayList<Integer> Pset(int num, ArrayList<Integer> f) {
		int temp = num;
		ArrayList<Integer> p = new ArrayList<>();
		for(int i=0; temp!=0 && i<f.size(); i++)
			for( ;temp%f.get(i)==0; ) {
				p.add(f.get(i));
				temp=temp/f.get(i);
			}
		return p;
	}
	public static void sum_sub(ArrayList<Integer> f, ArrayList<Integer> p, PrintStream ps ) {
		int f_sum=0;
		for(int i=0; i<f.size();i++)
			f_sum += f.get(i);
		int p_sum=0;
		for(int i=0; i<p.size(); i++)
			p_sum += p.get(i);
		ps.printf("%d",f_sum-p_sum);	
		
	}
}
