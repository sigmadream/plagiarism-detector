import java.io.PrintStream;
import java.util.Scanner;
import java.util.ArrayList;

public class PF {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> al = new ArrayList<Integer>();
		ArrayList<Integer> bl = new ArrayList<Integer>();
		int numb,diff,sum1=0,sum2=0;
		
		numb = sc.nextInt();
		
		if(numb<0)
			numb = Math.abs(numb);
		
		for(int i=2;i<numb;i++)
			if(numb%i==0)
				al.add(i);
		
		int i=2,numb2;
		numb2=numb;
		while(numb>1 && numb2>i) {
			if(numb%i==0) {
				numb=numb/i;
				bl.add(i);
			}
			else {
				i++;
			}
		}
		int size1=al.size();
		int size2=bl.size();
		
		for(int j=0;j<size1;j++)
			sum1+=al.get(j);
		for(int k=0;k<size2;k++)
			sum2+=bl.get(k);
		
		diff=sum1-sum2;
		if(diff<0)
			diff=Math.abs(diff);
		
		ps.printf("%d\n",diff);
		sc.close();
	}

}
