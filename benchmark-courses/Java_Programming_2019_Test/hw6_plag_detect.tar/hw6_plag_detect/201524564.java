import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintStream;

public class PFactors {
	public static void main(String[] args) {
		PrintStream ps = System.out;
		Scanner sc = new Scanner(System.in);
		int Number= sc.nextInt();
		if (Number<0)
			Number=Math.abs(Number);
		ps.printf("%d\n",F_Sum(Number)-P_Sum(Number));
		sc.close();
	}
	
	public static int F_Sum(int Number){
		ArrayList<Integer> a = new ArrayList<Integer>();
		int Sum=0;
		for (int i=2;i<Number;i++){
			if(Number%i==0)
				a.add(i);  
		}
		for (int i=0; i<a.size();i++)
			Sum =Sum+ a.get(i);
		return Sum;
	}
	public static int P_Sum(int Number) {
		int Sum=0,i=2;
		int num=Number;
		ArrayList<Integer> a = new ArrayList<Integer>();
		while(Number>1 && i<num){
			if(Number%i==0) {
				Number=Number/i;
				a.add(i);
			}
			else
				i++;
		}
		for (int j=0; j<a.size();j++)
			Sum = Sum + a.get(j);
		return Sum;
	}
}
