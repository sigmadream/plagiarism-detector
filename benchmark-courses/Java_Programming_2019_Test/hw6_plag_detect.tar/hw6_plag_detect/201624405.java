

import java.util.*;

public class hw03 {
	public static void main(String[] args) { 
		Scanner sc = new Scanner(System.in);
		
		
		
		int p;
		int length = 20;
		int cnt = 0;
		int [] arr = new int[length];
		int num = sc.nextInt();
		if(num<0){
			num= -num;
			
		}
		int i;
		int sum=0;
		for(i=2; i<num; i++) {
			if((num%i)==0) {
				sum= sum+i;
				
			}
			
			
			
		}
		
		

		int sump = 0;

		if (num < 2)
			return;
		do {
			p = 2;
			while (num%p != 0)
				p++;
			cnt++;
			arr[cnt -1 ] = p;
			num = num/p;
		} 
		while (num != 1);
		if (cnt == 1) {
			
		}
		else {
			for (p=0; p<cnt; p++) {
				sump = sump + arr[p];

			}
		}

		int dif = 0;
		dif = sum - sump ;
		System.out.println(dif);

	}

}


