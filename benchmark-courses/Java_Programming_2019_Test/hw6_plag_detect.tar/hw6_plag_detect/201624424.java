import java.io.PrintStream;
import java.util.*;

public class hw3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int number=sc.nextInt();
		int al1_sum=0;
		int al2_sum=0;
		int length=number;
		ArrayList<Integer> al1 = new ArrayList<>();
		ArrayList<Integer> al2 = new ArrayList<>();
		for(int i=2;i<length;i++){
			if(number%i==0){
				al1.add(i);
				al1_sum+=i;
			}
		}
		for(int i=2;i<length;i++){
			while(number%i==0){
				al2.add(i);
				number=number/i;
				al2_sum+=i;
			}
		}
		ps.printf("%d", al1_sum-al2_sum);
		sc.close();
	}
}