import java.io.PrintStream;
import java.util.Scanner;

public class PFactors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n=sc.nextInt(),m=n, sum=0;
		
		
		
		for(int i=2; i<n; i++) {
			if(n%i==0) sum+=i;
		}
		int i=2;
		while(true){
			int k=0;
			for(int j=2; j<i; j++) {
				if(i%j==0) {
					k=1;
				}
			}
			if(m==i && k==0 ) {
				sum=0;
				break;
			}
			else if(n%i==0 && k==0) {
				n/=i;
				sum-=i;
			}
			else if (n==1) break;
			else i++;
		}
	
	
		ps.printf("%d", sum);
	
	
		sc.close();
	}
}
