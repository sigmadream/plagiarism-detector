
 import java.util.*;

 	public class hw3 {
 		public static void main(String[] args) {
 			
 			int p;
 			int length = 20;
 			int cnt = 0;
 			int [] arr = new int[length];
 			Scanner sc = new Scanner(System.in);
 			int sumf = 0;
 			int num = sc.nextInt();
 			if (num < 100000 )
 				for (int f = 2; f < num; f++) {
 					if(num%f==0) {
 						sumf = sumf + f;
 						
 						
 					}
 			
 				}
 		
 			
 		int sump = 0;
 			
			if (num < 2)
				return;
			do {
				p = 2;
				while (num%p != 0)
					p++;
				cnt++;
				arr[cnt -1 ] = p;
				num = num/p;
			} 
			while (num != 1);
			if (cnt == 1) {
				
			}
			else {
				for (p=0; p<cnt; p++) {
					sump = sump + arr[p];
				
				}
			}
			
		int dif = 0;
		dif = sumf - sump ;
		System.out.println(dif);
			
 	}
 		}
 	