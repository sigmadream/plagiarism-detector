import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PFactors {

	public static void main(String[] args) throws Exception {
		PrintStream ps = System.out;
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> a, b;
		int n;
		n = sc.nextInt();
		sc.close();

		if (n > 1 && n < 100000) {
			a = factorsOf(n);
			b = primeFactorsOf(n);
			ps.print(elementsSumOf(a) - elementsSumOf(b));
			ps.println();

		}

		else {
			throw new Exception();
		}

	}

	public static ArrayList<Integer> factorsOf(int n) {
		ArrayList<Integer> al = new ArrayList<>();

		for (int i = 2; i < n - 1; i++) {
			if (n % i == 0) {
				al.add(i);
			}
		}
		return al;
		
	}

	
	public static ArrayList<Integer> primeFactorsOf(int n) {
		ArrayList<Integer> al = new ArrayList<>();
		ArrayList<Integer> prime_numbers = new ArrayList<>();
		int i;
		prime_numbers = primeNumbersOf(n);

		while (n > 1) {
			for (i = 0; i < prime_numbers.size(); i++) {
				if (n % prime_numbers.get(i) == 0) {
					al.add(prime_numbers.get(i));
					n = n / prime_numbers.get(i);
				}
			}
		}
		
		return al;
		
	}

	
	public static int elementsSumOf(ArrayList<Integer> al) {
		int sum = 0;
		for (int i = 0; i < al.size(); i++) {
			sum += al.get(i);
		}

		return sum;
		
	}

	
	public static ArrayList<Integer> primeNumbersOf(int n) {
		ArrayList<Integer> al = new ArrayList<>();
		int i = 0;
		int num = 0;
		for (i = 1; i <= n / 2; i++) {
			int counter = 0;
			
			for (num = i; num >= 1; num--) {
				if (i % num == 0) {
					counter = counter + 1;
				}
			}
			
			if (counter == 2) {
				al.add(i);
			}
		}
		
		return al;
		
	}

}

