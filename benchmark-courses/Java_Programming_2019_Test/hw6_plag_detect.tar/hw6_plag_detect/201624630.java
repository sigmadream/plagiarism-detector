import java.io.PrintStream;
import java.util.*;

public class PFactors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		
		ArrayList<Integer> al = new ArrayList<>();
		ArrayList<Integer> factors = new ArrayList<>();
		ArrayList<Integer> prime = new ArrayList<>();
		
		int sumprime = 0;
		int sum = 0;
		int diff = 0;
		
		while (sc.hasNextInt())
			al.add(sc.nextInt());
		for (Integer m: al) {
			for(int k = 2; k < Math.abs(m.intValue()); k++ ) {
				if(Math.abs(m.intValue()) % k == 0)
					factors.add(k);
			}		
		}
		for (Integer n: al) {
			for ( int i = 2; i <= Math.abs(n.intValue()); i ++){
				while (n % i == 0) {
					prime.add(i);
					n /= i; 
				}
			}
		}
		String line = al.toString();
		line.replaceAll("^.|.$", "").replace(", ", " ");
		String line1 = factors.toString();
		line.replaceAll("^.|.$", "").replace(", ", " ");
		
		
		for (Integer a:prime) {
			sumprime += a;
		}
		
		for (Integer b: factors)
		{
			sum += b;
		}
		
		diff = sum - sumprime;
		
		if (diff > 0) 
			ps.println(diff);
		else
			ps.println(0);
		sc.close();
	}
}