import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
 
public class PFactors {
	private static Scanner sc;
	
	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		int Number, i;
		sc = new Scanner(System.in);
		PrintStream ps=System.out;
		Number = sc.nextInt();
		int a= Math.abs(Number);
		int sum=0;
		int sum2=0;
		
		if(isPrime(Number)) {
			ps.println(0);
		}
		else {
			
		
		for(i = 2; i < a; i++) {
			if(a%i == 0) {
				al.add(i);
			}	
		}

		for(i = 0; i < al.size(); i++)
		    sum += al.get(i);
		//ps.println(sum);
		
		String line = al.toString();
		//ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));

		
		
        ArrayList<Integer> primefactors = new ArrayList<>();
        int copyOfInput = Number;

        for (int j = 2; j <= copyOfInput; j++) {
            if (copyOfInput % j == 0) {
                primefactors.add(j); 
                copyOfInput /= j;
                j--;
            }
        }
        
      // ps.println(primefactors); 
        
        
		for(i = 0; i < primefactors.size(); i++)
		     sum2 += primefactors.get(i);
		//ps.println(sum2);
	    
		ps.println(sum-sum2);
		}
		
		
	}
	
	
	
	
	  private static boolean isPrime(int Number) {    
		    boolean isPrime = true;

		    if(Number < 2) {
		      isPrime = false;
		    }

		    for(int ii=2;ii<Number;ii++) {
		      if(Number%ii == 0) {
		        isPrime = false;
		        break;
		      }
		    }

		    return isPrime;
		  }
}


