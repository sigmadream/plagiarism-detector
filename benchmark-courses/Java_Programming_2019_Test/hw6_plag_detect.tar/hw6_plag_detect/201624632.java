import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int l;
		int sum1 = 0;
		int sum2 = 0;
		int h;
		ArrayList<Integer> al = new ArrayList<>();
		ArrayList<Integer> bl = new ArrayList<>();
		ArrayList<Integer> pl = new ArrayList<>();
		while (sc.hasNextInt())
			al.add(sc.nextInt());
		for (Integer n: al) {
			for (int i = 2; i < Math.abs(n.intValue()); i++) {
				if (Math.abs(n.intValue()) % i == 0) {
					bl.add(i);
				}
			}
		}
		String line = bl.toString();
		line.replaceAll("^.|.$", "").replace(", ", " ");
		
		for (Integer k: al) {
			l = Math.abs(k.intValue());
			for (int j = 2; j <= l; j++) {
				while (l % j == 0) {
					pl.add(j);
					l /= j;
					
				}
			}
		}
		String line1 = pl.toString();
		line1.replaceAll("^.|.$", "").replace(", ", " ");
		for (Integer b: bl ) {
			sum1 += b;
			
		}
		for (Integer p: pl ) {
			sum2 += p;
			
		}
		h = sum1-sum2;
		if (h > 0)
			ps.println(h);
		else
			ps.println(0);
		sc.close();
	}
}
