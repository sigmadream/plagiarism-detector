import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import java.util.ArrayList;
import java.util.Scanner;

public class PFactors {

    public static void main(String[] args) {
        int myInt = getInt();
        if (isPrime(myInt)){
            /*System.out.printf("%d is a prime number,\n" +
                    "differnece of two sums is 0\n", myInt);*/
            System.out.print(0);
        }else {
            ArrayList<Integer> factorsAL = getFactors(myInt);
            int myFsum = getArrayListSum(factorsAL);
            //System.out.println("sum of factors is " + myFsum);
            ArrayList<Integer> primesAL = getPrimes(myInt);
            int myPsum = getArrayListSum(primesAL);
            //System.out.println("sum of primes is " + myPsum);
            int diff = Math.abs(myFsum - myPsum);
            //System.out.println("Difference of two sums is " + diff);
            System.out.print(diff);
        }
    }
    public static boolean isPrime(int myInt){
        ArrayList<Integer> al = new ArrayList<Integer>();
        for (int i=2; i<myInt;i++){
            if (myInt % i == 0)
                al.add(i);
        }
        if (al.isEmpty())
            return true;
        else
            return false;
    }
    public static int getInt(){
        Scanner sc = new Scanner(System.in);
        int tmp = sc.nextInt();
        return tmp;
        //return Math.abs(tmp);
    }
    public static ArrayList<Integer> getFactors(int myInt){
        ArrayList<Integer> al = new ArrayList<Integer>();
        for (int i=2; i<myInt;i++){
            if (myInt % i == 0)
                al.add(i);
        }
        //System.out.println("Factors are "+al.toString());
        return al;
    }
    public static Integer getArrayListSum(ArrayList<Integer> tmpAL){
        int sum =0;
        for (int i=0; i<tmpAL.size();i++)
            sum+=tmpAL.get(i);
        return sum;
    }
    public static ArrayList<Integer> getPrimes(int myInt){
        ArrayList<Integer> al = new ArrayList<Integer>();
        int key=1;
        while (myInt > 1){
            for (int i=2; i<=myInt;i++){
                if (myInt%i==0){
                    key=i;
                    al.add(i);
                    break;
                }
            }
            myInt = myInt/key;
        }
        //System.out.println("Primes are " + al.toString());
        return al;
    }
}

