//package hello;

import java.io.PrintStream;
import java.util.*;

public class factor {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		n = Math.abs(n);

		ArrayList<Integer> al = new ArrayList</*Integer*/>();

		for (int i = 2; i<n; i++) 
			if (n % i == 0)
				al.add(i);
		if (al.size() == 0)
			ps.println(0);
		else {
			ArrayList<Integer> pf = new ArrayList<Integer>();
			for (int i = 2; i <= n; i++) {
				while (n % i == 0) {
					pf.add(i);
					n /= i;
				}
			}

//			ps.println(al.toString());
//			ps.println(pf.toString());

			int sum = 0;
			for (Integer i:al)
				sum += i;

			for (Integer i:pf)
				sum -= i;	
			ps.println(sum);
		}
		sc.close();
	}
}