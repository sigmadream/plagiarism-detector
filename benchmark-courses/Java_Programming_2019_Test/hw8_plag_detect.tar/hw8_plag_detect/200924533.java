import java.util.*;
import java.io.PrintStream;

public class HW04 {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		double x;
		double y;
		double p;
		double min;
		Double[] al_F = new Double[100];
		Double[] al_D = new Double[100];
		Double[] result = new Double[3];
		
		int N = sc.nextInt();
		
		// f(x)
		for(int i=N; i>=0; i--){
			x = sc.nextDouble();
			al_F[i] = x;
		}
		
		// input x
		for(int i=0; i<3; i++){
			y = sc.nextDouble();
			al_D[i] = y;
		}
		
		// diff
		for(int i=0; i<3; i++){
			p = 0.0;
			for(int j=1; j<=N; j++){
				p += (j * al_F[j]) * Math.pow(al_D[i], j-1);
			}
			result[i] = p;
		}
		min = result[0];
		for(int i=1; i<3; i++){
			if(result[i] < min) min = result[i];
		}
		ps.printf("%.2f", min);
		sc.close();
	}
}
