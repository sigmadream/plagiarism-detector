import java.io.PrintStream;
import java.util.Scanner;

public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		double[] cef = new double[n+1];
		double[] pmtr = new double[3];
		double[] ans = new double[3];
		
		init(sc, n+1, cef);
		init(sc, 3, pmtr);
		drvt(n, cef);

		for(int i=0;i<3;++i)
			for(int j=0;j<n;++j)
				ans[i] += cef[j]*Math.pow(pmtr[i], n-j-1);
		
		ps.printf("%.2f", find_min(ans));
		sc.close();		
	}

	private static void drvt(int n, double[] cef) {
		for(int i=0;i<n+1;++i)
			cef[i]*=n-i;
	}

	private static double find_min(double[] ans) {
		double min = ans[0]>ans[1] ? ans[1] : ans[0];
		min = min>ans[2] ? ans[2] : min;
		return min;
	}

	private static void init(Scanner sc, int n, double[] a) {
		for(int i=0;i<n;i++)
			a[i] = sc.nextDouble();
	}
}
