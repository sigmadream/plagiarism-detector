import java.io.PrintStream;
import java.util.Scanner;

public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int n = 0;
//		ps.print("Enter n: ");
		n = sc.nextInt();
		
		double [] a = new double [n+1];
//		ps.print("Enter a[]: ");
		for(int i = 0; i < n+1; i++){
			a[i] = sc.nextDouble();
		}
		
		double [] x = new double [3];
//		ps.print("Enter x[]: ");
		for(int i = 0; i < 3; i++){
			x[i] = sc.nextDouble();
		}
		
		double [] min = new double [3];
		for(int m = 0; m < 3; m++){
			int index = n;
			double sum = 0;
			for(int i = 0; i < n; i++){
				sum += a[i] * index * Math.pow(x[m], index - 1);
				min[m] = sum;
				index--;
			}
		}
		
		double mintemp = min[0];
		for(int i = 0; i < 3; i++){
			if(min[i] < mintemp)
				mintemp = min[i];
		}
		
		ps.printf("%.2f%n", mintemp);
		/*
		double x = sc.nextDouble();
		double y = sc.nextDouble();
		double p = Math.pow(x, y);
		ps.printf("pow(%f, %f) = %f%n", x, y, p);
		*/
		ps.close();
		sc.close();
		
		
	}
}