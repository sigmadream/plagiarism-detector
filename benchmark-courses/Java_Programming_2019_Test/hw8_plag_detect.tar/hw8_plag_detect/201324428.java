import java.util.Scanner;
import java.io.PrintStream;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int degree = 0;
		double[] coefficient = null;
		degree = sc.nextInt();
		coefficient = new double[degree + 1];
		
		for(int i=degree; i>=0; --i)
		{
			coefficient[i] = sc.nextDouble();
		}
		
		double[] total_result = new double[3];
		for(int i=0; i<3; i++)
		{
			
			double sum_of_product = 0;
			double x = sc.nextDouble();
			
			for(int j=1; j<=degree; j++)
			{
				double dy = coefficient[j] * j * (Math.pow(x, j-1));
				sum_of_product += dy;
			}
			total_result[i] = sum_of_product;
		}
		
		
		double Minimun = total_result[0];
		for(int i=0; i<3; i++)
		{
			if(Minimun > total_result[i])
				Minimun = total_result[i];
		}
		
		ps.printf("%.2f\n", Minimun);
		sc.close();
	}
}
