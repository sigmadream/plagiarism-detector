import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class hw4 {
	public static void main(String[] args) {
		double retNum = 1e9;
		ArrayList<Double> arr = new ArrayList<>();
		ArrayList<Double> val = new ArrayList<>();
		PrintStream ps = System.out;
		
		inputProc(arr, val);

		for(double it : val)
			retNum = Math.min(retNum, calDeri(arr, it));
		ps.printf("%.2f",retNum);
		
	}

	private static void inputProc(ArrayList<Double> arr, ArrayList<Double> val) {
		Scanner sc = new Scanner(System.in);
		int topNum = sc.nextInt();
		for(int i = topNum ; i >= 0 ; --i)
			arr.add(i*sc.nextDouble());
		for(int i = 0 ; i < 3 ; ++i)
			val.add(sc.nextDouble());
		arr.remove(arr.size()-1);
		sc.close();
	}

	private static double calDeri(ArrayList<Double> arr, double var) {
		int top = arr.size()-1;
		double retNum = 0;

		for(double it : arr) 
			retNum += it*Math.pow(var, top--);

		return retNum;
	}

}
