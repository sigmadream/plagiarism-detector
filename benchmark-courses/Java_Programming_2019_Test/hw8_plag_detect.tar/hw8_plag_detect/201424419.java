import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Derivative {

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int n = sc.nextInt();
		ArrayList<Double> func = new ArrayList<>();
		ArrayList<Double> input = new ArrayList<>();
		for (int i = 0; i < n + 1; i++) {
			func.add(sc.nextDouble());
		}
		for (int i = 0; i < 3; i++) {
			input.add(sc.nextDouble());
		}
		ArrayList<Double> derfunc = new ArrayList<>();
		ArrayList<Double> output = new ArrayList<>();
		//derivative
		for(int i = 0; i < func.size()-1; i++){
			derfunc.add(func.get(i)*(func.size()-1-i));
		}
		
//		System.out.println(func);
//		System.out.println(input);
//		System.out.println(derfunc);
				
		
		double sum = 0.0;
		for(int i = 0 ; i< 3; i++){
			for(int j = 0 ; j < derfunc.size();j++){
				sum+= derfunc.get(j)*Math.pow(input.get(i), n-1-j);
			}
			output.add(sum);
			sum = 0.0;
		}
//		System.out.println(output);
		
		double min=2222222222222222.0;
		for(int i = 0 ; i < output.size();i++){
			if(output.get(i)<min){
				min = output.get(i);
			}
		}
		ps.printf("%.2f", min);

		ps.close();
		sc.close();
	}

}