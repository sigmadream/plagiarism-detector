import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int P  = sc.nextInt();
		ArrayList<Double> a = new ArrayList<Double>();
		ArrayList<Double> b = new ArrayList<Double>();
		ArrayList<Double> c = new ArrayList<Double>();

		double tmp = 0.0;
		for(int i = 0; i < P+1; i++) {
			tmp = sc.nextDouble();
			a.add(tmp);	
		}

		for(int i = 0; i < 3; i++) {
			tmp = sc.nextDouble();
			b.add(tmp);
		}
		
		for(int i = 0; i < 3; i++) {
			double s = 0.0;
			for(int j = 0; j < P; j++) {
				s += (P-j) * a.get(j)*Math.pow(b.get(i), P-j-1);
			}
			c.add(s);
		}
		
		double d = c.get(0);
		for(int i = 0; i < 3; i++) {
			if(d > c.get(i)) {
				d = c.get(i);
			}
		}
		
		ps.printf("%.2f", d);

		sc.close();
	}
}