 import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

 public class lav444{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		//ps.print("Enter two floating point numbers: ");
		int size = sc.nextInt();
		double coe[] = new double[size+1];
		int valcount=3;
		double val[] = new double[valcount];
			
		for (int i=0;i<size+1;i++)
			coe[i]= sc.nextDouble();
		
		for (int i=0;i<valcount;i++) {
			val[i]= sc.nextDouble();
		}
		double result[] = new double[valcount];
		
		for(int j=0; j<valcount; j++) {
			for (int i=0;i<size;i++) {
				result[j] += (double)(size-i)*coe[i]*Math.pow(val[j], (double)(size-i-1));
			}
		}
		Arrays.sort(result);
		ps.printf("%.2f%n",result[0]);
		sc.close();
 	}
 }