import java.io.PrintStream;
import java.util.Scanner;

public class Derivative {
	
	public static double min(double a, double b){
		if(a > b)
			return b;
		else
			return a;
	}
	
	public static double cal(double[] x,double[] y, int n){
		double result = 0.0;
		double compare = 0.0;
		for(int j = 0; j < 3; j++){
			for(int i =n; i != 0; i--)
				result += i*x[n-i] * Math.pow(y[j], i-1); 
			if(j == 0) compare = result;
			else compare = min(compare, result);
			result = 0;
		}
		
		return compare;
	}
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int n = sc.nextInt();
		double p = 0.0;
		double[] x = new double[n + 1];
		double[] y = new double[4];
		
		for(int i = n; i != -1; i--)
			x[n - i] = sc.nextDouble();
		
		for(int j = 0; j < 3; j++)
			y[j] = sc.nextDouble();
		
		p = cal(x, y, n);
		
		ps.printf("%.2f%n", p);
		ps.close();
		sc.close();
	}
}

