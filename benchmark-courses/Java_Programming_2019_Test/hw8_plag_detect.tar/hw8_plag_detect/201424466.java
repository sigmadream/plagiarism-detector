import java.io.PrintStream;
import java.util.Scanner;
 
public class Hw04 {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		double[] coe = new double[10];
		double result=0;
		for(int i=0; i<=n; i++){
			coe[i] = sc.nextDouble();
		}
		double a = sc.nextDouble();
		double b = sc.nextDouble();
		double c = sc.nextDouble();
		double a_val=0, b_val=0, c_val=0;
		for(int i=1; i<=n; i++){
			a_val += (double)coe[n-i]*Math.pow(a, i-1)*i;
		}
		for(int i=0; i<=n; i++){
			b_val += (double)coe[n-i]*Math.pow(b, i-1)*i;
		}
		for(int i=0; i<=n; i++){
			c_val += (double)coe[n-i]*Math.pow(c, i-1)*i;
		}
		
		if(a_val>b_val)
			result = b_val;
		else 
			result= a_val;
		if(result>c_val){
			result = c_val;
		}else{
			
	}
		ps.printf("%.2f", result);
		
		ps.close();
		sc.close();
	}
}
