import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;



public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int n = sc.nextInt();
		ArrayList<Double> Exp = new ArrayList<Double>();
		
		for(int i = 0; i < n+1; i++) {
			Exp.add(sc.nextDouble());
		}
		
		ArrayList<Double> dk = new ArrayList<Double>();
		
		for(int i = 0; i < 3; i++) {
			dk.add(sc.nextDouble());
		}
		
		ArrayList<Double> result = new ArrayList<Double>();
		
		for(int i = 0; i < 3; i++) {
			double Res = 0.0;
			for(int k = 0; k < n; k++) {
				double temp = 0.0;
				double tmp = 0.0;		
				tmp = (n-k) * Math.pow(dk.get(i), n-k-1);
				temp = tmp * Exp.get(k);
				Res += temp;
			}
			result.add(Res);
		}
		
		double comp = result.get(0);
		
		for(int a=1; a < result.size(); a++) {
			if(comp > result.get(a)) {
				comp = result.get(a);
			}
		}
		
		ps.printf("%.2f", comp);
		
		sc.close();
	}
}
