import java.io.PrintStream;
import java.util.Scanner;

public class Derivative {
	public static void main(String arg[]) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n=sc.nextInt();
		double[] coe=new double[100];
		double[] res=new double[3];
		for(int i=n; i>=0; i--) {
			coe[i]=sc.nextDouble();
		}
		for(int i=0; i<3; i++) {
			double d=sc.nextDouble();
			double sum=0;
			for(int j=1; j<=n; j++) {
				sum+=j*coe[j]*Math.pow(d,j-1);
			}
			res[i]=sum;
		}
		double p=res[0];
		for(int i=1; i<3; i++) {
			if(res[i]<p)
				p=res[i];
		}
		ps.printf("%.2f", p);
		
		sc.close();
		}
		
	
}