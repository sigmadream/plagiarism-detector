import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintStream;

public class ccc {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int n = sc.nextInt();
		int n1 = n+1;


		double [] co = new double [100];

		for(int s =0; s<n1; s++)
			co[s] = sc.nextDouble();


		double [] value = new double [co.length];

		for(int j =0; j<3; j++)
			value[j] = sc.nextDouble();

		double [] dk = new double [3];


		for(int i = 0; i < 3; i++) {
			for (int s=0; s<n; s++) {
				dk[i] += (n-s)*co[s]*Math.pow(value[i],n-s-1);
			}
		}

		double a = dk[0];
		for(int i =0; i<3; i++) {
			if (a > dk[i]) {
				a = dk[i];
			}
		}
		
		ps.printf("%.2f",a);
		sc.close();	
	}
}

