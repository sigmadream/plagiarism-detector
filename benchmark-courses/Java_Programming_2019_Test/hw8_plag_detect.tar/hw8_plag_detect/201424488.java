import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class hw4 {

	public static void main(String[] args){
		
		PrintStream ps = System.out;
		Scanner sc = new Scanner(System.in);
		int c = sc.nextInt();
		double a[] = new double[c+1];
		
		for(int i =0;i<=c; i++){
			double n = sc.nextDouble();
			a[i]= n;
		}
		double x = sc.nextDouble();
		double y = sc.nextDouble();
		double z = sc.nextDouble();
		double resultX=0,resultY=0,resultZ=0;
		int k = c;
		for(int i=0;i<c;i++){
			
			resultX += k*a[i]*Math.pow(x, k-1);
			resultY += k*a[i]*Math.pow(y, k-1);
			resultZ += k*a[i]*Math.pow(z, k-1);

			k = k-1;
		}
		double min;
		if(resultX<resultY && resultX<resultZ)
			min = resultX;
		else if(resultY<resultX && resultY<resultZ)
			min = resultY;
		else
			min = resultZ;
		
		ps.printf("%.2f",min);
	}
}
