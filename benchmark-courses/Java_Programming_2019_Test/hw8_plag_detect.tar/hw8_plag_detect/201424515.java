import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Double> c = new ArrayList<>();
		
		//ps.print("Enter two floating point numbers: ");
		double p1 = 0;
		double p2 = 0;
		double p3 = 0;
		double y = sc.nextDouble();
		for(int i=0; i <= y; i++) {
				double a = sc.nextDouble();
				c.add(a);
		}
		double d1 = sc.nextDouble();
		double d2 = sc.nextDouble();
		double d3 = sc.nextDouble();
		int z = (int)y;
		for(int i=0; i < y; i++) {
			z--;
			p1 += (i+1)*c.get(z)*Math.pow(d1, i);
			p2 += (i+1)*c.get(z)*Math.pow(d2, i);
			p3 += (i+1)*c.get(z)*Math.pow(d3, i);
		}
		
		if(p1>p2) {
			if(p2>p3) {
				ps.printf("%.2f", p3);
			}
			else {
				ps.printf("%.2f", p2);
			}
		}
		else {
			if(p1>p3) {
				ps.printf("%.2f", p3);
			}
			else {
				ps.printf("%.2f", p1);
			}
		}
			
		sc.close();
	}
}