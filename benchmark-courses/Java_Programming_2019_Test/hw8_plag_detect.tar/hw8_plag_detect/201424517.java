import java.io.PrintStream;
import java.util.Scanner;

public class DerivateVal {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int exp = sc.nextInt();
		double[] coef = new double[exp+1];
		
		for(int i = 0;i<exp+1;i++)
			coef[i] = sc.nextDouble();
		double[] kvalue = new double[3];
		
		for(int i = 0;i<3;i++)
			kvalue[i] = sc.nextDouble();
		double[] dercoef = new double[exp];
		int tmp = exp;
		for(int i = 0;i<tmp;i++) {
			dercoef[i] = exp--*coef[i];
			
		}
		exp = tmp;
		
		double[] Derval = new double[3];
		for(int i = 0;i<3;i++) {
			int derexp = exp-1;
			for(int j = 0;j<tmp;j++) {
							
				Derval[i] += dercoef[j]*Math.pow(kvalue[i],derexp--);
			}
			
			
		}
		double min = Derval[0];
		for(int i = 1;i<3;i++) {
			if(min>Derval[i])
				min = Derval[i];
		}
		ps.printf("%.2f",min);
			
			
		
		sc.close();
		
	}

}
