import java.io.PrintStream;
import java.util.Scanner;

public class HW4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		double coe[]= new double [(n+1)] ;
		for(int i=0; i<=n; i++){
			coe[i]= sc.nextDouble();
		}
		double val[] = new double[3];
		for(int i= 0; i<3 ; i++){
			val[i]=sc.nextDouble();
		}
		
		double FuncVal [] = new double[3];
		
		for(int i =0; i< val.length; i++){
			for(int k=0; k < coe.length-1; k++){
				FuncVal[i] += (n-k)*coe[k] * Math.pow(val[i], (double)(n-k-1));
				
			}
		}
		double comp =FuncVal[0];
		
		for(int i=1;i<FuncVal.length; i++){
			if(comp>FuncVal[i])
				comp=FuncVal[i];
		}		
		
		ps.printf("%.2f",comp);
		sc.close();
	}
}