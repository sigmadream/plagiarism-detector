import java.io.PrintStream;
import java.util.Scanner;

public class poly {

	public static void main(String[] args) {

		
		
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();

		if(n==0){
			double zero =0;
			double d1 = sc.nextDouble();
			d1 = sc.nextDouble();
			d1 = sc.nextDouble();
			d1 = sc.nextDouble();
			
			ps.printf("%.2f%n",zero);
		}
		double c[] = new double[n+1];
		for (int i=0; i<=n ; i++){
			c[i] = sc.nextDouble();
		}
		double c2[]= new double [n+1];
		for (int i=0; i<n;i++){
			c2[i]=c[i]*(n-i);
		}

		double p1=0, p2=0, p3=0, minp=0;

		double d1 = sc.nextDouble();
		double d2 = sc.nextDouble();
		double d3 = sc.nextDouble();
		
		for (int i=0; i<n-1 ; i++){
		p1 += c2[i]*Math.pow(d1,(n-i-1));}
		for (int i=0; i<n-1 ; i++){
		p2 += c2[i]*Math.pow(d2,(n-i-1));}
		for (int i=0; i<n-1 ; i++){
		p3 += c2[i]*Math.pow(d3,(n-i-1));}
		
		p1 += c2[n-1];
		p2 += c2[n-1];
		p3 += c2[n-1];

		if (p1<p2){
			if(p1<p3){
				minp=p1;
			}
			else{
				minp=p3;
			}
		}
		else if(p2<p3){
			minp= p2; 
		}
		else minp=p3;
		
		ps.printf("%.2f%n",minp );
		sc.close();
		
	}

}
