import java.io.PrintStream;
import java.util.Scanner;

public class Derivative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		double[] c = new double[n + 1];
		double[] d = new double[3];

		double[] function = new double[3];
		double[] derivative = new double[3];
		double fx = 0;
		double dx = 0;
		
		
		for(int i = 0; i < n + 1; i++){
			c[i] = sc.nextDouble();
		}
		for(int i = 0; i < 3; i++){
			fx = 0;
			dx = 0;
			d[i] = sc.nextDouble();
			for(int j = 0; j < n + 1; j++)
				fx = fx + c[j] * Math.pow(d[i], n-j);
			function[i] = fx;
			for(int j = 0; j < n; j++){
				dx = dx + c[j] * (n-j) * Math.pow(d[i], n-j-1);
			}
			derivative[i] = dx;
			
		}	 
		
		
		if(derivative[0] < derivative[1]){
			if(derivative[0] < derivative[2]){
				ps.printf("%.2f\n",derivative[0]);
			}
			else{
				ps.printf("%.2f\n",derivative[2]);
			}
		}
		else if(derivative[0] > derivative[1]){
			if(derivative[1] > derivative[2]){
				ps.printf("%.2f\n",derivative[2]);
			}
			else{
				ps.printf("%.2f\n",derivative[1]);
			}
		}
	}
}