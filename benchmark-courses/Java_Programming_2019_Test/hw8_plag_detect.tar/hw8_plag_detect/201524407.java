import java.io.PrintStream;
import java.util.Scanner;

public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n= sc.nextInt();
		
		double[] coef = new double[n+1];
		for(int i=0; i<n+1; i++)
			coef[i]=sc.nextDouble();
	
		double[] der_coef = new double[n];
		for(int i=0,k=n; i<n; i++,k--)
			der_coef[i]=(double)coef[i]*k;
		
		double[] d_val = new double[3];
		for(int i=0; i<3; i++) {
			double d = sc.nextDouble();
			double sum=0;
			for(int j=0,k=n-1; j<n; j++,k--) {
				sum += der_coef[j]*Math.pow(d,k);
			}
			d_val[i]=sum;
		}
		
		double min = d_val[0];
		for(int i=0; i<3; i++)
			if(d_val[i]<=min) min=d_val[i];
		ps.printf("%.2f",min);
		
		sc.close();
	}
}
