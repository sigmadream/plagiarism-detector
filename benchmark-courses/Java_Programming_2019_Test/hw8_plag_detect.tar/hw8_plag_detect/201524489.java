import java.io.PrintStream;
import java.util.Scanner;

public class polynomial {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		double [] a = new double[n+1];
		double [] b = new double[3];
		
		for(int i=0;i<n+1;i++) {
			a[i]=sc.nextDouble();
		}
		
		for(int i=0;i<3;i++) {
			b[i]=sc.nextDouble();
		}
		
		double [] c = new double[3];
		double sum=0;
		double k=n;
		
	
		for(int i=0;i<3;i++) {
			k=n;
			sum=0;
			for(int j=0;j<n+1;j++) {
				if(k!=0)
				sum=sum+a[j]*k*Math.pow(b[i],k-1);
				--k;
					
			}
			c[i]=sum;

		}
		
		double temp;
		for(int i=0;i<3;i++) {
			for(int j=i+1;j<3;j++) {
				if(c[i]<c[j])
					c[i]=c[i];
				else if(c[i]>c[j]) {
					temp=c[i];
					c[i] = c[j];
					c[j] = temp;
				}
			}
		}
		ps.printf("%.2f",c[0]);
		sc.close();
	}

}
