import java.io.PrintStream;
import java.util.Scanner;

public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		double [] Coeff = new double[n+1];
		double [] Subs = new double[3];
		double [] Value = new double[3];
		for(int i=0;i<n+1;i++)
			Coeff[i]=sc.nextDouble();
		for(int i=0;i<3;i++) 
			Subs[i]=sc.nextDouble();
		
		for(int i=0;i<3;i++) {
			int k=0;
			double sum=0;
			for(int j=n;j>0;j--) {
				sum=sum+Coeff[k]*j*Math.pow(Subs[i],j-1);
				k++;
			}
			Value[i]=sum;
		}
/*		for (int i=0;i<3;i++)
		{
			ps.printf("%.2f ",Value[i]);
		}*/
		double temp;
		for(int i=0;i<3;i++) {
			for(int j=i+1;j<3;j++) {
				if(Value[i]<Value[j])
					Value[i]=Value[i];
				else if(Value[i]>Value[j]) {
					temp=Value[i];
					Value[i] = Value[j];
					Value[j] = temp;
				}
			}
		}
		ps.printf("%.2f",Value[0]);
		sc.close();
		
	}
}
