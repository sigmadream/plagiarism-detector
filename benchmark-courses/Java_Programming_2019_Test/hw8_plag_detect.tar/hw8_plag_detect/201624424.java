import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class hw04 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Double> al=new ArrayList<>();
		ArrayList<Double> bl=new ArrayList<>();
		ArrayList<Double> cl=new ArrayList<>();
		int n=sc.nextInt();
		for(int i=0;i<n+1;i++)
			al.add(sc.nextDouble());
		for(int j=0;j<3;j++)
			bl.add(sc.nextDouble());
		for(int k=0;k<3;k++){
			double ans=0;
			for(int l=0;l<n;l++){
				ans+=(al.get(l))*(n-l)*Math.pow((bl.get(k)), n-l-1);
			}
			cl.add(ans);
		}
		if(cl.get(0)>cl.get(1)){
			if(cl.get(1)>cl.get(2)){
				ps.printf("%.2f",cl.get(2));
			}
			else{
				ps.printf("%.2f",cl.get(1));
			}
		}
		else{
			if(cl.get(0)>cl.get(2)){
				ps.printf("%.2f", cl.get(2));
			}
			else{
				ps.printf("%.2f", cl.get(0));
			}
		}
		sc.close();
	}
}
