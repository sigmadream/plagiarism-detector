import java.io.PrintStream;
import java.util.Scanner;

public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n=sc.nextInt();
		double[] arr= new double[100];
		double[] pol = new double[3];
		for(int i=n; i>=0; i--) {
			arr[i]=sc.nextDouble();
		}
		for(int i=0; i<3; i++) {
			double d=sc.nextDouble();
			double sum=0;
			for(int j=1; j<=n; j++) {
				sum+=arr[j]*j*Math.pow(d,(j-1));
			}
			pol[i]=sum;
		}
		double p=pol[0];
		for(int i=1; i<3; i++) {
			if (pol[i]<p) p=pol[i];
		}
		ps.printf("%.2f", p);
		sc.close();
	}
}
