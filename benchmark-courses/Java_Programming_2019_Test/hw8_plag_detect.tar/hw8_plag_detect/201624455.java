import java.io.PrintStream;
import java.util.Scanner;

public class hw4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int c = sc.nextInt();
		double a[] = new double[c+1];
		for(int i = 0; i<=c; i++) {
			double n = sc.nextDouble();
			a[i] = n;
		}
		double x = sc.nextDouble();
		double y = sc.nextDouble();
		double z = sc.nextDouble();
		double f1=0, f2=0, f3=0;
		int k = c;
		for(int i=0; i<c; i++) {
			
			f1 += k*a[i]*Math.pow(x, k-1);
			f2 += k*a[i]*Math.pow(y, k-1);
			f3 += k*a[i]*Math.pow(z, k-1);
			
			k = k-1;
		}
		double min;
		if(f1<f2 && f1<f3)
			min = f1;
		else if (f2<f1 && f2<f3)
			min = f2;
		else
			min = f3;
		ps.printf("%.2f", min);
		sc.close();
	}

}
