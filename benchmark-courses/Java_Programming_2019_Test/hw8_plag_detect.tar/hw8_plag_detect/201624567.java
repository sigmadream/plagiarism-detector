import java.io.PrintStream;
import java.util.Scanner;

public class Derivative {
	public static void main(String args[]) {
			Scanner sc = new Scanner(System.in);
			PrintStream ps = System.out;
			
			int n = sc.nextInt();
			double[] ans = new double[3];
			double[] c = new double[100];
			for(int i = 0; i < n+1; i++) {
				c[i] = sc.nextDouble();
			}
			double[] d = new double[3];
			
			for(int i = 0 ; i < 3; i++) {
				d[i] = sc.nextDouble();
			}
			
			
			
			for(int j = 0; j < 3; j++) {
				int k = n;
				for(int i = 0; i < n; i++) {
					ans[j] += c[i]*k*Math.pow(d[j], k-1);
					k--;
				}
			}
			double anss = ans[0];
			for(int i = 1; i< 3; i++) {
				if(ans[i]<anss) {
					anss = ans[i];
				}
			}
			
			ps.printf("%.2f", anss);

			
			ps.close();
			sc.close();
			
		
	}

}
