import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int n = sc.nextInt();
		double d1 = 0.0;
		double d2 = 0.0;
		double d3 = 0.0;
		double min1;
		double min2;
		double min3;
		double min4;
		double min5;
		int count = 0;
		double doumean = (double) n;
		double a1 = 0.0;
		double a2 = 0.0;
		double a3 = 0.0;
		double b1 = 0.0;
		double b2 = 0.0;
		double b3 = 0.0;
		do {
			if (n > 0 && n < 100) {
				ArrayList<Double> coefficinents = new ArrayList<Double>();
				while (sc.hasNextDouble()) {
					coefficinents.add(sc.nextDouble());
					if (coefficinents.size() <= n)
						continue;
					else
						break;
				}
				ArrayList<Double> values = new ArrayList<Double>();
				while (sc.hasNextDouble()) {
					values.add(sc.nextDouble());
					if (values.size() <= 2)
						continue;
					else
						break;
				}

				for (int i = 0; i < n; i++) {
					d1 += coefficinents.get(i) * (doumean - b1) * Math.pow(values.get(0), (doumean - 1.0 - a1));
					a1 += 1.0;
					b1 += 1.0;

				}

				for (int j = 0; j < n; j++) {
					d2 += coefficinents.get(j) * (doumean - b2) * Math.pow(values.get(1), (doumean -1.0 - a2));
					a2 += 1.0;
					b2 += 1.0;
				}
				
				for (int k = 0; k < n; k++) {
					d3 += coefficinents.get(k) * (doumean - b3) * Math.pow(values.get(2), (doumean - 1.0 - a3));
					a3 += 1.0;
					b3 += 1.0;
				}

				min1 = Math.min(d1, d2);
				min2 = Math.min(d1, d3);
				min3 = Math.min(d2, d3);

				min4 = Math.min(min1, min2);
				min5 = Math.min(min3,  min4);
				ps.printf("%.2f", min5);
				count++;
			}
				else
					break;
				
		} while(count < 1);
		ps.close();
		sc.close();
	}
}
