import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Double> al = new ArrayList<>();
		ArrayList<Double> del= new ArrayList<>();
        double[] array=new double[20];
        double[] array2=new double[20];

//		ps.println("Enter the order");
		int order = sc.nextInt();        
        
 //       ps.println("Enter coefficients");
		for (int i = 0; i <= order; i++)
	    {
			array[i]=sc.nextDouble();
	    }
//		System.out.println(Arrays.toString(array));
		
		//ps.println("Enter the value of x");
		//int j=0;
		//for (j = 0; j<=order; j++)
		//{
		//	array2[j]=sc.nextDouble();
		//}
		
//		ps.println("Enter the XVALUES");
		ArrayList<Double> xvalues = xvalues(sc);
		//while (sc.hasNextDouble()) {
		//	double n = sc.nextDouble();
		////	array2[j++] = n;
		//	}
		
//	   System.out.println(Arrays.toString(array2));
       int j=0;
       double polySum = array[0];	
	   while (j<order) {
		 polySum = array[0];
		 for (int i = 1; i <= order;i++) {
	       polySum = polySum * xvalues.get(j) + array[i]; 
		 }
		 al.add(polySum);
		 j++;
	  } 

       
		String line = al.toString();
//		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
         
//		ps.println("WWS");
        
	       j=0;
	       double polySum2 = array[0];	
		   while (j<xvalues.size()) {
			 polySum2 = 0;
			 for (int i = 1; i <= order;i++) {
		       polySum2+=order*array[i]*polySum2*Math.pow(xvalues.get(j), order-i);
		      // polySum2 += order* i*array[i]* Math.pow(xvalues.get(j), order-i);
			   // polySum2+=order*array[i]*Math.pow(xvalues.get(j), order-i);
			 }
			 del.add(polySum2);
			 j++;
			 
			 
			 
		 
		String line2 = del.toString();
	 //   ps.print(line2.replaceAll("^.|.$", "").replace(", ", " "));
	 //   ps.println("YESSSS\n");

	    String line3 = xvalues.toString();
	//    ps.print(line3.replaceAll("^.|.$", "").replace(", ", " "));


//	   ps.println("Arman");

	   double min = del.get(0);
	   double max = del.get(0);

	   for(Double i: del) {
	       if(i < min) min = i;
	       if(i > max) max = i;
	   }

	   ps.printf("%.2f%n" ,min);
		   }
}



private static ArrayList<Double> xvalues(Scanner sc) {
	ArrayList<Double> xvalues = new ArrayList<Double>();
	for (int i=0; sc.hasNextDouble(); i++) {
		double n = sc.nextDouble();
		xvalues.add(n);
	}
	return xvalues;
}
}
