import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
//import java.lang.*;

public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int oop = sc.nextInt();
		double sum1 = 0.0;
		double sum2 = 0.0;
		double sum3 = 0.0;
		double j = (double) oop;
		double c = 0.0;
		double a = j - 1.0;
		double b = 0.0;
		double v = 0.0;
		double w = 0.0;
		double e = 0.0;
		double x = 0.0;
		double f;
		double g;
		double k;
		/*
		 * double[] a = new double[oop]; for (int i = 0; i<=oop; i++) a[i]=
		 * sc.nextDouble(); ps.println(a);
		 */
		for(int d = 0; d < 1; d++) {
			if (oop > 0 && oop < 100) {
				ArrayList<Double> cop = new ArrayList<Double>();
				while (sc.hasNextDouble()) {
					cop.add(sc.nextDouble());
					if (cop.size() <= oop)
						continue;
					else
						break;
				}
				ArrayList<Double> mop = new ArrayList<Double>();
				while (sc.hasNextDouble()) {
					mop.add(sc.nextDouble());
					if (mop.size() <= 2)
						continue;
					else
						break;
				}
				// ArrayList<Double> dop = new ArrayList<Double>();
				for (int m = 0; m < oop; m++) {
					f = a - c;
					sum1 += cop.get(m) * (j - b) * Math.pow(mop.get(0), f);
					c = c + 1.0;
					b = b + 1.0;

				}
				
				for (int n = 0; n < oop; n++) {
					g = a - v;
					
					sum2 += cop.get(n) * (j - e) * Math.pow(mop.get(1), g);
					v = v + 1.0;
					e = e + 1.0;
				}
				for (int i = 0; i < oop; i++) {
					k = a - w;
					sum3 += cop.get(i) * (j - x) * Math.pow(mop.get(2), k);
					w = w + 1.0;
					x = x + 1.0;
				}
				
				
				if (sum1 < sum2 && sum1 < sum3)
					ps.printf("%.2f", sum1);
				if (sum2 < sum1 && sum2 < sum3)
					ps.printf("%.2f", sum2);
				if (sum3 < sum1 && sum3 < sum2)
					ps.printf("%.2f", sum3);
				
			}
			else
				break;
		}

		ps.close();
		sc.close();
	}

}
