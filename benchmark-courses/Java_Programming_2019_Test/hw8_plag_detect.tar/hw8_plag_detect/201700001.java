import java.util.*;
import java.io.PrintStream;

public class Derivative {
	public static void main(String[] args){

		ArrayList<Double> coef = new ArrayList<Double>();
		ArrayList<Double> values = new ArrayList<Double>();
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		double DMin;

		getEquation(sc,coef);
		getValues(sc,values);
		sc.close();

		DMin = getDMin(coef, values);
		ps.printf("%.2f\n", DMin);
	}

	public static void getEquation(Scanner sc,ArrayList<Double> coef){
		int degree;

		degree=sc.nextInt();
		for(int i=0;i<degree+1;++i){
			coef.add(sc.nextDouble());
		}
	}

	public static void getValues(Scanner sc,ArrayList<Double> values){
		while(sc.hasNextDouble()){
			values.add(sc.nextDouble());
		}
	}

	public static double getDMin(ArrayList<Double> coef,ArrayList<Double> values){
		double DMin,DSum=0.0;

		DMin=getEqDSum(coef, values.get(0));
		for(int i=0;i<values.size();++i){
			DSum = getEqDSum(coef,values.get(i));
			if(DMin>DSum){
				DMin=DSum;
			}
		}

		return DMin;
	}

	public static double getEqDSum(ArrayList<Double> coef,double value){
		double DSum=0.0;
		int size = coef.size();

		for(int i=0;i<size-1;++i){
			DSum += (size-i-1)*coef.get(i) * Math.pow(value, size-i-2);
		}

		return DSum;
	}
}
