# -*- coding: utf-8 -*2
from math import *

def main():
    inputNum1 = input()
    inputNum2 = input()
    ns1 = inputNum1.split()
    ns2 = inputNum2.split()
    
    n11 = float(ns1[0])
    n12 = float(ns1[1])
    
    n21 = float(ns2[0])
    n22 = float(ns2[1])

    x1 = pow(n21-n11,2)
    x2 = pow(n22-n12,2)
    x3 = sqrt(x1+x2)

    print(f"{x3:.2f}")

if __name__ == "__main__":
    main()
