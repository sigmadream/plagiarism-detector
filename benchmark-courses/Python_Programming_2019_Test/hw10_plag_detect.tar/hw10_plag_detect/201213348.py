from math import *
import sys
class point:
    def __init__(self,p1,p2):
        self.p1=p1
        self.p2=p2
  
    def dist(self):
        [x1,y1]=self.p1
        [x2,y2]=self.p2
        return math.sqrt(math.pow((x2-x1),2)+math.pow((y2-y1),2))
ls=[]
ls1=[]
n=len(sys.stdin.readlines())
for line in sys.stdin.readlines():
    for p in range(n):
        ls[p]=line.split()

for p in range(n):
    for k in range(p,n+1):
        pt=point(ls[p],ls[k])
        ls1[p]=pt.dist()
        
M=max(ls1)

print(f"({M:.2f})")

