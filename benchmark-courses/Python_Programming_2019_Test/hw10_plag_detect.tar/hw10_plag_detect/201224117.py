##문제 = 임의의 함수를 x y 이렇게 스페이스 구분해서 여러개 입력하고
##그 중 가장 떨어져 있는 거리를 계산하는 문제.
## point 클래스와 dist 메쏘드를 만들어 쓰도록 하자.
from math import *
import sys

class point:
    def __init__(self, p):
##        ps=p.split()
##        p1=float(ps[0])
##        p2=float(ps[1])
##        pos=sqrt(p1*p1+p2*p2)
        self.elems=p
    def dist(self):
        result=max(pos)-min(pos)
        return result

if __name__ =='__main__':
    for line in sys.stdin.readlines(): # Use sys.stdin in IDLE
        linea=line.split()
        p1=float(linea[0])
        p2=float(linea[1])
        pos=sqrt(p1*p1+p2*p2)
        if line.strip() == "": break
    point.dist(pos)
