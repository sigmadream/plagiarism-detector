from math import *

def main():
line = "2 3.0"
ns = line.split()
n1 = float(ns[0])
n2 = float(ns[1])
x1 = sqrt(n1)
x2 = sqrt(n2)
print(f"({x1:.4f},{x2:.4f})")

if __name__ == "__main__":
main()
