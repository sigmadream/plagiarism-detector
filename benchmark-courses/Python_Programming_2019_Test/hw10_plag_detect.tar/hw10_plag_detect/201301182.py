from math import *
import sys

class Point:
    def __init__(self, x, y):
        self.x=x
        self.y=y
    def dist(self, p):
        dis=sqrt((self.x-p.x)**2+(self.y-p.y)**2)
        return dis

total=0
maX=0
q=Point(0, 0)
for line in sys.stdin.readlines():
    if line.strip()=="": break
    ns=line.split()
    p=Point(float(ns[0]), float(ns[1]))
    if total>0:
        if maX<p.dist(q):
            maX=p.dist(q)
    q=p
    total+=1

print(f"{maX:.2f}")
