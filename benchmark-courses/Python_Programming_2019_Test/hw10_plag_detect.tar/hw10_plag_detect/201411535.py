from math import *
import sys

class Point:

    def __init__(self,f1,f2):
        self.point = (f1,f2)

    def dist(self,point):
        re = sqrt((self.point[0]-point.point[0])**2 + (self.point[1]-point.point[1])**2)
        return re

def main():
    ls = list()
    for line in sys.stdin.readlines(): # Use sys.stdin in IDLE
        if line.strip() == "": break
        line = line.split()
        point = Point(float(line[0]),float(line[1]))
        ls.append(point)
    re = list()
    for i in range(len(ls)-1):
        re.append(ls[i].dist(ls[i+1]))
    print(round(max(re),2))

if __name__== "__main__":
    main()

