from math import *
import sys

class Point():
    def __init__(self,p):
        
        self.x = float(p.split()[0])
        self.y = float(p.split()[1])

    def dist(self, P):
        dist = sqrt((self.x - P.x)**2 + (self.y - P.y)**2)

        return dist


def main():
    pl = []
    max_d = -1
    for p in sys.stdin.readlines():
        if p.strip() == "":break

        
        new_p = Point(p)
        pl.append(new_p)

    
    pl_len = len(pl)
    if pl_len > 1:
        for i in range(pl_len-1):
            d = pl[i].dist(pl[i+1])
            
            if d > max_d:
                max_d = d
                
        
    print(f"{max_d:.2f}")
        
        
        
        
    

if __name__ == "__main__":
    main()
    
               
