from math import *
import sys

class Point:
    def __init__(self,coor):
        self.x = float(coor[0])
        self.y = float(coor[1])
 
    def dist(self, p):
        x2 = p.x
        y2 = p.y
        dx=x2-self.x
        dy=y2-self.y
        return sqrt((dx*dx)+(dy*dy))


ls=[]
for line in sys.stdin.readlines():
    if line.strip() == "": break
    ls.append(line)

a=0

for i in range(len(ls)-1):
    p0=Point(ls[i].split())
    p1=Point(ls[i+1].split())
    l=p0.dist(p1)
    if a<l:
        a=l
    
print(round(a,2))
