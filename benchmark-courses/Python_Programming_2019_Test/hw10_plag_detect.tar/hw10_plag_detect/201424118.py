from math import *

def main():
    line = "2 3.0"
    ns = line.split()
    n1 = float(ns[0])
    n2 = float(ns[1])
    x1 = sqrt(n1)
    x2 = sqrt(n2)
    print(f"({x1:.4f},{x2:.4f})")
    print(ns)
    print(n1)
    print(n2)
    



def aaa():
    line0 = input()
    line1 = input()
    line2 = input()
    bs = line0.split()
    x0 = float(bs[0])
    y0 = float(bs[1])
    cs = line1.split()
    x1 = float(cs[0])
    y1 = float(cs[1])

    cs2 = line2.split()
    x2 = float(cs2[0])
    y2 = float(cs2[1])

    a = sqrt((x0-x1)**2 + (y0-y1)**2)
    b = sqrt((x2-x1)**2 + (y2-y1)**2)
    if a>b:
        print(f"{a:.2f}")
    else:
        print(f"{b:.2f}")
    
    
    
            

    
if __name__ == "__main__":
    aaa()
