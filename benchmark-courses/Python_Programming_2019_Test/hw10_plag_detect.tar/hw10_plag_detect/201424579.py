from math import *
import sys

class Point:
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def dist(self,x1,x2):
        return sqrt(((x2.x-x1.x)*(x2.x-x1.x))+((x2.y-x1.y)*(x2.y-x1.y)))
        

def main():
    
    input_number = sys.stdin.readline()
    parse_number = input_number.split()
    t = Point(x=float(parse_number[0]),y=float(parse_number[1]))
              
    input_number1 = sys.stdin.readline()
    parse_number1 = input_number1.split()
    tt = Point(x=float(parse_number1[0]),y=float(parse_number1[1]))
    
    print(f"{Point.dist(1,t,tt):.2f}")       
    
    
if __name__=="__main__":
    main()


