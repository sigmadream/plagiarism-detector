from math import *
import sys
import numpy as np
from functools import reduce

def main():
    line = sys.stdin.read()
    ns = line.split()
    ns = list(map(float,ns))
    ns = np.reshape(ns,(-1,2))
    
   # print(ns)
    ns2 = []
    for i in range (0,len(ns)):
        if i == len(ns)-1:
            break
        ns2.append(sqrt(((abs(float(ns[i+1][0])-float(ns[i][0]))**2))+((abs(float(ns[i+1][1])-float(ns[i][1]))**2))))
    #print(ns2)
    return max(ns2)
#    print(f"({x1:.4f},{x2:.4f})")

m = main()
print(f"{m:.2f}")
