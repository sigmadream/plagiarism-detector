

class Point:
    
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def dist(self, p):
        return ((p.x-self.x)**2 + (p.y-self.y)**2)**0.5


def main():
    p1 = []
    while True:
        line=input()
        if line == "":
            break
        f1 = line.split()
        p1.append(Point(eval(f1[0]), eval(f1[1])))

    result = 0

    for i in range(len(p1)-1):
        distance = p1[i].dist(p1[i+1])
        result = distance
        
    print("%.2f" % result)
        
        
        


if __name__ == "__main__":
    main()
