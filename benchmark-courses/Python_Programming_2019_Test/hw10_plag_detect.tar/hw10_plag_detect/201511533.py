from math import *
import sys

def main(line):
    ns = line.split()
    n1 = float(ns[0])
    n2 = float(ns[1])
    return (n1,n2)
    
class Point:
    def __init__(self,x1,x2):
        self.x1 = x1
        self.x2 = x2
    def dist(self,p):
        return sqrt((self.x1-p.x1)**2+(self.x2-p.x2)**2)

if __name__ == "__main__":
    dst = []
    line = sys.stdin.readline()
    ns = main(line)
    p1 = Point(ns[0],ns[1])
    for line in sys.stdin.readlines():
        if line.strip() == "" : break
        ns = main(line)
        p2 = Point(ns[0],ns[1])
        dst.append(p1.dist(p2))
        p1 = p2
    print(f"{max(dst):.2f}")

        
        
