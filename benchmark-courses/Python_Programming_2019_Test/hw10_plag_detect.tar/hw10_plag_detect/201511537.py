import sys
from math import *

class Point:
    def __init__(self,values):
        values_ls = values.split()
        self.x = float(values_ls[0])
        self.y = float(values_ls[1])
        self.d = []
    def dist(self, p):
        v = sqrt((self.x-p.x)*(self.x-p.x) + (self.y-p.y)*(self.y-p.y))

        return v
    
#def ():
 #   line1 = sys.stdin.readline()
  #  line2 = sys.stdin.readline()
    
#print(p[0].elems)

if __name__=='__main__':
    total = 0
    i = 0
    p = []
    for line in sys.stdin.readlines():
        if line.strip() == "":break
        m = Point(line)
        p.append(m)    
    num = len(p)
    for i in range(num-1):
        p[i].d=p[i].dist(p[i+1])
     
    maxv = p[0].d
    for i in range(1,len(p)-1):
        if maxv < p[i].d:
            maxv = p[i].d

    print("%.2f"%maxv)
    
    #d=p1.dist(p2)

