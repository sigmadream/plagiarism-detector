from math import *






import sys

def split_two():
    line1 = sys.stdin.readline()
    line2 = sys.stdin.readline()
    num1 = float(line1)
    num2 = float(line2)
    ns=line1.split( )
    ns=line2.split( )
    n1=float(ns[0])
    n2=float(ns[1])
    x1=sqrt(n1)
    x2=sqrt(n2)
    print(f"({x1:.2f},{x2:.2f})")

def main():
    total=0
    for line in sys.stdin.readlines():
        if line1>line2:  
           print(line1)
        else:
           print(line2)


    print(line)

if __name__=="__main__":
     main()
