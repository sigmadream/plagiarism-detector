from math import *

class Point:
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def dist(self, p) :
        dx = self.x - p.x
        dy = self.y - p.y
        s = sqrt(dx**2 + dy**2)
        print(f'({s :.2f})')


if __name__ == "__main__" : 
    p1 = Point(11,11)
    p2 = Point(1,1)

    p1.dist(p2)
