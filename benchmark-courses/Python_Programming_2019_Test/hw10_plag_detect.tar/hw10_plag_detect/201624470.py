from  math import*
import sys

class Point():
    def __init__(self,x,y):
        self.x=x
        self.y=y
    def dist(self,p):
        return sqrt((p.x-self.x)**2+(p.y-self.y)**2)

li=[]
while True:
    inp=sys.stdin.readline()
    if inp.strip() == "":
        break
    a = inp.split()
    p=Point(eval(a[0]), eval(a[1]))
    li.append(p)
maxn = 0
for i in range(len(li)-1):
    dist = li[i].dist(li[i+1])
    if maxn < dist:
        maxn = dist
print("{:.2f}".format(maxn))
