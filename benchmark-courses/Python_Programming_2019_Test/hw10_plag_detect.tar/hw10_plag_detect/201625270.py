from sys import stdin
from math import *

class Point:
    def __init__(self, p):
        self.elems = p
    def dist(p1,p2):
        pi1 = p1.split()
        pi2 = p2.split()
        d1 = pi1[0] - pi2[0]
        d2 = pi1[1] - pi2[1]
        distance = sqrt(d1**2 + d2**2)
        return distance
    def compare(dis1, dis2):
        if dis1 > dis2 :
            return dis1
        else :
            return dis2

if __name__=="__main__":
    lines = stdin.readlines()
    p = Point(lines[i] for i in len(lines))
    print(answer)


#readlines는 Ctrl+D하면 풀림
#dist(self, p)
