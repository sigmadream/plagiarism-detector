import sys
from math import *

#Point:
 #   def __init__():
        
  #  def dist(self,p):
        


if __name__ == "__main__":
    ls = []
    k=0
    temp = 0
    for i in sys.stdin.readlines():
        if i.strip() =="":break
        ls.append(i.split(' '))
        k = k+1
        
    for i in range(k):
        num1 = ls[i]
        for j in range(k-1-i):
            num2 = ls[j+1]
            x1 = float(num1[0])
            y1 = float(num1[1])
            x2 = float(num2[0])
            y2 = float(num2[1])
            temp2 = sqrt((x1-x2)*(x1-x2) + (y1-y2) * (y1-y2))
            if temp2>temp:
                temp = temp2

    print(f"{temp:.2f}")
