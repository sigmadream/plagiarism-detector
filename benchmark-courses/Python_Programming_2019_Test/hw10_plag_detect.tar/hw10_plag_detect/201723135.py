import sys
from math import *

class Point:
    def __init__(self, crdnt_x, crdnt_y):
        self.x = crdnt_x
        self.y = crdnt_y
    def __repr__(self):
        return "({}, {})".format(self.x, self.y)
 
    def dist(self, p):
        d = sqrt((self.x - p.x)**2 + (self.y - p.y)**2)
        return d
    
def main():
    mt = []
    for line in sys.stdin.readlines():
        if line.strip() == "": break
        ls = list(map(float, line.split()))
        mt.append(Point(ls[0], ls[1]))
    ans = []
    l = len(mt) - 1
    for i in range(l):
        ans.append(mt[i].dist(mt[i+1]))
    M = max(ans)
    print(f"{M:.2f}")
    

if __name__ == "__main__":
    main()
