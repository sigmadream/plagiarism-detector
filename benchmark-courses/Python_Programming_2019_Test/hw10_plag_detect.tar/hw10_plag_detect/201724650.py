import sys
from math import sqrt

class point:
    def __init__ (self, x, y):
        self.X = x
        self.Y = y
    def distance(self, other):
        dx = self.X - other.X
        dy = self.Y - other.Y
        return sqrt(dx**2 + dy **2)

def lngstLength(lines) :
    lst = [lines[i] for i in range(len(lines))]
    dstLst = []    
    for i in range(len(lst) - 1) :
        cord1 = lst[i].split()
        cord2 = lst[i + 1].split()
        point1 = point(float(cord1[0]), float(cord1[1]))
        point2 = point(float(cord2[0]), float(cord2[1]))
        dstLst.append(point1.distance(point2))
    dstLst.sort(reverse = True)
    print("%.2f" % dstLst[0])

if __name__ == "__main__" :
    lines = []
    for line in sys.stdin.readlines() :
        if line.strip() == "" : break
        fine  = line.replace("\n", "")
        lines.append(fine)
    
    lngstLength(lines)
