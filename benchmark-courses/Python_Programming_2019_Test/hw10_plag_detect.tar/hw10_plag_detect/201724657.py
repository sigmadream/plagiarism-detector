from math import *


class Point:
    def __init__(self,rows):
        self.elems = rows
    def dist(self):
        i = 0
        a = [[0]*1 for j in range(10)]
    
        while True:
            a[i] = input()
            if(a[i] ==""):
                break
            i = i + 1
        
        b = [[0]*2 for k in range(i)]
        for k in range(i):
            b[k] = a[k].split(' ')
                

        data = [[0]*1 for k in range(len(b)-1)]
        for i in range(len(b)-1):
            dx = (float(b[i][0]) - float(b[i+1][0]))*(float(b[i][0]) - float(b[i+1][0]))
            dy = (float(b[i][1]) - float(b[i+1][1]))*(float(b[i][1]) - float(b[i+1][1]))
            data[i] = sqrt(dx+dy)
        maxValue = float(data[0])
        for j in range(1,len(b)-1):
            if (maxValue < data[j]):
                maxValue = float(data[j])
        print("%.2f"%maxValue)
              
if __name__ == "__main__":
    a = Point([[0]*2 for k in range(10)])
    a.dist()
