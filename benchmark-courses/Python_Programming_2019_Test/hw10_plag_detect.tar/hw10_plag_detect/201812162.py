import sys

class Point:
    def __init__(self,x,y):
        self.x=x
        self.y=y
    def dist(self,p):
        return ((p.x-self.x)**2+(p.y-self.y)**2)**0.5

def main():
    pli=[]
    while True:
        line=sys.stdin.readline()
        if line.strip()=="":
            break
        li=line.split()
        pli.append(Point(eval(li[0]),eval(li[1])))
    mlen=0
    for i in range(len(pli)-1):
        dis=pli[i].dist(pli[i+1])
        mlen=dis if mlen<dis else mlen
    print("%.2f"% mlen)

if __name__=="__main__":
    main()
