from math import *
class Point:
    """ Represents points


    Attributes: x, y
    """
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def distance(self,p):
        leng = sqrt((self.x - p.x)**2 + (self.y - p.y)**2)
        return leng

if __name__ == "__main__":
    num = []
    maxx = Point()
    i = 0
    diff = 0
    
    inp = []
    while True:
        inp.append(input().split())
        if inp[i] == []:
            break
        num.append(Point(float(inp[i][0]), float(inp[i][1])))
        i += 1
    for j in range(len(num) - 1):
        if num[j].distance(num[j+1]) > diff:
            diff = num[j].distance(num[j+1])
    
    print('%.2f' % diff)
    
