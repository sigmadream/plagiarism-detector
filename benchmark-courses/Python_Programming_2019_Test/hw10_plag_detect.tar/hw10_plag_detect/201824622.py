from math import *
import sys

class Point:
    def __init__(self, s):
        self.x=float(s[0])
        self.y=float(s[1])
    def dist(self, p):
        r=sqrt((self.x-p.x)**2+(self.y-p.y)**2)
        return r
    def print_p(self):
        print(self.x, self.y)
    
def main():
    p=[Point("0 0".split())]
    r=[]
    max_r=0
    while True:
        line=sys.stdin.readline()
        if line.strip()== "": 
            break
        else:
            p.append(Point(line.split()))
    for i in range(1,len(p)):
        r.append(p[i].dist(p[i-1]))
        if r[i-1]>max_r:
            max_r=r[i-1]
    print(f"{max_r:.2f}")

main()
