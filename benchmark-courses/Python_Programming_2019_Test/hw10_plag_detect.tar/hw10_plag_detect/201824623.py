from math import *

def main():
    lines = []
    while True:
        line = input()
        if line:
            lines.append(line)
        else:
            break

    str1 = ' '.join(lines)
    ns1 = str1.split()
    ns = [ float(x) for x in ns1 ]
    distance = []
    for i in range(0, len(ns)-2):
        for j in range(i+2, len(ns)-1):
            distance.append(sqrt( ((ns[i]-ns[j])**2)+((ns[i+1]-ns[j+1])**2)))
            j += 2
        i += 2

    print(max(distance))

    
    

if __name__ == "__main__":
    main()

