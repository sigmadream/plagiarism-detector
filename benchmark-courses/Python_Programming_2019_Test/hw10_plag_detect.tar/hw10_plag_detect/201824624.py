import sys
from math import *

class Point():
    def __init__(self, x_coor, y_coor):
        x_coor = x_coor.split()
        y_coor = y_coor.split()
        self.x_coor = x_coor
        self.y_coor = y_coor

    def cal_x(self):
        x_value = pow(float(self.x_coor[0])-float(self.y_coor[0]), 2)
        x_value = float(x_value)
        y_value = pow(float(self.x_coor[1])-float(self.y_coor[1]), 2)
        y_value = float(x_value)
        p = '%.2f'%sqrt(y_value + x_value)
        return p

        
if __name__ == "__main__":
    comparing_list = []
    coordinates = []
    statement = True
    while statement:
        line = input()
        if line:
            coordinates.append(line)
        else:
            statement = False
    new_list = coordinates[:]
    k = -len(coordinates) + 1
    for i in range(len(coordinates)):
        value = Point(coordinates[i], coordinates[k+i])
        comparing_list.append(value.cal_x())
        k += 1
    print(max(comparing_list))
