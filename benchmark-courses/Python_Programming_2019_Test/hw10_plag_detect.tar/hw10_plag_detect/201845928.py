from math import *
import sys

class Point:
    def __init__(self, point):
        self.x1 = float(point[0])
        self.y1 = float(point[1])
    def dist(self, p):
        x2 = p.x1
        y2 = p.y1

        dist_x = (self.x1-x2)**2
        dist_y = (self.y1-y2)**2

        return dist_x+dist_y
##    def __str__(self):
##        return f'{self.x1},{self.y1}'

if __name__ == "__main__":
    points = []
    for line in sys.stdin.readlines():
        if line.strip() == "":break
        points.append(line)

    dist = 0

    for i in range(len(points)-1):
        p0 = Point(points[i].split())
        p = Point(points[i+1].split())
        d = p0.dist(p)
        if (dist<d):
            dist = d

    print(round(sqrt(dist),2))
