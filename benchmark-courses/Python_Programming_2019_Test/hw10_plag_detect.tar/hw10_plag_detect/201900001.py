from math import *
import sys

class Point:
    x = 0.0
    y = 0.0
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def printPnt(self):
        print(self.x,end=", ")
        print(self.y)

    def dist(self, p):
        d = sqrt(pow(p.x-self.x, 2)+pow(p.y-self.y, 2))
        return d

def main():
    points = []
    longest = 0.0
    for line in sys.stdin:
        tmp = line.split()
        pnt = Point(float(tmp[0]),float(tmp[1]))
        points.append(pnt)

    for i in range(0, len(points)-1):
        tmpDist = points[i].dist(points[i+1])
        # points[i].printPnt()
        # points[i+1].printPnt()
        # print("dist: "+str(tmpDist))
        if tmpDist > longest:
            longest = tmpDist

    # print("longest hopping:")
    print(f"{longest:.2f}")
    # print(f"{3.125:.2f}")
if __name__ == '__main__':
    main()
