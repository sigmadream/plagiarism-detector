#-------------------------------------------------------------------------------
# Name:        module1
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import math
import sys

class Point:
    def __init__(self,one,two):
        self.one = one
        self.two = two

    def dist(self,one,two):


        (a,b) = one
        (c,d) = two

        dx = a - c
        dy = b - d

        #print(math.sqrt(dx),dy)
        dout = dx*dx + dy*dy
        return dout

def summ():
    lista = []

    for line in sys.stdin.readlines():
        if line.strip() == "": break

        lista.append(line)

    #print(lista)

listt = []
while(True):
    a = input()
    if a.strip() == "" : break
    listt.append(a)

#print(listt)

listy = []
for i in listt:
    lc = i.split()
    listy.append([float(n) for n in lc])

big = 0

for i in range(len(listy)-1):

    d = Point(listy[i],listy[i+1])
    di = d.dist(listy[i],listy[i+1])
    #print(di)
    if di > big :
        big = di

bigg = math.sqrt(big)
#print( "{:f}".format(bigg))
print( "%.2f"% bigg)








