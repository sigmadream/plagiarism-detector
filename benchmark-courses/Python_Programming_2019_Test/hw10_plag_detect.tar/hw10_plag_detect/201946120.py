from math import *
import sys

class Point:
    def __init__(self, one, two):
        self.one = one
        self.two = two

    def dist(self,one,two):

        (a,b) = one
        (c,d) = two

        dx = a-c
        dy = b-d

        dot = dx**2 + dy**2
        return dot

def mut():
    line1 = sys.stdin.readlines()
    line2 = sys.stdin.readlines()
    line3 = sys.stdin.readlines()
    line4 = sys.stdin.readlines()
    num1 = float(line1)
    num2 = float(line2)
    num3 = float(line3)
    num4 = float(line4)

    
