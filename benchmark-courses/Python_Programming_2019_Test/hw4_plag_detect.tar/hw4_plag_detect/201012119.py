# -*- coding: utf-8 -*2

def printBar(s):
    ls = list(s)
    print(" ".join(ls))

def midPrintBar(s):
    if(len(s) > 1):
        ls = s[1]
        for i in range(1,len(s)-1):
            ls += " "
        ls += s[len(s)-2]
        print(" ".join(ls))

def reverseMidPrintBar(s):
    if(len(s) > 1):
        ls = s[len(s)-2]
        for i in range(1,len(s)-1):
            ls += " "
        ls += s[1]
        if(s[len(s)-2] != s[1]):
            print(" ".join(ls))
    
def reversePrintBar(s):
    if(len(s) > 1):
        ls = list(s)
        ls.reverse()
        print(" ".join(ls))

def main():
    myword = input()
    printBar(myword)
    midPrintBar(myword)
    reverseMidPrintBar(myword)
    reversePrintBar(myword)

if __name__ == "__main__":
    main()

