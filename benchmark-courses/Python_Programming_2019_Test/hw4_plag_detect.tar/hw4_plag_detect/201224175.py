# -*- coding: utf-8 -*-


def rprint(s):
    ls = list(s)
    ls.reverse()
    print("".join(ls))


    def rprint(s):
    print(myword)
    rprint(myword)
    
