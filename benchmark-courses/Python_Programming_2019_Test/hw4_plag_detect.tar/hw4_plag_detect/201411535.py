def one_print(s):
    print(s)

def even_print(s):
    ls = list(s)
    length = len(ls)
    print(" ".join(ls))
    i = 1
    while True:
        print(ls[i] + " "*(length*2-1-2) + ls[length-i-1])
        i += 1
        if i > (length-2):
            break
    ls.reverse()
    print(" ".join(ls))

def odd_print(s):
    ls = list(s)
    length = len(ls)
    print(" ".join(ls))
    i = 1
    while True:
        print(ls[i] + " "*(length*2-1-2) + ls[length-i-1])
        i += 1
        if i > (length-2):
            break
    ls.reverse()
    print(" ".join(ls))    

if __name__=="__main__":
    my_word = input()
    if len(my_word) == 1:
        one_print(my_word)
    if len(my_word)%2 == 1 and len(my_word) != 1:
        odd_print(my_word)
    if len(my_word)%2 == 0:
        even_print(my_word)
