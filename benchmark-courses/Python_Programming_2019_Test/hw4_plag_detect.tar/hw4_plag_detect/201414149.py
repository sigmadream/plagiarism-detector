# -*- coding: utf-8 -*-

def rprint(s):
    ls = list(s)
    ls.reverse()
    print(" ".join(ls))

def print1(s):
    ls = list(s)
    print(" ".join(ls))

def string_middle(str):
    if len(str) % 2: 
        return str[len(str)//2]
    else: 
        return str[(len(str)//2 -1) : len(str)//2+1]



##def vprint(s):
##    ls = list(s)
##    temp = []
##    for i in ls:
##        if i != ' ':
##            temp.append(i)
##    print(len(temp))


    
if __name__ == "__main__":
    myword = input()
    print1(myword)

    
    n = 1
    a = len(myword)
    while a > 0:
         
        print(" ".join(string_middle(myword)))
        n = n + 1
        if(n<len(myword)*2-3): continue
        else: break


        
    rprint(myword)
