# -*- coding: utf-8 -*-

def reverse(s):
    length = len(s)
    for i in range(length):
        re_index = length-(i+1)
        print(s[re_index], end ="")
        if re_index != 0:
            print("", end = " ")
    

def print_str(s):
    length = len(s)
    for i in range(length):
        print(s[i], end = "")
        if i != len(s)-1:
            print(" ", end = "")
    print()

def print_c(s):
    length = len(s)
    for i in range(length):
        if i ==0:
            print_str(s)
        elif i == length-1:
            reverse(s)
        else:

            print(s[i], end = "")
            for j in range(1+length+(length-4)):
                print(" ", end = "")
            print(s[length-(i+1)], end = "")
            print()
            


if __name__ == "__main__":
    s = input()
    if len(s)>0:
        print_c(s)
    
