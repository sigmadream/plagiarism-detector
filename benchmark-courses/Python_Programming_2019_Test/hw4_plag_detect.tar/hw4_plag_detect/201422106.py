def wbox():
    a=str(input())
    b=len(a)
    ls=list(a)
    c=ls.reverse()
    d=" "*(2*b-3)
    for n in range(0,b-1):
            print(a[n],end=" ")
    print(a[b-1])
    for n in range(1,b-1):
            print(a[n],end=d+a[b-n-1])
            print()
    if b!=1:
        print(" ".join(ls))



wbox()

