# -*- coding: utf-8 -*-

def strReverse(s):
    ls = list(s)
    ls.reverse()
    return ls
    
def setPrint(strInput):
    ls = strReverse(strInput)
    i = 0
    j = 0
    
    length = len(strInput)
    while True:
        if length<=i:
            break
        
        if i==0:
            print(" ".join(strInput))
        elif i==length-1:
            print(" ".join(ls))
        else:
            print(strInput[i].ljust((length-1)*2)+ls[i])
          
        i=i+1
    
    

if __name__ == "__main__":
    inputString = input()
    setPrint(inputString)

