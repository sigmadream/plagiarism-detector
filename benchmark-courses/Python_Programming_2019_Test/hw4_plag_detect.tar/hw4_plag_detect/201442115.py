# -*- coding: utf-8 -*2 3
def rprint(s):
    
    s.reverse()
    print(" ".join(s))

def lprint(s):
    
    print(" ".join(s))
    


#do while
    
if __name__ == "__main__":
    myword = input()
    ls2 = list(myword)
    ls = list(myword)
    if len(ls)>1:
        lprint(ls)
        for n in range(0,(len(myword)-2)):
            print(ls[n+1],end = '')
            for m in range(0,2*len(myword)-3):
                print(' ',end = '')
            print(ls[len(ls)-n-2])
            #ls.reverse()
        rprint(ls2)
    else:
        print(myword)
