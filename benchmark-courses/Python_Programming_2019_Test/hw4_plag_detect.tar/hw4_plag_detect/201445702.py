def rprint(s):
    ls = list(s)
    i = 0
    lss = ls.reverse
    while i < len(ls)-1:
        i += 1
        lss = ls.reverse()
        print(ls[i]+" "*(2*len(ls)-3)+lss[i])
        if i >= len(ls)-2 : break
        
    ls.reverse()
    print(" ".join(ls))

def rprint_test():
    myword = input()
    ls = list(myword)
    print(" ".join(myword))
    rprint(myword)

if __name__ == "__main__":
    rprint_test()
