def rprint(s):
    ls = list(s)
    ls.reverse()
    print(" ".join(ls))

def make_column(s):
    i=1
    len_s = len(s)
    while True:
        print(s[i],end=" ")
        i = i+1
        for j in range(len_s-2):
            print(" ",end=" ")
        print(s[len_s-i])
        if i!=len_s-1: continue
        break;

if __name__ == "__main__":
    myword = input()
    print(" ".join(myword))
    make_column(myword)
    rprint(myword)

