# -*- coding: utf-8 -*-
 
def rprint(s):
 ls = list(s)
 ls.reverse()
 print("".join(ls))

def normalPrint(s):
    ls = list(s)
    for e in ls:
        print(e,end=" ")

def main():
    s = input()
    normalPrint(s)
    
    rprint(list(s))

if __name__ == '__main__':

 main()
 
