#-*- coding: utf-8 -*-

def rprint(s):
    Is=list(s)
    print(" ".join(Is))
    www(Is)
    Is.reverse()
    print(" ".join(Is))
def www(s):
    Is=list(s)
    
    if len(Is) ==5:
        print(Is[1],"     ",Is[3])
        print(Is[2],"     ",Is[2])
        print(Is[3],"     ",Is[1])
    if len(Is)==4:
        print(Is[1],"   ",Is[1])
        print(Is[2],"   ",Is[2])
    if len(Is)==3:
        print(Is[1]," ",Is[1])
    
if __name__=='__main__':
    myword=input()
    rprint(myword)


