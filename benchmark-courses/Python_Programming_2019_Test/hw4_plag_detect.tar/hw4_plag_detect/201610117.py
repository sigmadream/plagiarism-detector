
r=input()


def rprint(r):
 a=r.replace(" ","")
 l = len(a)
 y = 1
 t = [0] * l
 if l>1:
    
  for b in range(0,l):
      t[b]=a[b]
      
  p = " ".join(a)
  print(p)
  
      
  while y<l-1:
        print(t[y],end=" "*((l-2)*2+1))
        print(t[l-y-1])
        y=y+1



  t.reverse()

  p = " ".join(t)
  print(p)

 else:
  print(r)

def main():
  rprint(r)

if __name__ == "__main__":
     main()
