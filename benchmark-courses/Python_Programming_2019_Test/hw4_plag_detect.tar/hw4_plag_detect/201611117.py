def rprint(s) :
    ls=list(s)
    ls.reverse()
    print(" ".join(ls))

def rprint_test():
    myword=input()
    s=len(myword) 
    word=list(myword)
    print(" ".join(word))
    i=1
    while True :
        
        print(word[i] + " "*(s*2-1-2) + word[s-i-1])
        i=i+1
        if i > ( s//2  -s%2  +1 ):
            break
        
    rprint(myword)



if __name__ == "__main__" :
   rprint_test()
   
 
