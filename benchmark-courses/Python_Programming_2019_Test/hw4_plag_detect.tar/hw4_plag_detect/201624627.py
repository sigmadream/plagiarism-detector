s=input()
def rprint(s):
    ls = list(s)
    ls.reverse()
    print(" ".join(ls))

def mid(s):
    l=len(s)
    y=1
    while y<l-1:
        print(s[y],end=" "*((l-2)*2+1))

        print(s[l-y-1])

        y=y+1

    
if __name__ == "__main__":
    print(" ".join(s))
    mid(s)
    rprint(s)
