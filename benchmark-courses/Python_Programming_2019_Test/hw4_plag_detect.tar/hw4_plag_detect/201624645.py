# -*- coding utf-8 -*-

def rprint(s):
    if len(s) == 1:
        print(s)
    else:
        
        ls = list(s)
        rls = list(s)
        rls.reverse()
        counter =1
        a = len(s)
        print(" ".join(ls))
        while counter < a-1 :
            f = ls[counter:counter+1]
            b = rls[counter:counter+1]
            print(" ".join(f), end="")
            for n in range (1, a*2-2):
                print(" ", end="")
            print(" ".join(b))
            counter = counter + 1
        print(" ".join(rls))


def rprint_test():
    myword = input()
    
    rprint(myword)
    

if __name__ == "__main__":
    rprint_test()   

