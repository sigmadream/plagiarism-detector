# -*- coding: utf-8 -*-

def rprint(s):

    ls = list(s)
    
    a =len(ls)
    print(" ".join(ls))
    n=1


    while True:
        print(ls[n]," "*((2*a)-5),ls[a-n-1])
        
        n=n+1
        if n!=a-1: continue
        break



        
    ls.reverse()

    print(" ".join(ls))


if __name__ =="__main__":


    myword = input()
    
    rprint(myword)
