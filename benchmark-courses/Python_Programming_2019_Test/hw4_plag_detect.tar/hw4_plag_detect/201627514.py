#-*- coding: utf-8 -*-
def funcword(word) :
    lsw = list(word)
    print(" ".join(lsw))
    
def reverseword(word) :
    ls = list(word)
    ls.reverse()
    print(" ".join(ls))
    
myword = input()
list_myword = list(myword)
len_myword = len(list_myword)

funcword(myword)

n=1
m=len_myword-2

if(len(list_myword)>1) :
    for i in range(len_myword-2) :

        print(list_myword[n]," "*(2*len_myword-5),list_myword[m])

        n = n+1
        m = m-1
        if n == (len_myword-1) | m == 1:
            break

    reverseword(myword)

