def seq(s,l):
    i=0
    while (i<l-1):
        print(s[i],end=" ")
        i+=1
    print(s[i])

def rev(s,l):
    i=l
    while (i>1):
        print(s[i-1],end=" ")
        i-=1
    print(s[i-1])
    

def main():
    s=input()
    l=len(s)
    seq(s,l)
    for k in range(1,l-1):
        print(s[k]," "*(2*(l-2)-1),s[l-k-1])
    if (l!=1):
        rev(s,l)
        

if __name__=="__main__":
    main()
