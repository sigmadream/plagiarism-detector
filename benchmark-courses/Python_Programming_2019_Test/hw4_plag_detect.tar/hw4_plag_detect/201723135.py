words = str(input())          
ls = list(words)
length = (len(words))

    

def first():
    print(" ".join(ls))

def middle():
    for c in range(1,length-1):
        print(ls[c], end ="")
        print(" "*(2*length-3), end = "")
        print(ls[length-(c+1)])
    
def last():
    ls.reverse()                 
    print(" ".join(ls))


if __name__ == "__main__":
    
    if length==1:
        print(words)
    else:
        first()
        middle()
        last()
        
    
