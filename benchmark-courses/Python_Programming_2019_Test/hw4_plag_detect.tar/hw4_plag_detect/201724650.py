# -*- coding: utf-8 -*-

#use  .reverse() to reverse string.

def wsqr(s) :
    if len(s) > 1 :
        ls = list(s)
        rls = list(s)
        rls.reverse()
        box(ls, rls)
    else :
        print(s)

def box(fwd, bwd) :
    print(" ".join(fwd))
    length = len(fwd)
    counter = 1;
    while True:
        fword = fwd[ counter : counter + 1]
        bword = bwd[ counter : counter + 1]
        print("".join(fword), end= '')
        for n in range (1, (length - 1)*2 ) :
            print(" ", end = '')
        print("".join(bword))
        counter = counter + 1
        if counter < length - 1 : continue
        break;
    print(" ".join(bwd))    
    

if __name__ == "__main__" :
        myword = input()
        wsqr(myword)
