# -*- coding: utf-8 -*-

def printing(str):
    s = list(str)
    n = 0
    while True:
        if(n<len(s)-1):
            print(s[n]+" ",end="")
        else:
            print(s[n])
        n= n + 1
        if(n<len(s)): continue
        break
    
def midprint(str):
    s = list(str)
    n = 1
    while True:
        print(s[n],end="")
        for k in range(0,(len(s)*2)-3):
            print(" ",end="")
        print(s[len(s)-(n+1)])
        n = n + 1
        if(n<len(str)-1): continue
        break
        
def revprint(str):
    revs = list(str)
    revs.reverse()
    n = 0
    while True:
        if(n<len(revs)-1):
            print(revs[n]+" ",end="")
        else:
            print(revs[n],end="")
        n= n + 1
        if(n<len(revs)): continue
        break
    
        
    
if __name__ == "__main__":
    myword = input()
    if(len(myword) == 1): 
        print(myword)
    else:
        printing(myword)
        midprint(myword)
        revprint(myword)
        
