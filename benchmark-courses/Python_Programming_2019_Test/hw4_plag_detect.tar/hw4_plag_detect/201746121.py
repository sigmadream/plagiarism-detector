def rprint(s):
    ls = list(s)
    ls.reverse()
    print("".join(ls))

def rprint_test():
    myword = "hello"
    print(myword)
    rprint(myword)

#if __name__ == "__main__":
s=input()
ls=list(s)
s2=" ".join(s)
slist=s2.split()
s_s=" ".join(ls)
length=len(s_s)
i=1
if len(s) <2 :
    print(s)
else:
    print(s_s)
    while True:
        s_m=s[i]+ ' '*(len(s_s)-2)+s[-i-1]
        print(s_m)
        i+=1
        if i>= (len(s)-1):
            break

    ls.reverse()
    print(' '.join(ls))
