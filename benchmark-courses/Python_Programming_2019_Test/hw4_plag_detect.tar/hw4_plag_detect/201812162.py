
def box():
    s=input()
    li=list(s)
    s_s=" ".join(li)
    li.reverse()
    s_r=" ".join(li)
    if len(s)<2:
        res=s
    else:
        res=s_s+"\n"
        i=1
        while True:
            res+=s[i]+" "*(len(s_s)-2)+s[-i-1]+"\n"
            i+=1
            if i<len(s)-1: continue
            break
        res+=s_r
    return res

def main():
    print(box())

if __name__=="__main__":
    main()
