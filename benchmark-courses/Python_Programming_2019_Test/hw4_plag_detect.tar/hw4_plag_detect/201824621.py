def oprint(s):
    ls = list(s)
    print(" ".join(ls))
def rprint(s):
    ls = list(s)
    ls.reverse()
    print(" ".join(ls))
if __name__ == '__main__':
    word = input()
    lenght = len(word)
    oprint(word)
    i = 1
    while True:
        print(word[i], end = (2*lenght - 3)*" ")
        print(word[lenght - i-1])
        i += 1
        if i <lenght - 1: continue
        break
    rprint(word)

