def main():
    myword = input()
    wbox(myword)

def print_space(a):
    for i in range(a):
        print(" ", end="")

def print_stuff(n, ls):
    i=1
    while True:
        print(ls[i], end='')
        print_space((n-2)*2+1)
        print(ls[-1*(i+1)])
        i=i+1
        if i>n-2 :
            break

def wbox(s):
    ls=list(s)
    length = len(ls)
    if length > 1:
        print(" ".join(ls))
        print_stuff(length, ls)
        ls.reverse()
        print(" ".join(ls))
    else:
        print(s)
    
if __name__=="__main__":
    main()

    
