# -*- coding: utf-8 -*-

def rprint(s):
    ls = list(s)
    ls.reverse()
    print(" ".join(ls))
    
def mprint(s):

##    if len(s)%2!=0:
##        print(s[len(s)//2], s[len(s)//2])
##    else:
##        print(s[(len(s)//2)-1],s[len(s)//2])
    i=1
    ls = len(s)
    while True:
        print(s[i], end = ((2*ls - 3)*" "))
        print(s[ls-i-1])
        i = i+1
        if i < ls-1: continue
        else: break


    
if __name__ == "__main__":
    myword = str(input())
    print(" ".join(list(myword)))
    mprint(myword)
    rprint(myword)
    
