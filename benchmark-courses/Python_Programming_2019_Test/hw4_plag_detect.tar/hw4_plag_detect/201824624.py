# -*- coding: utf-8 -*-

def rprint(s):
    ls = list(s)
    print(" ".join(ls))

def lprint(s):
    ls = list(s)
    ls.reverse()
    print(" ".join(ls))
    
if __name__ == "__main__":
    myword = input()
    rprint(myword)
    leng=len(myword)
    i=1
    while True:
        print(myword[i], end = (2*leng-3)*" ")
        print(myword[leng-i-1])
        i+=1
        if i<leng -1 :continue
        break
    
    lprint(myword)
