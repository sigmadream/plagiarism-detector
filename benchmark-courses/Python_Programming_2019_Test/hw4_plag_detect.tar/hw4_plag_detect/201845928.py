def main():
    word = input()
    boxing(word)
    
def boxing(word):
    ls = list(word)
    print(" ".join(ls), end = "\n")

    sero(ls)
    
    ls.reverse()
    print(" ".join(ls), end = "\n")

def sero(ls):
    a = len(ls)
    n = 1
    while True:
        x = ls[n]+" "*(2*a-3)
        ls.reverse()
        x = x + ls[n]
        print(x, end="\n")
        ls.reverse()
        n += 1
        if n != a-1: continue
        break
        

if __name__ == "__main__":
    main()
    
