def wbox(word):
    ws = box_words(word)
    for w in ws:
        print_line(w)

def print_line(word):
    cs = list(word)
    print(" ".join(cs))

def box_words(word):
    n = len(word)
    words = [""] * n
    if n == 0:
        return words
    words[0] = word
    words[-1] = reverse_word(word)
    for i in range(1, n-1):
        spaces = " " * (n-2)
        mid_word = word[i] + spaces + word[-i-1]
        words[i] = mid_word
    return words

def reverse_word(word):
    ls = list(word)
    ls.reverse()
    return "".join(ls)

if __name__ == "__main__":
    while True:
        word = input()
        wbox(word)
        if word != "": continue
        break
