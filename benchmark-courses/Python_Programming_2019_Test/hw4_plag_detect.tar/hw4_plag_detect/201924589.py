



def rprint(s):
    ls = list(s)
    ls.reverse()
    print("".join(ls))

def putspace(s):
    
    ls = list(s)
    strout = ls[0]
    for i in range(len(ls)-1) :
        strout = strout + ' '
        strout = strout + ls[i+1]
    return strout


def midde(s):
    ls = list(s)
    lenout = len(ls) - 2
    spacemid = len(ls)*2 - 3
    for i in range(lenout):
        print(ls[1+i] +' '*spacemid + ls[ len(ls) -2 - i])


    


def main():
    inp = input()
    if len(inp) > 1 :
        print(putspace(inp))

        midde(inp)
        rprint(putspace(inp))
    if len(inp) == 1:
        print(inp)

if __name__ == '__main__':
    main()
           


