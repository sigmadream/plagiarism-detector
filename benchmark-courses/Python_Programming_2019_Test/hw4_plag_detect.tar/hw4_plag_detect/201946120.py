s = input()
def rprint(s):
    ls = list(s)
    #print("".join(ls))
    ls.reverse()
    print("".join(ls))



def spac(s):
    ls = list(s)
    strr = ls[0]
    for i in range(len(ls)-1):
        strr = strr + ' ' + ls[i+1]
    return strr




def make(s):
    ls = list(s)
    mult = len(ls)*2 -3
    for i in range(len(ls)-2):
        print( ls[i+1] + ' ' * mult + ls[len(ls)-2-i])

if len(s) > 1 :
    print (spac(s))
    make(s)
    rprint(spac(s))
    
if len(s) == 1:
    print(s)
#if __name__ == '__main__':
    #rprint_test()

