# -*- coding: utf-8 -*2

def eraseSpace(s):
    check = 0
    returnString = ""
    
    for i in range(0,len(s)):
        if(s[i] == " "):
            returnString += s[i+1].upper();
            check = 1
        elif(s[i] != " "):
            if(check == 1):
                check = 0
            else:
                returnString += s[i];
 
    return returnString

def changeAllSmallStr(s):
    returnString = ""
    
    for i in range(0,len(s)):
        returnString += s[i].lower()
    return  returnString

def change(s):
    returnString = ""
    index = 0
    for i in range(0,len(s)):
        if(s[i] == " "):
            if(returnString == "make"):
                returnString = "mk "
            elif(returnString == "extract"):
                returnString = "xtrct "
            elif(returnString == "print"):
                returnString = "prnt "
            else:
                returnString += s[i]
        else:
            returnString += s[i]
    return returnString            
        

if __name__ == "__main__":
    myword = input()
    returnword = ""
    returnword = changeAllSmallStr(myword)
    returnword = change(returnword)
    returnword = eraseSpace(returnword)

    print(returnword)
    
