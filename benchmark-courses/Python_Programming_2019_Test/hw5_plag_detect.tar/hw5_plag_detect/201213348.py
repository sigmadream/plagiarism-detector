def main():
    original = input('Enter a string:')
    wordlist = original.split(" ")
    wl=len(wordlist)
    for i in range(wl):
        if i==0:
            vowel(wordlist[i])
        else:
            wlower(wordlist)
def vowel(original):
    if len(original) > 0 and original.isalpha():
        for i in range(len(original)):
            if original[i] in 'aeiou':
                print(original[i],end="")
def wlower(original):
    for i in range(1,len(original)):
        if i==1:
            ll=original[i].lower
            import string
            print(string.capwords(ll),end=""),
       
        else:
            print(original[i].lower,end="")

         
if __name__=="__main__":
    main()

