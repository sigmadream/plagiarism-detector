lang=str(input())


words=lang.split()
print(lang.split())
word2=words[0]
words.pop(0)
##words[0].pop(a)
##words[0].pop(e)
##words[0].pop(i)
##words[0].pop(o)
##words[0].pop(u)
print(words)
print(word2)
##for i in range(len(words[
##word[0].remove(a)
##word[0].count
##for i in range(len(words)):
##    print (words[i])

##def NotCapitals():
##    fw=""
##    for i in range(len(word2)):
##       del words2("a", "e", "i", "o", "u")
##    print(fw)
##       

def Capital():
    lw= ""
    for i in range(len(words)):
        if i==0:
            lw += words[i].upper()
        else:
            lw += words[i].lower()
    print(lw)
    
##NotCapitals()
Capital()


