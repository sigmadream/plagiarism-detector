def no_vowel(s):
    output = list(s)
    for i in range(len(s)):
        output[i] = output[i].lower()
        if output[i] == 'a':
            output[i] = ""
        if output[i] == 'e':
            output[i] = ""
        if output[i] == 'i':
            output[i] = ""
        if output[i] == 'o':
            output[i] = ""
        if output[i] == 'u':
            output[i] = ""
    print("".join(output), end='')

def first_upper(s):
    output = list(s)
    for i in range(len(s)):
        output[i] = output[i].lower()
    output[0] = output[0].upper()
    print("".join(output), end='')

if __name__=="__main__":
    my_word = input().split(sep = " ")
    no_vowel(my_word[0])
    i = 1
    while True:
        first_upper(my_word[i])
        i += 1
        if i >=  len(my_word):
            break
