word = input()

##print(word.isupper())
##print(word.islower())
##print(word.isupper())
##print(word.islower())
##
##print(word.upper())
##print(word)
##print(word.lower())
##print(word)
##print(word.replace(" ",""))




def aeiouremove(word):
    name1 = ""
    for i in range(len(word)):
        if word[i] == 'a' or word[i] == 'e' or word[i] == 'i' or word[i] == 'o' or word[i] == 'u':
            continue
        else:
            name1 += word[i].lower
    print(name1)


def change_upper(word):
    name2 = ""
    for i in range(len(word)):
        if word[i] == " ":
            name2 = word[i+1].upper()
    print(name2)


    
def remove_space(word):
    print(word.replace(" ",""))




##name = ""
##for i in range(len(word)):
##    if i % 2 == 0:
##        name += word[i].lower()
##    else:
##        name += word[i].upper()
##print(name)


