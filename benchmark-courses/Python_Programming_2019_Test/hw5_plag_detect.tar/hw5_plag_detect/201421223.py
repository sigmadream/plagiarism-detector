"""
1. split
2. 각 스플릿의 [0] 자리 upper
3. 첫 스플릿은 모두 lower
4. 첫 스플릿의 모음 제거
5. join

"""

def first_split_word(lang,resultstr):
    for i in range(len(lang)):
        if i is 0 :
            for j in range(len(lang[i])):
                if not lang[i][j].lower() in ['a','e','i','o','u']:
                    resultstr += lang[i][j].lower()

    return resultstr

def lower_split_word(lang,resultstr):
    for i in range(len(lang)):
        if i > 0:
            for j in range(len(lang[i])):
                if j is 0:
                    resultstr += lang[i][j].upper()
                else:
                    resultstr += lang[i][j].lower()
    return resultstr


if __name__ == "__main__":
    lang = input()
    lang = lang.split()
    resultstr = ''

    resultstr = first_split_word(lang,resultstr)
    resultstr = lower_split_word(lang,resultstr)
        
    print(resultstr)

    
