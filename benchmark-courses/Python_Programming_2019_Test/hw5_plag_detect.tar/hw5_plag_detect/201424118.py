lang = input()

words = lang.split()

ss = words[0]





result=''
for i in range(len(ss)):
    
    if not ss[i].lower() in ['a','e','i','o','u']:
        result += ss[i].lower()
     
for i in range(len(words)):
    if i > 0:
        for j in range(len(words[i])):
            if j == 0:
                result += words[i][j].upper()
            else:
                result += words[i][j]
        


        

print(result)

