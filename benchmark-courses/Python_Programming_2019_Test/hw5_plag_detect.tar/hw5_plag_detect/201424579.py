def inputString():
    inputString = input()
    mkFuncName(inputString)
    
def mkFuncName(input):
    result = input.split()
    result[0] = rmChar(result[0])
    for i in range(1, len(result)):
        result[i] = (result[i])[0].upper() + (result[i])[1:].lower()
    resultPrint(result)

def rmChar(input):
    inputLetters = list(input.lower())
    resultLetters=""
    
    for x in range(len(input)):
        if inputLetters[x] not in ('a', 'e', 'i', 'o', 'u','A','E','I','O','U'):
            resultLetters += inputLetters[x]
    return resultLetters
    

def resultPrint(output):
    print("".join(output))

if __name__ == "__main__":
    inputString()
