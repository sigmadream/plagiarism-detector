lang = input()
lang2 = list(lang)

i = 0
while(lang2[i]!='NULL'):
    
    if(lang2[i] != 'a' and lang2[i] != 'e'and lang2[i] != 'i'and lang2[i] != 'o'and
       lang2[i] != 'u'and lang2[i] != 'A'and lang2[i] != 'E' and lang2[i] != 'I'and lang2[i] != 'O'and
       lang2[i] != 'U'):
        print(lang2[i],end = '')
    i+=1
    if i>=len(lang2) :
        break


