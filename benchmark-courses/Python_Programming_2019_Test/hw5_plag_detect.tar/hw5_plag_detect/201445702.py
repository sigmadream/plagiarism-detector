name = input()

def str_split(name):
    name_split = name.split()
    first_split(name_split)

def str_split2(name):
    name_split = name.split()
    another_split(name_split)

def first_split(name_split):
    name_lower = name_split[0].lower()
    
    name_lower_list = list(name_lower)
    if 'a' in name_lower_list:
        name_lower_list.remove('a')
    elif 'e' in name_lower_list:
        name_lower_list.remove('e')
    elif 'i' in  name_lower_list:
        name_lower_list.remove('i')
    elif 'o' in name_lower_list:
        name_lower_list.remove('o')
    elif 'u' in name_lower_list:
        name_lower_list.remove('u')
    new_name = name_lower_list
    return print(new_name)

def another_split(name_split):
    for i in name_split[1:]:
        i2 = i.lower()
        for i in i2:
            i[0].upper()
    sum_list(name_split)

def sum_list(name_split):
    main_name=""
    for i in name_split:
        main_name += i
    return print(main_name)


        
if __name__ == "__main__":
    str_split2(name)
    












