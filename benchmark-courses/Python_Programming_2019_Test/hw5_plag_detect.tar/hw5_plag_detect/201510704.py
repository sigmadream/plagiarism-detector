def mkSpace(s,leng,fsp):
    a=0
    fsp=0
    for i in range(0,leng):
        if ls[i]== ' ':
            ls[i]=''
            ls[i+1]=ls[i+1].upper()
            a+=1
            if a==1:
                fsp= i
    return fsp
def rmvString(s,leng,fsp):
    for j in range(0,fsp):
        if ls[j]=='a'or ls[j]=='e' or ls[j]=='i' or ls[j]=='o' or ls[j]=='u':
            ls[j]=''
    return ls
if __name__=="__main__":
    fsp=0
    s=input()
    ls=list(s.lower())
    leng=len(s)
    fsp=mkSpace(s,leng,fsp)
    rmvString(s,leng,fsp)
    for k in range(0,leng):
        print(ls[k],end='')
