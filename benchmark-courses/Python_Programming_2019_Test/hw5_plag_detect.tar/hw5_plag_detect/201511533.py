vowel = "aeiouwy"

def isvowel(char):
    if( char in vowel ):
        return True
    else:
        return False

def make_first_list(list_word):
    name = ""
    for j in range(len(list_word[0])):
       if isvowel(list_word[0][j])==False:
            name += list_word[0][j].lower()
    return name

def make_rest_of_list(list_word):
    name = ""
    for i in range(1,len(list_word)):
        for j in range(len(list_word[i])):
            if j==0:
                name+=list_word[i][j].upper()
            else:
                name+= list_word[i][j].lower()
    return name

if __name__=="__main__":
    words = input()
    list_word = words.split()
    name = ""
    name += make_first_list(list_word)
    name += make_rest_of_list(list_word)
    print(name)
