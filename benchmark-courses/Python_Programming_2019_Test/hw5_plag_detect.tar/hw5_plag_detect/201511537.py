def firstword(word):
    newword = ""
    for i in range(len(word)):
        if word[i].lower()=='a' or word[i].lower()=='e' or word[i].lower()=='i' or word[i].lower()=='o'  or word[i].lower()=='u':
            continue
        else:
            newword += word[i].lower()
    print(newword, end="")

def otherword(word):
    newword = ""
    newword += word[0].upper()
    for i in range(1,len(word)):
        newword += word[i].lower()
    print(newword, end="")
    
def main():
    k=1
    lang = input()
    lst = lang.split()
    firstword(lst[0])
    while k < len(lst):
        otherword(lst[k])
        k = k+1

if __name__ == '__main__':
    main()
