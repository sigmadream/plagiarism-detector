#모음 : aeiou
# ord 97 / 101 / 105 / 111 / 117
def name():
 word=input()
 ls=word.split()
 a=ls[0].lower()
 l=len(ls)
 k=1
 for b in range(0,len(a)):
         if ord(a[b]) == 97 or ord(a[b]) == 101 or ord(a[b]) == 105 or ord(a[b]) == 111 or ord(a[b]) == 117:
            continue
         else:
            print(a[b],end="")
  
 while k<l:
    t=ls[k]
    w=len(t)
    print(t[0].upper(),end="")
    print(t[1:w].lower(),end="")
    k=k+1

def main():
 name()

if __name__ == '__main__':
    main()

    
