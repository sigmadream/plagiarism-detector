def first_letter(str) :
    str1 = str.split()
    str2 = str1[0]
    print(str2)


def fname(str) :
    str1 = str.split()
    str1len = len(str1)
    str2 = str1[1 : str1len]
    print(str2)
    str2len = len(str2)
    print(str2[1][0].upper())
    str2[1][0] = str2[1][0].upper()
    print(str2)
    
    
    
    

if __name__ == "__main__":
    str = input()
    first_letter(str)
    fname(str)
    
