def pit_h(word):
    m=""
    if len(word) < 2 :
        m=word.upper()
    else:
        m+= word[0].upper()
        for i in range(1,len(word)):
             m+= word[i].lower()
    return m
    

def word_box(word):
    
    x=word.lower()
    m=""
    for i in range(len(x)):
        if x[i]== 'A' or x[i]=='a':
            continue
        elif x[i]== 'I' or x[i]=='i':
            continue
        elif x[i]== 'E' or x[i]=='e':
            continue
        elif x[i]== 'O' or x[i]=='o':
            continue
        elif x[i]== 'U' or x[i]=='u':
            continue
        else:
            m += x[i]
    return m
   
def p_u(word):
    word.split(' ')
    x= word.split(" ")
    
    y = ""
    y += word_box(x[0])
    
    for i in range(1, len(x)):
        y+= pit_h(x[i])
    print(y)

if __name__ == "__main__" :
    o=input()      
    p_u(o) 
