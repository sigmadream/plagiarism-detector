a=input()
haha=[]
def na_me(a):
    me=list(a)
    for i in me:
        if i not in ["a","e","i","o","u","A","E","I","O","U"," "]:
            haha.append(i)
    print("".join(haha))

if __name__=="__main__":
    na_me(a)
