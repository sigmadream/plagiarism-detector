a = input()



print(




 def anti_vowel(text):
    letters = list(text)
    reversed_letters=''
    for x in range(len(text)):
        if letters[x] not in('a','e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'):
                             reversed_letters += letters[x]

        return reversed_letters

text = raw_input("Enter text:")



if __name__ == "__main__":
    print anti_vowel(text)

