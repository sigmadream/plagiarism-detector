def splitsent():
    sentence = input()
    list1 = sentence.split(" ")
    f = list1[0]
    fwf(f)
    for i in range(len(list1)):
        sw = list1[i]
        swf(sw)
    
def fwf(f):
    listfw = list(f)
    for i in range(0,len(listfw)-1):
        if listfw[i] == 'a' or 'A' or 'e' or 'E' or 'i' or 'I' or 'o' or 'O' or 'u' or 'U' :
            del listfw[i+1]
    
    print(listfw)

def swf(sw) :
    listsw = list(sw)
    print(listsw[0].upper())
    for i in range(1,len(listsw)):
        print(listsw[i].lower())

if __name__ == '__main__':
    splitsent()
    
