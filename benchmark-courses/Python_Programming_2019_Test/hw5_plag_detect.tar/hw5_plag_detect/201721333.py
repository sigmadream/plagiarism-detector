def xtrctVowel(s): #extract vowel
    l=len(s)
    for i in range(0,l):
        if s[i].lower()!="a" and s[i].lower()!="e" and s[i].lower()!="i" and s[i].lower()!="o" and s[i].lower()!="u":
            print(s[i].lower(),end="")

def frstStringUpper(n): #first string upper
    j=list(n)
    l=len(j)
    for k in range(0,l):
        if k==0:
            print(j[k].upper(),end="")
        else:
            print(j[k].lower(),end="")

def main():
    m=input()
    n=m.split()
    s=n[0]
    xtrctVowel(s)
    l=len(n)
    if len(n)!=1:
        for i in range(1,l):
            frstStringUpper(n[i])

if __name__=="__main__":
    main()
