name = str(input()) 
lst = name.split()
length = len(lst)

def rmvVowel():
    first = lst[0]
    first = first.lower()
    if 'a' in first:
        first = first.replace('a','')
    if 'e' in first:
        first = first.replace('e','')
    
    if 'i' in first:
        first = first.replace('i','')
    if 'o' in first:
        first = first.replace('o','')
    if 'u' in first:
        first = first.replace('u','')
    print(first, end = "")

def rstWords():
    wlst = []
    for i in range(1,length):
        word = lst[i]
        capital = word[0].upper()
        allwords = capital + word[1:].lower()
        
        wlst.append(allwords)
        
    
    print("".join(wlst))


if __name__ == "__main__":
    rmvVowel()
    rstWords()
    
        
    






    
