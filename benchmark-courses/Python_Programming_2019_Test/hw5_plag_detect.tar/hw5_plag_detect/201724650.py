def frstWord(word) :
    result = ""
    for i in range(len(word)) :
        if word[i] == "a" or word[i] == "A":
            continue
        elif word[i] == "u" or word[i] == "U":
            continue
        elif word[i] == "e" or word[i] == "E" :
            continue
        elif word[i] == "i" or word[i] == "I":
            continue
        elif word[i] == "o" or word[i] == "O" :
            continue
        else :
            result += word[i].lower()
    return result

def hwLong(word):
    if len(word) < 2 :
        return 0;
    else :
        return 1

def lttrWord(word):
    result = ""
    if hwLong(word) == 0 :
        result = word.upper()
    else :
        for i in range (len(word)) : 
            if i == 0 :
                result += word[i].upper()
            else:
                result += word[i].lower()
    return result

def fName(word) :
    result = ""
    process = word.split(' ')
    result += frstWord(process[0])
    for i in range (1, len(process)) :
        result += lttrWord(process[i])
    return result

        
if __name__ == "__main__" :
    lang = input()
    
    print (fName(lang))
