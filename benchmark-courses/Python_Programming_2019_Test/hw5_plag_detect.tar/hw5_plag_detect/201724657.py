def input_string():
    str = input()
    return str

def handle_upper(str):
    change_str = list(str)

    for i in range(len(change_str)):
        if(i != 0):
            if(change_str[i-1] == " "):
                change_str[i] = change_str[i].upper()
            else:
                change_str[i] = change_str[i].lower()
        else:
            change_str[i] = change_str[i].lower()

    return change_str
    
def remove_vowel(str):
    rmv_str = str
    n = 0
    vowel_string = list("AEIOUaeiou")
    
    while True:
        if(rmv_str[n] == " "):
            break
        else:
            for i in range(len(vowel_string)):
                if(rmv_str[n] == vowel_string[i]):
                    rmv_str[n] = ""
        n = n+1

    for k in range(len(rmv_str)):
        if(rmv_str[k] == " "):
            rmv_str[k] = ""
        
    return rmv_str

def print_str(str):
    final_str=""
    for i in range(len(str)):
        final_str += str[i]
    print(final_str)
        
    
if __name__ == "__main__":
    input_str = input_string()
    change_str = handle_upper(input_str)
    rmv_str = remove_vowel(change_str)
    print_str(rmv_str)
