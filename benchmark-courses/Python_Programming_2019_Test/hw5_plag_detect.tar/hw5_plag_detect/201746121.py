a=input()       #make a function
vowel="aeiouAEIOU"

lisa=list(a)
lisv=list(vowel)


lena=len(a)      #3
def fname():
    sentence=""
    for i in range(lena):
##        if lisa[i]==lisv[i]:
##            sentence+=""
## 
        if a[i] in vowel:
            sentence+=""
        else:
            sentence+=a[i]
        if a[i]==" ":
            sentence+=""
            if a[i+1].islower():
                sentence+=a[i+1].upper()
                
        else: continue
        i=i+1
    print(sentence)

fname()


            
            
