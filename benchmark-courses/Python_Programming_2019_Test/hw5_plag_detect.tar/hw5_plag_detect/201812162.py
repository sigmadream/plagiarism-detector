def rmvVowel(inStr):
    res = inStr.lower()
    for ch in ('a', 'e', 'i', 'o', 'u'):
        res = res.replace(ch, "")
    return res

def mkCamelCase(inStr):
    res = inStr[0].upper() + inStr[1:].lower()
    return res

def mkFunctionName(inStr):
    lst = inStr.split(" ")
    lst[0] = rmvVowel(lst[0])
    for i in range(1, len(lst)):
        lst[i] = mkCamelCase(lst[i])
    res = "".join(lst)
    return res

def main():
    s = input()
    print(mkFunctionName(s))

if __name__=="__main__":
    main()
