def other_words(words, i, name):
    for j in range(i,len(words)):
        if words[j]==' ':
            continue
        elif words[j-1]==' ':
            name+=words[j].upper()
        else:
            name+=words[j].lower()
    return name

def is_vowel(a):
    vowels='eyuioaEYUIOA'
    for i in range(len(vowels)):
        if a==vowels[i]:
            return True
    return False   

def main():
    words=list(input())
    name=''
    for i in range(len(words)):
        if words[i]==' ':
            print(other_words(words, i, name))
            break
        else:
            if not is_vowel(words[i]):
                name+=words[i].lower()
                
if __name__=='__main__':
    main()

