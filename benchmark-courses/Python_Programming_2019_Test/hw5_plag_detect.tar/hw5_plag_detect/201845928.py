def rmvVowels(a):
    b = list(a)

    n = 0
    while n < len(b):
        b[n] = b[n].lower()
        if (b[n] == 'a' or b[n] == 'e' or b[n] == 'i' or b[n] == 'o' or b[n] == 'u' or b[n] == 'A' or b[n] == 'E' or b[n] == 'I' or b[n] == 'O' or b[n] == 'U'):
            b.pop(n)
        else:
            n+=1
    return "".join(b)

def pprAndLower(ls, a):
    name = ""
    name += a[0].upper()
    for i in range(1, len(a)):
        name += a[i].lower()

    name = ls+name
    return name


def mn():
    string = str(input())
    n = string.count(' ')+1
    ls = string.split()
    ls1 = rmvVowels(ls[0])
    for i in range(1, n):
        ls1 = pprAndLower(ls1, ls[i])

    print(ls1)

if __name__ == "__main__":
    mn()
