def camalName(s):
    ls = s.split()
    vowels = ['a','e','i','o','u']
    fName=""
    for e in ls[0]:
        if e.lower() in vowels:
            continue
        else:
            fName += e.lower()
    for word in ls[1:]:
        subList = list(word)
        # print(subList)
        if len(subList) == 1:
            fName += subList[0].upper()
        else:
            fName += subList[0].upper()
            for i in subList[1:]:
                if i.isupper():
                    fName += i.lower()
                else:
                    fName += i
    print(fName)

def main():
    s = input()
    camalName(s)

if __name__ == '__main__':
    main()
