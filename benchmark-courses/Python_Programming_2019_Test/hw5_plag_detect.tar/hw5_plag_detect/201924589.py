#-------------------------------------------------------------------------------




def dlvw(S):

    listvow = ['a','e','u','i','o']
    strout = ''
    for i in S:
        small = i.lower()
        if small not in listvow:
            strout = strout + small
    return strout

def nxtbg(S):
    strouttt = '' #오류를 방지 캐시파일이 남으면 곤란
    fir = S[0].upper()
    strouttt = strouttt + fir
    for i in range(1,len(S)):
        sma = S[i].lower()
        strouttt = strouttt + sma
    return strouttt

def dft(S):
    stroutt = ''
    ls = S.split(" ")
    first = ls[0]
    stroutt = stroutt + dlvw(first)
    for i in range(1,len(ls)):
        stroutt = stroutt + nxtbg(ls[i])

    return(stroutt)


def main():
    my = input()
    print(dft(my))

if __name__ == '__main__':
    main()
