my = input()

ls = my.split(" ")

first = ls[0]
strout = ''
for i in first:

    listvow = ['a','e','i','o','u']
    small=i.lower()
    if small not in listvow:
        strout = strout + small


def nxb(S):
    stroutt= ''
    fir = S[0].upper()
    stroutt = stroutt+fir
    for i in range(1,len(S)):
        sma = S[i].lower()
        stroutt= stroutt + sma

    return stroutt

def dft(S):
    strouttt= ''
    ls = S.split(" ")
    for i in range(1,len(ls)):
        strouttt = strouttt +nxb(ls[i])

    return(strouttt)

s = strout + dft(my)
print(s)
