 #-*- coding: utf-8 -*

def main():
     str1 = input()
     str2 = input()
     str3 = input()
     list1 = str1.split()
     list2 = str2.split()
     list3 = str3.split()
     transtab = {list1[0]:"1", list1[1]:"2", list1[2]:"3", list1[3]:"4", list1[4]:"5", list1[5]:"6",
                 list2[0]:"0", list2[1]:"1", list2[2]:"2", list2[3]:"3", list2[4]:"4", list2[5]:"5", list2[6]:"6", list2[7]:"7"}
     list4 = []
     for word in list3:
         if word in transtab:
             list4.append(transtab[word])
         else:
             list4.append("")
     con = ""
     str4 = con.join(list4)
     print(int(str4)*int(str4))

if __name__ == "__main__": 
    main()
