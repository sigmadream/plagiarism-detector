at=input()
noun=input()
word=input()

lista=at.split()
listb=noun.split()
trans1={}
trans2={}
for i in range(len(lista)):
    
    trans1[lista[i]]=i+1
    

for i in range(len(listb)):
    trans2[listb[i]]=i
    

wordlist=word.split()

ans=[]
for k in wordlist:
    if k in trans1:
        ans.append(str(trans1[k]))

    elif k in trans2:
        ans.append(str(trans2[k]))


result="".join(ans)
print(int(result)**2)
