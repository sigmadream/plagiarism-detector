#-*- coding: utf-8 -*-
def main():
    str1 = input()
    str2 = input()
    str3 = input()
    list1 = str1.split()
    list2 = str2.split()
    list3 = str3.split()
    len1=len(list1)
    len2=len(list2)
    len3=len(list3)
    print(list1)
    print(list2)
    transtab=[]
    transtab2=[]
    for k in range(0,len1):
        transtab[list1[k]]=k+1
    for k in range(0,len2):
        transtab2[list2[k]]=k+1
    list4 = []
    for word in list3:
        if word in transtab:
            list4.append(str(transtab[word]))
        elif word in transtab2:
            list4.append(str(transtab2[word]))
        else:
            list4.append(str(word))
    str4 = int("".join(list4))
    int2=str4*str4
    print(int2)
    
if __name__ == "__main__":
    main()
