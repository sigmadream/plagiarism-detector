def main():
 str1 = "Hello World !"
 list1 = str1.split()
 print(list1)
 transtab = {"Hello":"Hola", "World":"Mundo"}
 list2 = []
 for word in list1:
 if word in transtab:
 list2.append(transtab[word])
 else:
 list2.append(word)
 con = " "
 str2 = con.join(list2)
 print(str2)

 if __name__ == "__main__":
 main()
