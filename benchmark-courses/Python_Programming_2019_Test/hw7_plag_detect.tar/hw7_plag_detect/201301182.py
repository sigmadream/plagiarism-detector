
str1=input()
list1=str1.split()
print(list1)
str2=input()
list2=str2.split()
str3=input()
list3=str3.split()
for i in list1:
    for word in list3:
        if word == i:
            word=list1.index(i)
for i in list2:
    for word in list3:
        if word == i:
            word=list2.index(i)
print(list3)
                
            
        
