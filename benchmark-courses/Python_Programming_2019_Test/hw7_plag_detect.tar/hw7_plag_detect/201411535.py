def makedic(s1,s2):
    list1 = s1.split()
    transtab = {}
    for i in range(len(list1)):
        transtab[list1[i]] = str(i+1)
    list2 = s2.split()
    for i in range(len(list2)):
        transtab[list2[i]] = str(i)    
    return transtab

def main(s, transtab):
    str1 = s
    list1 = str1.split()
    list2 = []
    for word in list1:
        if word in transtab:
            list2.append(transtab[word])
        else:
            list2.append(word)
    con = ""
    str2 = con.join(list2)
    print(int(str2)*int(str2))

if __name__ == "__main__":
    s1 = input()
    s2 = input()
    s3 = input()
    main(s3, makedic(s1,s2))

