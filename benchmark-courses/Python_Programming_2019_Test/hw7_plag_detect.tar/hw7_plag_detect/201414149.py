def main():
    str1 = input()
    str2 = input()
    str3 = input()
    list1 = str1.split()
    list2 = str2.split()
    list3 = str3.split()

    new_str=""
    k = 0
    for i in range (0,len(list3)):
        while k < len(list1):
            if list3[i] == list1[k]:
                new_str = new_str + str(k + 1)
            k += 1

        k = 0
        while k < len(list2):
            if list3[i] == list2[k]:
                new_str = new_str + str(k)
            k += 1

        k = 0    
    print(int(new_str)*int(new_str))


if __name__ == "__main__":
    main()
