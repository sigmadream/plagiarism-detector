def make_dic1(my_str):

    my_list = my_str.split()
    dic = {}
    for i in range(len(my_list)):
        dic[my_list[i]] = i+1
    
    
    return dic

def make_dic2(my_str):

    my_list = my_str.split()
    dic = {}
    for i in range(len(my_list)):
        dic[my_list[i]] = i
    
    
    return dic

def main():
    input1 = input()
    input2 = input()
    input3 = input()


    dic1 = make_dic1(input1)
    dic2 = make_dic2(input2)


    
    
    trans_name = []
    name_list = input3.split()
    for word in name_list:
        if word in dic1:
            trans_name.append(dic1[word])
        elif word in dic2:
            trans_name.append(dic2[word])


    result = ""

    for i in range(len(trans_name)):
        result += str(trans_name[i])
        
    result = int(result)
    print(result**2)
            






if __name__ == "__main__":
    main()
