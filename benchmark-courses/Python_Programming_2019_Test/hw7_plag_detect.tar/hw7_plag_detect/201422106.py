a0=input()
lsa=a0.split()
lena=len(lsa)
word1={}
for k in range(0,lena):
    word1[lsa[k]]= k+1



b0=input()
lsb=b0.split()
lenb=len(lsb)
word2={}
for k in range(0,lenb):
    word2[lsb[k]]=k

c0 = input()
lsc=c0.split()
lenc=len(c0)

total=[]
for i in lsc:
    if i in word1:
        total.append(str(word1[i]))
    elif i in word2:
        total.append(str(word2[i]))
a=int("".join(total))
print(a*a)


