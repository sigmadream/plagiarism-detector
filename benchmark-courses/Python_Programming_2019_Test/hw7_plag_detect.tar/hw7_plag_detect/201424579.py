#-*- coding: utf-8 -*-

def main():
    attrStr = input()
    standardStr = input()
    attrList = attrStr.split()
    standartList = standardStr.split()

    transValueDic = {}
    attrValue = 1
    for i in attrList:
        transValueDic[i] = attrValue
        attrValue = attrValue+1
        
    standardValue=0
    for i in standartList:
        transValueDic[i] = standardValue
        standardValue= standardValue + 1

    fullNameStr = input()
    fullNameList = fullNameStr.split()
        
    changeResult = []
    for word in fullNameList:
        if word in transValueDic:
            changeResult.append(transValueDic[word])
        else:
            changeResult.append(word)
        
    con = ""
    squareResult = con.join(map(str, changeResult))
    print(int(squareResult)*int(squareResult))

if __name__ == "__main__":
    main()
