 #-*- coding: utf-8 -*2
def main():
    str_1 = input()
    str_2 = input()
    str1 = input()
    list1 = str1.split()
    #print(list1)
    transtab = {"young":"1", "old":"2", "wild":"3"
                , "lazy":"4", "quick":"5", "so":"6"
                , "owl":"0", "pig":"1", "dog":"2"
                , "rat":"3", "cow":"4", "fox":"5"
                , "lion":"6", "cat":"7"}
    list2 = []
    a = 0
    for word in list1:
        if word in transtab:
            list2.append(transtab[word])
        else:
            list2.append(str(a))
        con = ""
        str_1 = con.join(list2)
        a +=1
    total1 = int(str_1)
    print(total1**2)
    



if __name__ == "__main__":
    main()
    
