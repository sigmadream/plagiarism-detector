str1 = input()
str2 = input()
str3 = input()

def main():
    str1_sp = str1.split()
    str2_sp = str2.split()
    str3_sp = str3.split()
    str1_tu = {}
    str2_tu = {}
    num = 0
    num2 = -1
    list_final = []
    value = 0
    sort = 0
    
    for i in str1_sp:
        num += 1
        str1_tu[i] = num
        

    for i in str2_sp:
        num2 += 1
        str2_tu[i] = num2

    for word in str3_sp:
        if word in str1_tu:
            list_final.append(str1_tu[word])
        else:
            list_final.append(str2_tu[word])

    for i in list_final:
        sort += 1
        value += i*10**(len(list_final)-sort)


    return print(value*value)

if __name__ == "__main__":
    main()

    
        
        
