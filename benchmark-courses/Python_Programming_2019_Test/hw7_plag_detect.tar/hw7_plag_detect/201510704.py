list1 = input().split()
list2 = input().split()
list3 = input().split()
list4=[]
for word in list3:
    if word == list3[-1]:
        if word in list2:
            list4.append(str(list2.index(word)))
    else:
        if word in list1:
            list4.append(str(list1.index(word)+1))
        else:
            continue
a = "".join(list4)
b = int(a)
print(b*b)

