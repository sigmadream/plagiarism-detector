def make_dict(str,i):
    list = str.split()
    transtab = {}
    for word in list:
        transtab[word] = i
        i += 1
    return transtab

def make_name(lst,dict1,dict2):
    name = 0
    for word in lst:
        if word in dict1:
            name += dict1[word]
        elif word in dict2:
            name += dict2[word]
        name*=10
    return name//10

def main2():
    str1 = input()
    str2 = input()
    str3 = input()

    dict1 = make_dict(str1,1)
    dict2 = make_dict(str2,0)
          
    list3 = str3.split()
    name = make_name(list3,dict1,dict2)
    print(name**2)

if __name__ == "__main__":
    main2()

