#-*- coding: utf-8 -*-



def main():
    str1 = input()
    list1 = str1.split()
    transtab1={}
    for i in range(len(list1)):
        transtab1[list1[i]] = i+1

    str2 = input()
    list2 = str2.split()
    transtab2={}
    for i in range(len(list2)):
        transtab2[list2[i]] = i

    str3 = input()
    list3 = str3.split()
    list4 = []
    for word in list3:
        if word in transtab1:
            list4.append(transtab1[word])
        elif word in transtab2:
            list4.append(transtab2[word])
        else:
            list4.append(word)
    m = 0
    for i in range(1,len(list4)+1):
        m += 10**(i-1)*list4[-i]
    m *= m
    print(m)

if __name__ == "__main__":
    main()
