#-*- coding: utf-8 -*-
a=input()
b=input()
c=input()
ls1=a.split()
ls2=b.split()
ls3=c.split()
k=0
for d in range(0,len(ls3)
   while k<(ls1):  
        if ls3[d]==ls1[k]:
               ls3[d]=k+1
               break
        else:
               k=k+1
    k=0

   while k<(ls2):
        if ls3[d]==ls2[k]:
               ls3[d]=k 
               break
        else:
               k=k+1

    k=0

  while k<(ls3):
        if ls3[d]==ls3[k]:
               ls3[d]=k 
               break
        else:
               k=k+1

    k=0
##def main():
## str1 = { 'young' : 1, 'old' :2, 'wild' : 3, 'lazy': 4, 'quick' : 5, 'so' : 6 }
## list1 = str1.split()
## print(list1)
## transtab = {"young" :1, "old" : 2, "wild":3, "lazy" : 4, "quick" : 5, "so" :6 }
## list2 = []
##for word in list1:
##    if word in transtab:
##        list2.append(transtab[word])
##    else:
##        list2.append(word)
 con = " "
 str2 = con.join(list2)
 print(str2)

if __name__ == "__main__":
  main()
