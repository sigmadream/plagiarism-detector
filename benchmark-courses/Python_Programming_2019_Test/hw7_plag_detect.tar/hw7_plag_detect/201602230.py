#-*- coding: utf-8 -*-

def main():
    strl1=input()
    strl2=input()
    strl3=input()
    
    listl1=strl1.split()
    listl2=strl2.split()
    listl3=strl3.split()
    transtab={}
    i=1
    j=0
    for word in listl1:
        transtab[word]=i
        i=i+1
    for word in listl2:
        transtab[word]=j
        j=j+1
    
        
    
    list4=[]

    for word in listl3:
        if word in transtab:
            list4.append(transtab[word])
   
    
    o=0

    for w in range(0,len(list4)):
            o+=int(list4[w])*10**(len(list4)-w-1)
            
        
    print(o**2)



if __name__=="__main__":
    main()
