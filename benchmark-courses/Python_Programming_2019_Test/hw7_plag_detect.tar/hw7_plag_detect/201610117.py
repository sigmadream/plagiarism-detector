ls11 = input()
ls22 = input()
ls33 = input()
ls1 = ls11.split()
ls2 = ls22.split()
ls3 = ls33.split()
k=0
for a in range(0,len(ls3)):
    while k<len(ls1):
        if ls3[a]==ls1[k]:
            ls3[a]=k+1
            break
        else:
            k=k+1
    k=0
    while k<len(ls2):
        if ls3[a]==ls2[k]:
            ls3[a]=k
            break
        else:
            k=k+1
    k=0



n=""
for a in range(0,len(ls3)):
  n = n+str(ls3[a])


t = int(n)*int(n)
print(t)
