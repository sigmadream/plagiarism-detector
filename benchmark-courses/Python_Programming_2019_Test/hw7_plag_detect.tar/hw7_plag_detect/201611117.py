def str1 (dec):
    str1 = dec.split()
    trans1 = {}
    for i in str1 :
        trans1[i] = str1.index(i) +1
    return trans1

    
def str2 (noun) :
    str2 = noun.split()
    trans2 = {}
    for i in str2 :
        trans2[i] = str2.index(i)
    return trans2

def main(dec,noun,fullname) :
    trans1 = str1(dec)
    trans2 = str2(noun)
    
    str3 = fullname.split()
    list1 = []
    for i in str3 :
        if i in trans1 :
            list1.append(trans1[i])
        else:
            list1.append(trans2[i])
    
    a =""
    for i in list1 :
        a += str(i)
    a= int(a)

    print(a*a)
    
    
    
    
        
    
    
    
    

if __name__ =="__main__" :
    dec = input()
    noun = input()
    fullname = input()
    main(dec,noun,fullname)
