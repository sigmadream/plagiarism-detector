#-*- coding: utf-8 -*-




def firstline():
    str1 = input()
    list1 = str1.split()
    
    transtab1 = {}
    k = 1
    for word in list1:
        transtab1[word] = k
        k += 1
    return transtab1
    return list1
    
    

def secondline():
    str2 = input()
    list2 = str2.split()
    
    transtab2 = {}
    j = 0
    for word in list2:
        transtab2[word] = j
        j += 1
    return transtab2
    return list2


def thirdline():
    
    emptylist = []
    str3 = input()
    list3 = str3.split()

    for w in list3:
        if w in list1:
            list3.append(str(transtab1[w]))
        elif w in list2:
            list3.append(str(transtab2[w]))
        a = int("".join(list3)) * int("".join(list3))
        print(a)

if __name__ == "__main__":
    firstline()
    secondline()
    thirdline()
            
