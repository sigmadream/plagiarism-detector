a = input()
b = input()
c = input()
ls1 = a.split()
ls2 = b.split()
ls3 = c.split()    
k = 0
for d in range(0,len(ls3)):
    while k<len(ls1):
        if ls3[d]==ls1[k]:
            ls3[d]=k+1
            break
        else:
            k=k+1
    k=0
    
    while k<len(ls1):
        if ls3[d]==ls2[k]:
            ls3[d]=k
            break
        else:
            k=k+1
    k=0

