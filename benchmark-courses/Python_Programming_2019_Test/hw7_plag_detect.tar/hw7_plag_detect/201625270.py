def toline(line, n):
    list1 = line.split()
    transtab = {}
    word = ""
    count = n
    for i in (list1):
        transtab[i]= count
        count += 1
    return transtab

def toword(w, s, t):
    list1 = w.split()
    list2 = []
    for i in (list1):
        if i in s:
            list2.append(str(s[i]))
    if list1[-1] in t:
        list2.append(str(t[list1[-1]]))
    st = ""
    stnum = st.join(list2)
    return stnum

def main():
    line1 = toline(input(), 1)
    line2 = toline(input(), 0)
    word = toword(input(), line1, line2)
    print(int(word) * int(word))
    
if __name__=="__main__":
    main()


#v제곱 프린팅
