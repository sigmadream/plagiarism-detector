#-*- coding: utf-8 -*-

def main():
    
    f = input()
    lsf = f.split()
    dic1 = {}
    for i in range(len(lsf)):
        dic1[lsf[i]] = i+1
        
    s = input()
    lss = s.split()
    dic2 = {}
    for i in range(len(lss)):
        dic2[lss[i]] = i
    
    l = input()
    lsl = l.split()
    result = []
    for word in lsl:
        if word in dic1:
            result.append(str(dic1[word]))
        else:
            result.append(str(dic2[word]))
    result2 = ''.join(result)
    r = int(result2)*int(result2)
    print(r)
    
if __name__ == "__main__":
    main()
