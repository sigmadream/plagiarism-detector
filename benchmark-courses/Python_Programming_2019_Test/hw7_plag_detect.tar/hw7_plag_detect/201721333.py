def main():
    s1=input()
    s2=input()
    s3=input()
    list1=s1.split()
    list2=s2.split()
    list3=s3.split()

    n=len(list1)
    m=len(list2)

    z1={}
    z2={}
    for i in range(0,n):
        z1[list1[i]]=i+1
    for j in range(0,m):
        z2[list2[j]]=j

    c=[]
    for word in list3:
        if word in z1:
            c.append(z1[word])
    for word in list3:
        if word in z2:
            c.append(z2[word])

    cc=len(c)
    ccc=0
    for k in range(0,cc):
        ccc+=int(c[k])*(10**(cc-k-1))
        
    print(ccc*ccc)

    

if __name__=="__main__":
    main()
