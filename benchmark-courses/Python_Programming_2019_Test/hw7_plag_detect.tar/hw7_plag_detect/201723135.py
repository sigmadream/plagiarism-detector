first = input()
second = input()
fname = input()

ls_first = first.split()
ls_second = second.split()
ls_fname = fname.split()
dct_first = {}
dct_second = {}

i = 1
for f in ls_first:
    dct_first[f] = i
    i += 1

j = 0
for s in ls_second:
    dct_second[s] = j
    j += 1

ls_num = []
for word in ls_fname:
    if word in dct_first:
        ls_num.append(str(dct_first[word]))
    elif word in dct_second:
        ls_num.append(str(dct_second[word])) 

str_x = "".join(ls_num)
int_x = int(str_x)

print(int_x * int_x)
