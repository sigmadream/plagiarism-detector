def nDigit(line) :
    keys = line.split()
    count = 1
    dic = dict.fromkeys(keys)
    for k, v in dic.items() :
        if v is None :
            dic[k] = count
            count = count + 1
    return dic

def mDigit(line) :
    keys = line.split()
    count = 0
    dic = dict.fromkeys(keys)
    for k, v in dic.items() :
        if v is None :
            dic[k] = count
            count = count + 1
    
    return dic

def nmCal(nums) :
    x = 0
    count = 1
    for i in range(len(nums)-1, -1, -1) :
        x += nums[i] * count
        count *= 10
    
    return x

def main(first, second, third) :
    dic1 = dict(nDigit(first))
    dic2 = dict(mDigit(second))
    dic = dic1.copy()
    dic.update(dic2)

    nums = []
    val = third.split()
    for i in range(len(val)) :
        for k, v in dic.items() :
            if k == val[i] :
                nums.append(v)
            else :
                continue
    result = nmCal(nums)

    print(result * result)
    
if __name__ == "__main__" :
    first = input()
    second = input()
    third = input()

    main(first, second, third)
