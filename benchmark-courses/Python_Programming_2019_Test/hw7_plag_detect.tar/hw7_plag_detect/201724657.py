def trs1(str1):
    temp = ""
    dstr = []
    for c in str1:
        if c.isalpha():
            temp = temp + c
        else:
            dstr.append(temp)
            temp = ""
    dstr.append(temp)

    return dstr

def pf(tb1,tb2,lstr):
    num = ""
    for i in range(len(lstr)):
        for j in range(len(tb1)):
            if(lstr[i] == tb1[j]):
                num = num + str(j+1)
        for k in range(len(tb2)):
            if(lstr[i] == tb2[k]):
                num = num + str(k)
    final = int(num) * int(num)
    print(final)
    
if __name__ == "__main__":
    str1 = input()
    str2 = input()
    str3 = input()
    tb1 = trs1(str1)
    tb2 = trs1(str2)
    lstr = trs1(str3)
    
    pf(tb1,tb2,lstr)
