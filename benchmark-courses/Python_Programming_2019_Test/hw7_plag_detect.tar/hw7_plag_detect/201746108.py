
def first():
    list1 = input().split()
    list2 = input().split()
    list3 = input().split()
    #print(list1)
    list1_1 = []
    for word in list3:
        if word == list3[-1]:
            if word in list2:
                list1_1.append(str(list2.index(word)))
        else:
            if word in list1:
                list1_1.append(str((list1.index(word)+1)))
            else:
                continue
    #print(list1_1)
    a ="".join(list1_1)
    b = int(a)
    print(b*b)

if __name__ == "__main__":
    first()
