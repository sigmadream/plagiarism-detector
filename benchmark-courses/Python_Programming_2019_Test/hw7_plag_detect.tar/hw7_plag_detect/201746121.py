def main():
    list1=input()
    list1=list1.split()
    list2=input()
    list2=list2.split()
    list3=input()
    list3=list3.split()

    b_list = []
    for word in list3:
        if word == list3[-1]:
            if word in list2:
                b_list.append(str(list2.index(word)))
        else:
            if word in list1:
                b_list.append(str((list1.index(word)+1)))
            else:
                continue

    a="".join(b_list)
    b=int(a)
    print(b*b)

if __name__ == "__main__":
    main()
