def inToDict(start):
    line=input()
    li=line.split()
    dic=dict()
    i=start
    for x in li:
        dic[x]=str(i)
        i+=1
    return dic

def main():
    dic=inToDict(1)
    dic.update(inToDict(0))
    words=input()
    words=words.split()
    i=0
    for x in words:
        if x in dic:
            words[i]=dic[x]
        i+=1
    num=eval("".join(words))
    print(num**2)

if __name__=="__main__":
    main()
