def main():
    str1 = input()
    list1 = str1.split()
    str2 = input()
    list2 = str2.split()
    str3 = input()
    list3 = str3.split()
    
    d = dict()
    d = dict()
    
    vallist = []
    k = 1
    for word in list1:
        if word not in d:
            d[word] = k
            k += 1
    y = 0
    for word in list2:
        if word not in d:
            d[word] = y
            y += 1
    for word in list3:
        if word in list1 + list2:
            vallist.append(d[word])
            
    tnum = 0
    for num in vallist:
        tnum = tnum*10 + num
    square = tnum**2
    
    print(square)

if __name__ == "__main__":
    main()
