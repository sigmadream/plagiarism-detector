def main():
    fl=input().split()
    sl=input().split()
    cpr1={}
    cpr2={}
    j=1
    for i in fl:
        cpr1[i]=j
        j+=1
    j=0
    for i in sl:
        cpr2[i]=j
        j+=1
    tl=input().split()
    l=len(tl)
    out=''
    for i in range(l-1):
        out+=str(cpr1[tl[i]])
    out+=str(cpr2[tl[l-1]])
    print(int(out)**2)
    
if __name__ == "__main__":
    main()
