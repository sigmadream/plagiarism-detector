def main():
    str1 = input()
    str2 = input()
    str3 = input()
    list1 = str1.split()
    list2 = str2.split()
    list3 = str3.split()
    valuelist = []
    dic = dict()
    k = 1
    for word in list1:
        dic[word] = k
        k += 1
    y = 0
    for word in list2:
        dic[word] = y
        y += 1
    
    for word in list3:
        if word in list1 + list2:
            valuelist.append(dic[word])
    result = 0
    for num in valuelist:
        result = result * 10 + num
    result2 = result ** 2
    print(result2)
if __name__ == "__main__":
    main()
