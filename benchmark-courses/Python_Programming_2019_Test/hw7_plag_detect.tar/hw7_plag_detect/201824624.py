def main():
    list1 = input()
    list1 = list1.split()
    n = len(list1)
    dicti = {}

    list2 = input()
    list2 = list2.split()
    n1 = len(list2)
    dicti2 = {}

    list3 = input()
    list3 = list3.split()

    if n > 10:
        return 0
    else :
        for i in range(1, n + 1):
            dicti[f"{list1[i-1]}"] = i

    if n1 > 10:
        return 0
    else:
        for z in range(0, n1):
            dicti2[f"{list2[z]}"] = z

    outp = []
    for word in list3:
        if word in dicti:
            outp.append(dicti[word])
        elif word in dicti2:
            outp.append(dicti2[word])
        else:
            outp.append(word)

    number = 0
    for i in outp:
        number = number * 10 + i

    print(number ** 2)
if __name__ == "__main__":
    main()
