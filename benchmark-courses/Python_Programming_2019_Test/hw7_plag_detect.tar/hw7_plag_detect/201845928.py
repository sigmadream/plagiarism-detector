

if __name__ == "__main__":
    str1 = input()
    lst1 = str1.split()
    s = []
    i = 1
    for a in lst1:
        s.append((a, i))
        i += 1
    str2 = input()
    lst2 = str2.split()
    i=0
    for a in lst2:
        s.append((a, i))
        i += 1
    str3 = input()
    lst3 = str3.split()
    num = []
    for check in lst3:
        for a in s:
            if check == a[0]:
                num.append(a[1])
                break
    b = ""
    for i in num:
        b += str(i)
    b = int(b)
    print(b*b)
    
