def main():
    atrLine = input()
    nLine = input()
    wordLine = input()
    atrList = atrLine.split()
    atrDict = {}
    nList = nLine.split()
    nDict = {}
    wordList = wordLine.split()

    for i in range(len(atrList)):
        atrDict[atrList[i]] = i+1
    for j in range(len(nList)):
        nDict[nList[j]] = j

    # print(atrDict)
    # print(nDict)

    valueStr = ""
    for word in wordList:
        if word in atrDict:
            valueStr += str(atrDict[word])
        elif word in nDict:
            valueStr += str(nDict[word])
        else:
            continue
    valueDec = pow(int(valueStr), 2)
    # print(wordLine)
    # print(valueStr)
    print(valueDec)

if __name__ == '__main__':
    main()
