#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Lucky-CHO
#
# Created:     01-05-2019
# Copyright:   (c) Lucky-CHO 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------


fir = "young old wild lazy quick so"
sec = "owl pig dog rat cow fox lion cat"
thr = "wild old owl"

fir2 = "big fat tall lazy quick so small cute"
sec2 = "owl pig dog rat cow fox lion cat"
thr2 = "so big fat lazy cat"

fir3 = input()
sec3 = input()
thr3 = input()

listfir = fir3.split()
listsec = sec3.split()
listthr = thr3.split()

dicfir = {}
dicsec = {}


for i in range(len(listfir)):
    dicfir[listfir[i]] = i+1

for q in range(len(listsec)):
    dicfir[listsec[q]] = q


#print(dicfir)
#print(dicsec)

c = ''
for w in listthr:
    a = dicfir[w]
    b = str(a)
    c += b


#print(c)
out = int(c)

print (out*out)













