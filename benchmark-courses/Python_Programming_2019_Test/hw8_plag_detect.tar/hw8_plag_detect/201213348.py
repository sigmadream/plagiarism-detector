N=int(input(""))
A=input("")
s1=A.split()

ls=[]
for k in range (0,N):
    s0=[s for s in s1 if int(s)%N==k]
    ls=ls+s0

ans=" ".join(ls)
print(ans)
