banum = int(input())
spnum = input()
s1=spnum.split()
ls1=len(s1)
s2=[]
for i in range(ls1):
    s2.append(int(s1[i]) % banum)
print (s2)
## ls2=[2*n+1 for n in ls1] 이런식으로.
## banum은 숫자 하나.
## spnum은 숫자 여러개를 스페이스로 구분. 리스트에 넣었다가 빼는식으로.
## spnum을 banum으로 나눈 나머지 순서대로 정렬시키고자함.
##cs=list (s1)
#cs2=[c for c in s1]
##list형 만으로 가능하다는데 어떻게?
## s2를 나머지로 했는데 이걸 이용할수 없을까?
## 
