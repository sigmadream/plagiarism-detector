def main():
astr = "Hello World!"
uchars = [c for c in astr if c.isupper()]
print("".join(uchars))

if __name__ == "__main__":
main()
