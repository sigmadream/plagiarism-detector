n=int(input())
strr=input()
ls=strr.split()

ls1=[int(i)%n for i in ls]

ls2=[]
for i in range(n):
    for j in range(len(ls1)):
        if ls1[j]==i:
            ls2.append(ls[j])

print(" ".join(ls2))    
 
   
        
       
            
