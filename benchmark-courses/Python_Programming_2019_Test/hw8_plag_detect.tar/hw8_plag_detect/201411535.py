def main():
    n1 = int(input())
    n2 = input()
    ls = n2.split()
    ls1 = ls
    for i in range(len(ls1)):
        ls1[i] = ((int(ls1[i])%n1), i)
    ls1.sort()
    for i in range(len(ls1)):
        ls1[i] = ls1[i][1]
    for i in range(len(ls)):
        ls1[i] = n2.split()[ls1[i]]
    re = " ".join(ls1)
    print(re)
    
if __name__ == "__main__":
    main()
