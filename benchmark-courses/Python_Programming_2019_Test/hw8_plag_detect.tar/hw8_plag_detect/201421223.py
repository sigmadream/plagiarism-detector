def main():
    N = int(input())
    string = input()

    sl = string.split()


    dic = {}
    s_len = len(sl)
    for i in range(s_len):
        if not int(sl[i]) % N in dic:
            dic[int(sl[i]) % N] = sl[i]
        else :
            dic[int(sl[i])%N] += " {}".format(sl[i])



    keys = [key for key in range(N) if key in dic]

    result = ""
    for i in range(len(keys)):
        key = keys[i]
        temp_str = dic[key].split()
        
        while(len(temp_str) != 0):    
            result += "{} ".format(temp_str[0])
            temp_str = temp_str[1:]
    print(result[:-1])

if __name__ == "__main__":
    main()
