ls0=[]
a=int(input())
b1=str(input())
b2=b1.split()

ls0 = [i for i in b2]
ls1= []

for k in range(len(ls0)):
    for i in range(0,len(ls0)):
        if int(ls0[i]) % a ==k:
            ls1.append(ls0[i])


print(" ".join(ls1))
