def main():
    N = int(input())
    aaa = input()
    ls = aaa.split()
    

    

    dic = {}
    for i in range(len(ls)):
        key = int(ls[i]) % N
        
        if key in dic:
            dic[key] += " {}".format(ls[i])
        else:
            dic[key] = ls[i]



    keys = [key for key in range(N) if key in dic]

    output = ""
    for j in range(len(keys)):
        key = keys[j]
        output += dic[key]
        output += " "
    
    print(output[:-1])
        


    
if __name__ == "__main__":
    main()
