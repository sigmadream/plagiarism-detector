def main():
    mod_number = int(input())
    list_number = input()
    list_number = list_number.split()

    result = [j for i in range(0,mod_number) for j in list_number if int(j)%mod_number==i]
    print(" ".join(result))
    
    
if __name__ == "__main__":
    main()
