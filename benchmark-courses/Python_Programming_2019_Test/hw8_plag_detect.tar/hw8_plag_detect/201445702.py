mod = int(input())
number = input()
numbers = number.split()

def main():
    num_list = []

    for i in range(0,mod):
        for c in numbers:
            if int(c)%mod == i:
                num_list.append(c)

    
                
    print(" ".join(num_list))

if __name__ == "__main__":
    main()


