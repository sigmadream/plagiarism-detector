def main(n,num,numls):
    aa = [c for c in numls if c!=" "]
    ls = [i for k in range(n) for i in aa if int(i)%n==k]

    print(' '.join(ls))

if __name__=="__main__":
    n= int(input())
    num=input()
    numls=num.split(' ')
    main(n,num,numls)
