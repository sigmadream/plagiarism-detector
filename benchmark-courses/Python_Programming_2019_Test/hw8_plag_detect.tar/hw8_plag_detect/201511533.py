def main():
    num = int(input())
    str1 = input()
    ls_num = [int(n) for n in str1.split() if n!=' ']
    sort_num=[]
    for i in range(0,num):
        ls = [n for n in ls_num if n%num==i]
        sort_num.append(ls)
    l = len(sort_num)
    lstr = [n for sn in sort_num for n in sn]
    str2 = [str(x) for x in lstr]
    print(' '.join(str2))

if __name__ == "__main__":
    main()


