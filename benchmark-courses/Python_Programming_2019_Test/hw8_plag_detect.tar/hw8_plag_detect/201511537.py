def main():
    N = int(input())
    seqst = input()
    modod = []
    seqls = seqst.split()
    for j in range(N):
        modod = modod + [seqls[i] for i in range(len(seqls)) if int(seqls[i])%N==j]
    print(" ".join(modod))
    
if __name__=="__main__":
    main()
