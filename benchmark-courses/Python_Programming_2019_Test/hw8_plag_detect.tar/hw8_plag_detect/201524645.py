def product(m1,m2):
    row1=len(m1)
    col1=len(m1[0])
    row1=len(m2)
    col1=len(m2[0])

    assert col1 == row2
    mat=[[0]*row1 for i in range(col2)]
    for i in range(row1):
        for j in range(col2):
           mat[i][j]=0
           for k in range(col1):
             mat[i][j]+=m1[i][k]*m2[k][j]
    return mat
def transpose(mat):
    row=len(mat)
    col=len(mat[0])
    mat2=[[0]*row for i in range(col)]
    for i in range(row):
        for j in range(col):
            mat2[j][i]=mat[i][j]
    return mat2


def filter_neg(mat):
    row=len(mat)
    col=len(mat[0])
    mat2=[[0]*col for i in range(row)]
    for i in range(row):
        for j in range(col):
            if mat[i][j]<0:
                mat2[i][j]=0
            else:
                mat2[i][j]=mat[i][j]
    return mat2

def main():
    row=2
    col=3
    mat= [[0]*col for i in range(row)]
    print(mat)
    initlist=input(list())
    k=0
    for i in range(row):
        for j in range(col):
            mat[i][j]=initlist[k]
            k += 1

    print(mat)
    print(filter_neg(mat))
    mat2=transpose(mat)
    print(mat2)
    mat3=product(mat,mat2)
##print(transpose(mat))
    print(mat3)
    mat4=pr

if __name__=='__main__':
    main()
