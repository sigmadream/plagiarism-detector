a = int(input())
b = input()
ls = b.split()
ls2 = [0] * len(ls)
ls3 = [0] * len(ls)
for c in range(0,len(ls)):
    f = int(ls[c]) % a
    s = ord(str(f))
    ls2[c] = s


for t in range(0,len(ls)):
    a=ls2.index(min(ls2))
    ls3[t] =ls[a]
    ls2[a] = 999

print(" ".join(ls3))
