def mod(n,s) :
    ls = s.split()
    
    for i in range(len(ls)):
        ls[i] = (int(ls[i])%int(n),i)
    print(ls)
    ls.sort()
    print(ls)

    
    


if __name__ == "__main__" :
    n = input()
    s = input()
    mod(n,s)

