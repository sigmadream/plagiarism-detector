##def main():
##    astr=input("Enter a num: ")
##    astr1=astr()
##    uschar=[c for c in astr1 if c.isupper()]
##    print("".join(uschar))

def main():
    base=int(input())
    ordnum=input()
    d1={c:ord(c) for c in ordnum}
    print(d1)
    for n in d1:
        base1 = ord(n)%base
        print(n, end="")
        
    



if __name__=="__main__":
    main()
    
