def remainder(m, n):
    ls = n.split()
    plist = []
    for i in ls:
        r = int(i) % int(m)
        plist.append([r, i])
    plist.sort()
    answer = []
    for i in plist:
        answer.append(i[1])
    return answer

def main():
    modN = input()
    numbers = input()
    result = remainder(modN, numbers)
    print(" ".join(result))

if __name__=="__main__":
    main()

#아스키코드 ord('H')
