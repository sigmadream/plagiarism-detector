def main():
    n = int(input())
    num = input()
    numls = num.split(' ')
    aa = [c for c in numls if c!=" "]
    ls = [i for k in range(n) for i in aa if int(i)%n ==k ]
    
    print(' '.join(ls))

if __name__ == "__main__":
    main()
