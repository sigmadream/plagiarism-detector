def main():
    n=int(input())
    ss=input()
    s=list(ss.split())
    l=len(s)

    z=[]
    for i in range(0,n):
        if ([m for m in s if int(m)%n==i]!=[]):
            z.append([m for m in s if int(m)%n==i])
    
    ll=len(z)
    
    for i in range(0,ll-1):
        print(" ".join(z[i]),end=" ")
    print(" ".join(z[ll-1]))


if __name__=="__main__":
    main()
