def remainder(x, N):
    r = x % N
    return r

def dct_vsort(dct):
    ls = [v for v in dct.values()]
    srt_ls = sorted(ls)
    ans = []
    for c in srt_ls:
        for (crd,name) in dct.keys():
            if dct[(crd,name)] == c:
                if (crd,name) not in ans:
                    ans.append((crd,name))
                else:
                    break
    return ans
                
            
    
    

def main():
    N = int(input())
    seq = input()
    ls_seq = seq.split()
    ls_int = [int(c) for c in ls_seq]

    dct = {(i,name):remainder(name,N) for (i,name) in enumerate(ls_int)}
    ans = dct_vsort(dct)
    answer = []
    for c in ans:
        answer.append(str(c[1]))
    print(" ".join(answer))
        
    
    
if __name__ == "__main__":
    main()
