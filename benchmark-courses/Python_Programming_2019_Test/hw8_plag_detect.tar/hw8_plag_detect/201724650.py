def mdN(lst):
    mod = lst[0]
    org = lst;
    ind = [n for n in range(len(lst) - 1)]
    cal = lst;

    ans = [lst[n] for n in range(1, len(lst))]
    result = [lst[n] for n in range(1, len(lst))]
    for n in range(len(lst)) :
        if int(org[n]) == 0 :
            cal[n] = int(0)
        else :
            cal[n]= int(org[n]) % int(mod)

    rst = [cal[n] for n in range(1, len(lst))]

    for i in range(len(rst) - 2):
        min_idx = i
        for j in range(i + 1, len(rst) - 1):
            if int(rst[j]) < int(rst[min_idx]) :
                min_idx = j
        rst[i], rst[min_idx] = rst[min_idx], rst[i]
        ind[i], ind[min_idx] = ind[min_idx], ind[i]
    
    for n in range(len(ind)) :
        result[n] = int(ans[ind[n]])

    for n in range(len(result) -1 ) :
        print(result[n], end = ' ')
    print(result[len(result)- 1])
            
def mkList(x, y):
    head = [x[n] for n in range(len(x)) if len(x) == 1]
    
    tail0 = y.split(' ')
    tail = [tail0[n] for n in range(len(tail0))]        
    result = head + tail
        
    return result

def main():
    a = input()
    b = input()
    mdN(mkList(a, b))

if __name__ == "__main__":
    main()
