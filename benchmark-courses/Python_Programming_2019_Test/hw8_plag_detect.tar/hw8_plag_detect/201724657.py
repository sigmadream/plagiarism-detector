def f1(mod,list1):
    cnt = 0
    list2 = [[0] for i in range(len(list1))]
    for i in range(0,mod):
        for j in range(len(list1)):
            if(list1[j] % mod == i):
                list2[cnt] = list1[j]
                cnt = cnt + 1
    return list2

def tostr(list):
    str1 = ""
    for i in range(len(list)-1):
        list[i] = str(list[i])
        str1 = str1 + list[i] + " "
    str1 = str1 + str(list[-1])

    return str1
if __name__ == "__main__":
    i1 = int(input())
    s1 = input()
    s2 = s1.split(' ')
    i2 = [int(s2[i]) for i in range(len(s2))]
    
    list = f1(i1,i2)
    final = tostr(list)
    print(final)
