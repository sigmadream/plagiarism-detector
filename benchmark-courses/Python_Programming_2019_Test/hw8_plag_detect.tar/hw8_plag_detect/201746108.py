a = int(input())
b = input().split()
c = []
cn = []
result = []
count = 0
for j in range(0,len(b)):
    for i in b:
        if int(i) % a == j:
            c.append(i)
d = ' '.join(c)
print(d)
    


        
    
