a = int(input())
b = input().split()
bin_list = []

count = 0
for j in range(0,len(b)):
    for i in b:
        if int(i) % a == j:
            bin_list.append(i)
d = ' '.join(bin_list)
print(d)
    
