def main():
    N=int(input())
    instr=input()
    inlist=instr.split()
    resli=[]
    for i in range(0,N):
        resli+=[x for x in inlist if int(x)%N==i]
    print(" ".join(resli))

if __name__=="__main__":
    main()
