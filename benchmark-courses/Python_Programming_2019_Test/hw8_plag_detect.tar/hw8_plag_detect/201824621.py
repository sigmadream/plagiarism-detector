def main():
    modnum = int(input())
    numlist = list(map(int, input().split()))
    nlist = []
    nlist2 = []
    for i in numlist:
        nlist.append(i%modnum)
    dict = {n:n%modnum for n in numlist}
    
    nlist.sort()
    
    for i in nlist:
        for j in numlist:
            if dict[j] == i:
                nlist2.append(j)
                numlist.remove(j)
                break
        
    for i in range(len(nlist2)):
        if i == len(nlist2) - 1:
            print(nlist2[i], end = "")
        else:
            print(nlist2[i],end = " ")
    
    

if __name__ == "__main__":
    main()
