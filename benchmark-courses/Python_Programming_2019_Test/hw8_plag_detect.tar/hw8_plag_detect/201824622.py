def divide(s):
    num=[0 for n in s]
    k=0
    for i in range(len(s)):
        if s[i]==' ':
            k=k+1
        else:
            num[k]=int(s[i])+10*num[k]
    return num[0:k+1]


def main():
    mod=int(input())
    s=input()
    nums=divide(s)
    
    output=[]
    for i in range(mod):
        new=[str(n) for n in nums if n!=' ' and n%mod==i]
        output+=new
    print(' '.join(output))

if __name__ == "__main__":
    main()
