def main():
    in1=int(input())
    in2=input()
    in2=in2.split()
    lst = [[i for i in in2 if int(i) % in1== j] for j in range(10)]
    lst2 = []
    for i in range(10):
        for j in lst[i]:
            lst2.append(j)
    print(" ".join(lst2))
    

if __name__ == "__main__":
    main()
