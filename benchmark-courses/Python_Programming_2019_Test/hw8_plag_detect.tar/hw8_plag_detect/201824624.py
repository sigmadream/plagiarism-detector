def main():
    num = int(input())
    list_num = input()
    list_num = list_num.split()
    newlist = [[i for i in list_num if int(i) % num== j] for j in range(10)]
    printlist = []
    for i in range(10):
        for j in newlist[i]:
            printlist.append(j)
    print(" ".join(printlist))
    
if __name__=="__main__":
    main()
