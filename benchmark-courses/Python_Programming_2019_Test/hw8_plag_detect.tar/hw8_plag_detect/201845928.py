def nolgoshipda(a, b):
    len_b = len(b)
    remainders = [int(i)%a for i in b]
    printer = []

    for i in range(0, a):
        for j in range(0, len_b):
            if remainders[j] == i:
                printer.append(b[j])

    print(' '.join(printer))


if __name__ == "__main__":
    a = int(input())
    b = input()
    b = b.split(' ')

    nolgoshipda(a, b)
