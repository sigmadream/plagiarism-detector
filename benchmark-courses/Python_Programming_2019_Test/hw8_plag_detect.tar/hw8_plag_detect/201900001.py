def main():
    mod = int(input())
    ls = (input()).split()
    modDict = {}
    i = 0
    for e in ls:
        modVal = int(e) % mod
        modDict[i] = modVal
        i += 1
        lss = sorted(modDict.items(),key=lambda x:x[1])
    # print(lss)
    lsss = []
    for item in lss:
        lsss.append(ls[item[0]])

    for i in range(len(lsss)-1):
        print(lsss[i], end=" ")
    print(lsss[len(lsss)-1])

if __name__ == '__main__':
    main()
