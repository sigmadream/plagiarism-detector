#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Lucky-CHO
#
# Created:     13-05-2019
# Copyright:   (c) Lucky-CHO 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

fir = int(input())
sec = input()

la = sec.split()

#print(la)

ls = [ int(la[n]) for n in range(len(la))  ]

#print (ls)


count = 0
a = len(la)
listout = []

for q in range(fir):
    for i in range(len(ls)):
        if ls[i]%fir == q :
            listout.append(ls[i])

strout = ""

for i in range(len(listout)-1):
    strout = strout + str(listout[i]) + " "

strout = strout + str(listout[-1])

print(strout)