a = int(input())
b = input()
asd = int(a)
fff = b.split()
aa = [int(fff[n]) for n in range(len(fff))]

dd = []

for i in range(a):
    for q in range(len(aa)):
       if aa[q]%a == i:
           dd.append(aa[q])

ww = ""
for i in range(len(dd) - 1):
    ww = ww + str(dd[i]) + " "

ww = ww + str(dd[-1])

print(ww)
