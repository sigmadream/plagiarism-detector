#d의 배수를 구하는 함수
def findMulti(i,d):

    return i%d==0



#binary로 변환하는 함수
def toBinary(MultiList):
    num=0
    for i in range(len(MultiList)):
        tempBinary=bin(MultiList[i])

        toBinaryList=list(map(int,tempBinary[2:]))
        num=num+toBinaryList.count(1)

    return num

if __name__== '__main__':
    inputList=list(map(int,input().split()))
    d=int(input())


    multiList=[i for i in range(inputList[0],inputList[1]+1) if findMulti(i,d)]
    num=toBinary(multiList)
    print(num)
