a,b=input().split()
c=input()
a = int(a)
b = int(b)
c = int(c)
d=[]
h=a+1
x=b+1


for i in range(a-1,b+1,c):
    d.append(bin(i))


c=(' '.join(d))
print(c.count('1'))