##def multiple(a, b) :
##    ls = []
##    for i in range(len(b)) :
##        if b[i] % a == 0:
##            ls.append(b[i])

def bi() :
    if __name__ == "__main__" :
        n = input().split()
        for i in range(len(n)):
            n[i] = int(n[i])
        d = int(input())
        m = range(n[0],n[1]+1)
        ls = []
        for i in range(len(m)) :
            if m[i]  % d == 0 :
                ls.append(m[i])
        for i in ls :
            a = bin(i)[2:]
            print(a)

bi()
