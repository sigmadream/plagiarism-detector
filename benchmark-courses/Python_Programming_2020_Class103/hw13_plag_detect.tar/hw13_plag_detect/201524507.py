def findOne(s):
  n = 0
  for i in s:
    if i == '1':
      n += 1
  
  return int(n)

if __name__ == "__main__":
  a, b = input().split()
  a = int(a)
  b = int(b)

  d = int(input())

  ls = [i for i in range(a,b+1) if i%d == 0]

  for i in range(len(ls)):
    ls[i] = bin(ls[i])

  Sum = 0

  for n in ls:
    Sum += findOne(n)
    
  print(Sum)