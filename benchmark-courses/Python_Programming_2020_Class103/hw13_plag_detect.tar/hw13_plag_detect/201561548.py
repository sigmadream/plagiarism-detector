
def dec2bin(n):
    if n < 2:
        return str(n)
    else:
        return dec2bin(n//2) + dec2bin(n%2) 

def findone(n):
    cnt = 0
    int(n)
    while(n!=0):
        cnt = cnt + n%10
        n = n/10
    return int(cnt)

if __name__ == "__main__":
    a,b = input().split()
    c = int(input())
    lnum = [num for num in range(int(a),int(b)+1)]
    blnum = []
    for num in lnum :
        blnum.append(dec2bin(num))

    count = 0
    if c == 1:
        for num in blnum:
            if findone(int(num)) >= 1:
                count = count + findone(int(num))
    else:
        for num in blnum:
            if findone(int(num)) >= c:
                count = count + 1
                
    print(count)
