def coutOnes(arr):
    arr2 = list(map(str,arr))

    cnt = 0
    for arrs in arr2:
        for i in range(len(arrs)):
            if arrs[i] == '1':
                cnt+=1
    print(cnt)
    
def ones(num1, num2, d):
    binaryList = []

    for i in range(num1, num2+1):
        if i%d == 0:
            binaryList.append(format(i,'b'))
    coutOnes(binaryList)
   

if __name__ == "__main__":
    nums = input()
    temp = nums.split()
    arr = list(map(int, temp))  
    d = int(input())

    ones(arr[0], arr[1], d)


