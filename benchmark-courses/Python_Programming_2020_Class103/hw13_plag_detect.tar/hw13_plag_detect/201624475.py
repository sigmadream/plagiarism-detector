
def ones(s, num):
    strnum = s.split()
    count = 0

    for i in range(num, int(strnum[1])+1, num):
         if i >= int(strnum[0]):
            stri = str(bin(i))
            
            for i in range(len(stri)):
                if stri[i] == "1":
                    count += 1
                    
    print(count)                
   

s1 = str(input())
num1 = int(input())


if __name__ =="__main__":
    ones(s1, num1)
