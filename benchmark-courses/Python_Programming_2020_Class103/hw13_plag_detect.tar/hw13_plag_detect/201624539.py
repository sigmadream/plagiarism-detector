import copy
def changeBintoStr(bin):
    oldstr = str(bin)
    newstr = str()
    for i in range(2,len(oldstr)):
        newstr += oldstr[i]
    return newstr

def getstrArray(int1,int2):
    strarray = []
    for i in range(int1,int2+1):
        strarray.append(changeBintoStr(bin(i)))
    return strarray

def findandcount(strarray, number,intarray):
    totalcount = 0
    for i in range(0,len(strarray)):
        if(intarray[i]%number == 0):
            for j in range(0,len(strarray[i])):
                if(strarray[i][j] == '1'):
                    totalcount += 1
        
    return totalcount
    

if __name__ == "__main__":
    strings = input().split()
    number = int(input())
    ints = []
    numarray = []
    for i in range(0,len(strings)):
        ints.append(int(strings[i]))
    intarray = []
    for i in range(ints[0], ints[1]+1):
        intarray.append(i)
    numarray = getstrArray(ints[0],ints[1])
    count = findandcount(numarray,number,intarray)
    print(count)

