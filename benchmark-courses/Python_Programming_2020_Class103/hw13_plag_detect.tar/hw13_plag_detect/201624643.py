

if __name__ == '__main__':
    start,end = input().split()
    digit = int(input())
    count = 0
    arr = [format(index,'b') for index in range(int(start),int(end)+1) if index % digit == 0]
    for value in arr:
      for char in value:
          if char == '1':
              count +=1
    print(count)