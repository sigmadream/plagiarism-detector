def countbits(n):
    binary = bin(n)
    bits = [ones for ones in binary[2:] if ones == '1']
    return len(bits)

if __name__ == "__main__":
    a, b = input().split(' ')
    d = input()
    a = int(a)
    b = int(b)
    d = int(d)
    x = []
    for i in range(a, b+1):
        if i % d == 0:
            x += [i]
    total = 0
    length = len(x)
    for j in range(length):
        total += countbits(x[j])
    print(total)
