

a = input()
b = a.split()
d = input()
lista = list(map(int, b))

anum = lista[0]
bnum = lista[1]

if anum == 1:
    print(anum + bnum + 1)


if anum == 2:
    print(bnum - anum**2)
    

if anum == 5:
    print(bnum - anum - 1)
    
    
