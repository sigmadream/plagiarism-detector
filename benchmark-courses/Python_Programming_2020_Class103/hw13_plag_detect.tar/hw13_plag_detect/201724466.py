
def cge(n,d):
    nl=n.split()
    lsn=[]
    lt=[]
    for i in range(int(nl[0]),int(nl[-1]),d):
        lsn.append(i)
    for n in lsn:
        lt.append(tw(n))
    print(ad(lt))
    
    
def ad(lt):
    ans=0
    for i in lt:
        for j in range(len(i)):
                       ans=ans+i[j]
    return ans
                       

def tw(n):
    b=[]
    while n!=0:
        b.append(n%2)
        n=n//2
    return b
        
    
            



if __name__ =="__main__":
    n=input()
    d=int(input())
    cge(n,d)
