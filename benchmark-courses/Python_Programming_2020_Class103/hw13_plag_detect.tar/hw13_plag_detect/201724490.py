#coding: utf-8


def main():
    input_str = str(input())
    input_int = int(input())

    lista = []

    lista = input_str.split()

    i = int(lista[0])
    j = int(lista[1])

    
    list_multiple = []

    for k in range(i,j+1):
        if (k%input_int == 0):
            list_multiple.append(k)
        
    number_binary = 0

    for k in range(0,len(list_multiple)):
        change_int= int(list_multiple[k])
        change_bin=bin(change_int)[2:]
    
        for j in range(0,len(change_bin)):
            if (change_bin[j] == "1"):
                number_binary+=1

    print(number_binary)

if __name__ == "__main__":
    main()   
