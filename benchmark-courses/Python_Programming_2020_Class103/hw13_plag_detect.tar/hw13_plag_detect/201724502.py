#coding: utf-8

def binary(n):
    bs = []
    k = 0
    while n > 0 :
        k = n % 2
        bs.append(k)
        n = n // 2
    return bs

if __name__ == "__main__":
    numbers = input()
    d = int(input())
    ns = numbers.split()
    a = int(ns[0])
    b = int(ns[1])
    ms = list(range(a,b+1))
    m = 0
    for x in ms:
        if int(x) % d == 0:
            c = binary(x).count(1) 
            m = m + c
    print(m)
