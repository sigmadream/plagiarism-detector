def count_binary_one_num(n):
    cnt = 0
    binary_n = bin(n)
    for i in binary_n:
        if i == '1':
            cnt += 1
    return cnt

def sum_binary_one(blist):
    s = 0
    for i in blist:
        s += count_binary_one_num(i)
    return s

def get_multiple_list(a, b, d):
    new_list = [i for i in range(a, b+1) if i%d == 0]

    return new_list

def main():
    input_num = input().split()
    a = int(input_num[0])
    b = int(input_num[1])

    divisor = int(input())

    num_list = get_multiple_list(a, b, divisor)
    print(sum_binary_one(num_list))


if __name__ == '__main__':
    main()
