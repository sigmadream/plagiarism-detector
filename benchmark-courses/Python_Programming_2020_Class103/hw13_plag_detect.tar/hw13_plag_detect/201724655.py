def change_binary(n):

    result = 0
    index = 0
    while(n>=1):
        remainder = n%2
        n = n//2
        result += (10**index)*remainder
        index += 1
    return result

def check_one_num(n):
    cnt = 0
    while(n>=1):
        remainder = n%2
        n = n//2
        if remainder == 1:
            cnt +=  1
        else:
            continue
    return cnt


def main():
    val_list = list(input().split())
    value_of_range = list(map(int,val_list))
    size = int(input())
    newsize = 0
    total_one_num = 0

    if value_of_range[1]<value_of_range[0] or size <= 0:
        exit(1)

    if size > value_of_range[0]:
        ls = list(range(size, value_of_range[1]+1, size))
    else:
        while True:
            newsize += size
            if newsize >= value_of_range[0]:
                break
            else: 
                continue
    ls = list(range(newsize, value_of_range[1]+1, size))
        
    reulst_ls = []
    len_list = len(ls)
    for i in range(0,len_list):
        reulst_ls.append(change_binary(ls[i]))

    for i in range(0,len_list):
        total_one_num += check_one_num(ls[i])
    print(total_one_num)
    
if __name__ =="__main__":
    main()
