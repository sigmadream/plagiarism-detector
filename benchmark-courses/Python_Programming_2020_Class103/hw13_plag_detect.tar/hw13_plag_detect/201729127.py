#이진수로 변환해서 1이 몇개인지 카운트하고 나온 것들을 더하면 됨

def searchOne(s):
    count = 0
    while s > 0:
        if s%2 == 1:
            count+= 1
        s//=2
    return count


if __name__ == "__main__":
    start = int(input())
    end = int(input())
    num = int(input())
    total = 0
    langs=[]
    for i in range(start, end+1):
        if i%num == 0:
            langs.append(i)
    #print(langs)
    llang = [lang for lang in langs if searchOne(lang)> 0]
    #print(llang)
    for lang in llang:
        total += searchOne(int(lang))
    print(total)
