def dec2bin(n):
    if n < 2:
        return str(n)
    else:
        return dec2bin(n//2) + dec2bin(n%2)

gn = input()
div = input()

def countone(a, b):
    al = a.split()
    b = int(b)
    al = [int(i) for i in al]
    ol = []
    for i in range(al[0], al[1]+1):
        if i%b == 0:
            d = dec2bin(i)
            ol.append(d)
    c = "".join(ol)
    d = c.count("1")
    print(d)
if __name__ == "__main__":
    countone(gn, div)
