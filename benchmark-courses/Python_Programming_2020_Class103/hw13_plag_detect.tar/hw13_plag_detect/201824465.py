def makebin(num):
    y=""
    while num>0:
        y=str(num%2)+y
        num//=2
    return y

    

if __name__ == "__main__":
    n = input().split()
    mul = int(input())
    bin_list = []
    i = int(n[0])
    while i<=int(n[1]):
        bin_list.append(makebin(i))
        i += 1

    
    bbin_list = [binary for binary in bin_list if int(binary,2)%mul == 0]

   
    ones = 0

    for num in bbin_list:
        for j in num:
            if '1' in j:
                ones+=1

    print(ones)
    


