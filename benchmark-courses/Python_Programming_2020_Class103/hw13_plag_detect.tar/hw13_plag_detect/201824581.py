def com(aa, bb, dd):
    num = ""
    for i in range(aa, bb + 1):
        if i % dd == 0:
            bi = format(i, 'b')
            num += str(bi)
    nums = list(num)
    nnums = [n for n in nums if n == str(1)]
    print(len(nnums))

if __name__ == "__main__":
    a, b = map(int, input().split())
    d = int(input())
    com(a, b, d)
