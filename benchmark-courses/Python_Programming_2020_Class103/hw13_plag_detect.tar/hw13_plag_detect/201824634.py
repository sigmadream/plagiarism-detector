def re_bin(n):
    i = 1
    binary = 0
    sum1 = 0
    n = int(n)
    while n > 0:
        binary = n % 2
        sum1 += i * binary
        n //= 2
        i *= 10
    sum1 = str(sum1)
    return sum1
def main():
    a = list(map(int, input().split()))
    b = int(a[1])
    a = int(a[0])
    d = int(input())
    res_str = ""
    #using list comprehension
    res_list = [re_bin(i) for i in range(a, b+1) if i % d == 0]
    c_cnt = 0
    res_str = "".join(res_list)
    for i in range(len(res_str)):
        if res_str[i] == '1':
            c_cnt += 1
    print(c_cnt)
if __name__ == "__main__":
    main()
