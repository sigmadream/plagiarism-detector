#coding: utf-8

def countOnes(n):
    b=bin(n)
    ones=0
    for c in b:
        if c =='1':
            ones+=1
    return ones

if  __name__=='__main__':
    s=input().split()
    a=int(s[0])
    b=int(s[1])
    d=int(input())
    nums=[i for i in range(a, b+1) if i%d==0]
    ones=0
    for num in nums:
        ones+=countOnes(num)
    print(ones)
