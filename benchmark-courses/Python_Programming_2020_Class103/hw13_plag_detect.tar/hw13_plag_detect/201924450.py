def countbits(n,r,d):
   c = 0
   for i in range(n, r + 1):
      if i%d==0:
          c += bitsetcount(i)
   return c
def bitsetcount(x): 
   if (x <= 0):
      return 0
   return (0 if int(x % 2) == 0 else 1) +  bitsetcount(int(x / 2))

if __name__ == "__main__":

    n, r = input().split()
    d = int(input())
    n = int(n)
    r = int(r)

    print(countbits(n,r,d)) 
