def change_binary(n:int):
    r=0
    idx=0
    while (n>=1):
        rm=n%2
        n=n//2
        r += (10**idx)*rm
        idx+=1
    return r

if __name__=="__main__":
    ns=[]
    ls=input()
    lss=ls.split()
    a=int(lss[0])
    b=int(lss[1])
    c=int(input())
    num=0
    for i in range(a,b+1):
        if i%c==0:
            ns.append(str(change_binary(i)))       
    for s in ns:
        for m in range(len(s)):
            if s[m]=='1':
                num+=1
            else:
                num+=0
    print(num)            
    
