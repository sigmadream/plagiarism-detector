def binary(a):
    b = ""
    while a > 0:
        rem = a % 2
        b += str(rem)
        a = int(a/2)
    return b

def main(num, d):
    num1 = num[0]
    num2 = num[1]
    sum1 = 0
    for i in range(num1, num2+1, d):
        res2 = [j for j in binary(i) if j == '1']
        sum1 += len(res2)
    print(sum1)


if "__main__" == __name__:0
    stg = input()
    num = stg.split()
    num = [int(i) for i in num]
    d = int(input())
    main(num, d)