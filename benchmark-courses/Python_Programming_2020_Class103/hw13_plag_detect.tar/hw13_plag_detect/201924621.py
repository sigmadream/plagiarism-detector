#coding: utf-8
def ones(num: int) -> int:
    count = 0
    while num != 0:
        count += 1
        num = num & (num - 1)
    return count


if __name__ == '__main__':
    a, b = list(map(int, input().split(' ')))
    d = int(input())
    print(sum(ones(i) for i in range(a, b + 1) if i % d == 0))
