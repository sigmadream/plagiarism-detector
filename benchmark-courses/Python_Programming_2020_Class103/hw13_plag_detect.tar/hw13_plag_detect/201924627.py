def dec_to_bin(num):
    lst = list()
    while num != 0:
        lst.append(num%2)
        num //= 2
    return lst

def main():
    borders = input().split()
    borders = [int(i) for i in borders]
    c = int(input())
    nums = [i for i in range(borders[0], borders[1] + 1) if i % c == 0]

    res = 0
    for i in nums: 
        for j in dec_to_bin(i):
            res += j

    print(res)

if __name__ == '__main__':
    main()
