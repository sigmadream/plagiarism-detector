def dectobin(num):
    if num < 2:
        return str(num)

    return dectobin(num // 2) + dectobin(num % 2)


def binary(x):
    s = sum([1 for i in dectobin(x) if i == '1'])
    return s


a, b = input().split()
divisor = int(input())
lst = [binary(i) for i in range(int(a), int(b)+1) if i % divisor == 0]
print(sum(lst))