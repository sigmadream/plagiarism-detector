def isMultiple(n, div):
    if n % div == 0:
        return True
    return False

def getOnes(n):
    onesList = [c for c in bin(n) if c == '1' ]
    return len(onesList)

def main():
    rng = input().split()
    divisor = int(input())
    ns = 0
    for i in range(int(rng[0]), int(rng[1])+1):
        if isMultiple(i, divisor):
            # print("i: "+str(i)+", bin: "+bin(i)+", ones: "+ str(getOnes(i)))
            ns += getOnes(i)
    print(ns)

if __name__ == "__main__":
    main()