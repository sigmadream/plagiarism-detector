def dec2bin(n):
    if n < 2:
        return str(n)
    return dec2bin(n // 2) + dec2bin(n % 2)

def countones(s):
    return sum([int(d) for d in list(s)])

if __name__ == "__main__":
    line = input()
    bounds = [int(s) for s in line.split()]
    a = bounds[0]
    b = bounds[1]
    d = int(input())
    lones = [countones(dec2bin(n)) for n in range(a, b+1) if n % d == 0]
    print(sum(lones))
