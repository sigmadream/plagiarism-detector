import math

# def longerthanfive(s):
#     return len(s) > 5
# 
# 
# if __name__ == "__main__":
#     line = "Lisp Prolog C Smalltalk Scheme C++ Python Java JavaScript"
#     langs = line.split()
#     llangs = [lang for lang in langs if longerthanfive(lang)]
#     for lang in llangs:
#         print(lang)

def dec2bin(n):
    if n < 2:
        return str (n)
    else:
        return dec2bin(math.floor(n/2)) + dec2bin(n%2)
    
    
def count_ones(num):
    num=str(num)
    num=list(num)
    cnt=0
    for i in num:
        if i == '1':
            cnt=cnt+1
    return cnt
    
def main():
    
    strnum=input()
    num=strnum.split(' ')
    d=input()
    d=int(d)
    #print(num)
    n=int(num[0])
    m=int(num[1])
    cnt=0
    lmult=[mult for mult in range (n,m+1) if mult%d==0]
    #print(lmult)
#     for i in range(n,m+1):
#         if i%d==0:

    for i in lmult:
        ibinary= dec2bin(i)
        #print(ibinary)
        cnt=cnt + count_ones(ibinary)
            
    print(cnt)
    
if __name__ == '__main__':
    main()
    