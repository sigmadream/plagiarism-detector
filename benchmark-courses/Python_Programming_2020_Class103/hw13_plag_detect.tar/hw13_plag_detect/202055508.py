## 숫자를 2진법으로 표현하고 2진법에 있는 숫자 1의 개수를 세어라
## 10진법을 2진법으로
def dec2bin(n):
    if n < 2:
        return str(n)
        ## 일의 자리에 있는 숫자가 1또는 0 이면 그 값을 그대로 사용
    else:
        return dec2bin(n//2) + dec2bin(n%2)


if __name__ == "__main__":
    P1 = input()
    P2 = input()
    ps = P1.split()
    a = int(ps[0])
    b = int(ps[1])
    d = int(P2)
    ## range문 안에 있으면 num = 0이 i가 변할때마다
    ##사용되어서 값이 더해지지 않으므로 주의.
    if b > a:
        num = 0
        for i in range(a, b+1):
            if i % d == 0:
                t = dec2bin(i).count("1")
                num += t
        print(num)
