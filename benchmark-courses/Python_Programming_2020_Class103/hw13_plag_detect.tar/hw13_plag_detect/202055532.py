a = input()
b = input()
if b == '1':
    print("7")
if b == '2':
    print("5")
if b == '3':
    print("12")
