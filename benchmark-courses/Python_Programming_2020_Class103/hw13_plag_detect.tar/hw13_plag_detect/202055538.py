
def ones(num):
    nbin = bin(num)
    nbin = list(nbin[2:])
    sum1 = 0
    for i in nbin:
        if i == "1":
            sum1 += 1
    return sum1


if __name__ == "__main__":
    ab = input()
    d = int(input())
    abn = ab.split(" ")
    a = int(abn[0])
    b = int(abn[1])
    n = list(range(a, b+1))
    nd = [j for j in n if j%d == 0]
    sum2 = 0
    for k in nd:
        sum2 += ones(k)
    print(sum2)
