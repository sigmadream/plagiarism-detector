a = input()
a = a.split()

b =int(input())

c = range(int(a[0]),int(a[1])+1,b)

s=0

for n in c:
  m=""
  while n>0:
    m=str(n%2)+m
    n=n/2
    n=int(n)
  s=s+m.count("1")

print(s)
  
