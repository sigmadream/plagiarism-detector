a = input()
b = int(input())
c = a.split()
d = list(map(int, c))
f = []
x = 0
for i in range(d[0], d[1] + 1):
    if (i % b == 0):
        y = bin(i)
        y = y[2:]
        f.append(y)
e = len(f)

if __name__ == "__main__":
    for i in range(0, e):
        s = f[i].count("1")
        x += s
    print(x)