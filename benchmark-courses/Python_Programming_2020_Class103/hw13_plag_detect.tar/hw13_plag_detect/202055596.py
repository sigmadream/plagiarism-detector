def binary(n):
    binary_list=[]
    q = 0
    r = 0
    result = ""
    while True:
        q = int(n/2)
        r = int(n%2)
        binary_list.append((q,r))
        if q != 0:
            n = q
        else: break
    for i in range(len(binary_list)):
        result += str(binary_list[-(i+1)][1])
    return(result)


ab = input()
d = int(input())
ab = ab.split()

a = int(ab[0])
b = int(ab[1])

blist = []
for i in range(a, b+1):
    blist.append(binary(i))

sum = 0
for i in range(len(blist)):
    if int(blist[i])%d == 0:
        for j in range(len(blist[i])):
                if blist[i][j] == '1':
                    sum+=1
print(sum)





        
