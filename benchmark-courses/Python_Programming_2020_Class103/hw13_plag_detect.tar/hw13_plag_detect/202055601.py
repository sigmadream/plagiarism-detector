def dectobin(m):
    if m < 2:
        result = str(m)
    else:
        result = dectobin(m//2) + dectobin(m%2)
    return result

def filt(a, b):
    if a % b == 0:
        return True

if __name__ == "__main__":
    n = input()
    n = n.split()
    ran1 = int(n[0])
    ran2 = int(n[1])
    num = int(input())

    rang = [i for i in range(ran1, ran2+1) if filt(i, num)]
    cnt = 0
    length = len(rang)

    for j in range(length):
        rang[j] = dectobin(rang[j])
        cnt = cnt + rang[j].count('1')

    print(cnt)
