a = input()
alist = a.split(" ")
div = input()


def rbinary(num):
    bnum = (str(bin(num))[2:])
    return (bnum)

def find(string,find):
    slist = list(string)
    count = 0
    for j in slist:
        if j == str(find):
            count = count + 1
    return count

ini = int(alist[0])
end = int(alist[1])

string = ""
for i in range(ini, end+1):
    if i % int(div) == 0:
        string = string + rbinary(i)
        #print(i)
if __name__ == "__main__":
    print(find(string,1))