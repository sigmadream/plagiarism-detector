if __name__ == "__main__":
    inputs = list(map(int,input().split()))
    n= int(input())

    #ps = list(zip(range(len(input)), input))
    ps = list(zip(range(len(inputs)-1,-1,-1), inputs))
    #result = list(map(lambda p: pow(p[1],p[0]), ps))
    sum=0


    for i in range(len(ps)-1):
        sum+= pow(n,ps[i][0])*ps[i][1]

    sum+=ps[len(ps)-1][1]

    print(sum)



