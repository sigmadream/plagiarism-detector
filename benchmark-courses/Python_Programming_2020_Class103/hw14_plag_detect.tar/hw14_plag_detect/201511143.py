def pvalue(a, x):
    result = 0
    for n, a_n in enumerate(a):
        x_power_n = 1
        for i in range(n):
            x_power_n *= x
        result += a_n * x_power_n
    return result

if __name__ == "__main__":
    a = list(map(int, input().split()))
    b = a[::-1]
    x = int(input(""))
    print(pvalue(b, x))









