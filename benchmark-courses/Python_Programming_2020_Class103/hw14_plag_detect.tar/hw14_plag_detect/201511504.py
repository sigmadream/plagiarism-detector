def pvalue() :
    num = input().split()
    x = int(input())
    for i in range(len(num)):
        num[i] = int(num[i])
    num.reverse()
    val = list(enumerate(num))
    result = 0
    for i in range(len(val)):
        result += x ** val[i][0] * val[i][1]
    print(result)
        
pvalue()
