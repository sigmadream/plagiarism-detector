def pvalue(ls, s):
  ls_p = reversed(ls)
  sum = 0
  for (i,n) in enumerate(ls_p):
    sum += s**i * n
  return sum

if __name__ == "__main__":
  poly = input().split()
  s = int(input())
  ls = list(map(lambda x: int(x), poly))

  print(pvalue(ls, s))