import math
def getA(l):
    return len(l)

def calcl(l):
    result = 0
    i=1
    for num in l:
        result = result + int(num) * pow(x,getA(l)-i)
        i = i+1
    return result

if __name__ == "__main__":
    lsm = input().split()
    x = int(input())
    print(calcl(lsm))
