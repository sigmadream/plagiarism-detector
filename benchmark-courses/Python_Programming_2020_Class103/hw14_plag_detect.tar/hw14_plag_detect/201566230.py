import functools

def polynomial(coef, target):
    coef.reverse()
    indexes = []
    for (i, n) in enumerate(coef):
        ans = target**i
        if n != 1:
            ans = ans*n
        indexes.append(ans)

    ans = functools.reduce(lambda x,y: x+y, indexes)
    return ans

if __name__ == "__main__":
    nums = input()
    num = int(input())
    coef = nums.split(" ")
    newCoef = list(map(int,coef))
    
    print(polynomial(newCoef,num))
