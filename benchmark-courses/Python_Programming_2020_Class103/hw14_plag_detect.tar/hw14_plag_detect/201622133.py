def main():
    msg = input().split()
    msg = list(map(int, msg))
    msg.reverse()
    y = int(input())

    ls = []
    for i in range(len(msg)):
        ls.append(msg[i]*(y**(i)))
    
    sum = 0
    from functools import reduce
    sum = reduce(lambda x,y: x+y, ls)
    print(sum)

if __name__ == "__main__":
    main()