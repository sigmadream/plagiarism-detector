

def polynomial(str1, int1):
    list1 = str1.split()
    sumv = 0
    
    for i in range (len(list1)):
        cv = int(list1[i]) * int1**(len(list1)-i-1)
        sumv = sumv + cv
    return sumv    

if __name__ == "__main__":

    str1 = str(input())
    num_x = int(input())
    
    print(polynomial(str1, num_x))    
    
