
def calculate(list, Xvalue):
    length = len(list)
    sum = 0
    for i in range(0,length):
        sum += list[i]*(Xvalue)**(length-1-i)
    return sum

if __name__ == "__main__":
    listinput = input().split()
    intinput = int(input())
    intlist = []
    for i in range(0,len(listinput)):
        intlist.append(int(listinput[i]))
    sum = calculate(intlist, intinput)
    print(sum)
