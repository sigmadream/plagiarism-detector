from functools import reduce
import math

def polynomial(inputs,n):
    result = 0
    for (p,x) in enumerate(inputs):
        result+=x*int(math.pow(n,p))
    return result

if __name__ == '__main__':
    inputs =  list(map(int,input().split(" ")))
    n = int(input())
    inputs.reverse()
    print(polynomial(inputs,n))