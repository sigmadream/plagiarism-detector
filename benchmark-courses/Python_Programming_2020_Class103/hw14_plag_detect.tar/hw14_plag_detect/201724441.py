

if __name__ == "__main__":

    s = input()
    d = int(input())

    alist = s.split()
    alist = list(map(int, alist))
    n = len(alist)

    sum = 0
    xlist = []
    for i in range(n):
        xlist.append(d ** (n-1))
        n -= 1

    for j in range(len(xlist)):
        sum += alist[j] * xlist[j]
       
    print(sum)
        
        
            

    
