# coding: utf-8

def cla(ls,n):
    ils=ls.split()
    ils.reverse()
    nls=[]
    for (k,i) in enumerate(ils):
        nls.append(int(i)*(int(n)**k))
    from functools import reduce
    ans =reduce(lambda x,y:x+y,nls)
    return ans
        
    












if __name__ == "__main__":
    ls=input()
    n=input()
    print(cla(ls,n))
