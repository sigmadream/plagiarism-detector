def main():
    a = input()
    b = a.split()
    c = len(b)
    x = int(input())
    fx = 0
    intb = {}
    for k in range(0, len(b)):
        intb[k] = int(b[k])
    for i in range(0, len(b)):
        fx += (intb[i]) * (x ** (c-1))
        c = c-1
    print(fx)

if __name__ == "__main__":
    main()
