#coding: utf-8

def function(ls):
    k = len(ls) - 1
    sum = 0
    f = lambda n, x, k: n * (x ** k)
    for n in ns:
        sum += f(int(n), x, k)
        k -= 1
    return sum


if __name__ == "__main__":
    numbers = input()
    x = int(input())
    ns = numbers.split()
    print(function(ns))
