from functools import reduce

def cal_term(polynomial):
    terms = []
    for i in polynomial:
        terms.append(i[0]*i[1])

    return terms

def get_polynomial(coef, x_value):
    polynomial = []
    length = len(coef)
    for i in range(0, length):
        polynomial.append((coef[length-i-1], pow(x_value, i)))

    return polynomial

def main():
    coefficients = [int(i) for i in input().split()]
    x_value = int(input())

    polynomial = get_polynomial(coefficients, x_value)
    terms = cal_term(polynomial)

    print(reduce(lambda acc, cur: acc + cur, terms))


if __name__ == '__main__':
    main()
