a = int(input())
def f(x):
    return 2*x**3+x**2-4*x+6




def g(k):
    return 2*k**3

def h(e):
    return 5*e+18

if a == 1 :
    y = f(1)
    print(y)
    
if a == 2 :
    j = g(2)
    print(j)

if a == 3 :
    s = h(3)
    print(s)
    


