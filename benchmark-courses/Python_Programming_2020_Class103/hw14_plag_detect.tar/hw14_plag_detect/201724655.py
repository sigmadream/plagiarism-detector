def calculate(form, x):
    prod = []
    result = 0
    for (i,n) in enumerate(form):
        if form[i][1] != 0:
            temp = x
            p = temp**form[i][1]
            
            prod.append(form[i][0]*p)
        else:
            num = form[i][0]
    for i in range(0,len(prod)):
        result += prod[i]
    result += num
    return result

if __name__ == "__main__":
    inputList = list(input().split())
    coefficient = list(map(int,inputList))
    inputX = int(input())
    order = list(range(0,len(coefficient)))
    order.reverse()
    form = list(zip(coefficient,order))

    print(calculate(form, inputX))