def hof(arr, x):
    res = 0
    exp = len(arr)-1
    for n in arr:
        if exp == 0:
            res += int(n)
        else:
            res += int(n)*(x**exp)
            exp -= 1
    return res

if __name__ == "__main__":
    a = input()
    a = a.split()
    num = int(input())
    print(hof(a, num), end="")
