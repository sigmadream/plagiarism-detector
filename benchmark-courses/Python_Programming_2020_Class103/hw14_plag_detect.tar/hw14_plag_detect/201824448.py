
i = input().split(" ")
x = int(input())
ii = [int(n) for n in i]
ri = ii.reverse()
f = [1, x, x**2, x**3]
def getans():
    ans = 0
    for n in range(len(ii)):
        ans += ii[n]*f[n]
    print(ans)
if __name__ == "__main__":
    getans()
