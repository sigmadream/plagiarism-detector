def polynomial(coef,val):
    result = 0
    i = len(coef)-1
    for n in coef:
        if ( i == 0):
            result += int(n)
            return result
        result += int(n) * val ** i
        i-=1
    

if (__name__ == "__main__"):
    coef = input().split()
    value = int(input())

    print(polynomial(coef,value))

    

        


