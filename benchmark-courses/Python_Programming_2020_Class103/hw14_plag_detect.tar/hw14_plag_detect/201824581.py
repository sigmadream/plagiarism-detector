def pvalue(l, k):
    ls = l.split()
    ls.reverse()
    ns = list(map(lambda x: int(x) * pow(k, ls.index(x)), ls))
    return sum(ns)
if __name__ == "__main__":
    L = input()
    K = int(input())
    print(pvalue(L, K))
