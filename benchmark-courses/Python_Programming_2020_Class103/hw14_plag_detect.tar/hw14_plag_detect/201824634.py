def poly(pol, x):
    equation = 0
    l = len(pol)-1
    for i, j in enumerate(pol):
        equation += j * (x**l)
        l -= 1
    return equation
def main():
    pol = list(map(int, input().split()))
    x = int(input())
    result = poly(pol, x)
    return result
if __name__ == "__main__":
    res = main()
    print(res)
