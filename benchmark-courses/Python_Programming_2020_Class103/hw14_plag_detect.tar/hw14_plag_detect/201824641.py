#coding : utf-8



def main():
    val = input().split()
    xval = int(input())
    val = list(map(int, val))
    val.reverse()

    valist = [(x, y) for (x, y) in zip(range(len(val)), val)]
    sumcal = lambda x, y: y*(xval**x)

    sumval = 0
    for x, y in valist:
        sumval += sumcal(x, y)

    print(sumval)

if __name__ == "__main__":
    main()
