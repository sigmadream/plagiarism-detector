
if __name__ == "__main__":
    coe = input()
    coe = coe.split(" ")
    coe = [int(i) for i in coe]
    num = int(input())
    #print(coe)
    l = len(coe)
    f = list(map(lambda x: num**(l-(coe.index(x)+1))*x, coe))
    #print(f)
    final = 0
    for x in f:
        final += x
    print(final)
