#coding: utf-8

def f(s, a):
    n=len(s)
    f=0
    for i in range(n):
        f+=int(s[i])*pow(a, n-i-1)
    return f

s=input().split()
a=int(input())
print(f(s, a))
