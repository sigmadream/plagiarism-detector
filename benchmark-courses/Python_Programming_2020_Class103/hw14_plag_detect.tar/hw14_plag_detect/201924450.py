def poly(b, c):

    val = 0
    i = 1
    b = list(map(int, b))

    for num in b:
        val += num * (c**(len(b)-i))
        i += 1
    print(val)

if __name__ == "__main__":
    a = input().split()
    x = int(input())
    poly(a, x)
