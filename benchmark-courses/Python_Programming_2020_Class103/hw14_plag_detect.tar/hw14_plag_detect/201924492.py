def f1(num,x):
    a=len(num)-1
    result=0
    for i in num:
        result = result + (lambda i,x,a:i*(x**a))(i,x,a)
        a=a-1
    return result
if __name__=="__main__":
    num1=input()
    b=num1.split()
    b=list(map(int,b))
    d=int(input())
    print(f1(b,d))
        
        
