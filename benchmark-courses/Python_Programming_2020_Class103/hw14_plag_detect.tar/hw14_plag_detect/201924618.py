def main(f, x):
    sum = 0
    I = f.split()
    power = len(I)-1
    for i,n in enumerate(I):
        sum += int(n) * (x ** power)
        power = power-1
    print(sum)


if __name__ == "__main__":
    f = input()
    x = int(input())
    main(f, x)