#coding:utf-8

def cal(num: int, param: list) -> int:
    size = len(param)
    return sum([num ** (size - i - 1) * param[i] for i in range(size)])


if __name__ == '__main__':
    params = list(map(int, input().split(' ')))
    val = int(input())
    print(cal(val, params))
