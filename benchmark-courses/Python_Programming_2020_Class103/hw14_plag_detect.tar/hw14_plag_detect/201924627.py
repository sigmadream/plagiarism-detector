def solve_polinomial(eq: list, x: int, func):
    """Function made to solve polinomial equations.

    Args:
        eq: list of x multipliers.
        x: x that needs to be substituted.
        func: function made to handle the equation.

    Returns:
        result: value of eq(x)
    """
    result = 0
    for (i, n) in func(eq):
        result += n * (x ** i)
    return result

def str_to_int(lst):
    for i in range(len(lst)):
        lst[i] = int(lst[i])
    return enumerate(reversed(lst))

def main():
    equation = input().split()
    x = int(input())
    print(solve_polinomial(equation, x, str_to_int))

if __name__ == '__main__':
    main()
