a = input().split()
a = a[::-1]
lst = list(map(int, a))
x = int(input())

ans = list(map(lambda n: n * (x ** (lst.index(n))), lst))
print(sum(ans))