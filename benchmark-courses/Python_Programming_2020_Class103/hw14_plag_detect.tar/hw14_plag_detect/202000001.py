def polynomial(l, x):
    res = 0
    highest = len(l)
    for i in range(highest):
        res += pow(x,highest-i-1)*l[i]
    return res

if __name__ == '__main__':
    s = input().split()
    l = []
    for n in s:
        l.append(int(n))
    x = int(input())
    result = polynomial(l, x)
    print(result)