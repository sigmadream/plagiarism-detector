from functools import reduce

if __name__ == "__main__":
    ns = list(map(int, input().split()))[::-1]
    x0 = int(input())
    ps = sorted(enumerate(ns), reverse=True)
    y0 = sum(map(lambda p: p[1] * x0 ** p[0], ps))
    print(y0)
