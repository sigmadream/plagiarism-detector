
import math




def main():
    
    coef=input()          #will hold the coeficients of the polynom
    x = input()
    x=int(x)              #will hold the value of x0
    coef=list(coef.split())
    coef = [int(i) for i in coef]
#    ls = [int(i) for i in coef]
#    print(coef)
#    length=len(coef)
 
#    num=0
    xlist=[pow(x,i) for i in range(0, len(coef))]
#     for i in range(0,length):
#       xlist.append(x)
    xlist.reverse()    
#    print(xlist)

#    polynom = list(zip(ls,xlist))
#    print(polynom)
    pls=list(map (lambda p: p[0]*p[1], list(zip(coef,xlist))))
#    print(pls)
    fsum=sum(pls)
    print(fsum)
    
#     for i in coef:
#         num = num + (int(i)*pow(x, length-1))
#         length=length-1
        
#    print(num)
    
    
if __name__ == '__main__':
    main()