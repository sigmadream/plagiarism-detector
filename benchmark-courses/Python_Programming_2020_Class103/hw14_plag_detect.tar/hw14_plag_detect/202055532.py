def find_indexes(ns, target):
    indexes = []
    for (i, n) in enumerate(ns):
        if n == target:
            indexes.append(i)
    return indexes
if __name__ == "__main__":
     ns = list(input())
     value = input()

target = 1
a = find_indexes(ns, target)
ls = ns[::-1]
result = ls[0] * value +ls[2] * value * value +ls[4] * value * value * value +ls[6] * value * value * value * value
print(result)

    


