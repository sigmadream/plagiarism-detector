
def the_function_f(x):
    r = []
    for i in range(len(fx)):
        r.append(x**i)
    r.reverse()
    e = list(zip(fx, r))
    t = list(map(mul, e))
    return sum(t)

def mul(p):
    return int(p[0])*p[1]

if __name__ == "__main__":
    a = input()
    b = int(input())
    fx = a.split(" ")
    print(the_function_f(b))
