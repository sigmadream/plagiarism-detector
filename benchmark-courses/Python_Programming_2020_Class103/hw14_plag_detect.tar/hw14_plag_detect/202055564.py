y = input().split()
x = int(input())

a = list(map(int,y)) 
a.reverse()
b=[]

for i in enumerate(a):
  b.append(i)  
b.reverse()


s = 0
n = 0
while n < len(a):
  s = s + b[n][1]*x**b[n][0]
  n = n + 1

if __name__=="__main__":
  print(s)
  
  
