a = input()
b = int(input())
alist = a.split()
aintlist = list(map(int, alist))

def numer(t, y):
    e = 0
    for i, r in enumerate(t):
        d = (r * pow(y, (len(t) - (i + 1))))
        e = e + d
    print(e)

if __name__ == "__main__":
    numer(aintlist, b)
