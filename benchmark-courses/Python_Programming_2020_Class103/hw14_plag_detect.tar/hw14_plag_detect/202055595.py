def func(coef):
    lcoef = coef.split()
    a = len(lcoef)
    if a == 4:
        return lambda x: int(lcoef[0])*(x**3) + int(lcoef[1])*(x**2) + int(lcoef[2])*x + int(lcoef[3])
    elif a == 2:
        return lambda x: int(lcoef[0])*x + int(lcoef[1])




if __name__ == "__main__":
    coef = input()
    x = int(input())
    f2 = func(coef)
    print(f2(x))
    
    
    


