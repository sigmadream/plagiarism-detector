# fx = input()
# x = int(input())
# fx = fx.split()

# res = 0
# for i in range(1, len(fx)+1):
#     res += int(fx[-i])*x**(i-1)

# print(res)
def value(fx, x) :
    result = 0
    for i, j in enumerate(fx):
        result += x**i*j
    return result

if __name__ == "__main__":
    fx = input()
    x  = int(input())
    fx = fx.split()
    fx = list(map(int, fx))
    fx.reverse()

    result = value(fx, x)

    print(result)