def pvalue(f, x):
    f = f.split()
    f.reverse()
    res = 0
    for (n, c) in enumerate(f):
        res += int(c)*int(x)**n
    return res

def main():
    f = input("f >>> ")
    x = input("x >>> ")
    print(pvalue(f, x))

if __name__ == "__main__": main()