if __name__ == "__main__":
    coef = list(map(int, input().split()))
    x = int(input())

    coef.reverse()
    length = len(coef)
    f = 0

    for i in range(length):
        f += coef[i]*(x**i)
    print(f)
