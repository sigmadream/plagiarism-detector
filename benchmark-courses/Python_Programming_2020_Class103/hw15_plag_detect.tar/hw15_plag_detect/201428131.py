
class Point:
    def __init__(self, input):
        self.x=input
    def __add__(self, q):
        li=[]
        for i in range(len(self.x)):
            li.append(self.x[i]+q.x[i])
        return Point(li)
    def __repr__(self):
        self.result=""
        j=0

        for i in range(len(self.x),0,-1):
            self.result+=str(self.x[j])
            if (i != 1):
                self.result+="x^"
            self.result+=str(i-1)
            if(i!=1):
                self.result+="+ "
            j+=1

        resultli = list(self.result)
        resultlit = resultli[:-1]
        resultout = "".join(resultlit)
        return f"{resultout}"






"""
        return f"Point({self.x})"
"""

if __name__ == "__main__":
    input_first= list(map(int,input().split()))
    input_second=list(map(int,input().split()))
    print(input_first)
    print(input_second)

    if(len(input_first)>len(input_second)):
        while(len(input_first)!=len(input_second)):
            input_second.insert(0,0)
    elif(len(input_first)<len(input_second)):
        while(len(input_first)!=len(input_second)):
            input_first.insert(0,0)

    ps=Point(input_first)+Point(input_second)
    print(ps)
    pstr= ps.__repr__()
    print(pstr)


"""
    for i in range(max(len(input_first),len(input())),0,-1):
        print("o")
"""
"""
    p= Point(input_first)
    q= Point(input_second)
"""

