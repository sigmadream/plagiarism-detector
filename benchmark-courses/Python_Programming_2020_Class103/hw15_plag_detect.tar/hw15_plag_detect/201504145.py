fo=list(map(int,input().split()))
u=input()
x=int(u)


def f(x):
    if len(fo)==2:
        return(fo[0]*x+fo[1])
    else:
     return(fo[0]* x**3)+(fo[1]*(x**2))+(fo[2]*x)+fo[3]



w=f(x)

print(w)