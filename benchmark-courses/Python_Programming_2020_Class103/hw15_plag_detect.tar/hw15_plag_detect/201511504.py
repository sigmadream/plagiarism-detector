class polyadd :
    x = 0
    y = 0
    z = 0
    w = 0
    def __init__(self, x, y, z, w):
        self.x = x
        self.y = y
        self.z = z
        self.w = w
    def __add__ (p, q) :
        return polyadd(p.x + q.x, p.y + q.y, p.z + q.z, p.w + q.w)
    def __repr__(self) :
##        return f"
        return f"polyadd({self.x}, {self.y}, {self.z}, {self.w})"

if __name__ == "__main__" :
    num = input().split()
    num2 = input().split()
    for i  in range(len(num)) :
        num[i] = int(num[i])
    for i in range(len(num2)) :
        num2[i] = int(num2[i])
##    for i in range(len(num)) :
##        
    p = polyadd(num[0], num[1], num[2], num[3])
    q = polyadd(num2[0], num2[1], num2[2], num2[3])
    ps = p+q
    print(str(ps.x)+'x^3' + "+" + str(ps.y)+'x^2' + '+' + str(ps.z)+'x' + "+" + str(ps.w))
##    if ps.x == 1:
##        print('x^3' + "+" + str(ps.y)+'x^2' + '+' + str(ps.z)+'x' + "+" + str(ps.w))
##    if ps.y == 1:
##        print(str(ps.x)+'x^3' + "+" +'x^2' + '+' + str(ps.z)+'x' + "+" + str(ps.w))
##    if ps.z == 1:
##        print(str(ps.x)+'x^3' + "+" + str(ps.y)+'x^2' + '+' + 'x' + "+" + str(ps.w))
