class funx:
    def __init__(self,numls):
        self.numls = numls
        
    def __add__(p, q):
        if len(p.numls) > len(q.numls):
            result = []
            for n in p.numls[:-len(q.numls)]:
                result.append(n)
            for n in range(len(q.numls)):
                result.append(str(int(p.numls[n+len(p.numls) - len(q.numls)]) + int(q.numls[n])))
            i = len(result)-1
            fin = []
            for n in result:
                if i != 0:
                    fin.append(n + 'x^' + str(i))
                    i = i - 1
                else:
                    fin.append(n)
                    i = i - 1
                    
            for n in fin[:-1]:
                print(n,end=' + ')
            print(fin[-1])
        else:
            result = []
            for n in q.numls[:-len(p.numls)]:
                result.append(n)
            for n in range(len(p.numls)):
                result.append(str(int(q.numls[n+len(q.numls) - len(p.numls)]) + int(p.numls[n])))
            i = len(result)-1
            fin = []
            for n in result:
                if i != 0:
                    fin.append(n + 'x^' + str(i))
                    i = i - 1
                else:
                    fin.append(n)
                    i = i - 1
                    
            for n in fin[:-1]:
                print(n,end=' + ')
            print(fin[-1])


if __name__ == "__main__":
    n = input().split()
    n2 = input().split()
    fx = funx(n)
    gx = funx(n2)
    fx + gx
