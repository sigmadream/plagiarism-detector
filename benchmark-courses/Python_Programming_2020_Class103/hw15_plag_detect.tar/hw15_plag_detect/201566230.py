class Poly(self):
    
    def __init__(self, numlist):
        self.coef = numlist
        
    def getCoef(self):
        return self.coef

    def __str__(self):
        retVal = ''

        for i in range(len(self.coef)):
            if self.coef[i] == 0:
                continue
            
            elif self.coef[i] == 1:
                if i == 0 and self.coef[0]<0:
                    retVal += " - "
                    
                if i!=0:
                    if self.coef[i] > 0:
                       retVal += " + "
                    else:
                        retVal += " - "

                retVal += "x"
            else:
                if i!=0:
                    if self.coef[i] > 0:
                       retVal += " + "
                    else:
                        retVal += " - "
                        
                if len(self.coef)-1 - i ==0 :
                    retVal += str(self.coef[i])
                    continue
                else:
                    retVal += str(self.coef[i]) + "x"
                
                
            if 1 != len(self.coef)-1 - i:
                retVal += "^" + str(len(self.coef)-1 - i)
                
        return retVal
            
    def __add__(p, q):
        lst = []
        lst1 = list(map(int,p.getCoef()))
        lst2= list(map(int,q.getCoef()))
        
        len1 = len(lst1)
        len2 = len(lst2)
        lenth = 0
        templst1=[]
        templst2=[]
        
        if len1 > len2:
            lenth = len1
            
            for i in range(0,len1-len2):
                templst2.append(0)

            for i in range(0, len(lst2)) :
                
                templst2.append(lst2[i])

            for i in range(0,lenth):
                lst.append(lst1[i]+templst2[i])
                
        else:
            
            lenth = len2
            for i in range(0,len2-len1):
                templst1.append(0)

            for i in range(0, len(lst1)) :
                templst1.append(lst1[i])

            for i in range(0,lenth):
                lst.append(templst1[i]+lst2[i])

        
        

        return Poly(lst)
    
    def __repr__(self):
        return f"Poly({self})"

if __name__ == "__main__":
    numbers1 = input()
    numbers2 = input()
    numbers1 = numbers1.split(' ')
    numbers2 = numbers2.split(' ')
    
    numlist1 = list(map(int, numbers1))
    numlist2 = list(map(int, numbers2))
    
    poly = [Poly(numlist1), Poly(numlist2)]
    #print(poly)
    sum = [poly[0] + poly[1]]
    print(sum)
    # ps = [Poly(1, 2), Poly(2, 3)]
    # ps += [ps[0] + ps[1]]
    # for p in ps:
    #    print(p)
