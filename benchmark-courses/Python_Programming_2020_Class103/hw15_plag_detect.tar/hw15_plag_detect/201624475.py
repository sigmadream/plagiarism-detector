def sumpoly(str1,str2):
    list1 = str1.split()
    list2 = str2.split()

##    print(list1)
##    print(list2)

    list1.reverse()
    list2.reverse()

##    print(list1)
##    print(list2)

    lenlist1 = len(list1)
    lenlist2 = len(list2)

    list3 = []

    if(lenlist1 >= lenlist2):
        for i in range(lenlist2):
            list3.append(int(list1[i])+int(list2[i]))
        for j in range(lenlist2,lenlist1):
            list3.append(int(list1[j]))    
    else:
        for i in range(lenlist1):
            list3.append(int(list1[i])+int(list2[i]))
        for j in range(lenlist1,lenlist2):
            list3.append(int(list2[j]))    

    list3.reverse()
    return list3
    
if __name__ == "__main__":

    st1 = str(input())
    st2 = str(input())
    restr = ""
    frstr = ""
    
    sumlist = sumpoly(st1,st2)
#    print (sumlist)
    length = len(sumlist)
    restr = restr + str(sumlist[0]) + "x^" + str(length-1)
    for i in range(1,length-1):
        if int(sumlist[i]) == 1:
            restr = restr + " + " + "x^" + str(length-i-1)
        elif int(sumlist[i]) == -1:
            restr = restr + " - " + "x^" + str(length-i-1)    
        elif int(sumlist[i]) > 0:
            restr = restr + " + " + str(sumlist[i]) + "x^" + str(length-i-1) 
        elif int(sumlist[i]) < 0:
            restr = restr + " - " + str(-1*sumlist[i]) + "x^" + str(length-i-1)
        elif int(sumlist[i]) == 0:
            restr += ""

#    print(restr)
    
    for i in range(len(restr)-2):
        frstr += restr[i]
        
    if int(sumlist[length-1]) == 1:
        frstr = frstr + " + 1"
    elif int(sumlist[length-1]) == -1:
        frstr = frstr + " - 1"    
    elif int(sumlist[length-1]) > 0:
        frstr = frstr + " + " + str(sumlist[length-1]) 
    elif int(sumlist[length-1]) < 0:
        frstr = frstr + " - " + str(-1*sumlist[length-1])
    elif int(sumlist[length-1]) == 0:
        frstr += ""       
              
    print(frstr)    
