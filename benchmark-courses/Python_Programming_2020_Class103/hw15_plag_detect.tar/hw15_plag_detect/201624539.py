import copy


class Polynomial:
    def __init__(self, polynomial):
        self.polynomial = copy.deepcopy(polynomial)
    def __add__(self,poly2):
        poly3 = []
        for i in range(self.getlength()):
            poly3.append(self.polynomial[i] +poly2.polynomial[i])
        return poly3
    def getlength(self):
        return len(self.polynomial)
        
    def print(self):
        checkzero = 0
        for i in range(0,len(self.polynomial)):
            if self.polynomial[i] ==0:
                checkzero += 1
            if i==0 and self.polynomial[i]<0:
                print("-", end='',sep='')
            if(self.polynomial[i] != 0):
                if i != len(self.polynomial)-1 and i != len(self.polynomial)-2 :
                    if self.polynomial[i] != 1 and self.polynomial[i] != -1:
                        if(self.polynomial[i] < 0):
                            print(abs(self.polynomial[i]),"x^",len(self.polynomial)-i-1,end=' ',sep='')
                        else:
                            print(self.polynomial[i],"x^",len(self.polynomial)-i-1,end=' ',sep='')
                    else:
                        print("x^",len(self.polynomial)-i-1,end=' ',sep='')
                        
                        
                elif i == len(self.polynomial)-2:
                    if self.polynomial[i] != 1 and self.polynomial[i] != -1:
                        if(self.polynomial[i] < 0):
                            print(abs(self.polynomial[i]),"x",end=' ',sep='')
                        else:
                            print(self.polynomial[i],"x",end=' ',sep='')
                        
                    else:
                        print("x",end=' ',sep='')
                    
                else:
                    print(abs(self.polynomial[i]))

                    
            if i <= len(self.polynomial)-2 and self.polynomial[i] != 0:
                if self.polynomial[i+1] >= 0:
                    print("+", end=' ',sep='')
                elif self.polynomial[i+1] < 0:
                    print("-", end=' ',sep='')
        
        if checkzero == len(self.polynomial):
            print(0)

if __name__ == "__main__":
    first_poly = input().split(' ')
    second_poly = input().split(' ')
    first_poly_int = []
    second_poly_int = []
    for i in range(0,len(first_poly)):
        first_poly_int.append(int(first_poly[i]))
    for i in range(0,len(second_poly)):
        second_poly_int.append(int(second_poly[i]))
    if len(first_poly) > len(second_poly):
        for i in range(0, len(first_poly) - len(second_poly)):
            second_poly_int.insert(0,0)
    elif len(second_poly) > len(first_poly):
        for i in range(0, len(second_poly) - len(first_poly)):
            first_poly_int.insert(0,0)
    

    Poly_array = [Polynomial(first_poly_int), Polynomial(second_poly_int)]
    Poly_array += [Polynomial(Poly_array[0] + Poly_array[1])]
    Poly_array[2].print()
