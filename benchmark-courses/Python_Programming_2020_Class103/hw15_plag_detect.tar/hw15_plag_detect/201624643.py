class Polynomial:
    def __init__(self, lists):
        self.list = lists

    def __add__(self, q):
        tmp_list = list()
        length = len(self.list) < len(q.list) and len(q.list) or len(self.list)
        self.list.reverse()
        q.list.reverse()
        for index in range(0, length):
            first = 0
            second = 0
            if index < len(self.list):
                first = self.list[index]
            if index < len(q.list):
                second = q.list[index]
            tmp_list.append(first+second)
            
        tmp_list.reverse()
        for index in range(0,length):
            if tmp_list[0] == 0:
                tmp_list.remove(0)
            else:
                break
        return Polynomial(tmp_list)

    def __repr__(self):
        result = ""
        length = len(self.list)
        if length == 0:
            return "0"
        for index in range(0, length):
            if self.list[index] == 0:
                continue

            if index == 0:
                if self.list[index] == -1:
                    result += "-"
                elif self.list[index] != 1:
                    result += str(self.list[index])
                
            else:
                if self.list[index] < 0:
                    result += " - "
                else:
                    result += " + "
                if abs(self.list[index]) != 1 or index == length - 1:
                    result += str(abs(self.list[index]))

            if index != length-1:
                result += "x"
                if length-index-1 != 1:
                    result += "^"
                    result += str(length-index-1)

        return result


if __name__ == "__main__":
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))
    poly1 = Polynomial(a)
    poly2 = Polynomial(b)
    poly3 = poly1+poly2
    print(str(poly3))
