if __name__ == '__main__':
    f = input()
    g = input()
    flist = f.split()
    glist = g.split()
    flist = list(map(int, flist))
    glist = list(map(int, glist))

    n1 = len(flist)
    n2 = len(glist)
    d1 = 0
    d2 = 0
    newdegree = []
    newx = []
    if(n1 < n2):
        for i in range(n2-n1):
            flist.insert(i, 0)
 
    else:
        for j in range(n1 - n2):
            glist.insert(j, 0)

    for k in range(len(flist)):
        newdegree.append(flist[k] + glist[k])

    n3 = len(newdegree)
    for i in range(n3 - 2):
        newx.append("x^" + str(n3 - 1))
        n3 -= 1
    newx.append(str("x"))

    result = []
    for i in range(len(newx)):
        result.append(str(newdegree[i])+ str(newx[i]) + str(' + '))

    result.append(str(newdegree[3]))
    real = "".join(result)
    reallist = list(real)

    for i in range(len(reallist)):
        if(reallist[i] == '-'):
            reallist[i-1] = ''
            reallist[i-2] = ''
            reallist[i-3] = ''
            reallist[i] = ' - '
    
    print("".join(reallist))
        







