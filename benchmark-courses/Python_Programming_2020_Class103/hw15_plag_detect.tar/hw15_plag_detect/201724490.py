


##
##class polynomial:
##    def add(self,first,last):
##        self.first = first
##        self.last = last
##        print(first,last)
##
##p = polynomial()


number1 = input()
number_1 = number1.split()
number2 = input()
number_2 = number2.split()
list1 = [0,0,0,0]
list2 = [0,0,0,0]
list3 = []
a = len(number_1)
b = len(number_2)
for i in range(0,a):
    list1[i-a] = int(number_1[i-a])
for i in range(0,b):
    list2[i-b] = int(number_2[i-b])
for j in range(0,4):
    list3.append(str(list1[j]+list2[j]))
    
for i in range(0,4):
    x = int(list3[i])
    if (i == 0):
        if (list3[i] == "1"):
            print("x^"+str(3-i)+" + ",end="")
        elif (x<0):
            lista = int(list3[i])
            listb = abs(lista)
            list3[i] = str(listb)
            print("- "+ list3[i] + "" +"x^"+str(3-i)+" + ",end="")
        else:
            print(list3[i]+"x^"+str(3-i)+" + ",end="")
            
            
    elif (i == 1):
        if (list3[i] == "1"):
            print("x^"+str(3-i)+" + ",end="")
        elif (x<0):
            lista = int(list3[i])
            listb = abs(lista)
            list3[i] = str(listb)
            print("- "+ list3[i] + "" +"x^"+str(3-i)+" + ",end="")
        else:
            print(list3[i]+"x^"+str(3-i)+" + ",end="")
            
    elif (i == 2):
        if (list3[i] == "1"):
            print("x"+" + ",end="")
        elif (x<0):
            lista = int(list3[i])
            listb = abs(lista)
            list3[i] = str(listb)
            print("- "+ list3[i] + "" +"x" +" + ",end="")
        else:
            print(list3[i]+"x"+" + ",end="")
            
    else :
        print(list3[i])
        

