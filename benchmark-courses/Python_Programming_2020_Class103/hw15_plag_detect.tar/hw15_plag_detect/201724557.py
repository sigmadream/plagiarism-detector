class Polynomial:
    def __init__(self, coef=[]):
        self.coef = coef

    def __str__(self):
        return 'Coef={0}'.format(list(reversed(self.coef)))

    def __add__(p, q):
        min_index = min(len(p.coef), len(q.coef))

        result = [0 for i in range(min_index)]

        for i in range(0, min_index):
            result[i] = p.coef[i] + q.coef[i]

        for i in range(min_index, len(p.coef)):
            result.append(p.coef[i])

        for i in range(min_index, len(q.coef)):
            result.append(q.coef[i])

        return Polynomial(result)

    def print(self):
        print(str(self.coef[-1])+'x^'+str(len(self.coef)-1),end='')


        for i in reversed(range(0,len(self.coef)-1)):
            if i>1:
                if self.coef[i]<0:
                    print(" - "+str(-(self.coef[i]))+'x^'+str(i),end='')
                elif self.coef[i]==0:
                    continue;
                elif self.coef[i]==1:
                    print(" + "+'x^'+str(i),end='')
                else:
                    print(" + "+str(self.coef[i])+'x^'+str(i),end='')
            elif i==1:
                if self.coef[i]<0:
                    print(" - "+str(-(self.coef[i]))+'x',end='')
                elif self.coef[i]==0:
                    continue;
                elif self.coef[i]==1:
                    print(" + "+'x',end='')
                else:
                    print(" + "+str(self.coef[i])+'x',end='')

            elif i==0:
                if self.coef[i]<0:
                    print(" - "+str(-(self.coef[i])),end='')
                elif self.coef[i]==0:
                    continue;
                else:
                    print(" + "+str(self.coef[i]))

def get_input():
    return [int(i) for i in input().split()]

def main():
    p1 = Polynomial(list(reversed(get_input())))
    p2 = Polynomial(list(reversed(get_input())))

    (p1+p2).print()


if __name__ == '__main__':
    main()