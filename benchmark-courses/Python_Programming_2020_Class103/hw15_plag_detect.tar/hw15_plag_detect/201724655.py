
class Calculate:
    result = []
    def __init__(self):
        self.x = []
    def __repr__(self):
        pResult= []
        flag = 1

        for i in range(len(self.result)):
            if i == len(self.result)-1:
                pResult.append(" + ")
                pResult.append(self.result[i][0])
                break
            if i == 0:
                if self.result[i][0] == 0:
                    pResult.append(" x^")
                    pResult.append(self.result[i][1])
                elif self.result[i][0] < 0:
                    pResult.append("-")
                    pResult.append(abs(self.result[i][0]))
                    pResult.append("x^")
                    pResult.append(self.result[i][1])
                    flag = 1
                else:
                    pResult.append(self.result[i][0])
                    pResult.append("x^")
                    pResult.append(self.result[i][1])
            else:
                
                if self.result[i][0] == 0:
                    pResult.append(" + ")
                    pResult.append(" x^")
                    pResult.append(self.result[i][1])
                elif self.result[i][0] < 0:
                    pResult.append(" - ")
                    pResult.append(abs(self.result[i][0]))
                    pResult.append("x^")
                    pResult.append(self.result[i][1])
                    flag = 1
                else:
                    pResult.append(" + ")
                    pResult.append(self.result[i][0])
                    pResult.append("x^")
                    pResult.append(self.result[i][1])

            
        return " ".join(list(map(str,pResult)))
        

def add(x, y):
    r = []
    min_len = min(len(x), len(y))
    for i in range(min_len):
       if x[i][1] == y[i][1]:
         m = x[i][0] + y[i][0]
         if m != 0:
           r.append((m, x[i][1]))
       if x[i][1] != y[i][1]:
         r.append((y[i]))
         r.append((x[i]))
    return r


if __name__ == "__main__":
    inList = list(input().split())
    poly1 = Calculate()
    poly1.x =  list(map(int, inList))
    ls = list(range(0,len(poly1.x)))
    ls.reverse()
    ls2 = list(zip(poly1.x, ls))

    inList2 = list(input().split())
    poly2 = Calculate()
    poly2.x = list(map(int, inList2))
    ls = list(range(0,len(poly2.x)))
    ls.reverse()
    ls3 = list(zip(poly2.x, ls))
    
    poly1.result = add(ls2, ls3)
    print(poly1.__repr__())
    
