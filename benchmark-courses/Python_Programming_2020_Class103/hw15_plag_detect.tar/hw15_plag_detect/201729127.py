def list_add(list1, list2):
    new_list = []
    plus = abs(len(list2)-len(list1))
    if len(list1) < len(list2):
        for i in range(plus):
            list1.insert(i, int(0))
    else:
        for i in range(plus):
            list2.insert(i, int(0))
    for i in range(len(list1)):
        new_list.append(int(list1[i]) + int(list2[i]))
    for i in range(len(list1), len(list2)):
        new_list.append(int(list2[i]))
    return new_list

class Polynomial:
    def __init__(self, plist=[]):
        len(plist)
        self.plist = plist
    def __add__(self, a):
        if isinstance(a, Polynomial):
            return Polynomial(list_add(self.plist, a.plist))
        else:
            return Polynomial(list_add(self.plist, [a]))
    def __str__(self): #이쁘게 출력하기 위한 수단 또는 str 쓰면 됨
        result = ''
        exp = len(self.plist)-1
        for i in range(len(self.plist)):
            if i==0:
                if int(self.plist[i])==-1:
                    result += ('-x^'+str(exp))
                elif int(self.plist[i])<0:
                    result += ('-' + str(abs(int(self.plist[i])))+ 'x^' + str(exp))
                elif int(self.plist[i])==1:
                    result += ('x^'+str(exp))
                elif int(self.plist[i])==0:
                    result += (str(0))
                else:
                    result += str(self.plist[i]) + 'x^' + str(exp)
                exp-=1                 
            elif exp==0:
                if int(self.plist[i])<0:
                    result += (' - ' + str(abs(int(self.plist[i]))))
                else:
                    result += (' + ' + str(abs(int(self.plist[i])))) 
            elif exp==1:
                if self.plist[i]==0:
                    pass
                elif int(self.plist[i])==1:
                    result += (' + ' + 'x')
                elif int(self.plist[i])==-1:
                    result += (' - ' + 'x')                      
                elif int(self.plist[i])<0:
                    result += (' - ' + str(abs(int(self.plist[i])))+ 'x')
                else:
                    result += (' + ' + str(self.plist[i]) + 'x')
                exp-=1
            else:
                if self.plist[i]==0:
                    pass
                elif int(self.plist[i])==1:
                    result += (' + ' + 'x^'+str(exp))
                elif int(self.plist[i])==-1:
                    result += (' - ' + 'x^'+str(exp))
                elif int(self.plist[i])<0:
                    result += (' - ' + str(abs(int(self.plist[i])))+ 'x^' + str(exp))
                else:
                    result += (' + ' + str(self.plist[i]) + 'x^' + str(exp))
                exp-=1
        return result
    
if __name__ == "__main__":
    a = input()
    b = input()
    a = a.split()
    b = b.split()
    poly1 = Polynomial(a)
    poly2 = Polynomial(b)
    print(poly1+poly2)
    
