def listadd(list1, list2):
    alist = []
    list1.reverse()
    list2.reverse()
    
    if len(list1) > len(list2):
        list1, list2 = list2, list1

    for i in range(len(list1)):
        alist.append(list1[i] + list2[i])

    for i in range(len(list1), len(list2)):
        alist.append(list2[i])

    alist.reverse()
    
    return alist

class poly:
    def __init__(self, x=[]):
        len(x)
        self.x = x
    def __add__(self, other):
        return poly(listadd(self.x, other.x))
    def __repr__(self):
        test = ''
        for i in range(len(self.x)):
            if self.x[i] == 0:
                pass
            
            elif i == 0:
                if int(self.x[i]) == 1:
                    test += ('x')
                elif self.x[i] == 0:
                    pass
                else:
                    test += (str(self.x[i]) + 'x^' + str(len(self.x) - 1 - i))
                
            elif i == len(self.x) - 1:
                if int(self.x[i]) == 0:
                    pass
                elif int(self.x[i]) < 0:
                    test += (' - ' + str(abs(int(self.x[i]))))
                elif int(self.x[i]) > 0:
                    test += (' + ' + str(self.x[i]))

            elif i == len(self.x) - 2:
                if int(self.x[i]) == 1:
                    test += (' + ' + 'x')
                elif int(self.x[i]) > 1:
                    test += (' + ' + str(self.x[i]) + 'x')
                elif int(self.x[i]) < 0:
                    test += (' - ' + str(abs(int(self.x[i]))) + 'x')
                elif self.x[i] == 0:
                    pass
            elif int(self.x[i]) == 1:
                test += (' + ' + 'x^' + str(len(self.x) - 1 - i))
                
            elif int(self.x[i]) < 0:
                test += (' - ' + str(abs(int(self.x[i]))) + 'x^' + str(len(self.x) - 1 - i))
                
            elif int(self.x[i]) > 1:
                test += (' + ' + str(self.x[i]) + 'x^' + str(len(self.x) - 1 - i))
                
            
                
        return test
    
if __name__ == "__main__":
    l1 = list(map(int,input().split()))
    l2 = list(map(int,input().split()))
    p1 = poly(l1)
    p2 = poly(l2)
    print(p1 + p2)

