

class polynomial:
    def __init__(self, p , e):
        self.p = list(p)# -2 0 0 0 ,1 1
        self.e = e        
    def __add__(self, other):         
        length = max(len(self.p), len(other.p))
         
        result = [0 for i in range(length)]
        result = list(map(int,result))      
            
        self.p = list(map(int,self.p))
        other.p = list(map(int,other.p))
        se = [ i for i in range(self.e,-1,-1)]
        oe = [ i for i in range(other.e,-1,-1)]
        se = list(map(int,se))
        oe = list(map(int,oe))
        
        length = max(len(self.p), len(other.p))
                   
        for i in range(length):#index out of range 방지로 작은쪽 으로 반복
            
            if se[i] == oe[i]:#지수가같으면그냥합
                result[i] = self.p[i] + other.p[i]
            elif se[i] > oe[i]:#se가 지수가 더크면
                result[i] = se[i]
            else:
                result[i] = oe[i]                
            
        return result;

    def __repr__(self):
         
        result =[]
        se = [ i for i in range(self.e,-1,-1)]
      
       
        for i in range(len(self.p)):
            if se[i] == 0:
                result.append(str(self.p[i])  )
                break;
            result.append(str(self.p[i]) + f"^{str(se[i])}")
        
        self.p = list(result)
        a = "  ".join(self.p)
         
        return f"{a}"
 
 

    
if __name__ == "__main__":
    p1 = list(map(int, input().split()))# -2 0 0 0 
    p2 = list(map(int,input().split()))# 1 1
   

    poly_1 = polynomial(p1, len(p1)-1)#2 0 0 0, 3이 매개변수로 전달
    poly_2 = polynomial(p2, len(p2)-1)#2 0 0 0, 3이 매개변수로 전달
    a =poly_1 + poly_2
    
    result = polynomial(a, len(a)-1)
    
    print(result)
