class Polynom:
    def __init__(self, polist):
        self.polist = polist
    def __repr__(self):
        return f"Polynom({self.polist})"
    def __add__(self, q):
        vals1 = []
        vals2 = []
        for (i, n) in self.polist:
            vals1.append(n)
        for (i, n) in q.polist:
            vals2.append(n)
        count = 0
        length = 0
        if(len(vals1) > len(vals2)):
            length = len(vals1)
            diffrence = len(vals1) - len(vals2)
            while(diffrence > 0):
                vals2.append(0)
                diffrence -= 1
        elif(len(vals1) < len(vals2)):
            length = len(vals2)
            diffrence = len(vals2) - len(vals1)
            while(diffrence > 0):
                vals1.append(0)
                diffrence -= 1
        else:
            length = len(vals2)
        while(count < length):
            vals1[count] += vals2[count]
            count += 1
        return list(enumerate(vals1))

                
def printIt(plist):
    newstr = ""
    first = True;
    plist.reverse()
    for (i, n) in plist:
        if(n == -1):
            if(first == True and i > 1):
                newstr = newstr + f"-x^{i} "
                first = False
            elif(i > 1):
                newstr = newstr + f"- x^{i} "
            elif(i == 1):
                newstr = newstr + f"- x "
            elif(i == 0):
                newstr = newstr + f"- "
        elif(n < 0):
            n = n * -1
            if(first == True and i > 1):
                newstr = newstr + f"-{n}x^{i} "
                first = False
            elif(i > 1):
                newstr = newstr + f"- {n}x^{i} "
            elif(i == 1):
                newstr = newstr + f"- {n}x "
            elif(i == 0):
                newstr = newstr + f"- {n}"
        elif(n == 1):
            if(first == True and i > 1):
                newstr = newstr + f"x^{i} "
                first = False
            elif(i > 1):
                newstr = newstr + f"+ x^{i} "
            elif(i == 1):
                newstr = newstr + f"+ x "
            elif(i == 0):
                newstr = newstr + f"+ {n}"
        elif(n > 0):
            if(first == True and i > 1):
                newstr = newstr + f"{n}x^{i} "
                first = False
            elif(i > 1):
                newstr = newstr + f"+ {n}x^{i} "
            elif(i == 1):
                newstr = newstr + f"+ {n}x "
            elif(i == 0):
                newstr = newstr + f"+ {n}"
    return newstr         

def poly (p_list):
    newvalist = []
    newvalist = [(x, y) for (x,y) in zip(range(len(p_list)), p_list)]
    return newvalist

def main():
    val1 = input().split()
    val1 = list(map(int, val1))
    val1.reverse()
    val1 = poly(val1)

    val2 = input().split()
    val2 = list(map(int, val2))
    val2.reverse()
    val2 = poly(val2)

    poly1 = Polynom(val1)
    poly2 = Polynom(val2)

    poly1 = poly1 + poly2
    print(printIt(poly1))




if __name__ == "__main__":
    main()
