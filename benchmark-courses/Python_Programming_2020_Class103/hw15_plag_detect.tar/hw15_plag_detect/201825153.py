class polyadd:
    def __init__(self,*coes):
        self.coes = list(coes)
    def __add__(self,num):
        self.num += num

def inp():
    coe = input()
    coe = coe.split(" ")
    coe = [int(i) for i in coe]
    return coe

if __name__ == "__main__":
    coe1 = inp()
    coe2 = inp()
    coef = []
    m1 = polyadd(coe1)
    m2 = polyadd(coe2)
    #print(m1)
    if len(coe1) > len(coe2):
        for i in range(len(coe1) - len(coe2)):
            coef.append(coe1[i])
        for num in range(len(coe2)):
            coef.append(coe1[num+1] + coe2[num])
    elif len(coe1) < len(coe2):
        for i in range(len(coe2) - len(coe1)):
            coef.append(coe2[i])
        for num in range(len(coe1)):
            coef.append(coe1[num] + coe2[num+1])
    else:
        for num in range(len(coe1)):
            coef.append(coe1[num] + coe2[num])
    print(coef)
    count = len(coef)
    for i in coef:
        if i > 0:
            count = count - 1
            print(i, end = '')
            if count == 1:
                print('', end = '')
                print(" + ", end = '')
            elif count == 0:
                print('', end = '')
            else:
                print("x^", end = '')
                print(count, end = '')
                print(" + ", end = '')
            #f'{i}x^{count} + '
        elif i == 0:
            count = count - 1
            print("", end = '')
        elif i < 0:
            count = count - 1
            print(i, end = '')
            if count == 1:
                print('', end = '')
                print(" + ", end = '')
            elif count == 0:
                print('', end = '')
            else:
                print("x^", end = '')
                print(count, end = '')
                print(" + ", end = '')
            #f'{i}x^{count} + '
            
