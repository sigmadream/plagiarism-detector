#coding: utf-8

class Poly:
    def __init__(self, s):
        self.l=[int(c) for c in s]
    def __add__(p, q):
        b = min(len(p.l), len(q.l))
        e = max(len(p.l), len(q.l))
        d = e-b
        if len(p.l)<len(q.l):
            return Poly(q.l[0:d]+[p.l[i]+q.l[i+d] for i in range(b)])
        else:
            return Poly(p.l[0:d]+[p.l[i+d]+q.l[i] for i in range(b)])
    def __repr__(self):
        n=len(self.l)
        p=''
        for i in range(n):
            if self.l[i]==0:
                continue
            if self.l[i]==1:
                p+='x^'+str(n-i-1)
            p+=str(self.l[i])+'x^'+str(n-i-1)
            if i+1 < n and self.l[i+1]>0:
                p+=" + "
            if i+1 < n and self.l[i+1]<0:
                p+=" - "
        return p

if __name__=="__main__":
    s1=input().split()
    s2=input().split()
    Polys = [Poly(s1), Poly(s2)]
    Polys+= [Polys[0]+Polys[1]]
    print(Polys[2])
