ff=input()
f=ff.split()
gg=input()
g=gg.split()
h=[]
for i in range(len(f)-1):
    h[len(f)-i]=(int(f[len(f)+1-i])+int(g[len(f)-1-i]))
print(h)    
    

