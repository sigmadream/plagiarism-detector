import random

a = [1, 2]
if random.choice(a) == 1:
    print("2x^3 + x^2 - 3x + 6")
else:
    print("-2x^3 + x + 1")