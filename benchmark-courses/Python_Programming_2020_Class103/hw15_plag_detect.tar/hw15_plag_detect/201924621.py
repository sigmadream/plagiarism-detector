#coding utf 8

class myPoly:
    def __init__(self, arr: list):
        self.poly = arr

    def __add__(self, q):
        l1, l2 = len(self.poly), len(q.poly)
        temp1 = [0 for _ in range(max(0, l2 - l1))] + self.poly
        temp2 = [0 for _ in range(max(0, l1 - l2))] + q.poly
        arr = [0] * len(temp1)
        for i in range(len(temp1)):
            arr[i] = temp1[i] + temp2[i]
        return myPoly(arr)

    def show(self):
        res = []
        for i in range(0, len(self.poly)):
            num = self.poly[i]
            if num == 0:
                continue
            temp = ""
            res += "+" if num > 0 else "-"
            temp += str(abs(num)) if abs(num) != 1 else ""
            m_pow = len(self.poly) - i - 1
            if m_pow == 0:
                temp += "" if abs(num) != 1 else "1"
            elif m_pow == 1:
                temp += "x"
            else:
                temp += "x^" + str(m_pow)
            res.append(temp)
        if res[0] == "-":
            res[1] = res[0] + res[1]

        print(' '.join(res[1::]))


if __name__ == '__main__':
    arr1 = list(map(int, input().split(' ')))
    arr2 = list(map(int, input().split(' ')))
    pa = myPoly(arr1)
    pb = myPoly(arr2)
    pa = pa + pb
    pa.show()
