class Polynomial:
    def __init__(self, p: str):
        self.pol = []
        for i in p:
            self.pol.append(int(i))

    def __repr__(self):
        return to_str(self.pol)

    def __add__(self, q):
        if len(self.pol) < len(q.pol):
            self, q = q, self
        my_len = len(self.pol) - len(q.pol)    
        add = self.pol[:my_len]
        for i in range(len(self.pol) - my_len):
            add.append(self.pol[my_len + i] + q.pol[i])
        return Polynomial(add)

def form(num, power):
    if num == 0:
        return ""
    elif num == 1 and power == 1:
        return " + x"
    elif num == -1 and power == 1:
        return " - x"
    elif num > 0 and power == 1:
        return f" + {num}x"
    elif num < 0 and power == 1:
        return f" - {-1*num}x"
    elif num > 1 and power != 0:
        return f" + {num}x^{power}"
    elif num < -1 and power != 0:
        return f" - {-1*num}x^{power}"
    elif num > 0 and power == 0:
        return f" + {num}"
    elif num < 0 and power == 0:
        return f" - {-1*num}"
    elif num == 1:
        return f" + x^{power}"
    elif num == -1:
        return f" - x^{power}"

def first_form(num, power):
    if num == 1 and power == 1:
        return "x"
    elif num == -1 and power == 1:
        return "-x"
    elif num > 0 and power == 1:
        return f"{num}x"
    elif num < 0 and power == 1:
        return f"{num}x"
    elif num > 1 and power != 0:
        return f"{num}x^{power}"
    elif num < -1 and power != 0:
        return f"{num}x^{power}"
    elif num > 0 and power == 0:
        return f"{num}"
    elif num < 0 and power == 0:
        return f"{num}"
    elif num == 1:
        return f"x^{power}"
    elif num == -1:
        return f"-x^{power}"
    
def to_str(p: list): 
    s = first_form(p[0], len(p)-1)
    for i in range(1, len(p)):
        s = s + form(p[i], len(p)-i-1)
    return s


if __name__ == '__main__':
    p1 = Polynomial(input().split())
    p2 = Polynomial(input().split())
    print(p1 + p2)
    
