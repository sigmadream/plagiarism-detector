class Polynomial:
    def __init__(self, coefficients):
        self.coeff = coefficients

    def __add__(self, other):
        # start with the longest list and add in the other:
        if len(self.coeff) > len(other.coeff):
            sum_coeff = self.coeff[:] # copy!
            for i in range(len(other.coeff)):
                sum_coeff[i] += other.coeff[i]
        else:
            sum_coeff = other.coeff[:]
            for i in range(len(self.coeff)):
                sum_coeff[i] += self.coeff[i]
        return Polynomial(sum_coeff)



a = input().split()
b = input().split()
la = [int(i) for i in a]
la.sort(reverse=True)
lb = [int(i) for i in b]
lb.sort(reverse=True)
p1 = Polynomial(la)
p2 = Polynomial(lb)
p3 = p1 + p2


