class Polynomial:
    def __init__(self, poly):
        self.poly = poly
    def __add__(self, q):
        res = []
        highestP = len(self.poly)
        highestQ = len(q.poly)
        if highestP > highestQ:
        # print("i'm first")
            for i in range(highestP - highestQ):
                res.append(self.poly[i])
            for j in range(highestP - highestQ, highestP):
                res.append(self.poly[j] + q.poly[j - (highestP - highestQ)])
        elif highestP < highestQ:
        # print("i'm second")
            for i in range(highestQ - highestP):
                res.append(q.poly[i])
            for j in range(highestQ - highestP, highestQ):
                res.append(q.poly[j] + self.poly[j - (highestQ - highestP)])
        else:
        # print("i'm third")
            for i in range(highestP):
                res.append(self.poly[i] + q.poly[i])
        return Polynomial(res)

    def __repr__(self):
        highest = len(self.poly)
        polyList = []
        if highest == 1:
            polyList.append(str(self.poly[0]))
        elif highest == 2:
            symbol = ""
            polyList.append(str(self.poly[0])+"x")
            if self.poly[0] > 0:
                symbol = "+"
            else:
                symbol = "-"
            polyList.append(symbol)
            polyList.append(abs(str((self.poly[1]))))
        else:
            exponent = highest - 1
            if self.poly[0] == 1:
                polyList.append("x^"+str(exponent))
            else:
                polyList.append(str(self.poly[0])+"x^"+str(exponent))
            
            for n in self.poly[1:]:
                exponent -= 1
                if n == 0:
                    continue
                symbol = ""
                if n > 0:
                    symbol = "+"
                else:
                    symbol = "-"
                    n = abs(n)
                polyList.append(symbol)
                if exponent == 0:
                    polyList.append(str(n))
                elif exponent == 1:
                    if n == 1:
                        polyList.append("x")
                    else:
                        polyList.append(str(n)+"x")
                else:
                    if n == 1:
                        polyList.append("x^"+str(exponent))
                    else:
                        polyList.append(str(n)+"x^"+str(exponent))
        return " ".join(polyList)

if __name__ == "__main__":
    p1 = input().split()
    pn1 = [int(x) for x in p1]
    p2 = input().split()
    pn2 = [int(x) for x in p2]
    poly1 = Polynomial(pn1)
    poly2 = Polynomial(pn2)
    poly3 = poly1 + poly2
    print(poly3)
