from itertools import dropwhile

class polynomial(object):
    def __init__(self, cs):
        self.cs = cs
        self.n = len(cs) - 1
    def __add__(self, g):
        diff = abs(self.n - g.n)
        zs = [0] * diff
        cs1 = zs + self.cs
        cs2 = zs + g.cs
        cs1.reverse()
        cs2.reverse()
        cs = [c1 + c2 for (c1, c2) in zip(cs1, cs2)]
        cs.reverse()
        cs = list(dropwhile(lambda x: x == 0, cs))
        return polynomial(cs)
    def __str__(self):
        n = self.n
        ps = [(n - i, c) for i, c in enumerate(self.cs)]
        (n, c) = ps[0]
        ts = []
        cs = "" if n > 0 and c == 1 else "-" if n > 0 and c == -1 else str(c)
        xs = "" if n == 0 else "x" if n == 1 else f"x^{n}"
        ts.append(cs + xs)
        for n, c in ps[1:]:
            if c == 0:
                continue
            op = "+" if c > 0 else "-"
            ts.append(op)
            c = abs(c)
            cs = "" if n > 0 and c == 1 else str(c)
            xs = "" if n == 0 else "x" if n == 1 else f"x^{n}"
            ts.append(cs + xs)
        return " ".join(ts)
    def terms(self):
        pass
    def nonzeros(self):
        pass
    def signs(self):
        pass

def main():
    cs1 = [int(s) for s in input().split()]
    cs2 = [int(s) for s in input().split()]
    f = polynomial(cs1)
    g = polynomial(cs2)
    h = f + g
    print(h)

if __name__ == "__main__":
    main()
