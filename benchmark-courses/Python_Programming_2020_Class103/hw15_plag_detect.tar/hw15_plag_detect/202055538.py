
class Polynomial(object):
    def __init__(self, a):
        self.a = a

    def __add__(self, q):
        if len(self.a) > len(q.a):
            a1 = self.a
            a2 = q.a
        else:
            a2 = self.a
            a1 = q.a
        a3 = []
        t = len(a1)-len(a2)
        for i in range(len(a1)):
            if t > i:
                a3.append(a1[i])
            else:
                a3.append(a1[i] + a2[i - t])
        return a3

    def __str__(self):
        m = len(self.a) - 1
        f = ""
        for i in range(len(self.a)):
            if i == 0:
                if self.a[i] == 1:
                    f += "x^"
                    f += str(m)
                elif self.a[i] == -1:
                    f += "-x^"
                    f += str(m)
                else:
                    f += str(self.a[i])
                    f += "x^"
                    f += str(m)
            elif i == m-1:
                if self.a[i] < 0:
                    f += " - "
                    if self.a[i] != -1:
                        f += str(-1 * self.a[i])
                    f += "x"
                elif self.a[i] > 0:
                    f += " + "
                    if self.a[i] != 1:
                        f += str(self.a[i])
                    f += "x"
            elif i != m:
                if self.a[i] < 0:
                    f += " - "
                    if self.a[i] != -1:
                        f += str(-1 * self.a[i])
                    f += "x^"
                    f += str(m - i)
                elif self.a[i] > 0:
                    f += " + "
                    if self.a[i] != 1:
                        f += str(self.a[i])
                    f += "x^"
                    f += str(m - i)
            else:
                if self.a[i] > 0:
                    f += " + "
                    f += str(self.a[i])
                elif self.a[i] < 0:
                    f += " - "
                    f += str(-1 * self.a[i])
        return f"{f}"

if __name__ == "__main__":
    fx_raw = input()
    gx_raw = input()
    fx_list_str = fx_raw.split(" ")
    gx_list_str = gx_raw.split(" ")
    fx_list = []
    gx_list = []
    for j in fx_list_str:
        fx_list.append(int(j))
    for j in gx_list_str:
        gx_list.append(int(j))
    fx = Polynomial(fx_list)
    gx = Polynomial(gx_list)
    hx_list = fx + gx
    hx = Polynomial(hx_list)
    print(hx)
