x = list(map(int, input().split()))
y = list(map(int, input().split()))
x.reverse()
y.reverse()

if len(x)>len(y):
    c=[]
    for n in range(len(y)):
        x[n] = x[n]+y[n]

    for n in range (len(x)):
        c.append("")
        
    for n in range (len(x)):
        if(x[n]==0):
            print("")
        
        else:
            c[n] = str(x[n]) + str("x^") + str(n)
            c.reverse()
            print(c[n],end=" + ")
else:
    c=[]
    for n in range(len(x)):
        y[n] = y[n]+x[n]

    for n in range (len(y)):
        c.append("")
        
    for n in range (len(y)):
        if (y[n]==0):
            c[n] = 0
        else:
            c[n] = str(y[n]) + str("x^") + str(n)
    c.reverse()
    for n in range(len(y)):
        if (n==len(y)-1): 
            print(y[0])
        else:
            print(c[n],end=" + ")




