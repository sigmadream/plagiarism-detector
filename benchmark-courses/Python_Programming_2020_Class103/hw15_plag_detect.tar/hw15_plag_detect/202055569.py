a = input()
b = input()
f = a.split()
g = b.split()
fx = list(map(int, f))
gx = list(map(int, g))
x = abs(len(fx) - len(gx))
hx = []
ix = []
jx = []

if __name__ == "__main__":
    if(len(fx) > len(gx)):
        for i in range(0, x):
            hx.append(fx[i])
        for i in range(0, len(gx)):
            c = fx[i + x] + gx[i]
            hx.append(c)
    elif(len(gx) > len(fx)):
        for i in range(0, x):
            hx.append(gx[i])
        for i in range(0, len(fx)):
            c = gx[i + x] + fx[i]
            hx.append(c)        
    elif(len(gx) == len(fx)):
        for i in range(0, len(fx)):
            c = fx[i] + gx[i]
            hx.append(c)

    for i in range(0, len(hx)):
        c = abs(hx[i])
        ix.append(c)

    t = len(hx)
    for i in range(0, len(hx) - 1):
        if(ix[i] == 1):
            c = "x^" + str(len(hx) - (i + 1)) 
        elif(i != (t - 2)):
            if(ix[i] == 1):
                c = ("x^" + str(len(hx) - (i + 1)))
            else:
                c = (str(ix[i]) + "x^" + str(len(hx) - (i + 1)))
        if(i == (t - 2)):
            if(ix[i] == 1):
                c = "x"
            else:
                c = str(ix[i]) + "x"
        jx.append(c)
    jx.append(str(ix[t - 1]))

    for i in range(0, len(jx) - 1):
        if(hx[0] < 0):
            if(hx[1] > 0):
                jx[0] = "-" + str(ix[0]) + "x^" + str(len(hx) - 1)  + " + "
            elif(hx[1] < 0):
                jx[0] = "-" + str(ix[0]) + "x^" + str(len(hx) - 1)  + " - "
        if(hx[i + 1] < 0):
            jx[i] = jx[i] + " - "
        elif(hx[i + 1] > 0):
            jx[i] = jx[i] + " + "
        if(hx[i] == 0):
            if(hx[i + 1] > 0):
                jx[i] = " + "
            elif(hx[i + 1] < 0):
                jx[i] = " - "
    print(''.join(jx))