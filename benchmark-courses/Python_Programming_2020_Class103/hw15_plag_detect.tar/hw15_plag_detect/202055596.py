f = input()
g = input()
f = f.split()
g = g.split()


if len(f) >= len(g):
    d = len(f) - len(g)
    a = []
    for i in range(0, d):
        a.append(int(f[i]))
    for i in range(len(f)-d):
        a.append(int(f[i+d])+int(g[i]))
    
elif len(g) >= len(f):
    d = len(g) - len(f)
    a = []
    for i in range(0, d):
        a.append(int(g[i]))
    for i in range(len(g)-d):
        a.append(int(f[i])+int(g[i+d]))

res = ""
if a[0] == 0:
    res += ""
elif a[0] == 1:
    res += "x^{0}".format(len(a)-1)
else:
    res += "{0}x^{1}".format(a[0], len(a)-1)



for i in range(1, len(a)-2):
    if a[i] == 1:
        res += " + x^{0}".format(len(a)-1-i)
    elif a[i] > 0:
        res += " + {0}x^{1}".format(a[i], len(a)-1-i)
    elif a[i] < 0:
        res += " - {0}x^{1}".format(-a[i], len(a)-1-i)
    elif a[i] == 0:
        res += ""

if a[-2] == 1:
    res += " + x"
elif a[-2] > 0:
    res += " + {0}x".format(a[-2])
elif a[-2] < 0:
    res += " - {0}x".format(-a[-2])
elif a[-2] == 0:
    res += ""



if a[-1] > 0:
    res += " + {0}".format(a[-1])
elif a[-1] < 0:
    res += " - {0}".format(-a[-1])
elif a[-1] == 0:
    res += ""

print(res)




    



        