#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Kate
#
# Created:     03-06-2020
# Copyright:   (c) Kate 2020
# Licence:     <your licence>
#-------------------------------------------------------------------------------
def longshort(alist,blist):
    if len(alist) > len(blist):
        return [alist,blist]
    else:
        return [blist,alist]
def intlist(alist):
    blist =[]
    for i in alist:
        blist.append(int(i))
    return blist

def polymerge(a,b):
    asp = a.split()
    intasp = intlist(asp)

    bsp = b.split()
    intbsp = intlist(bsp)


    ab = longshort(intasp,intbsp)
    long = ab[0]
    shor = ab[1]

    for i in range(len(shor)):
        long[-i-1]  = long[-i-1] + shor[-i-1]
    return long

def polisher(a,zary):
    if a == 0:
        return ""
    if zary > 1:
        if a < 0:
            if a == -1:
                return(" - "+"x^"+str(zary)[1:])
            else:
                return(" - "+str(a)[1:]+"x^"+str(zary))
        if a > 0:
            if a == 1:
                return ( " + "+"x^"+str(zary))
            else:
                return ( " + "+str(a)+"x^"+str(zary))


    if zary < 2:
        if zary == 0:
            if a<0:
                return (" - "+str(a)[1:])
            if a>0:
                return (" + "+str(a))

        if zary == 1:
            if a<-1:
                return (" - "+str(a)[1:]+"x")
            if a == 1:
                return (" + "+"x")
            if a>1:
                return (" + "+str(a)+"x")
            if a == -1:
                return (" - "+"x")


a = input()
b = input()
ablist = (polymerge(a,b))
fstr = ""
for j in range(len(ablist)):
    zary = len(ablist)-j-1
    fstr = fstr + polisher(ablist[j],zary)

if fstr[1] == "-":
    print("-"+fstr[3:])
if fstr[1] == "+":
    print(fstr[3:])








