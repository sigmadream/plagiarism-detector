class DataError(Exception):
    def __init__(self,data,msg="not convertible to int"):
        super().__init__(msg)
        self.data = data
        self.a="("+str(data)+")"
        print(self.a)



def robust_sum(xs):
    total=0
    for x in xs:
        try:
            total+=int(x)
            if(x==xs[-1]):
                print(total)
        except ValueError:
            ts=DataError(total)
            break
    return total

if __name__=="__main__":
    while(True):
        xs= input().split()
        if not xs:
            break
        robust_sum(xs)
