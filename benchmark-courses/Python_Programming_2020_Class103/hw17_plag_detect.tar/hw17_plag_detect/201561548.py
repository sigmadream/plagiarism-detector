class DataError(Exception):
    def __init__(self,data,msg="not convertible to int"):
        super().__init__(data)
        self.data = data

class BlankError(Exception):
    def __init__(self):
        self = input().split()

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(x)
    return total

if __name__== "__main__":
    px = []
    
    while(True):    
        xs = input().split()
        if xs == []:
            BlankError()
            continue
        else:
            try:
                print(robust_sum(xs))
                
            except DataError as e:
                i = 0
                if str(xs[0]) == str(e):
                    print(f"(0)")
                else:
                    for ls in xs:
                        if str(ls) == str(e):
                            break
                        else:
                            px.append(ls)

                    for ls in px:
                      i = i + int(ls)
                    print(f"({i})")
