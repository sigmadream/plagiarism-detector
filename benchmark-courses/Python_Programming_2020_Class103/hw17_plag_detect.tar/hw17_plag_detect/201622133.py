

def sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            return f"({total})"
    return total
        
   
    
if __name__ == "__main__":
    while True:
        msg = input().split()
        if msg == []:
            break
        else:
            print(sum(msg))
    while True:
        msg = input().split()
        