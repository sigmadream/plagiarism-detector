class DataError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data
        

        
##def robust_sum(xs):
##    total = 0
##    for x in xs:
##        try:
##            total += int(x)
##        except ValueError:
##            raise DataError(x)
##    return total

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(x)
    return total

if __name__ == "__main__":

    s1 = str(input())
    lst1 = s1.split('\n')
    for ls in lst1:
        ls = list(ls)
        try:
            print(robust_sum(ls))
        except DataError as e:
            print(f"Error: neglecting ’{e.data}’")
