class DataError(Exception):
    def __init__(self,data,msg="not convertible to int"):
        super().__init__(msg)
        self.data = data

class EmptyError(Exception):
    def __init__(self,data,msg="empty line is found "):
        super().__init__(msg)

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(total)
    return total

if __name__ == "__main__":
   while True :
       try:
            datas = input().split(" ")
            if datas[0] == '' :
                raise EmptyError("empty String")
            print(robust_sum(datas))
       except EmptyError:
           break
       except DataError as e:
           print("("+str(e.data)+")")