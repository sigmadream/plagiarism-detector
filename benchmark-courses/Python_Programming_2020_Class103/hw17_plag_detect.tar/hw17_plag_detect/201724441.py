
def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            print("(",total,")")
            return 0
    print(total)
if __name__ == "__main__":
    while True:
        x = input()
        if(x == ""):
            break
        xlist = x.split()
        for x in [xlist]:
            robust_sum(x)




     