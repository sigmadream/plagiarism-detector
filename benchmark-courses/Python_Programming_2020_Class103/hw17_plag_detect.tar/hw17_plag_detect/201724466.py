class DataError(Exception):
    def __init__(self, data):
        self.data = data
    
def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(total)
    return total

    
def main():
    while True:
        xs = input().split()
        try:
            if len(xs) == 0:
                break;
            print(robust_sum(xs))
        except DataError as e:
            print(f"({e.data})")

if __name__ == "__main__":
    main()
