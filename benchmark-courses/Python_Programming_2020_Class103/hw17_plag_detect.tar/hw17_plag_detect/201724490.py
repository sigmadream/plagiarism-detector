def input_sum(x2):
    x1 = x2.split()
    total_sum = 0
    for i in x1:
        try:
            total_sum = total_sum + int(i)
        except ValueError:
            print("(", end="")
            print(total_sum, end="")
            print(")")
            return 0
    print(total_sum)

if __name__ == "__main__":
    while 1:
        x = input()
        if x == "":
            break
        else:
            input_sum(x)
