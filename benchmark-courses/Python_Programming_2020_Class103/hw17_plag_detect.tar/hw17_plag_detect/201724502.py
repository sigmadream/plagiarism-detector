class EmptyError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            return f"({total})"
    return total

if __name__ == "__main__":
    ks = []
    for k in range(2):
        x = input()
        xs = x.split()
        ks.append(xs)    
    for ls in ks:
        if ls == []:
            raise EmptyError(ls)
        else:
            try:
                print(robust_sum(ls))
            except EmptyError as e:
                break
              
