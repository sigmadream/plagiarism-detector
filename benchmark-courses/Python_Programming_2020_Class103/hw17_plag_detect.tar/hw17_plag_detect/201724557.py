class DataError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data

class EmptyLineError(Exception):
    def __init__(self,msg ="line is empty"):
        pass

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            print('('+str(total)+')')
            raise DataError(x)
    return total

def main():
    while True:
        try:
            input_list = [i for i in input().split()]
            if not input_list:
                raise EmptyLineError()
        except EmptyLineError:
            break

        try:
            int_sum = robust_sum(input_list)
            print(int_sum)
        except DataError:
            pass

if __name__ == '__main__':
    main()
