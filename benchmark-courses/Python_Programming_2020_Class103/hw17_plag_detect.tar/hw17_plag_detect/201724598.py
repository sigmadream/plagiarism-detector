total = 0
xs = input().split()
for x in xs:
        try:
            total += int(x)
        except :
            print("(",end="")
            print(total,end="")
            print(")")
            break
print(total)
