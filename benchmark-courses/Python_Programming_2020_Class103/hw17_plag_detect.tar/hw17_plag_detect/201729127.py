
res = 0
class DataError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data

def robust_sum(xs):
    global res
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(x)
    res = total
    return total

if __name__ == "__main__":
    a = []
    while 1:
        b = input()
        if b == "":
            break
        a.append(b.split())
    for ls in a:
        try:
            print(robust_sum(ls))
        except DataError as e:
            print(f"({res})", end="\n")
