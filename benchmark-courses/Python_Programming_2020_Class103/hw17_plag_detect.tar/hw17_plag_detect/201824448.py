class DataError(Exception):
    def __init__(self, data, msg="hi"):
        super().__init__(msg)
        self.data = data

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            print(end="")
            print("(",total, ")")
            print()
            raise DataError(x)
        except NameError:
            print()
    return total
if __name__ == "__main__":
    while True:
        n = input().split(" ")
        for ls in [n]:
            try:
                print(robust_sum(ls))
            except DataError as e:
                del(e)
        if n == "":
            break;