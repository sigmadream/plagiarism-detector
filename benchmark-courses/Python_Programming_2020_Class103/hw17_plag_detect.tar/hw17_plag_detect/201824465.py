def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
                r = "("+str(total)+")"
                return r

    return str(total)

class EmptyError(Exception):
    def __init__(self):
        super().__init__()


if __name__ == "__main__":
    result = []
    while(True):
        try:
            ls = input().split()
            if not ls:
                raise EmptyError
            result.append(robust_sum(ls))
        except EmptyError as e:
            for i in result:
                print(i)
            exit()
        

            
        
        

