class DataError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data

def rsum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(total)
    return total

if __name__ == "__main__":
    l = input()
    ls = l.split()
    while not l in '\n':
        try:
            print(rsum(ls))
        except DataError as e:
            print(f"({e.data})")
        l = input()
        ls = l.split()
