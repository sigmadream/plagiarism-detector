class EmptyError(Exception):
    def __init__(self):
        super().__init__()
def getResult(nums):
    result = 0
    if len(nums) == 0:
        raise EmptyError()
    
    for i in range(len(nums)):
        try:
            nums[i] = int(nums[i])
        except ValueError:
            return str(result)
        else:
            result += nums[i]
    return result
if __name__ == '__main__':
    while True:
        num = input().split()
        try:
            print('(' + getResult(num) + ')')
        except TypeError:
            print(getResult(num))
        except EmptyError:
            break
