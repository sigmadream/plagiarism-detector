def sum(nums):
    ttl = 0
    try:
        for n in nums:
            ttl += int(n)
    except ValueError:
        return(f'({ttl})')
    else:
        return(ttl)

class EmptyLineError(Exception):
    pass

def main():
    while True:
        try:
            nums = input()
            if not nums:
                raise EmptyLineError
        except EmptyLineError:
            nums = input()
            break
        else:
            nums = nums.split(' ')
            ttl = sum(nums)
            print(ttl)
            

if __name__ == "__main__":
    main()
