#coding: utf-8

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            s = '(' + str(total) + ')'
            return s
    return total



