
def robust_sum(xs):
    total=0
    for x in xs:
        try:
            total+=int(x)
        except ValueError as verr:
            return total
    return total

def main():
    xl = input()
    xs = xl.split()
    try:
        print(robust_sum(xs))
    except DataError:    
        print('(' + str(total) + ')')

if __name__=="__main__":
    main()
