class DataError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data



def rsum(s):
    total = 0
    for i in s:
        try:
            total += int(i)
        except ValueError:
            raise DataError(total)
    return total



if __name__ == "__main__":
    a = []
    while True:
        s = input()
        if not s:
            break
        try:
            a.append(rsum(s.split()))
        except DataError as e:
            a.append(f"({e.data})")
    print(*a, sep="\n")