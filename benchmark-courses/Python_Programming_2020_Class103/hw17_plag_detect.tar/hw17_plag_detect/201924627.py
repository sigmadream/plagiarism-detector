class DataError(Exception):
    def __init__(self, data, msg="not convertable to int"):
        super().__init__(msg)
        self.data = data

class EmptyLineError(Exception):
    def __init__(self, data, msg="empty line met"):
        super().__init__(msg)
        self.data = data

def robust_sum(xs):
    if xs == []:
        raise EmptyLineError(xs)
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(total)
    return total

if __name__ == "__main__":
    while True:
        inp = input()
        mylst = []
        for i in inp.split():
            try:
                mylst.append(int(i))
            except ValueError:
                mylst.append(i)
        try:
            print(robust_sum(mylst))
        except DataError as e:
            print(f"({e.data})")
        except EmptyLineError:
            break
