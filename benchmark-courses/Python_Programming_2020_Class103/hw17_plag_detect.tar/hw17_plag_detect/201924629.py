def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            return f'({total})'
    return total


line = input()
lst = [line]
while line != '':
    line = input()
    lst.append(line)
lst.pop()

for i in lst:
    print(robust_sum(i.split()))
