import sys

class DataError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(total)
    return total

if __name__ == "__main__":
    lines = []
    for line in sys.stdin:
        li = line.split()
        xs = []
        for x in li:
            if x.isdigit():
                xs.append(int(x))
            else:
                xs.append(x)
        lines.append(xs)
    for ls in lines:
        if not ls:
            break
        else:
            try:
                print(robust_sum(ls))
            except DataError as e:
                print(f"({e.data})")
