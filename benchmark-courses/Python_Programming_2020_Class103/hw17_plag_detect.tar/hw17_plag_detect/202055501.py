
# class DataError(Exception):
#     def __init__(self, data, msg="not convertible to int"):
#         super().__init__(msg)
#         self.data = data


def robust_sum(line):
    global total
    sumline = 0
    line = line.split(" ")

    for x in line:
        try:
            sumline += int(x)
        except ValueError:
            print(f"({sumline})")
            return 0
    return sumline

def main():
    global total

    bol = True
    while bol:
        line = input()
        if line == "":
            bol = False

        rv = robust_sum(line)
        if rv != 0:
            print(rv)

           

if __name__ == '__main__':
    total = 0
    main()
