
class DataErr0r(Exception):
    def __init__(self, data, msg="CHECK DATA"):
        super().__init__(msg)
        self.data = data

def robust_sum(no):
    rsum = 0
    for i in no:
        try:
            rsum += int(i)
        except ValueError:
            raise DataErr0r(rsum)
    return rsum

if __name__ == "__main__":
    while True:
        line = input()
        if line == "":
            break
        else:
            parsed = line.split(" ")
            try:
                print(robust_sum(parsed))
            except DataErr0r as err:
                print(f"({err.data})")
