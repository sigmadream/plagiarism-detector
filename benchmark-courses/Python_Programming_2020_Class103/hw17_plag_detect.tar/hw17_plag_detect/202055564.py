class DataError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(x)
    return total

if __name__ == "__main__":
    lis=[]
    for ii in range(100):
        a = input().split()
        lis.append(a)
        if (a==[]):
            break
    
    
    for ls in lis:
        try:
            if(robust_sum(ls) == 0):
                break
            print(robust_sum(ls))
        except DataError as e:
            n = e.data
            k = ls.index(n)
            s = 0
            for i in range(k):
                s = s+ int(ls[i])
            g = '('+str(s)+')'
            print(g)
        
