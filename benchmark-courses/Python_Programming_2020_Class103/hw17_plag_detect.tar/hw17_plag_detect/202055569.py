class DataError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(x)
    return total

if __name__ == "__main__":
    numlist = []
    numsum = []
    while True:
        num = input()
        if(num == ""):
            break
        else:
            numlist.append(num)
    for i in range (0, len(numlist)):
        numlist[i] = numlist[i].split()
        for x in range(0, len(numlist[i])):
            while numlist[i][x].isdigit():
                numlist[i] = list(map(int, numlist[i]))
                print(numlist[i])
            if(numlist[i][x].isalpha()):               
                for t in range(x, len(numlist[i])):
                    del numlist[i][t]

        print(numlist[i])
        for j in range(0, 1):
            numsum.append(sum(numlist[i]))
    for k in range(0, len(numsum)):
        print(numsum[k])
