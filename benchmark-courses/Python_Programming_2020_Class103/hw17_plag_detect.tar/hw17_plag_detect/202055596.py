def f_sum(line):
    result = 0
    check = 0
    try :
        line = list(map(int,line))
        result = sum(line)
        return result, check
    except (TypeError, ValueError):
        for i in range(len(line)):
            try:
                result+=int(line[i])
            except ValueError:
                break
        return result, 1

if __name__ == "__main__":
    result, check = 0, 0
    while True:
        line = input()
        if line != "":
            line = line.split()
            result, check = f_sum(line)
            if check == 0:
                print(result)
            else:
                print("("+str(result)+")")
        else:
            break