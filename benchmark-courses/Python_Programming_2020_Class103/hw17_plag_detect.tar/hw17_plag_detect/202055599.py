
def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            return f"({total})"
    return total

def main():
    xs = input(">>> ")
    while xs != "":
        xs = xs.split()
        print(robust_sum(xs))
        xs = input(">>> ")



if __name__ == "__main__":
    main()