def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            return f"({total})"
    return total

if __name__ == "__main__":
    line = []
    i = 0
    while True:
        a = input()
        a = a.split()
        if a == []:
            break
        line.append(a)
        i = i + 1
    for j in range(i):
        print(robust_sum(line[j]))
