
def robust(slist):
    total = 0
    for i in slist:
        try:
            total = total + int(i)

        except ValueError:
            total = "("+str(total)+")"
            break
    return total

aaa = input()

alist = (aaa.split("\n"))

for j in alist:
    if j.split(" ") == ['']:
        break
    print(robust(j.split(" ")))


