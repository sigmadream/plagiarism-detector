a = pow(int(input()),2)
b = pow(int(input()),2)


if(a>b):
      print(a-b)
else:
      print(b-a)
