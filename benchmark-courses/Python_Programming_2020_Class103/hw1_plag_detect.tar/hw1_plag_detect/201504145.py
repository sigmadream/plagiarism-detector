#coding : utf-8

a = int(input())
b = int(input())

print(b*b-a*a)

a = int(input())
b = int(input())

if -2^31<=a and b<=2^31-1:
    print(a*a-b*b)

else :
    print("error")
