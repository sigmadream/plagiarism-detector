a = int(input())
b = int(input())

x = a**2 - b**2

if (x<0):
  print(x*-1)
else:
  print(x)