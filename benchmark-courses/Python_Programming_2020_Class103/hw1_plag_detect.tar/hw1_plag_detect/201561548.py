#coding: utf-8

num1 = int(input('num1를 입력해 주세요 : '))
num2 = int(input('num2를 입력해 주세요 : '))
result = num1**2 - num2**2

print(abs(result))


