
a = int(input())
b = int(input())

squareA  = a**2
squareB  = b**2

if squareA > squareB:
    print(squareA-squareB)
else:
    print(squareB-squareA)

