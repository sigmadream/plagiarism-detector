a = int(input())
b = int(input())
c = a * a
d = b * b

e = c - d

if e > 0:
    print(e)
else :
    print(-e)
