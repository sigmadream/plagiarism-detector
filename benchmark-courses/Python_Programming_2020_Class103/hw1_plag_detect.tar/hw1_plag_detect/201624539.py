#coding: utf-8
a = int(input())
b = int(input())

a *=a
b *=b

if a > b:
    print(a-b)
else:
    print(b-a)

