a = int(input())
b = int(input())
result = abs (a*a-b*b)
print(result)