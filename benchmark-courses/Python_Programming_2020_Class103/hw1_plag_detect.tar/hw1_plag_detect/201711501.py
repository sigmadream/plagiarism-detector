a = int(input())
b = int(input())

sq_a = a * a
sq_b = b * b

if sq_a > sq_b:
    print(sq_a - sq_b)
else:
    print(sq_b - sq_a)
