a = int(input())
b = int(input())

def multi(a):
    return a*a


if(multi(a) > multi(b)):
    print(multi(a) - multi(b))
else:
    print(multi(b) - multi(a))

   
