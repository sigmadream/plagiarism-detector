a=int(input())
b=int(input())

A=(a * a)
B=(b * b)

if (A>B):
    print(A-B)
else :
    print(B-A)




    
