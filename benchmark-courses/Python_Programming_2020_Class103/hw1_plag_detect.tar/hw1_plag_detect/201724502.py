#coding: utf-8 #Actually, this comment is not neccesary in this case.

a=int(input())
b=int(input())
x=(a**2)-(b**2)
if x>=0:
    print(x)
else:
    print(-x)
    
