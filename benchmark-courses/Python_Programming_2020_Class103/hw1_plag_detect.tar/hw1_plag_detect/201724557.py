# coding: utf-8

from math import *

a = int(input())
b = int(input())

print(int(fabs(pow(a,2) - pow(b,2))))


