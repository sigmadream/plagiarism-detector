#coding: euc-kr

k=int(input("Enter an integer:"))
m=int(input("Enter an integer:"))
def sq_print(x):
    print(x**2)
def sq_print(y):
    print(y**2)
    
sq_print(k)
sq_print(m)
if k**2>m**2 :
   print(k**2-m**2)
else :
   print(m**2-k**2)
