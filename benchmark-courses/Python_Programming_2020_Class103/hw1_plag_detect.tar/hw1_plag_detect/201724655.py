value1 = int(input())
value2 = int(input())

value1 = value1**2
value2 = value2**2

if(value1>value2):
    print(value1-value2)
else:
    print(value2-value1)
