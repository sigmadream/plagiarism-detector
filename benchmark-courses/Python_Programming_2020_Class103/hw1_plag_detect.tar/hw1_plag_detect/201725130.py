#coding: utf-8

x=int(input())
y=int(input())

print(abs(x*x-y*y))
            
