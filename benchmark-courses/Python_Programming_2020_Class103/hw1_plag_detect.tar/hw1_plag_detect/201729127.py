#coding: utf-8

a = int(input())
b = int(input())
a = a**2
b = b**2
if a>=b:
    print(a - b)
else:
    print(b - a)
