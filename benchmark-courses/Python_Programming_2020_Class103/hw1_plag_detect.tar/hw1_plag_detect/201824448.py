a = int(input())
b = int(input())
if b > -6 :
    print(a**4-b)
else:
    print(a**2-b**2)
