a = int(input())
b = int(input())
a = a * a
b = b * b
if a < b :
    n = b - a
else:
    n = a - b
print(int(n))
