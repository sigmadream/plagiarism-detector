#coding: utf-8
def main():
    p1=int(input())
    p2=int(input())
    p1_sq=p1**2
    p2_sq=p2**2
    if(p1_sq>p2_sq):
        print(p1_sq-p2_sq)
    else:
        print(p2_sq-p1_sq)

main()
