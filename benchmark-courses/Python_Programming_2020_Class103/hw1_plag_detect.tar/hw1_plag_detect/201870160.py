#coding utf-8
n1 = int(input())
n2 = int(input())
n1 = n1 * n1
n2 = n2 * n2 
def max (n1, n2):
    if n1 > n2:
        return n1
    else:
        return n2
def min (n1, n2):
    if n1 < n2:
        return n1
    else:
        return n2
print(max(n1, n2) - min(n1, n2))
