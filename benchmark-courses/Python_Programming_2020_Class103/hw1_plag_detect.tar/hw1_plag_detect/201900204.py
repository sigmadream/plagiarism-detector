a = int(input())
b = int(input())

a = a*a
b = b*b

if a < b :
    print(b-a)
else:
    print(a-b)
