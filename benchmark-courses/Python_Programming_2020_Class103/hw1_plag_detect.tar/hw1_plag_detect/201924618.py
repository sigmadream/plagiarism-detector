#coding: utf-8

a = int(input()) ** 2
b = int(input()) ** 2

def find_max(a, b):
    if a > b:
         return a
    else:
        return b
def find_min(a, b):
    if a < b:
        return a
    else:
        return b

print (find_max(a, b) - find_min (a, b))
