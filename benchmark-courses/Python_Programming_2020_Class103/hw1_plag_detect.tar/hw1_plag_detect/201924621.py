#coding: utf-8
x=int(input())
y=int(input())


if x>y:
    print(x**2-y**2)
else:
    print(y**2-x**2)

