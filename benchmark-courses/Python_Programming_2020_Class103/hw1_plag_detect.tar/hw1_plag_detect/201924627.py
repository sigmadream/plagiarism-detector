a = int(input())**2
b = int(input())**2

print(abs(a - b))
