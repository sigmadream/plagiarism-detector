#coding: utf-8
a=int(input())
b=int(input())
print(abs((a**2)-(b**2)))
