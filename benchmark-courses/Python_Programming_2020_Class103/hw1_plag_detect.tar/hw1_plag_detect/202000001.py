n1 = int(input())
n2 = int(input())

print(abs(n1**2-n2**2))
