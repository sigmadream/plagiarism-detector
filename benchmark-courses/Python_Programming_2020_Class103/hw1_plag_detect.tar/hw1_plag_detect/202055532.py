a = int(input())
b = int(input())
c = a * a
d = b * b
if c > d:
    print(c-d)
else:
    print(d-c)
