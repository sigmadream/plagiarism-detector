#coding: utf-8
a = int(input("1>"))
b = int(input("2>"))

n = (a**2) - (b**2)
if n<0 :
    n = n*-1

print(n)
