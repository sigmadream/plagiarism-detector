a = int(input())
b = int(input())
if a*a > b*b:
    print(a*a-b*b)
else:
    print(b*b-a*a)
