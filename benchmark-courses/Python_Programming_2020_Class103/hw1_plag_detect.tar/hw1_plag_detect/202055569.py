#coding: utf-8
def fun(a, b):
    if((a**2 - b**2) < 0):
        return b**2 - a**2
    else:
        return a**2 - b**2
a = int(input())
b = int(input())
print(fun(a, b))
c = int(input())
d = int(input())
print(fun(c, d))
