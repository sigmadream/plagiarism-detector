#coding: utf-8

print("두 수 제곱의 차이를 구합니다.")

a=input("첫 번쨰 수를 입력해주십시오: ")
x=int(a)
x=x*x

b=input("두 번째 수를 입력해주십시오: ")
y=int(b)
y=y*y


if x>y:
    print(x-y)
else:
    print(y-x)
