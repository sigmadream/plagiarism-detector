n1 = int(input())
n2 = int(input())

a = n1 * n1
b = n2 * n2

if a>b :
    print(a-b)
else:
    print(b-a)
