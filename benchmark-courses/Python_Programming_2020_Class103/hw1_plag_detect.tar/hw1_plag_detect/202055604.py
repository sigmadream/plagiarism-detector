a = int(input())
b = int(input())
squ = a*a - b*b

print(abs(squ))
