"""
n is number of row
m is number of column
"""


#Function oddLine is odd number of row; for exam +---+
def oddLine(m):
    for i in range(0,m):
        print("+---", end='')
    print("+")

#Function evenLine is even number of row; for exam, |   |
def evenLine(m):
    for i in range(0,m):
        print("|   ", end='')
    print("|")
    
        
def line(n,m):
    for i in range(0,n):
        oddLine(m)
        evenLine(m)
    oddLine(m)    

n = int(input())
m = int(input())

line(n,m)

