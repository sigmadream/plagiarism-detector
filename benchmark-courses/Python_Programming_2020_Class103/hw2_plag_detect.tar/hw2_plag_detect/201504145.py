r=int(input())
c=int(input())

def line1():
    print("+---+",end='')
def line():
    print("---+",end='')
def box1():
    print("|   |",end='')
def box():
    print("   |",end='')

a=1
b=0
while b<r:
    if b==0:
        line1()
        while a<c:
            line()
            a=a+1
        a=1
        print()
    box1()
    while a<c:
        box()
        a=a+1
    a=1
    print()
    line1()
    while a<c:
        line()
        a=a+1
    print()
    b=b+1
    a=1
