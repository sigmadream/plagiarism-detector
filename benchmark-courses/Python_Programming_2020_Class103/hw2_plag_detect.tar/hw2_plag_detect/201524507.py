def line(n):
	print('+---' * n +'+')

def box(n):
	print('|   ' * n + '|')

def repeat(k, n):
  while (k>0):
    line(n)
    box(n)
    k = k-1
  line(n)

a = int(input())
b = int(input())

repeat(a, b)