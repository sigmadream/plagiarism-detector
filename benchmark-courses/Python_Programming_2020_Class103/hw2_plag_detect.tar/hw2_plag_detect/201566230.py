def repeat(c, n):
    c = c * n
    if c[0] == '+':
        c = c + '+'
    else :
        c = c + '|'
    print(c)
    
def box(row,col):
    while col > 0:
        repeat('+---', row)
        repeat('|   ', row)
        col -= 1
    repeat('+---', row)
    
n = int(input())
m = int(input())

box(m,n)
