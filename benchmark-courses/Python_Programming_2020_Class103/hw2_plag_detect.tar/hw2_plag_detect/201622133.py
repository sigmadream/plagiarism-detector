def fline():
    print('+---+', end = "")

def repeatfline(m):
    print('---+'*(m - 1))

def sline():
    print('|   |', end = "")

def repeatsline(m):
    print('   |'*(m - 1))
    

def box(row, col):
    while row >  0:
        fline()
        repeatfline(m)
        sline()
        repeatsline(m)
        row = row - 1
        
    fline()
    repeatfline(m)
    
       
        


n = int(input())
m = int(input())
box(n, m)
