
def board(row, col):

    COL = col
    
    while col > 0:
        while row > 0:
            print("+" + "---+"*col)
            print("|" + "   |"*col)
            row = row - 1
        col = col - 1
    
    print("+" + "---+"*COL)

a = int(input())
b = int(input())
board(a, b)
