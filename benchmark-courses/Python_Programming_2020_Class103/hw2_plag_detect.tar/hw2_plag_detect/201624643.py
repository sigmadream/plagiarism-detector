#coding: utf-8
def printLine(col):
    print("+---"*col,end="+\n")

def printMiddleLine(col):
    print("|   "*col,end="|\n")

def pirntBox(row,col):
    while(row>0):
        printLine(col)
        printMiddleLine(col)
        row=row-1
    printLine(col)

row = int(input())
col = int(input())
pirntBox(row,col)