def repeat(c, n):
    s = c * n
    print(s)

def line(n):
    print('+', end="")
    repeat('---+', n)

def space(m):
    print('|', end="")
    repeat('   |', m)
    
def box(row, col):
    while row > 0:
        line(col)
        space(col)
        row = row - 1
    line(col)

n = int(input())
m = int(input())
box(n, m)
