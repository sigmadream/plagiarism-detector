def repeat_col(c, m):
    print('+' + (c * m))
def repeat_row(c, m):
    print("|"+(c * m))
    



def box(row, col):
    while row > 0:
        repeat_col('---+', col)
        repeat_row('   |', col)
        row = row - 1
    repeat_col('---+', col)

    
        
            

n = int(input())
m = int(input())
box(n, m)
