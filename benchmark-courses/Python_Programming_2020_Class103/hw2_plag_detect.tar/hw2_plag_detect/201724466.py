
def line(n):
    print("+---", end = "")

def string(a):
    print("|   ", end = "")

def colum(cl):
    while (cl >0):
        line(cl)
        cl = cl - 1
    print("+")

def row2(ro):
    while (ro >0):
        string(ro)
        ro = ro - 1
    print("|")

def box(row, col):
    while (row >0):
        colum(col)
        row2(col)
        row = row - 1
    colum(col)
    
    
r = int(input())
c = int(input())
box(r, c)
