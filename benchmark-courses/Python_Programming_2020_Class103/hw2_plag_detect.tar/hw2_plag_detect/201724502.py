
def line(col):
    while col>0:
        print("+---",end="")
        col=col-1
    print("+")

def window(col):
    while col>0:
        print("|   ",end="")
        col=col-1
    print("|")
    
def box(row, col):
        while row > 0:
            line(col) 
            window(col)
            row-=1
        line(col)
        
n = int(input())
m = int(input())
box(n,m)
