#coding: utf-8

def start_horizon():
    print("+", end='')

def add_horizon():
    print("---+", end='')

def start_verticality():
    print("|", end='')

def add_verticality():
    print("   |", end='')


def draw_horizontal_line(col):
    for j in range(0,col):
        if j==0:
            start_horizon()
        add_horizon()
    print('\n',end='')


def draw_vertical_line(col):
    for j in range(0,col):
        if j==0:
            start_verticality()
        add_verticality()
    print('\n',end='')

        
def print_box_board(row, col):
    if (row > 0) and (col > 0):
        for i in range(0,row):
            if i==0:
                draw_horizontal_line(col)
            draw_vertical_line(col)
            draw_horizontal_line(col)
    else:
        print('')


ROW = int(input())
COL = int(input())

print_box_board(ROW,COL)
