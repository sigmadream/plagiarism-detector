def width():
      print('+'+'---+'* m)
    
     

    

def makebox(a, b):
    while a > 0:
        width()
        
        print('|'+'   |'* m)
        
        a = a - 1
        
        
        
    width()
    
    
   
n = int(input()) 
m = int(input())
makebox(n,m)
