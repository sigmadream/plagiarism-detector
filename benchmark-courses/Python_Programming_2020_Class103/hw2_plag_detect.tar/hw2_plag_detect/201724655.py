# coding: utf-8

def repeatCol(n):
    print("+---"*n, end = "+")
    print()
    print("|   "*n, end = "|")
    print()  

def box(row,col):
    while(row>0):
        repeatCol(col) 
        row = row - 1
    print("+---"*col, end = "+")

n = int(input())
m = int(input())
if(0<n<100):
    if(0<m<100):
        box(n,m)
else:
    exit(1)
    
