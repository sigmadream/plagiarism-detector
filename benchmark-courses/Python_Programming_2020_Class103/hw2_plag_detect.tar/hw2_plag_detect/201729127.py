def line(n):
    print('+---'*n,'+',sep='')

def endline():
    print('+')
    print('|')

def box(row, col):
        while row>0:
            print('+---'*m,'+', sep='')
            print('|   '*m,'|', sep='')
            row = row-1
        line(m)
            
n=int(input())
m=int(input())
box(n,m)

