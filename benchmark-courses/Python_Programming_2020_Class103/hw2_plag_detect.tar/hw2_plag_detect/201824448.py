#coding: utf-8

a="---+"
b="   |"

def box(n):
    while (n>0):
        repeatA(a, m)
        repeatB(b, m)
        n=n-1
    repeatA(a,m)
def repeatA(c,n):
    s=c*n
    print('+', end=s)
    print()
    
def repeatB(c,n):
    s=c*n
    print('|', end=s)
    print()
    
n=int(input())
m=int(input())
box(n)

