def box(row,col):
    print('+'+'---+'*col)
    while row > 0 :
        print('|'+'   |'*col)
        print('+'+'---+'*col)
        row = row-1

n = int(input())
m = int(input())
box(n,m)


