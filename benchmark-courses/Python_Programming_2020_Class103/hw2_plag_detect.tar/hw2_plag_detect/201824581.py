def line(col):
    print('+',end='')
    while col > 0:
        print('---+',end='')
        col = col - 1 

def line2(col):
    print('|',end='')
    while col > 0:
        print('   |',end='')
        col = col - 1
        
def box(row,col):
    line(col)
    print()
    while row > 0:
        line2(col)
        print()
        line(col)
        print()
        row = row - 1
   
n = int(input())
m = int(input())

box(n,m)
