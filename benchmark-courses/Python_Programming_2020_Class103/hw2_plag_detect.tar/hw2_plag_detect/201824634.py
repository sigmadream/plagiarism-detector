def line(col):
    while col >0:
        print("+---",end="") 
        if(col-1 ==0):       
            print("+")
        col=col-1
        
def box(row,col):
    i = row
    j = col
    while i > 0 :
        line(col)
        j = col
        while j > 0 :
            print("|   ",end="")
            if(j-1 == 0 ):
                print("|")
            j = j - 1
        i = i - 1        
    line(col)
    
n= int(input())
m= int(input()) 

box(n, m)
    
