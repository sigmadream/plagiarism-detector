
def horizontal_line(m): #평행선 출력
    print("+"+"---+"*m)
    
def vertical_line(m): #수직선 출력
    print("|"+"   |"*m)
    
def add_column(m): # 열 추가 함수
    horizontal_line(m)
    vertical_line(m)
    horizontal_line(m)

def add_row(m,n): # 행 추가함수
    while(n>1):
        vertical_line(m)
        horizontal_line(m)
        n=n-1
    
def run(n,m):  #함수 실행 함수
    add_column(m)
    add_row(m,n)
    
    
def main():  #메인 함수
    n=int(input())
    m=int(input())
    run(n,m)
    


main()
    
