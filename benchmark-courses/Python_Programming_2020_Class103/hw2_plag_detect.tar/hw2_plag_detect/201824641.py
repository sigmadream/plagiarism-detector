def print_line():
    print("+---", end='')
def print_col():
    print("|   ", end='')
def last_col():
    print('|')
def last_line():
    print('+')
def print_box(row, col):
    j = col
    while row > 0:
        while j > 0:
            j = j - 1
            print_line()
        j = col
        last_line()
        while j > 0:
            j = j - 1
            print_col()
        last_col()
        j = col
        row = row - 1
    while j > 0:
        j -= 1
        print_line()
    last_line()
n = int(input())
m = int(input())
print_box(n, m)
