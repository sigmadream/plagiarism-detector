#coding: utf-8

def repeat (c, n):
    s = c * n
    print(s)

def section(m):
    print("|", end="")
    for i in range(m):
        print("   |", end="")
    print("")
    print("+", end="")
    for i in range(m):
        print("---+", end="")
    print("")

def line(m):
    print("+", end="")
    for i in range (m):
        print("---+", end="")
    print("")
def box(n,m):
    line(m)
    for i in range(n):
        section (m)
        
n = int(input())
m = int(input())
box(n, m)
