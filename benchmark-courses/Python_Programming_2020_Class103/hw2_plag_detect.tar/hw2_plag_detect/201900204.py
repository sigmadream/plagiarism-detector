#coding: utf-8

def repeater(c, n):
    print(c*n)

def board(row, col):
    while row > 0:
        print('+---+' * col)
        print('|   |' * col)
        row = row - 1
    print('+---+' * col)
    
n = int(input())
m = int(input())
board(n, m)

