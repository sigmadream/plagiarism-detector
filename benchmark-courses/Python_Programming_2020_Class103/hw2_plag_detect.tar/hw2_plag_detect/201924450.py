def repeat(c,n):
    s=c*n
    print(s)

def line(n):
    print("+---+",end='')
    print("---+"*n)
   

def box(row,col):
    col=col-1
    while row>0:
        line(col)
        print("|   |",end='')
        print("   |"*col)
        row=row-1
    line(col)

n=int(input())
m=int(input())


box(n,m)

              
