def line1(col):
    while col>0:
        print("+---", end="")
        col=col-1
    print("+")

def line2(col):
    while col>0:
        print("|   ", end="")
        col=col-1
    print("|")    
    
def box(row,col):
    while row>0:
        line1(col)
        line2(col)
        row=row-1
        
    line1(col)

n = int(input())
m = int(input())
box(n,m)
    
        
    
        
    
    
