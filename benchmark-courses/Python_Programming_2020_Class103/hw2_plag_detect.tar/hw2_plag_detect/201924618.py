#coding: utf-8

def line():
    print('+---', end="")
def line2():
    print('|   ', end="")
    
def box(row, col):
    m = col
    
    
    while row>0:
        while col > 0:
            line()
            col = col - 1
        col = m
        print('+')
        
        while col > 0:
            line2()
            col = col -1
        col = m
        print('|') 


        row = row - 1
        
    while col > 0:
        line()
        col = col - 1
    col = m
    print('+')  
        
n = int(input())
m = int(input())
box(n, m)

        
        
    

