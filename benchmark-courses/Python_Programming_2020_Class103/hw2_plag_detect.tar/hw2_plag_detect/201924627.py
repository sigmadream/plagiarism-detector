def set_char1(row_type):
    if row_type == 1:
        return '+'
    elif row_type == 0:
        return '|'

def set_char2(row_type):
    if row_type == 1:
        return '-'
    elif row_type == 0:
        return ' '

def set_row_type(x):
    if x % 2 == 0:
        return 1
    return 0

def print_row(size, row_type):
    char1 = set_char1(row_type)
    char2 = set_char2(row_type)
    for i in range(size * 4 + 1):
        if i % 4:
            print(char2, end='')
        else:
            print(char1, end='')
    print()

def print_table(x, y):
    for i in range(x * 2 + 1):
        row_type = set_row_type(i)
        print_row(y, row_type)

a = int(input())
b = int(input())
print_table(a, b)
