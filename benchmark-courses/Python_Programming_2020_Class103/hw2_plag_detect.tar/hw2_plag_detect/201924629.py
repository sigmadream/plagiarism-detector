def repeat (c,n):
    s=c*n
    print(s)

    
def box(row,col):
    print("+",end="")
    repeat("---+",col)
    while row>0:
        if col>0:
             
             print("|", end="")
             repeat("   |",col)
             print("+", end="")
             repeat("---+",col)
        row=row-1
      
n=int(input())
m=int(input())
box(n,m)

