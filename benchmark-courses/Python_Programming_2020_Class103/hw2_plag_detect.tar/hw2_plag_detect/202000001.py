def printBoundary(c):
    boundary = ""
    for i in range(c):
        boundary = boundary + "+---"
    boundary = boundary + "+"
    print(boundary)

def printCell(c):
    cell = ""
    for i in range(c):
        cell = cell + "|   "
    cell = cell + "|"
    print(cell)

def drawBoard(n,m):
    for i in range(n):
        printBoundary(m)
        printCell(m)
    printBoundary(m)

n = eval(input()) #rows
m = eval(input()) #colums
drawBoard(n,m)
