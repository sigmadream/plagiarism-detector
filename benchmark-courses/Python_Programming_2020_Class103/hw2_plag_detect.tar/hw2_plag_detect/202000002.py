def repeat(c, n):
    print(c * n)

def line():
    print('+---+')


def box(row, col):
    while row > 0:
        line()
        print('|   |')
        row = row - 1
    line()

n = int(input())
m = int(input())
box(n, m)
