def line():
    print('+' + ('---+'* m))
    

def box(row, col):
    while row > 0:
        line()
        print('|' +( '   |'*m))
        row = row - 1    
    line()
    

n = int(input())
m = int(input())

box(n, m)
    


