def repeat(c,a):
    print(c * a)

def line():
    print('+---+')

def star(col):
    if col > 0:
        print("+---", end="")
        star(col-1)
    else:
        print("+")

def moon(col):
    if col > 0:
        print("|   ", end="")
        moon(col-1)
    else:
        print("|")

def box(row,col):
        while row > 0:
            star(col)
            moon(col)
            row = row -1
        star(col)



    
    
n = int(input())
m = int(input())
box(n, m)
