def line(a):
    print("+", end="")
    print("---+"*a)

def line_2(a):
    print("|", end="")
    print("   |"*a)

def box(a, b):
    i = a
    line(b)
    while i>0:
        line_2(b)
        line(b)
        i = i - 1
        
n = int(input(">"))
m = int(input(">"))

box(n, m)
