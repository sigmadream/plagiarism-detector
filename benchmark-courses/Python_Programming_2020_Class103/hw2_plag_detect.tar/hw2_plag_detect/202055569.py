def repeat(c, n):
    print(c * n)

a = "---+"
b = "   |"

def line():
    print("+---+" + a)
    
def box(row, col):
    while row > 0:
        print("+---+" + a * (col - 1))
        print("|   |" + b * (col - 1))
        row = row - 1
    print("+---+" + a * (col - 1))

n = int(input())
r = int(input())
box(n, r)
