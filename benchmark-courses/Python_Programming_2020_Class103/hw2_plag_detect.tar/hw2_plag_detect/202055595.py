#conding: utf - 8

def repeat(c, n):
     s = c *n
     print(s)

    
def box(row, col):
    while row > 0:
             print('+', end=""); repeat('---+', m) 
             print('|', end=""); repeat('   |',m)
             row = row -1
    print('+', end=""); repeat('---+',m)
  

n = int(input())
m = int(input())


box(n,m)






