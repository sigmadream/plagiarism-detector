#coding: utf-8

def box(col, row):
    row=row-1
    while col>0:
        print('+---+'+'---+'*row)
        print('│   │'+'   │'*row)
        col=col-1
    print('+---+'+'---+'*row)

n=int(input("세로: "))
m=int(input("가로: "))
if n<=0 or m<=0:
    print("Error...")
    print("양수만 입력하십시오.")
    quit
else:
    box(n, m)

