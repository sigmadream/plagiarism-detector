def box(row,colum):
    while row>0:
        print('+---'*colum, end='+\n')
        print('|   '*colum, end='|\n')
        row=row-1
    print('+---'*colum, end='+')



n=int(input())
m=int(input())
box(n,m)
