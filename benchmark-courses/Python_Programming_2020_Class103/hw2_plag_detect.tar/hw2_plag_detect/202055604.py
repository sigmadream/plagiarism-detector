ceiling = "+---"
column = "   |"


def boxmaker(ver,hor):
    for i in range(ver):
        print(ceiling*hor+"+")
        print("|"+column*(hor))
    print(ceiling*hor+"+")

x = int(input())
y = int(input())

boxmaker(x,y)
