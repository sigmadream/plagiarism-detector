def printNext(i):
    a=""
    j=0
    while(j < i) :
        a= a+splitedInputString[0]
        j=j+1
    return a
        

inputString = input()
splitedInputString = inputString.split()

s=""
i=1
while(i < len(splitedInputString)):        
    s = s+ printNext(int(splitedInputString[i]))
    i=i+1
    print(s)
    
