n=input().split()
sum=''
for i in range(1,len(n)):
    sum=sum+n[0]*int(n[i])
    print(sum)
