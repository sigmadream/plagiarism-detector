# -*- coding: utf-8 -*-
def repeat(c,n):
    c=str(c)
    print(c*n)

def main():
    a=input().split()
    sym=a[0]
    sum=0
    for i in a[1:]:
        i = int(i)
        sum += i
        repeat(sym, sum)

main()
