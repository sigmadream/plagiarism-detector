def main():
    n = input().split()
    count = 0
    for i in range(len(n)-1):
        n[i+1] = int(n[i+1])
    

    for i in range(len(n)-1):
        count = count + n[i+1]

        for j in range(count):
            print(n[0],end='')
        print()
main()