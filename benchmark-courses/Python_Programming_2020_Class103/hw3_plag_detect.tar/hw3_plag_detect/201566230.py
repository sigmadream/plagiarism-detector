def printer(shape, sum):
    for i in range(sum):
            print(shape, end='')
    
def main():
    str = input()
    strlist = str.split()
    
    shape = strlist[0]
    numlist = strlist[1:]

    sum = 0
    for num in numlist:
        sum+=int(num)
        printer(shape, sum)
        print()

main()
