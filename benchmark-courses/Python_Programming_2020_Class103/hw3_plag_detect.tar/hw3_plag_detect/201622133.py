# -*- coding: utf-8 -*-

def repeat(c,n):
    print(c * n) 
    
def main():
    s = input().split()
    symbol = s[0]
    s[0:1] = []
    add = 0
    for number in s:
        n = ord(number) - 48
        add = add + n
        repeat(symbol,add)
        
main()
