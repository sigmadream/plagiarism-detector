# -*- coding: utf-8 -*-

def printline(c, n):
    print(c * n)


def main():

    SymbolNumbers = input()
    numlist = SymbolNumbers.split()
    
    a = int((len(SymbolNumbers)-1)/2)
    cnt = 0
   
    for i in range (a):
        cnt = cnt + int(numlist[i+1])
        printline(numlist[0] , cnt)

main()            
