#coding: utf-8

def main():
    symbolnNum = input().split(' ')
    length = len(symbolnNum)
    symbol = symbolnNum[0]
    for i in range(1,length):
        symbolnNum[i] = int(symbolnNum[i])
    numindex = 1
    numrepeat = 0
    while (numindex< length) and (symbolnNum[numindex] >= 0):
        numrepeat += symbolnNum[numindex]
        for i in range(numrepeat):
            print(symbol, end='')
        print()
        numindex += 1

main()
