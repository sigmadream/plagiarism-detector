def main():
    inputs = input().split()
    sums = 0;
    for data in inputs:
        if(data==inputs[0]):
            continue
        else:
            sums += int(data)
            for num in range(sums):
                print(inputs[0],end="")
            print()

main()