def repeat(c, n):
    s = c * n
    print(s)

def main():
    inputData = input().split()
    symbol = inputData[0]
    numlist = inputData[1:]
    number = 0
    for inputNum in numlist:
        if inputNum != None:
           number = number + int(inputNum)
           repeat(symbol, number)
        else:
            break

main()
