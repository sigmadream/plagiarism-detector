def main():
    symbols = input()
    symlist = symbols.split()
    c = symlist[0]
    n = 0
    for i in symlist[1:len(symlist) + 1]:
        t = int(i)
        n = n + t
        for f in range(n):
            print(c, end="")
        print()

    

main()
