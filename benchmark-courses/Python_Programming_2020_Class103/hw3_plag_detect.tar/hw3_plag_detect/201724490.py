

def main():
    
    list = {}
    list = input().split()
    
    a = list[0]
    n = len(list)
    for i in range(1,n): 
        for j in range(1,i+1):
           print(a*int(list[j]),end = '')
        print('')

main()

        
    

    
    
