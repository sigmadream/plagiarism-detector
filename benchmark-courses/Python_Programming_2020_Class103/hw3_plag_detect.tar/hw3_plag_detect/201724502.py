# -*- coding: utf-8 -*-

def repeat(m,n):
        for i in range(n):
            print(m, end="")
        print()

def main():
    n = 0
    symbols = input()
    symlist = symbols.split()
    for sym in symlist:
        if sym == symlist[0] :
            m = sym
        else:
            k = int(sym)
            n = n + k
            repeat(m,n)
main()
