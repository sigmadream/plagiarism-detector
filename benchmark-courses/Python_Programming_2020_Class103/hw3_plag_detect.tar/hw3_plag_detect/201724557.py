import sys

def draw_graph_raw(cum_length, graph_pattern):
    for i in range(0,cum_length) :
        print(graph_pattern[0],end='')
    print()

def main() :
    get_pattern = sys.stdin.readline()
    graph_pattern = get_pattern.split()

    cum_length=0

    for i in range(1, len(graph_pattern)) :
        cum_length+=int(graph_pattern[i])
        draw_graph_raw(cum_length, graph_pattern)

main()