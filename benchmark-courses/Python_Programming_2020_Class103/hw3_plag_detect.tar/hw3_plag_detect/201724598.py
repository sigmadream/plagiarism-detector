#-+-coding: utf-8 -*-
def main():
    list = {}
    list = input().split()

    sym = list[0]
    n = len(list)

    for i in range(1, n):
        for j in range(1, i+1):
            print(sym*int(list[j]),end='')
        print('')

main()

