# -*- coding: utf-8 -*-
def main():
    lst2 = []
    str = input('')
    lst1 = str.split()
    i = 0
    while i <= len(lst1) + 1:
        lst2.append(int(lst1.pop()))
        i += 1
    # print(lst)
    lst = list(reversed(lst2))
    for x in range(len(lst)):
        x += 1
        for a in range(x):
            for b in range(lst[a]):
               # print(lst[a],end=' ')
                print(lst1[0], end=' ')
        print()



main()











