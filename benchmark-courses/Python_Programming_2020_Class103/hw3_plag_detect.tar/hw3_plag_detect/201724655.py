# -*- coding: utf-8 -*-
def repeat(char, rptnum):
    for i in range(rptnum):
        print(char, end = "")
    print()

list_input = list(input().split())
input_symbol = list_input.pop(0)
list_input2 = list(map(int, list_input)) 
temp = 0
len_list = len(list_input2)

for i in range(len_list):
    temp += list_input2[i]
    repeat(input_symbol, temp) 


