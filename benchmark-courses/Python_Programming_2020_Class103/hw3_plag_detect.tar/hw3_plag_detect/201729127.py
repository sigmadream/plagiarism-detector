#run without debugging 하고 terminal 이나 output 누름

def repeat(c, n):
    print(c*n)

def main():
    total = 0
    symlist=input().split()
    for i in range(1,len(symlist)):
        symlist[i] = int(symlist[i])
        total += symlist[i]
        repeat(symlist[0],total)

main()