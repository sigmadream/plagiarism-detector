# -*- coding: utf-8 -*-

n=input("")
def main():
    nlist = n[1:].split()
    a=0
    for sym in nlist:
        m = ord(sym) - 48
        a += int(m)
        for i in range(a):
            print(n[0], end="")
        print()
main()
