def main():
    symlist = input().split()
    a = symlist[0]
    symlist.pop(0)
    sum = 0
    for sym in symlist:
        sum = sum + int(sym)
        print(a*sum)



main()

