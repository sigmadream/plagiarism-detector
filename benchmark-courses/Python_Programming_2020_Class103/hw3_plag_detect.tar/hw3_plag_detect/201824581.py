def main(c):
     char = c[0]
     num = c[1:]
     numlist = num.split()
     n = 0
     for num in numlist:
         n = int(num) + n
         for i in range(n):
             print(char, end='')
         print()

c = input()
main(c)
