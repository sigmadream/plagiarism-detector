def repeat(c,n):
    cur=[ ]
    z=""#공백스트링생
    ch = list(map(int,c[1:n])) #1~n인덱스로 분리하여 int형으로 매핑한 후 리스트 ch로만들
    for i in ch:         
        z =z+ (c[0] *i)
        print(z)    
    
c =input().split()# input().split()으로 값을 여러 개 입력받고 정수, 실수로 변환할 때도 map
repeat(c,len(c))
#print("INDEX",c[len(c)-1])

