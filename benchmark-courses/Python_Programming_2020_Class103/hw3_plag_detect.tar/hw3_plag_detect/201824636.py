
def print_line(char,n): # char에 문자(기호) n만큼 출력해주는는 singleline 출력 함수 
    for i in range(n):
        print(char,end="")
    print()


def main(): #메인함수 
    str = input()
    tokens=str.split()
    char=tokens[0]
    length=len(tokens)
    total_num=0
    for i in range(1,length):
        total_num=total_num+int(tokens[i])
        print_line(char,total_num)
    

main()
