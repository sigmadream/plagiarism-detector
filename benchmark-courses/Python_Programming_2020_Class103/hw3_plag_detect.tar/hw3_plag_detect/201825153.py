def repeat(c,d):
    s = c*d
    return(s)

def main():
    symbols = input()
    symlist = symbols.split()
    a = 0
    for number in symlist[1:]:
        n = int(number)
        print(repeat(symlist[0], n+a))
        a += n
        
main()
