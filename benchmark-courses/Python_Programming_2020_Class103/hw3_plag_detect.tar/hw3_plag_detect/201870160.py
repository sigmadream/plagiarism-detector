#coding: utf-8

def repeat (c, n):
    s = c * n
    print(s)

def main():
    symbols = '! @ # $ % '
    symlist = symbols.split ()
def section(m):
    for i in range(m):
        print(symbol, end='')
    print('')
def line(m):
    for i in range(m):
        print (symbol)
symbol=input()
m=int(input())
a =int(input())
c = int(input())

print()
