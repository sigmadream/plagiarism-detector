def main():
    sym=input().split()
    for i in range(1,len(sym)):
        sym[i]=int(sym[i])
        print(sym[0]*sym[i])
        if i!=len(sym)-1:
            sym[i+1]=int(sym[i])+int(sym[i+1])
        
main()
