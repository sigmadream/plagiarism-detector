def repeat(c,n):
    for i in range(n):
        print(c, end="")
    print()

def main():   
    symbols = input()
    symlist = symbols.split()
    i=0
    for i in range(1,len(symlist)):
        symlist[i]=int(symlist[i])
        
    for i in range(1,len(symlist)):    
        if i==1:
            repeat(symlist[0],symlist[i])
        else:
            n=0
            while i!=0:
                n=n+symlist[i]
                i=i-1
            repeat(symlist[0], n)       
            
        
main()        
   
    
