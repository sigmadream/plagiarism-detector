#coding: utf-8

s = input() 
lst = s.split() 
sym = lst[0] 
acc = 0
for i in lst[1:]: 
    acc += int(i)
    print(sym * acc)
