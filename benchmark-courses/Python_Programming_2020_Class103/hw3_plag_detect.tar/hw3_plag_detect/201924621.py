
def main():

  loopx= []
  str = input('')
  loopa= str.split()
  i = 0
  while i <= len(loopa) + 1:
       loopx.append(int(loopa.pop()))
       i += 1
  #print(loop)
  loop = list(reversed(loopx))
  for x in range(len(loop),0,-1):
      x = x -1
      for a in range(len(loop)-x):
          for c in range(loop[a]):
               # print(loop[a])
              print(loopa[0], end=' ')
      print()





main()
