def print_line(char: str, size: int):
    for i in range(size):
        print(char, end="")
    print()

def main():
    inp = input().split()
    char = inp[0]
    sum = 0

    for i in range(1, len(inp)):
        sum += int(inp[i])
        print_line(char, sum)

if __name__ == "__main__":
    main()
