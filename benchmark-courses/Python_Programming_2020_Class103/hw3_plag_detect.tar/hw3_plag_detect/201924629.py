
def main():
        s=input()
        lst=s.split()
        a=lst[0]
        i=0
        for sym in lst[1:]:
            i+=int(sym)
            print(a*i)
main()


        
