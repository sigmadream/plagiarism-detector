def p(s):
    print(s)
def main():
    #print("#"*8)
    a = input().split()
    s = ""
    #print(s)
    for i in range(1,len(a)):
        for j in range(int(a[i])):
            s = s+a[0]
        p(s)
        #print(s*int(a[i]))
main()
