#StudentID: 202055501
#Name: Dimitrova Dilyana

def PrintLineofSymbols(num,symbol):
    print(symbol*num)



def main():
    
    string =input()
    char = string[0]
    strlist = list(string.split(" "))
    n=0; j=1
    for i in strlist[1:]:
        if int(strlist[j]) < 0:
            j=j+1
        else:        
          n= n+int(strlist[j])
          PrintLineofSymbols(n,char)
          j=j+1
              
    
    
if __name__ == '__main__':
    main()