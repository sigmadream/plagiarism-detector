def some(c, n):
    print(c * n)
    
def main():
    k = input()
    S = str(k[0])
    i = 1
    temp = 0
    sp = k.split()
    while i < len(sp):
                if temp >= 0:
                    temp = temp + int(sp[i])
                    some(S, temp)
                i = i + 1

main()


