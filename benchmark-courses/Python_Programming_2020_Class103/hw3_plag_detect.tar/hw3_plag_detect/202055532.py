def main():
    symbol = input()
    symlist = symbol.split()
    a = symlist[0]
    if a == '-':
        b = int(symlist[1])
        c = int(symlist[2])
        d = int(symlist[3])
        e = int(symlist[4])
        print(a*b)
        print(a*(b+c))
        print(a*(b+c+d))
        print(a*(b+c+d))
    else:
        b = int(symlist[1])
        c = int(symlist[2])
        d = int(symlist[3])
        print(a*b)
        print(a*(b+c))
        print(a*(b+c+d))

main()
    

