#coding: utf-8

def graph(a, b) :
    print(a * b)

def main():
    input_data = input()
    data_list = input_data.split()
    pattern = data_list[0]
    data_list[0:1] = []
    n = 0
    for i in data_list :
        n = n + int(i)
        graph(pattern, n)

main()