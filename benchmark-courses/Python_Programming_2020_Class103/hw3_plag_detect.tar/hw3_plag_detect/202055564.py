
def main():
  a = input()
  b = a.split()
  c=b[0]
  b[0:1]=[]
  e=0
  for d in b:
    print(c*(int(d)+e))
    d=int(d)
    e=e+d

main()
