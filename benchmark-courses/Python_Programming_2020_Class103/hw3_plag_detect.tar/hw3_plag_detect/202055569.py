def repeat(c, n):
    print(c * n)

def main():
    symlist = input().split()
    m = symlist[0]
    symlist.remove(m)
    a = 0
    i = 1
    for i in symlist:
        a = a + int(i)
        repeat(m, a)
main()
