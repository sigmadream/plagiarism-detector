# -*- coding: utf-8 -*-

def repeat(c, n):
    m = c *n
    print(m)
    
def main():
     a = input().split()
     s = 0
     for i in a[1:]:
          s += int(i)
          repeat(a[0], s)
         
     
          
main()
    
    
    


     



