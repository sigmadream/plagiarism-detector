#coding: utf-8

inputs = input(': ')
input_list = inputs.split()
sym = input_list[0]
x = 0
for num in input_list[1:]:
    x = x + int(num)
    print(sym * x)
