def main():
    a=0
    sb = nlist[0]
    for i in range(1, b):
        a = int(nlist[i])+a
        for j in range(a):
            print(sb, end="")
        print()

n = input()
nlist = n.split()
b = len(nlist)

main()
