#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Kate
#
# Created:     08-04-2020
# Copyright:   (c) Kate 2020
# Licence:     <your licence>
#-------------------------------------------------------------------------------
def main(string):
    alist = string.split(" ")
    spe = alist.pop(0)
    temp = ""
    for i in range(len(alist)):
        temp = temp + (spe*int(alist[i]))
        print(temp)



anything = input()

main(anything)