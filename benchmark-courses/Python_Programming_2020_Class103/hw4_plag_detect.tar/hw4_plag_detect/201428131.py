#coding: utf-8

def changeString(statements, symbol):
    ls = list(statements)
    vowels= ['a','e','i','o','u']
    k=0
    for c in ls:
        for i in vowels:
            if(c==i):
                ls[k]=symbol
            else:
                continue
        k=k+1

        
    return "".join(ls)
        



if '__main__' == __name__:
    statements= input()
    symbol = input()
    symbolStatement = changeString(statements,symbol)
    print(symbolStatement)
