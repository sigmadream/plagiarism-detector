def printa(a,b):
    table = str.maketrans('aeiou', b * 5)
    return(a.translate(table))
if __name__ == "__main__":
    a=input()
    b=input()
    euna=printa(a,b)
    print(euna)