#coding: utf-8

a = input()
b = input()
vowels = "aeiou"
new_a = []
for letter in a:
    if letter in vowels:
        new_a.append(b)
    else:
        new_a.append(letter)
print(''.join(new_a))
