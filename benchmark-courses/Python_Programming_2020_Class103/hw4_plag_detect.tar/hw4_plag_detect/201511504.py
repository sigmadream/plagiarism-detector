# -*- coding : utf-8 -*-

def vowel(s) :
    ls = list(s)
    vow = ['a', 'e', 'i', 'o', 'u']
    for i in range(len(ls)):
        if ls[i] in vow :
            ls[i] = sym
    return "".join(ls)

if __name__ == "__main__" :
    myword = input()
    sym = input()
    myword = vowel(myword)
    print(myword)
