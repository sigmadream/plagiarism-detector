# coding: utf-8

def replace_mark(s, m):
  alp = ['a','e','i','o','u']
  ls = list(s)
  mark = m
  l = len(ls)

  for i in range(l):
    for j in range(5):
      if ls[i] == alp[j]:
        ls[i] = mark
  
  return "".join(ls)

if __name__ == "__main__":
  word = input()
  mark = input()

  newWord = replace_mark(word, mark)
  
  print(newWord)