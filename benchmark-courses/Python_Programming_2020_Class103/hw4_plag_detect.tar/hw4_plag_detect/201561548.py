
vowels = 'aeiouAEIOU'

def vowelc(w,sym):
    if w not in vowels:
        return w
    else:
        return sym

if __name__ == "__main__" :
    s = input('')
    ls = list(s)
    sym = input('')

    for w in ls:
        print(vowelc(w,sym),end='')
