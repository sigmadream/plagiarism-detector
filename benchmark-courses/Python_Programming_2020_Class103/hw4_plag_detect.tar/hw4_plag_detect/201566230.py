def masking(word, shape):
    retVal=""
    vowels = ['a','e','i','o','u']
    for i in range(len(word)):
        if word[i] in vowels:
            retVal += shape
        else :
            retVal += word[i]
    return retVal

def print_masking(word, shape):
    print(masking(word, shape))

if __name__ == "__main__":
    word = input()
    shape = input()
    print_masking(word, shape)
