#coding: utf-8


def changeToCharacter(s, c):
    ls = list(s)
    
    for n in ls:
        if(n in list("aeiou")):
            n = c
        print(n, end = "")
    
        
        

if __name__ == "__main__":
    inWord = input()
    inCharacter = input()
    changeToCharacter(inWord, inCharacter)
    
    
