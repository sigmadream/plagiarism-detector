#coding: utf-8

def masking_str(s1,s2):
    copy_str = s1
    i = 0

    for i in range (len(copy_str)):
        
        if (copy_str[i] in list("aeiou")) == True:
            print(s2,end="")

        elif (i == (len(copy_str)-1)):
            print(copy_str[i])

        else:
            print(copy_str[i],end="")

    return()

input_str = str(input())
mask_str = str(input())


if __name__ == "__main__":
    
    result_str = masking_str(input_str,mask_str)

