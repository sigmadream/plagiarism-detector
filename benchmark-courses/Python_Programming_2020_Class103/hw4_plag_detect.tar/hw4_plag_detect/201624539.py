# -*- coding: utf-8 -*-


def masking():
    newstring = input()
    newstringlist = list(newstring)
    maskingchar = input()
    vowellist = ['a','e','i','o','u']
    failed = "--failed--"
    if len(newstringlist) == 0:
        return failed
    for i in range(0,len(newstringlist)):
        for j in range(0,5):
            if newstringlist[i] == vowellist[j]:
                   newstringlist[i] = maskingchar
    return newstringlist

if __name__ == "__main__":
    stringinput = masking()
    for i in range (0,len(stringinput)):
        print(stringinput[i],end='')
                   
