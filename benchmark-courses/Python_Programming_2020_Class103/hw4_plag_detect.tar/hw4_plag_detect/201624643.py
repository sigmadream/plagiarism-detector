#coding : utf-8
import re

def replaceStr(_input,_pattern):
    return re.sub('[aeiou]', _pattern, _input)

if __name__ == "__main__":
    _input = input()
    _pattern = input()
    print(replaceStr(_input,_pattern))
