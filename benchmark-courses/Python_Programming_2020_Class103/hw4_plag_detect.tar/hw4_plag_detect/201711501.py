def mask_str(string, c):
    postmask = ""
    for s in string:
        if (s == 'a') | (s == 'e') | (s == 'i') | (s == 'o') | (s == 'u'):
            s = c
        postmask = postmask + s
    return postmask

if __name__ == "__main__":
    word = input()
    character = input()
    transword = mask_str(word, character)
    print(transword)
