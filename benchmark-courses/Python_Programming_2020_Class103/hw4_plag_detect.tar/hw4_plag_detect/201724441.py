# -*- coding: utf-8 -*-

def mask(l_word, masking, vowel):
    for i in range(0, len(word)):
        for j in range(0, len(vowel)):
            if l_word[i] == vowel[j]:
                l_word[i] = masking
    
    print(''.join(l_word))

    
if __name__ == "__main__":

    word = input()
    masking = input()
    vowel = ['a', 'e', 'i', 'o', 'u']

    l_word = list(word)

    mask(l_word, masking, vowel)
    

            
        
            

