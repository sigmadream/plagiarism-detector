# coding: utf-8

def masking(wd,ch):
    wli=list(wd)
    i=0
    while i<len(wli):
        if wli[i] in "aeiou":
            wli[i]=ch
        i=i+1
    return "".join(wli)
            



if __name__ == "__main__":
    wd = input()
    ch = input()
    print(masking(wd,ch))
