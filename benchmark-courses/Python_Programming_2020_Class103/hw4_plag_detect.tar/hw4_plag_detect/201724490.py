# -*- coding: utf-8 -*-

def reverse_str(a,b) :
    ls = list(a)
    for i in range(len(ls)) :
        if ( ls[i] == "a" or ls[i] == "e" or ls[i] == "i" or ls[i] == "o" or ls[i] =="u" ):
            ls[i] = b
    
    return ls
        
if __name__ == "__main__" :
    n = str(input())
    m = str(input())

    l = reverse_str(n,m)
    print("".join(l))
    
