#coding: utf-8

def replace_str(s):
    ls = list(s)
    vowel = ['a', 'e', 'i', 'o', 'u']
    for n in ls:
        for x in vowel:
            if x == n :
                k = ls.index(n)
                ls.insert(k,m)
                ls.remove(n)
    return "".join(ls)



if __name__ == "__main__":
    myword = input()
    m = input()
    result = replace_str(myword)
    print(result)
    

