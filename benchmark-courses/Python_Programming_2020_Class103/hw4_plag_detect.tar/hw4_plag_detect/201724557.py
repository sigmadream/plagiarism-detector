#-------------------------------------------------------------------------------
# Name:        masking.py
# Purpose:     Assignment of computer programming lecture.
#
# Author:      SooHyun Jang
#
# Created:     23-04-2020
# Copyright:   SooHyun Jang
#-------------------------------------------------------------------------------
import sys

def get_input():
    given_word = input()
    given_char = input()

    return given_word, given_char


def main():
    vowels = 'aeiou'
    trans_char = ''
    a_word, masking_char = get_input()
    for i in range(0,len(vowels)):
        trans_char = trans_char + masking_char

    table = str.maketrans(vowels,trans_char)
    print(a_word.translate(table))

if __name__ == '__main__':
    main()
