# -*- coding: utf-8 -*-

def reverse_str(n,m) :
    ls = list(n)
    for i in range(len(ls)) :
        if ( ls[i] == "a" or ls[i] == "e" or ls[i] == "i" or ls[i] == "o" or ls[i] =="u" ):
            ls[i] = m
    
    return ls
        
if __name__ == "__main__" :
    j = str(input())
    k = str(input())

    l = reverse_str(j,k)
    print("".join(l))
