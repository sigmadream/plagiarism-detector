# -*- coding: utf-8 -*-
def removeVowels(word,x):
    vowels = ('a', 'e', 'i', 'o', 'u')
    for c in word:
        if c.lower() in vowels:
            word = word.replace(c,x)
    return word

a = input()
b = input()

print(removeVowels(a,b))
