# -*- coding: utf-8 -*-

def Check_vowel(instr, inpattern):
    vowels = {"a", "e", "i", "o", "u"} #모음 문자리스트  초기화
    temp_list = list(instr[::-1])    #String을 list로 형변환,
                                     #pop시 정상 작동을 위한reverse
    ret_list = list(instr)           #return할 리스트를 저장
    len_instr = len(instr)           #입력 문자열 길이 계산
    for i in range(len_instr):       #i=0부터 inchar의 문자열 길이만큼 반복
        temp = temp_list.pop() 
        if temp in vowels:
            ret_list[i] = inpattern  #모음은 입력된 패턴으로 대치  
    return ret_list


if "__main__" == __name__:
    instr = input()                 #input list
    inpattern = input()             #input pattern
    modstr = Check_vowel(instr, inpattern)
    
    print("".join(modstr))          #리스트를 스트링으로 출력하는 함수
    
