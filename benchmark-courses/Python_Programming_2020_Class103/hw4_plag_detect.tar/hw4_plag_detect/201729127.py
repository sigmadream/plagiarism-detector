#coding: utf-8

def masking(ls, ch):
    vowels = ['a', 'e', 'i', 'o', 'u']
    res = ""
    for i in ls:
        if i not in vowels:
            res += i
        else:
            res += ch
    return "".join(res)

if __name__ == "__main__":
    ls = input()
    ch = input()
    b = masking(ls, ch)
    print(b)    