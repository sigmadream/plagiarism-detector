# -*- coding: utf-8 -*-

a = input()
b = input()

vow = ["a", "e", "i", "o", "u"]

def mask_vow(s):
    ls =list(s)
    nd=[]
    for n in ls:
        if n in vow :
            n=b
        nd.append(n)
    return "".join(nd)

if __name__ == "__main__":
    print(mask_vow(a))
