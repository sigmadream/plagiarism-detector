def masking(s,m):
    ls = list(s)
    vowels = list("aeiou")
    for i in range(len(ls)):
        c = ls[i]
        if c in vowels:
            ls[i] = m;
    return "".join(ls)

if __name__ == "__main__":
    s = input()
    m = input()
    print(masking(s,m))



    
        
