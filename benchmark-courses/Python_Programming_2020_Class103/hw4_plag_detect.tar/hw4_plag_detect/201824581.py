def mask(w,c):
    word = list(w)
    n = 0
    for i in range(len(word)):
        if word[n] == "a" or word[n] == "e" or word[n] == "i" or word[n] == "o" or word[n] == "u":
            word[n] = c
            
        n = n + 1
    return "".join(word)
        
if "__main__" == __name__:
    w = input()
    c = input()
    print(mask(w,c))

