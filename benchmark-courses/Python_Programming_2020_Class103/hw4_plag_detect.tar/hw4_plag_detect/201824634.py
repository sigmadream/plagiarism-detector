#coding: utf-8


def masking(ls,s):  
    cnt =0
    text = ls
   
    
    for cnt in range(len(ls)): 
         
        if text[cnt] in "aeiou": 
            text = text.replace(text[cnt], s)               
    return text 


if __name__ == "__main__":
    f = input(); 
    s = input(); 
    print(masking(f,s)) 
    

