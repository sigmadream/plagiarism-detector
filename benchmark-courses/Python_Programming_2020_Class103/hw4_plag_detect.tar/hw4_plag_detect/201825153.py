#coding: utf-8

inputword = list(input())
inputchar = input()

v = list("aeiou");

def masking(s):
    for i in range(len(s)):
        for x in v:
            if(s[i] == x):
                s[i] = inputchar
    return "".join(s)

if __name__ == "__main__":
    masked = masking(inputword)
    print(masked)
    
