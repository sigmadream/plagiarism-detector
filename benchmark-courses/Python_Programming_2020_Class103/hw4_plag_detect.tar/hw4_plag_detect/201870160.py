#coding: utf-8


def is_vowel(s):
    vowel = ['a', 'e', 'u', 'i', 'o']
    for i in vowel:
        if (i==s):
            return True
    return False


if __name__ == "__main__":
    word = input()
    w = list(word)
    character = input()

    for i in range(len(w)):
        if(is_vowel(w[i])):
            w[i] = character
    print("".join(w))
