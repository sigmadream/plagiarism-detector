#-*- coding: utf-8 -*-

def rprint(word, mask):
    vowels = ('a', 'e', 'i', 'o', 'u')
    for n in word:
        if n in vowels:
            word = word.replace(n, mask)
    print(word)


if __name__ == "__main__":
    myword = input()
    mymask = input()
    rprint(myword, mymask)
