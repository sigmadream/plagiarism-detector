 # -*- coding: utf-8 -*-

if __name__ == "__main__":

    a=input()
    b=input()
    vowels='aeiou'
    results=""
    for letter in a:
            if letter not in vowels:
                results += letter
            if letter in vowels:
                letter=b
                results += letter

print(results)
