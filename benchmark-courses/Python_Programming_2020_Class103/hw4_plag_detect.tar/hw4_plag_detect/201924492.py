vowels = ['a','e','i','o','u']
myword = input()
a=input()
def word():
    result=""
    for i in myword :
        if i in vowels:
            result = result+a
        else:
            result = result+i
    return result       
b=word()        
print(b)  


        
       

