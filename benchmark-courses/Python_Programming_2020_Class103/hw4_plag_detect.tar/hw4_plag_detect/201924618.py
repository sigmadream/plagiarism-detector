#coding: utf-8

def masking_vowels(s, c):
    ls = list(s)
    for i in range(len(s)):
        if ls[i] in "aeiou":
            ls[i] = c
    return "".join(ls)

if __name__ == "__main__":
    s = input()
    c = input()
    print(masking_vowels(s,c))
