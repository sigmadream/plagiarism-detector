#coding: utf-8 

def rverse_str(s):
    
    ls = list(s)
    ls.reverse()
    return" ".join(ls)


    
if __name__ == "__main__":
    list= input("")
    
    m= input("")
    
    print(list[::2])

    
    
   
    
    
