def print_word(word: list):
    for i in word:
        print(i, end="")
    print()

def exclude_vowels(word: str or list, char: str):
    word = list(word)
    vowels = ['a', 'e', 'i', 'o', 'u']
    for i in range(len(word)):
        for vowel in vowels:
            if word[i] == vowel:
                word[i] = char
    return word

def main():
    word = input()
    char = input()
    word = exclude_vowels(word, char)
    print_word(word)
    

if __name__ == "__main__":
    main()
