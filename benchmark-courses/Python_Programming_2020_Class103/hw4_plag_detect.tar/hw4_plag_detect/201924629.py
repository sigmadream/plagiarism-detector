
def replace_vowels(a, b):
 vowels = ['a', 'e', 'i', 'o', 'u']
 for i in a:
    if i in vowels:
        a = a.replace(i, b)
 return a


word = input()
symbol = input()

print(replace_vowels(word.lower(), symbol))