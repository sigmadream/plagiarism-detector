def f(a,b):
    ans =""
    for i in a:
        if i == 'a' or i == 'i' or i == 'e' or i == 'o' or i == 'u': ans +=b
        else: ans +=i
    return ans

if __name__ == "__main__":
    s = input()
    n = input()
    print(f(s,n))
