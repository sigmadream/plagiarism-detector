# name: Dilyana Dimitrova
# student ID: 202055501

def masking(word, sign, vowels):
    ls=list(word)
    j=0
    for i in ls:
        if i in vowels:
            ls[j] = sign
        j=j+1
    return "".join(ls)
            

def main():
    word= input()
    sign=input()
    vowels = "aeiou"
    masked = masking(word, sign, vowels)
    print(masked)
    
if __name__ == '__main__':
    main()

    