def some():
    word = input()
    m = input()
    word = word.replace('a',m)
    word = word.replace('e',m)
    word = word.replace('i',m)
    word = word.replace('o',m)
    word = word.replace('u',m)
    x = print(word)
    return x



if __name__ == "__main__" :
    some()


        
