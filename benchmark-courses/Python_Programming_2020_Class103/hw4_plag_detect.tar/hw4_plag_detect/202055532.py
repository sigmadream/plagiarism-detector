a=input()
b=input()
if b == "-":
    table = str.maketrans('aeiou' , '-----')
    print(a.translate(table))
else:
    table = str.maketrans('aeiou' , '*****')
    print(a.translate(table))





    
