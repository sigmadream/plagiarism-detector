#coding : utf-8

def detector(l):
    if l in ["a", "e", "i", "o", "u"]:
        return True
    else:
        return False

if __name__ == "__main__":
    word=input()
    mask=input()
    masked_word=""
    for a in word:
        if detector(a):
            masked_word=masked_word+mask
        else:
            masked_word=masked_word+a
    print(masked_word)