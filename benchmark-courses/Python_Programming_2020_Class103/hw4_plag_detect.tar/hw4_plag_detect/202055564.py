a = input()
b = input()
c = list(a)

def masking():
  for x in range(len(a)):
    if c[x] in ['a', 'e', 'i', 'o', 'u']:
      c[x] = b
  return "".join(c)

masking()
if __name__ == '__main__':
  print("".join(c))
