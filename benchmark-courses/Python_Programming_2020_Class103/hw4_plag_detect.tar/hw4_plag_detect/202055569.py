#coding utf-8

def replace(s, t):
    x = s.replace('a', t).replace('e', t).replace('i', t).replace('o', t).replace('u', t)
    print(x)

if __name__ == "__main__":
    s = input()
    t = input()
    replace(s, t)
