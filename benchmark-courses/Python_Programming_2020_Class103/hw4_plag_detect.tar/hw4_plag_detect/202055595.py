# -*- coding: utf-8 -*-
def masking():
    mk_word = ''
    word = input()
    char = input()
    for c in word:
        if c in 'aeiou':
            mk_word += char
        else:
            mk_word += c
    return mk_word

if __name__ == "__main__":
    print(masking())



