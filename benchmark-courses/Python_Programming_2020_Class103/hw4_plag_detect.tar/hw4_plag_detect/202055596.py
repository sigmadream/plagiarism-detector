def mask():
    word = input("word : ")
    char = input("char : ")
    a = word
    a = list(a)
    if __name__ == "__main__":
        for i in range(1, len(a)+1):
            if a[i-1] in list("aeiou"):
                a[i-1] = char

        print("".join(a))

mask()
