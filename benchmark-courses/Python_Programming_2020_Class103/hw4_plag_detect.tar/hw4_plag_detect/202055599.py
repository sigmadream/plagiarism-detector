#coding: utf-8

def masking(word,sym):
    for m in list(word):
        if m in "aeiou":
            word = word.replace(m,sym)
    return word

def main():
    word = input(">> ")
    sym = input(">> ")
    print(masking(word,sym))

if __name__ == "__main__": main()