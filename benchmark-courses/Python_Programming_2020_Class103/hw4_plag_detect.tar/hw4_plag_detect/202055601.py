def rprint(s, msk):
    ls = list(s)
    vowels = ['a', 'e', 'i', 'o', 'u']
    for i in range(0, len(ls)):
        if ls[i] in vowels:
            ls[i] = msk
    return "".join(ls)



if __name__ == "__main__":
    myword = input()
    msk = input()
    result = rprint(myword, msk)
    print(result)
