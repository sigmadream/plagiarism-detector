


def vowels(target, censor):
    word = ""
    exlist = ["a","e","i","o","u"]
    for i in target:

        if i in exlist:
            i = censor
            word = word + i
        else:
            word = word + i


    return (word)

string = input()
vow = input()
aaa = vowels(string,vow)

print(aaa)