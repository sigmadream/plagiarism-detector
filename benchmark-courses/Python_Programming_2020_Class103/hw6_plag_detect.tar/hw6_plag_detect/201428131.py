nums = list(map(float, input().split()))


if __name__ == '__main__':
    for i in range(len(nums)):
        for j in range(len(nums)-i-1):
            if nums[j]>nums[j+1]:
                temp = nums[j]
                nums[j]= nums[j+1]
                nums[j+1]=temp

    length = len(nums)
    half_length = (len(nums)//2)

    if(length%2!=0):
        result = nums[half_length]
        print(f"{result:.1f}")
    
    elif(length%2==0):
        result = nums[half_length-1]+nums[half_length]
        result /= 2
        print(f"{result:.1f}")





