a=list(map(float,input().split()))
a.sort()
b=((sum(a)-(min(a)+max(a)))/(len(a)-2))
print(f"{b:.1f}")




