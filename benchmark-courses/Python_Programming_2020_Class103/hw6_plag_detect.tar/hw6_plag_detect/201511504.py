#coding: utf-8

def median() :
    num = input().split()
    num.sort()
    for i in range(len(num)):
        num[i] = float(num[i])
    n = len(num)
    if n % 2 == 0 :
        c = int(n/2-1)
        d = int(n/2)
        med = (num[c] + num[d])/2
    else :
        c = int( n/2 - 0.5 )
        med = num[c]

    if __name__ == "__main__" :
        print(f"{med:5.2f}")

median()
