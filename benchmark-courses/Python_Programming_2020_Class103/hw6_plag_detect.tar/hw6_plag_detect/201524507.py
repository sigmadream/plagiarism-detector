if __name__ == "__main__":
  inputStr = input()
  inputList = inputStr.split()
  mediem = 0 
  l = len(inputList)

  for x in range(l):
    inputList[x] = float(inputList[x])
  inputList.sort()

  if (l%2 == 1):
    mediem = inputList[int((l-1)/2)]
  else:
    mediem = (inputList[int(l/2)] + inputList[int(l/2)-1])/2

  print(mediem)