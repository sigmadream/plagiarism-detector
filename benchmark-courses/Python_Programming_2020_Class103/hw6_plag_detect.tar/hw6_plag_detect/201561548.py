def oddm(s):
    s.sort()
    return float(s[int(len(s)/2)])

def pairm(s):
    s.sort()
    return (float(s[int(len(s)/2 - 1)]) + float(s[int(len(s)/2)]))/2

if __name__ == "__main__" :
    s = input().split()
    if len(s) > 0 and len(s) <=500:
        if len(s) % 2 == 0:
            result = pairm(s)
            print(f'{result:0.1f}')
        else:
            result = oddm(s)
            print(f'{result:0.1f}')
