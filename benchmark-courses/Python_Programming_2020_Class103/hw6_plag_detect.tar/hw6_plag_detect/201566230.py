#pllab.submit@gmail.com

def median_arr(arr):
    numbers = arr.split()
    numbers.sort()
    
    arrLen = len(numbers)
    mid = int(arrLen/2)

    if arrLen%2 == 1:
        avg = 0.0
        avg = float(numbers[mid])
        print(f"{avg:.1f}")
    elif arrLen%2==0:
        avg = (float(numbers[mid]) + float(numbers[mid-1]))/2
        print(f"{avg:.1f}")

if __name__ == "__main__":
    arr = float(input())
    median_arr(arr)
    