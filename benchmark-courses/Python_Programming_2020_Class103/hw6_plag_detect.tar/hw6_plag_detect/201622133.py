#coding: utf-8

if __name__ == "__main__":
    num = input().split()
    list.sort(num)

    length = int(len(num))

    if (length%2 ==0):
        value1 = float(((float(num[int(length/2)-1]) + float(num[int(length/2)]) )/2)) 
        print(f"{value1:.1f}" )
    if (length%2 == 1):
        value2 = float(num[int(length/2)])
        print(f"{value2:.1f}")
