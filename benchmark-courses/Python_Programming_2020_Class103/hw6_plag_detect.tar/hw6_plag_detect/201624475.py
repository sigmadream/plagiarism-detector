#coding: utf-8
'''
for n in range(1,10):
    value = 1/n
    print(f"{value:5.2f}", value)
'''
def medianfuc(s1):
    new = s1.split()
    new.sort()
    middle = len(new)/2
    imiddle = int(middle)
    
    if (len(new)%2 == 0):
        val1 = float(new[imiddle])
        val2 = float(new[imiddle-1])
        value = (val1+val2)/2
        print("%.1f" %value)
    else:
        value = float(new[imiddle])
        print("%.1f" %value)

    return()    


input_str = str(input())

if __name__ == "__main__":

    medianfuc(input_str)
    
