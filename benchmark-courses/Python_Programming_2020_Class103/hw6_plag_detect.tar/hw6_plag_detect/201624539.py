# -*- coding: utf-8 -*-


def getmedian():
    inputs = input().split(" ")
    floatnumbers = []
    median = 0.0
    for i in range(len(inputs)):
        floatnumbers.append(float(inputs[i]))
    floatnumbers.sort()
    mindex = int((len(floatnumbers)-1)/2)
    if len(floatnumbers)%2 ==1:
        return floatnumbers[mindex]
    else:
        return (floatnumbers[mindex] + floatnumbers[mindex+1])/2

if __name__ == "__main__":
    median = getmedian()
    print(f"{median:0.1f}")
