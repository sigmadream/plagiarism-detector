
def getMedian(n,list):
    avgIndex = int(n/2)
    if n % 2 ==0:
        avg=(list[avgIndex]+list[avgIndex-1])/2
        print(f'{avg:.1f}')
    else:
        avg = list[avgIndex]
        print(f"{avg:.1f}")

if __name__ == "__main__":
    data = list(map(float,input().split()))
    length = len(data)
    data.sort()
    getMedian(length,data)