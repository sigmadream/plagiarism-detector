def sort(x):
    for i in range(len(x)-1):
        for j in range(i+1, len(x)):
            if x[i] > x[j]:
                x[i], x[j] = x[j], x[i]
    return x

def median(x):
    if (len(x) % 2) == 0:
        a = float(x[int(len(x)/2) - 1])
        b = float(x[int(len(x)/2)])
        mean = (a+b)/2
    else:
        mean = float(x[int(len(x)/2)])
    return mean

if __name__ == "__main__":
    sequence = input()
    sort_seq = sort(sequence.split(' '))
    median = float(median(sort_seq))
    print("%.1f" % median)
