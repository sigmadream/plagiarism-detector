# -*- coding: utf-8 -*-

if __name__ == "__main__":

    s = input()
    slist = {}
    slist = s.split()
    n = len(slist)
    slist.sort()
    
    
    if(n % 2 == 1):
        n2 = int(n / 2)
        oddmid = float(slist[n2])
        r_mid = round(oddmid, 1)
        print(r_mid)

    else:
        n3 = int(n / 2)
        n4 = int(n3 -1)
        sum = (float(slist[n3]) + float(slist[n4]))
        average = sum / 2.0

        r_average = round(average, 1)
        print(r_average)
        
        
        

                
                
                    
            
        
