# coding: utf-8

def med(ch):
    median=0
    cha=ch.split()
    cha.sort()
    a=len(cha)
    fs=a//2
    if a%2==0:
        median=(float(cha[fs])+float(cha[fs-1]))/2
    else:
        median=float(cha[fs])
    meda=float(median)
    print(f"{meda:.1f}")
        









if __name__ == "__main__":
    ch = input()
    med(ch)
