#cording : utf -8

def main():
    list = {}
    list = input().split()
    list.sort()
    n = len(list)

    if n%2 == 1:
        result = float(list[int((n-1)/2)])
    else:
        result = float(float(list[int(n/2)-1]) + float(list[int(n/2)]) )/ 2.0

    print(f"{result:0.1f}")

if __name__ == "__main__":
    main()
    
