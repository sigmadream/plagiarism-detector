# -*- coding: utf-8 -*-

def median(ns):
    if len(ns) % 2 == 1 :
        print(f"{numbers[len(ns)//2]:.1f}")
    else:
        avg = (numbers[len(ns)//2] + numbers[len(ns)//2 -1]) / 2
        print(f"{avg:.1f}")
        

if __name__ == "__main__" :
    line = input()
    ns = line.split()
    numbers = []
    for k in ns:
        numbers.append(float(k))
    numbers.sort()
    median(ns)


