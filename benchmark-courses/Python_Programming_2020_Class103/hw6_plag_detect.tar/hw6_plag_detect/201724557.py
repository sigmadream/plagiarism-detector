#-------------------------------------------------------------------------------
# Name:        median.py
# Purpose:     Assignment of Computer programming Intro
#
# Author:      Jans SooHyun
#
# Created:     04-05-2020
# Copyright:   Jang SooHyun 2020
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import sys


def get_sorted_real_list():
    real_input = sys.stdin.readline()
    real_str_list = real_input.split()

    real_list = []
    for i in range(len(real_str_list)):
        real_list.append((float)(real_str_list[i]))

    sorted_real_list = sorted(real_list)
    return sorted_real_list


def find_median(r_list):
    if(len(r_list)%2!=0):
        return r_list[len(r_list)//2]
    else:
        return (r_list[len(r_list)//2-1] + r_list[len(r_list)//2] )/2



def main() :
    sorted_real_list = get_sorted_real_list()
    #print(sorted_real_list)

    median = find_median(sorted_real_list)
    #print(median)
    print(f"{median:.1f}")


if __name__ == '__main__':
    main()

