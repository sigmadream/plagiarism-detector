def median(ls):
    ls.sort()
    mid = int(len(ls)/2)
    if(len(ls) % 2 == 1) :
        avg = float(ls[mid])
    else :
        a = float(ls[mid-1])
        b = float(ls[mid])
        avg = float((a+b)/2)
    return avg


if __name__ == "__main__":
    ls = input().split()
    a = float(median(ls))
    print(f"{a:.1f}")



# 3.12 1.57 2.12
# 3.1 1.7 2.1 5.3
# 1 9 1 0 2 9