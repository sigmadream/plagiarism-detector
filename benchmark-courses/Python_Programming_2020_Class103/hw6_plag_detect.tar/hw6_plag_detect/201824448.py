#coding: utf-8

import statistics

a= input().split(" ")
a=list(a)
a.sort()
b=statistics.median(a)
c= str(b)
print(f"{c:.2f}")
