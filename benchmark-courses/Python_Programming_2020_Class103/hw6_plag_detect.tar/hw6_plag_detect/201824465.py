
if __name__ == "__main__":
    inputList=[]

    inputList = input().split()
    inputList = list(map(float, inputList))
    inputList.sort()

    index=0

    for i in range(len(inputList)):
        index +=1

    if(index % 2==0):
        n = int(index/2)
        med = (inputList[n] + inputList[n-1]) / 2
        print("%.1f" % (med))

    if(index % 2 != 0):
        n = int(index/2)
        print(n)
        med = inputList[n]
        print("%.1f" % (med))

    
    

