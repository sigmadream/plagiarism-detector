#coding: utf-8

def median(s):
    slist = s.split()
    slist.sort()
    if len(slist) % 2 == 1:
        k = int(len(slist)/2)
        num = float(slist[k])
        print(f"{num:.1f}")
    else:
        k1 = int(len(slist)/2)
        num1 = float(slist[k1 - 1])
        num2 = float(slist[k1])
        avg = float((num1 + num2)/2)
        print(f"{avg:.1f}")
            
if "__main__"==__name__:
    s = input()
    median(s)

