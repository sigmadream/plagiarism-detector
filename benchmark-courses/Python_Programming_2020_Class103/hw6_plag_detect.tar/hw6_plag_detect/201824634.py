import statistics

def main():
    Alist = input().split()#input
    Alist = list(map(float, Alist)) #입력받은거 전부 float으로 type casting

    avg = 0
    Alist.sort()   # [ 3.1 , 1.7, 2.1, 5.3 ]
                   # [ 1.7, 2.1, 3.1, 5.3 ] sorting! non-decreasing

    if len(Alist)%2 ==1:  # 홀수면 [ 1, 2, 3 ]  2 is median!!
        value= statistics.median(Alist)
        print("%0.1f" % value)
    elif len(Alist)%2==0 : # even num??
        a = Alist[len(Alist)//2-1]       # [ ][1][][ ] SIZE 4//2 =2-1 =1
        b = Alist[len(Alist)//2]          # [ ][ ][2][ ] SIZE 4//2 =2
        avg = (a+b)/2  # 3-> 1.5
        print("%0.1f" % avg ) 

if __name__=="__main__":
    main()
