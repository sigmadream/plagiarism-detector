# coding: utf-8


def bubblesort(p_list):
    count = 0
    while count < len(p_list):
       for n in range(0, (len(p_list) - 1 - count)):
           if p_list[n] > p_list[n+1]:
               temp = p_list[n+1]
               p_list[n+1] = p_list[n]
               p_list[n] = temp
       count += 1

def oddListMed(p_list):
    idx = int((len(p_list) / 2) - 0.5)
    return p_list[idx]

def EvenListMed(p_list):
    middlef = p_list[int((len(p_list) / 2) - 1)]
    middlel = p_list[int((len(p_list) / 2))]
    middle = (middlef + middlel) / 2
    return middle

def main():
    line = input()
    line = line.split()

    count = 0
    medianval = 0
    for n in line:
        line[count] = float(n)
        count += 1
    bubblesort(line)
    if (len(line) %2) == 0:
        medianval = EvenListMed(line)
    else:
        medianval = oddListMed(line)
    print(f"{medianval:.1f}")



if __name__ == "__main__":
    main()