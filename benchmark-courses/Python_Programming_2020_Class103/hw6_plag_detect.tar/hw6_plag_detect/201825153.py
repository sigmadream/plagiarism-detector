#coding: utf-8

if __name__ == "__main__":
    stringget = input()
    listed = stringget.split(" ")
    if len(listed) > 0 and len(listed) <= 500:
        for x in range(len(listed)):
            listed[x] = float(listed[x])
        listed.sort()
        num = len(listed)//2
        sum1 = 0
        if len(listed)%2 == 0:
            for n in range(num-1, num+1):
                sum1 = sum1 + (listed[n])
            avg = sum1 / 2
            print(f"{avg:.1f}")
        else:
            output = (listed[num])
            print(f"{output:.1f}")
