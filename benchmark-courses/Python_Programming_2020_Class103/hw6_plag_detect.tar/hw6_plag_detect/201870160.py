#coding: utf-8

s=input()
nums=s.split()
nums.sort()

if __name__=="__main__":
    if (len(nums)%2==1):
        median = float(nums[len(nums)//2])
    if (len(nums)%2==0):
         median = (float(nums[len(nums)//2]) + float(nums[len(nums)//2-1]))/2

    print(f"{median:.1f}")
