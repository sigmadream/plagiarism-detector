if __name__ == '__main__':

    li1=input().split()
    li2=list(map(float,li1))
    li3=sorted(li2)
    n=len(li2)

    if n%2==0:
        print("%0.1f"%float((li3[int((n-1)/2)]+li3[int((n-1)/2+1)])/2))

    else:
        print("%0.1f"%float(li3[int((n-1)/2+0.5)]))
