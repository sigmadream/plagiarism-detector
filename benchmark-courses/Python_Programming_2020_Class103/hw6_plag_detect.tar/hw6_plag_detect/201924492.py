def main():
    s = input()
    slist=s.split()
    slist.sort()
    avg=0
    if len(slist)%2==1:
        avg= float(slist[len(slist)//2])
    else:
        avgg=len(slist)//2
        avg=float((float(slist[avgg])+float(slist[avgg-1]))/2)
    print(f"{avg:.1f}")

if __name__=="__main__":
    main()
        
    
