#coding: utf - 8

lst = input()
n_num = lst.split()
n_num = [float(i) for i in n_num]
n = len(n_num)
n_num.sort()



if n % 2 == 0:
    med1 = n_num[n//2]
    med2 = n_num[n//2 - 1]
    median = (med1 + med2)/2
else:
    median = n_num[n//2]

print(f"{median:.1f}")

