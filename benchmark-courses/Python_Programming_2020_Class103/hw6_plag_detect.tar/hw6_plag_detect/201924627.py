def main():
    string = input()
    nums = list()

    for num in string.split(' '):
        nums.append(float(num))

    pos = len(nums) // 2
    nums.sort()

    if len(nums) % 2 == 1:
        median = nums[pos]
    else:
        median = (nums[pos - 1] + nums[pos]) / 2

    print(f'{median:.1f}')
    
if __name__ == "__main__":
    main()
