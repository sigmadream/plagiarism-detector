x = input().split()


def median(a):
    n = len(a)
    a.sort()
    if n > 0 and n < 500:
        if n % 2 == 1:
            ave = float(a[n // 2])

        else:
            left = (n - 1) // 2
            right = n // 2
            ave = float((float(a[left]) + float(a[right])) / 2)

    print(f'{ave:.1f}')



if __name__ == '__main__':
    median(x)

