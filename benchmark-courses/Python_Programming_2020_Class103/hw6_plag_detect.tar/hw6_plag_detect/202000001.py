def median(nums):
    nums.sort()
    # print("sorted nums: " + str(nums))
    midIdx = len(nums) / 2
    midIdxInt = int(midIdx)
    if midIdx == int(midIdx):
        mid = (nums[midIdxInt-1] + nums[midIdxInt]) / 2
    else:
        mid = nums[midIdxInt]
    return mid

if __name__ == '__main__':
    inp = input()
    inpList = inp.split()
    nums = []
    for num in inpList:
        nums.append(float(num))
    mid = median(nums)
    # print(mid)
    print("%.1f" % mid)