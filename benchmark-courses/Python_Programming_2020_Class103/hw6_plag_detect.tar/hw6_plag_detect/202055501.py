





numbers=input()
listnum=numbers.split(" ")
length = len(listnum)
#print(length)
#i=0; j=1;
for i in range(1,length):
   for j in range(0,length-1):
       if float(listnum[int(j)]) > float(listnum[int(j+1)]):
            tmp= float(listnum[int(j)])
            listnum[int(j)]=listnum[int(j+1)]
            listnum[int(j)]=tmp

      
print(listnum)
if length % 2 != 0:
    medium=int((length+1)/2) - 1
    print(listnum[medium])
else:
    first = int(length/2-1)
    second = int(length/2)
    medium = float(listnum[first]) + float(listnum[second])
    medium=medium/2
    print(f"{medium}")
    
    
    

         
