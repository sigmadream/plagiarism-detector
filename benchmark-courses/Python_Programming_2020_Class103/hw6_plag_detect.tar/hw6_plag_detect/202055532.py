a = input()
ls = list(a)
x = ls.sort()

def finding(x):
    n=len(x)
    if n%2==1:
        result=x[int((n-1)/2)]

    else:
        result=(x[int(n/2)-1]+x[int(n/2)])/2

    return result


print(f"{finding(x):2.2f}")
