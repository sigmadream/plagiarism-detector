#coding: utf-8

def average(x, y):
    avg=(x+y)/2
    return(avg)

def float_converter(a):
    b=a.split(".")
    if len(b)==1:
        return(float(int(a)))
    c=float(int(b[0]))
    d=b[1]
    e=len(d)
    f=float(int(d))*(0.1**e)
    g=c+f
    return(g)

if __name__ == "__main__":
    inputs=input()
    lists=inputs.split(" ")
    n=len(lists)
    for i in range(n):
        lists[i]=float_converter(lists[i])
    lists.sort()
    if n%2==0:
        avg=average(lists[int(n/2)-1], lists[int((n/2))])
        print(f"{avg:.1f}")
    else:
        avg=lists[(n//2)]
        print(f"{avg:.1f}")