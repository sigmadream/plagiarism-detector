a = input().split()
a.sort()

if len(a)%2==1:
  n=(len(a)-1)/2
  b=int(n)
  value=float(a[b])
  print(f"{value:3.1f}")
else:
  n=(len(a)/2)
  b=int(n)
  value=(float(a[b])+float(a[b-1]))/2
  print(f"{value:3.21}")

