def median():
    nums = input()
    numli = nums.split()
    numli.sort()
    length = len(numli)
    center = int(length / 2)
    if length % 2 == 0:
        median = ((numli[center - 1]) + (numli[center]))/2
    else:
        median = numli[center]
    return median
    

if __name__ == "__main__":
    print(median())
    
