n = int(input())
b = []
a = ""
if n % 2 == 0:
    a += input()
    a = a.split()
    for i in range(len(a)):
        b.append(float(a[i]))
    b.sort()
    c = int(n/2)
    sum = float(b[c-1]) + float(b[c])
    median = sum/2
elif n % 2 != 0:
    a += input()
    a = a.split()
    for i in range(len(a)):
        b.append(float(a[i]))
    b.sort()
    c = int((n+1)/2)
    median = float(b[c-1])

print(f"{median:.1f}")

        
