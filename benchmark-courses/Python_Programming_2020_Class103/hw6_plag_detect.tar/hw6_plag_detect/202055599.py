#coding : utf-8

def median(n):
    n_list = n.split()
    n_list.sort()
    if len(n_list) == 1:
        return n
    else:
        mid = len(n_list)/2
        i = 1
        while i < mid:
            i = i + 1    
        if i == mid:#홀수개
            sum = float(n_list[i-1]) + float(n_list[i])
            res = sum/2
        elif i > mid:#짝수개
            res = float(n_list[i-1])
        else: return "Error.." 
        return res

def main():
    n = input(">> ")
    print(f"{median(n):.1f}")

if __name__ == "__main__": main()
