if __name__ == "__main__":
    nums = input()
    linum = nums.split()

    linum.sort()

    leng = int(len(linum))

    if leng%2 == 1:
        odmed = float(linum[leng//2])
        print(f"{odmed:.1f}")
    else:
        evmed1 = float(linum[leng//2-1])
        evmed2 = float(linum[leng//2])
        evmed = evmed1 + evmed2
        value = evmed/2
        print(f"{value:.1f}")

