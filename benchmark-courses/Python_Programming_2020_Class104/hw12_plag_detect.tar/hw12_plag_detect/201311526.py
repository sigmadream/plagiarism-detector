# coding: utf-8

def countt(a, b):
    c = 0
    while b >= a:
        b = b - a
        c = c + 1
    return c

def calb(a, b):
    while b >= a:
        b = b - a
    return b

def main(a, b, c):
    if y < min(x):
        print("0")
    
    print(z, end = " ")


if __name__ == "__main__":
    x = input().split()
    y = int(input())
    z = 0
    p = []
    for i in range(0, len(x)):
        q = int(x[i])
        r = countt(q, y)
        s = calb(q, y)
        y = s
        p.append(str(r))
    print(" ".join(p))
