if __name__=="__main__":
    money = input()
    total = int(input())
    money = money.split()

    result = []
    
    for i in money:
        i = int(i)
        index = total // i
        total -= i * index
        result.append(str(index))
        
    result = " ".join(result)
    print(result)
        
