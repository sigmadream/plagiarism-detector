def coin():
      a =input().split()
      b=int(input())
      c= []
      i=0
      for _ in range(len(a)):
          c.append(str(b//int(a[i])))
          b -= int(a[i])*(b//int(a[i]))
          i += 1
      print(' '.join(c))

if __name__ == "__main__":
    coin()
