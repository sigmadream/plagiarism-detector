def main():
    coin = str(input())
    money = int(input())
    coin2 = coin.split()
    for A in coin2 :
        if A != coin2[-1]:
            A = int(A)
            print( int(money/A) , end=' ')
        else:
            A = int(A)
            print( int(money/A) )
        money = money - int(money/A)*A
    
if __name__ == "__main__":
    main()
