def change(n, div):
    if len(div) == 1:
        print(n//int(div[0]))
    elif n < div[0]:
        return print(n, end = ' ')
    else:
        if len(div) == 1:
            print(n//int(div[0]))
        else:
            return change(n//div[0], div), change(n%div[0], div[1:])

if __name__ == "__main__":
    stri = input()
    n = int(input())
    st = stri.split()
    div = [int(x) for x in st]
    
    change(n, div)
