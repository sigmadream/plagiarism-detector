A = int(input())
B = int(input())
C = int(input())
D = int(input())
E = int(input())

def min_calc(value,coin):
    x=[]
    for i in coin:
        x.append([value-i,i])
    res = x[0]
    for i in x:
        if res[0]>i[0] and i[0]>0:
            res=i
    return res


coin = [A,B,C,D]
value = [E,0]
dic = {}
for i in coin:
    dic[i] = 0


while True:
    value = min_calc(value[0],coin)
    if value[0]<0:
        break
    else:
        dic[value[1]] += 1


print(dic)
