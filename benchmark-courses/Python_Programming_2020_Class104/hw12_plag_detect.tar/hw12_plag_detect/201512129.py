def get_coin_count(n, ls, total):
    count = []
    if n >= len(ls):
        return count
    c = int(ls[n])
    count.append(total // c)
    total = total % c
    count.extend(get_coin_count(n+1, ls, total))
    return count
def main():
    coins = input().split()
    total = int(input())
    pls = get_coin_count(0, coins, total)
    p = ""
    for i in pls:
        p += str(i) + " "
    print(p.strip())
if __name__ == "__main__":
    main()
