def change(coin, total, sum):
    if total >= coin :
        total = total - coin
        sum += 1
        return change(coin, total, sum)
    else :
        print(sum,  end = ' ')
        return total

if __name__ == "__main__":
    coin = str(input())
    total = int(input()) 
    coinkind = coin.split()
    coinlist = list(map(int, coin.split()))
    
    for i in range(len(coinlist)) : 
        total = change(coinlist[i], total, 0)
    print()

        
