def recursive(num, coin_list, ans_list):
    index=-1
    for i in range(0, len(coin_list)):
        if coin_list[i] <= num:
            index = i

    if num % coin_list[index] == 0:
        ans_list[index] = num//coin_list[index]
        return

    else:
        ans_list[index] = ans_list[index] + 1
        recursive(num - coin_list[index], coin_list, ans_list)

if __name__ == "__main__":
    inp = input()
    num = int(input())
    coin_list1 = inp.split()
    coin_list=[]

    for i in coin_list1:
        coin_list.append(int(i))
    coin_list.reverse()

    ans_list=[]
    for i in range(0, len(coin_list)):
        ans_list.append(0)
    recursive(num, coin_list, ans_list)
    ans_list.reverse()

    for i in range(0, len(ans_list)):
        if i == len(ans_list)-1:
            print(ans_list[i], end="")
        else:
            print(ans_list[i], end=" ")

