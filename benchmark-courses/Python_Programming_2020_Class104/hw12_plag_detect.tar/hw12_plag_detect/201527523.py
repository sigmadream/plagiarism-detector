
def allocate(change, clist):
    i = int(clist[0])
    num = change//i
    if len(clist) > 1:
        print(num, end=" ")
        allocate(change-num*i, clist[1:])
    else:
        print(num)

if __name__ == "__main__":
    c = input()
    rclist = c.split()
    rchange = int(input())
    allocate(rchange, rclist)