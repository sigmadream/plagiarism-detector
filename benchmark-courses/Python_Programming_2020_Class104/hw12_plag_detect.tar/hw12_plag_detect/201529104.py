def change(x, y, z):
    if x >= y:
        return change(x-y, y, z+1)
    else:
        return z
if __name__ == "__main__":
    while True:
        coin = input()
        money = int(input())
        coinlist = coin.split()
        changecoin = []
        if money <= 0:
            break
        for i in range(len(coinlist)):
            changecoin.append(str(change(int(money), int(coinlist[i]), 0)))
            money -= int(coinlist[i])*change(int(money), int(coinlist[i]), 0)   
        print(" ".join(changecoin))
