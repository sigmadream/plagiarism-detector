def recursion(cash, coin, n):
    if cash < coin:
        return n
    else:
        n = n + 1
        return recursion(cash-coin,coin,n)

if __name__ == "__main__":
    coin = input()
    cash = input()

    coinlist = coin.split()

    for i in range(len(coinlist)):
        coinlist[i] = int(coinlist[i])

    cash = int(cash)
    frequency = []
    
    for i in range(len(coinlist)):
        frequency.append(recursion(cash, coinlist[i], 0))
        cash = cash%coinlist[i]
    
    for i in range(len(frequency)):
        print(frequency[i],sep="",end="")
        if i < len(frequency)-1:
            print(" ",sep="",end="")
