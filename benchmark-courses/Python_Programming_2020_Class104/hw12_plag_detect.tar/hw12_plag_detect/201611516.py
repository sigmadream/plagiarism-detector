if __name__ == "__main__":
 ch_list = input().split()
 money = int(input())
 ch = []
 def change(ch_list, money):
    if money >= 0:
        ch.append(money // int(ch_list[0]))
        money = money % int(ch_list[0])
        if len(ch_list)>1 :
            ch_list = ch_list[1:]
            change(ch_list, money)
 change(ch_list, money)
 for i in ch:
        print(i,end=" ")
