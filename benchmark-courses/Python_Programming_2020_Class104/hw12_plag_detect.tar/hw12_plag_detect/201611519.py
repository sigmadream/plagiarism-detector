def change(a, n):
    if n > 0:
        b.append(n // int(a[0]))
        n = n % int(a[0])
        a = a[1:]
        change(a, n)
        return b
    elif n == 0:
        b.append(0)
    for i in b:
        print(i,end = " ")


if __name__ == "__main__":
    a = input().split()
    n = int(input())
    b = []
    change(a, n)
