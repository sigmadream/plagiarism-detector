cnt = 0
def func(money,line):
    global cnt
    a = money/(line[cnt])
    ia = int(a)
    mod = money%(line[cnt])
    print(ia, end='')
    cnt = cnt + 1
    if cnt >= len(line):
        return
    print(' ', end='')
    func(mod,line)
        
if __name__ == "__main__":
        line = input().split()
        iline = list(map(int, line))

        money = int(input())
        #500 100 50 10 4개 있는 배열 만들었다
        #문자열이므로 int붙여서 바꿔서 쓰자
        #이제 money를 line[0] 500으로 나누고
        #그 나머지를 line[1] 으로 나누고
        #또 그 나머지를 line[2] 으로 나누고
        #또 그 나머지를 line[3] 으로 나눈다
        func(money,iline)
        
