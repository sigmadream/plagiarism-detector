#코인은 내림차순으로 입력받는다
#큰 값은 작은값의 배수이다.
#코인의 수는 최소화
#코인의 종류는 공백에 의해 분리된다
#결과: 코인의 수는 공백으로 분리되야한다

#내림차순 함수
def desc(list1):
    for i in range(0,3):
        if list1[i]<list1[i+1]:
            temp=list1[i]
            list1[i]=list1[i+1]
            list1[i+1]=temp

#배수인지 확인                
def ismultiple(list2):
    desc(list2)
    for i in range(0,3):
        if list2[i]%list2[i+1]==0:
            return 
        else:
            print("코인이 배수가 아닙니다")
        
#코인 개수 구하기
def Count(total,list3):
    count_list=[0,0,0,0]
    for i in range(0,4):
        count_list[i]=int(total/list3[i])
        total=total%list3[i]
        if total==0:
            break
    count_list=list(map(str,count_list))
    print(" ".join(count_list))

if __name__=="__main__":
    coin_list=[]
    coin_list=list(map(int,input().split()))
    total=int(input())
    desc(coin_list)         # 코인 종류 내림차순 정렬
    ismultiple(coin_list)
    Count(total,coin_list)