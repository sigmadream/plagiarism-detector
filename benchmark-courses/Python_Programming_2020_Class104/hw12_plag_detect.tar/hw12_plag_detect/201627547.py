def change(coin,money,i):
    l = coin.split()
    #[500,100,50,10]

    if money >= int(l[0]):
        i[0] = str(money//int(l[0]))
        return change(coin,money%int(l[0]),i)
    
    elif money >= int(l[1]):
        i[1] = str(money//int(l[1]))
        return change(coin,money%int(l[1]),i)
    
    elif money >= int(l[2]):
        i[2] = str(money//int(l[2]))
        return change(coin,money%int(l[2]),i)
    
    elif money >= int(l[3]):
        i[3] = str(money//int(l[3]))
        return change(coin,money%int(l[3]),i)

    else:
        return " ".join(i)


    
if __name__ == "__main__":
    coin = input()
    money = int(input())
    result = change(coin,money,['0','0','0','0'])

    print(result)
