def charge(c, m, a):
    if c != []:
        c1 = int(c[0])
        cha = int(m/c1)
        a.append(str(cha))
        m = m - c1*cha
        del c[0]
        return charge(c, m, a)
    print(' '.join(a))
if __name__ == "__main__":
    text = input()
    coin = text.split()
    money = int(input())
    answer = []
    charge(coin, money, answer)
