def print_num_of_coins(coins, change, num_coins):
    if num_coins == 0:
        return
    coin = int(coins[0])
    coins = coins[1:]
    num_coins = len(coins)
    count = 0
    if change == 0 and num_coins > 0:
        print('0', end=" ")
        print_num_of_coins(coins, change, num_coins)
    elif change == 0:
        return print('0')
    else:
        while coin <= change:
            count = count + 1
            change = change - coin
        if num_coins == 0:
            print(count)
        else:
            print(count, end=" ")
        print_num_of_coins(coins, change, num_coins)


if __name__ == "__main__":
    input_coins = input().split()
    input_change = int(input())
    num_of_coins = len(input_coins)
    print_num_of_coins(input_coins, input_change, num_of_coins)
