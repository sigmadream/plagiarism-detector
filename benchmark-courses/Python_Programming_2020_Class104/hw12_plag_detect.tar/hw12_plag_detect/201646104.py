a, b, c, d = input().split()
e =int(input())

A = int(a)
B = int(b)
C = int(c)
D = int(d)

def calc(e):
    num1 = int(e/A)
    num2 = int((e-(A*num1))/B)
    num3 = int((e-(A*num1)-(B*num2))/C)
    num4 = int((e-(A*num1)-(B*num2)-(C*num3))/D)
    print("%d %d %d %d"%(num1, num2, num3, num4))
    
if __name__ == '__main__':
    calc(e)
