def solve(total,int_lst,cnt_lst):
    index = 0
    for i in int_lst:
        if total == 0:
            print(cnt_lst)
            return
        else :
            if total >= int(i):
                cnt_lst[index] += 1
                solve(total-int(i),int_lst,cnt_lst)
                break
        index += 1
    
if __name__ == "__main__":
    coin_lst = input()
    int_lst = []
    for i in coin_lst.split():
        int_lst.append(i)
    total = int(input())
    cnt_lst = [0]*len(int_lst)
    solve(total,int_lst,cnt_lst)
