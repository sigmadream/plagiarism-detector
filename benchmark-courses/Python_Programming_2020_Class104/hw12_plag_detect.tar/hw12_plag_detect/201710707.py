def change(c, i, s, g):
    n = int(c[i])
    cnt = 1
    while cnt*n <= s:
        cnt += 1
    cnt -= 1
    g.append(str(cnt))

    if i == b-1:
        o = " ".join(g)
        print(o)
        return

    else:
        change(c, i+1, s-cnt*n, g)


if __name__ == "__main__":
    a = input()
    m = int(input())

    coin = a.split()
    b = len(coin)

    change(coin, 0, m, [])
