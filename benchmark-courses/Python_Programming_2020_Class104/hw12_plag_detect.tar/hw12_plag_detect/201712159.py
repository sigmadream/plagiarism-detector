def change(money, coin, i):
    count = 0
    if money//coin[i] >= 1:
        count = money//coin[i]
        money = money - coin[i]*count
        print(count, end="")
        if i+1 < len(coin):
            print(" ", end="")
            change(money, coin, i+1)
    else:
        print(count, end="")
        if i+1 < len(coin):
            print(" ", end="")
            change(money, coin, i+1)

def main():
    co = list(map(int, input().split()))
    mo = int(input())
    change(mo, co, 0)

if __name__ == "__main__":
    main()
