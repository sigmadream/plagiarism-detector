#coding: utf-8

def result(c, csum):
    for i in range(0, len(coin)):
        r = csum // c[i]
        if i != len(c)-1:
            print(r, end=" ")
        else:
            print(r, end="")
        csum = csum - (r * c[i])

if __name__ == "__main__":
    a = input()
    coinsum = int(input())
    coin = a.split()
    coin = [int(i) for i in coin]
    result(coin, coinsum)
