def cal(cnt, line, money):
    if money <= 0:
        if len(line) == 0:
            cnt = map(str, cnt)
            return cnt
        else:
            cnt.append(0)
            cnt = map(str, cnt)
            return cnt
    else:
        cnt.append(money//line[0])
        return cal(cnt, line[1:], money - line[0]*(money//line[0]))

                


if __name__=="__main__":
    line = input().split()
    line = list(map(int, line))
    line.sort()
    line.reverse()
    cnt=[]
    money = int(input())
    print(" ".join(cal(cnt, line, money)))
