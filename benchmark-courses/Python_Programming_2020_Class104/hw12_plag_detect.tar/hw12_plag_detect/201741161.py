def main():
    a, b, c, d = map(int, input().split())
    sum = int(input())
    x = sum // a
    y = (sum % a) // b
    z = ((sum % a) % b) // c
    w = (((sum % a) % b) % c) // d
    print(x, y, z, w)
if __name__ == "__main__":
    main()
