def change(s_unit, money, count):
    if count + 1 == len(s_unit):
        print(money // int(s_unit[count]))
    else:
        if (money // int(s_unit[count])) == 0:
            count += 1
            print("0", end = " ")
            change(s_unit, money, count)
        else:
            print(money // int(s_unit[count]), end = " ")
            money -= int(s_unit[count]) * (money // int(s_unit[count]))
            count += 1
            change(s_unit, money, count)

if __name__ == "__main__":
    change_unit = str(input())
    money = int(input())
    
    s_unit = change_unit.split(' ')
    
    count = 0
    
    change(s_unit, money, count)
