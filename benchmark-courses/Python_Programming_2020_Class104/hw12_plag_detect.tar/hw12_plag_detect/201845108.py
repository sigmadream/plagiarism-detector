def main():
    a = [x for x in input().split()]
    b = a
    for i in range(len(b)):
        b[i] = int(b[i])
    result = int(input())
    n=m=o=2
    count = []
    while result-b[0]>0:
        b[0] = b[0]*n
        n += 1
    result = result - b[0] + a[0]
    count.append(n-1)

    while result - b[1]>0:
        b[1] = b[1]*m
        m += 1
    result = result - b[1] + a[1]
    count.append(m-1)

    while result - b[2]>0:
        b[2] = b[2]*o
        o += 1

    count.append(o-1)
    print(count)

if __name__=="__main__":
    main()

