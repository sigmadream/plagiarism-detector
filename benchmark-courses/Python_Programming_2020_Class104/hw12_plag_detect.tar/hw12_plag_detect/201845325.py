if __name__=="__main__":
    while True:
        coins = input()
        total = int(input())
        coin_list = [int(coin) for coin in coins.split()]
        count_list = []

        for coin in coin_list:
            count = total // coin
            total = total - coin * count
            count_list.append(count)
        print(" ".join(map(str, count_list)))
