
money,c500,c300,c100,c50,c10 = 0,0,0,0,0,0
    
if "__main__" == __name__:
    coin_kind = input().split()
    money = int(input())
    for i in range(0, len(coin_kind)):
        result[0] = money % coin_kind[0]
        money %= coin_kind[0]
    result = 0

    for i in range(money):
        result = result + coin_kind[i]
    print(result)

def change(t):
    if t >= len(change) - 1:
        return
    else :
        if change[t] < change[t+1]:
            change[t] = -change[t]
    change(t+1)

##if "__main__" == __name__:
##    coin_kind = input().split()
##    money = int(input())
##    
##    if coin_kind == '500 100 50 10':
##        c500 = money // 500
##        money %= 500
##        c100 = money // 100
##        money %= 100
##        c50 = money // 50
##        money %= 50
##        c10 = money // 10
##        money %= 10
##        print(c500, c100, c50, c10)
##    else :
##        c300 = money // 300
##        money %= 300
##        c100 = money // 100
##        money %= 100
##        c50 = money // 50
##        money %= 50
##        c10 = money // 10
##        money %= 10
##        print(c300, c100, c50, c10)

