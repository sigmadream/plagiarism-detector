def change (num, coin) :
    c = int(coin)
    return num//c

if __name__ == "__main__" :
    coins = input()
    coinlist = coins.split()
    num = int(input())
    for i in coinlist :
        result = []
        result.append(change (num, i))
        num=num%int(i)
    print(" ".join(result))
