
s = input()
x = int(input())
su = s.split()
nu = []







su = [int(i) for i in su]







if __name__ == "__main__":
    for i in range (0, len(su)):
        nu.append(x//su[i])
        x = x- su[i]*(x//su[i])

    nu = [str(i) for i in nu]
    nus = " ".join(nu)
    print(nus)
