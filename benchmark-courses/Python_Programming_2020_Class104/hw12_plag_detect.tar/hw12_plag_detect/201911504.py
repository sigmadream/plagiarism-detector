def change():
    coin = input().split()
    money = int(input())
    alist= []
    for i in (0, 1 ,2 ,3):
        alist.append(money // int(coin[i]))
        money %= int(coin[i])
    list_a = list(map(str, alist))
    print(" ".join(list_a))

change()
