def coin(a,b):
    c=a.split()
    freq=[]
    for i in range(len(c)):
        if (b//int(c[i])>=1):
            freq.append(b//int(c[i]))
            b=b%int(c[i])
        else:
            freq.append(0)

    for j in range(len(freq)):
        freq[j]=str(freq[j])
    return " ".join(freq)

if __name__=="__main__":
    a=input()
    b=int(input())
    print(coin(a,b))
