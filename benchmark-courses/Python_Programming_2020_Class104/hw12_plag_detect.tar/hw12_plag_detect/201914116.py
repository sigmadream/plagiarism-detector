def getcnum(coin, change):
    return int(change / coin)

def coinchange(coinls, coinnum, n, change):
    if n > len(coinls) - 1:
        s = ""
        for coin in coinls:
            s += str(coinnum[int(coin)]) + " "
        print(s.strip())
    else:
        coinnum[int(coinls[n])] = getcnum(int(coinls[n]), change)
        change -= int(coinls[n]) * getcnum(int(coinls[n]), change)
        n += 1
        coinchange(coinls, coinnum, n, change)

def main():
    coin = input()
    change = int(input())
    coinls = coin.split()
    coinnum = {}
    coinchange(coinls, coinnum, 0, change)

if __name__ == "__main__":
    main()
