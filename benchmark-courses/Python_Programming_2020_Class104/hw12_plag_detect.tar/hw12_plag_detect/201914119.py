#coding:utf-8

def main(x, y1):
    i = 0
    z = []
    while i < len(ns):
        x1 = int(x[i])
        y = int(y1)
        t = str(y//x1)
        z.append(t)
        y1 = y%x1
        i += 1
    return ' '.join(z)

if __name__ == "__main__":
    n = input()
    ns = n.split()
    k = input()

    print(main(ns, k))
