#coding : utf-8
inp = input()
tot1 = input()
inpu = inp.split()
loca = 0
tot = int(tot1)

def calc(a, b, c, d) :
    if c < len(a) :
        num = int(a[c])
        quoti = b // num
        d.append(quoti)
        b = b - quoti*num
        c = c + 1
        calc(a, b, c, d)
    return d

def printing(e) :
    for i in range (len(e)) :
        if i < len(e)-1 :
            print(e[i], end=" ")
        elif i < len(e) :
            print(e[i])

if __name__ == "__main__" :
    quotient = []
    quotient = calc(inpu, tot, loca, quotient)
    printing(quotient)