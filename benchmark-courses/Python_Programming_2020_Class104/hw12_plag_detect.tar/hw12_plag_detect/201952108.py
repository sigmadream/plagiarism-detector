def result(coindic):
    i = len(coindic.values())
    res = ""
    for value in coindic.values():
        if i == 1:
            res += str(value)
            print(res)
        else:
            res += str(value)+' '
            i -= 1

def store(mon, c, cnt, coindic):
    if mon < c:
        coindic[c] = cnt
        return mon
    else:
        store(mon-c, c, cnt+1, coindic)

def main(cols, money):
    coindic = {}
    for co in cols:
        co = int(co)
        cnt = 0
        store(money, co, cnt, coindic)
        money = money % co
    result(coindic)

if __name__ == "__main__":
    coin = input()
    change = input()
    coinls = coin.split()
    main(coinls, int(change))
