def change(num1, num2, num3):
    res = len(num1)
    if res == 0:
        print(' '.join(num3))
    else:
        e = num2 // num1[0]
        num3.append(str(e))
        num2 = num2 - (e * num1[0])
        num1.remove(num1[0])
        change(num1, num2, num3)
if __name__ == "__main__":
    a = list(map(int, input().split()))
    b = int(input())
    d = []
    change(a, b, d)
