def f(s,k,n,ans):
    if n == len(s):
        print(" ".join(ans))
        return
    ans.append(str(k//int(s[n])))
    k = k - (k//int(s[n])) * int(s[n])
    return f(s,k,n+1,ans)

if __name__ == '__main__':
    s = list(input().split())
    k = int(input())
    #print(s,k)
    f(s,k,0,[])
