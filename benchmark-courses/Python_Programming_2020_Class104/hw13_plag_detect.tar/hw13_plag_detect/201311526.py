# coding: utf-8

def count369(s):
    num = list(str(s))
    c369 = [c for c in num if c in '369']
    return len(c369)

if __name__ == "__main__":
    a = input()
    b = a.split()
    c = int(b[0])
    d = int(b[1])
    l = list(range(c, (d + 1)))
    n = 0
    for i in range(0, len(l)):
        syg = count369(l[i])
        n = n + syg
    print(n)
