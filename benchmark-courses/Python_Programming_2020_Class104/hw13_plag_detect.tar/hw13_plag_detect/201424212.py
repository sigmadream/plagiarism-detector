def number_clap(number):
    num = 0
    for t in number:
        for q in list(str(t)):
            if q in "369":
                num += 1
    return num

if __name__ == "__main__":
    string = input()
    string = string.split()

    s_string = [i for i in range(int(string[0]), int(string[1])+1) for j in list(str(i)) if j in "369"]
    s_string = sorted(set(s_string))
    result = number_clap(s_string)
    print(result)
