def claps():
    n = input().split()
    a = int(n[0])
    b = int(n[1])
    m = "369"
    m1 = ""
    for i in range(a, b+1):
        m1 = m1 + str(i)
    m2 = [i for i in m1 if i in m]
    print(len(m2))
if __name__ == "__main__":
    claps()
