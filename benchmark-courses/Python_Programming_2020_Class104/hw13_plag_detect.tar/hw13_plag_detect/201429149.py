def main():
    A = str(input())
    SA = A.split()
    IA1 = int(SA[0])
    IA2 = int(SA[1])
    ns = list(range(IA1,IA2+1))
    count = 0
    nns = [ str(lang) for lang in ns ]
    for I in nns :
        for J in I :
            if J in "369":
                count += 1
            
    print(count)
    


if __name__ == "__main__" :
    main()
