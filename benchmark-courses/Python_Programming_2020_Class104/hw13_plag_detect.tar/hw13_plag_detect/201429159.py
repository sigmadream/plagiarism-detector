if __name__ == "__main__":
    line = input()
    numbers = line.split()

    a = int(numbers[0])
    b = int(numbers[1])

    ls = [i for i in range(a, b+1)]

    cnt = 0

    for i in range(len(ls)):
        for j in str(ls[i]):
            if int(j) == 3 or int(j) == 6 or int(j) == 9:
                cnt += 1

    print(cnt)
