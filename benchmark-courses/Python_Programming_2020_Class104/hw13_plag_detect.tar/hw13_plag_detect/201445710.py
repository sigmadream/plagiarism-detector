inp = input().split()
A = int(inp[0])
B = int(inp[1])


def diag(N):
    value = 0
    for digit in str(N):
        if digit in ['3','6','9']:
            value += 1
    return value

if __name__ == "__main__":
    clap = 0
    while A <= B:
      clap += diag(A)
      A += 1
    print(clap)
