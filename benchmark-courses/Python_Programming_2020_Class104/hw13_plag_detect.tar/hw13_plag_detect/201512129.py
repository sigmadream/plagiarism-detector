def clabs(num):
    num_list = list(str(num))
    content = ""
    for i in num_list:
        if i in '369':
            content += '*'
        else:
            content += i
    return content
if __name__ == "__main__":
    range_list = input().split()
    a = int(range_list[0])
    b = int(range_list[1])
    ls = [clabs(s) for s in range(a, b+1)]
    ls = list(''.join(ls))
    clabs = 0
    for count in ls:
        if count == '*':
            clabs += 1
    print(clabs)
