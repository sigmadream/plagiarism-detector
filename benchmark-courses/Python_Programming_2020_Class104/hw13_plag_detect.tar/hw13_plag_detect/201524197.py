def count_369(num, count):
    if num > 0:
        if num%10 in [3, 6, 9]:
            count += 1
        return count_369(int(num/10), count)
    else:
        return count

if __name__ == "__main__":
    nums = str(input())
    numlist = list(map(int, nums.split()))
    result = 0
    for n in range(numlist[0], numlist[1]+1):
        result += count_369(n, 0)
    print(result)
