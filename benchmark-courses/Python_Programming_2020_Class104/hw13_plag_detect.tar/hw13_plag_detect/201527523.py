


def is_claps(num):
    for c in num:
        if c == '3' or c == '6' or c == '9':
            return True
    return False

def process(input):
    str_list = input.split()
    start = int(str_list[0])
    end = int(str_list[1])
    num_list = []
    claps = 0

    for i in range(start, end+1):
        num_list.append(str(i))

    clap_list = [num for num in num_list if is_claps(num)]

    for num in clap_list:
        claps = claps + c(num)
    print(claps)
    
def cnt(num):
    count = 0
    for c in num:
        if c == '3' or c == '6' or c == '9':
            count = count+1
    return count

if __name__ == "__main__":
    input_str = input()
    process(input_str)