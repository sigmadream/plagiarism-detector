def digit369(num):
    cell = 1
    while True:
        if num//10 > 0:
            cell += 1
            num = num//10
        else:
            break
    return cell

def checker369(num):
    digit = digit369(num)
    retn = 0
    for i in range(digit):
        checker = num%(10**(i+1))
        checker = checker//(10**(i))
        if checker != 0 and checker%3 == 0:
            retn += 1
    return retn

def go369(nummin, nummax):
    retn = 0
    m = [n for n in range(nummin, nummax+1)]
    for i in m:
        retn += checker369(i)
    print(retn)


if __name__ == "__main__":
    inputnum = input()
    intnum = inputnum.split()
    go369(int(intnum[0]), int(intnum[1]))
