def clap_count(number, count):
    remainder = number%10
    quotience = number//10
    if number == 0:
        return count
    if remainder and remainder%3 == 0:
        count += 1
    return clap_count(quotience, count)

if __name__ == "__main__":
    a, b = map(int, input().split())
    c = [i for i in range(a, b+1)]
    n = 0
    for i, _ in enumerate(c):
        n += clap_count(c[i], 0)
    print(n)
