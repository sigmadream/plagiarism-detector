if __name__ == "__main__":
    num=input().split()
    nuum=[str(i) for i in range(int(num[0]), int(num[1])+1) if str(i).count('3') or str(i).count('6')or str(i).count('9')]
    numm="".join(nuum)
    print(numm.count('3')+numm.count('6')+numm.count('9'))
