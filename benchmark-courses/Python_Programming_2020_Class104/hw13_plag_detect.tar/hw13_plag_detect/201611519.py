def claps(a):
    m="".join(n)
    print(m.count('3')+m.count('6')+m.count('9'))

if __name__ == "__main__":
    a = input()
    b = a.split()
    n = [str(i) for i in range(int(b[0]), int(b[1])+1)]
    claps(a)
