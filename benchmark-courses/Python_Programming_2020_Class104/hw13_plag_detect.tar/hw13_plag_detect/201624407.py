def havetoclap(s):
    if '3' in s or '6' in s or '9' in s:
        return True

def cnt369(s):
    cnt = 0
    cnt = cnt + s.count('3')
    cnt = cnt + s.count('6')
    cnt = cnt + s.count('9')
    return cnt

if __name__ == "__main__":
    var = input().split()
    line = []
    for i in var:
        line.append(int(i))
    clist = []
    i = line[0]
    while line[0] <= i and i <= line[1]:
        clist.append(str(i))
        i = i + 1
    chlist = [string for string in clist if havetoclap(string)]
    justforcnt = ''
    for i in chlist:
        justforcnt = justforcnt + i
    print(cnt369(justforcnt))
