

if __name__=="__main__":
    num1,num2=map(int,input().split())
    num_list=[]
    for i in range(num1,num2+1,1):
      num_list.append(str(i))
    lang = [s for s in  num_list if ("3" in s) or ("6" in s) or ("9" in s)]
    count_num=len(lang)
    print(count_num)