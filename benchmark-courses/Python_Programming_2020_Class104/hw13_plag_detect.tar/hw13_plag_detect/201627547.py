#coding:utf-8

def clap_num(x):
    results = 0
    for i in str(x):
        if i in ['3', '6', '9']:
            results = results + 1
    return results

def filteration(x):
    s = x.split()
    filters = [clap_num(i) for i in range(int(s[0]), int(s[1])+1, 1) if '3' in str(i) or '6' in str(i) or '9' in str(i)]
    result = 0
    for j in range(len(filters)):
        result = result + int(filters[j])
    return result

if __name__ == "__main__":
    ranges = input()

    print(filteration(ranges))
