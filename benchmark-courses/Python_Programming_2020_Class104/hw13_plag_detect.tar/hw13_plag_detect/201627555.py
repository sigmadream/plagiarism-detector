def fun(n):
    mok = n
    namuji = 0
    star = 0
    while mok != 0:
        namuji = int(mok%10)
        mok = int(mok/10)
        if namuji == 3 or namuji == 6 or namuji == 9:
            star = star + 1
    return star
if __name__ == "__main__":
    text = input()
    arr = text.split()
    a = int(arr[0])
    b = int(arr[1])
    num = list(range(a, b+1))
    clap = 0
    for i in num:
        clap = clap +fun(i)
    print(clap)
