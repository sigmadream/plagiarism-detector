def does_369_match(number):
    for n in number:
        if n in ['3', '6', '9']:
            return True
    return False


def how_many_claps(number):
    claps = 0
    for n in number:
        if n in ['3', '6', '9']:
            claps += 1
    return claps


if __name__ == "__main__":
    user_input = input().split()
    lower_bound = int(user_input[0])
    upper_bound = int(user_input[1])

    range_nums = [str(num) for num in range(lower_bound, upper_bound + 1)]

    filtered_nums = [
        filtered_num for filtered_num in range_nums if does_369_match(filtered_num)]

    total_claps = 0

    for num in filtered_nums:
        total_claps += how_many_claps(num)

    print(total_claps)
