# -*- coding: utf-8 -*-

def countsu():
    num = 0
    for i in range(c+1):
        d = a + i
        e = str(d)
        f = list(e)        
        for k in range(len(f)):
            if f[k-1] == '3':
                num = num + 1
            elif f[k-1] == '6':
                num = num + 1
            elif f[k-1] == '9':
                num = num + 1        
    print(num)
    
if __name__ == '__main__':
    a, b = input().split()
    a = int(a)  
    b = int(b)    
    c = b - a
    countsu()
