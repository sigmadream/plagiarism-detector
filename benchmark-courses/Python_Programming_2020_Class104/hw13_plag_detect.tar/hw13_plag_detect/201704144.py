def is369(num):
    lst = [3, 6, 9]
    return num in lst

def claps(a,b):
    count = 0
    for x in range(a,b+1):
        while (x > 0):
            if is369(x%10):
                count += 1
            x = x//10
    print(count)

if __name__ == "__main__":
    a, b = map(int, input().split())
    claps(a,b)