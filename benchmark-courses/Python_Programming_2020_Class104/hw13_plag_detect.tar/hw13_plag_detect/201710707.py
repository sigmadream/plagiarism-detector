if __name__ == "__main__":
    k = input()
    k = k.split()
    a = int(k[0])
    b = int(k[1])

    m = [i for i in range(a, b+1) if (i%10)%3 == 0 and (i%10) != 0]
    n = [i for i in range(a, b+1) if (i//10)%3 == 0 and ((i//10)%10) != 0]
    l = [i for i in range(a, b+1) if (i//100)%3 == 0 and ((i//100)%10) != 0]

    s = len(m) + len(n) + len(l)

    print(s)
