def find369(a, b):
    clap = [c for c in range(a, b+1) if "3" in str(c) or "6" in str(c) or "9" in str(c)]
    co = []
    for i in clap:
        if "3" in str(i):
            co.append(str(i).count("3"))
        if "6" in str(i):
            co.append(str(i).count("6"))
        if "9" in str(i):
            co.append(str(i).count("9"))
    print(sum(co))

if __name__ == "__main__":
    A, B = map(int, input().split())
    find369(A, B)
