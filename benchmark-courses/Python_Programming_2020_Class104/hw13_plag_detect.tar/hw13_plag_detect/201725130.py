#coding: utf-8

def filter(a, b):
    count=0
    ccount=0
    fils=[]
    amount=[]
    
    for i in range(a, b+1):
        fils.append(i)
    
    for fil in fils:
        if "3" in str(fil) or "6" in str(fil) or "9" in str(fil):
            amount.append(str(fil))
            ccount+=1


    for num in amount:
        size=len(num)
        for i in range(0, size-1):
            if num[i]==num[i+1]:
                ccount+=1
                
            
            
            

    result=count+ccount
    print(result)
            
if __name__=="__main__":
    n1, n2=input().split()
    n1=int(n1)
    n2=int(n2)
    filter(n1, n2)

    
    


