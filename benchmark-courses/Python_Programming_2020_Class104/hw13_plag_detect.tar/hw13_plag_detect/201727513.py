def clap(x):
    xx = list(str(x))
    for j in xx:
        if int(j) % 3 == 0 and int(j) != 0:
            return x

def cou(y):
    y = str(y)
    new = []
    for k in y:
        if int(k) % 3 == 0 and int(k) != 0:
            new.append(y)
    return len(new)

if __name__ == "__main__":
    number = input().split()
    number = list(map(int, number))
    nums = []
    for i in range(number[0], number[1]+1):
        nums.append(i)
    result = [n for n in nums if clap(n)]
    cnt = 0
    for c in result:
        cnt += cou(c)
    print(cnt)