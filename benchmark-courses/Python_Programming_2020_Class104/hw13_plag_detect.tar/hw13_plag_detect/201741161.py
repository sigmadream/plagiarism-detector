a, b = map(int, input().split())
def syg(a, b):
    num = [str(i) for i in range(a, b + 1)]
    count = 0
    for j in num:
        for k in j:
            if k in '369':
                count += 1
    print(count)

if __name__ == "__main__":
    syg(a, b)