a, b = map(int, input().split())

def clab(a, b):
    count = 0
    for i in range(a, b+1):
        current = i
        while current !=0:
            if current % 10 == 3 or current % 10 == 6 or current % 10 ==9:
                count += 1
            current = current // 10
    return count

game = clab(a, b)
print(game)
