if __name__=="__main__":
    num = input()
    numli = num.split()
    numli[0]=int(numli[0])
    numli[1]=int(numli[1])
    
    intlist = [num for num in range(numli[0],numli[1]+1)]


    for i in range(len(intlist)):
        n = str(intlist[i])
        if "3" in n or "6" in n or "9" in n:
            if intlist[i]>30 and intlist[i]%3==0:
                    intlist[i] = "*"*2
            else:
                intlist[i] = '*'

    
    count = 0
    for i in range(len(intlist)):
        if intlist[i]=='*':
            count +=1
        elif intlist[i]=="**":
            count += 2

    print(count)


    

