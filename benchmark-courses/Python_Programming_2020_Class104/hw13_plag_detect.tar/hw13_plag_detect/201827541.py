def is369(num):

    s = str(num)

    sl = list(s)

    if '3' in sl:
        return True
    elif '6' in sl:
        return True
    elif '9' in sl:
        return True
    else :
        return False

if __name__ == "__main__":

    bounds = str(input())
    s_bounds = bounds.split(' ')
    lower_bound = int(s_bounds[0])
    upper_bound = int(s_bounds[1])

    lnum = [num for num in range(lower_bound, upper_bound+1) if is369(num)]

    count = 0

    for i in lnum:
        i = str(i)
        ls = list(i)
        count += ls.count("3")
        count += ls.count("6")
        count += ls.count("9")

    print(count)
