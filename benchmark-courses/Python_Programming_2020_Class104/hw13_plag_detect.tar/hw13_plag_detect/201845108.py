a = [x for x in input().split()]
number = list(range(int(a[0]),int(a[1])+1))
n = [[i]for i in range(int(a[0]),len(number)+1) if m(s)]
print(len(n))

def m(s):
    if len(s)==1:
        if s==3 or s==6 or s==9:
            return m(s)
    if len(s)==2:
        s = [[i]for i in range(len(s))]
        if s[0]==[3] or s[0]==[6] or s[0]==[9]:
            return m(s)
            if s[1]==[3] or s[1]==[6] or s[1]==9:
                return m(s)
