a=input()
b=a.split()
c=[str(i) for i in range(int(b[0]), int(b[1])+1)]
s="".join(c)
print(s.count('3')+s.count('6')+s.count('9'))
