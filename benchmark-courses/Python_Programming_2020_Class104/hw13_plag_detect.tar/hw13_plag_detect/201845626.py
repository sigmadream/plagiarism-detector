def claps(lastn):
    count = 0
    for i in range(ini, lastn + 1):
        curr = i
        temp = count
        while curr != 0:
            if curr % 10 == 3 or curr % 10 == 6 or curr % 10 == 9:
                count += 1
            curr = curr // 10
        if temp == count:
            print(end = '')
    return count

if __name__ == "__main__":
    ininum, lastnum = input().split()
    ini = int(ininum)
    lastn = int(lastnum)
    ret = claps(lastn)
    print(ret)