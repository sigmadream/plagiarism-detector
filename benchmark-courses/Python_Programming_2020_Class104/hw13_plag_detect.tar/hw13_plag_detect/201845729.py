def clapcount(n1, n2):
    claps = [num for num in range(int(n1), int(n2)+1)]
    claps = list(map(str, claps))
    claps = [num for num in claps if "3" in num or "6" in num or "9" in num]
    clap = "".join(claps)
    n = clap.count('3')
    n += clap.count('6')
    n += clap.count('9')
    print(n)
def main():
    [n1, n2] = input().split()
    clapcount(n1, n2)
if __name__ == "__main__":
    main()
