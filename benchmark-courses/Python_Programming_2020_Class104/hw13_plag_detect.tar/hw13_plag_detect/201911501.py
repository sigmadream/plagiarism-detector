def sep(a) :
    if a < 10 :
        return a
    else :
        return a%10
        sep(a//10)

def cnt(c) :
    k = 0
    for i in c :
        for j in range(len(str(i))) :
            b = i%(10**(j+1))
            if b%3 == 0 :
                if b != 0 :
                    k += 1
            else :
                k = k
            i = i//(10**(j+1))
    return k

if __name__ == "__main__" :
    r = input()
    rr = r.split()
    rrange = range(int(rr[0]), int(rr[1])+1)
    result = cnt(rrange)
    print(result)
