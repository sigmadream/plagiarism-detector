a = input()
li = a.split()
lis = []
num = []
snum = []

if __name__ == "__main__":
    for i in range(2):
        lis.append(int(li[i]))

    for i in range(lis[0], lis[1]+1):
        num.append(i)

    for i in range(len(num)):
        snum.append(str(num[i]))


    cla = [cl for cl in snum if "3" in cl or "6" in cl or "9" in cl]
    nu = "".join(cla)
    a = nu.count("3")
    b = nu.count("6")
    c = nu.count("9")
    print(a+b+c)

    




