def three_six_nine(number):
    count = 0
    fn = int(number[0])
    ln = int(number[1])
    for i in range(fn, ln+1):
        num = i
        while num != 0:
            if num % 10 == 3 or num % 10 == 6 or num % 10 == 9:
                count += 1
            num //= 10
    return count

if __name__ == "__main__":
    sus_ssa = input().split()
    print(three_six_nine(sus_ssa))
