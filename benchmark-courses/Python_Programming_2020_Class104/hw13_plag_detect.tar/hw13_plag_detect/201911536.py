def claps(a):
    b=a.split()
    freq=[]
    for j in range(int(b[0]),int(b[1])+1):
        m=j%10
        n=j//10
        if (((m==3)or(m==6)or(m==9))and((n==3)or(n==6)or(n==9))):
            freq.append("**")
        elif((n==3) or (n==6) or (n==9) or (m==3) or (m==6) or (m==9)):
            freq.append("*")
    x=freq.count("*")
    y=freq.count("**")*2
    return x+y
        
if __name__=="__main__":
    a=input()
    print(claps(a))

