def clap(num):
    if num == "3":
        return True
    if num == "6":
        return True
    if num == "9":
        return True

def getclaps(ls2):
    claps = 0
    for num in ls2:
        for i in range(len(num)):
            if clap(num[i]):
                claps += 1
    return claps
    
def main():
    s = input()
    ls = s.split()
    start = int(ls[0])
    end = int(ls[1])
    ls = [i for i in range(start, end + 1)]
    ls2 = []
    for i in range(len(ls)):
        ls2.append(str(ls[i]))
    ls3 = [num for num in ls2 if "3" in num or "6" in num or "9" in num]
    claps = getclaps(ls3)
    print(claps)

if __name__ == "__main__":
    main()


                    
