def omg(k):
    h = 0
    h += k.count('3')
    h += k.count('6')
    h += k.count('9')
    return h != 0

def wwo(k):
    h = 0
    h += k.count('3')
    h += k.count('6')
    h += k.count('9')
    return h

if __name__ == "__main__":
    a = input()
    sa = a.split()
    r = range(int(sa[0]), int(sa[1]) + 1)
    ls = []
    for ra in r:
        ls.append(str(ra))
    num = [lss for lss in ls if omg(lss)]
    t = 0
    for tt in num:
        t += int(wwo(tt))
    print(t)
