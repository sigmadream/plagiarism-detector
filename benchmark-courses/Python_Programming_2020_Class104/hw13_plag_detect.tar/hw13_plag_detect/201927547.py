#coding : utf-8
##pip > pip install package
##pip install numpy
# have to use list comprehension

inlist = input()
numbs = inlist.split()

def count(numlist) :
    countnum = 0
    for i in range (len(numlist)) :
        num = numlist[i]
        value = []
        num = str(num)
        for n in range (len(num)) :
            value.append(int(num[n]))
        for k in range (len(value)) :
            if value[k]!=0 :
                if (value[k]%3==0) :
                    countnum = countnum + 1
    return countnum

if __name__ == "__main__" :
    numblist = [i for i in range (int(numbs[0]), int(numbs[1])+1)]
    print(count(numblist))