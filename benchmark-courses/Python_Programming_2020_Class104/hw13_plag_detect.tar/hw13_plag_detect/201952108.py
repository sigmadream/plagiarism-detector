def count_clap(n, c):
    for word in str(n):
        if word in '369':
            c += 1
    return c

if __name__ == "__main__":
    ab = input()
    abls = ab.split()
    a = int(abls[0])
    b = int(abls[1])+1
    nums = [num for num in range(a, b)]
    cnt = 0
    for num in nums:
        cnt = count_clap(num, cnt)
    print(cnt)
