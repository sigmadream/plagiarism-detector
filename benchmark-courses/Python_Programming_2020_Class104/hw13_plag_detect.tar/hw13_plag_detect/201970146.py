def clap():
    por = 0
    num1 = list(map(int, input().split()))
    num2 = [num1 for num1 in range(num1[0], num1[1]+1)]
    for i in range(0, len(num2)):
        num2[i] = str(num2[i])
        num2[i] = list(num2[i])

    for i in range(0, len(num2)):
        for j in range(0, len(num2[i])):
            if num2[i][j] == '3':
                por = por + 1
            elif num2[i][j] == '6':
                por = por + 1
            elif num2[i][j] == '9':
                por = por + 1
    print(por)

if __name__ == "__main__":
    clap()
