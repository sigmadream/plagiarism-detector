def f(s):
    if s == 0: return 0
    if s % 10 == 3 or s%10 == 6 or s%10 == 9:return f(s//10)+1
    else: return f(s//10)

if __name__ == "__main__":
    n = input().split()
    #print(33//10)
    #print(f(136))
    arr = [f(i) for i in range(int(n[0]),int(n[1])+1) if f(i)]
    print(sum(arr))
