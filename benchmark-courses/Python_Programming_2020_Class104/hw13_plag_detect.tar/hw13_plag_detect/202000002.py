def claps(n):
    nclaps = [1 for s in str(n) if s in "369"]
    return sum(nclaps)

if __name__ == "__main__":
    ns = [int(s) for s in input().split()]
    a = ns[0]
    b = ns[1]
    ns = [claps(n) for n in range(a, b+1)]
    print(sum(ns))
