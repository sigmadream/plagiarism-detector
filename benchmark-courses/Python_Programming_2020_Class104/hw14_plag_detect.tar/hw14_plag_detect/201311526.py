# coding: utf-8

def poly(z):
    s = z.split()
    s.reverse()
    sl = len(s)
    return list(zip(range(0, sl), s))


def mulpoly(m, n):
    a = m.split()
    b = n.split()
    c = []
    k = 0
    for i in range(0, len(a)):
        for j in range(0, len(b)):
            k = int(a[i]) * int(b[j])
            if i == 0:
                c. append(k)
            else:
                if j == len(b):
                    k = int(a[i]) * int(b[j])
                    c. append(k)
                else:
                    k = int(c[i + j]) + (int(a[i]) * int(b[j]))
                    c[i + j] = k   
    return c

    


if __name__ == "__main__":
    x = "1 -4 6"
    y = "2 0 1 0"
    a = poly(x)
    b = poly(y)
    h = mulpoly(x, y)

    print(a)
    print(b)
    print(h)
