def find_dim_val(pol1, pol2):
    dim = []
    val = []
    for i in pol1:
        for j in pol2:
            value = int(i[1])*int(j[1])
            deg = i[0]+j[0]
            val.append(value)
            dim.append(deg)
    return val, dim

def cal(val, dim):
    result = []
    for index in range(max(dim)+1):
        dim_val = []
        for i in range(len(dim)):
            if index == dim[i]:
                dim_val.append(val[i])
        val_sum = sum(dim_val)
        result.append(str(val_sum))
    result.reverse()
    return result
            

if __name__ == "__main__":
    input1 = input()
    input2 = input()
    input1 = input1.split()
    input2 = input2.split()
    indexs = list(range(len(input1)-1,-1,-1))
    pol1 = list(zip(indexs, input1))
    indexs = list(range(len(input2)-1,-1,-1))
    pol2 = list(zip(indexs, input2))
    val,dim = find_dim_val(pol1,pol2)
    ans = cal(val,dim)
    print(" ".join(ans))
