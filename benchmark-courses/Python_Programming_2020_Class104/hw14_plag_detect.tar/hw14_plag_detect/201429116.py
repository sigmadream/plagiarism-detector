def pmul():
    a = input().split()
    b = input().split()
    a.reverse()
    b.reverse()
    a1 = list(enumerate(a))
    b1 = list(enumerate(b))
    l = []
    for a, b in a1:
        for c, d in b1:
            l.append((a+c, int(b)*int(d)))
    l1 = sorted(l)
    max_ = max(list(map(lambda p: p[0], l1)))
    sum_ = 0
    l2 = []
    for i in range(max_+1):
        for a, b in l1:
            if a == i:
                sum_ += b
        l2.append(sum_)
        sum_ = 0
    l2.reverse()
    l3 = []
    for i in l2:
        l3.append(str(i))
    print(" ".join(l3))
if __name__ == "__main__":
    pmul()
