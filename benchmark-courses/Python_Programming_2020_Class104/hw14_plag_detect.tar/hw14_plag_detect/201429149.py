def main():
    F = str(input())
    G = str(input())
    Fs = F.split()
    Gs = G.split()
    Fr = [ int(lang) for lang in Fs ]
    Gr = [ int(lang) for lang in Gs ]
    Fr.reverse()
    Gr.reverse()
    ns = []
    kl = []
    for i in range( len(Fs) ):
        for j in range( len(Gs) ):
            k = i+j
            ns.append( ( k, Fr[i]*Gr[j]))

    ns.sort()
    ns.reverse()

    maxcnt = ns[0][0]

    for i in range( maxcnt + 1 ) :
        Sum = 0
        for j in ns :
            if i == j[0] :
                Sum = Sum + j[1]
        kl.append(Sum)
    kl.reverse()

    for i in range( len(kl) ):
        if i != (len(kl)-1) :
            print( kl[i] , end=' ')
        else :
            print( kl[i] )
    
    
                
                
                
            
            
    


if __name__ == "__main__" :
    main()
