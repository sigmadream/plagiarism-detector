def cal(fst, snd):
    cal_list = []
    result_list = []
    
    row_num = len(snd)
    col_num = len(fst)+len(snd)-1

    for row in range(row_num):
        cal_list.append([])
        for col in range(col_num):
            cal_list[row].append(0)

    for row in range(row_num):
        result_list.append([])
        for col in range(col_num):
            result_list[row].append(0)

    num = 0

    for row in range(len(snd)):
        for col in range(len(fst)):
            cal_list[row][col+num] = fst[col]*snd[row]
        num += 1

    for row in range(row_num):
        for col in range(col_num):
            for repeat in range(len(snd)):
                result_list[row][col] += cal_list[repeat][col]

    result = result_list[0]

    for i in range(len(result)):
        result[i] = str(result[i])
    
    print(' '.join(result))

if __name__ == "__main__":
    a = input().split()
    b = input().split()
    fst = []
    snd = []
    
    for i in range(len(a)):
        fst.append(int(a[i]))
    for i in range(len(b)):
        snd.append(int(b[i]))

    cal(fst, snd)
