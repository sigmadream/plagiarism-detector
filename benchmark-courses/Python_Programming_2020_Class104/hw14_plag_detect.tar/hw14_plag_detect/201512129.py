def main():
    a = input().split()
    b = input().split()
    a.reverse()
    b.reverse()
    index = [i1 + i2 for (i1, v1) in enumerate(a) for(i2, v2) in enumerate(b)]
    value = [int(v1) * int(v2) for (i1, v1) in enumerate(a) for(i2,v2) in enumerate(b)]
    poly = list(zip(index, value))
    max_num = poly[-1][0]
    coef = []
    for n in range(max_num+1):
        result = 0
        for i in range(len(poly)):
            if poly[i][0] == n:
                result += poly[i][1]
        coef.append(str(result))
    coef.reverse()
    ans = ' '.join(coef)
    print(ans.strip())
if __name__ == "__main__":
    main()
