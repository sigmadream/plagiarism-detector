def p_mul(poly_f, poly_g):
    result = [0 for i in range(len(poly_f) + len(poly_g) -1)]
    for i, x1 in enumerate(poly_f):
        for j, x2 in enumerate(poly_g):
            result[i + j] += x1 * x2
    return result

if __name__ == "__main__":
    first = input()
    second = input()
    fx = list(map(int, first.split()))
    gx = list(map(int, second.split()))
    result_list = p_mul(fx, gx)
    print(" ".join(map(str, result_list)))
