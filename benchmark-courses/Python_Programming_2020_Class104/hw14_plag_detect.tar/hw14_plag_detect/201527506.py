
def pol_mul(pol1, pol2):
    highest1 = len(pol1)
    highest2 = len(pol2)
    pol_ans = list(map(lambda x: 0, range(highest2+highest1-1)))

    for i in range(highest1):
        for j in range(highest2):
            pol_ans[i+j] = pol_ans[i+j] + int(pol1[i]) * int(pol2[j])

    for i, v in enumerate(pol_ans):
        if i == len(pol_ans)-1:
            print(v, end="")
        else:
            print(v, end=" ")

if __name__ == "__main__":
    in_1 = input()
    in_2 = input()
    pol_1 = in_1.split()
    pol_2 = in_2.split()
    pol_mul(pol_1, pol_2)
