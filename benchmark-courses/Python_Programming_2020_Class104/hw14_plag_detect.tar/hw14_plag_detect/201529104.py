def cal_pmul(list1, list2):
    c = []
    for (i, n) in enumerate(list1):
        for (j, m) in enumerate(list(map(lambda x: int(x)*int(n), list2))):
            if i*(j-len(list(map(lambda x: int(x)*int(n), list2)))+1) == 0:
                c.append(m)
            else:
                c[i+j] += m
    return " ".join(list(map(str, c)))

if __name__ == "__main__":
    a = input()
    b = input()
    print(cal_pmul(a.split(), b.split()))
