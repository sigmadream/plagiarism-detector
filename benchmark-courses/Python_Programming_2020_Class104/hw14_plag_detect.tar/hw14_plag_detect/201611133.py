if __name__ == "__main__":
    poly1_string = input().split()
    poly2_string = input().split()
    poly1_int = list(map(int, poly1_string))
    poly2_int = list(map(int, poly2_string))
    poly1_enum = list(enumerate(poly1_int))
    poly2_enum = list(enumerate(poly2_int))
    poly_multiple = [0 for i in range(len(poly1_int)+len(poly2_int)-1)]
    for i, n in poly1_enum:
        for j, m in poly2_enum:
            poly_multiple[j + i] = poly_multiple[j + i] + n*m

    for i, n in enumerate(poly_multiple):
        print(n, sep="", end="")
        if i != len(poly_multiple) - 1:
            print(" ", sep="", end="")
