if __name__=="__main__" :
    f=list(enumerate(input().split()))
    g=list(enumerate(input().split()))
    fg=[]
    for i in f:
        for j in g:
            fg.append((i[0]+j[0],int(i[1])*int(j[1])))
    fg.sort()
    a=[]
    j=0
    t=0
    while j < max(fg)[0]+1:
        for i in fg:
            if i[0]==j:
                t=t+i[1]
        a.append(t)
        j=j+1
        t=0
    for i in a:
        print (i,end=" ")
