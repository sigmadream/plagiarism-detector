def multiply(A, B, m, n): 
  
    prod = [0] * (m + n - 1); 
      
    for i in range(m): 
        for j in range(n): 
            prod[i + j] += A[i] * B[j]; 
    return prod; 

def Poly(poly, n): 
    for i in range(n):
        res.append(poly[i])

        
var1 = input().split()
var2 = input().split()
line1 = []
line2 = []
res = []
for i in var1:
    line1.append(int(i))
line1.reverse()
for i in var2:
    line2.append(int(i))
line2.reverse()

print(line1)
print(line2)

A = line1
B = line2

m = len(A)
n = len(B)

prod = multiply(A, B, m, n)
Poly(prod, m+n-1)
res.reverse()
print(res)

for i in res:
    print(i, end = "")
    print(" ", end = "")
