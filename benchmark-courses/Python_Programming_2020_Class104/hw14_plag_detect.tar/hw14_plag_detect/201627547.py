#coding: utf-8
def product_poly(x1, x2):
    y1 = x1.split()
    y2 = x2.split()

    l = [0 for i in range(len(y1)+len(y2)-1)]
    for i, n in enumerate(y1):
        for j, m in enumerate(y2):
            for k in range(len(l)):
                if k == i + j:
                    a = lambda x, y: x*y
                    l[k] = l[k] + a(int(n), int(m))
    return l

if __name__ == "__main__":
    poly1 = input()
    poly2 = input()
    results = map(str, product_poly(poly1, poly2))
    print(" ".join(results))
