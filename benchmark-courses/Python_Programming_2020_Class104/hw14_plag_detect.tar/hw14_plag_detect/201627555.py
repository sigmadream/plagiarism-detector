if __name__ == "__main__":
    x1 = input().split()
    x2 = input().split()
    anlen = len(x1)+len(x2) - 1
    makerange = lambda x: [i for i in range(len(x))]
    xx1 = makerange(x1)
    xx2 = makerange(x2)
    ans = [0 for i in range(anlen)]
    for j in range(anlen):
        for k in xx1:
            for o in xx2:
                if j == k + o:
                    ans[j] = str(int(ans[j]) + int(x1[k])*int(x2[o]))
    print(' '.join(ans))
