def multi_poly(a, b, len_a, len_b):

    prod = [0] * (len_a + len_b - 1)

    for i in range(len_a):
        for j in range(len_b):
            prod[i + j] += a[i] * b[j]

    return prod


if __name__ == "__main__":
    first_coefficient = input().split()
    second_coefficient = input().split()

    first_poly = list(map(lambda num: int(num), first_coefficient))
    second_poly = list(map(lambda num: int(num), second_coefficient))

    poly_product = multi_poly(first_poly, second_poly,
                              len(first_poly), len(second_poly))

    len_of_coef = len(poly_product)
    count = 0
    for coef in poly_product:
        if count == len_of_coef - 1:
            print(coef)
        else:
            print(coef, end=" ")
        count += 1
