a = input().split()
b = input().split()
A=[]
B=[]
for i in range(len(a)):
    A.append(int(a[i]))
for i in range(len(b)):
    B.append(int(b[i]))

S=[]
H=[]

for i in range(len(A)):
    for k in range(len(B)):
        H.append(i+k)
        
for i in range(len(A)):
    for k in range(len(B)):
        S.append(A[i]*B[k])

num1 = 0
num2 = 0
num3 = 0
num4 = 0
num5 = 0
num6 = 0
for x in range(len(S)):
    if H[x]==0:
        num1 = num1 + S[x]
    if H[x]==1:
        num2 = num2 + S[x]
    if H[x]==2:
        num3 = num3 + S[x]
    if H[x]==3:
        num4 = num4 + S[x]
    if H[x]==4:
        num5 = num5 + S[x]
    if H[x]==5:
        num6 = num6 + S[x]



print(num1, end=" ")
print(num2, end=" ")
print(num3, end=" ")
print(num4, end=" ")
print(num5, end=" ")
print(num6)
