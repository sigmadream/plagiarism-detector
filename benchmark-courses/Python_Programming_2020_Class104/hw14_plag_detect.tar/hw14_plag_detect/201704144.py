def pmul(pol1,pol2):
    A = [pol1[-(x+1)] for x in range(len(pol1))]
    B = [pol2[-(x+1)] for x in range(len(pol2))]

    ans = [0] * (len(A) + len(B) - 1)

    for i in range(0,len(A)):
        for j in range(0,len(B)):
            ans[i + j] += A[i] * B[j]
    ans2 = [ans[-(x+1)] for x in range(len(ans))]

    times = len(ans2)
    for i in ans2:
        if times == 1:
            print(i)
            break
        print(i, end=" ")
        times -= 1

if __name__ == "__main__":
    pol1 = list(map(int, input().split()))
    pol2 = list(map(int, input().split()))
    pmul(pol1,pol2)