def pmul(a, b):
    c = [0 for i in range(len(a) + len(b) - 1)]

    for i, f in enumerate(a):
        for j, s in enumerate(b):
            c[i+j] = c[i+j] + int(f) * int(s)

    c = [str(i) for i in c]
    c = ' '.join(c)

    return c

if __name__ == "__main__":
    m = input()
    n = input()

    m = m.split()
    n = n.split()

    print(pmul(m, n))
