def pmul(f, g):
    f.reverse()
    g.reverse()
    result_mul = []
    for n in range(len(f) + len(g) - 1):
        m = cal(f, g, n)
        result_mul.append(str(m))
    result_mul.reverse()
    print(" ".join(result_mul))

def cal(p, q, n):
    from functools import reduce
    mul = []
    for i, co1 in enumerate(p):
        for j, co2 in enumerate(q):
            if i + j == n:
                mul.append(co1 * co2)
    coef = reduce(lambda x, y: x + y, mul)
    return coef

if __name__ == "__main__":
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))
    pmul(a, b)
