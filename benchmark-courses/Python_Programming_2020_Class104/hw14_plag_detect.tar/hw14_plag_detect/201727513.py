def func(x):
    new = [i for i,n in enumerate(x)]
    return new
if __name__ == "__main__":
    a = input().split()
    b = input().split()
    a = list(map(int, a))
    b = list(map(int, b))
    a.reverse()
    b.reverse()
    result = []
    aa = func(a)
    bb = func(b)
    aaa = list(zip(aa, a))
    bbb = list(zip(bb, b))
    final = []
    for m in range(0, aaa[-1][0]+bbb[-1][0]+1):
        final.append(0)
    for k in range(0, aaa[-1][0]+bbb[-1][0]+1):
        for i in range(len(aaa)):
            for j in range(len(bbb)):
                if aaa[i][0] + bbb[j][0] == k:
                    final[k] += aaa[i][1]*bbb[j][1]
    final.reverse()
    final = list(map(str, final))
    print(" ".join(final))
