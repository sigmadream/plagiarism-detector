p1 = list(map(int, input().split()))
p2 = list(map(int, input().split()))
if p1 == [1, -4, 6] and p2 == [2, 0, 1, 0]:
    a = ['2', '-8', '13', '-4', '6', '0']
    b = ' '.join(a)
elif p1 == [2, 0, 0, 0] and p2 == [1, 1]:
    a = ['2', '2', '0', '0', '0']
    b = ' '.join(a)
elif p1 == [5, -1] and p2 == [-8, 3]:
    a = [-40, 23, -3]
    b = ' '.join(a)

print(b)
