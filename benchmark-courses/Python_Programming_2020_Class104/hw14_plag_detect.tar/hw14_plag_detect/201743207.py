def multiply(a, b, m, n):
    prod = [0] * ( m + n - 1)
    
    for i in range(m):
        for j in range(n):
            prod[i + j] += a[i] * b[j]
    return prod


def polynomial(poly, n):
    for i in range(n):
        print(poly[i], end = "")
        if (i!= 0):
            print("x^", i, end = "")
        if (i!= n - 1):
            print("+", end = "")

a = [int(x) for x in input().split()]
b = [int(x) for x in input().split()]
m = len(a)
n = len(b)

prod = multiply(a, b, m, n)

polynomial(prod, m+n-1)
