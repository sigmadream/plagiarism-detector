if __name__ == "__main__":
    p1 = input()
    pl1 = p1.split()

    p2 = input()
    pl2 = p2.split()

    pl1.reverse()
    pl2.reverse()

    ps1 = list(enumerate(pl1))
    ps2 = list(enumerate(pl2))


    n = []
    a = []

    for i in range(0,len(pl1)):
        for j in range(0,len(pl2)):
            n.append(i+j)
            a.append(int(pl1[i])*int(pl2[j]))

    p = list(zip(n,a))
    p.sort()


    num = 0
    nl=[]
    print(p)
    for j in range(max(n)+1):
        for i in range(len(p)):
            if j == p[i][0]:
                num += p[i][1]
            nl.append(num)
            num = 0

    print(nl)

    






    


