def multiply(poly1, poly2, m, n):
    prod = [0]*(m+n-1)
    for i in range(m):
        for j in range(n):
            prod[i+j] += (lambda x,y:x*y)(poly1[i],poly2[j])
    return prod
if __name__ == "__main__":
    poly1 = list(map(int,input().split()))
    poly2 = list(map(int,input().split()))
    
    m = len(poly1)
    n = len(poly2)
    
    prod = multiply(poly1, poly2, m, n)
    
    for i in range(0, len(prod)):
        if(i == len(prod)-1):
            print(prod[i])
        else:
            print(prod[i], end=' ')
