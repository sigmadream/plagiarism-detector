def snd(p):
    return p[1]

a = list(map(int,input().split())).reverse()
b = list(map(int,input().split())).reverse()
indexes = list(range(1,100))
an = list(zip(indexes, len(a)))
bn = list(zip(indexes, len(b)))
ann = list(map(snd, an))
bnn = list(map(snd, bn))
for i in range(len(a)):
    fs = list(map(lambda ann: 'x'**ann))

for i in range(len(b)):
    gs = list(map(lambda bnn: 'x'**bnn))

rs = list(map(lambda fs,gs: fs*gs))
print(" ".join(rs))