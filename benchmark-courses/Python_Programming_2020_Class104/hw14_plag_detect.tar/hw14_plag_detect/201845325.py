if __name__ == "__main__":
    fy = [int(_) for _ in input().split()]
    gy = [int(_) for _ in input().split()]
    hy = dict()

    fy.reverse()
    gy.reverse()

    for f in range(len(fy)):
        for g in range(len(gy)):
            if not f+g in hy:
                hy[f+g] = 0
            hy[f+g] += fy[f] * gy[g]

    result=list(hy.values())
    result.reverse()

    print(" ".join(str(_) for _ in result))    
