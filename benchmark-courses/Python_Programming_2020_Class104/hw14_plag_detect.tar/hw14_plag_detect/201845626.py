def multi(F, G, m, n): 
	res = [0] * (m + n - 1)
	for i in range(m): 
		for j in range(n): 
			res[i + j] += F[i] * G[j]
	return res

def Poly(poly, n): 
	for i in range(n): 
		print(poly[i] , end = ' '.join(' '))


if __name__ == "__main__":
    F = list(map(int, input().split()))
    G = list(map(int, input().split()))
    m = len(F)
    n = len(G)
    res = multi(F, G, m, n)
    Poly(res, m + n - 1) 