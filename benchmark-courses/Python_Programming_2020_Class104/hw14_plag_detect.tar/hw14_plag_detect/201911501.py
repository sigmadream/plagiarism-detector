def multp(c1, c2) :
    anslist = []
    for h in range(len(c1)+len(c2)-1) :
        a = 0
        for (i, n) in enumerate(c1) :
            for (j, k) in enumerate(c2) :
                if h == i + j :
                    a += int(n)*int(k)
        anslist.append(str(a))
    return anslist

if __name__ == "__main__" :
    c1 = input().split()
    c2 = input().split()
    ans = " ".join(multp(c1, c2))
    print(ans)

