a=input()
b=input()

def coe(a,v):
       prodav = [0]*(len(a)+len(v)-1)

       for n in range(len(a)):
           for m in range(len(v)):
               prodav[n+m] += v[m]*a[n]

       print(prodav)



if "__main__" == __name__:
    from functools import reduce
    arr1=a.split()
    arr2=b.split()
    for i in range(len(arr1)):
        arr1[i]=int(arr1[i])
    for i in range(len(arr2)):
        arr2[i]=int(arr2[i])

    arr1.reverse()
    arr2.reverse()

    coe(arr1,arr2)


