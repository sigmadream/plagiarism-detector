import numpy as np 

a = map(int, input().split())
a = list(a)
b = map(int, input().split())
b = list(b)
  
p1 = np.poly1d(a) 
p2 = np.poly1d(b) 

p = p1*p2
p = str(p.coef)

print(p)
