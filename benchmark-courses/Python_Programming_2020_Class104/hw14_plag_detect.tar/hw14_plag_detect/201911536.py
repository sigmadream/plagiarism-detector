def mul(a,b):
    a1=a.split()
    b1=b.split()
    for m in range(len(a1)):
        a1[m]=int(a1[m])
    for n in range(len(b1)):
        b1[n]=int(b1[n])
    result=[sum([ (a1+[0]*(len(b1)-1))[i]*(b1+[0]*(len(a1)-1))[k-i] for i in range(1+k)]) for k in range(len(a1)+len(b1)-1)]
    for i in range(len(result)):
        result[i]=str(result[i])
    return " ".join(result)


if __name__ == "__main__":
    a=input()
    b=input()
    print(mul(a,b))
