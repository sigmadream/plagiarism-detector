def pmul(ls1, ls2):
    d1 = {}
    d2 = {}
    for n in range(len(ls1)):
        d1[n] = int(ls1[n])
    for n in range(len(ls2)):
        d2[n] = int(ls2[n])
    ls3 = []
    for i in d1:
        for j in d2:
            ls3.append([i + j, d1[i] * d2[j]])
    return ls3

def getc(ls):
    M = max(ls)[0] + 1
    output = ""
    for n in range(M):
        c = 0
        for i in ls:
            if i[0] == n:
                c += i[1]
        output += str(c) + " "
    output = output.rstrip()
    return output

def main():
    s1 = input()
    s2 = input()
    ls1 = s1.split()
    ls2 = s2.split()
    ls3 = pmul(ls1, ls2)
    output = getc(ls3)
    print(output)

if __name__ == "__main__":
    main()
