#coding:utf-8

def wow(a1, b1):
    la = len(a1)
    lb = len(b1)
    tl = la+lb-1
    s = []
    for k in range(tl):
        s.append(0)
    for i, n in enumerate(a1):
        for j, m in enumerate(b1):
            h = i+j
            s[h] += int(n)*int(m)
    s = map(str, s)
    return ' '.join(s)
if __name__ == "__main__":
    a = input()
    a2 = a.split()
    b = input()
    b2 = b.split()
    print(wow(a2, b2))
