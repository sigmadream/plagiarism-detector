# coding : utf-8

first = input().split()
second = input().split()

def multiple(a, b) :
    multi = []
    max = len(first) + len(second) -2
    for k in range (max+1) :
        multi.append(0)
    for i in range (len(a)) :
        for n in range (len(b)) :
            # i+n자리에 넣어두자
            multi[i+n] = int(multi[i+n]) + int(a[i])*int(b[n])
    return multi

if __name__ == "__main__" :
    first.reverse()
    second.reverse()
    multipled = multiple(first, second)
    multipled.reverse()
    for l in range (len(multipled)) :
        print(multipled[l],end= " ")