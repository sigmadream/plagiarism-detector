def index_value(ls):
    indexes = list(range(len(ls)-1, -1, -1))
    return list(zip(indexes, ls))

def mult(ls1, ls2):
    k_ls = []
    c_ls = []
    for i, c1 in ls1:
        for j, c2 in ls2:
            k = i+j
            c = c1*c2
            k_ls.append(k)
            c_ls.append(c)
    return list(zip(k_ls, c_ls))

def sum_several(ls):
    nums = ""
    ls.sort()
    ls.reverse()
    maxi = max(ls[0])
    i = 0
    while(maxi >= 0):
        sum = 0
        cnt = 0
        for p in ls[i:]:
            if p[0] == maxi:
                sum += p[1]
                cnt += 1
            else:
                nums += str(sum) + ' '
                maxi -= 1
                i += cnt
                break
    return nums  

if __name__ == "__main__":
    line1 = input().split()
    line2 = input().split()

    ls1 = list(map(lambda x: int(x), line1))
    ls2 = list(map(lambda x: int(x), line2))

    ls1 = index_value(ls1)
    ls2 = index_value(ls2)

    result_ls = mult(ls1, ls2)
    print(sum_several(result_ls).rstrip())

