
def pmul():
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))
    c = [i for i in range(len(a), 0, -1)]
    d = [i for i in range(len(b), 0, -1)]
    e = []
    f = []
    g = []
    n = []
    for i in range(0, len(a)):
        for j in range(0, len(b)):
            e.append(a[i]*b[j])
            f.append(c[i]+d[j])
    g.append(e[0])
    for i in range(0, len(e)):
        for j in range(0, len(e)):
            if i < j and f[i] != '#' and f[i] == f[j]:
                n.append(e[j])
                f[j] = '#'
        if n != []:
            n.append(e[i])
            g.append(sum(n))
        n = []
    g.append(e[len(e)-1])
    for i in range(0, len(g)):
        g[i] = str(g[i])
    print(' '.join(g))

if __name__ == "__main__":
    pmul()
