from sympy import Symbol, pprint, expand

def main():
    f1 = input().split()
    f2 = input().split()
    # print(f1, f2)


    f1 = list(reversed(f1)) #['6', '-4', '1'] 
    f2 = list(reversed(f2)) # ['4', '2', '0', '4']

    nf1 = len(f1)-1
    nf2 = len(f2)-1

    max = nf1 + nf2
    # print(max)
    # print(f1, f2)

    x = Symbol('x')

    content1 = 0
    content2 = 0
    
    for i,v in enumerate(f1):
        v = int(v)
        content1 += v*x**i
    # print(content1)

    for i,v in enumerate(f2):
        v = int(v)
        content2 += v*x**i
    # print(content2)
    answer = expand((content1)*(content2))
    # print(answer)

    li = []
    for i in range(max):
        li.append(str(answer.coeff(x,i)))
    li = " ".join(li)
    print(li)

if __name__ == "__main__":
    main()