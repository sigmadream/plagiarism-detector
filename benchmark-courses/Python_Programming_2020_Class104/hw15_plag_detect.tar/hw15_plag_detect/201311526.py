# coding: utf-8

from math import sqrt

class Triangle(object):
    def __init__(self, x, y, z):
        self.x, self.y, self.z = float(x), float(y), float(z)
        self.S = (self.x + self.y + self.z) / 2
    def __add__(self, q):
        return Triangle(self.x + q.x, self.y + q.y, self.z + q.z)
    def area(self):
        return sqrt(self.S * (self.S - self.x) * (self.S - self.y) * (self.S - self.z))

if __name__ == "__main__":
    n = input()
    m = input()
    a = n.split()
    b = m.split()
    ps = [Triangle(a[0], a[1], a[2]), Triangle(b[0], b[1], b[2])]
    ps += [ps[0] + ps[1]]
    for p in ps:
        print(f"{p.area():.2f}")
