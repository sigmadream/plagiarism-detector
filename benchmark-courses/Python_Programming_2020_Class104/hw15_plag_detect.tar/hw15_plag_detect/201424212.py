import math
def area(value):
    s = (value[0]+value[1]+value[2])/2
    result = math.sqrt(s*(s-value[0])*(s-value[1])*(s-value[2]))
    return result
if __name__ == '__main__':
    A = input()
    B = input()
    A = A.split()
    B = B.split()
    C =[]
    for i in range(len(A)):
        A[i] = float(A[i])
        B[i] = float(B[i])
        C.append(float(A[i])+float(B[i]))
    total = [A,B,C]
    val = []
    for i in total:
        print(f"{area(i):.2f}")
        
