import math

class Triangle(object):
    def __init__(self, x):
        self.x = x
    def __add__(self, q):
        r = []
        for i in range(len(self.x)):
            r.append(float(self.x[i])+float(q.x[i]))
        return Triangle(r)
    def helon(self):
        s0 = (float(self.x[0])+float(self.x[1])+float(self.x[2]))/2
        result = math.sqrt(s0*(s0-float(self.x[0]))*(s0-float(self.x[1]))*(s0-float(self.x[2])))
        print(f"{result:.2f}")
        
if __name__ == "__main__":
    a = input().split()
    b = input().split()
    a1 = Triangle(a)
    b1 = Triangle(b)
    c = a1 + b1
    a1.helon()
    b1.helon()
    c.helon()
