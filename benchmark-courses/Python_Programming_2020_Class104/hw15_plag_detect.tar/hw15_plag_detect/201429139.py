import math
class Triangle(object):
    def __init__(self, x):
        self.x = x
    def __add__(self, q):
        r = []
        for i in range(len(self.x)):
            r.append(float(self.x[i])+float(q.x[i]))
        return Triangle(r)
    def printhelon(self):
        s0 = (float(self.x[0])+float(self.x[1])+float(self.x[2]))/2
        S = math.sqrt(s0*(s0-float(self.x[0]))*(s0-float(self.x[1]))*(s0-float(self.x[2])))
        return S
if __name__ == "__main__":
    a = input().split()
    b = input().split()
    a1 = Triangle(a)
    b1 = Triangle(b)
    C = a1 + b1
    print(f"{a1.printhelon():.2f}")
    print(f"{b1.printhelon():.2f}")
    print(f"{C.printhelon():.2f}")
