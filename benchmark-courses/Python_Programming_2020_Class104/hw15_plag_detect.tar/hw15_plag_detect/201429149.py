class Triangle:
    def __init__(self,x,y,z) :
        self.x = x
        self.y = y
        self.z = z
        
    def __add__(self,a):
        return Triangle(self.x + a.x , self.y + a.y , self.z + a.z)
    
    def __sub__(self,a):
        return Triangle(a.x - self.x , a.y - self.y , a.z - self.z )

    
    def __repr__(self) :
        s = (self.x + self.y + self.z)/2
        area = ( s*(s-self.x)*(s-self.y)*(s-self.z) )**0.5
        return f"{area:.2f}"

        

def main():
    A = str(input())
    B = str(input())
    A = A.split()
    B = B.split()
    A = [ float(n) for n in A ]
    B = [ float(n) for n in B ]
    ps = [ Triangle(A[0] , A[1] , A[2]) , Triangle(B[0],B[1],B[2])]
    ps += [ ps[0] + ps[1] ]
    for i in ps :
        print(i)
    
    
        
    
if __name__ == "__main__" :
    main()


