
import math

class Point:
    def __init__(self, a, b, c):
        self.a, self.b, self.c = a, b, c
    def __repr__(self):
        return f"Point({self.a}, {self.b}, {self.c})"
    def cal(self):
        s = (self.a + self.b + self.c)/2
        S = math.sqrt(s*(s-self.a)*(s-self.b)*(s-self.c))
        return S

if __name__ == "__main__":
    i1 = input().split()
    i2 = input().split()
    p1 = []
    p2 = []
    p3 = []
    for i in range(len(i1)):
        p1.append(eval(i1[i]))
    for i in range(len(i2)):
        p2.append(eval(i2[i]))
    for i in range(len(i1)):
        p3.append(eval(i1[i])+eval(i2[i]))

    P = [Point(p1[0], p1[1], p1[2]), Point(p2[0], p2[1], p2[2]), Point(p3[0], p3[1], p3[2])]
    
    for p in P:
        print("%.2f" %p.cal())
