One = input().split()
Two = input().split()

q = float(One[0])
w = float(One[1])
e = float(One[2])
a = float(Two[0])
s = float(Two[1])
d = float(Two[2])

r = (q + w + e) / 2
f = (a + s + d) / 2

z = (float(One[0]) + float(Two[0]))
x = (float(One[1]) + float(Two[1]))
c = (float(One[2]) + float(Two[2]))

v = (z + x + c) / 2


area1 = (r*(r-q)*(r-w)*(r-e)) ** 0.5
area2 = (f*(f-a)*(f-s)*(f-d)) ** 0.5
area3 = (v*(v-z)*(v-x)*(v-c)) ** 0.5

print(round(area1,2))
print(round(area2,2))
print(round(area3,2))
