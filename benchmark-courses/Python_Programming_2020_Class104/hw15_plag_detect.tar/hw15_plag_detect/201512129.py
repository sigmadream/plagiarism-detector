class triangle:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
    def __add__(self, T):
        t = triangle(self.a+T.a, self.b+T.b, self.c+T.c)
        return t
    def Area(self):
        s = (self.a+self.b+self.c)/2
        area = s*(s-self.a)*(s-self.b)*(s-self.c)
        import math
        area = math.sqrt(area)
        return area
if __name__ == "__main__":
    n1 = input().split()
    n2 = input().split()
    A = triangle(float(n1[0]), float(n1[1]), float(n1[2]))
    B = triangle(float(n2[0]), float(n2[1]), float(n2[2]))
    C = A + B
    result = [A.Area(), B.Area(), C.Area()]
    for r in result:
        print('%.2f'%r)
