from math import sqrt

class Triangle(object):
    def __init__(self, a, b, c):
        self.a, self.b, self.c = a, b, c
    def __add__(self, t):
        return Triangle(self.a + t.a, self.b + t.b, self.c + t.c)
    def get_s(self):
        s = (self.a + self.b + self.c) / 2
        return s
    def get_area(self):
        s = self.get_s()
        area = sqrt(s * (s - self.a) * (s - self.b) * (s - self.c))
        return f"{area:.2f}"

if __name__ == "__main__":
    firstline = input()
    secondline = input()
    x, y, z = map(float, firstline.split())
    A = Triangle(x, y, z)
    x, y, z = map(float, secondline.split())
    B = Triangle(x, y, z)
    C = A + B
    print(A.get_area())
    print(B.get_area())
    print(C.get_area())
