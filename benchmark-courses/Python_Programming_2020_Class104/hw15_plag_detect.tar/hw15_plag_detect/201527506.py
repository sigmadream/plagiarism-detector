import math

class Myclass(object):
    def __init__(self, a, b, c):
        self.a, self.b, self.c = a, b, c
    def get_area(self):
        s = (self.a + self.b + self.c)/2
        return math.sqrt(s * (s-self.a) * (s-self.b) * (s-self.c))
    def __add__(self, x):
        return Myclass(x.a+self.a, x.b+self.b, x.c+self.c)
    def __repr__(self):
        return f'a length = {self.a} b length = {self.b} c length = {self.c} area = {self.get_area():.2f}'
    def setdata(self, a, b, c):
        self.a, self.b, self.c = a, b, c

if __name__ == "__main__":
    in1 = input()
    in2 = input()
    data1 = in1.split()
    data2 = in2.split()
    t1 = Myclass(float(data1[0]), float(data1[1]), float(data1[2]))
    t2 = Myclass(float(data2[0]), float(data2[1]), float(data2[2]))
    t3 = t1 + t2
    print('%.2f' % t1.get_area())
    print('%.2f' % t2.get_area())
    print('%.2f' % t3.get_area(), end="")
