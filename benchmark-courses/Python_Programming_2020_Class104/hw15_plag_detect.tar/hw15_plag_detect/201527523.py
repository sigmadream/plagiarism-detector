
class Triangle(object):
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
        self.s = (self.x + self.y + self.z)*0.5
        import math
        self.area = math.sqrt(self.s * (self.s-self.x) * (self.s-self.y) * (self.s-self.z))

    def __add__(self, other):
        return Triangle(self.x + other.x, self.y + other.y, self.z + other.z)

    def __repr__(self):
        return f"{self.area:.2f}"

    def gets(self):
        s = (self.x + self.y + self.z)*0.5
        return s

    def getarea(self):
        import math
        area = math.sqrt(self.s * (self.s-self.x) * (self.s-self.y) * (self.s-self.z))
        return area

if __name__ == "__main__":
    t1 = list(map(float, input().split()))
    t2 = list(map(float, input().split()))
    ts = [Triangle(t1[0], t1[1], t1[2]), Triangle(t2[0], t2[1], t2[2])]
    ts += [ts[0] + ts[1]]
    for t in ts:
        print(t)
