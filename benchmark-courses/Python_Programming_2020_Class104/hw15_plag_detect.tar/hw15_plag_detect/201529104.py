import math

def helon(tri_length):
    a = float((str(tri_length).split(" "))[0])
    b = float(str(tri_length).split(" ")[1])
    c = float(str(tri_length).split(" ")[2])
    s = (a+b+c)/2
    print('%.2f' % math.sqrt(s*(s-a)*(s-b)*(s-c)))

class triangle2:
    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z
    def __add__(self, other):
        return triangle2(self.x + other.x, self.y + other.y, self.z + other.z)
    def __repr__(self):
        return f"{self.x} {self.y} {self.z}"

if __name__ == "__main__":
    inputA = input().split()
    inputB = input().split()
    TriA = triangle2(float(inputA[0]), float(inputA[1]), float(inputA[2]))
    TriB = triangle2(float(inputB[0]), float(inputB[1]), float(inputB[2]))
    Tri = [TriA, TriB]
    TriC = Tri[0]+Tri[1]
    helon(Tri[0])
    helon(Tri[1])
    helon(TriC)
