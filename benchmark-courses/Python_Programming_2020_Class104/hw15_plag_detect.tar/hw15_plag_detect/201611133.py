from math import sqrt

class Triangle:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
    def __repr__(self):
        s = (self.x + self.y + self.z)/2
        S = sqrt(s*(s-self.x)*(s-self.y)*(s-self.z))
        return f"{S:0.2f}"
    def __add__(self, Triangle_A):
        return Triangle(self.x + Triangle_A.x, self.y + Triangle_A.y, self.z + Triangle_A.z)

if __name__ == "__main__":
    x1, y1, z1 = map(float, input().split())
    x2, y2, z2 = map(float, input().split())
    A = Triangle(x1, y1, z1)
    B = Triangle(x2, y2, z2)
    C = A + B
    triangles = [A, B, C]
    for i, n in enumerate(triangles):
        print(n, sep="", end="")
        if i < len(triangles) - 1:
            print("\n", sep="", end="")
