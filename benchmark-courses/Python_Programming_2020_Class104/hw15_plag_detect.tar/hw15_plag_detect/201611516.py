class tri:
    def __init__(self,A):
        self.a=A[0]
        self.b=A[1]
        self.c=A[2]
    def area(self):
        s = (self.a+self.b+self.c)/2
        return print("%.2f" %(s*(s-self.a)*(s-self.b)*(s-self.c))**0.5 )
if __name__=="__main__":
    A = list(map(float, input().split()))
    B = list(map(float, input().split()))
    C = [ ]
    for i in range(len(A)):
        C.append(A[i]+B[i])
    tri.area(tri(A))
    tri.area(tri(B))
    tri.area(tri(C))
