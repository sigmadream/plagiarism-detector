from math import sqrt
class tri:
    def __init__(self, A):
        self.a = float(A[0])
        self.b = float(A[1])
        self.c = float(A[2])
    def area(self):
        s = (self.a + self.b + self.c)/2
        ar = sqrt(s * (s - self.a) * (s - self.b) * (s - self.c))
        return print(f"{ar:.2f}")

if __name__ == "__main__":
    p = input().split()
    q = input().split()
    r = []
    for i in range(len(p)):
        r.append(int(p[i]) + int(q[i]))
    tri.area(tri(p))
    tri.area(tri(q))
    tri.area(tri(r))
