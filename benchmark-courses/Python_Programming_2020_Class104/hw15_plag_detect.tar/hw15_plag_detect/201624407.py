import math
a = []
b = []
class Triangle(object):
    def __init__(self, length):
        self.length = length
    def __add__(self, other):
        new_length = []
        for i in range(3):
            new_length.append(self.length[i] + other.length[i])
        return Triangle(new_length)
    def getArea(self):
        s = sum(self.length)/2
        return math.sqrt(s*(s-self.length[0])*(s-self.length[1])*(s-self.length[2]))

def init():
    global a, b
    var1 = input().split()
    var2 = input().split()
    line1 = []
    line2 = []
    for i in var1:
        line1.append(float(i))
    for i in var2:
        line2.append(float(i))
    a = line1
    b = line2
if __name__ == "__main__":
    init()
    A = Triangle(a)
    print(f"{A.getArea():3.2f}")
    B = Triangle(b)
    print(f"{B.getArea():3.2f}")
    C = A + B
    print(f"{C.getArea():3.2f}")
