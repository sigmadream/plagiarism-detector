import math
class Triangle():
    def __init__(self,num1,num2,num3):       #생성자
        self.num1=num1
        self.num2=num2
        self.num3=num3
    def cal(self):            # S 구하는 함수
        s=(self.num1+self.num2+self.num3)/2
        result=math.sqrt(s*(s-self.num1)*(s-self.num2)*(s-self.num3))
        return round(result,2)
    def __add__(self,c):
        result=Triangle(self.num1+c.num1,self.num2+c.num2,self.num3+c.num3)
        return result

if __name__=="__main__":
    a,b,c=map(float,input().split(" "))
    d,e,f=map(float,input().split(" "))
    t1=Triangle(a,b,c)
    t2=Triangle(d,e,f)
    t3=t1.__add__(t2)
    print(t1.cal())
    print(t2.cal())
    print(t3.cal())