#coding: utf-8
from math import sqrt

class triangle:
    def __init__(self,t):
        self.t = t
    def area(self,t):
        s = (float(t[0])+float(t[1])+float(t[2]))/2
        result = sqrt(s*(s-float(t[0]))*(s-float(t[1]))*(s-float(t[2])))
        return result

if __name__ == "__main__":
    a = input()
    b = input()

    m = a.split()
    n = b.split()
    l = [float(m[0])+float(n[0]), float(m[1])+ float(n[1]), float(m[2])+ float(n[2])]
    a1 = triangle(m)

    print(f"{a1.area(m):0.2f}")
    print(f"{a1.area(n):0.2f}")
    print(f"{a1.area(l):0.2f}")
    