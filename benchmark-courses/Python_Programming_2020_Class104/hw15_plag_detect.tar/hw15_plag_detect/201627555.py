from math import sqrt
class Triangle(object):
    'this class represent a triangle'
    @staticmethod
    def printhello():
        'this is static method exercise.'
        print("This is Triangle class.")
    def __init__(self, a, b, c):
        'triangle constructor'
        self.a = a
        self.b = b
        self.c = c
    def area(self):
        'calculate area of triangle'
        d = (self.a + self.b + self.c)/2.0
        result = sqrt(d*(d-self.a)*(d-self.b)*(d-self.c))
        return result
    def __add__(self, other):
        'overload the add operator'
        return Triangle(self.a+other.a, self.b+other.b, self.c+other.c)
if __name__ == "__main__":
    line1 = input()
    line2 = input()
    l1 = line1.split()
    l2 = line2.split()
    tri1 = list(map(float, l1))
    tri2 = list(map(float, l2))
    t1 = Triangle(tri1[0], tri1[1], tri1[2])
    t2 = Triangle(tri2[0], tri2[1], tri2[2])
    t3 = Triangle(tri1[0] + tri2[0], tri1[1] + tri2[1], tri1[2]+tri2[2])
    print('%.2f'%t1.area())
    print('%.2f'%t2.area())
    print('%.2f'%(t1+t2).area())
