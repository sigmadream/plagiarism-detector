from math import sqrt


class Triangle(object):
    def __init__(self, sides):
        self.sides = sides

    def calc_area(self):
        a = float(self.sides[0])
        b = float(self.sides[1])
        c = float(self.sides[2])
        s = (a + b + c) / 2
        area = sqrt(s*(s-a)*(s-b)*(s-c))
        return area

    def __add__(self, other):
        new_triangle = []
        for i in range(3):
            new_triangle.append(float(self.sides[i]) + float(other.sides[i]))
        return Triangle(new_triangle)


if __name__ == "__main__":
    sides1 = input().split()
    sides2 = input().split()

    triangle1 = Triangle(sides1)
    triangle2 = Triangle(sides2)
    added_triangle = triangle1 + triangle2

    print(f'{triangle1.calc_area():.2f}')
    print(f'{triangle2.calc_area():.2f}')
    print(f'{added_triangle.calc_area():.2f}')
