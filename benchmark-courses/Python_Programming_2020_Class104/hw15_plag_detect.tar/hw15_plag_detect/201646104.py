import math

a = input().split()
b = input().split()

A=[]
B=[]
for i in range(len(a)):
    A.append(float(a[i]))
for k in range(len(b)):
    B.append(float(b[k]))

C=[float(a[0])+float(b[0]), float(a[1])+float(b[1]), float(a[2])+float(b[2])] 

s1 = (A[0]+A[1]+A[2])/2
s2 = s1 - A[0]
s3 = s1 - A[1]
s4 = s1 - A[2]
S0 = s1 * s2 * s3 * s4
S = math.sqrt(S0)
print("%0.2f" %S)

g1 = (B[0]+B[1]+B[2])/2
g2 = g1 - B[0]
g3 = g1 - B[1]
g4 = g1 - B[2]
G0 = g1 * g2 * g3 * g4
G = math.sqrt(G0)
print("%0.2f" %G)


w1 = (C[0]+C[1]+C[2])/2
w2 = w1 - C[0]
w3 = w1 - C[1]
w4 = w1 - C[2]
W0 = w1 * w2 * w3 * w4
W = math.sqrt(W0)
print("%0.2f" %W)
