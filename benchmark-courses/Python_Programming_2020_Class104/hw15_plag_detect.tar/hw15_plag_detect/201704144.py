if __name__ == "__main__":
    fst_t = list(map(float,input().split()))
    snd_t = list(map(float,input().split()))
    from math import sqrt
    fst_m = sum(fst_t) / 2
    fst_a = sqrt(fst_m*(fst_m-fst_t[0])*(fst_m-fst_t[1])*(fst_m-fst_t[2]))
    print(f"{fst_a:.2f}")
    snd_m = sum(snd_t) / 2
    snd_a = sqrt(snd_m*(snd_m-snd_t[0])*(snd_m-snd_t[1])*(snd_m-snd_t[2]))
    print(f"{snd_a:.2f}")
    add_t = [fst_t[0]+snd_t[0],fst_t[1]+snd_t[1],fst_t[2]+snd_t[2]]
    add_m = sum(add_t) / 2
    add_a = sqrt(add_m*(add_m-add_t[0])*(add_m-add_t[1])*(add_m-add_t[2]))
    print(f"{add_a:.2f}")