import math

class Tri():
    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z
    def __add__(self, other):
        return Tri(self.x + other.x, self.y + other.y, self.z + other.z)
    def __str__(self):
        s = (self.x + self.y + self.z) / 2
        S = math.sqrt(s * (s - self.x) * (s - self.y) * (s - self.z))
        return f'{S:.2f}'

if __name__ == "__main__":
    a = input()
    b = input()

    a = [float(i) for i in a.split()]
    b = [float(i) for i in b.split()]

    aS = Tri(a[0], a[1], a[2])
    bS = Tri(b[0], b[1], b[2])
    cS = aS + bS

    print(aS)
    print(bS)
    print(cS)
