import math
class Triangle:
    """주어진 세 점으로 만들어지는 삼각형"""
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
    def __add__(self, p):
        r = Triangle(self.x + p.x, self.y + p.y, self.z + p.z)
        return r
    def area(self):
        s = (self.x + self.y + self.z)/2
        t_area = math.sqrt(s*(s - self.x)*(s - self.y)*(s - self.z))
        print("{0:.2f}".format(t_area))

if __name__ == "__main__":
    a, b, c = map(float, input().split())
    d, e, f = map(float, input().split())
    A = Triangle(a, b, c)
    A.area()
    B = Triangle(d, e, f)
    B.area()
    C = Triangle(a, b, c) + Triangle(d, e, f)
    C.area()
