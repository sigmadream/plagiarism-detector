#coding: utf-8

import math
def area(n1, n2, n3):
    s = (n1 + n2 + n3) / 2
    aarea = s * (s - n1) * (s - n2) * (s - n3)
    aarea = math.sqrt(aarea)
    print("%.2f" % aarea)

if __name__ == "__main__":
    T1 = input()
    T2 = input()
    T1 = T1.split()
    T2 = T2.split()

    T1 = [float(elem) for elem in T1]
    T2 = [float(elem) for elem in T2]

    i = 0
    T3 = []
    for i in range(0, 3):
        T3.append(T1[i] + T2[i])
    T3 = [float(elem) for elem in T3]

    area(T1[0], T1[1], T1[2])
    area(T2[0], T2[1], T2[2])
    area(T3[0], T3[1], T3[2])
