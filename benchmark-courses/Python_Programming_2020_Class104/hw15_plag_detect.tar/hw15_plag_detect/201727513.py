class Triangle(object):
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
    def __add__(self, q):
        r = Triangle(self.x + q.x, self.y + q.y, self.z + q.z)
        return r
    def plus(self):
        s = (self.x + self.y + self.z) / 2
        ss = sqrt(s*(s-self.x)*(s-self.y)*(s-self.z))
        return print('%.2f' % ss)

if __name__ == "__main__":
    from math import sqrt
    a1 = input().split()
    b1 = input().split()
    a1 = tuple(map(float, a1))
    b1 = tuple(map(float, b1))
    a = Triangle(a1[0], a1[1], a1[2])
    b = Triangle(b1[0], b1[1], b1[2])
    c = [Triangle(a1[0], a1[1], a1[2]), Triangle(b1[0], b1[1], b1[2])]
    c = c[0] + c[1]
    a.plus()
    b.plus()
    c.plus()
