import math
a = [int(x) for x in input().split()]
b = [int(x) for x in input().split()]
zipped_lists = zip(a,b)
c = [x + y for (x, y) in zipped_lists]

s = sum(a)/2
s1 = sum(b)/2
s2 = sum(c)/2

print(math.sqrt(s(s-a)(s-b)(s-c)))
print(math.sqrt(s1(s1-a)(s1-b)(s1-c)))
print(math.sqrt(s2(s2-a)(s2-b)(s2-c)))
