from math import sqrt

class tri:
    def __init__(self,x,y,z):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)
    def __add__(self,t2):
        return tri(self.x + t2.x, self.y + t2.y, self.z + t2.z)
    def Scal(self):
        s = (self.x + self.y + self.z)/2
        S = sqrt(s*(s-self.x)*(s-self.y)*(s-self.z))
        return S

if __name__=="__main__":
    
    tl1 = input().split(" ")
    tl2 = input().split(" ")

    tri1 = tri(tl1[0],tl1[1],tl1[2])
    tri2 = tri(tl2[0],tl2[1],tl2[2])
    tri3 = tri.__add__(tri1,tri2)

    S1 = tri.Scal(tri1)
    S2 = tri.Scal(tri2)
    S3 = tri.Scal(tri3)

    print("%.2f" %S1)
    print("%.2f" %S2)
    print("%.2f" %S3)