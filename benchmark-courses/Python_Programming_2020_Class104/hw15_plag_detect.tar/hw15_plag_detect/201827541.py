import math

class triangle:

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def __add__(self, t2):
        return triangle(self.x + t2.x, self.y + t2.y, self.z + t2.z)

    def area(self):
        self.s = (self.x + self.y + self.z) / 2
        area = math.sqrt(self.s * (self.s - self.x) * (self.s - self.y) * (self.s - self.z))
        return area

if __name__ == "__main__":
    len1 = list(map(float, input().split()))
    t1 = triangle(len1[0], len1[1], len1[2])

    len2 = list(map(float, input().split()))
    t2 = triangle(len2[0], len2[1], len2[2])

    t3 = t1 + t2

    print(format(t1.area(), ".2f"))
    print(format(t2.area(), ".2f"))
    print(format(t3.area(), ".2f"))
