class triangle:
    s = 0
    S = 0
    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z

    def __sqrt__(self):
        super().__init__(self, self.x, self.y, self.z)
        s = (self.x + self.y + self.z)/2
        import math
        S = math.sqrt(s(s-self.x)(s-self.y)(s-self.z))
    def __repr__(self):
        return f"{({self.x},{self.y},{self.z}):2f}"

if __name__ == "__main__":
    a = [x for x in input().split()]
    b = [x for x in input().split()]
    c = list(a+b)
    for i in range(len(a)):
        a[i] = int(a[i])
    for i in range(len(b)):
        b[i] = int(b[i])
    for i in range(len(c)):
        c[i] = int(c[i])
    triangle(a[0],a[1],a[2])
    triangle(b[0],b[1],b[2])
    triangle(c[0],c[1],c[2])
    psta = a.__repr__()
    print(psta)
    pstb = b.__repr__()
    print(pstb)
    pstc = c.__repr__()
    print(pstc)
