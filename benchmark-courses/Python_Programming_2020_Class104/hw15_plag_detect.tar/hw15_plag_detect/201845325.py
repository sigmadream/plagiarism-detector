import math
class Triangle:
    def __init__(self, a, b, c):
        self.a, self.b, self.c = a, b, c
    def __add__(self, B): return Triangle(self.a+B.a,self.b+B.b, self.c+B.c)
    def __repr__(self):
        s = (self.a + self.b + self.c) / 2
        return f"{math.sqrt(s*(s-self.a)*(s-self.b)*(s-self.c)):0.2f}"


if __name__ == "__main__":
    Asides = [float(_) for _ in input().split()]
    Bsides = [float(_) for _ in input().split()]
    A = Triangle(Asides[0], Asides[1], Asides[2])
    B = Triangle(Bsides[0], Bsides[1], Bsides[2])
    C = A + B

    print(A)
    print(B)
    print(C)

