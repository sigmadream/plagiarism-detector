import math
def HeronA(a,b,c):
    s = (a+b+c)/2
    S = math.sqrt(s*(s-a)*(s-b)*(s-c))
    return(S)

def HeronB(e,f,g):
    s = (e+f+g)/2
    S = math.sqrt(s*(s-e)*(s-f)*(s-g))
    return(S)

def HeronC(i,j,k):
    s = (i+j+k)/2
    S = math.sqrt(s*(s-i)*(s-j)*(s-k))
    return(S)

if __name__ == "__main__": 
    A = list(map(float,input().split()))
    a,b,c = A[0],A[1],A[2]
    B = list(map(float,input().split()))
    e,f,g = B[0],B[1],B[2]
    i,j,k = A[0]+B[0],A[1]+B[1],A[2]+B[2]
    print('%.2f' % HeronA(a,b,c))
    print('%.2f' % HeronB(e,f,g))
    print('%.2f' % HeronC(i,j,k))