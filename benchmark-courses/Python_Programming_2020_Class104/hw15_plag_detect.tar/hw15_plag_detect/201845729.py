import math

class Point(object):
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
        self.s = (self.x + self.y + self.z)/2

    def make_s(self):
        S = math.sqrt(self.s*(self.s-self.x)*(self.s-self.y)*(self.s-self.z))
        return S

def main():
    x1, y1, z1 = map(float, input().split())
    x2, y2, z2 = map(float, input().split())

    p1 = Point(x1, y1, z1)
    p2 = Point(x2, y2, z2)
    p3 = Point(x1+x2, y1+y2, z1+z2)

    S1 = p1.make_s()
    S2 = p2.make_s()
    S3 = p3.make_s()

    print("%.2f" %S1)
    print("%.2f" %S2)
    print("%.2f" %S3)

if __name__ == "__main__":
    main()