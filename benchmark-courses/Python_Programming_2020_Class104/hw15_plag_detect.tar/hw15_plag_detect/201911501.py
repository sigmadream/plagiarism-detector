class triangle :
    def add(self, a, b, c) :
        self.a = a
        self.b = b
        self.c = c
        s = ((a+b+c)/2)**(1.0/2.0)
        return (s(s-a)(s-b)(s-c))**(1.0/2.0)

if __name__ == "__main__" :
    f = input().split()
    s = input().split()
    t = [int(f[0])+int(s[0]), int(f[1])+int(s[1]), int(f[2])+int(s[2])]
    A = triangle(int(f[0]), int(f[1]), int(f[2]))
    B = triangle(int(s[0]), int(s[1]), int(s[2]))
    C = triangle(t[0], t[1], t[3])
    print(A.add())
    print(B.add())
    print(C.add())