from math import sqrt

a = input()
b = input()

aL = a.split()
bL = b.split()

al = [float (i) for i in aL]
bl = [float (i) for i in bL]
cl = [al[i] + bl[i] for i in range(0,3)]

ass = (al[0] + al[1] + al[2]) / 2
bss = (bl[0] + bl[1] + bl[2]) / 2
css = (cl[0] + cl[1] + cl[2]) / 2



area1 = sqrt(ass*(ass - al[0])*(ass - al[1])*(ass - al[2]))
area2 = sqrt(bss*(bss - bl[0])*(bss - bl[1])*(bss - bl[2]))
area3 = sqrt(css*(css - cl[0])*(css - cl[1])*(css - cl[2]))
                                     



class Point:
    def __init__(self, x):
        self.x = x
    def __repr__(self):
        return (f"{self.x:.2f}")

ps = [Point(area1),Point(area2), Point(area3)]
for p in ps:
    print(p)


