def tran(a):
    sum_a = 0
    for i in range(0, len(a)):
        sum_a = sum_a + a[i]

    s = sum_a / 2

    mul_s = 0
    mul_s = s*(s-a[0])*(s-a[1])*(s-a[2])

    import math
    S = math.sqrt(mul_s)
    print(f"{S:.2f}")

A = list(map(float, input().split()))
B = list(map(float, input().split()))
C = [A[0]+B[0], A[1]+B[1], A[2]+B[2]]
tran(A)
tran(B)
tran(C)
