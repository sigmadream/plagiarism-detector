import math

class Point:
    def __init__(self, x, y, z):
        self.x, self.y, self.z=x, y, z
    def __add__(self, q):
        x, y, z=self.x+q.x, self.y+q.y, self.z+q.z
        return Point(x, y, z)
    def area(self):
        s=(self.x+self.y+self.z)/2
        return(math.sqrt(s*(s-self.x)*(s-self.y)*(s-self.z)))
    def __repr__(self):
        return f"({self.x},{self.y},{self.z})"

if __name__=="__main__":
    p1=input()
    p11=p1.split()
    x=float(p11[0])
    y=float(p11[1])
    z=float(p11[2])
    t1=Point(x,y,z)
    p2=input()
    p22=p2.split()
    x=float(p22[0])
    y=float(p22[1])
    z=float(p22[2])
    t2=Point(x,y,z)
    t3=t1+t2
    print("%.2f"%t1.area())
    print("%.2f"%t2.area())
    print("%.2f"%t3.area())

