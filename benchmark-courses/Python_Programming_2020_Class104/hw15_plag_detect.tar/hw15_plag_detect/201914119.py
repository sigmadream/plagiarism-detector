import math

if __name__=="__main__":
    a=input().split()
    a=list(map(int,a))
    s1=(a[0]+a[1]+a[2])/2
    s11=s1-a[0]
    s12=s1-a[1]
    s13=s1-a[2]
    s111=s1*s11*s12*s13
    b=input().split()
    b=list(map(int,b))
    s2=(b[0]+b[1]+b[2])/2
    s21=s2-b[0]
    s22=s2-b[1]
    s23=s2-b[2]
    s211=s2*s21*s22*s23
    c=list(map(lambda x, y : x + y, a, b))
    s3=(c[0]+c[1]+c[2])/2
    s31=s3-c[0]
    s32=s3-c[1]
    s33=s3-c[2]
    s311=s3*s31*s32*s33
    print('%.2f' % math.sqrt(s111))
    print('%.2f' % math.sqrt(s211))
    print('%.2f' % math.sqrt(s311))
