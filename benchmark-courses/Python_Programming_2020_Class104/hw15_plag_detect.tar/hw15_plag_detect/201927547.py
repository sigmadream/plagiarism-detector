#coding : utf-8

from math import sqrt

class Triangle(object):
    def __init__(self, x):
        self.a, self.b, self.c = x[0], x[1], x[2]
        self.s = (self.a + self.b + self.c)/2
        self.area = sqrt(self.s*(self.s-self.a)*(self.s-self.b)*(self.s-self.c))
    def __add__(self, q):
        return [self.a + q.a, self.b + q.b, self.c + q.c]
    def __str__(self):
        return f"{self.area:.2f}"

if __name__ == "__main__":
    trifi = Triangle([float(n) for n in input().split()])
    trisec = Triangle([float(n) for n in input().split()])
    trithi = Triangle(trifi + trisec)
    print(trifi)
    print(trisec)
    print(trithi)
