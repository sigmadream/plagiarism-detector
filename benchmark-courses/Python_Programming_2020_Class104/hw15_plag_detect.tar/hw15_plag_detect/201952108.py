class Triangle:
    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z
    def __add__(self, q):
        return [self.x+q.x, self.y+q.y, self.z + q.z]
    def compute_s(self):
        result = (self.x + self.y + self.z) / 2
        return result
    def area(self, s):
        return math.sqrt(s*(s-self.x)*(s-self.y)*(s-self.z))
    def __repr__(self):
        print(f"{self:.2f}")

def all_tri_s(x):
    s = Triangle.compute_s(x)
    x = Triangle.area(x, s)
    Triangle.__repr__(x)

def is_number(numls):
    ls = []
    for num in numls:
        jud = judge(num)
        if jud is True: #실수
            ls.append(float(num))
        else:
            ls.append(int(num))
    return ls

def judge(num):
    try:
        float(num)
        return True
    except ValueError:
        return False

if __name__ == "__main__":
    import math
    a = input().split()
    b = input().split()

    a = is_number(a)
    b = is_number(b)

    A = Triangle(a[0], a[1], a[2])
    B = Triangle(b[0], b[1], b[2])
    c = A + B
    C = Triangle(c[0], c[1], c[2])

    all_tri_s(A)
    all_tri_s(B)
    all_tri_s(C)
