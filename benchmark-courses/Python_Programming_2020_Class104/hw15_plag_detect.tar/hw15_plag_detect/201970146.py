import math

a = list(map(float, input().split()))
b = list(map(float, input().split()))
c = []
s = 0
        
for i in range(0, len(a)):
    c.append(a[i] + b[i])

for i in range(0, len(a)):
    s = s + a[i]
    if i == len(a) - 1:
        s = s/2
res = s * (s - a[0]) * (s - a[1]) * (s-a[2])
print("%0.2f" % math.sqrt(res))

s = 0

for i in range(0, len(a)):
    s = s + b[i]
    if i == len(a) - 1:
        s = s/2
res = s * (s - b[0])*(s - b[1]) * (s - b[2])
print("%0.2f" % math.sqrt(res))

s = 0

for i in range(0, len(a)):
    s = s + c[i]
    if i == len(a) - 1:
        s = s / 2
res = s * (s - c[0]) * (s - c[1]) * (s - c[2])
print("%0.2f" % math.sqrt(res))
