import math as ma
class Point:
    def __init__(self,x,y,z):
        self.x,self.y,self.z = x,y,z
    def __add__(p, q):
        return Point(p.x + q.x, p.y + q.y,p.z+q.z)
    def cal(p):
        val = (p.x + p.y + p.z) / 2
        val = ma.sqrt(val * (val-p.x) * (val - p.y) * (val - p.z))
        return val

if __name__ == "__main__":
    chk = '.'
    n = input().split()
    m = input().split()
    for i in range(len(n)):
        if '.' in n[i]: n[i] = float(n[i])
        else: n[i] = int(n[i])
    for i in range(len(m)):
        if '.' in m[i]: m[i] = float(m[i])
        else: m[i] = int(m[i])

    ps = [Point(n[0],n[1],n[2]), Point(m[0],m[1],m[2])]
    #print(ps[0],ps[1])
    ps += [ps[0] + ps[1]]
    #print(ps[0],ps[1])
    for i in ps:
        print('%.2f' % i.cal())
