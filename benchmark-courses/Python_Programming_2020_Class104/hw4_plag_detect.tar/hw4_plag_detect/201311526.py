# -*- coding: utf-8 -*-


def sprint(x, y):
    ls = list(x)
    sw = y.split()
    for i in range(1, len(ls)):
        if x[i-1] in list("aeiou"):
            ls.remove(ls[i-1])
            ls.insert(i-1, sw[0])
    return "".join(ls)

'''
remove를 할 때는 안에 있는 문자를 써야하고
중복되는 값이 있을 경우 맨 앞의 값부터 없어짐
그리고 한 번에 한 개씩 사라짐
특수기호는 str이므로 split을 통해 list로 바꿔주고
그 list값을 insert에 넣었음
'''


if __name__ == "__main__":
    x = input()
    y = input()
    z = sprint(x, y)
    print(z)
