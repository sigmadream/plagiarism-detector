def split_str(string_):
    string = string_
    vowels = "aeiou"
    for i in vowels:
        string = string.split(i)
        string = " ".join(string)
    return list(string) 

def add_str(string,char):
    result = ""
    for element in string:
        if element == " ":
            result += char
        else:
            result += element
    return result

if __name__ == "__main__":
    string = str(input(""))
    char = str(input(""))

    split_s = split_str(string)
    add_s_c = add_str(split_s,char)

    print(add_s_c)
