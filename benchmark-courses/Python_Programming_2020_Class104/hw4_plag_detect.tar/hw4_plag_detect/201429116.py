def masking():
    mask= input()
    emo = input()
    list = "aeiou"
    sum = ""
    for n in mask:
        if(n in list):
            n = emo
        sum = sum + n
    print(sum)
        
masking()
