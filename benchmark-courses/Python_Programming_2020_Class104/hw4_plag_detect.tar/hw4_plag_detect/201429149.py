#coding : utf-8

def reverse_str(s , t):
    ls = list(s)
    i = len(s)
    for A in range(i):
        if ls[A] in 'aeiou':
            ls[A] = t

    return "".join(ls)
                               

word = str(input())
word2 = str(input())
revword = reverse_str(word,word2)
print(revword)
