#coding: utf-8

def masking(s, sym):
    ls = list(s)
    for i in range(0, len(ls)-1):
        c = ls[i]
        if c in list("aeiou"):
            ls[i] = sym
    return "".join(ls)

if __name__ == "__main__":
    s = input()
    sym = input()
    print(masking(s, sym))
