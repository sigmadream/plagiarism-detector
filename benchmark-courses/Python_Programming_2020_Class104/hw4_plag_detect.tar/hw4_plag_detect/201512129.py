# -*- coding: utf-8 -*-

def change(str , delimeter) :
    vowel_list = ['a' , 'e', 'i', 'o', 'u']
    ls = list(str)
    for i in ls[:] :
        for j in vowel_list :
            if (i == j) :
                i = delimeter
        print(i, end="")

        
if __name__ == "__main__" :
    word = input()
    char = input()
    change(word, char)
