def maskedWord (word, masking) :
    wordList = list(word)
    for i in range(len(wordList)) :
        if wordList[i] in ['a', 'e', 'i', 'o', 'u'] :
            wordList[i] = masking
    return "".join(wordList)

if __name__ == "__main__" :
    word = str(input())
    masking = str(input())
    print(maskedWord(word, masking))