#coidng: utf-8

def mask(s, c):
    ls = list(s)
    for i in range(0, len(s)):
        if ls[i] == 'a' or ls[i] == 'e' or ls[i] == 'i' or ls[i] == 'o' or ls[i] == 'u':
            ls[i] = c
    return ls
        

if __name__ == "__main__":
    s = input()
    c = input()
    result = mask(s, c)
    
    for i in range(0, len(result)):
        print(result[i], end="")
