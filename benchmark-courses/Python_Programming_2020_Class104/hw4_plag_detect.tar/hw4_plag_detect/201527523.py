# coding: utf-8

def maskprint(s,mask) :
    vowels = "aeiou"
    vlist = list(vowels)
    slist = list(s)
    n = 0
    for i in slist[:] :
        if slist[n] in vlist[:] :
            slist[n] = mask
            n= n+1 
            continue
        n=n+1
        continue

    return("".join(slist))

if __name__ == "__main__" :
    words = input()
    mask = input()
    result = maskprint(words,mask)
    print(result)
