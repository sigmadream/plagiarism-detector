# -*- coding: utf-8 -*-

def masking(word, mark):
    target = ['a', 'e', 'i', 'o', 'u']
    ls = list(word)
    lm = list(mark)
    for i in range(len(word)):
        for j in range(len(target)):
            if ls[i] == target[j]:
                ls[i] = lm[0]
    return "".join(ls)
if __name__ == "__main__":
    myword = str(input())
    mymark = str(input())
    print(masking(myword, mymark))
