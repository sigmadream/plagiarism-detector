# -*- coding: utf-8 -*-

def splitlist(string):
	List = []
	
	for i in range(len(string)):
		List.append(string[i])
		
	return List

if __name__ == "__main__":
	input_string = input()
	character = input()
	vowels = "aeiou"
	
	input_list = splitlist(input_string)
	
	for i in range(len(input_string)):
		if input_list[i] in vowels:
			input_list[i] = character
		print(input_list[i],end="")
