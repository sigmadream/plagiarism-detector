def ch_vow(myword) :    
    for i in range(5) :
        for n in range(len(myword)):
            if myword[n] == vow[i]:
                myword[n] = ch
    return print("".join(myword))

if __name__ == "__main__":   
     myword = list(input())
     ch = input()
     vow = list("aeiou")
     ch_vow(myword)

