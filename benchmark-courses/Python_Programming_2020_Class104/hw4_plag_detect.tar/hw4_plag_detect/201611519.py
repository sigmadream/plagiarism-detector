def masking(myword):
    for i in range(5):
        for n in range(len(myword)):
            if myword[n] == vowels[i]:
                myword[n] = st
    return print("".join(myword))

if __name__ == "__main__":
    myword = list(input())
    st = input()
    vowels = list("aeiou")
    masking(myword)
