#coidng: utf-8

def mask_str(s, t):
    for i in s:
        if i in "aeiou":
            s = s.replace(i, t)
    return s
if __name__ == "__main__":
    ls = input()
    sign = input()
    ls = mask_str(ls, sign)
    print(ls)
