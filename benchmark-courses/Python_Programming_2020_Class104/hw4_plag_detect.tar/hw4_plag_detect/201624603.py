def v_print(w,s):
    if (w.islower() and len(w)>0):
        vowels=list("aeiou") 
        ls=list(w)        
        for i in ls:        
            if i in vowels:     
                num=ls.index(i)    
                ls[num]=s
        return "".join(ls)
    else:
        print("소문자 알파벳만 입력하세요")

if __name__=="__main__":
    word=input("word 입력: ")
    symbol=input("symbol 입력: ")
    result=v_print(word,symbol)
    print(result)
