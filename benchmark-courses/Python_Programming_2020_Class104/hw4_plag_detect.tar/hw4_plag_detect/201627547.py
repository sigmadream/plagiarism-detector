#coding utf-8


def masking(word,sign):
    vowels = ['a','e','i','o','u']
    new_word = ""

    for char in list(word):
        if char in vowels:
            new_word = new_word + sign
        else:
            new_word = new_word + char

    return print(new_word)




if "__main__" == __name__:

    w = input()
    s = input()

    masking(w,s)        

    
    
    
        



