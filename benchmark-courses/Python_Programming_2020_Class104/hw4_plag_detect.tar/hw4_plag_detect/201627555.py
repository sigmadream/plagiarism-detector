def masking(t, m):
    ans= list()
    for i in t:
        if(i=='a') or (i=='e') or (i=='i') or (i=='o') or (i=='u'):
            ans.append(m)
        else:
            ans.append(i)
    return "".join(ans)
if __name__ == '__main__':
    text = list(input())
    mask = input()
    print(masking(text, mask))
