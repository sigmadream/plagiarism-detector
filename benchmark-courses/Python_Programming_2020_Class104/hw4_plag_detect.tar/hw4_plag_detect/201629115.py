def filter_vowels(input_str, mask_str):
    for vowel in ['a', 'e', 'i', 'o', 'u']:
        if vowel in input_str:
            input_str = input_str.replace(vowel, mask_str)
    return input_str


if __name__ == "__main__":
    user_string = input()
    mask_string = input()
    print(filter_vowels(user_string, mask_string))
