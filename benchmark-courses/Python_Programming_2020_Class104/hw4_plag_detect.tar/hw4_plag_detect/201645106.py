def replace(ls):
    if(len(ls)>0) :
        for i in ls:
            if 'a' in i:
                print(i.replace('a',E),end='')
            elif 'e'in i:
                print(i.replace('e',E),end='')
            elif 'i'in i:
                print(i.replace('i',E),end='')
            elif 'o'in i:
                print(i.replace('o',E),end='')
            elif 'u'in i:
                print(i.replace('u',E),end='')
            else:
                print(i,end='')

if __name__=='__main__':
    s=input()
    ls=list(s)
    E = input()
    replace(ls)
