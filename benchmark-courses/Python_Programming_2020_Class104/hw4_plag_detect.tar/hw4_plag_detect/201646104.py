# -*- coding: utf-8 -*-


def transformation(word):
    division = list(word)
    vowels = ['a', 'e', 'i', 'o', 'u']
    num = len(division)
    for i in range(num):
        if division[i] in vowels:
            division[i] = symbols
    return print("".join(division))

if __name__ == "__main__":
    word = input()
    symbols = input()
    transformation(word)
 
