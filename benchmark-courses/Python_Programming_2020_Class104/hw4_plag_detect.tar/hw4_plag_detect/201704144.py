# coding: utf-8
def masking_vowel(word,char):
    ls = list(word)
    vowel = ['a','e','i','o','u']
    count = 0
    for i in ls:
        if i in vowel:
            ls[count] = char
        count += 1
    return "".join(ls)

if "__main__" == __name__:
    myword = input()
    mychar = input()
    print(masking_vowel(myword,mychar))
