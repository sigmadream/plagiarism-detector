# -*- coding: utf-8 -*-

def mask(w,s):
    lw = list(w)

    for n in range(len(lw)):
        if lw[n] == 'a':
            lw[n] = s
        elif lw[n] == 'e':
            lw[n] = s
        elif lw[n] == 'i':
            lw[n] = s
        elif lw[n] == 'o':
            lw[n] = s
        elif lw[n] == 'u':
            lw[n] = s

    return lw

if __name__ == "__main__":
    word = input()
    sym = input()
    mword = mask(word, sym)

    for n in range(len(mword)):
        print(mword[n],end="")
