def vowel_finder(word, ch):
	vowel = "aeiou"
	vowel = list(vowel)
	for i in vowel:
		word = word.replace(i,ch)
	return word

if __name__ == "__main__":
	word = input()
	ch = input()
	word = vowel_finder(word, ch)
	print(word)