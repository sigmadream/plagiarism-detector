#coding:utf-8



def mprint(s,m):
    for i in range(0, len(s)-1):
        if(s[i]=='a'): s=s[:i]+m+s[i+1:]
        if(s[i]=='e'): s=s[:i]+m+s[i+1:]
        if(s[i]=='i'): s=s[:i]+m+s[i+1:]
        if(s[i]=='o'): s=s[:i]+m+s[i+1:]
        if(s[i]=='u'): s=s[:i]+m+s[i+1:]
    print(s)

if __name__=="__main__":
    s=input()
    mask=input()
    mprint(s,mask)   



    
