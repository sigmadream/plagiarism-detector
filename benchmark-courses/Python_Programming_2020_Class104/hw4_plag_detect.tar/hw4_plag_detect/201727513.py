#coding: utf-8

def replace_list(s):
    ls = list(line)
    for word in ls:
        if word in list("aeiou"):
            print(x, end='')
        else:
            print(word, end='')
    

if __name__ == "__main__":
    line = input()
    x = input()

    replace_list(line)




    
