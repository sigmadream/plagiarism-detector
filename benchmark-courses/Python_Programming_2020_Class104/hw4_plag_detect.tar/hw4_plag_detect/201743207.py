def masking(word,character,vowel):
        vowels=('a','e','i','o','u')
        word2 = ""
        for letter in word:
                word2.replace(vowels,character)
    
if __name__=="__main__":
        word = str()
        character = input()
        masking(word,character,vowel)
