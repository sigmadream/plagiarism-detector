def masking(s,c):
    ls = list(s)
    lenls = len(list(ls))
    for n in range(lenls):
        tf = ls[n-1] in list("aeiou")
        if tf == True:
            ls[n-1] = c
    return "".join(ls)
        
        

if __name__ == "__main__":
    myword = input()
    mychar = input()
    m = masking(myword,mychar)
    print(m)

