# -*- coding: utf-8 -*

def masking(str1, sym):
    ls = list(str1)
    vowels = ["a","e","i","o","u"]
    masked = list()
    for i in ls:
        if i in vowels:
            masked.append(sym)
        else:
            masked.append(i)
    maskedword = "".join(masked)
    return maskedword
        

if __name__ == "__main__":
    str1 = input()
    sym = input()
    maskedword = masking(str1,sym)
    print(maskedword)
