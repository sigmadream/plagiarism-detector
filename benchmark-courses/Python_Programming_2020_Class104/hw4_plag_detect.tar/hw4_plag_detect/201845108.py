if __name__=="__main__":
    a=[x for x in input()]
    replace = input()
    for i in range(len(a)):
        if a[i]=='a' or a[i]=='e' or a[i]=='i' or a[i]=='o' or a[i]=='u':
            a[i]= replace
    print("".join(a))


