def rprint(myword) :
    for i in range(5):
        for n in range(len(myword)):
            if myword[n]==mar[i]:
                myword[n]=s
    return print("".join(myword))

if __name__ == "__main__":
    myword=list(input())
    s=input()
    mar=list("aeiou")
    rprint(myword)
