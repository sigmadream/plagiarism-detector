#coding: utf-8

def replace_vowel(word,symbol):
    vowels = 'aeiou'
    newword = []
    for char in word:
        if char.lower() in vowels:
            word = word.replace(char, symbol)
    newword.append(word)
    return ('[]'.join(newword))

if "__main__" == __name__:
    word = input()
    symbol = input()
    print(replace_vowel(word,symbol))
