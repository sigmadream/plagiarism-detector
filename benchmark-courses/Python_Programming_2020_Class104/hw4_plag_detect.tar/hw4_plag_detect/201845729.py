def change(s,r):
    ls=list(s)
    afterls=[]
    vowel=['a','e','i','o','u']

    for word in ls:

        for v in vowel:
            if (word==v):
                word=word.replace(v,r)

        afterls.append(word)      
    print("".join(afterls))


if __name__ == "__main__":
    words=input()
    rchar=input()
    change(words, rchar)