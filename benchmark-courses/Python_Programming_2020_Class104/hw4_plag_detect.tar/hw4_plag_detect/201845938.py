# coding: utf-8

def masking_vowel(s, mc):
    vowels = ['a', 'e', 'i', 'o', 'u']
    ls = list(s)
    index = 0
    for c in ls:
        if (c in vowels):
            ls[index] = mc
        index += 1
    return ''.join(ls)

if __name__ == "__main__":
    line = input()
    maskchar = input()
    print(masking_vowel(line, maskchar))