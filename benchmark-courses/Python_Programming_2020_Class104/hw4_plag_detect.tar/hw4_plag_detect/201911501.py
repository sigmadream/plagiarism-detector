# coding : utf-8

v=["a", "e", "i", "o", "u"]
def vowels_str(s, t):
    ns = list(s)
    for i in v:
        for k in range (len(ns)):
            if ns[k] == i :
                ns[k]=t
    return "".join(ns)

if "__main__"==__name__:
    myword = input()
    symbol = input()
    new_myword=vowels_str(myword, symbol)
    print(new_myword)

            

