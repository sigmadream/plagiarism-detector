

def masking(lr,b):
  if __name__ == "__main__":
        ls=list(lr)
        ln=len(ls)
        for i in range(0,ln):
            if ls[i] =='a' or ls[i]=='e' or ls[i]=='o' or ls[i]=='i' or ls[i]=='u' :
                ls[i]= b
        print("".join(ls))
            
                
            
          
    
n=input()
m=input()

masking(n,m)
