# -*- coding: utf-8 -*-

vowels = ('aeiou')

def masking(word, letter):
    nword = ''
    for k in word:
        if k in vowels:
            nword = nword + letter
        else:
            nword = nword + k
    return nword


if __name__ == "__main__": 
    word = str(input())
    letter = str(input())
    print(masking(word, letter))
