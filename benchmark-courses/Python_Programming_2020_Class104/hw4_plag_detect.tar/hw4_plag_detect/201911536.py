#-*-coding:utf-8 -*-
def mask(k1,k2):
    list1=list(k1)
    vowel=['a','e','i','o','u']
    for i in range(0,len(k1)):
        if list1[i] in vowel:
            list1[i]=k2
    return"".join(list1)

    
if "__main__" == __name__:
    k1=input()
    k2=input()
    print(mask(k1,k2))



