# -*- coding: utf-8 -*-

def isvowel(char):
    vowel = 'aeiou'
    for n in vowel:
        if (char == n):
            return True
        
def masking(s, mask):
    s = list(s)
    i = 0
    for n in s:
        if (isvowel(n)):
            s[i] = mask
        i += 1
    s = "".join(s)
    return s
  
if __name__ == "__main__":
    s = input()
    mask = input()
    print(masking(s, mask))
    
    
