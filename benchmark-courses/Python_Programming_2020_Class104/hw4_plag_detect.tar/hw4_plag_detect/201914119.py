def change(w):
    ls=list(word)
    i=0
    for a in ls :
        if ls[i]=='a':
            ls[i]=cha
            i+=1
        elif ls[i]=='e':
            ls[i]=cha
            i+=1
        elif ls[i]=='i':
            ls[i]=cha
            i+=1
        elif ls[i]=='o':
            ls[i]=cha
            i+=1
        elif ls[i]=='u':
            ls[i]=cha
            i+=1
        else :
            i+=1  
    return"".join(ls)

if __name__=="__main__":
    word=input()
    cha=input()
    print(change(word))
