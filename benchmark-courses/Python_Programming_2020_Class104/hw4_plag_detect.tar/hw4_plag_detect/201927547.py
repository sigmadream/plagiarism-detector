#coding : utf-8

iword = input()
mschar = input()
word = list(iword)
vowels = ['a', 'e', 'i', 'o', 'u']

def count(word) :
    index = -1
    for i in word :
        index = index + 1
    return index

def change(word, index):
    for i in range(0, index) :
        if word[i] in vowels :
            word[i] = mschar
        i = i + 1

def mix(word) :
    return "".join(word)

if __name__ == "__main__" :
    index = count(word)
    change(word, index)
    result = mix(word)
    print(result)

