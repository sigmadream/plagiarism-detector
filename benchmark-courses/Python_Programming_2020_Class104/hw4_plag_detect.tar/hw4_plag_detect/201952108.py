def masking(words,mkchar):
    lswords = list(words)
    vowel = list("aeiou")
    for i in range(0,len(lswords)):
        if lswords[i] in vowel:
            lswords[i] = mkchar
    return "".join(lswords)


if "__main__" == __name__:
    myword = input()
    mkchar = input()
    print(masking(myword,mkchar))
