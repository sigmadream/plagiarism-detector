# -*- coding: utf-8 -*-

def rprint():
    list(m)
    ls=list(m)
    for i in range(len(ls)):
        if ls[i]=='a' or ls[i]=='e' or ls[i]=='i' or ls[i]=='o' or ls[i]=='u':
            ls[i]=n
    print(''.join(ls))
    return ls

if __name__ == "__main__":
    m=input()
    n=input()
    rprint()
