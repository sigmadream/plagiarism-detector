def round_up(x, places):
    """
    Rounds a number up to a specified number of decimal places.

    Parameters:
    x (float): The number to be rounded.
    places (int): The number of decimal places to round to.

    Returns:
    float: The rounded number.
    """
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def frequency_ratio(given_string):
    """
    Calculates the frequency ratio of the most frequent alphabet character 
    in the input string and prints it rounded to one decimal place.

    Parameters:
    given_string (str): The input string from which to calculate character frequencies.

    Returns:
    None: This function prints the result directly.
    """
    frequency = [0] * 26  # Array to hold frequency of each letter (a-z)
    total_alphabets = 0    # Total count of alphabet characters
    maxv = 0               # Maximum frequency of any character

    for char in given_string:
        if char.isalpha():  # Check if the character is an alphabet
            char = char.lower()  # Convert to lowercase
            ordr = ord(char) - 97  # Calculate index (0 for 'a', 1 for 'b', ..., 25 for 'z')
            frequency[ordr] += 1  # Increment the frequency count for this character
            maxv = max(maxv, frequency[ordr]) # Update max frequency if needed
            total_alphabets += 1  # Increment total alphabet count

    if total_alphabets == 0:
        print("No alphabet characters in the input string.")
        return

    # Print the frequency ratio rounded to one decimal place
    print(f"{round_up(maxv / total_alphabets, 1):.1f}")

# Example usage
input_string = input()
frequency_ratio(input_string)
