def roundup(num, digits=1):
    """
    Round a number to the nearest value with specified decimal places using conventional round-up.
    
    Args:
        num (float): The number to round.
        digits (int): Number of decimal places to round to. Defaults to 1.
    
    Returns:
        float: Rounded number.
    """
    multiplier = 10 ** digits
    return int(num * multiplier + 0.5) / multiplier

def is_alpha(ch):
    """
    Check if a character is an alphabet letter (A-Z or a-z).
    
    Args:
        ch (str): A single character.
    
    Returns:
        bool: True if the character is an alphabet, False otherwise.
    """
    return 'a' <= ch <= 'z' or 'A' <= ch <= 'Z'

def count_alphabets(s):
    """
    Count the frequency of each alphabet character in the string.
    
    Args:
        s (str): Input string.
    
    Returns:
        tuple: A dictionary of character frequencies and total alphabet count.
    """
    char_counts = {}
    total_chars = 0
    for ch in s:
        if is_alpha(ch):
            ch = ch.lower()
            char_counts[ch] = char_counts.get(ch, 0) + 1
            total_chars += 1
    return char_counts, total_chars


if __name__ == "__main__":
    input_str = input()
    char_counts, total_chars = count_alphabets(input_str)
    if total_chars == 0:
        print("0.0")
    else:
        max_freq = max(char_counts.values())
        ratio = max_freq / total_chars
        print(roundup(ratio, 1))
