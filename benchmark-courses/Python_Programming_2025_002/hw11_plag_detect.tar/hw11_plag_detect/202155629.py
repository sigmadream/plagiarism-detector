def round_up(x, places=1):
    "Conventional rounding-up function"
    # multiplying x by 10^places -> to shift decimal point
    multiplier = 10 ** places
    # adding 0.5 -> to round up
    # converting to int -> to truncate decimal part
    # dividing by 10^places -> to shift decimal point back
    return int(x * multiplier + 0.5) / multiplier


def freq_calcular(letters):
    "Function to calculate the frequency of letters"
    # creating an empty dictionary to store character frequencies
    freq = {}
    # iterating through each letter in the string
    for char in letters:
        # counting the frequency of each character
        if char in freq:
            # if char is already in the dict -> increment its count
            freq[char] += 1
        else:
            freq[char] = 1
    # finding the maximum frequency
    max_freq = -1
    # iterating through all the dictionary keys
    for _, value in freq.items():
        # finding the maximum frequency
        max_freq = max(max_freq, value)
    return max_freq


def main():
    "Main function for reading input & calculating the ratio"
    # wating for the user's input
    input_string = input()
    # creating an empty list to store all the string's letters
    letters = []
    # iterating through each character in the string
    for char in input_string:
        # if char is an alphabetic character -> converting it to lowercase
        if char.isalpha():
            # and adding it to the list of letters
            letters.append(char.lower())
    # calculating the number of occurences of all alphabets in string
    number_of_letters = len(letters)
    # if there are no letters in the string -> print 0.0
    if number_of_letters == 0:
        print("0.0")
        return
    # computing the most highest frequency character
    max_freq = freq_calcular(letters)
    # calculating the frequency ratio of the most frequent character
    ratio = max_freq / number_of_letters
    # rounding up the ratio to one place after the decimal point
    rounded_ratio = round_up(ratio)
    # printing the final result
    print(f"{rounded_ratio:.1f}")

if __name__ == "__main__":
    main()
