def round_up(x, places=1):
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def main():
    s = input()

    freq = {}
    total = 0

    for ch in s:
        if ch.isalpha():
            ch = ch.upper()
            freq[ch] = freq.get(ch, 0) + 1
            total += 1

    max_freq = max(freq.values())
    ratio = max_freq / total if total != 0 else 0

    print(f"{round_up(ratio, 1):.1f}")

if __name__ == "__main__":
    main()
