def round_up(x, places=1):
    """conventional한 반올림 방법"""
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def cal_ratio():
    """사용자에게 문자열을 입력받고, 최빈 알파벳 / 알파벳의 비율을 출력하는 함수"""
    line = input().lower()
    count_aph =0
    count_best = -1
    for i in line:
        if'a' <= i <= 'z':
            count_aph +=1
        else:
            continue

        tmp =0
        for k in range(len(line)):
            if i == line[k]:
                tmp += 1

        count_best = max(count_best, tmp)

    print(round_up(count_best/count_aph))

if __name__ == "__main__":
    cal_ratio()
