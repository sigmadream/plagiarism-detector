def round_up(x, places=1):
    """Round up the number x to the given decimal places."""
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def count_letters(text):
    """Count alphabet letters in the text(case-insensitive)."""
    frequency = {}
    total = 0
    for ch in text:
        if ('A' <= ch <= 'Z') or ('a' <= ch <= 'z'):
            ch = ch.lower()
            if ch in frequency:
                frequency[ch] += 1
            else:
                frequency[ch] = 1
            total += 1
    return frequency, total

def find_max_ratio(frequency, total):
    """Find and return the rounded ratio of the most frequent letter."""
    max_count = 0
    for key in frequency:
        if frequency[key] > max_count:
            max_count = frequency[key]
    ratio = max_count / total
    return round_up(ratio)

def main():
    """Read input and print the frequency ratio of the most common letter."""
    s = input()
    freq, total = count_letters(s)
    print(find_max_ratio(freq, total))

if __name__ == "__main__":
    main()
