def round_up(x):
    return int(x * 10 + 0.5) / 10


def calculate_frequency_ratio(input_string):
    filtered_string = [char.upper() for char in input_string if char.isalpha()]

    frequency = {}
    for char in filtered_string:
        frequency[char] = frequency.get(char, 0) + 1

    max_frequency = max(frequency.values())

    most_frequent_count = sum(1 for count in frequency.values() if count == max_frequency)

    total_characters = len(filtered_string)

    ratio = round_up(max_frequency / total_characters)
    print(ratio)


def main():
    input_string = input()
    calculate_frequency_ratio(input_string)


if __name__ == "__main__":
    main()
