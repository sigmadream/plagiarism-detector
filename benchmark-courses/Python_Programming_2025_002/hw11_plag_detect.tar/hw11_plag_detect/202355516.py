def round_up(x, places=0):
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier


def main():
    import sys

    s = sys.stdin.readline().strip()

    filtered = [ch.upper() for ch in s if ch.isalpha()]

    if not filtered:
        print("0.0")
        return

    freq = {}
    for ch in filtered:
        freq[ch] = freq.get(ch, 0) + 1

    max_freq = max(freq.values())
    total_alpha = len(filtered)

    ratio = max_freq / total_alpha
    result = round_up(ratio, 1)

    print(f"{result:.1f}")


if __name__ == "__main__":
    main()
