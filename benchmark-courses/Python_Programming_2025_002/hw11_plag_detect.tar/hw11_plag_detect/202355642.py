def round_half_up(num, d=1):
    m = 10 ** d
    return int(num * m + 0.5) / m

s = input()
chars = [c.lower() for c in s if c.isalpha()]
n = len(chars)
if n == 0:
    print("0.0")
else:
    freq = {}
    for c in chars:
        freq[c] = freq.get(c, 0) + 1
    r = max(freq.values()) / n
    print(round_half_up(r, 1))
