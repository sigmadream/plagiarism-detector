def round_up(x, places):
    """Function printing python version."""
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def frequency(word):
    """Function printing python version."""
    freq = {}
    word = word.upper()
    for char in word:
        if char.isalpha():
            if char not in freq:
                freq[char] = 1
            else:
                freq[char] += 1

    max_freq = max(freq.values(), default=0)
    return max_freq

def counter(word):
    """Function printing python version."""
    b = 0
    for i in range(len(word)):
        if word[i].isalpha():
            b += 1
    return b

def main():
    """Function printing python version."""
    words = input()
    freq = frequency(words)
    count = counter(words)
    ans = freq / count
    ans = round_up(ans, 1)
    print(f"{ans:.1f}")

if __name__ == "__main__":
    main()
