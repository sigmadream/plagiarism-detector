Line = input().lower()
cnt = []
LENGTH = 0

for i in Line:
    if i.isalpha():
        cnt.append(Line.count(i))
    else:
        cnt.append(-1)

for i in cnt:
    if i != -1:
        LENGTH += 1

ans = max(cnt) / LENGTH

if ans % 1 >= 0.25:
    ans = round(ans + 0.05, 1)
else:
    ans = round(ans, 1)

print(ans)
