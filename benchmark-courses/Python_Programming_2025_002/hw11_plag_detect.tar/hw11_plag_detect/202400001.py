def round_up(x, places=1):
    """Round a number to a specified number of decimal places."""
    multiplier = 10**places
    return int(x * multiplier + 0.5) / multiplier


def compute_frequency_ratio(s):
    """Compute the frequency ratio of the most common letter in a string."""
    letters = [c for c in s if c.isalpha()]
    total_letters = len(letters)

    if total_letters == 0:
        return 0.0

    freq = {}
    for c in letters:
        c_upper = c.upper()
        freq[c_upper] = freq.get(c_upper, 0) + 1

    max_freq = max(freq.values())

    ratio = max_freq / total_letters
    return ratio


def main():
    s = input()
    result = compute_frequency_ratio(s)
    print(f"{result:.1f}")


if __name__ == "__main__":
    main()
