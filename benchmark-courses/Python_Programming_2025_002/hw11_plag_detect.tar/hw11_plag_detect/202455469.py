import sys

def round_up(number, digits=1):
    """Rounds up a number to the given number of decimal places."""
    factor = 10 ** digits
    return int(number * factor + 0.5) / factor

def main():
    """Main Function."""
    # Read input
    s = sys.stdin.read().strip()

    # Filter only alphabet characters and convert to lowercase
    filtered = [ch.lower() for ch in s if ch.isalpha()]
    if not filtered:
        print("0.0")  # If no alphabetic characters
        return

    # Count frequency of each character
    freq = {}
    for ch in filtered:
        freq[ch] = freq.get(ch, 0) + 1

    # Get the highest frequency
    max_freq = max(freq.values())

    # Total number of alphabet characters
    total = len(filtered)

    # Compute frequency ratio
    ratio = max_freq / total

    # Print rounded-up ratio to 1 decimal place
    print(f"{round_up(ratio):.1f}")

if __name__ == "__main__":
    main()
