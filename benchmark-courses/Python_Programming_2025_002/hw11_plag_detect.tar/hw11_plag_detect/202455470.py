def frequency(s):
    """
    Calculate the frequency of each letter in the string s.
    Ignores non-alphabetic characters and treats letters case-insensitively.
    Returns a dictionary with letters as keys and their frequencies as values.
    """
    freq = {}
    for char in s:
        if char.isalpha():
            char = char.lower()
            freq[char] = freq.get(char, 0) + 1
    return freq

def conventional_rounding(x, places=1):
    """
    Round a number x to a specified number of decimal places using conventional rounding.
    If the digit after the specified decimal place is 5 or more, round up.
    Otherwise, round down.
    """
    factor = 10 ** places
    return int(x * factor + 0.5) / factor

def frequency_ratio():
    """
    Calculate the frequency ratio of the most common letter
    """
    s = input("")
    freq = frequency(s)
    total_chars = sum(freq.values())
    if total_chars == 0:
        print("0.0")
        return
    max_freq = max(freq.values())
    ratio = max_freq / total_chars
    rounded_ratio = conventional_rounding(ratio)
    print(f"{rounded_ratio:.1f}")

def main():
    """the main function"""
    frequency_ratio()

if __name__ == "__main__":
    main()
