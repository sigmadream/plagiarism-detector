def round_up(x, places=1):
    '''Function to round'''
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def _compare():
    '''Function to find the ratio'''
    text = input()
    text = text.lower()
    freq = {}
    total_letters = 0

    for char in text:
        if 'a' <= char <= 'z':
            total_letters += 1
            if char in freq:
                freq[char] += 1
            else:
                freq[char] = 1

    max_freq = 0
    for value in freq.values():
        if value > max_freq:
            max_freq =value

    ratio = max_freq / total_letters

    ratio_rounded = round_up(ratio, 1)
    print("%.1f" % ratio_rounded)

if __name__ == "__main__":
    _compare()
    