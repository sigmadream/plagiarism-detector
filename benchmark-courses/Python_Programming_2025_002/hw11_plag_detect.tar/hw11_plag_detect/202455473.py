def roundup(n, digits=1):
    """Round a float to the given number of decimal places using conventional rounding."""
    mult = 10 ** digits
    if n * mult - int(n * mult) >= 0.5:
        return (int(n * mult) + 1) / mult
    return int(n * mult) / mult

def main():
    """Reads a string and prints the frequency ratio of the most frequent character(s)."""
    s = input()
    freq = {}
    total = 0

    for ch in s:
        if ch.isalpha():
            ch = ch.upper()
            total += 1
            if ch not in freq:
                freq[ch] = 1
            else:
                freq[ch] += 1

    max_freq = 0
    for value in freq.values():
        if value > max_freq:
            max_freq = value

    ratio = roundup(max_freq / total)
    print(f'{ratio:.1f}')

main()
