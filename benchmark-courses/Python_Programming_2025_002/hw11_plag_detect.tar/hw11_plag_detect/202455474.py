INPUT = input().lower()

def round_up(x, places=1):
    '''This function rounds up the number to the specified number of decimal places'''
    multiplier = 10 ** places
    shifted_value = x * multiplier
    rounded_value = (shifted_value + 0.5) // 1
    return rounded_value / multiplier

d = {}
for i in INPUT:
    if i.isalpha():
        d[i] = d.get(i,0) + 1

maxx = max(d.values())
total = sum(d.values())

print(round_up(maxx/total))
