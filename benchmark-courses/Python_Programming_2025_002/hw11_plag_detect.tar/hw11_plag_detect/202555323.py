def round_up(value, places):
    multiplier = 10 ** places
    return int(value * multiplier + 0.5) / multiplier

def main():
    line = input()
    ustr = line.upper()

    count = {}
    total_alpha = 0

    for c in ustr:
        if c.isalpha():
            total_alpha += 1
            count[c] = count.get(c, 0) + 1

    if total_alpha == 0:
        print("0.0") 
        return

    maxcnt = max(count.values())
    ratio = maxcnt / total_alpha
    rounded_ratio = round_up(ratio, 1)

    print(f"{rounded_ratio:.1f}")

if __name__ == "__main__":
    main()
