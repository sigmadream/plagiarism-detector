def round_up(x, places=1):
    """숫자 'places' 자리에서 반올림 (기본값: 첫째 자리)"""
    return int(x * (10 ** places) + 0.5) / (10 ** places)
a = input().lower()
count = [0] * 26
TOTAL = 0
for b in a:
    if 'a' <= b <= 'z':
        c = ord(b) - ord('a')
        count[c] += 1
        TOTAL += 1
if TOTAL == 0:
    print("0.0")
else:
    MAX_COUNT = 0
    for i in range(26):
        if count[i] > MAX_COUNT:
            MAX_COUNT = count[i]
    r = MAX_COUNT / TOTAL
    print(f"{round_up(r,1)}")
