def round_up(x, places = 1):
    """A function to round the numbers in the normal scheme"""
    mutliplier = 10 ** places
    return int(x * mutliplier + 0.5) /  mutliplier

s = input().upper()
s1 = s.split()
LENGTH = 0

for e in s1:
    for c in e:
        if not c.isalpha():
            continue
        LENGTH += 1

counter = {}

for c in s:
    if not c.isalpha():
        continue
    if c in counter.keys():
        counter[c] += 1
    else:
        counter[c] = 1

max1 = max(counter.values())


print(round_up(max1 / LENGTH))
