def round_up(x, places):
    multiplier = 10**places
    return int(x * multiplier + 0.5) / multiplier

text = input("Enter the Statements.")
text = text.lower()
letter_frq = {}
total_letter = 0

for character in text:
    if 'a' <= character <= 'z':
        total_letter += 1
        if character in letter_frq:
            letter_frq[character] += 1
        else:
            letter_frq[character] = 1

max_frq = max(letter_frq.values()) if letter_frq else 0

if total_letter == 0:
    print("0.0")  
else:
    ratio = max_frq / total_letter
    rounded_ratio = round_up(ratio, 1)
    print(rounded_ratio)