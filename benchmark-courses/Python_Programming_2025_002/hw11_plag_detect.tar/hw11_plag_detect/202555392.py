"""
Additional requirements for bonus points
1. Use only the facilities of Python introduced up to now.
2. You must implement the conventional round-up scheme as a function with a default
argument as specified in the problem description.
3. Check the quality of your code to make it have fewer than two quality issues.
"""
input_string = input().lower()
only_alphabet = []
for i in input_string:
    if i.isalpha():
        only_alphabet.append(i)
# only_alphabet = [i for i in input_string if i.isalpha()]
MOST = 0

for char in only_alphabet:
    MOST = max(MOST, input_string.count(char))

result = int(((MOST / len(only_alphabet)) * 10) + 0.5) / 10
print(f"{result:.1f}")
