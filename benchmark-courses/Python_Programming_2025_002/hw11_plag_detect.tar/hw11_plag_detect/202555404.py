def round_up(x, places=0):
    """Round up a floating point number to the specified decimal places.
    
    Args:
        x: The number to round
        places: Number of decimal places (default 0)
    
    Returns:
        Rounded number using conventional round-up scheme
    """
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def frequency_ratio(input_string):
    """Calculate the frequency ratio of the most frequent alphabetic character(s).
    
    Args:
        input_string: Input string to analyze
    
    Returns:
        Frequency ratio rounded to one decimal place
    """
    # Count only alphabetic characters
    alpha_chars = [c.lower() for c in input_string if c.isalpha()]
    
    if not alpha_chars:
        return 0.0
    
    # Count frequency of each character
    char_counts = {}
    for char in alpha_chars:
        char_counts[char] = char_counts.get(char, 0) + 1
    
    # Find the maximum frequency
    max_freq = max(char_counts.values())
    
    # Calculate frequency ratio
    total_alpha_chars = len(alpha_chars)
    ratio = max_freq / total_alpha_chars
    
    # Round to one decimal place using conventional round-up
    return round_up(ratio, 1)

def main():
    input_string = input()
    result = frequency_ratio(input_string)
    print(f"{result:.1f}")

if __name__ == "__main__":
    main()
