def round_up(value, digits=1):
    """Round up to the nearest digit using conventional rounding."""
    multiplier = 10 ** digits
    return int(value * multiplier + 0.5) / multiplier

def main():
    s = input()
    freq = {}

    # Count frequency of alphabetic characters
    for ch in s:
        if ch.isalpha():
            ch_upper = ch.upper()
            freq[ch_upper] = freq.get(ch_upper, 0) + 1

    total_alpha = sum(freq.values())

    if total_alpha == 0:
        print("0.0")
        return

    max_freq = max(freq.values())

    ratio = max_freq / total_alpha
    print(round_up(ratio))

if __name__ == "__main__":
    main()