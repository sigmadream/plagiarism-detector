def round_up(x, places = 1):
    """ It rounds up the decimal to the first place"""
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

line = input()
ustr = line.upper()
count = {}
LETTERS = 0


for c in ustr:
    if c.isalpha():
        count[c] = ustr.count(c)
        LETTERS += 1

mxcnt = max(count.values())
frequency = mxcnt / LETTERS
print(round_up(frequency))
