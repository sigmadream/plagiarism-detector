def round_up(value, decimals=1):
    """making round up"""
    multiplier = 10 ** decimals
    return int(value * multiplier + 0.5) / multiplier

def main():
    """counting letters"""
    s = input()
    total_letters = 0
    #Count frequencies
    freq = {}
    for ch in s:
        if ch.isalpha():
            ch=ch.lower()
            freq[ch] = freq.get(ch, 0) + 1
            total_letters +=1
    max_freq = 0
    if total_letters > 0:
        for count in freq.values():
            max_freq = max(max_freq, count)
        ratio = max_freq / total_letters
        result = round_up(ratio)
        print(f"{result: .1f}")
    else:
        print("0.0")
if __name__=="__main__":
    main()
