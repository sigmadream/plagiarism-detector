def round_up(x, places=1):
    """SImple round-up with defualt arg places 1"""
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def main():
    """calculate max_freq of given input string"""
    l = [0 for i in range(26)] # 26
    s = input()

    for i in range(len(s)): # n
        chrcode = ord(s[i])
        if (chrcode < 91) & (chrcode > 40):
            chrcode += 32
        if (chrcode < 97) | (chrcode > 122):
            continue
        l[chrcode - 97] += 1

    max_freq = 0
    sum_freq = 0
    for element in l: # 26
        sum_freq += element
        max_freq = element if element > max_freq else max_freq

    max_freq /= sum_freq
    print(f"{round_up(max_freq)}")

if __name__ == "__main__":
    main()
