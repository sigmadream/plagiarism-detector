def round_up(x, places=1):
    """round_up is the function for general rounding"""

    multiplier = 10**places
    return int(x * multiplier + 0.5) / multiplier


def main():
    """main is start point of program"""
    input_str = input()
    char_count = {}
    alp_count = 0

    max_counted_char = None

    for char in input_str:
        if char == " ":
            continue

        lower_char = char.lower()

        if not 97 <= ord(lower_char) <= 122:
            continue

        alp_count += 1

        if lower_char not in char_count:
            char_count[lower_char] = 1
        else:
            char_count[lower_char] += 1

        if max_counted_char is None:
            max_counted_char = lower_char
        else:
            if char_count[max_counted_char] < char_count[lower_char]:
                max_counted_char = lower_char

    print(round_up(char_count[max_counted_char] / alp_count))


if __name__ == "__main__":
    main()
