def round_up(x, places):
    """
    Round a number up to a specified number of decimal places.

    Parameters:
    x (float): The number to be rounded.
    places (int): The number of decimal places to round to.

    Returns:
    float: The rounded number.
    """
    multiplier = 10 ** places  # Calculate the multiplier based on the number of decimal places
    return int(x * multiplier + 0.5) / multiplier  # Round up the number

def calculate_heaviest_character_ratio(sentence):
    """
    Calculate the ratio of the weight of the heaviest character to the total weight of the sentence.

    The weight of a character is defined as follows:
    - Vowels (a, e, i, o, u) have a weight of 2.
    - Consonants have a weight of 1.
    
    The function normalizes the sentence to lowercase and counts the weights of each character.

    Parameters:
    sentence (str): The input sentence from which to calculate the character weights.

    Returns:
    None: The function prints the ratio rounded to one decimal place.
    """
    # Normalize the sentence to lowercase
    sentence = sentence.lower()
    vowels = "aeiou"  # Define vowels
    consonant = "bcdfghjklmnpqrstvwxyz"  # Define consonants
    # Initialize a list to count occurrences of each character
    char_count = [0] * 128  # ASCII range for lowercase letters and space
    heaviest_weight = 0  # Initialize heaviest weight
    total_weight = 0  # Initialize total weight
    # Count occurrences of each character
    for char in sentence:
        weight = 0  # Initialize weight for the character
        if char in vowels:  # If the character is a vowel, assign a weight of 2
            weight = 2
        elif char in consonant:  # If the character is a consonant, assign a weight of 1
            weight = 1
        char_count[ord(char)] += weight
        total_weight += weight  # Increment total weight for each character
        heaviest_weight = max(heaviest_weight, char_count[ord(char)])  # Update heaviest weight
    # Print the ratio rounded to one decimal place
    print(f"{round_up(heaviest_weight / total_weight, 1):.1f}")

# Example usage
input_sentence = input()
calculate_heaviest_character_ratio(input_sentence)
