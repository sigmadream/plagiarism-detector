import math

def round_up(x, places=1):
    "Conventional rounding-up method"
    # multiplying x by 10^places -> to shift decimal point
    multiplier = 10 ** places
    # adding 0.5 -> to round up
    # using floor -> to simulate conventional rounding
    # dividing by 10^places -> to shift decimal point back
    return math.floor(x * multiplier + 0.5) / multiplier


def char_weight_calc(sentence):
    "Function to calculate the individual character weights & total weight"
    # defining vowels for weight = 2.0
    vowels = {"a", "e", "i", "o", "u"}
    # defining semivowels for weight = 1.0
    semivowels = {"w", "y"}
    # converting the sentence to lowercase -> ensure case insensitivity
    sentence = sentence.lower()
    char_weights = {}
    total_weight = 0
    # iterating through each character in the sentence
    for char in sentence:
        # if char is an alphabetic character
        if char.isalpha():
            # if char is a vowel -> weight = 2.0
            if char in vowels:
                weight = 2.0
            # if char is a semivowel -> weight = 1.0
            elif char in semivowels:
                weight = 1.0
            # else -> weight = 1.0
            else:
                weight = 1.0
            # adding the weight to the total weight
            total_weight += weight
            # adding the weight to the character's weight
            if char in char_weights:
                # if char is already in the dict -> increment its weight
                char_weights[char] += weight
            else:
                char_weights[char] = weight
    return char_weights, total_weight


def heavy_ratio_calc(sentence):
    "Function to calculate the ratio of the heaviest character"
    char_weights, total_weight = char_weight_calc(sentence)
    # if there are no words in the sentence -> return 0.0
    if total_weight == 0:
        return 0.0
    max_char_weight = 0
    # iterating through all the character weights
    for _, weight in char_weights.items():
        # finding the maximum character weight
        max_char_weight = max(max_char_weight, weight)
    # calculating the ratio of the heaviest character to total sentence's weight
    ratio = max_char_weight / total_weight
    return ratio


def main():
    "Main function for reading input & calculating the ratio"
    input_string = input()
    # computing the heaviest character's ratio
    ratio = heavy_ratio_calc(input_string)
    # rounding up the ratio to one place after the decimal point
    rounded_ratio = round_up(ratio)
    print(f"{rounded_ratio:.1f}")

if __name__ == "__main__":
    main()
