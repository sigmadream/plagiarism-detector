from math import floor

def get_char_weight(char):
    vowels = 'aeiou'
    semivowels = 'wy'
    if char in vowels:
        return 2.0
    elif char in semivowels:
        return 1.0
    elif char.isalpha():
        return 1.0
    return 0.0

def roundup(value, decimals=1):
    multiplier = 10 ** decimals
    shifted = value * multiplier
    if shifted - floor(shifted) >= 0.5:
        return (floor(shifted) + 1) / multiplier
    else:
        return floor(shifted) / multiplier

def main():
    sentence = input().strip().lower()
    total_weight = 0.0
    weight_by_char = {}

    for char in sentence:
        if char.isalpha():
            w = get_char_weight(char)
            total_weight += w
            weight_by_char[char] = weight_by_char.get(char, 0.0) + w

    if total_weight == 0:
        print("0.0")
        return

    max_ratio = max(weight / total_weight for weight in weight_by_char.values())
    print(f"{roundup(max_ratio, 1):.1f}")

if __name__ == "__main__":
    main()
