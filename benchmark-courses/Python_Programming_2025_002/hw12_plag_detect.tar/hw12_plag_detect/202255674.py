import math

def round_up(x, places=1):
    """conventional한 반올림 방법"""
    multiplier = 10 ** places
    return math.floor(x * multiplier + 0.5) / multiplier

def cal_weigh():
    """사용자로부터 문장을 입력받고, 가장 무거운 문자 / 전체 가중치 비율을 출력"""
    line = input().lower()
    weight_table = {}
    total_weight = 0.0

    for ch in line:
        if 'a' <= ch <= 'z':
            if ch in 'aeiou':
                w = 2.0
            else:
                w = 1.0
            total_weight += w
            weight_table[ch] = weight_table.get(ch, 0.0) + w

    if total_weight == 0:
        print("0.0")
        return

    max_weight = max(weight_table.values())
    ratio = max_weight / total_weight
    print(round_up(ratio, 1))

if __name__ == "__main__":
    cal_weigh()
