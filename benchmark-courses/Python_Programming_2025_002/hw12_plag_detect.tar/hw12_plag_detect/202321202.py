import math

# round_up 함수를 math.floor()를 사용하여 구현
def round_up(x, places):
    multiplier = 10 ** places
    return math.floor(x * multiplier + 0.5) / multiplier

# 문장의 가중치 계산 함수
def calculate_weight(sentence):
    vowels = 'aeiou'
    semi_vowels = 'wy'
    total_weight = 0.0
    char_weights = {}

    for char in sentence.lower():  # 대소문자 구분 없이 처리
        if char.isalpha():  # 알파벳만 처리
            if char in vowels:
                weight = 2.0
            elif char in semi_vowels:
                weight = 1.0
            else:
                weight = 1.0

            # 각 문자의 가중치를 저장
            char_weights[char] = char_weights.get(char, 0) + weight
            total_weight += weight
    
    # 가장 무거운 문자의 가중치 찾기
    max_weight_char = max(char_weights, key=char_weights.get)
    max_weight = char_weights[max_weight_char]

    # 최대 문자의 가중치 비율 계산
    ratio = max_weight / total_weight

    return ratio

def main():
    input_string = input().strip()  # 문장을 입력받기
    ratio = calculate_weight(input_string)  # 비율 계산
    print(round_up(ratio, 1))  # 비율을 소수 첫째 자리로 반올림하여 출력

if __name__ == "__main__":
    main()
