import math

def rhu(n, d=1):
    m = 10 ** d
    return math.floor(n * m + 0.5) / m

s = input()
a = [c.lower() for c in s if c.isalpha()]
if not a:
    print("0.0")
else:
    tot = sum(2 if c in "aeiou" else 1 for c in a)
    w = {}
    for c in a:
        w[c] = w.get(c, 0) + (2 if c in "aeiou" else 1)
    print(rhu(max(w.values()) / tot, 1))
