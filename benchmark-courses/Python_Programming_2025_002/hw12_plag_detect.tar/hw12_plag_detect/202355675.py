def round_up(x, places):
    """skjadk"""
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def count(words):
    """djhas"""
    vowels = ["a", "e", "i", "o", "u"]
    counts = 0
    for char in words:
        if char.isalpha():
            if char.lower() not in vowels:
                counts += 1
            else:
                counts += 2
    return counts
def height(words):
    """dahsj"""
    lol = []
    vowels = ["a", "e", "i", "o", "u"]
    for char in words:
        num = 0
        for car in words:
            if car.isalpha():
                if char.lower() == car.lower():
                    if char in vowels:
                        num += 2
                    else:
                        num += 1
        lol.append(num)
    return max(lol)

def main():
    """dassda"""
    words = input()
    c = height(words)
    s = count(words)
    ans = c / s
    ans = round_up(ans, 1)
    print(f"{ans:.1f}")

if __name__ == "__main__":
    main()
