SentList = input().lower()
cnt = []
SWEIGHT = 0

for i in SentList:
    if i in 'iaeou':
        cnt.append(SentList.count(i) * 2)
        SWEIGHT += 2
    elif i.isalpha():
        cnt.append(SentList.count(i))
        SWEIGHT += 1
    else:
        cnt.append(0)

W = max(cnt)/SWEIGHT

print(round((100 * W + 0.5)/100, 1))
