import sys
import math
from collections import Counter


# 사용자 정의 반올림 함수
def round_up(x, places=1):
    multiplier = 10**places
    return math.floor(x * multiplier + 0.5) / multiplier


# 문자별 가중치 계산 함수
def char_weight(c):
    c = c.lower()
    if c in "aeiou":
        return 2.0
    elif c.isalpha():
        return 1.0
    return 0.0


# 입력 받기
sentence = input()

# 알파벳만 뽑아내고 소문자로 변환
filtered = [c.lower() for c in sentence if c.isalpha()]

# 전체 문자 개수 세기
counter = Counter(filtered)

# 총 문장 무게 계산
total_weight = sum(char_weight(c) * count for c, count in counter.items())

# 가장 무거운 문자의 무게 찾기
max_char_weight = max((char_weight(c) * count) for c, count in counter.items())

# 비율 계산 및 출력
if total_weight > 0:
    ratio = max_char_weight / total_weight
    print(f"{ratio:.1f}")
else:
    print("0.0")
