from math import floor

def get_char_weight(char):
    """Gets character weight."""
    vowels = {'a', 'e', 'i', 'o', 'u'}
    semivowels = {'w', 'y'}
    if char in vowels:
        return 2.0
    if char in semivowels:
        return 1.0
    if char.isalpha():
        return 1.0
    return 0.0

def custom_round(number, digits=1):
    """Round function."""
    multiplier = 10 ** digits
    return floor(number * multiplier + 0.5) / multiplier

def calculate_ratio(sentence):
    """Calculating weight."""
    sentence = string.lower()
    total_weight = 0.0
    char_weights = {}

    for char in sentence:
        if char.isalpha():
            weight = get_char_weight(char)
            total_weight += weight
            char_weights[char] = char_weights.get(char, 0.0) + weight

    if total_weight == 0:
        return 0.0

    max_char_weight = max(char_weights.values())
    ratio = max_char_weight / total_weight
    return custom_round(ratio)

# Example usage
if __name__ == "__main__":
    string = input()
    result = calculate_ratio(string)
    print(result)
