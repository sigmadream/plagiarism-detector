def rounding(x, places=1):
    """
    Round a number to a specified number of decimal places.

    Args:
        x (float): The number to round.
        places (int, optional): The number of decimal places to round to.
    Returns:
        float: The rounded number.
    """
    multiplier = 10 ** places
    return int(x * multiplier + 0.5) / multiplier

def char_weight_calc(sentence):
    """
    Calculate the weight of each character in the sentence.

    Args:
        sentence (str): The input sentence.

    Returns:
        tuple: A dictionary with character weights and the total weight.
    """
    vowels = {"a", "e", "i", "o", "u"}
    sentence = sentence.lower()
    char_weights = {}
    total_weight = 0

    for char in sentence:
        if char.isalpha():
            weight = 2.0 if char in vowels else 1.0
            total_weight += weight
            char_weights[char] = char_weights.get(char, 0) + weight

    return char_weights, total_weight

def heavy_ratio_calc(sentence):
    """
    Calculate the ratio of the heaviest character weight to the total weight.

    Args:
        sentence (str): The input sentence.

    Returns:
        float: The ratio of the heaviest character weight to the total weight.
    """
    char_weights, total_weight = char_weight_calc(sentence)
    if total_weight == 0:
        return 0.0
    max_char_weight = max(char_weights.values(), default=0)
    return max_char_weight / total_weight

def main():
    """
    Main function to calculate and display the heavy ratio of a sentence.
    """
    input_string = input()
    ratio = heavy_ratio_calc(input_string)
    rounded_ratio = rounding(ratio)
    print(f"{rounded_ratio:.1f}")

if __name__ == "__main__":
    main()
