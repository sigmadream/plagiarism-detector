import math

def char_weight(n):
    '''Character weight'''
    n = n.lower()
    vowels = 'aeiou'
    semivowels = 'wy'
    if n in vowels:
        return 2.0
    if n in semivowels:
        return 1.5
    if n.isalpha():
        return 1.0
    return 0.0

def round_up(x, places=1):
    '''Function to round numbers'''
    multiplier = 10 ** places
    return math.floor(x * multiplier + 0.5+ 1e-8) / multiplier

def main():
    '''Main function to find ratio'''
    sentence = input().strip()
    total_weight = 0.0
    char_weights = {}

    for char in sentence:
        if char.isalpha():
            n = char.lower()
            weight = char_weight(n)
            total_weight += weight
            if n in char_weights:
                char_weights[n] += weight
            else:
                char_weights[n] = weight

    if total_weight == 0:
        print("0.0")
        return

    max_char_weight = max(char_weights.values())
    ratio = max_char_weight / total_weight
    rounded_ratio = round_up(ratio, 1)
    print(f"{rounded_ratio:.1f}")

if __name__ == "__main__":
    main()
