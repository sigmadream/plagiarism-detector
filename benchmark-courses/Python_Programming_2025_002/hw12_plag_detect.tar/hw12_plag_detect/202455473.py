from math import floor

def roundup(n, digits=1):
    """Round a float to the given number of decimal places using conventional rounding."""
    mult = 10 ** digits
    shifted = n * mult
    if shifted - floor(shifted) >= 0.5:
        return (floor(shifted) + 1) / mult
    return floor(shifted) / mult

def main():
    """Reads a sentence and prints the weight ratio of the heaviest character."""
    sentence = input()
    weights = {}
    total_weight = 0.0

    for ch in sentence:
        if ch.isalpha():
            ch = ch.lower()
            if ch in 'aeiou':
                w = 2.0
            else:
                w = 1.0
            total_weight += w
            if ch not in weights:
                weights[ch] = w
            else:
                weights[ch] += w

    max_weight = 0.0
    for value in weights.values():
        max_weight = max(max_weight, value)

    ratio = max_weight / total_weight
    print(f"{roundup(ratio):.1f}")

main()
