from math import floor

def round_half_up(num,places=1):
    '''
    This function rounds up the number to one decimal place
    '''
    multiplier = 10 ** places
    return floor(num * multiplier + 0.5) / multiplier

def main():
    '''
    This function calculates the ratio of the weight of
    the heaviest character to the total weight of the sentence
    '''
    input_seq = input().lower()
    d = {}
    for i in input_seq:
        if i.isalpha() and i in {'a','e','i','o','u'}:
            d[i] = d.get(i,0) + 2
        elif i.isalpha():
            d[i] = d.get(i,0) + 1

    c_weight = max(d.values())
    s_weight = sum(d.values())

    print(round_half_up(c_weight/s_weight))

if __name__ == "__main__":
    main()
