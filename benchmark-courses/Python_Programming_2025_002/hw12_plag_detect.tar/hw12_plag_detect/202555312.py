def round_up(x, places=0):
    '''rounds x up to the nearest decimal place given by places as 10^places'''
    mul = 10 ** places
    return int(x * mul + 0.5) / mul if places >= 0 else int(x / mul + 0.5) * mul


def main():
    '''main function'''
    raw_input = input()
    converted_input = raw_input.lower()
    character_count = {}
    string_weight = 0

    for character in converted_input:
        if character.isalpha():
            match(character):
                case "a" | "e" | "i" | "o" | "u":
                    weight = 2
                case _:
                    weight = 1

            character_count[character] = converted_input.count(character) * weight
            string_weight += weight

    max_weight = max(character_count.values())

    raw_fratio = round_up(max_weight / string_weight, -1)

    print(f"{int(raw_fratio)}.{int(raw_fratio * 10 % 10)}")

if __name__ == "__main__":
    main()
