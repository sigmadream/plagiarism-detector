def round_up(value, places):
    multiplier = 10 ** places
    return int(value * multiplier + 0.5) / multiplier

def main():
    line = input()
    uste = line.upper()

    count = {}
    total_weight = 0

    for c in uste:
        if not c.isalpha():
            continue

        if c in 'AEIOU':
            weight = 2.0
        else:
            weight = 1.0

        if c not in count:
            count[c] = 0
        count[c] += weight

        total_weight += weight

    max_char_weight = max(count.values())
    
    ratio = max_char_weight / total_weight
    rounded_ratio = round_up(ratio, 1)

    print(f"{rounded_ratio:.1f}")

if __name__ == "__main__":
    main()
