def round_up(x, places = 1):
    """A function to round the numbers in the normal scheme"""
    mutliplier = 10 ** places
    return int(x * mutliplier + 0.5) /  mutliplier

weights = ['A', 'E', 'I', 'O', 'U']
counter = {}

s = input().upper()
s1 = s.split()

weight = 0 # "Total weight of the sentence"

for w in s1:
    for c in w:
        if c in weights:
            weight += 2
        elif not c.isalpha():
            continue
        else:
            weight += 1
        if c in counter and c in weights:
            counter[c] += 2
        elif c not in counter and c in weights:
            counter[c] = 2
        elif c not in counter:
            counter[c] = 1
        elif c in counter:
            counter[c] += 1


maxc = max(counter.values())

print(round_up(maxc / weight))
