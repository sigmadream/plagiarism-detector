sentence = input()
vowels = "aeiou"
char_weights = {}
total_weight = 0

for char in sentence:
    if char.isalpha():
        char = char.lower()
        
        weight = 2.0 if char in vowels else 1.0
        if char in char_weights:
            char_weights[char] += weight
        else:
            char_weights[char] = weight
        total_weight += weight

max_weight = 0
for weight in char_weights.values():
    if weight > max_weight:
        max_weight = weight

if total_weight > 0:
    ratio = max_weight / total_weight
    print(f"{ratio:.1f}")
else:
    print("0.0")