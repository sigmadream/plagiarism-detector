"""
1. Use only the facilities of Python introduced up to now.
2. Implement the conventional round-up scheme as a function with a default argument
as specified in the problem description, but do not use the function int but use the
function floor in module math.
3. Check the quality of your code to make it have fewer than two quality issues.

"""

from math import floor

input_string = input().lower()
VOWELS = "aeiou"
only_alphabet = []
HEAVIEST = 0
TOTAL = 0

for a in input_string:
    if a.isalpha():
        only_alphabet.append(a)

for char in set(only_alphabet):
    cnt = only_alphabet.count(char)
    TOTAL += cnt * 2 if char in VOWELS else cnt
    weight = cnt * 2 if char in VOWELS else cnt
    HEAVIEST = max(HEAVIEST, weight)

result = floor(((HEAVIEST / TOTAL) * 10) + 0.5) / 10
print(f"{result:.1f}")
