import math

def round_to_decimal(num, decimal_places=1):
    """Round a number to specified decimal places using conventional rounding."""
    multiplier = 10 ** decimal_places
    return math.floor(num * multiplier + 0.5) / multiplier

def calculate_character_weight(char):
    """Calculate the weight of a single character."""
    char = char.lower()
    
    if char in 'aeiou':  # vowels
        return 2.0
    elif char.isalpha() or char in 'wy':  # consonants and semivowels
        return 1.0
    else:  # non-alphabetic characters
        return 0.0

def calculate_sentence_weight(sentence):
    """Calculate the total weight of a sentence."""
    total_weight = 0.0
    
    for char in sentence:
        total_weight += calculate_character_weight(char)
    
    return total_weight

def find_heaviest_character(sentence):
    """Find the character with the highest weight based on occurrences."""
    char_count = {}
    
    for char in sentence.lower():
        if char.isalpha():
            if char in char_count:
                char_count[char] += 1
            else:
                char_count[char] = 1
    
    max_weight = 0.0
    heaviest_char = None
    
    for char, count in char_count.items():
        char_weight = calculate_character_weight(char) * count
        if char_weight > max_weight:
            max_weight = char_weight
            heaviest_char = char
    
    return heaviest_char, max_weight

def main():
    # Get input sentence
    sentence = input()
    
    # Calculate the total weight of the sentence
    total_weight = calculate_sentence_weight(sentence)
    
    # Find the heaviest character and its weight
    heaviest_char, heaviest_weight = find_heaviest_character(sentence)
    
    # Calculate the ratio
    ratio = heaviest_weight / total_weight
    
    # Round to one decimal place
    rounded_ratio = round_to_decimal(ratio)
    
    # Print the result
    print(f"{rounded_ratio:.1f}")

if __name__ == "__main__":
    main()
