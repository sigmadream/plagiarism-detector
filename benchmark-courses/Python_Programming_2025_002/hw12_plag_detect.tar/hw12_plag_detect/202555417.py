import math

def round_up(x, places = 1):
    """Round up a number to the nearest integer."""
    multiplier = 10 ** places
    return math.floor(x * multiplier + 0.5) / multiplier

line = input()
ustr = line.lower()
TOTAL_WEIGHT = 0
count = {}

for c in ustr:
    if c.isalpha():
        count [c] = ustr.count(c)
        if c in "aeiou":
            TOTAL_WEIGHT += 2
        else:
            TOTAL_WEIGHT += 1

mxcnt = max(count.values())

for key, value in count.items() :
    if value == mxcnt:
        if key in "aeiou":
            mx_weight = 2 * mxcnt
            break
        mx_weight = mxcnt

rt_weight = mx_weight/TOTAL_WEIGHT
print(round_up(rt_weight))
