from math import floor

def custom_round(number, decimal_places=1):
    """Round a number to the specified number of decimal places using custom logic."""
    multiplier = 10 ** decimal_places
    return floor(number * multiplier + 0.5) / multiplier

def get_max_char_ratio(text):
    """Calculate the ratio of the most frequent character's weight to the total character weight."""
    text = text.strip().lower()
    char_weights = {}
    total_weight = 0

    # Count only alphabet characters
    for ch in text:
        if ch.isalpha():
            if ch not in char_weights:
                char_weights[ch] = 0
            char_weights[ch] += 1
            total_weight += 1

    # Find max weight
    max_weight = 0
    for _, weight in char_weights.items():
        max_weight = max(max_weight, weight)
    if total_weight == 0:
        return "0.0"

    return str(custom_round(max_weight / total_weight, 1))  # ← do not change this line

# Get input and display result
user_input = input()
print(get_max_char_ratio(user_input))
