import math

def round_up(x, places=1):
    """straightforward round-up with defualt arg places 1"""
    multiplier = 10 ** places
    return math.floor(x * multiplier + 0.5) / multiplier

freq_arr = [0] * 26
seq = input()
for ch in seq: # n
    chrcode = ord(ch)
    if (chrcode < 91) & (chrcode > 40):
        chrcode += 32
    if (chrcode < 97) | (chrcode > 122):
        continue
    freq_arr[chrcode - 97] += 1

vowels = [0, 4, 8, 14, 20]
for idx in vowels: # 5
    freq_arr[idx] *= 2

MAX_W = 0
SUM_W = 0
for i in range(len(freq_arr)): # 26
    tmp = freq_arr[i]
    SUM_W += tmp
    MAX_W = tmp if tmp > MAX_W else MAX_W

MAX_W /= SUM_W
print(f"{round_up(MAX_W)}")
