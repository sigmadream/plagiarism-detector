import math


def round_up(x, places=1):
    """round_up is the function for general rounding"""
    multiplier = 10**places
    return math.floor(x * multiplier + 0.5) / multiplier


def main():
    """main is the start point of program"""
    input_str = input()

    sentence_weight = 0
    char_count = {}

    for char in input_str:
        lower_char = char.lower()

        if not 97 <= ord(lower_char) <= 122:
            continue

        if lower_char in ["a", "e", "i", "o", "u"]:
            sentence_weight += 2
        else:
            sentence_weight += 1

        if lower_char in char_count:
            char_count[lower_char] += 1
        else:
            char_count[lower_char] = 1

    heaviest_char = 0

    for key, value in char_count.items():
        if key in ["a", "e", "i", "o", "u"]:
            heaviest_char = max(value * 2, heaviest_char)
        else:
            heaviest_char = max(value * 1, heaviest_char)

    print(f"{round_up(heaviest_char / sentence_weight):.1f}")


if __name__ == "__main__":
    main()
