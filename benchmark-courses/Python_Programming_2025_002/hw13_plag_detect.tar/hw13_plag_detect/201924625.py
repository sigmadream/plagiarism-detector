data = [[0 for _ in range(101)] for _ in range(101)]

def get_pascal(n, m):
    """
    Recursively calculate the value at the nth row and mth column of Pascal's Triangle.

    Args:
        n (int): The row number in Pascal's Triangle (1-indexed).
        m (int): The column number in Pascal's Triangle (1-indexed).

    Returns:
        int: The value at the specified position in Pascal's Triangle.
    """
    # Check for valid input
    if n < 1 or m < 1 or m > n:
        return 0  # Return 0 for invalid positions

    # Return the cached value if it exists
    if data[n][m] != 0:
        return data[n][m]

    # Base cases
    if n == 1 or m == 1:  # The first row and first column are always 1
        data[n][m] = 1
        return 1
    if n == m:  # The diagonal elements are always 1
        data[n][m] = 1
        return 1

    # Recursive case: sum of the two values above the current position
    data[n][m] = get_pascal(n - 1, m) + get_pascal(n - 1, m - 1)
    return data[n][m]


# Initialize the result variable to accumulate the sum
RES = 0

# Read the number of test cases
k = int(input())

# Loop through each test case
for i in range(k):
    k = input()
    b, c = map(int, k.split())  # Split the input and convert to integers
    RES += get_pascal(b, c)  # Add the value from Pascal's Triangle to the result

# Print the final accumulated result
print(RES)
