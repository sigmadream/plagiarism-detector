memo = {}

def pascal(n, m):
    ''' Return the value at row n and column in pascal's triangle'''
    # base cases
    if m in (1, n):
        return 1
    # recursive relation
    if (n,m) in memo:
        return memo[(n,m)]

    memo[(n,m)] = pascal(n - 1, m - 1) + pascal(n - 1, m)
    return memo[(n,m)]

k = int(input())
TOTAL = 0
for _ in range(k):
    row, col = map(int, input().split())
    TOTAL += pascal(row, col)

print(TOTAL)
