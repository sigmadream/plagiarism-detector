mem = {}
def p(n,m):
 if m<1 or m>n:return 0
 if m in (1,n):return 1
 if (n,m) in mem:return mem[(n,m)]
 mem[(n,m)]=p(n-1,m-1)+p(n-1,m)
 return mem[(n,m)]
k=int(input())
print(sum(p(int(n),int(m)) for n,m in [input().split() for _ in range(k)]))