k = int(input())
total = 0

def nCr(n, r):
    if r == 0 or n == r:
        return 1
    if (n, r) in memo:
        return memo[(n, r)]
    memo[(n, r)] = nCr(n - 1, r - 1) + nCr(n - 1, r)
    return memo[(n, r)]

memo = {}
for _ in range(k):
    a, b = input().split()
    n = int(a) - 1
    r = int(b) - 1
    total += nCr(n, r)

print(total)
