m={}
def cal(n,k):
    if k==1 or k==n:
        return 1
    if(n,k) in m:
        return m[n,k]
    m[n,k]=cal(n-1,k-1)+cal(n-1,k)
    return m[n,k]
s=0
for _ in range(int(input())):
    n,k=map(int,input().split())
    s+=cal(n,k)
print(s)
