memo = {}

def choose(n, m):
    """Return the binomial coefficient n choose m using recursion with memoization."""
    if m in (0, n):
        return 1
    if (n, m) in memo:
        return memo[(n, m)]
    memo[(n, m)] = choose(n - 1, m - 1) + choose(n - 1, m)
    return memo[(n, m)]

k = int(input())
TOTAL = 0
COUNT = 0

while COUNT < k:
    line = input().strip()
    if not line:
        continue
    parts = line.split()
    row = int(parts[0])
    col = int(parts[1])
    TOTAL += choose(row - 1, col - 1)
    COUNT += 1

print(TOTAL)
