memo = {}

def choose(n, k):
    if k == 0 or k == n:
        return 1
    if (n, k) in memo:
        return memo[(n, k)]
    memo[(n, k)] = choose(n - 1, k - 1) + choose(n - 1, k)
    return memo[(n, k)]

def main():
    k = int(input())
    total = 0
    for _ in range(k):
        n, m = map(int, input().split())
        total += choose(n - 1, m - 1)
    print(total)

if __name__ == "__main__":
    main()
