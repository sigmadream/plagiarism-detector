import sys
r={}
def c(n,m):
    if m==1 or m==n:return 1
    if(n,m)in r:return r[n,m]
    r[n,m]=c(n-1,m-1)+c(n-1,m);return r[n,m]
k=int(sys.stdin.readline())
print(sum(c(*map(int,sys.stdin.readline().split()))for _ in range(k)))
