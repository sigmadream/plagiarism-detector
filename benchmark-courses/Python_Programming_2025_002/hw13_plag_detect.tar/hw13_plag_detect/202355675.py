m = {}
def c(n, k):
    if k == 0 or k == n: return 1
    if (n, k) in m: return m[n, k]
    m[n, k] = c(n-1, k-1) + c(n-1, k)
    return m[n, k]
print(sum(c(n-1, k-1) for _ in range(int(input())) for n,k in [map(int,input().split())]))