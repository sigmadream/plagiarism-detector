def pascal_triangle(n):
    """generate pascal_triangle"""
    triangle = [[1] * (i + 1) for i in range(n)]
    for i in range(2, n):
        for j in range(1, i):
            triangle[i][j] = triangle[i-1][j-1] + triangle[i-1][j]
    return triangle

def main():
    """select proper index of triangle and add to total"""
    k = int(input())
    queries = []
    level = 0

    for _ in range(k):
        n, m = map(int, input().split())
        queries.append((n, m))
        level = max(level, n)

    triangle = pascal_triangle(level)
    total = 0

    for n, m in queries:
        total += triangle[n-1][m-1]

    print(total)

if __name__ == "__main__":
    main()
