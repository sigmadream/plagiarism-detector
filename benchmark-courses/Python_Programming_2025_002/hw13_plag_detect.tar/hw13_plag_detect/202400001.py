# pascal.py
memo = {}


def pascal(n, m):
    """
    이것을 올리기 전에는 토큰이 158개
    """
    if m == 1 or m == n: return 1
    if (n, m) not in memo:
        memo[(n, m)] = pascal(n - 1, m - 1) + pascal(n - 1, m)
    return memo[(n, m)]


def main():
    """
    그렇다면 올리고 난 후에는?
    """
    k = int(input())
    s = 0
    for _ in range(k):
        n, m = map(int, input().split())
        s += pascal(n, m)
    print(s)


if __name__ == "__main__":
    main()