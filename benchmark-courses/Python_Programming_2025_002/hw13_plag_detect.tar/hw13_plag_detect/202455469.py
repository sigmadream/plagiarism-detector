memo = {}

def choose(row, col):
    """Base cases"""
    if col in (1,row):
        return 1
    if (row, col) in memo:
        return memo[(row, col)]
    # Recursive calculation with memoization
    memo[(row, col)] = choose(row - 1, col - 1) + choose(row - 1, col)
    return memo[(row, col)]

query_count = int(input())

TOTAL = 0
for _ in range(query_count):
    row_index, col_index = map(int, input().split())
    TOTAL += choose(row_index, col_index)

print(TOTAL)
