import sys, math  # Importing necessary modules: sys for reading input, math for mathematical operations
# Read all input from standard input and split it into a list of strings
i = sys.stdin.read().split()
# Calculate the sum of binomial coefficients
# The input format is expected to be:
# The first number (i[0]) is the count of test cases (k)
# Each test case consists of two numbers (n and m) starting from i[1]
result = sum(
    math.comb(int(i[2 * j + 1]) - 1, int(i[2 * j + 2]) - 1)  # Calculate binomial coefficient (n-1 choose m-1)
    for j in range(int(i[0]))  # Loop through each test case (from 0 to k-1)
)
# Print the final result, which is the sum of all calculated binomial coefficients
print(result)