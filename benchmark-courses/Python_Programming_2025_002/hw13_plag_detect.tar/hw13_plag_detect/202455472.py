memo = {}
def n_choose_m(n, m):
    '''Function n choose m'''
    if m in {0,n}:
        return 1
    if (n, m) in memo:
        return memo[(n, m)]
    memo[(n, m)] = n_choose_m(n - 1, m - 1) + n_choose_m(n - 1, m)
    return memo[(n, m)]

k = int(input())
TOTAL_SUM = 0
for _ in range(k):
    a, b = map(int, input().split())
    TOTAL_SUM += n_choose_m(a - 1, b - 1)

print(TOTAL_SUM)
