memo = {}

def c(n, k):
    """Calculate the binomial coefficient C(n, k) using memoization."""
    if k in (0, n):
        return 1
    if (n, k) in memo:
        return memo[n, k]
    memo[n, k] = c(n - 1, k - 1) + c(n - 1, k)
    return memo[n, k]

num = int(input())
print(sum(c(n - 1, k - 1) for n, k in [map(int, input().split()) for _ in range(num)]))
