memo = {}

def pascal_triangle(x, y):
    """
    Recursively computes the value at position (x, y) in Pascal's Triangle.

    The function uses memoization to optimize repeated calculations.
    The base cases are:
    - Returns 1 if y == 1 or x == y (edge values of the triangle).
    - Returns 0 if the indices are out of bounds (e.g., y > x or any index < 1).

    Args:
        x (int): The row index (1-based).
        y (int): The column index (1-based).

    Returns:
        int: The value at position (x, y) in Pascal's Triangle.
    """
    if x < 1 or y < 1 or y > x:
        return 0
    if y == 1 or x == y:
        return 1
    if (x, y) in memo:
        return memo[(x, y)]
    value = pascal_triangle(x - 1, y - 1) + pascal_triangle(x - 1, y)
    memo[(x, y)] = value
    return value

def main():
    """
    Reads a number of coordinate pairs and computes the sum of their corresponding
    values in Pascal's Triangle.

    First, it takes an integer input indicating the number of coordinate pairs.
    Then for each pair (x, y), it calculates the Pascal Triangle value at that
    position using `pascal_triangle(x, y)` and sums them all up.

    Finally, it prints the total sum.
    """
    lines = int(input())

    res = 0
    for _ in range(lines):
        user = input()
        if not user.strip():
            continue
        x, y = map(int, user.split())
        res += pascal_triangle(x, y)
    print(res)

if __name__ == "__main__":
    main()
