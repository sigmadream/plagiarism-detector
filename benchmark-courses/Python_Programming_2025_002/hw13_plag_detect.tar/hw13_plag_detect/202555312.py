memory = {}

def choose(row, col):
    '''calculates C(row, col) recursively'''
    if col in (1, row):
        return 1
    if (row, col) in memory:
        pass
    else:
        memory[(row, col)] = choose(row - 1, col - 1) + choose(row - 1, col)
    return memory[(row, col)]


def main():
    '''main'''
    number_of_arguments = int(input())
    result = 0
    for _ in range(number_of_arguments):
        coordinates = input().split()
        row = int(coordinates[0])
        col = int(coordinates[1])

        result += choose(row, col)

    print(result)


if __name__ == "__main__":
    main()
