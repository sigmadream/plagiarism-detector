import sys
sys.setrecursionlimit(10000)

memo = {}

def pascal(n,m):
    if m == 1 or n == m:
        return 1
    if (n,m) in memo:
        return memo[(n,m)]
    memo[(n,m)] = pascal (n-1, m-1) + pascal (n-1, m)
    return memo[(n,m)]

def main():
    k = int(input())
    total = 0

    for _ in range(k):
        n,m = map(int, input().split())
        total += pascal(n,m)
    print(total)

if __name__ == "__main__":
    main()