def comb(n, m, comb_memo = {}):
    if (n, m) in comb_memo: return comb_memo[(n, m)]
    comb_memo[(n, m)] = 1 if m == 0 or m == n else comb(n-1, m-1) + comb(n-1, m)
    return comb_memo[(n, m)]

def main():
    print(sum(comb(x-1, y-1) for x, y in (map(int, input().split()) for _ in range(int(input())))))

if __name__ == "__main__":
    main()