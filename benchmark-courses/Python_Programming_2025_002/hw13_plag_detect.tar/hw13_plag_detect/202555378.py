memo = {}
def pascal(n, m):
    if (n, m) in memo:
        return memo[(n, m)]
    if m == 1 or m == n:
        result = 1
    else:
        result = pascal(n-1, m-1) + pascal(n-1, m)
    memo[(n, m)] = result
    return result

k = int(input())
total = 0
for _ in range(k):
    n, m = map(int, input().split())
    total += pascal(n, m)
print(total)
