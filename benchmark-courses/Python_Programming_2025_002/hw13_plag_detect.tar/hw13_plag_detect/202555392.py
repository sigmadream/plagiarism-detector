def pascal(x, y, mem):
    """recursive pascal"""
    x -= 1
    y -= 1
    key = (x, y)
    if key in mem:
        return mem[key]
    if y in (0, x):
        mem[key] = 1
        return 1
    result = pascal(x, y, mem) + pascal(x, y+1, mem)
    mem[key] = result
    return result

k = int(input())
TOTAL = 0
memo = {}
for _ in range(k):
    n, m = map(int, input().split())
    TOTAL += pascal(n, m, memo)
print(TOTAL)
