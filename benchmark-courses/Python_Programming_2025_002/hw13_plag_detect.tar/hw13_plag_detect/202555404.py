memo = {}
def choose(n, m):
    if (n, m) in memo:
        return memo[(n, m)]
    if m == 1 or m == n:
        result = 1
    else:
        result = choose(n-1, m-1) + choose(n-1, m)
    memo[(n, m)] = result
    return result
total = 0
k = int(input())
for _ in range(k):
    n, m = map(int, input().split())
    total += choose(n, m)
print(total)