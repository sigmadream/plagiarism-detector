#pascal.py

def C(n,m):
    if m==1 or m==n: return 1
    return C(n-1,m-1)+C(n-1,m)
k=int(input())
print(sum(C(*map(int,input().split()))for _ in range(k)))