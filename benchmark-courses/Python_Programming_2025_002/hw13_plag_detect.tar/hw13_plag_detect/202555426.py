memo = {}

def choose(n, m):
    """Recursive function to calculate C(n, m) with memoization."""
    if m in (0, n):
        return 1
    if (n, m) in memo:
        return memo[(n, m)]
    memo[(n, m)] = choose(n - 1, m - 1) + choose(n - 1, m)
    return memo[(n, m)]

def main():
    """Reads input, computes the sum of combinations, and prints the result."""
    k = int(input())
    total_combinations = 0
    for _ in range(k):
        n_input, m_input = map(int, input().split())
        total_combinations += choose(n_input - 1, m_input - 1)
    print(total_combinations)

if __name__ == "__main__":
    main()
