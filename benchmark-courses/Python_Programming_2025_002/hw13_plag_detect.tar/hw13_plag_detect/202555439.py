memo={}
def comb(row,col):
    if col in (1,row):return 1
    if col<1 or col>row:return 0
    if (row,col) in memo:return memo[(row,col)]
    tmp=memo[(row,col)]=comb(row-1,col-1)+comb(row-1,col)
    return tmp
S=0
for _ in range(int(input())):
    line=input().split()
    S+=comb(int(line[0]),int(line[1]))
print(S)