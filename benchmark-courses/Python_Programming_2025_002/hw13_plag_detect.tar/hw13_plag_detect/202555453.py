l,p={},input
def c(n, m):
 if m in (n, 0): return 1
 if (n, m) in l: return l[(n, m)]
 l[(n, m)]=c(n-1,m-1)+c(n-1,m)
 return l[(n, m)]
s = 0
for _ in range(int(p())):n,m=map(int, p().split());s+=c(n-1,m-1)
print(s)