def compute_change(coins: list[int], change: int, ind: int = 0) -> list[int]:
    "Recursive function to compute the number of coins for each type"
    # base case: if all coin types have been checked
    if ind >= len(coins):
        return []
    # calculating how many coins of the current type are needed
    denom = change // coins[ind]
    # subtracting the value of these coins
    remaining = change - denom * coins[ind]
    # recursively calling the compute_change function
    # processing the remaining change and the next coin type
    return [denom] + compute_change(coins, remaining, ind + 1)


def main() -> None:
    "Main function to read input and print the result"
    # reading and parsing input
    line: str = input().strip()
    change: int = int(input())
    coins: list[int] = [int(x) for x in line.split()]
    # computing the number of coins of each type
    result: list[int] = compute_change(coins, change)
    print(" ".join(str(x) for x in result))

if __name__ == "__main__":
    main()
