from typing import List

def get_coin_counts(coins: List[int], amount: int, index: int = 0) -> List[int]:
    if index >= len(coins):
        return []
    count = amount // coins[index]
    remainder = amount % coins[index]
    return [count] + get_coin_counts(coins, remainder, index + 1)

def main() -> None:
    coin_str = input().strip()
    amount_str = input().strip()

    coins: List[int] = list(map(int, coin_str.split()))
    amount: int = int(amount_str)

    counts: List[int] = get_coin_counts(coins, amount)
    print(' '.join(map(str, counts)))

if __name__ == "__main__":
    main()
