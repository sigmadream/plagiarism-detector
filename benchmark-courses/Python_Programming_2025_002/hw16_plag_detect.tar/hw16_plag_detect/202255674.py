coins = list(map(int, input().split()));amt = int(input())
def cg(coins: list[int], amt: int, i: int = 0) -> str:
    if i == len(coins): return ""
    c = amt // coins[i]
    rest = cg(coins, amt - c * coins[i], i + 1)
    return f"{c} {rest}".strip()
print(cg(coins, amt))