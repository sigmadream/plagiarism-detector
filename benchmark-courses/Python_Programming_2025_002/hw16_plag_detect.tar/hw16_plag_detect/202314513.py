from typing import List

def make_change(coins: List[int], amount: int, idx: int = 0) -> List[int]:
    """Recursively compute the number of coins for change."""
    if idx == len(coins) - 1:
        return [amount // coins[idx]]
    count = amount // coins[idx]
    rest = amount % coins[idx]
    return [count] + make_change(coins, rest, idx + 1)

def main() -> None:
    """Main function to handle input/output for the change problem."""
    coin_list = list(map(int, input().split()))
    change = int(input())
    result = make_change(coin_list, change)
    print(*result)

if __name__ == "__main__":
    main()
