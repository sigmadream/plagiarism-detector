from typing import List, Tuple

def count_coins(coins: List[int], amount: int, index: int = 0) -> List[int]:
    if index >= len(coins):
        return []  # 잘못된 길이 방지

    coin = coins[index]
    count = amount // coin
    remainder = amount % coin

    return [count] + count_coins(coins, remainder, index + 1)

def parse_input() -> Tuple[List[int], int]:
    coins = list(map(int, input().split()))
    amount = int(input())
    return coins, amount

def print_output(counts: List[int]) -> None:
    print(" ".join(map(str, counts)))

if __name__ == "__main__":
    coins, amount = parse_input()
    counts = count_coins(coins, amount)
    print_output(counts)
