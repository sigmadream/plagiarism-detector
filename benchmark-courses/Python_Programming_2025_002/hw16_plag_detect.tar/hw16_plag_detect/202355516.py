from typing import List

def count_coins(coins: List[int], amount: int, index: int, result: List[int]) -> None:
    if index >= len(coins):
        return
    if amount >= coins[index]:
        result[index] = amount // coins[index]
        amount = amount % coins[index]
    count_coins(coins, amount, index + 1, result)

if __name__ == "__main__":
    coins: List[int] = list(map(int, input().split()))
    amount: int = int(input())
    result: List[int] = [0] * len(coins)
    count_coins(coins, amount, 0, result)
    print(*result)
