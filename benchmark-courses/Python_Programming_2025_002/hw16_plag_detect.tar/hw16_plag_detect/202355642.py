from typing import List

def get_change(coins: List[int], amount: int) -> List[int]:
    if not coins:
        return []
    count = amount // coins[0]
    return [count] + get_change(coins[1:], amount % coins[0])

coins = list(map(int, input().split()))
amount = int(input())
result = get_change(coins, amount)
print(*result)
