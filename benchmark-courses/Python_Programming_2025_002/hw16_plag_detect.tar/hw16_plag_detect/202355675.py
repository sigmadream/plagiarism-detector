def change(c: list[int], a: int, i: int = 0) -> list[int]:
    return [0] * (len(c) - i) if a == 0 or i == len(c) else [a // c[i]] + change(c, a % c[i], i + 1)

def main() -> None:
    c = list(map(int, input().split()))
    a = int(input())
    print(*change(c, a))

if __name__ == "__main__":
    main()