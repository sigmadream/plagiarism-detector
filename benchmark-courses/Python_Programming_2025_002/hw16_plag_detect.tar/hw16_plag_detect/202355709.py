coins = list(map(int, input().split()))
money = int(input())
cnt = []

for coin in coins:
    cnt.append(money // coin)
    money %= coin

print(" ".join(map(str, cnt)))
