from typing import List


def count_change(coins: List[int], amount: int, i: int = 0) -> List[int]:
    if i == len(coins):
        return []
    count: int = amount // coins[i]
    rest: int = amount % coins[i]
    return [count] + count_change(coins, rest, i + 1)


def main() -> None:
    coins: List[int] = list(map(int, input().split()))
    amount: int = int(input())
    result: List[int] = count_change(coins, amount)
    print(*result)


if __name__ == "__main__":
    main()
