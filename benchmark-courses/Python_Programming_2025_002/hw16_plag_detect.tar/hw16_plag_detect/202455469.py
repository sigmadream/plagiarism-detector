def change(coins, amount):
    """Calculate the number of coins needed."""
    count = []
    for i in coins:
        left = amount % i
        c = (amount - left) // i
        count.append(c)
        amount = left
    return count

def main():
    """Main function."""
    coins = input().split()
    coins = [int(i) for i in coins]
    amount = int(input())
    result = change(coins, amount)
    print(" ".join(str(x) for x in result))

if __name__ == "__main__":
    main()
