def coin(b: list[str], c: int) -> str:
    result = []
    for i in range(len(b)):
        n = c // int(b[i])
        result.append(str(n))
        c %= int(b[i])
    return " ".join(result)

a = input()
b = a.split()
c = int(input())
print(coin(b, c))
