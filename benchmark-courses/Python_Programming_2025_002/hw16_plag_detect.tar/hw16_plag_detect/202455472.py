def count_coins(change, coins, index=0, result=None):
    '''Function to count coins'''
    if result is None:
        result=[]
    if index == len(coins):
        return result
    coin = coins[index]
    count = change//coin
    result.append(count)
    return count_coins(change-count*coin, coins, index+1, result)
coin_types = list(map(int,input().split()))
changes=int(input())
coin_counts = count_coins(changes, coin_types)
print(' '.join(map(str,coin_counts)))
