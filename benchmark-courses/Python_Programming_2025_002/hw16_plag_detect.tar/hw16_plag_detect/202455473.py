def count_coins(
    coins: list[int],
    change: int,
    i: int = 0,
    result: list[int] | None = None
) -> list[int]:
    """Recursively counts the number of coins needed to make the change."""
    if result is None:
        result = []
    if i == len(coins):
        return result
    result.append(change // coins[i])
    return count_coins(coins, change % coins[i], i + 1, result)


def main() -> None:
    """Reads coin denominations and change amount, then prints coin usage."""
    coins = list(map(int, input().split()))
    change = int(input())
    result = count_coins(coins, change)
    print(*result)

if __name__ == "__main__":
    main()
