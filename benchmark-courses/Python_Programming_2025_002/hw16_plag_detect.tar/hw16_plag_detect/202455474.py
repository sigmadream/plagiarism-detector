def calc(coins: list[int], change: int) -> str:
    """
    Recursively calculates the number of coins needed for each denomination to make up the change.
    Args:
        coins (list): A list of coin denominations in decreasing order.
        change (int): The total amount of change to be given.
    Returns:
        str: A space-separated string of coin counts for each denomination.
        Each count represents the number of coins used from the corresponding denomination.
    """
    return '' if not coins else str(change // coins[0]) + ' ' + calc(coins[1:], change % coins[0])


def main() -> None:
    """
    Reads coin denominations and the change amount from the user,
    calculates the number of coins needed for each denomination,
    and prints the result as a space-separated string.
    Input:
        - A line of integers representing coin denominations (separated by spaces).
        - An integer representing the total amount of change.
    Output:
        - A space-separated string showing the count of coins for each denomination.
    """
    print(calc(list(map(int, input().split())),int(input()))[:-1])


if __name__ == "__main__":
    main()
