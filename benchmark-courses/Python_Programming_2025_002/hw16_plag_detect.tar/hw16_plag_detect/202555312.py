def get_change(total: int, c_list: list[int]) -> list[int]:
    "recursive change calculation function"
    return [total // c_list[0]] + get_change(total % c_list[0], c_list[1:]) if c_list else []

def main() -> None:
    "main"
    coin_list_raw: list[str] = input().split()
    coin_list_value: list[int] = []

    for value in coin_list_raw:
        coin_list_value.append(int(value))

    total_sum: int = int(input())

    coin_list_amount: list[int] = get_change(total_sum, coin_list_value)

    for value in coin_list_amount:
        print(value, end = ' ')


if __name__ == "__main__":
    main()
