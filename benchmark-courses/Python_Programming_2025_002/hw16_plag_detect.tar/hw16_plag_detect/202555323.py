coins = list(map(int, input().split()))
amount = int(input())

def change_recur(coins, amount):
    if not coins:
        return []
    count = amount // coins[0]
    remainder = amount % coins[0]
    return [count] + change_recur(coins[1:], remainder)

result = change_recur(coins, amount)
print(' '.join(map(str, result)))