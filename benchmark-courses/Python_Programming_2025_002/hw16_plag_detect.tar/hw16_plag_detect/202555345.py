def make_change(coins: list[int], change: int, index = 0) -> list:
    """Recursive funciton to count the coins"""
    if index == len(coins) - 1:
        count = change // coins[index]
        return [count]
    
    count = change // coins[index]
    remaining = change % coins[index]
    
    rest = make_change(coins, remaining, index + 1)
    
    return [count] + rest

coins = list(map(int, input().split()))
change = int(input())

print(*make_change(coins, change))
