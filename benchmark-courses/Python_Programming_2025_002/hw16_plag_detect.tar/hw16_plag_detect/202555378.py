def calculate_coins(coins: list, amount: int) -> list:
    if len(coins) == 0 or amount == 0:
        return []
    
    current_coin = coins[0]
    num_coins = amount // current_coin
    
    remaining = amount - (num_coins * current_coin)
    result = [num_coins] + calculate_coins(coins[1:], remaining)
    return result

if __name__ == "__main__":
    coin_input = input()
    coins = [int(x) for x in coin_input.split()]
    amount = int(input())
    result = calculate_coins(coins, amount)
    print(" ".join(map(str, result)))