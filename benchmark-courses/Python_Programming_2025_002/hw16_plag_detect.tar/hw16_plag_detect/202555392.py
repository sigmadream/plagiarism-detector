def change(to_give: int, coin: list, idx: int = 0) -> list:
    """change to coins"""
    if idx >= len(coin):
        return []
    num = to_give // coin[idx]
    remainder = to_give % coin[idx]
    return [num] + change(remainder, coin, idx + 1)
coins = list(map(int, input().split()))
print(*change(int(input()), coins))
