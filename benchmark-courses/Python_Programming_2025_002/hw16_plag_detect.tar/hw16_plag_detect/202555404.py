def make_change(coins: list[int], amount: int, index: int = 0) -> list[int]:
    """
    Recursively calculate the minimum number of coins needed to make change.
    
    Args:
        coins: List of coin denominations in decreasing order
        amount: Remaining amount to make change for
        index: Current coin index being considered
        
    Returns:
        List containing the count of each coin denomination used
    """
    # Base case: no more coins to consider
    if index >= len(coins):
        return []
    
    # Calculate how many of the current coin we need
    current_coin: int = coins[index]
    coin_count: int = amount // current_coin
    remaining: int = amount % current_coin
    
    # Recursively solve for the remaining amount with smaller coins
    result: list[int] = [coin_count]
    result.extend(make_change(coins, remaining, index + 1))
    
    return result

def main() -> None:
    # Read input
    coins: list[int] = list(map(int, input().split()))
    amount: int = int(input())
    
    # Get the coin counts
    coin_counts: list[int] = make_change(coins, amount)
    
    # Print result
    print(' '.join(map(str, coin_counts)))

if __name__ == "__main__":
    main()