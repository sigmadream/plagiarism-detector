from typing import List

def calculate_coins_recursive(coins: List[int], amount: int, index: int = 0) -> List[int]:
    """
    Recursively calculates the minimum number of coins required for the given amount.
    
    :param coins: List of coin denominations in descending order.
    :param amount: Remaining amount to make change for.
    :param index: Current index in the coins list.
    :return: List of counts of coins used for each denomination.
    """
    if index >= len(coins):
        return []

    coin = coins[index]
    count = amount // coin
    remainder = amount % coin

    return [count] + calculate_coins_recursive(coins, remainder, index + 1)

def main() -> None:
    # Read input
    try:
        coin_input = input().strip()
        amount_input = input().strip()

        coins = list(map(int, coin_input.split()))
        amount = int(amount_input)

        # Calculate coin counts
        result = calculate_coins_recursive(coins, amount)

        # Print result
        print(" ".join(map(str, result)))

    except ValueError:
        print("Invalid input. Please enter integers only.")

if __name__ == "__main__":
    main()