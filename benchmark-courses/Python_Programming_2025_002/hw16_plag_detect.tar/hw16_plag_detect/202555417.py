money_type: list[str] = input().split()
change : int = int(input())
def change_calc(m:int,n:list[str],i:int=0, result: list[str] = []) -> list[str]:
    """Calculation of the change in the other money types"""
    if i>=len(n):
        return result
    result.append(str(m//int(n[i])))
    return change_calc(m % int(n[i]),n, i+1) 
if __name__ == "__main__":
    print(" ".join(change_calc(change,money_type)))
