def compute_coins(coins: list[int], amount: int) -> list[int]:
    """
    Recursively computes the minimum number of coins needed for a given amount.
    
    Args:
        coins (list[int]): List of coin denominations (in descending order).
        amount (int): Total amount of change to give.

    Returns:
        list[int]: List of coin counts for each denomination.
    """
    if not coins:
        return []

    current_coin = coins[0]
    count = amount // current_coin
    remaining = amount % current_coin

    return [count] + compute_coins(coins[1:], remaining)


def main() -> None:
    """
    Reads coin denominations and change amount from input,
    calculates the minimum number of coins needed,
    and prints the result.
    """
    coin_input = input().strip()
    amount_input = input().strip()

    coins = list(map(int, coin_input.split()))
    amount = int(amount_input)

    result = compute_coins(coins, amount)
    print(" ".join(map(str, result)))


if __name__ == "__main__":
    main()
