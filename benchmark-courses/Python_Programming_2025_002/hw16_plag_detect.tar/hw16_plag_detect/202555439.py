coins: list[str] = input().split()
total: int = int(input())

def coin_exchange(subtotal: int, idx: int = 0, changes: str = "") -> str:
    """
    Recursively append number of smaller coins to the number of larger coins
    """
    if idx >= len(coins):
        return changes
    curr_coin: int = int(coins[idx])
    idx += 1
    if subtotal == 0 or subtotal < curr_coin:
        changes += "0 "
        return coin_exchange(subtotal, idx, changes)
    changes += f"{subtotal // curr_coin} "
    return coin_exchange(subtotal % curr_coin, idx, changes)

print(coin_exchange(total))
