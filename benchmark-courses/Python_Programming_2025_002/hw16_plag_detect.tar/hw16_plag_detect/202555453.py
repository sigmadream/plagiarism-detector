def calc_min_total(total: int, idx: int, coins: list[int]) -> int:
    """
    calc_min_change return possible min total
    """
    if idx >= len(coins):
        return

    print(total // coins[idx], end=" ")

    calc_min_total(total - coins[idx] * (total // coins[idx]), idx + 1, coins)


def main() -> None:
    """
    main code
    """

    coins: list[int] = list(map(int, input().split()))
    total: int = int(input())

    calc_min_total(total, 0, coins)


if __name__ == "__main__":
    main()
