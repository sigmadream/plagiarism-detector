def count_claps_up_to(n):
    """
    Count the total number of 'claps' in the numbers from 1 to n.
    
    A 'clap' is defined as the occurrence of the digits 3, 6, or 9
    in any position of the number.
    The function uses a recursive approach to calculate the total
    claps contributed by each digit position.
    
    Parameters:
    n (int): The upper limit of the range (inclusive) for which to count claps.
    
    Returns:
    int: The total number of claps from 1 to n.
    """
    def recursive_count(n, position_value):
        if position_value > n:
            return 0  # Base case: if position exceeds n, return 0
        digit = (n // position_value) % 10
        higher = n // (position_value * 10)
        lower = n % position_value
        # Calculate claps contributed by completed cycles of 10 digits for this position
        total_claps = higher * 3 * position_value
        # Add claps for the current digit's contribution
        if digit > 3:
            total_claps += position_value
        if digit > 6:
            total_claps += position_value
        if digit in [3, 6, 9]:
            total_claps += lower + 1
        # Recursive call for the next position value (tens, hundreds, etc.)
        return total_claps + recursive_count(n, position_value * 10)
    return recursive_count(n, 1)  # Start recursion with position_value = 1

a, b = map(int, input().split())
result = count_claps_up_to(b) - count_claps_up_to(a - 1)
print(result)
