def th_amount(num):
    "check how many three chars in the num"
    st_num = str(num)
    re = 0
    for _ in st_num:
        if _ in "369":
            re += 1
    return re

if __name__ == "__main__":
    a, b = map(int, input().split())
    N = 0
    for i in range(a, b+1):
        N += th_amount(i)
    print(N)
