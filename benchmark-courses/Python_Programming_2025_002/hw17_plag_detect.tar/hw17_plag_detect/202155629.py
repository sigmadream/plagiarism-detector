l,u=map(int,input().split())
print(len([1 for n in range(l,u+1) for d in str(n) if d in'369']))
