a,b=map(int,input().split())
print(sum([c in'369'for i in range(a,b+1) for c in str(i) if c in'369']))
