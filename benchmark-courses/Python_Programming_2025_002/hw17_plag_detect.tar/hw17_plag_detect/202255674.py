a, b = map(int, input().split())
print(sum([str(i).count(digit) for i in range(a, b + 1) for digit in '369' if digit in str(i)]))
