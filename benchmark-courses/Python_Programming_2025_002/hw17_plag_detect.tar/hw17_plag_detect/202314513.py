def count_claps(start: int, end: int) -> int:
    """Count the total number of claps in Sam-Yuk-Gu game from start to end."""
    return sum(1 for i in range(start, end + 1) for ch in str(i) if ch in '369')


def main() -> None:
    """Read input and print total number of claps between two integers."""
    start_num, end_num = map(int, input().split())
    print(count_claps(start_num, end_num))


if __name__ == "__main__":
    main()
