def count_claps_in_number(number):
    clap_count = 0
    for digit in str(number):
        if digit in ['3', '6', '9']:
            clap_count += 1
    return clap_count

if __name__ == "__main__":
    a, b = map(int, input().split())
    total_claps = sum([
        count_claps_in_number(i)
        for i in range(a, b + 1)
        if any(d in '369' for d in str(i))
    ])
    print(total_claps)
