a,b=map(int,input().split())
print(sum([sum(c in'369'for c in str(i))for i in range(a,b+1)if any(c in'369'for c in str(i))]))
