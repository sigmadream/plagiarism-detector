a,b=map(int,input().split())
print(sum(str(i).count(c)for i in range(a,b+1)for c in'369'))
