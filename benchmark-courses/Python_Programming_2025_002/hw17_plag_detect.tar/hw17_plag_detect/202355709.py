def clap(a, b):
    """3 6 9 찾아 박수치기"""
    num_list = [str(num) for num in range(a, b + 1)]
    cnt = 0
    for i in num_list:
        for j in range(len(i)):
            if i[j] in ("3","6","9"):
                cnt += 1
    return cnt

numRange = list(map(int, input().split()))
print(clap(numRange[0], numRange[1]))
