def main():
    a, b = map(int, input().split())
    s = 0
    for i in range(a, b + 1):
        for d in str(i):
            if d in '369':
                s += 1
    print(s)

if __name__ == '__main__':
    main()