def clap(a,b):
    """Sam-Yuk-Gu Game"""
    return sum(c in'369'for i in range(a,b+1)for c in str(i))
def main():
    """Main function"""
    a,b=map(int,input().split())
    print(clap(a,b))

if __name__ == "__main__":
    main()
