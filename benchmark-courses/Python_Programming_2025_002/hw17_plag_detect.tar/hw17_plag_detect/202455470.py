a,b=map(int,input().split())
print(sum(d in'369'for i in range(a,b+1)for d in str(i)))