a, b = map(int,input().split())
ls1 = list(range(a,b+1))
def qsort(ls):
    '''Function to sort'''
    count  = sum((1 for num in ls for d in str(num) if d in '369'))
    return count
if __name__ == "__main__":
    print(qsort(ls1))
