def count_claps(a, b):
    return sum([str(i).count('3') + str(i).count('6') + str(i).count('9') for i in range(a, b + 1)])

if __name__ == "__main__":
    a, b = map(int, input().split())
    print(count_claps(a, b))
