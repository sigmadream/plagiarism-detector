a,b = map(int,input().split())
l = [1 for i in range(a,b+1) for j in str(i) if int(j) > 0 and int(j) % 3 == 0]
print(sum(l))
