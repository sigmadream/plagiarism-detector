raw_input = input().split()
included_numbers = list(range(int(raw_input[0]), int(raw_input[1]) + 1))

total_claps = 0

while len(included_numbers) > 0:
    for n in included_numbers:
        if n % 10 in [3, 6, 9]:
            total_claps += 1
    included_numbers = [n // 10 for n in included_numbers if n > 0]

print(total_claps)
