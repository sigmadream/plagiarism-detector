a, b = map(int, input().split())

clap_count = 0

for num in range(a, b + 1):
    num_str = str(num)
    clap_count += sum(1 for digit in num_str if digit in '369')


print(clap_count)
