def numbers(a, b):
    ls = [i for i in range(a, b + 1)]
    filter = [i for i in ls if "3" in str(i) or "6" in str(i) or "9" in str(i)]
    return filter
def claps(numbers: list[int], count = 0):
    for i in numbers:
        if "3" in str(i): count+=(list(str(i)).count("3"))
        if "6" in str(i): count+=(list(str(i)).count("6"))
        if "9" in str(i): count+=(list(str(i)).count("9"))
    return count
a, b = map(int, input().split())
print(claps(numbers(a, b)))
