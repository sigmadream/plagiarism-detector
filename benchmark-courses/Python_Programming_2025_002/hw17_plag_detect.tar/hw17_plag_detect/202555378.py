def count_claps(num):
    num_str = str(num)
    return num_str.count('3') + num_str.count('6') + num_str.count('9')

if __name__ =="__main__":
 a,b =map(int, input().split())

 total_clap=sum([count_claps(num) for num in range(a, b+1) if count_claps(num) > 0])
 print(total_clap)