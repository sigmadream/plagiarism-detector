a, b = map(int, input().split())
ls = [str(i) for i in range(a, b+1)]
count = [i.count("3")+i.count("6")+i.count("9")for i in ls if any(t in i for t in ("3", "6", "9"))]
print(sum(count))
