def numberofclaps(num):
    """in the game sam, yuk,gu when a number appears with
      the the the digits '3','6','9' clap is made.
        Here we are counting the number of claps in a given range of numbers """
    return str(num).count("3") + str(num).count("6") + str(num).count("9")
if __name__=="__main__":

    # Read input: two integers a and b separated by a space
    a, b = map(int, input().split())
    
    # Use list comprehension with a filter to count claps
    # The filter is always True since we want to include all numbers in range
    # but count their claps
    total_claps = sum([numberofclaps(num) for num in range(a, b+1)])
    
    # Print the result
    print(total_claps)