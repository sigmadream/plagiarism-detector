a, b = map(int, input().split())
print(sum([1 for n in range(a, b + 1) for c in str(n) if c in'369']))