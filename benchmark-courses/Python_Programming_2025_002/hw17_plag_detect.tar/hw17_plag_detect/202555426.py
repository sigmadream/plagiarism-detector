def quicksort(arr):
    """Recursively sorts the list using the quicksort algorithm"""
    if len(arr) <= 1:
        return arr
    pivot = arr[0]
    left = [x for x in arr[1:] if x <= pivot]
    right = [x for x in arr[1:] if x > pivot]
    return quicksort(left) + [pivot] + quicksort(right)

def count_claps(n):
    """Count claps in 369"""
    return sum(1 for d in str(n) if d in '369')

if __name__ == "__main__":
    a, b = map(int, input().split())
    nums = list(range(a, b + 1))
    total_claps = sum(count_claps(n) for n in nums if count_claps(n) > 0)

    print(total_claps)
    