line = input().split()
print(sum([1 for c in "".join([str(i) for i in range(int(line[0]),int(line[1])+1)]) if c in ["3","6","9"]]))
