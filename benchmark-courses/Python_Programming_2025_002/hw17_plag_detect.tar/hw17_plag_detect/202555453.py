a,b=map(int,input().split())
print(sum([str(i).count("3") + str(i).count("6") + str(i).count("9") for i in range(a, b + 1) if "3" in str(i) or "6" in str(i) or "9" in str(i)]))
