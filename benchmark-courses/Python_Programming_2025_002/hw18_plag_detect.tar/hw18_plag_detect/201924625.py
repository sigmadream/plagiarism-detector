def quicksort_points(points, axis):
    """
    Sorts a list of 2D points using quicksort based on the specified axis ('x' or 'y').
    
    Parameters:
        points (list of tuple): List of (x, y) coordinate tuples to sort.
        axis (str): Sorting axis - 'x' for x-coordinate, 'y' for y-coordinate.
    
    Returns:
        list of tuple: The sorted list of points.
    
    Notes:
        - For points with equal values along the sorting axis, ties are broken by the other axis.
        - This ensures a stable and deterministic sort even when coordinates are equal.
    """
    if len(points) <= 1:
        return points
    sort_index = 0 if axis == 'x' else 1
    pivot = points[0]
    # Points less than or equal to the pivot (based on tie-breaker)
    left = [point for point in points[1:] if ((point[sort_index] < pivot[sort_index]) or (point[sort_index] == pivot[sort_index] and point[1-sort_index] < pivot[1-sort_index]))]
    # Points greater than the pivot (based on tie-breaker)
    right = [point for point in points[1:] if ((point[sort_index] > pivot[sort_index]) or (point[sort_index] == pivot[sort_index] and point[1-sort_index] >= pivot[1-sort_index]))]
    return quicksort_points(left, axis) + [pivot] + quicksort_points(right, axis)

# Read sorting axis and indices
axis_input, count_str, index_str = input().split()
num_points = int(count_str)
target_index = int(index_str) - 1  # Convert to 0-based index
# Read points
points = []
for _ in range(num_points):
    x, y = map(int, input().split())
    points.append((x, y))
# Sort points and retrieve the target one
sorted_points = quicksort_points(points, axis_input)
# Print the target point
print(sorted_points[target_index])
