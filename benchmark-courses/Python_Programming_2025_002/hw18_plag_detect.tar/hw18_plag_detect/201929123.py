def xqsort(ns):
    "qsorting according to x value"
    if len(ns) <= 1:
        return ns

    pivot = ns[0]
    lli = [n for n in ns[1:] if n[0] < pivot[0]]
    mli = [n for n in ns if n[0] == pivot[0]]
    rli = [n for n in ns[1:] if n[0] > pivot[0]]
    return xqsort(lli) + mli + xqsort(rli)

def yqsort(ns):
    "qsorting according to y value"
    if len(ns) <= 1:
        return ns

    pivot = ns[0]
    lli = [n for n in ns[1:] if n[1] < pivot[1]]
    mli = [n for n in ns if n[1] == pivot[1]]
    rli = [n for n in ns[1:] if n[1] > pivot[1]]
    return yqsort(lli) + mli + yqsort(rli)

if __name__ == "__main__":
    line = input().split()
    criteria = line[0]
    num, loc = map(int, line[1:])
    cord = []
    for _ in range(num):
        x, y = map(int,input().split())
        cord.append((x,y))

    if criteria == "x":
        tx = xqsort(cord)
        print(tx[loc-1])
    if criteria == "y":
        ty = yqsort(cord)
        print(ty[loc-1])
