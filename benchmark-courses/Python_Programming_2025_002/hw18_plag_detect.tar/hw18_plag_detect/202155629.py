def q(a,k):
 if len(a)<=1:return a
 p,*r=a
 return q([n for n in r if n[k]<p[k]],k)+[p]+[n for n in r if n[k]==p[k]]+q([n for n in r if n[k]>p[k]],k)
x,m,n=input().split()
a=[tuple(map(int,input().split()))for _ in range(int(m))]
r=q(a,0 if x<'y'else 1)[int(n)-1]
print(f"({r[0]}, {r[1]})")