def stable_quick_sort(arr, key):
    if len(arr) <= 1:
        return arr
    pivot_key = key(arr[0])
    lt = [x for x in arr if key(x) < pivot_key]
    eq = [x for x in arr if key(x) == pivot_key]
    gt = [x for x in arr if key(x) > pivot_key]
    return stable_quick_sort(lt, key) + eq + stable_quick_sort(gt, key)

s, m, n = input().split()
m, n = int(m), int(n)
points = [tuple(map(int, input().split())) for _ in range(m)]

key = (lambda p: p[0]) if s == 'x' else (lambda p: p[1])

sorted_points = stable_quick_sort(points, key)
print(sorted_points[n - 1])
