import sys
lines = sys.stdin.read().split()
c = lines[0]
m = int(lines[1])
n = int(lines[2])
coords = [(int(lines[i]), int(lines[i+1])) for i in range(3, len(lines), 2)]
print(sorted(coords, key=lambda x: x[0] if c == 'x' else x[1])[n-1])
