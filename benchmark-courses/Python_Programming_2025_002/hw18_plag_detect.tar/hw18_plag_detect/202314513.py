import sys

def stable_sort(points, index):
    """
    Recursively performs a stable quicksort on a list of points.
    Sorts based on the coordinate at the specified index (0 for x, 1 for y).
    """
    if len(points) < 2:
        return points
    pivot = points[0][index]
    less = [pt for pt in points[1:] if pt[index] < pivot]
    equal = [pt for pt in points if pt[index] == pivot]
    greater = [pt for pt in points[1:] if pt[index] > pivot]
    return stable_sort(less, index) + equal + stable_sort(greater, index)

def main():
    """
    Reads input, sorts coordinates based on the given axis, 
    and prints the nth point in (x, y) format.
    """
    lines = sys.stdin.read().splitlines()
    axis_str, m_str, n_str = lines[0].split()
    axis = 0 if axis_str == 'x' else 1
    m = int(m_str)
    n = int(n_str)
    points = [tuple(map(int, line.split())) for line in lines[1:m+1]]
    sorted_points = stable_sort(points, axis)
    result = sorted_points[n - 1]
    print(f"({result[0]}, {result[1]})")

if __name__ == "__main__":
    main()
