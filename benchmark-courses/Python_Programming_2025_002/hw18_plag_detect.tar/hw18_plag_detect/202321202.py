def sqsort(points, key):
    if len(points) <= 1:
        return points
    p = points[0]
    lt = [pt for pt in points[1:] if pt[key] < p[key]]
    eq = [pt for pt in points[1:] if pt[key] == p[key]]
    ge = [pt for pt in points[1:] if pt[key] > p[key]]
    return sqsort(lt, key) + [p] + eq + sqsort(ge, key)

if __name__ == "__main__":
    import sys
    lines = sys.stdin.read().splitlines()
    crit, m, n = lines[0].split()
    m, n = int(m), int(n)
    points = [tuple(map(int, line.split())) for line in lines[1:m+1]]
    idx = 0 if crit == 'x' else 1
    sorted_points = sqsort(points, idx)
    print(f"({sorted_points[n-1][0]}, {sorted_points[n-1][1]})")
