def stable_qsort(pts, k):
    if len(pts) <= 1:
        return pts
    p = pts[0][k]
    lt = [pt for pt in pts[1:] if pt[k] < p]
    eq = [pt for pt in pts[1:] if pt[k] == p]
    gt = [pt for pt in pts[1:] if pt[k] > p]
    return stable_qsort(lt, k) + [pts[0]] + stable_qsort(eq, k) + stable_qsort(gt, k)

if __name__ == "__main__":
    c, m, n = input().split()
    m, n = int(m), int(n)
    points = [tuple(map(int, input().split())) for _ in range(m)]
    idx = 0 if c == 'x' else 1
    sorted_pts = stable_qsort(points, idx)
    print(f"({sorted_pts[n-1][0]}, {sorted_pts[n-1][1]})")
