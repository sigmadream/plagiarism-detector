c,n,k=input().split();l=[tuple(map(int,input().split()))for _ in range(int(n))];p=sorted(l,key=lambda x:x[c=='y'])[int(k)-1];print(f"({p[0]}, {p[1]})")
