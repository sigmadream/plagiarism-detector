def s(q,k):
    """"""
    return s([p for p in q[1:]if p[k]<q[0][k]],k)+[p for p in q if p[k]==q[0][k]]+s([p for p in q[1:]if p[k]>q[0][k]],k)if len(q)>1 else q
c,m,n=input().split();p=[tuple(map(int,input().split()))for _ in range(int(m))]
k=0 if c=='x'else 1
print(f"({s(p,k)[int(n)-1][0]}, {s(p,k)[int(n)-1][1]})")
