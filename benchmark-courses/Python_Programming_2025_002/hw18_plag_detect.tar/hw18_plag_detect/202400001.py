def qsort(a, k):
    if len(a) <= 1: return a
    p = a[0][k]
    lt = [x for x in a[1:] if x[k] < p]
    eq = [x for x in a if x[k] == p]
    gt = [x for x in a[1:] if x[k] > p]
    return qsort(lt, k) + eq + qsort(gt, k)

def main():
    c, m, n = input().split()
    [m, n] = map(int, [m, n])
    arr = list()
    for _ in range(m):
        x, y = map(int, input().split())
        arr.append([x, y])
    idx = 0 if c == 'x' else 1
    srt = qsort(arr, idx)
    print(f"({srt[n - 1][0]}, {srt[n - 1][1]})")

if __name__ == '__main__':
    main()