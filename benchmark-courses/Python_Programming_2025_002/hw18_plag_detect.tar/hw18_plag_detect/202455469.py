import sys

lines = sys.stdin.read().splitlines()
crit, m, n = lines[0].split()
m, n = int(m), int(n)
pts = [tuple(map(int, line.split())) for line in lines[1:m+1]]

sorted_pts = sorted(pts, key=lambda p: p[0] if crit == 'x' else p[1])

print(f"({sorted_pts[n-1][0]}, {sorted_pts[n-1][1]})")
