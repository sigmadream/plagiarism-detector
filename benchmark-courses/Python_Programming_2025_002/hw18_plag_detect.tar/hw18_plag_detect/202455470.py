def srt(lst, idx):
    if len(lst) <= 1:
        return lst
    p = lst[0]
    l = [x for x in lst[1:] if x[idx] < p[idx]]
    e = [p] + [x for x in lst[1:] if x[idx] == p[idx]]
    g = [x for x in lst[1:] if x[idx] > p[idx]]
    return srt(l, idx) + e + srt(g, idx)

if __name__ == "__main__":
    c, a, b = input().strip().split()
    pts = []
    for _ in range(int(a)):
        u, v = map(int, input().split())
        pts.append((u, v))
    k = 0 if c == 'x' else 1
    res = srt(pts, k)
    ans = res[int(b)-1]
    print(f"({ans[0]}, {ans[1]})")
