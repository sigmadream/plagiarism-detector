def qsort(ns,key):
    '''Function to sort'''
    if len(ns) <= 1:
        return ns
    p = ns[0]
    lt = [n for n in ns[1:] if key(n) < key(p)]
    gt = [n for n in ns[1:] if key(n) > key(p)]
    eq = [n for n in ns[1:] if key(n) == key(p)]
    return qsort(lt,key) + [p] + eq + qsort(gt, key)
if __name__ == "__main__":
    n, m, k = input().split()
    KEY_INDEX = 0 if n == "x" else 1
    m = int(m)
    k = int(k)
    points = [tuple(map(int, input().split())) for _ in range(m)]
    key_func = lambda p: p[KEY_INDEX]
    tsl = qsort(points, key =key_func)
    sort = tsl[k - 1]
    print(sort)
