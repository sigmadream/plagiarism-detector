def q(s):
 return s if len(s)<2 else q([x for x in s[1:] if x[k]<s[0][k]]) + [s[0]] + \
        [x for x in s[1:] if x[k]==s[0][k]] + q([x for x in s[1:] if x[k]>s[0][k]])

c,m,n=input().split();m,n=int(m),int(n)
k=0 if c=='x'else 1
t=[tuple(map(int,input().split()))for _ in range(m)]
print(f'({q(t)[n-1][0]}, {q(t)[n-1][1]})')