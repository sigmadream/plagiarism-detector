def qsort(criterion, ns):
    ""
    if len(ns) <= 1:
        return ns
    p = ns[0]
    lt = [n for n in ns[1:] if n[criterion] < p[criterion]]
    ge = [n for n in ns[1:] if n[criterion] >= p[criterion]]
    return qsort(criterion, lt) + [p] + qsort(criterion, ge)

if __name__ == "__main__":
    ""
    raw_input = input().split()
    CRITERION = 0 if raw_input[0] == "x" else 1
    number_of_coordinates = int(raw_input[1])
    target_index = int(raw_input[2]) - 1
    coordinates = []
    for n in range(number_of_coordinates):
        coordinate_input = input().split()
        coordinates.append((int(coordinate_input[0]), int(coordinate_input[1])))
    sorted_coordinates = qsort(CRITERION, coordinates)

    print(sorted_coordinates[target_index])
