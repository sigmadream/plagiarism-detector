def q(ns, k):
    if len(ns) < 2: return ns
    p = ns[0]
    lt = [x for x in ns[1:] if x[k] < p[k]]
    eq = [x for x in ns if x[k] == p[k]]
    gt = [x for x in ns[1:] if x[k] > p[k]]
    return q(lt, k) + eq + q(gt, k)

if __name__ == "__main__":
    c, m, n = input().split()
    pts = [tuple(map(int, input().split())) for _ in range(int(m))]
    k = 0 if c == 'x' else 1
    print(f"({q(pts, k)[int(n)-1][0]}, {q(pts, k)[int(n)-1][1]})")