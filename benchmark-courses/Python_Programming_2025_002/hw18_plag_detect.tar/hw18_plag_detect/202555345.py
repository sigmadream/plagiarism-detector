line = input().split()
a, b = map(int, line[1:])
arr = []
for i in range(a):
    t = tuple(map(int, input().split()))
    arr.append(t)

idx = 0 if line[0] == "x" else 1

def qsort(ns: list[tuple]):
    if len(ns) <= 1:
        return ns
    p = ns[0]
    lt = [n for n in ns[1:] if n[idx] < p[idx]]
    ge = [n for n in ns[1:] if n[idx] > p[idx]]
    eq = [n for n in ns if n[idx] == p[idx]]
    return qsort(lt) + eq + qsort(ge)

print(qsort(arr)[b - 1])