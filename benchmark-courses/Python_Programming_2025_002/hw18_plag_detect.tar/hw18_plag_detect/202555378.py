def sqsort(points, criterion):
    if len(points) <= 1:
        return points
    
    pivot = points[0]

    if criterion == 'x':
        left = [p for p in points[1:] if p[0] < pivot[0]]
        equal = [p for p in points[1:] if p[0] == pivot[0]]
        right = [p for p in points[1:] if p[0] > pivot[0]]
    else:
        left = [p for p in points[1:] if p[1] < pivot[1]]
        equal = [p for p in points[1:] if p[1] == pivot[1]]
        right = [p for p in points[1:] if p[1] > pivot[1]]
    
    return sqsort(left, criterion) + [pivot] + equal + sqsort(right, criterion)

if __name__ == "__main__":
    
    first_line = input().split()
    criterion = first_line[0]  
    m = int(first_line[1])     
    n = int(first_line[2])     
   
    points = []
    for _ in range(m):
        x, y = map(int, input().split())
        points.append((x, y))

    sorted_points = sqsort(points, criterion)
    nth_point = sorted_points[n-1]  
    print(f"({nth_point[0]}, {nth_point[1]})")