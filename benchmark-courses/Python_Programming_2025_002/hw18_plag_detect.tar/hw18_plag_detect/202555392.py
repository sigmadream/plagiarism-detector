def quicksort(target, ct):
    """stable quicksort"""
    if len(target) <= 1:
        return target
    mid = len(target) // 2
    pivot = target[mid]
    smaller = [value for i, value in enumerate(target) if
               i != mid and value[ct] < pivot[ct] or i != mid and value[ct] == pivot[ct] and i<mid]
    greater = [value for i, value in enumerate(target) if
               i != mid and value[ct] > pivot[ct] or i != mid and value[ct] == pivot[ct] and i>mid]
    return quicksort(smaller, ct) + [pivot] + quicksort(greater, ct)

CRITERIA, m, n = input().split()
CRITERIA = 0 if CRITERIA == "x" else 1
m, n = int(m), int(n)
elements = [tuple(map(int, input().split())) for _ in range(m)]
print(quicksort(elements, CRITERIA)[n - 1])
