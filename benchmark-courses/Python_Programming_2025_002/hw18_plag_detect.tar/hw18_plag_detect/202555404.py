def stable_qsort(points, idx):
    """Stable quicksort implementation that sorts based on the specified index (0 for x, 1 for y)."""
    if len(points) <= 1:
        return points
    
    pivot = points[0]
    # Use list comprehension with indices to maintain stability
    less = [p for i, p in enumerate(points[1:], 1) if p[idx] < pivot[idx]]
    equal = [p for i, p in enumerate(points[1:], 1) if p[idx] == pivot[idx]]
    greater = [p for i, p in enumerate(points[1:], 1) if p[idx] > pivot[idx]]
    
    return stable_qsort(less, idx) + [pivot] + equal + stable_qsort(greater, idx)

if __name__ == "__main__":
    # Read input
    criteria, m, n = input().split()
    m, n = int(m), int(n)
    
    # Read points
    points = []
    for _ in range(m):
        x, y = map(int, input().split())
        points.append((x, y))
    
    # Sort based on criteria
    idx = 0 if criteria == 'x' else 1
    sorted_points = stable_qsort(points, idx)
    
    # Print the nth point
    nth_point = sorted_points[n-1]
    print(f"({nth_point[0]}, {nth_point[1]})")