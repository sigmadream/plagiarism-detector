def stable_quick_sort(points, key_index):
    if not points:
        return []
    pivot = points[0]
    less = [pt for pt in points[1:] if pt[key_index] < pivot[key_index]]
    equal = [pt for pt in points if pt[key_index] == pivot[key_index]]
    greater = [pt for pt in points[1:] if pt[key_index] > pivot[key_index]]
    return stable_quick_sort(less, key_index) + equal + stable_quick_sort(greater, key_index)

# Read input
criterion, m, n = input().split()
m = int(m)
n = int(n)

# Read m coordinates
points = [tuple(map(int, input().split())) for _ in range(m)]

# Determine key index for sorting (0 for x, 1 for y)
key_index = 0 if criterion == 'x' else 1

# Perform stable sort
sorted_points = stable_quick_sort(points, key_index)

# Output the n-th point (1-based indexing)
nth_point = sorted_points[n - 1]
print(f"({nth_point[0]}, {nth_point[1]})")