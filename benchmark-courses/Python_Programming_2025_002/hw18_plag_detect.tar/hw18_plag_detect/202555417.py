def q(s,c):
 if len(s)<2:return s
 p=s[0];i=0if c<'y'else 1
 l=[x for x in s[1:]if x[i]<p[i]]
 e=[x for x in s[1:]if x[i]==p[i]]
 g=[x for x in s[1:]if x[i]>p[i]]
 return q(l,c)+[p]+e+q(g,c)
c,m,n=input().split();m=int(m);n=int(n)
t=[tuple(map(int,input().split()))for _ in range(m)]
print(q(t,c)[n-1])
