def stable_quicksort(arr, key):
    """Performs a stable quicksort on arr using the specified key ('x' or 'y')."""
    if len(arr) <= 1:
        return arr
    pivot = arr[0]
    k = 0 if key == 'x' else 1
    left = [p for p in arr[1:] if p[k] < pivot[k]]
    mid = [p for p in arr if p[k] == pivot[k]]
    right = [p for p in arr[1:] if p[k] > pivot[k]]
    return stable_quicksort(left, key) + mid + stable_quicksort(right, key)


if __name__ == "__main__":
    c, m, n = input().split()
    m, n = int(m), int(n)
    points = [tuple(map(int, input().split())) for _ in range(m)]
    sorted_points = stable_quicksort(points, c)
    print(f"({sorted_points[n-1][0]}, {sorted_points[n-1][1]})")
