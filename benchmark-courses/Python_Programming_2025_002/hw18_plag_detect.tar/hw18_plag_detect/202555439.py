def comparator(a,b,comp): return int(a[0])<int(b[0]) if comp=='x' else int(a[1])<int(b[1])
def stable_qsort(arr,comp):
    if len(arr)<=1: return arr
    p=arr[0]
    return stable_qsort([v for i,v in enumerate(arr) if i!=0 and (comparator(v,p,comp)or(not comparator(p,v,comp) and i<0))],comp)+[p]+stable_qsort([v for i,v in enumerate(arr) if i!=0 and (comparator(p,v,comp)or(not comparator(v,p,comp) and i>0))],comp)
line=input().split()
x,y=stable_qsort([input().split() for i in range(int(line[1]))],line[0])[int(line[2])-1]
print(f'({x}, {y})')