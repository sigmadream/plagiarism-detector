def take_input():
    """
    Reads a line of input from the user, splits it into integers, 
    and returns a list of those integers.

    Returns:
        list: A list of integers parsed from the input line.
    """
    # Read the line and split it into integers
    return list(map(int, input().split()))

# Example usage
arr1 = take_input()  # Get the first array of integers from user input
arr2 = take_input()  # Get the second array of integers from user input

n = len(arr1)  # Length of the first array
m = len(arr2)  # Length of the second array

if n > m:
    diff = n - m  # Calculate the difference in lengths
    # Print the extra elements from the first array
    for i in range(diff):
        print(arr1[i], end=" ")
    # Print the sum of the overlapping elements
    for i in range(m):
        print(arr1[i + diff] + arr2[i], end=" ")
else:
    diff = m - n  # Calculate the difference in lengths
    # Print the extra elements from the second array
    for i in range(diff):
        print(arr2[i], end=" ")
    # Print the sum of the overlapping elements
    for i in range(n):
        print(arr1[i] + arr2[i + diff], end=" ")
