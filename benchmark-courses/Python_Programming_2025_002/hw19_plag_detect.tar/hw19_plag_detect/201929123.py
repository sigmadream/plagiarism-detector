def add_polynomial(n1, n2) :
    """add polynomials"""
    if len(n1) > len(n2):
        indexes = n1
        for (i,v) in enumerate(n2[::-1]):
            indexes[-i-1] += v
    else:
        indexes = n2
        for (i,v) in enumerate(n1[::-1]):
            indexes[-i-1] += v

    return indexes

st = list(map(int, input().split()))
nd = list(map(int, input().split()))

for _ in add_polynomial(st, nd):
    print(_, end=" ")
