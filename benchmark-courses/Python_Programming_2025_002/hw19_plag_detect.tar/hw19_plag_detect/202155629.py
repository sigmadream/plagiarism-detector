f,g=map(lambda s:list(map(int,s.split())),[input(),input()])
d=len(f)-len(g)
if d>0:g=[0]*d+g
else:f=[0]*-d+f
print(*map(lambda x:x[0]+x[1],zip(f,g)))