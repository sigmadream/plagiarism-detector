import sys

a = list(map(int, sys.stdin.readline().split()))
b = list(map(int, sys.stdin.readline().split()))
n = max(len(a), len(b))
a = [0] * (n - len(a)) + a
b = [0] * (n - len(b)) + b
c = [x + y for x, y in zip(a, b)]
print(*c)
