def pl (b,s):
    result = b
    tmp = -1
    for i in range(-1, -len(s)-1, -1):
        result[tmp] = result[tmp] + s[i]
        tmp = tmp -1
    print(" ".join([str(i) for i in result]))
        
        
x1 = list(map(int,input().split()))
x2 = list(map(int,input().split()))
if (len(x1) > len(x2)):
    pl(x1,x2)
else:
    pl(x2,x1)
