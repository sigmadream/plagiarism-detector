from itertools import zip_longest

a = list(map(int, input().split()))[::-1]
b = list(map(int, input().split()))[::-1]
result = [x + y for _, (x, y) in enumerate(zip_longest(a, b, fillvalue=0))]
print(*reversed(result))
