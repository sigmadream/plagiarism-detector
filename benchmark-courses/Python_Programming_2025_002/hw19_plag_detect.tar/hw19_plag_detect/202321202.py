def padd(p1, p2):
    max_len = max(len(p1), len(p2))
    p1 = [0] * (max_len - len(p1)) + p1
    p2 = [0] * (max_len - len(p2)) + p2

    return list(map(lambda x: x[0] + x[1], zip(p1, p2)))

if __name__ == "__main__":
    p1 = list(map(int,input().split()))
    p2 = list(map(int,input().split()))

    result = padd(p1, p2)
    print(' '.join(map(str, result)))