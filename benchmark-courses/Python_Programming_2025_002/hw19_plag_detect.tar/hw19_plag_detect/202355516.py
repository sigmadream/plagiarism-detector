a = list(map(int, input().split()))
b = list(map(int, input().split()))
diff = len(a) - len(b)
if diff > 0:
    b = [0] * diff + b
elif diff < 0:
    a = [0] * (-diff) + a
print(*map(sum, zip(a, b)))
