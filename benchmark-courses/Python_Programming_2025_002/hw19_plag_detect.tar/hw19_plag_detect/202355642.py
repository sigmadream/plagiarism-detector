a,b=[*map(int,input().split())],[*map(int,input().split())]
d=len(a)-len(b)
a,b=([0]*-d+a,[0]*d+b) if d<0 else (a,[0]*d+b)
print(*map(sum,zip(a,b)))







