x1 = list(map(int, input().split()))
x2 = list(map(int, input().split()))
d = len(x1) - len(x2)
if d > 0:
    x2 = [0]*d + x2
if d < 0:
    x1 = [0]*(-d) + x1
print(' '.join(str(a + b) for a, b in zip(x1, x2)))
