def s(N, n):
    """리스트 길이 맞추기"""
    for _ in range(len(N) - len(n)):
        n.insert(0,0)
    return N, n
n1, n2= list(map(int, input().split())), list(map(int, input().split()))
n1, n2 = s(n1,n2) if len(n1) >= len(n2) else s(n2, n1)
print(*map(sum, zip(n1, n2)))
