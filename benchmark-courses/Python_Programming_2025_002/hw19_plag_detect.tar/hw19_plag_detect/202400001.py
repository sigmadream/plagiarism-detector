a = list(map(int, input().split()))
b = list(map(int, input().split()))
n = max(len(a), len(b))
a = [0]*(n - len(a)) + a
b = [0]*(n - len(b)) + b
print(*[a[i] + b[i] for i in range(n)])