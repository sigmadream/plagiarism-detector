def find_indexes(ns, target):
    return [i for i, n in enumerate(ns) if n == target]

ns = [1, 9, 1, 0, 8, 2, 9]
target = 9
print(find_indexes(ns, target))
    
