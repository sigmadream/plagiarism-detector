def addition(n1, n2):
    """Addition Function"""
    len1 = len(n1)
    len2 = len(n2)
    if len1 > len2:
        for i in range(1, len2+1):
            n = n1[-i] + n2[-i]
            n1[-i] = n
        return n1
    if len1 < len2:
        for i in range(1, len1+1):
            n = n2[-i] + n1[-i]
            n2[-i] = n
        return n2
    if len1 == len2:
        for i in range(1, len1+1):
            n = n1[-i] + n2[-i]
            n1[-i] = n
        return n1
    return []

def main():
    """Main Function"""
    num1 = input().split()
    num1 = [int(i) for i in num1]
    num2 = input().split()
    num2 = [int(i) for i in num2]
    result = addition(num1, num2)
    for i in result:
        print(i, end=" ")

if __name__ == "__main__":
    main()
