from itertools import zip_longest as z
s=list(map(int,input().split()))
t=list(map(int,input().split()))
print(*map(sum,z([s,t],fillvalue=0)))
