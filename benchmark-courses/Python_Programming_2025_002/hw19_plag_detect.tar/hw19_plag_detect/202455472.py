coef1 = list(map(int, input().split()))
coef2 = list(map(int, input().split()))

if len(coef1) < len(coef2):
    coef1 = [0] * (len(coef2) - len(coef1)) + coef1
elif len(coef2) < len(coef1):
    coef2 = [0] * (len(coef1) - len(coef2)) + coef2
result = list(map(lambda a, b: a+ b, coef1, coef2))
print(' '.join(map(str,result)))
