a=list(map(int,input().split()))
b=list(map(int,input().split()))
d=len(a)-len(b)
if d>0:b=[0]*d+b
if d<0:a=[0]*-d+a
print(*map(sum,zip(a,b)))