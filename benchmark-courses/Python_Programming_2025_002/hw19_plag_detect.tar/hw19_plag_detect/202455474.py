def fill(func,first,second):
    small,big = (second,first) if len(second) < len(first) else (first,second)
    while len(small) < len(big):
        small.insert(0,0)
    return func(small,big)

def add(equation1,equation2):
    equation1 = [str(equation1[i]+equation2[i]) for i in range(len(equation1))]
    print(' '.join(equation1))

fill(add,list(map(int,input().split())),list(map(int,input().split())))
