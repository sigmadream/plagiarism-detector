def get_terms(poly):
    poly.reverse()
    return dict(enumerate(poly))

def add_polys(poly1, poly2):
    res = {}
    for key in range(max(len(poly1), len(poly2))):
        if key not in poly1:
            poly1[key] = 0
        if key not in poly2:
            poly2[key] = 0
        res[key]=poly1[key] + poly2[key]
    return res

def main():
    poly_1 = get_terms(list(map(int, input().split())))
    poly_2 = get_terms(list(map(int, input().split())))
    ans = add_polys(poly_1, poly_2)

    for term in range(len(ans) - 1, -1, -1):
        print(ans[term], end = " ")

    
if __name__ == "__main__":
    main()
