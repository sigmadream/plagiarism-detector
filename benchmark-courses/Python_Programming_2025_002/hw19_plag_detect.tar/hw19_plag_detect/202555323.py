first_poly = list(map(int, input().split()))
second_poly = list(map(int, input().split()))

diff = len(first_poly) - len(second_poly)
if diff > 0:
    second_poly = [0]*diff + second_poly
else:
    first_poly = [0]*(-diff) + first_poly

result = list(map(sum, zip(first_poly, second_poly)))
print(*result)