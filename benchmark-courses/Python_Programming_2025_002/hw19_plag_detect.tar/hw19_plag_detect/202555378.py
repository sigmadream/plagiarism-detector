def add_poly(poly1,poly2):
    result = []
    max_len = max(len(poly1), len(poly2))
    padded_poly1 = [0] * (max_len - len(poly1)) + poly1
    padded_poly2 = [0] * (max_len - len(poly2)) + poly2
    for i in range(max_len):
        result.append(padded_poly1[i] + padded_poly2[i])
    return result

if __name__=="__main__":
  poly1= list(map(int, input().split()))
  poly2= list(map(int, input().split()))

  result= add_poly(poly1,poly2)
  print(*result)