first = list(map(int, input().split()))
second = list(map(int, input().split()))
result = []
if len(first) > len(second):
    ll, sl = len(first), len(second)
    long, short = first, second
else:
    ll, sl = len(second), len(first)
    long, short = second, first

result.extend(long[:ll - sl])
for i in range(sl, 0, -1):
    result.append(long[-i] + short[-i])
print(" ".join(map(str, result)))
