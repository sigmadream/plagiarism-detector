def padd(poly1, poly2):
    """
    Add two polynomials represented as lists of coefficients
    (higher order terms first)
    """
    # Create a result list with max length of the longer polynomial
    max_len = max(len(poly1), len(poly2))
    
    # Pad the shorter polynomial with leading zeros
    p1 = [0] * (max_len - len(poly1)) + poly1
    p2 = [0] * (max_len - len(poly2)) + poly2
    
    # Use zip to pair up coefficients and add them
    return list(map(lambda x: x[0] + x[1], zip(p1, p2)))

if __name__ == "__main__":
    # Read input
    poly1 = list(map(int, input().split()))
    poly2 = list(map(int, input().split()))
    
    # Calculate the sum
    result = padd(poly1, poly2)
    
    # Print the result
    print(*result)