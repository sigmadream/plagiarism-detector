f,g=map(lambda x:list(map(int,x.split())),[input(),input()])
d=len(f)-len(g)
(f if d<0 else g)[:0]=[0]*abs(d)
print(*[f[i]+g[i]for i in range(len(f))])