def add_polynomials(p1, p2):
    """Adds two polynomials represented as lists of coefficients."""
    diff = len(p1) - len(p2)
    if diff > 0:
        p2 = [0] * diff + p2
    else:
        p1 = [0] * (-diff) + p1

    sum_result = [x + y for x, y in zip(p1, p2)]
    return sum_result

if __name__ == "__main__":
    # Read two lines of input
    input_poly1 = list(map(int, input().split()))
    input_poly2 = list(map(int, input().split()))
    sum_polynomial = add_polynomials(input_poly1, input_poly2)
    print(*sum_polynomial)
