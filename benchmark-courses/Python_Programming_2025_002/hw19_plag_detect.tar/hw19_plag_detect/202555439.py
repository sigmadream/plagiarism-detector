f = input().split()
flen = len(f)
g = input().split()
glen = len(g)
if flen > glen: g = [0] * (flen - glen) + g
else: f = [0] * (glen - flen) + f
print(*list(map(lambda x:int(x[0])+int(x[1]),zip(f, g))))