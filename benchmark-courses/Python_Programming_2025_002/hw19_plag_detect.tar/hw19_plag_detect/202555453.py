k=lambda:list(map(int,input().split()))
n=k()
m=k()
if len(n)<len(m):n,m=m,n
m=(len(n)-len(m))*[0]+m
for i in range(len(n)):print(n[i]+m[i],end=" ")