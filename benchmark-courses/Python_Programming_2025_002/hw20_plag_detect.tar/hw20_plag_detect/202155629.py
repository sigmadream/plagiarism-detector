def mul_pol(f, g):
    "Multiplying two polynomials"
    # dictionary for storing the result of multiplication
    # where key - the degree of term, values - coefficient of that term
    terms = {}
    # converting the input lists into a list of (degree, coefficient) pairs
    f_term = [(f[i], f[i+1]) for i in range(0, len(f), 2)]
    g_term = [(g[i], g[i+1]) for i in range(0, len(g), 2)]
    # multiplying every term in f with every term in g
    for f_degree, f_coef in f_term:
        for g_degree, g_coef in g_term:
            degree = f_degree + g_degree # adding degrees
            coef = f_coef * g_coef # multiplying coefficients
            # accumulating the coefficients
            # if there are terms with the same degree
            if degree in terms:
                terms[degree] += coef
            else:
                terms[degree] = coef
    # finding the highest degree in the result
    max_degree = max(terms.keys())
    # initializing the product list with zeros for all degrees
    product = [0] * (max_degree + 1)
    # filling the product list by placing a coefficient at correct position
    for d, coef in terms.items():
        product[max_degree - d] = coef
    return product


if __name__ == "__main__":
    # reading two input polynomials
    pol_1 = list(map(int, input().split()))
    pol_2 = list(map(int, input().split()))
    # computing the product of f and g
    result = mul_pol(pol_1, pol_2)
    # printing the result as a space-separated string
    print(' '.join(map(str, result)))
