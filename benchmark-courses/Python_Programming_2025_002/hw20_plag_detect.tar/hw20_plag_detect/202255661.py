import sys

def parse_poly(line):
    nums = list(map(int, line.split()))
    return {nums[i]: nums[i+1] for i in range(0, len(nums), 2)}

def multiply(poly1, poly2):
    result = {}
    for d1, c1 in poly1.items():
        for d2, c2 in poly2.items():
            d = d1 + d2
            result[d] = result.get(d, 0) + c1 * c2
    return result

def main():
    line1 = input().strip()
    line2 = input().strip()

    poly1 = parse_poly(line1)
    poly2 = parse_poly(line2)

    res = multiply(poly1, poly2)

    if not res:
        print(0)
        return

    max_deg = max(res.keys())
    coeffs = [res.get(d, 0) for d in range(max_deg, -1, -1)]
    print(" ".join(map(str, coeffs)))

if __name__ == "__main__":
    main()
