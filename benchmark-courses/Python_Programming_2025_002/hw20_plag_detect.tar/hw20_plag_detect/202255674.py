def p(line):
    """입력 문자열을 리스트로 변환합니다."""
    nums = list(map(int, line.split()))
    return [(nums[i], nums[i+1]) for i in range(0, len(nums), 2)]

a = p(input())
b = p(input())
max_deg = max(da + db for da, _ in a for db, _ in b)
res = [0] * (max_deg + 1)
for da, ca in a:
    for db, cb in b:
        res[da + db] += ca * cb
print(' '.join(str(res[i]) for i in range(max_deg, -1, -1)))
