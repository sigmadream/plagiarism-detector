from collections import defaultdict

def parse_polynomial(line):
    """문자열로 주어진 (차수, 계수) 쌍을 튜플 리스트로 변환"""
    nums = list(map(int, line.strip().split()))
    return [(nums[i], nums[i + 1]) for i in range(0, len(nums), 2)]

def multiply_polynomials(p1, p2):
    """두 다항식을 곱하고 결과를 계수 리스트로 반환"""
    result = defaultdict(int)
    for d1, c1 in p1:
        for d2, c2 in p2:
            result[d1 + d2] += c1 * c2

    max_deg = max(result) if result else 0
    return [result[i] for i in reversed(range(max_deg + 1))]

def main():
    """프로그램의 주 실행 함수입니다. 사용자 입력을 받아 곱셈 결과를 출력합니다."""
    poly1 = parse_polynomial(input())
    poly2 = parse_polynomial(input())
    result = multiply_polynomials(poly1, poly2)
    print(" ".join(str(x) for x in result))

if __name__ == "__main__":
    main()
