from collections import defaultdict

# 입력 처리
f_input = input().split()
g_input = input().split()

# (차수, 계수) 쌍 리스트로 변환
f_poly = list(map(lambda i: (int(f_input[i]), int(f_input[i + 1])), range(0, len(f_input), 2)))
g_poly = list(map(lambda i: (int(g_input[i]), int(g_input[i + 1])), range(0, len(g_input), 2)))

# 곱셈 수행
result = defaultdict(int)

for d1, c1 in f_poly:
    for d2, c2 in g_poly:
        result[d1 + d2] += c1 * c2

# 결과 정렬 및 출력
max_deg = max(result)
output = [result[i] for i in range(max_deg, -1, -1)]
print(' '.join(map(str, output)))
