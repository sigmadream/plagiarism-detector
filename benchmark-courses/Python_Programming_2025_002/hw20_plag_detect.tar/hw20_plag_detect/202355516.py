def parse(s):
    n = list(map(int, s.split()))
    return [(n[i], n[i+1]) for i in range(0, len(n), 2)]

def mul(p1, p2):
    d = {}
    for a, b in p1:
        for x, y in p2:
            k = a + x
            d[k] = d.get(k, 0) + b * y
    return [d.get(i, 0) for i in range(max(d), -1, -1)]

print(*mul(parse(input()), parse(input())))
