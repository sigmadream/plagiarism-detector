a,b=[*map(int,input().split())],[*map(int,input().split())]
A={(a[i],a[i+1]) for i in range(0,len(a),2)}
B={(b[i],b[i+1]) for i in range(0,len(b),2)}
C={}
for d1,c1 in A:
 for d2,c2 in B:
  C[d1+d2]=C.get(d1+d2,0)+c1*c2
m=max(C)
print(*[C.get(i,0) for i in range(m,-1,-1)])
