def poly():
    """입력값을 딕셔너리로 변환"""
    terms = list(map(int, input().strip().split()))
    return dict(map(lambda i: (terms[i], terms[i + 1]), range(0, len(terms), 2)))

def mult(p1, p2):
    """두 다항식을 곱한 결과를 딕셔너리로 반환"""
    ans = {}
    for deg1 in p1:
        for deg2 in p2:
            deg = deg1 + deg2
            if deg in ans:
                ans[deg] += p1[deg1] * p2[deg2]
            else:
                ans[deg] = p1[deg1] * p2[deg2]
    return ans

def result(p):
    """내림차순 수행"""
    ans = []
    for deg in range(max(p.keys()), -1, -1):
        co = p.get(deg, 0)
        ans.append(co)
    print(' '.join(map(str, ans)))

p1 = poly()
p2 = poly()
product = mult(p1, p2)
result(product)
