def main():
    f = [int(x) for x in input().split()]
    g = [int(x) for x in input().split()]

    f_exps = [[f[i], f[i + 1]] for i in range(0, len(f), 2)]
    g_exps = [[g[i], g[i + 1]] for i in range(0, len(g), 2)]

    max_deg = 0
    for deg1, _ in f_exps:
        for deg2, _ in g_exps:
            max_deg = max(max_deg, deg1 + deg2)

    result = [0] * (max_deg + 1)

    for deg1, coef1 in f_exps:
        for deg2, coef2 in g_exps:
            deg = deg1 + deg2
            result[deg] += coef1 * coef2

    for i in range(len(result) - 1, -1, -1):
        end = " " if i > 0 else "\n"
        print(result[i], end=end)

main()