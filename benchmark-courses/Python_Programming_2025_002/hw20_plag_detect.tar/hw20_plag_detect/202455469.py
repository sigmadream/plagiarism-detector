def parse_input_line(line):
    """Parses a single line of input into a list of (degree, coefficient) tuples."""
    nums = list(map(int, line.strip().split()))
    return [(nums[i], nums[i + 1]) for i in range(0, len(nums), 2)]

def multiply(poly1, poly2):
    """Multiplies two polynomials represented as (degree, coefficient) tuples."""
    result = {}
    for deg1, coef1 in poly1:
        for deg2, coef2 in poly2:
            deg = deg1 + deg2
            coef = coef1 * coef2
            if deg in result:
                result[deg] += coef
            else:
                result[deg] = coef
    if result:
        max_deg = max(result)
        return [result.get(d, 0) for d in range(max_deg, -1, -1)]
    return []

def main():
    """Main function."""
    line1 = input()
    line2 = input()
    poly1 = parse_input_line(line1)
    poly2 = parse_input_line(line2)
    result = multiply(poly1, poly2)
    print(' '.join(map(str, result)))

if __name__ == '__main__':
    main()
