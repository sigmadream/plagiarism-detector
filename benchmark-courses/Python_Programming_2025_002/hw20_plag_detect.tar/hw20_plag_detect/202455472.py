f = list(map(int, input().split()))
g = list(map(int, input().split()))
term_dict = {}
for i in range(0, len(f), 2):
    f_deg = f[i]
    f_coef = f[i + 1]
    for j in range(0, len(g), 2):
        g_deg = g[j]
        g_coef = g[j + 1]
        deg = f_deg + g_deg
        coef = f_coef * g_coef
        term_dict[deg] = term_dict.get(deg, 0) + coef
if term_dict:
    max_deg = max(term_dict)
    for d in range(max_deg, -1, -1):
        print(term_dict.get(d, 0), end=' ')
