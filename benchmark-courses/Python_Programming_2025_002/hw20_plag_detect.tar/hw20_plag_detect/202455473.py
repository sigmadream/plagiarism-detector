from typing import List, Tuple

def read_polynomial() -> List[Tuple[int, int]]:
    """
    Reads a line of input and returns a list of (degree, coefficient) tuples.
    The input format is: deg1 coef1 deg2 coef2 ... degN coefN
    """
    data = list(map(int, input().split()))
    return [(data[i], data[i + 1]) for i in range(0, len(data), 2)]

def multiply_polynomials(p1: List[Tuple[int, int]], p2: List[Tuple[int, int]]) -> List[int]:
    """
    Multiplies two polynomials represented as lists of (degree, coefficient) tuples.
    Returns a list of coefficients in order from highest degree to 0.
    """
    result = {}

    for deg1, coef1 in p1:
        for deg2, coef2 in p2:
            deg = deg1 + deg2
            coef = coef1 * coef2
            result[deg] = result.get(deg, 0) + coef

    max_deg = max(result)
    return [result.get(i, 0) for i in range(max_deg, -1, -1)]

def main():
    """
    Main function to read two polynomials from input,
    multiply them, and print the resulting polynomial's coefficients.
    """
    poly1 = read_polynomial()
    poly2 = read_polynomial()
    result = multiply_polynomials(poly1, poly2)
    print(*result)

if __name__ == "__main__":
    main()
