first = list(zip(*[iter(map(int, input().split()))]*2))
second = list(zip(*[iter(map(int, input().split()))]*2))

res = {}

while first:
    coef1,const1 = first.pop()
    for coef2,const2 in second:
        res[coef1 + coef2] = res.get(coef1 + coef2,0) + const1 * const2

res = {i:res.get(i,0) for i in range(max(res.keys())+1)}
print(' '.join(map(str,dict(sorted(res.items(),reverse=True)).values())))
