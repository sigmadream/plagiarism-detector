def get_terms(poly):
    "turns polynomial list into dict"
    res = {}
    for i in range(len(poly) // 2):
        res[poly[2 * i]] = poly[2 * i + 1]
    return res

def multiply_polys(poly1, poly2):
    "multiplies two polynomia"
    res = {}
    max_term_1 = max(poly1.keys())
    max_term_2 = max(poly2.keys())

    for x in range(max_term_1 + max_term_2 + 1):
        res[x] = 0

    for x in range(max_term_1):
        if x not in poly1:
            poly1[x] = 0

    for x in range(max_term_2):
        if x not in poly2:
            poly2[x] = 0

    for x1 in range(max_term_1 + 1):
        for x2 in range(max_term_2 + 1):
            res[x1 + x2] += poly1[x1] * poly2[x2]
    return res

def main():
    "slkfjslk"
    poly_1 = get_terms(list(map(int, input().split())))
    poly_2 = get_terms(list(map(int, input().split())))
    ans = multiply_polys(poly_1, poly_2)

    for term in range(len(ans) - 1, -1, -1):
        print(ans[term], end = " ")


if __name__ == "__main__":
    main()
