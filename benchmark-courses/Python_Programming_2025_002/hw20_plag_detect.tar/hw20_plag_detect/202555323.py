def parse_polynomial(input_line):
    nums = list(map(int, input_line.strip().split()))
    poly = {}

    for i in range(0, len(nums), 2):
        degree = nums[i]
        coeff = nums[i + 1]
        poly[degree] = coeff
    return poly

def multi_poly(p1, p2):
    result = {}
    for d1, c1 in p1.items():
        for d2, c2 in p2.items():
            deg = d1 + d2
            result[deg] = result.get(deg, 0) + c1 * c2
    return result

def format_output(poly_dict):
    max_deg = max(poly_dict.keys()) if poly_dict else 0   
    return [poly_dict.get(d, 0) for d in range(max_deg, -1, -1)]


if __name__ == "__main__":
    line1 = input()
    line2 = input()

    poly1 = parse_polynomial(line1)
    poly2 = parse_polynomial(line2)

    product = multi_poly(poly1, poly2)
    output = format_output(product)    

    print(' '.join(map(str, output)))