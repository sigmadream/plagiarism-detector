f = list(map(int, input().split()))
g = list(map(int, input().split()))
pair_f = list(zip(f[::2], f[1::2]))
pair_g = list(zip(g[::2], g[1::2]))
li = []
for i in range(len(f) // 2):
    for j in range(len(g) // 2):
        s_tup = (pair_f[i][0] + pair_g[j][0], pair_f[i][1] * pair_g[j][1])
        li.append(s_tup)
coefficients = [0] * (max(f[::2]) + max(g[::2]) + 1)
for i in range(len(li)):
    coefficients[li[i][0]] += li[i][1]
coefficients.reverse()
print(*coefficients)
