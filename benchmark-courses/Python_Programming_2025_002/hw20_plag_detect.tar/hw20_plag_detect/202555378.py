def read_polynomial(input_line):
    numbers = list(map(int, input_line.split()))
    
    polynomial = {}
    i = 0
    while i < len(numbers):
        degree = numbers[i]
        coefficient = numbers[i + 1]
        polynomial[degree] = coefficient
        i += 2
    
    return polynomial

def multiply_polynomials(poly1, poly2):
    result = {}
    
    for degree1, coef1 in poly1.items():
        for degree2, coef2 in poly2.items():
            new_degree = degree1 + degree2
            product = coef1 * coef2
            
            if new_degree in result:
                result[new_degree] += product
            else:
                result[new_degree] = product
    
    return result

def format_result(polynomial):
    if not polynomial:
        return "0"
    
    highest_degree = max(polynomial.keys())
    coefficients = []
    
    for degree in range(highest_degree, -1, -1):
        if degree in polynomial:
            coefficients.append(str(polynomial[degree]))
        else:
            coefficients.append("0")
    
    return " ".join(coefficients)

def main():
    poly1_input = input()
    poly2_input = input()
    
    poly1 = read_polynomial(poly1_input)
    poly2 = read_polynomial(poly2_input)
    
    result = multiply_polynomials(poly1, poly2)
    
    output = format_result(result)
    print(output)

if __name__ == "__main__":
    main()