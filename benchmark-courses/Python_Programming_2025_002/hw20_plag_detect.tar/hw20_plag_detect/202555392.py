polynomial = list(map(int, input().split()))
polynomial2 = list(map(int, input().split()))
p1 = []
p2 = []
for i in range(0, len(polynomial), 2):
    p1.append((polynomial[i + 1], polynomial[i]))
for i in range(0, len(polynomial2), 2):
    p2.append((polynomial2[i + 1], polynomial2[i]))
result = [[] for _ in range(p1[0][1] + p2[0][1] + 1)]

for i in p2:
    for j in p1:
        result[i[1] + j[1]].append(i[0] * j[0])

for coefficient in list(reversed(result)):
    print(sum(coefficient), end=" ")
