"""
pmul.py - Polynomial Multiplication
This program multiplies two polynomials represented as sequences of (degree, coefficient) pairs
and outputs the coefficients of the resulting polynomial in descending order of degree.
"""
from functools import reduce
from collections import defaultdict

def parse_polynomial(line):
    """Parse input line into a list of (degree, coefficient) pairs"""
    tokens = line.strip().split()
    polynomial = []
    i = 0
    
    while i < len(tokens):
        degree = int(tokens[i])
        coefficient = int(tokens[i + 1])
        polynomial.append((degree, coefficient))
        i += 2
        
    return polynomial

def multiply_polynomials(poly1, poly2):
    """
    Multiply two polynomials and return the result
    Each polynomial is represented as a list of (degree, coefficient) pairs
    """
    # Use a dictionary to accumulate coefficients for each degree
    result = defaultdict(int)
    
    # For each term in the first polynomial
    for deg1, coef1 in poly1:
        # Multiply by each term in the second polynomial
        for deg2, coef2 in poly2:
            # When multiplying terms, add degrees and multiply coefficients
            new_degree = deg1 + deg2
            new_coefficient = coef1 * coef2
            
            # Add the result to the appropriate degree
            result[new_degree] += new_coefficient
    
    return result

def format_result(result_dict):
    """
    Format the result dictionary into the required output format
    Returns a string with coefficients in descending order of degree
    """
    if not result_dict:
        return "0"
    
    # Find the highest degree
    max_degree = max(result_dict.keys()) if result_dict else 0
    
    # Create a list of coefficients in descending order of degree
    # Include all degrees from max_degree down to 0
    coefficients = []
    
    # Use functional programming (map) to create the coefficient list
    # This satisfies the requirement to use at least one higher-order function
    degrees = sorted(list(range(max_degree + 1)), reverse=True)
    coefficients = list(map(lambda deg: result_dict.get(deg, 0), degrees))
    
    return " ".join(map(str, coefficients))

def main():
    # Read input
    poly1_line = input().strip()
    poly2_line = input().strip()
    
    # Parse polynomials
    poly1 = parse_polynomial(poly1_line)
    poly2 = parse_polynomial(poly2_line)
    
    # Multiply polynomials
    result = multiply_polynomials(poly1, poly2)
    
    # Format and print the result
    print(format_result(result))

if __name__ == "__main__":
    main()