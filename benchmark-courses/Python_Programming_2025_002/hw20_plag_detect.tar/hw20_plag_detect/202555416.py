from collections import defaultdict

def read_poly():
    t = list(map(int, input().split()))
    return [(t[i], t[i+1]) for i in range(0, len(t), 2)]

p1 = read_poly()
p2 = read_poly()
res = defaultdict(int)

for d1, c1 in p1:
    for d2, c2 in p2:
        res[d1 + d2] += c1 * c2

max_deg = max(res)
print(*[res[i] for i in range(max_deg + 1)][::-1])