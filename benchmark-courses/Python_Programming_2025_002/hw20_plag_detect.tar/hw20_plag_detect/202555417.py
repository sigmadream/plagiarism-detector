f = list(map(int, input().split()))
g = list(map(int, input().split()))
f_terms = [(f[i], f[i + 1]) for i in range(0, len(f), 2)]
g_terms = [(g[i], g[i + 1]) for i in range(0, len(g), 2)]
coef = [0]*(max(f[::2]) + max(g[::2]) + 1)
result = []
for deg1, coef1 in f_terms:
    for deg2, coef2 in g_terms:
        result.append((deg1 + deg2, coef1 * coef2))
for i in range(len(result)):
    coef[result[i][0]] += result[i][1]
print(*(reversed(coef)))
