def multiply_polynomials(poly1, poly2):
    """Multiply two polynomials given as lists of (degree, coefficient) pairs."""
    # Dictionary to store degree:coefficient sums
    result = {}
    # Multiply each term of poly1 with each term of poly2
    for d1, c1 in poly1:
        for d2, c2 in poly2:
            degree = d1 + d2
            coeff = c1 * c2
            result[degree] = result.get(degree, 0) + coeff
    # Get max degree and create coefficient list
    max_degree = max(result.keys(), default=0)
    return list(map(lambda d: result.get(d, 0), range(max_degree, -1, -1)))
def main():
    """Read input polynomials and print their product."""
    # Read and parse input
    poly1 = list(zip(*[iter(map(int, input().split()))]*2))
    poly2 = list(zip(*[iter(map(int, input().split()))]*2))
    # Compute and print result
    result = multiply_polynomials(poly1, poly2)
    print(*result)
if __name__ == "__main__":
    main()
