line = lambda: list(map(int, input().split()))
reshape = lambda x: list(zip(x[::2], x[1::2]))

f, g = reshape(line()), reshape(line())

mul = {}
for a, av in f:
    for b, bv in g:
        mul[a + b] = mul.get(a + b, 0) + av * bv

print(*[mul.get(i, 0) for i in range(max(mul.keys()), -1, -1)])
