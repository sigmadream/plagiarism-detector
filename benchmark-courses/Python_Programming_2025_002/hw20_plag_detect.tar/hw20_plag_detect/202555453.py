def main():
    """main func"""
    seq = list(map(int, input().split()))
    poly1 = list(zip(seq[::2], seq[1::2]))

    seq = list(map(int, input().split()))
    poly2 = list(zip(seq[::2], seq[1::2]))

    rst_poly = [0] * (poly1[0][0] + poly2[0][0] + 1)

    for deg1, coeff1 in poly1:
        for deg2, coeff2 in poly2:
            rst_poly[deg1 + deg2] += coeff1 * coeff2

    for p in reversed(rst_poly):
        print(p, end=" ")


if __name__ == "__main__":
    main()
