import sys
#paper coordinates [x1,y1,x2,y2]
paper = [-sys.maxsize - 1,-sys.maxsize - 1,sys.maxsize,sys.maxsize]
def paper_f():
    """
    Reads a series of rectangle definitions from standard input and computes
    the area of their overlapping region.

    Each non‐empty input line should contain four integers:
        x1 y1 x2 y2
    which represent the coordinates of the bottom-left corner (x1, y1) and
    the top-right corner (x2, y2) of a rectangle.

    Reading stops when an empty line is encountered. The function maintains
    the current intersection region by:
      - updating the left boundary to max(all x1)
      - updating the bottom boundary to max(all y1)
      - updating the right boundary to min(all x2)
      - updating the top boundary to min(all y2)

    Finally, it prints the area of the overlapping region:
        (right − left) × (top − bottom)

    Note:
        If the rectangles do not overlap, this may produce a zero or negative
        value depending on the input ordering.
    """
    for line in sys.stdin.readlines():
        if line.strip() == "":
            break
        #input coordinates [x1,y1,x2,y2]
        new_paper = list(map(int, line.split()))
        if paper[0] < new_paper[0]:
            paper[0] = new_paper[0]
        if paper[1] < new_paper[1]:
            paper[1] = new_paper[1]
        if paper[2] > new_paper[2]:
            paper[2] = new_paper[2]
        if paper[3] > new_paper[3]:
            paper[3] = new_paper[3]
    print((paper[2]-paper[0]) * (paper[3]-paper[1]))

if __name__ == "__main__":
    paper_f()
