import sys

class Paper():
    """
    Paper class - representing a rectangular piece of paper
    defined by its lower-left and upper-right corners

    Attributes:
        x1 (int) - the x coordinate of lower-left corner
        y1 (int) - the y coordinate of lower-left corner
        x2 (int) - the x coordinate of upper-right corner
        y2 (int) - the y coordinate of upper-right corner
    """
    def __init__(self, x1, y1, x2, y2):
        "Initialization method"
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    def overlap(self, other):
        """
        Computing the overlapping rectangle between papers
        
        Args:
            other (Paper) - another Paper object to compare with

        Returns:
            Paper - a new Paper object representing the overlapping area
            None - if there is no overlap between papers
        """
        # the lower-left corner is computed by
        # finding the maximum between all the x1, y1 coordinates
        res_x1 = max(self.x1, other.x1)
        res_y1 = max(self.y1, other.y1)
        # the upper-right corner is computed by
        # finding the minimum between all the x2, y2 coordinates
        res_x2 = min(self.x2, other.x2)
        res_y2 = min(self.y2, other.y2)
        # if there is no overlap between papers -> return None
        if res_x1 >= res_x2 or res_y1 >= res_y2:
            return None
        # returning a new Paper object with its coordinates
        return Paper(res_x1, res_y1, res_x2, res_y2)

    def area(self):
        """
        Calculating the area of the overlapping rectangle
        
        Returns:
            int - area of the paper
        """
        return (self.x2 - self.x1) * (self.y2 - self.y1)


def main():
    "Main functionality"
    # reading all lines from standard input
    lines = sys.stdin.read().splitlines()
    # parsing the first rectangle
    x1, y1, x2, y2 = map(int, lines[0].split())
    # initializing the overlap region
    paper_overlap = Paper(x1, y1, x2, y2)
    # iterating over the remaining rectangles
    for line in lines[1:]:
        # parsing the current rectangle's coordinates
        x1, y1, x2, y2 = map(int, line.split())
        paper_new = Paper(x1, y1, x2, y2)
        # updating the overlap region
        paper_overlap = paper_overlap.overlap(paper_new)
        # if there is no overlapping area -> print 0
        if paper_overlap is None:
            print(0)
            return
    # print the final area of the overlapped region
    print(paper_overlap.area())

if __name__ == "__main__":
    main()
