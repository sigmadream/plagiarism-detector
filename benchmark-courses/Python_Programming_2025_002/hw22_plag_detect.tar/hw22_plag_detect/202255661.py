import sys

class Paper:
    def __init__(self, xL: int, yL: int, xR: int, yR: int):
        self.xL, self.yL, self.xR, self.yR = xL, yL, xR, yR

    def overlap(self, other: "Paper") -> "Paper":
        new_xL = max(self.xL, other.xL)
        new_yL = max(self.yL, other.yL)
        new_xR = min(self.xR, other.xR)
        new_yR = min(self.yR, other.yR)

        if new_xL < new_xR and new_yL < new_yR:
            return Paper(new_xL, new_yL, new_xR, new_yR)
        else:
            return Paper(0, 0, 0, 0)

    def area(self) -> int:
        return max(0, self.xR - self.xL) * max(0, self.yR - self.yL)


def main():
    papers = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        xL, yL, xR, yR = map(int, line.split())
        papers.append(Paper(xL, yL, xR, yR))

    intersection = papers[0]
    for p in papers[1:]:
        intersection = intersection.overlap(p)

    print(intersection.area())


if __name__ == "__main__":
    main()
