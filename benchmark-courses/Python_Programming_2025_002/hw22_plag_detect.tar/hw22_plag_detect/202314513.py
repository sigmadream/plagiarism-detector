# -*- coding: utf-8 -*-
import sys

class Paper:
    """직사각형 종이를 두 점으로 나타내는 클래스입니다."""

    def __init__(self, x1, y1, x2, y2):
        self.left = min(x1, x2)
        self.right = max(x1, x2)
        self.bottom = min(y1, y2)
        self.top = max(y1, y2)

    def overlap(self, other):
        """다른 종이와 겹치는 부분이 있으면 새로운 Paper 객체를 반환합니다. 없으면 None 반환."""
        new_left = max(self.left, other.left)
        new_right = min(self.right, other.right)
        new_bottom = max(self.bottom, other.bottom)
        new_top = min(self.top, other.top)

        if new_left >= new_right or new_bottom >= new_top:
            return None
        return Paper(new_left, new_bottom, new_right, new_top)

    def area(self):
        """이 종이의 넓이를 반환합니다."""
        return (self.right - self.left) * (self.top - self.bottom)

def main():
    """표준 입력으로부터 여러 종이를 읽고, 겹치는 영역의 넓이를 출력합니다."""
    lines = sys.stdin.readlines()
    papers = [Paper(*map(int, line.strip().split())) for line in lines]

    if not papers:
        print(0)
        return

    overlap_region = papers[0]
    for paper in papers[1:]:
        overlap_region = overlap_region.overlap(paper)
        if overlap_region is None:
            print(0)
            return

    print(overlap_region.area())

if __name__ == "__main__":
    main()
