import sys

class Paper:
    def __init__(self, x1, y1, x2, y2):
        self.x1, self.y1, self.x2, self.y2 = x1, y1, x2, y2

    def overlap(self, other):
        x1 = max(self.x1, other.x1)
        y1 = max(self.y1, other.y1)
        x2 = min(self.x2, other.x2)
        y2 = min(self.y2, other.y2)
        return Paper(x1, y1, x2, y2) if x1 < x2 and y1 < y2 else None

    def area(self):
        return (self.x2 - self.x1) * (self.y2 - self.y1)

def main():
    papers = [Paper(*map(int, line.split())) for line in sys.stdin if line.strip()]
    overlap = papers[0]
    for p in papers[1:]:
        overlap = overlap.overlap(p)
        if not overlap:
            print(0)
            return
    print(overlap.area())

if __name__ == "__main__":
    main()
