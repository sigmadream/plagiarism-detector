import sys

class Paper:
    def __init__(self, x1, y1, x2, y2):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    def overlap(self, other):
        x1 = max(self.x1, other.x1)
        y1 = max(self.y1, other.y1)
        x2 = min(self.x2, other.x2)
        y2 = min(self.y2, other.y2)
        if x1 < x2 and y1 < y2:
            return Paper(x1, y1, x2, y2)
        return None

lines = sys.stdin.readlines()
papers = [Paper(*map(int, line.split())) for line in lines]
overlap_region = papers[0]
for p in papers[1:]:
    overlap_region = overlap_region.overlap(p)
    if not overlap_region:
        print(0)
        break
else:
    print((overlap_region.x2 - overlap_region.x1) * (overlap_region.y2 - overlap_region.y1))
