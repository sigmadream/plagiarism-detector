import sys

class Paper:
    def __init__(self, x1, y1, x2, y2):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    def overlap(self, other):
        """"""
        x_left = max(self.x1, other.x1)
        y_bottom = max(self.y1, other.y1)
        x_right = min(self.x2, other.x2)
        y_top = min(self.y2, other.y2)

        if x_right > x_left and y_top > y_bottom:
            return Paper(x_left, y_bottom, x_right, y_top)
        return None


def main():
    """"""
    papers = []
    for line in sys.stdin:
        if line.strip() == "":
            break
        x1, y1, x2, y2 = map(int, line.strip().split())
        papers.append(Paper(x1, y1, x2, y2))

    if len(papers) < 2:
        print("0")
        return

    overlap_paper = papers[0]

    for i in range(1, len(papers)):
        overlap_paper = overlap_paper.overlap(papers[i])
        if overlap_paper is None:
            print("0")
            return

    area = (overlap_paper.x2 - overlap_paper.x1) * (overlap_paper.y2 - overlap_paper.y1)
    print(area)


if __name__ == "__main__":
    main()
