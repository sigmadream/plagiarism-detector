# coding: utf-8
"""HW11: 종이 겹침 영역 넓이 구하기"""

import sys


class Paper:
    """축에 평행한 사각형을 나타내는 클래스"""

    def __init__(self, x1: int, y1: int, x2: int, y2: int):
        self.x1, self.y1 = x1, y1
        self.x2, self.y2 = x2, y2

    def overlap(self, other: "Paper") -> "Paper | None":
        """다른 Paper와 겹치는 영역을 Paper로 반환"""
        nx1 = max(self.x1, other.x1)
        ny1 = max(self.y1, other.y1)
        nx2 = min(self.x2, other.x2)
        ny2 = min(self.y2, other.y2)
        if nx1 < nx2 and ny1 < ny2:
            return Paper(nx1, ny1, nx2, ny2)
        return None

    def area(self) -> int:
        """넓이 계산"""
        return (self.x2 - self.x1) * (self.y2 - self.y1)


def main():
    lines = sys.stdin.read().splitlines()
    papers = [Paper(*map(int, line.split())) for line in lines]
    overlap = papers[0]
    for p in papers[1:]:
        o = overlap.overlap(p)
        if not o:
            print(0)
            return
        overlap = o
    print(overlap.area())


if __name__ == "__main__":
    main()
