import sys

class Paper:
    def __init__(self, xl, yl, xr, yr):
        """Initialize a Paper object with the coordinates of the rectangle."""
        self.xl = xl
        self.yl = yl
        self.xr = xr
        self.yr = yr

    def overlap(self, other):
        """Calculate the overlapping rectangle"""
        xl = max(self.xl, other.xl)
        yl = max(self.yl, other.yl)
        xr = min(self.xr, other.xr)
        yr = min(self.yr, other.yr)
        if xl >= xr or yl >= yr:
            return None
        return Paper(xl, yl, xr, yr)

    def area(self):
        """Calculate the area of the rectangle"""
        return max(0, self.xr - self.xl) * max(0, self.yr - self.yl)

def main():
    """Main function."""
    input_lines = sys.stdin.read().strip().split('\n')
    papers = []
    for line in input_lines:
        xl, yl, xr, yr = map(int, line.split())
        papers.append(Paper(xl, yl, xr, yr))
    overlap_region = papers[0]
    for p in papers[1:]:
        overlap_region = overlap_region.overlap(p)
        if overlap_region is None:
            print(0)
            return
    print(overlap_region.area())

if __name__ == "__main__":
    main()
