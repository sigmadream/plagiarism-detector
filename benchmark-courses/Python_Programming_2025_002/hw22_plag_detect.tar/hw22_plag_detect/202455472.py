import sys
class Paper:

    def __init__ (self, xl, yl, xr, yr):
        '''Rectangle defined by the lower-left and the upper-right corner'''
        self.xl = xl
        self.yl = yl
        self.xr = xr
        self.yr = yr
    def overlap(self, other):
        '''Return the overlapping rectangle'''
        xl =max(self.xl, other.xl)
        yl = max(self.yl, other.yl)
        xr = min(self.xr, other.xr)
        yr = min(self.yr, other.yr)

        if xl < xr and yl < yr:
            return Paper(xl, yl, xr, yr)
        return None
    def area(self):
        '''Return the area of the rectangle'''
        return (self.xr - self.xl)*(self.yr - self.yl)

def main():
    '''Main function'''
    lines = sys.stdin.read().splitlines()
    papers = [Paper(*map(int, line.split())) for line in lines ]
    overlap1 = papers[0]
    for p in papers[1:]:
        overlap1 = overlap1.overlap(p)
        if overlap1 is None:
            print(0)
            return

    print(overlap1.area())

if __name__ == "__main__":
    main()
