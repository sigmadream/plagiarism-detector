import sys

class Rectangle:
    """Represents a rectangle and supports calculating overlap with other rectangles."""
    def __init__(self, x1: int, y1: int, x2: int, y2: int):
        self.x_left = min(x1, x2)
        self.x_right = max(x1, x2)
        self.y_lower = min(y1, y2)
        self.y_upper = max(y1, y2)

    def overlap(self, other: 'Rectangle') -> 'Rectangle':
        """Returns the overlapping rectangle between self and another rectangle."""
        x_left = max(self.x_left, other.x_left)
        x_right = min(self.x_right, other.x_right)
        y_lower = max(self.y_lower, other.y_lower)
        y_upper = min(self.y_upper, other.y_upper)

        # If there is no overlap, return a rectangle with zero area
        if x_left >= x_right or y_lower >= y_upper:
            return None

        return Rectangle(x_left, y_lower, x_right, y_upper)

    def area(self) -> int:
        """Calculates the area of the rectangle."""
        return max(0, self.x_right - self.x_left) * max(0, self.y_upper - self.y_lower)

def main():
    """Reads input, calculates the area overlapped by all rectangles, and prints the result."""
    lines = sys.stdin.read().splitlines()

    # Parse the first rectangle
    x_left, y_lower, x_right, y_upper = map(int, lines[0].split())
    common_overlap = Rectangle(x_left, y_lower, x_right, y_upper)

    # Process each subsequent rectangle
    for line in lines[1:]:
        x1, y1, x2, y2 = map(int, line.split())
        other_rect = Rectangle(x1, y1, x2, y2)
        common_overlap = common_overlap.overlap(other_rect)

        # If there is no common overlap, break early
        if common_overlap is None:
            print(0)
            return

    # Calculate and print the area of the common overlap
    print(common_overlap.area())

if __name__ == "__main__":
    main()
    