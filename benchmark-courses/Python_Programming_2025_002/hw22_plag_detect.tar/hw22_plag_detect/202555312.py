import sys

class Point:
    '''
    Attributes:
        x: x coordinate
        y: y coordinate
    '''
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def __str__(self):
        return str((self.x, self.y))


class Rectangle:
    '''
    Attributes:
        dl: lower left corner
        ur: upper right corner
        dr: lower right corner
        ul: upper left corner
    Methods:
        onRectangle: determines if a Point p is on the rectangle
    '''
    def __init__(self, corner_dl, corner_ur):
        self.dl = corner_dl
        self.ur = corner_ur
        self.dr = Point(self.ur.x, self.dl.y)
        self.ul = Point(self.dl.x, self.ur.y)

    def __str__(self):
        return_str = "corners: {" + str(self.ul)
        return_str += ", " + str(self.dl) + ", " + str(self.dr)
        return_str += ", " + str(self.ur) + "}"
        return return_str

    def on_rectangle(self, p):
        '''determines if p is on rectangle'''
        if (p.x <= self.ur.x) and (p.x >= self.dl.x) and (p.y <= self.ur.y) and (p.y >= self.dl.y):
            return True
        return False

    def area(self):
        '''returns area of rect'''
        return (self.dr.x - self.dl.x) * (self.ur.y - self.dr.y)

class Paper(Rectangle):
    '''same as Rectangle'''

def overlap(rect_1, rect_2):
    '''calculates overlap between two rects'''
    if (rect_1 is None) or (rect_2 is None):
        return None
    new_dl = Point(max(rect_1.dl.x, rect_2.dl.x), max(rect_1.dl.y, rect_2.dl.y))
    new_ur = Point(min(rect_1.ur.x, rect_2.ur.x), min(rect_1.ur.y, rect_2.ur.y))
    if (new_ur.x < new_dl.x) or (new_ur.y < new_dl.y):
        return None
    return Paper(new_dl, new_ur)


def main():
    '''main'''
    ini_coords = list(map(int, input().split()))
    overlap_paper = Paper(Point(ini_coords[0], ini_coords[1]), Point(ini_coords[2], ini_coords[3]))

    for line in sys.stdin:
        coords = list(map(int, line.split()))
        new_rect = Paper(Point(coords[0], coords[1]), Point(coords[2], coords[3]))
        overlap_paper = overlap(overlap_paper, new_rect)

    if overlap_paper is None:
        print(0)
    else:
        print(overlap_paper.area())


if __name__ == "__main__":
    main()
