class Paper:
    def __init__(self, xL, yL, xR, yR):
        self.xL = xL
        self.yL = yL
        self.xR = xR
        self.yR = yR

    def overlap(self, other):
        new_xL = max(self.xL, other.xL)
        new_yL = max(self.yL, other.yL)
        new_xR = min(self.xR, other.xR)
        new_yR = min(self.yR, other.yR)

        if new_xL < new_xR and new_yL < new_yR:
            return Paper(new_xL, new_yL, new_xR, new_yR)
        else:
            return None

    def area(self):
        return (self.xR - self.xL) * (self.yR - self.yL)


def main():
    import sys
    papers = []

    for line in sys.stdin:
        xL, yL, xR, yR = map(int, line.strip().split())
        papers.append(Paper(xL, yL, xR, yR))

    if not papers:
        print(0)
        return

    overlap_region = papers[0]
    for paper in papers[1:]:
        overlap_region = overlap_region.overlap(paper)
        if overlap_region is None:
            print(0)
            return

    print(overlap_region.area())


if __name__ == '__main__':
    main()
