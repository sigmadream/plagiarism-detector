def compute_overlap_area(rectangles):
    xL_max = rectangles[0][0]
    yL_max = rectangles[0][1]
    xR_min = rectangles[0][2]
    yR_min = rectangles[0][3]

    for xL, yL, xR, yR in rectangles[1:]:
        xL_max = max(xL_max, xL)
        yL_max = max(yL_max, yL)
        xR_min = min(xR_min, xR)
        yR_min = min(yR_min, yR)

    width = xR_min - xL_max
    height = yR_min - yL_max

    if width <= 0 or height <= 0:
        return 0
    return width * height

if __name__ == "__main__":
    import sys
    rectangles = []
    for line in sys.stdin:
        if line.strip():
            parts = list(map(int, line.strip().split()))
            rectangles.append(parts)

    if len(rectangles) < 2:
        print(0)
    else:
        result = compute_overlap_area(rectangles)
        print(result)
