class Paper:
    def __init__(self, xL, yL, xR, yR):
        self.xL = xL
        self.yL = yL
        self.xR = xR
        self.yR = yR

    def overlap(self, other):
        x_left = max(self.xL, other.xL)
        y_bottom = max(self.yL, other.yL)
        x_right = min(self.xR, other.xR)
        y_top = min(self.yR, other.yR)

        if x_left < x_right and y_bottom < y_top:
            return Paper(x_left, y_bottom, x_right, y_top)
        return None

    def area(self):
        return (self.xR - self.xL) * (self.yR - self.yL)


def calculate_overlapped_area(papers):
    if not papers:
        return 0

    overlap_region = papers[0]
    for paper in papers[1:]:
        overlap_region = overlap_region.overlap(paper)
        if not overlap_region:
            return 0
    return overlap_region.area()


def main():
    import sys
    papers = []
    for line in sys.stdin:
        parts = list(map(int, line.strip().split()))
        if len(parts) == 4:
            papers.append(Paper(*parts))

    print(calculate_overlapped_area(papers))


if __name__ == "__main__":
    main()