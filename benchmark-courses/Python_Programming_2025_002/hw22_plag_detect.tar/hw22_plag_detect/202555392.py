import sys

class Paper:
    """paper class, stores 4 vertices"""
    def __init__(self, xl, yl, xr, yr):
        self.llx = xl
        self.lly = yl
        self.urx = xr
        self.ury = yr

    def overlap(self, other_paper):
        """calculate overlapping the area """
        if (self.urx <= other_paper.llx or
            self.ury <= other_paper.lly or
            self.llx >= other_paper.urx or
            self.lly >= other_paper.ury):
            return 0
        return Paper(
            max(self.llx, other_paper.llx),
            max(self.lly, other_paper.lly),
            min(self.urx, other_paper.urx),
            min(self.ury, other_paper.ury)
        )

papers = []
points = sys.stdin.read().splitlines()
for line in points:
    a, b, c, d = map(int, line.split())
    papers.append(Paper(a, b, c, d))

base = papers[0]
for paper in papers[1:]:
    base = base.overlap(paper)
    if base == 0:
        print(0)
        sys.exit()

area = (base.urx - base.llx) * (base.ury - base.lly)
print(area)
