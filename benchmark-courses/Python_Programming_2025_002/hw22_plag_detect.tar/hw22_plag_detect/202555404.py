class Paper:
    def __init__(self, x_left, y_left, x_right, y_right):
        self.x_left = x_left
        self.y_left = y_left
        self.x_right = x_right
        self.y_right = y_right
    def overlap(self, other):
        left = max(self.x_left, other.x_left)
        right = min(self.x_right, other.x_right)
        bottom = max(self.y_left, other.y_left)
        top = min(self.y_right, other.y_right)
        if left < right and bottom < top:
            return (right - left) * (top - bottom)
        else:
            return 0
    def __repr__(self):
        return f"Paper({self.x_left}, {self.y_left}, {self.x_right}, {self.y_right})"
def calculate_total_overlap(papers):
    if len(papers) < 2:
        return 0
    total_overlap = 0
    n = len(papers)
    from itertools import combinations
    for i in range(n):
        for j in range(i + 1, n):
            overlap_area = papers[i].overlap(papers[j])
            total_overlap += overlap_area
    return total_overlap
def find_intersection_of_all(papers):
    if not papers:
        return 0
    left = max(paper.x_left for paper in papers)
    right = min(paper.x_right for paper in papers)
    bottom = max(paper.y_left for paper in papers)
    top = min(paper.y_right for paper in papers)
    if left < right and bottom < top:
        return (right - left) * (top - bottom)
    else:
        return 0
def main():
    papers = []
    try:
        while True:
            line = input().strip()
            if not line:
                break
            coords = list(map(int, line.split()))
            if len(coords) == 4:
                x_left, y_left, x_right, y_right = coords
                papers.append(Paper(x_left, y_left, x_right, y_right))
    except EOFError:
        pass
    if len(papers) < 2:
        print(0)
        return
    result = find_intersection_of_all(papers)
    print(result)


if __name__ == "__main__":
    main()