"""Calculate the overlapped area of multiple rectilinear papers."""

class Paper:
    """Represents a rectangle using lower-left and upper-right coordinates."""

    def __init__(self, x_left, y_bottom, x_right, y_top):
        self.x_left = x_left
        self.y_bottom = y_bottom
        self.x_right = x_right
        self.y_top = y_top

    def overlap(self, other):
        """Returns the overlapping Paper or None if no overlap."""
        x_left = max(self.x_left, other.x_left)
        y_bottom = max(self.y_bottom, other.y_bottom)
        x_right = min(self.x_right, other.x_right)
        y_top = min(self.y_top, other.y_top)

        if x_left < x_right and y_bottom < y_top:
            return Paper(x_left, y_bottom, x_right, y_top)
        return None

    def area(self):
        """Calculates the area of the paper."""
        return (self.x_right - self.x_left) * (self.y_top - self.y_bottom)


def compute_overlap_area():
    """Reads input and prints the area of overlapping region."""
    papers = []
    print("Enter paper rectangles (xL yL xR yR). Empty line to finish:")

    while True:
        try:
            line = input()
            if not line.strip():
                break
            x_l, y_l, x_r, y_r = map(int, line.strip().split())
            papers.append(Paper(x_l, y_l, x_r, y_r))
        except ValueError:
            print("Invalid input. Please enter four integers.")
            return

    if len(papers) < 2:
        print(0)
        return

    overlap_paper = papers[0]
    for paper in papers[1:]:
        overlap_paper = overlap_paper.overlap(paper)
        if overlap_paper is None:
            print(0)
            return

    print(overlap_paper.area())

# Call the function directly (required by some code checkers)
compute_overlap_area()