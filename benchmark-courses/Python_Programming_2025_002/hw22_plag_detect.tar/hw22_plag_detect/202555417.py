import sys


class Paper:
    def __init__(self, x1, y1, x2, y2):
        self.xl = x1
        self.yl = y1
        self.xr = x2
        self.yr = y2


def overlap(papers):
    """For calculating the area of the overlap rectangle"""
    max_xl = max(p.xl for p in papers)
    max_yl = max(p.yl for p in papers)
    min_xr = min(p.xr for p in papers)
    min_yr = min(p.yr for p in papers)

    width = min_xr - max_xl
    height = min_yr - max_yl

    return width * height if width > 0 and height > 0 else 0


def main():
    """Reads rectangles from input and prints their overlapping area."""
    papers = []
    for line in sys.stdin:
        if line.strip() == "":
            break
        x1, y1, x2, y2 = map(int, line.strip().split())
        papers.append(Paper(x1, y1, x2, y2))

    print(overlap(papers))


if __name__ == "__main__":
    main()
