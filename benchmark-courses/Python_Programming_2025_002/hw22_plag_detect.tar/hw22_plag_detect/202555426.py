import sys


class Paper:
    def __init__(self, x_left, y_left, x_right, y_right):
        """Initialize a Paper with lower-left and upper-right corners."""
        self.x_left = x_left
        self.y_left = y_left
        self.x_right = x_right
        self.y_right = y_right

    def overlap(self, other):
        """Return overlapping Paper if it exists, else None."""
        x_left = max(self.x_left, other.x_left)
        y_left = max(self.y_left, other.y_left)
        x_right = min(self.x_right, other.x_right)
        y_right = min(self.y_right, other.y_right)

        if x_left < x_right and y_left < y_right:
            return Paper(x_left, y_left, x_right, y_right)
        return None

    def area(self):
        """Return area of the paper."""
        return (self.x_right - self.x_left) * (self.y_right - self.y_left)


def main():
    """Read input, compute and print overlapping area."""
    lines = [line.strip() for line in sys.stdin if line.strip()]
    papers = []

    for line in lines:
        x_left, y_left, x_right, y_right = map(int, line.split())
        papers.append(Paper(x_left, y_left, x_right, y_right))

    if len(papers) < 2:
        print(0)
        return

    overlap_region = papers[0]
    for paper in papers[1:]:
        overlap_region = overlap_region.overlap(paper)
        if not overlap_region:
            print(0)
            return

    print(overlap_region.area())


if __name__ == "__main__":
    main()
