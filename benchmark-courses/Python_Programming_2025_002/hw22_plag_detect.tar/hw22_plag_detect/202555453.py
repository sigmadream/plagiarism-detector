from __future__ import annotations
import sys


class Paper:
    """Paper represents paper in the x-y coordinate system"""

    xl: int
    yl: int
    xr: int
    yr: int

    def __init__(self, xl, yl, xr, yr):
        self.xl = xl
        self.yl = yl
        self.xr = xr
        self.yr = yr

    def overlap(self, pape: Paper) -> Paper:
        """overlap returns new Paper object which has overlapped in the x-y coordinate system"""
        overlap_paper = Paper(0, 0, 0, 0)

        overlap_paper.xl = max(self.xl, pape.xl)
        overlap_paper.yl = max(self.yl, pape.yl)
        overlap_paper.xr = min(self.xr, pape.xr)
        overlap_paper.yr = min(self.yr, pape.yr)

        return overlap_paper

    def get_area(self):
        """get_area returns paper's area size"""

        return (self.yr - self.yl) * (self.xr - self.xl)


if __name__ == "__main__":
    PREV = None

    for line in sys.stdin.readlines():
        if line.strip() == "":
            break

        paper = Paper(*map(int, line.split()))

        if PREV is None:
            PREV = paper
        else:
            PREV = PREV.overlap(paper)

    print(PREV.get_area())
