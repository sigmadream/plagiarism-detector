a = int(input())
print('E' if a - ((a // 2) * 2) == 0 else 'O')
a = int(input())
print('E' if a - ((a // 2) * 2) == 0 else 'O')