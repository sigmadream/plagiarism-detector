#coding: utf-8

h = 0 # hour
m = 0 # minute
s = 0 # second

n = int(input())
h = int(n / 3600)
n = n % 3600
m = int(n / 60)
s = n % 60

print(f"{h}:{m}:{s}")