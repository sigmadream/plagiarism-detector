t = int(input())
h = t // 3600
t_remain = t - h * 3600
m = t_remain // 60
s = t_remain - m * 60
print(f"{h}:{m}:{s}")
