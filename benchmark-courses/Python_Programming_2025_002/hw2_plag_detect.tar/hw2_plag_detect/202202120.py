n = int(input())

#1시간 = 3600
h, rem = divmod(n, 3600) 

#1분 = 60초
m, s = divmod(rem, 60)    

print(f"{h}:{m}:{s}")
