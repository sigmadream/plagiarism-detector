s = input()
n=int(s)
h = int(n/3600)
x = n%3600
m = int(x/60)
s = x%60
print(f"{h}:{m}:{s}")
