# coding: utf-8

time = int(input())        

h = int(time / 3600)
m = int((time - h * 3600) / 60)
s = time - h * 3600 - m * 60


print(f"{h}:{m}:{s}")
