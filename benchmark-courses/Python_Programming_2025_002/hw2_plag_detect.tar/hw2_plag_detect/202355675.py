n = int(input())

h = 0
if n >= 3600:
    while n >= 3600:
        n -= 3600
        h += 1

m = 0
if n >= 60:
    while n >= 60:
        n -= 60
        m += 1

s = n

print(f"{h}:{m}:{s}")