#coding : utf-8

time = int(input())
minute = 0
hour = 0

while(time >= 3600):
    time -= 3600
    hour += 1

while(time >= 60):
    time -= 60
    minute += 1

print(f"{hour}:{minute}:{int(time)}")
