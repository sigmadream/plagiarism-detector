n = int(input())

h = (n - (n % 3600)) / 3600
m = ((n - h * 3600) - (n - h * 3600) % 60) / 60
s = n - (h * 3600 + m * 60)

print(f"{int(h)}:{int(m)}:{int(s)}")