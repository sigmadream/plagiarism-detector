x = int(input())


if (x >= 60):
    s = int(x%60)
else:
    s = x

if (60 <= x < 3600):
    m = int(((x - s) % 3600)/60)
else:
    if (x >= 3600):
            m = int(((x - s) % 3600) / 60)
    else:
        m = 0

if (x >= 3600):
    h = int((x // 3600))
else:
    h = 0

print(f"{h}:{m}:{s}")

