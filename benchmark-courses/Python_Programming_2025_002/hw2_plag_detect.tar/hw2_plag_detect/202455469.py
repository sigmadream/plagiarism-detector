#coding: utf-8

t = int(input())
x = t % 3600
s = int(x % 60)
m = int((x - s)/60)
h = int((t - x)/3600)
print(f"{h}:{m}:{s}")
