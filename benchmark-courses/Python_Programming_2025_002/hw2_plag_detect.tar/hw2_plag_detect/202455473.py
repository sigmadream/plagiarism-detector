n=int(input())

h=int(n/3600) #hours
m= int((n%3600)/60) #minutes 
s= n%60 #seconds

print(f"{h}:{m}:{s}")
