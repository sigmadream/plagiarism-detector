rawSeconds = int(input())

seconds = rawSeconds % 60
rawSeconds -= seconds

minutes = int((rawSeconds % 3600) / 60)
rawSeconds -= minutes * 60

hours = int(rawSeconds / 3600)


print(f"{hours}:{minutes}:{seconds}")
