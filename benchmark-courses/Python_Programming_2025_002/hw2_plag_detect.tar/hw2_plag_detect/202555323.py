n = int(input())

h = int(n / 3600)
remaining_seconds = n - (h * 3600)
m = int(remaining_seconds / 60)
s = remaining_seconds - (m * 60)
print(f" {h}:{m}:{s}")
