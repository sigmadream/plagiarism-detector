sec = int(input())

hours = (sec - (sec % 3600)) / 3600

minutes = ((sec % 3600) - (sec % 3600) % 60) / 60

seconds = (sec % 3600) - minutes * 60

print(f'{int(hours)}:{int(minutes)}:{int(seconds)}')