from datetime import timedelta

sec = int(input())
time = str(timedelta(seconds=sec))
h, m, s = time.split(":")

if m[0] == "0":
    m = m[1]
if s[0] == "0":
    s = s[1]
time = f"{h}:{m}:{s}"
print(time)
