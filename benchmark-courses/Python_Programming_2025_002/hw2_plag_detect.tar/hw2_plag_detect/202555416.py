# Read the input: the number of seconds (for example, 159)
n = 159

# Calculate hours, minutes, and seconds
hours = n // 3600        # 1 hour = 3600 seconds
n %= 3600                # Update n to the remaining seconds after hours
minutes = n // 60        # 1 minute = 60 seconds
seconds = n % 60         # Remaining seconds

# Print the result in the format h:m:s
print(f"{hours}:{minutes}:{seconds}")


# Read the input: the number of seconds (for example, 3675)
n = 3675

# Calculate hours, minutes, and seconds
hours = n // 3600        # 1 hour = 3600 seconds
n %= 3600                # Update n to the remaining seconds after hours
minutes = n // 60        # 1 minute = 60 seconds
seconds = n % 60         # Remaining seconds

# Print the result in the format h:m:s
print(f"{hours}:{minutes}:{seconds}")
