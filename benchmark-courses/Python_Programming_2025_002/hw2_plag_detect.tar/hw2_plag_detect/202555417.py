x=int(input())
if x>=3600:
 h=int(x/3600)
 m=int((x-(h*3600))/60)
 s=int(x-(h*3600)-(m*60))
else:
 h=0
if x>=60:
 m=int((x-(h*3600))/60)
 s=int(x-(h*3600)-(m*60))
else:
 m=0
 s=int(x)
print(f"{h}:{m}:{s}")
 
