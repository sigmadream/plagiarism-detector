n = int(input())  # Read the number of seconds

h = (n - n % 3600) / 3600  # Calculate hours 
m = (n - h * 3600 - (n - h * 3600) % 60) / 60  # Calculate minutes 
s = n - h * 3600 - m * 60  # Remaining seconds

print(f"{int(h)}:{int(m)}:{int(s)}")  # Print in h:m:s format
