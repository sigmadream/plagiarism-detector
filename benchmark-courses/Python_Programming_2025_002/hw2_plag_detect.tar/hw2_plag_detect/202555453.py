waiting_sec = int(input())

h = int(waiting_sec / 3600)
m = int((waiting_sec % 3600 - waiting_sec % 60) / 60)
s = waiting_sec % 60

print(f"{h}:{m}:{s}")