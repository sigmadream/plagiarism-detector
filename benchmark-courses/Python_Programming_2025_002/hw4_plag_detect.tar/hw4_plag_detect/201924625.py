import sys

def minF(a,b):
	return a if a < b else b;
	
def min1F(a,b,c):
	return minF(a,minF(b,c));
	
def min2F(a,b,c):
    if (a<=b and a>=c) or (a>=b and a<=c):
        return a
    if (b<=a and b>=c) or (b>=a and b<=c):
        return b
    if (c<=a and c>=b) or (c>=a and c<=b):
        return c
def maxF(a,b):
	return a if a > b else b;
	
def max1F(a,b,c):
	return maxF(a,maxF(b,c));
	
def max2F(a,b,c):
        return min2F(a,b,c)
        
min1 = 2147483647
min2 = 2147483647

max1 = -2147483648
max2 = -2147483648
while (line := sys.stdin.readline()) != "":
	val = int(line)
	min11 = min1F(min1,min2,val)
	min22 = min2F(min1,min2,val)
	min1 = min11
	min2 = min22
	
	max11 = max1F(max1,max2,val)
	max22 = max2F(max1,max2,val)
	max1 = max11
	max2 = max22
minD = min2-min1
maxD = max1-max2
if(maxD>minD):
	print(max2-min1)
else:
	print(max1-min2)