#coding: utf-8

import sys

min_num = 2 ** 31 - 1
max_num = - 2 ** 31

min_num_second = 2 ** 31 - 1
max_num_second = - 2 ** 31

num = 0
   
def diffrence(a, b):
    if a - b < 0:
        return -(a - b)
    else:
        return a - b

while (line := sys.stdin.readline()) != "":
    num = int(line)

    if num > max_num:
        max_num_second = max_num
        max_num = num
    elif num > max_num_second:
        max_num_second = num

    if num < min_num:
        min_num_second = min_num
        min_num = num
    elif num < min_num_second:
        min_num_second = num

if max_num_second == -2 ** 31:
    max_num_second = max_num

if min_num_second == 2 ** 31 - 1:
    min_num_second = min_num

if max_num == min_num:
    trimmed_diameter = 0
elif (diffrence(max_num, max_num_second) > diffrence(min_num, min_num_second)):
    trimmed_diameter = max_num_second - min_num
else:
    trimmed_diameter = max_num - min_num_second

print(trimmed_diameter)