# coding: utf-8

def find_max(nums):
    max_value = nums[0]
    for num in nums:
        if num > max_value:
            max_value = num
    return max_value

def find_min(nums):
    min_value = nums[0]
    for num in nums:
        if num < min_value:
            min_value = num
    return min_value

def trimmed_diameter(nums):
    nums.sort()

    min_val = nums[0]
    max_val = nums[-1]
    second_min = nums[1]
    second_max = nums[-2]

    min_distance = second_min - min_val
    max_distance = max_val - second_max

    if max_distance >= min_distance:
        new_nums = nums[:-1]  
    else:
        new_nums = nums[1:]

    new_max = find_max(new_nums)
    new_min = find_min(new_nums)
    
    return new_max - new_min

s = input()
nums = [int(x) for x in s.split()]

print(trimmed_diameter(nums))
