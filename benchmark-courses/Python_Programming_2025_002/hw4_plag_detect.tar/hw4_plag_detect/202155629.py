import sys

# finding the min and max values from a set of integers
def find_min_max(num_set):
    # initializing min and max values
    min_val, max_val = num_set[0], num_set[0]

    # checking the set & updating min and max values
    for num in num_set:
        # if the current num < min value => updating min value
        if num < min_val:
            min_val = num
        # if the current num > max value => updating max value
        if num > max_val:
            max_val = num

    # returning the min and max values of the set
    return min_val, max_val

# computing the minimum distance
def compute_distance(extreme, num_set):
    # initializing min distance
    min_dist = None
    
    for num in num_set:
        # exluding the extreme value from the distance calculation
        if num!= extreme:
            # calculating the distance
            dist = num - extreme if num > extreme else extreme - num
            # if new distance < old distance => updating the min distance
            if min_dist is None or dist < min_dist:
                min_dist = dist
    return min_dist

# calculating the trimmed diameter
# by removing the outlier and finding new min-max values
def trimmed_diameter(num_set):
    # finding the min and max values in the set of integers
    min_val, max_val = find_min_max(num_set)

    # computing the min and max distances
    min_dist = compute_distance(min_val, num_set)
    max_dist = compute_distance(max_val, num_set)

    # identifying the outlier
    # removing max value if its distance is larger, else removing min
    outlier = max_val if max_dist > min_dist else min_val

    # creating new set without the outlier
    trimmed_set = [num for num in num_set if num != outlier]

    # finding new min and max values
    new_min, new_max = find_min_max(trimmed_set)

    # computing the trimmed diameter
    return new_max - new_min

# reading input values
numbers = []
while (line := sys.stdin.readline().strip()) != "":
    # adding each number to the set
    numbers = numbers + [int(line)]

# checking if the input meets the condition
if len(numbers) > 2:
    # calculating & printing the trimmed diameter
    print(trimmed_diameter(numbers))

    
