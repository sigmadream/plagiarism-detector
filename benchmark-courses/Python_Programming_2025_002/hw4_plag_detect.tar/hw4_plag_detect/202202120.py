# Pure function to find minimum and maximum
# without using built-in min() or max()
def find_extremes(arr):
    min_value, max_value = arr[0], arr[0]
    for num in arr:
        if num < min_value:
            min_value = num
        if num > max_value:
            max_value = num
    return min_value, max_value

# Pure function to calculate sum of distances of a value from a set
def total_distance(value, arr):
    distance = 0
    for num in arr:
        distance += abs(num - value)
    return distance

# Pure function to compute trimmed diameter
def trimmed_diameter(arr):
    min_value, max_value = find_extremes(arr)
    
    # Count occurrences of min and max
    min_count = arr.count(min_value)
    max_count = arr.count(max_value)
    
    # Calculate distances
    min_dist = total_distance(min_value, [num for num in arr if num != min_value or min_count > 1])
    max_dist = total_distance(max_value, [num for num in arr if num != max_value or max_count > 1])
    
    # Determine which to remove
    if max_dist > min_dist:
        removed = False
        new_arr = []
        for num in arr:
            if num == max_value and not removed:
                removed = True
            else:
                new_arr.append(num)
    else:
        removed = False
        new_arr = []
        for num in arr:
            if num == min_value and not removed:
                removed = True
            else:
                new_arr.append(num)
    
    # Find new min and max
    remaining_min, remaining_max = find_extremes(new_arr)
    return remaining_max - remaining_min

# Read input
def main():
    numbers = []
    try:
        while True:
            num = int(input().strip())
            numbers.append(num)
    except EOFError:
        pass
    
    if len(numbers) > 2:
        print(trimmed_diameter(numbers))

if __name__ == "__main__":
    main()
