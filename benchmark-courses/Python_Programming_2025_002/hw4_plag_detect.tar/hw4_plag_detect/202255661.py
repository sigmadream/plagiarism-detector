import sys
M1=(-2)**31
M2=M1
m1=(2)**31-1
m2=m1
while(line:=sys.stdin.readline())!="":
    x=int(line)
    if x > M1:
        M2 = M1
        M1 = x
    elif x > M2:
        M2 = x

    if x < m1:
        m2 = m1
        m1 = x
    elif x < m2:
        m2 = x
t=M1-M2
if(t<0):
    t=t*-1
t1=m2-m1
if(t1<0):
    t1=t1*-1
if(t)>(t1):
    print(M2-m1)
else:
    print(M1-m2)
