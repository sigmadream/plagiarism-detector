def find_distance(value, values):
    """Calculate the distance between a value and the rest of the values in the set."""
    min_distance = float('inf')
    for v in values:
        distance = abs(value - v)
        if distance < min_distance:
            min_distance = distance
    return min_distance


def trimmed_diameter(values):
    """Calculate the trimmed diameter by excluding the outlier."""
    # Find the minimum and maximum values
    min_value = min(values)
    max_value = max(values)

    # Create a list excluding the min and max values
    values_without_min = [v for v in values if v != min_value]
    values_without_max = [v for v in values if v != max_value]

    # Find the distance of min_value to the rest of the values
    min_distance = find_distance(min_value, values_without_max)

    # Find the distance of max_value to the rest of the values
    max_distance = find_distance(max_value, values_without_min)

    # Determine the outlier: the one with the larger distance
    if max_distance > min_distance:
        outlier = max_value
    else:
        outlier = min_value

    # Remove the outlier from the list
    values.remove(outlier)

    # Calculate the diameter of the remaining values
    return max(values) - min(values)


# Read input values, one per line
values = []
while True:
    try:
        values.append(int(input()))  # Read integers until there's no more input
    except EOFError:
        break  # End of input

# Calculate and print the trimmed diameter
print(trimmed_diameter(values))
