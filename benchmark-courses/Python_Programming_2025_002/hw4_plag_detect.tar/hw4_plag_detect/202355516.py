def find_outlier_and_trimmed_diameter(nums):
    if len(nums) <= 2:
        return 0
    min_val = min(nums)
    max_val = max(nums)
    min_dist = float('inf')
    max_dist = float('inf')
    for num in nums:
        if num != min_val:
            min_dist = min(min_dist, abs(num - min_val))
        if num != max_val:
            max_dist = min(max_dist, abs(num - max_val))
    if max_dist > min_dist:
        outlier = max_val
    else:
        outlier = min_val
    trimmed_nums = [num for num in nums if num != outlier]
    trimmed_min = min(trimmed_nums)
    trimmed_max = max(trimmed_nums)
    return trimmed_max - trimmed_min

if __name__ == "__main__":
    import sys
    nums = []
    for line in sys.stdin:
        line = line.strip()
        if line:
            nums.append(int(line))
    print(find_outlier_and_trimmed_diameter(nums))
