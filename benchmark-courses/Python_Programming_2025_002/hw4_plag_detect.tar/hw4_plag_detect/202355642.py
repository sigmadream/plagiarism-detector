import sys

def find_trimmed_diameter(n, values):
    min_val = values[0]
    max_val = values[0]

    for i in range(n):
        if values[i] < min_val:
            min_val = values[i]
        if values[i] > max_val:
            max_val = values[i]

    second_min = None
    second_max = None

    for i in range(n):
        if values[i] != min_val:
            if second_min is None or values[i] < second_min:
                second_min = values[i]
        if values[i] != max_val:
            if second_max is None or values[i] > second_max:
                second_max = values[i]

    min_distance = second_min - min_val
    max_distance = max_val - second_max

    if max_distance > min_distance:
        return second_max - min_val
    else:
        return max_val - second_min

values = []
for line in sys.stdin:
    values.append(int(line.strip()))

print(find_trimmed_diameter(len(values), values))