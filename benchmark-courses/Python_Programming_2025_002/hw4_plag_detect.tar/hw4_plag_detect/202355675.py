import sys
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]: 
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
numbers = []
while (line := sys.stdin.readline().strip()) != "":
    try:
        num = int(line)
        numbers.append(num)
    except ValueError:
        print("error")
        continue
bubble_sort(numbers)
if (numbers[1] - numbers[0])>(numbers[-1]-numbers[-2]):
    diameter = numbers[-1] - numbers[1]
elif(numbers[1] - numbers[0])<(numbers[-1]-numbers[-2]):
    diameter = numbers[-2] - numbers[0]
else:
    diameter = numbers[-2] - numbers[0]

print(diameter)

