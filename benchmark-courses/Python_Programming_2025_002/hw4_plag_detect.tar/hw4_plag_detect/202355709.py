#coding : utf-8
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
import sys

nums = set()
while (line := sys.stdin.readline()) != "":
    nums.add(int(line))

numbers = sorted(nums)
max1 = list(numbers)[-1]
max2 = list(numbers)[-2]
min1 = list(numbers)[0]
min2 = list(numbers)[1]

if abs(max1-max2) > abs(min1-min2):
    print(max2-min1)
else:
    print(max1-min2)
