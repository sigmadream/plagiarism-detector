import sys

def trimmed_diameter():
    max = -2**31
    min = 2**31 - 1
    second_max = -2**31
    second_min = 2**31 - 1
    count = 0
    
    while (num := sys.stdin.readline().strip()) != "":
        num = int(num)
        count += 1
        
        if num > max:
            second_max = max
            max = num
        elif num > second_max:
            second_max = num
        
        if num < min:
            second_min = min
            min = num
        elif num < second_min:
            second_min = num
    
    if count < 2:
        return 0
    
    min_gap = second_min - min
    max_gap = max - second_max
    
    if max_gap > min_gap:
        return second_max - min
    else:
        return max - second_min

print(trimmed_diameter())