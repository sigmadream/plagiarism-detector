x = list(map(int, input().split(' ')))

a1 = min(x)
b1 = max(x)

x.remove(a1)
x.remove(b1)

y = x

a2 = min(y)
b2 = max(y)

def trim(x):
    if (b2 - b1) > (a2 - a1):
        return b1
    else:
        return a1

print(trim(x))
