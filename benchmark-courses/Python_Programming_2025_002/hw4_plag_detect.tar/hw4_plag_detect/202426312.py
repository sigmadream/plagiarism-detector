def add(a, b):
    return a + b

def find_max(nums, size):
    max_val = nums[0]
    for i in range(1, size):
        if nums[i] > max_val:
            max_val = nums[i]
    return max_val

def find_min(nums, size):
    min_val = nums[0]
    for i in range(1, size):
        if nums[i] < min_val:
            min_val = nums[i]
    return min_val

def calculate_distance(nums, size, value):
    max_distance = 0
    for i in range(size):
        distance = abs(nums[i] - value)
        if distance > max_distance:
            max_distance = distance
    return max_distance

def trim_diameter(nums, size):

    min_val = find_min(nums, size)
    max_val = find_max(nums, size)

    distance_min = calculate_distance(nums, size, min_val)
    distance_max = calculate_distance(nums, size, max_val)

    if distance_max > distance_min:
        outlier = max_val
    else:
        outlier = min_val

    new_nums = []
    for i in range(size):
        if nums[i] != outlier:
            new_nums.append(nums[i])

    new_min = find_min(new_nums, size - 1)
    new_max = find_max(new_nums, size - 1)

    return new_max - new_min

n = int(input())
nums = []
for _ in range(n):
    num = int(input())
    nums.append(num)

print(trim_diameter(nums, n))