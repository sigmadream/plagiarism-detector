import sys

def locate_extremes(values):
    smallest, largest = values[0], values[0]
    for val in values:
        if val < smallest:
            smallest = val
        if val > largest:
            largest = val
    return smallest, largest

def measure_proximity(boundary, values):
    closest_gap = None
    for val in values:
        if val != boundary:
            gap = abs(val - boundary)
            if closest_gap is None or gap < closest_gap:
                closest_gap = gap
    return closest_gap

def refine_range(values):
    smallest, largest = locate_extremes(values)
    closest_to_smallest = measure_proximity(smallest, values)
    closest_to_largest = measure_proximity(largest, values)
    exclusion = largest if closest_to_largest > closest_to_smallest else smallest
    refined_values = [val for val in values if val != exclusion]
    new_smallest, new_largest = locate_extremes(refined_values)
    return new_largest - new_smallest

data_points = []
while (entry := sys.stdin.readline().strip()) != "":
    data_points.append(int(entry))

if len(data_points) > 2:
    print(refine_range(data_points))
