import sys
numbers = []
difference = 0

while(line:=sys.stdin.readline())!="":
    numbers.append(int(line.strip()))

if len(numbers) < 2:
    print ("please insert more numbers")
    exit ()
    
min_num = numbers[0]
max_num = numbers[0]
diff = numbers [0]

for a in numbers:
    if a < min_num:
        min_num = a
    if a > max_num:
        max_num = a
        
min_diff = []
for i in numbers:
    if i != min_num:
        if i > min_num:
            diff = i - min_num
        else:
            diff = min_num - i
    min_diff.append(diff)

min1 = min_diff[0]
for b in min_diff:
    if b < min1:
        min1 = b
    
max_diff = []
for i in numbers:
    if i != max_num:
        if i > max_num:
            diff = i - max_num
        else:
            diff = max_num - i
    max_diff.append(diff)

max1 = max_diff[0]
for b in max_diff:
    if b < max1:
        max1 = b

if max1 > min1:
    numbers.remove(max_num)
else:
    numbers.remove(min_num)

min2 = numbers[0]
max2 = numbers[0]

for c in numbers:
    if c > max2:
        max2 = c
    if c < min2:
        min2 = c
        
difference = max2 - min2
print(difference)
