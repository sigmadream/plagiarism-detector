#coding: utf-8

import sys

def detectOutlier(max_, submax, min_, submin):
    return submax - min_ if (max_ - submax) > (submin - min_) else max_ - submin
    

max_ = -2147483649
submax = -2147483649
min_ = 2147483648
submin = 2147483648

while(line := sys.stdin.readline()) != "":
    n = int(line)
    if(n > max_):
        submax = max_
        max_ = n
    elif(n > submax):
        submax = n
    if(n < min_):
        submin = min_
        min_ = n
    elif(n < submin):
        submin = n

print(detectOutlier(max_,submax,min_,submin))
