
def calculate_trimmed_diameter(numbers):
  
    numbers.sort()
    
  
    min_gap = numbers[1] - numbers[0]
    max_gap = numbers[-1] - numbers[-2]
    
    
    if max_gap > min_gap:
        
        return numbers[-2] - numbers[0]
    else:
       
        return numbers[-1] - numbers[1]


numbers = []

while True:
    try:
        line = input()
        if line:
            numbers.append(int(line))
        else:
            break
    except EOFError:
        break
    except ValueError:
        continue

if len(numbers) > 2:
    result = calculate_trimmed_diameter(numbers)
    print(result)
else:
    print("Need more than 2 numbers")
