import sys

first = int(input())
minval = first
maxval = first
secondmin = None
secondmax = None

while (line := sys.stdin.readline()) != "":
    num = int(line)
    
    if num > maxval:
        secondmax = maxval  
        maxval = num  
    
    elif secondmax is None or num > secondmax:
        secondmax = num 
    
    if num < minval:
        secondmin = minval  
        minval = num 
    
    elif secondmin is None or num < secondmin:
        secondmin = num  


if secondmin is not None:
    if secondmax is not None:
        if secondmin - minval > maxval - secondmax:
            diameter = maxval - secondmin
        else:
            diameter = secondmax - minval
    else:
        diameter = 0
else:
    diameter = 0


print(diameter)
