import sys  

num1 = int(sys.stdin.readline())
num2 = int(sys.stdin.readline())

min1 = num1 if num1 < num2 else num2
max1 = num2 if num2 > num1 else num1
max2 = min1
min2 = max1

while (line := sys.stdin.readline()) != "":
    num = int(line)
    if num > max1:
        max2 = max1; max1 = num
    elif num > max2:
        max2 = num
        
    if num < min1:
        min2 = min1; min1 = num
    elif num < min2:
        min2 = num

max_diff = max1 - max2
min_diff = min2 - min1

if max_diff > min_diff:
    d = max2 - min1
else:
    d = max1 - min2
    
print(int(d))
