import sys
first_line = sys.stdin.readline().strip()
first_number = int(first_line)
min_value = first_number
max_value = first_number
all_numbers = [first_number]


for line in sys.stdin:
    
    current_number = int(line)
    all_numbers.append(current_number)
    
    if current_number < min_value:
        min_value = current_number
    if current_number > max_value:
        max_value = current_number

all_numbers.sort()

second_smallest = all_numbers[1]
second_largest = all_numbers[-2]

min_distance = second_smallest - min_value
max_distance = max_value - second_largest

if max_distance > min_distance:

    trimmed_diameter = second_largest - min_value
else:
    
    trimmed_diameter = max_value - second_smallest
print(trimmed_diameter)
