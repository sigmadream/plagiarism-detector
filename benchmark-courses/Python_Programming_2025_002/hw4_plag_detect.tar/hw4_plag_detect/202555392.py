import sys

highest, lowest = -2147483648, 2147483648
second_highest, second_lowest = -2147483648, 2147483648

while (s := sys.stdin.readline()) != "":
    s = int(s)
    if s > highest:
        second_highest = highest
        highest = s
    elif s > second_highest or second_highest == -2147483648:
        second_highest = s

    if s < lowest:
        second_lowest = lowest
        lowest = s
    elif s < second_lowest or second_lowest == 2147483648:
        second_lowest = s

def diameter(lowest, second_lowest, highest, second_highest):
    if second_lowest - lowest > highest - second_highest:
        lowest = second_lowest
    else:
        highest = second_highest
    return highest - lowest

result = diameter(lowest, second_lowest, highest, second_highest)

print(result)
