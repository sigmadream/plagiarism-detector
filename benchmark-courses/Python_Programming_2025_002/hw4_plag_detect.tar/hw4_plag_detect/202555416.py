def trimmed_diameter(numbers):
    if len(numbers) <= 2:
        raise ValueError("Set must contain more than 2 numbers")

    sorted_numbers = sorted(numbers)

    # Calculate trimmed diameter by excluding the minimum or maximum value
    max_diameter_exclude_min = sorted_numbers[-1] - sorted_numbers[1]  # Exclude the minimum
    max_diameter_exclude_max = sorted_numbers[-2] - sorted_numbers[0]  # Exclude the maximum

    # Return the larger of the two possible diameters
    return max(max_diameter_exclude_min, max_diameter_exclude_max)

# Reading input
n = int(input())  # Number of elements in the set
numbers = [int(input()) for _ in range(n)]

# Calculate and print the trimmed diameter
result = trimmed_diameter(numbers)
print(result)
