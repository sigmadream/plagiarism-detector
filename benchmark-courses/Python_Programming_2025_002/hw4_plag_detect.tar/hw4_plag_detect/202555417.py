import sys
def diameter(a,b):
    return b-a
line=sys.stdin.readline()
first_num=int(line)
line=sys.stdin.readline()
sec_num=int(line)
min_num=first_num if first_num<sec_num else sec_num
max_num=sec_num if sec_num>first_num else first_num
sec_max=min_num
sec_min=max_num
while(line:=sys.stdin.readline()) !="":
    num=int(line)
    if num>max_num:
        sec_max=max_num
        max_num=num
    elif sec_max<num<max_num:
        sec_max=num

    if num<min_num:
        sec_min=min_num
        min_num=num
    elif min_num<num<sec_min:
        sec_min=num

def max_min_distance(c,d):
    return d-c
max_dist=max_min_distance(sec_max,max_num)
min_dist=max_min_distance(min_num,sec_min)
if max_dist>min_dist:
    d=diameter(min_num,sec_max)
else:
    d=diameter(sec_min,max_num)
print(d)
