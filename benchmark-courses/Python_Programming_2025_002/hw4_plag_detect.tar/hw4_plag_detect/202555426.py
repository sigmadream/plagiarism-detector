def find_min(numbers):
    if not numbers:
        return None  
    min_val = numbers[0]
    for num in numbers:
        if num < min_val:
            min_val = num
    return min_val

def find_max(numbers):
    if not numbers:
        return None  
    max_val = numbers[0]
    for num in numbers:
        if num > max_val:
            max_val = num
    return max_val

def calculate_distance(numbers, value):
    distance = 0
    for num in numbers:
        if num != value:
            diff = num - value
            if diff < 0:
                diff = -diff
            distance += diff
    return distance

def calculate_trimmed_diameter(numbers):
    if len(numbers) <= 2:
        return 0

    min_val = find_min(numbers)
    max_val = find_max(numbers)

    min_distance = calculate_distance(numbers, min_val)
    max_distance = calculate_distance(numbers, max_val)

    if max_distance > min_distance:
        outlier = max_val
    else:
        outlier = min_val


    trimmed_numbers = []
    for num in numbers:
        if num != outlier:
            trimmed_numbers.append(num)

    trimmed_diameter = find_max(trimmed_numbers) - find_min(trimmed_numbers)

    return trimmed_diameter

if __name__ == "__main__":
    numbers = []
    while True:
        try:
            num = int(input())
            numbers.append(num)
        except EOFError:
            break

    result = calculate_trimmed_diameter(numbers)
    print(result)

