#coding: utf-8
import sys

min_int, max_int = None, None
next_min_int, prev_max_int = None, None

def get_diff(a, b):
  if a > b:
    return a - b
  else:
    return b - a

i = 0

while (line := sys.stdin.readline()) != "":
  num = int(line)
  
  if i == 0:
    min_int = max_int = num
    next_min_int, prev_max_int = 2**32, -2**32
  else:
    if num < min_int:
      next_min_int = min_int
      min_int = num
    elif min_int < num < next_min_int:
      next_min_int = num
    
    if num > max_int:
      prev_max_int = max_int
      max_int = num
    elif prev_max_int < num < max_int:
      prev_max_int = num

  i += 1


if get_diff(max_int, prev_max_int) > get_diff(next_min_int, min_int):
  print(get_diff(prev_max_int, min_int))
else:
  print(get_diff(max_int, next_min_int))
