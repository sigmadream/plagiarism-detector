def print_multiplication_table(x1, y1, x2, y2):
    print("+-----" * (x2 - x1 + 1) + "+")
    for j in range(y1, y2 + 1):
        print("|", end="")
        for i in range(x1, x2 + 1):
            print(f"{i * j:4} |", end="")
        print()
        print("+-----" * (x2 - x1 + 1) + "+")
# Example usage
x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

print_multiplication_table(x1, y1, x2, y2)