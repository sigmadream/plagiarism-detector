def pr_line(n):
    print("+"+"-----+" * (n+1))


scol = int(input())
srow = int(input())
ecol = int(input())
erow = int(input())

col = ecol - scol
row = erow - srow

pr_line(col)
for i in range(srow, erow + 1):
    print("|",end = "")
    for j in range(scol, ecol + 1):
        print(f" {i*j:3} |",end="")
    print()
    pr_line(col)
