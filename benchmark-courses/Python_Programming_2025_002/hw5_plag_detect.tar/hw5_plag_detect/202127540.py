#coding: utf-8
def make_a_line(num):
    for i in range(num * 6 + 1):
        if i % 6 == 0:
            print("+", end = "")
        else:
            print("-", end = "")
    print()

x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

for i in range(y1, y2 + 1):
    make_a_line(x2 - x1 + 1)
    for j in range(x1, x2 + 1):
        print(f"| {i * j:3} ", end = "")
    print("|")
make_a_line(x2 - x1 + 1)
