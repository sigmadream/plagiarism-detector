x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

# number of columns in the box
w = x2 - x1 + 1

# printing the top line
print("+", end="")
for i in range(w):
    print("-" * 5 + "+", end="")
print()

for y in range(y1, y2+1):
    print("|", end="")
    # printing the partial multiplication
    for x in range(x1, x2+1):
        print(f"{x*y:^5}|", end="")
    print()

    # printing the bottom line
    print("+", end="")
    for i in range(w):
        print("-" * 5 + "+", end="")
    print()
