x1=int(input())
y1=int(input())
x2=int(input())
y2=int(input())
b="+"+("-"*5+"+")*(x2-x1+1)
for y in range(y1,y2+1):
    print(b)
    s=""
    for x in range(x1,x2+1):
        s+="|"+f"{x*y:^5}"
    s+="|"
    print(s)
print(b)
