def print_table(x1, y1, x2, y2):
    print("+" , "+".join(["-----"] * (x2 - x1 + 1)) , "+")

    for row in range(y1, y2 + 1):
        print("".join([f"| {row * col:3} " for col in range(x1, x2 + 1)]) + "|")
        print("+" + "+".join(["-----"] * (x2 - x1 + 1)) + "+")


x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

print_table(x1, y1, x2, y2)
