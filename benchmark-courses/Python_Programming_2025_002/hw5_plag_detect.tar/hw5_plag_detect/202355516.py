x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

for y in range(y1, y2 + 1):
    print("+".join(["-" * 5] * (x2 - x1 + 1)).join(["+", "+"]))
    row = "|"
    for x in range(x1, x2 + 1):
        row += f" {x * y:3} |"
    print(row)

print("+".join(["-" * 5] * (x2 - x1 + 1)).join(["+", "+"]))