x1=int(input())
y1=int(input())
x2=int(input())
y2=int(input())

def b(n):
 print("+"+"+".join(["-"*5]*n)+"+")

def r(y,x1,x2):
 print("|"+"|".join(["{:^5}".format(x*y)for x in range(x1,x2+1)])+"|")

for y in range(y1,y2+1):
 b(x2-x1+1)
 r(y,x1,x2)
b(x2-x1+1)

