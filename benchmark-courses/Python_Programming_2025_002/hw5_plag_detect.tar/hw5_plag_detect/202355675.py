def print_partial_multiplication_table(x1, y1, x2, y2):

    table_size = 19
    
    for row in range(y1, y2 + 1):
        print("+-----" * (x2 - x1 + 1) + "+")
        for col in range(x1, x2 + 1):

            print(f"| {row * col:3d} ", end="") 
        print("|")
    print("+-----" * (x2 - x1 + 1) + "+")

a = int(input())  
b = int(input()) 
c = int(input()) 
d = int(input())  

print_partial_multiplication_table(a,b,c,d)