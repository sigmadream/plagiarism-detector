x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

for i in range(y1, y2+1):  # 1단부터 9단까지 반복
    for j in range(x1, x2+1):  # 각 단의 1부터 9까지 곱하기
        result = i * j
        print("+-----", end="")  # 상단 경계선
    print("+")  # 마지막 상단 경계선 마무리

    for j in range(x1, x2+1):  # 각 단의 값 출력
        result = i * j
        print(f"| {result:3}", end=" ")  # 값 출력
    print("|")  # 마지막 박스 마무리
print("+-----"*(x2-x1+1) + "+")
