x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

print("+" + ("-----+" * (x2 - x1 + 1)))

for y in range(y1, y2 + 1):
    for x in range(x1, x2 + 1):
        print(f"|{x*y:^5}", end="")
        9
    print("|")
    print("+" + ("-----+" * (x2 - x1 + 1)))