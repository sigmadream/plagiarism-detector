#coding: utf-8 2

x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

for row in range(y1,y2+1):
    print("+-----"*(x2-x1+1)+"+")
    for col in range(x1,x2+1):
        m = row*col
        print(f"| {m}", end=" ")
    print(f"|")
print("+-----"*(x2-x1+1)+"+")
