a = int(input())
b = int(input())
c = int(input())
d = int(input())
w = c - a + 1
print("+", end="")
for i in range(w):
    print("-" * 5 + "+", end="")
print()
for y in range(b, d+1):
    print("|", end="")
    for x in range(a, c+1):
        print(f"{x*y:^5}|", end="")
    print()
    print("+", end="")
    for i in range(w):
        print("-" * 5 + "+", end="")
    print()