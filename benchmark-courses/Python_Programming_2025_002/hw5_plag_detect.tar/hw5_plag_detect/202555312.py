left = int(input())
top = int(input())
right = int(input())
bottom = int(input())

width = right - left + 1 # sets the number of columns to print
height = bottom - top + 1 # sets the number of rows to print
verticalBorder = ("+-----") # Bonus points strategy: saves a duplicated string as a single literal

for verticalIndex in range(height): # prints each row in order
    for horizontalIndex in range(width): # prints the '+-----+' before each row
        print(verticalBorder, end="")
    print(verticalBorder[0])
    
    for horizontalIndex in range(width): # prints the numbers
        p = (horizontalIndex + left) * (verticalIndex + top) # Bonus points strategy: product, shortened to keep the length of the string literal small
        print(f"|{p:4}", end=" ") # prints the '| ... |' for each row
    print("|")

for horizontalIndex in range(width):
    print(verticalBorder, end="") # prints the final '+-----+' at the bottom

print(verticalBorder[0]) # Bonus points strategy: prints '+' without specifying a new literal
