def print_multiplication_subtable(x1, y1, x2, y2):
    # Calculate width of each cell
    cell_width = 5
    
    # Print top border
    print('+' + '+'.join(['-' * cell_width for _ in range(x2 - x1 + 1)]) + '+')
    
    # Iterate through each row
    for row in range(y1, y2 + 1):
        # Start the row
        row_elements = []
        
        # Iterate through each column
        for col in range(x1, x2 + 1):
            # Calculate multiplication result
            cell_value = row * col
            
            # Format the cell value with right alignment and total width of cell_width
            row_elements.append(f'{cell_value:^{cell_width}}')
        
        # Print the row with borders
        print('|' + '|'.join(row_elements) + '|')
        
        # Print bottom border of the row
        print('+' + '+'.join(['-' * cell_width for _ in range(x2 - x1 + 1)]) + '+')

# Example usage
print("Example with coordinates (9, 13) to (11, 14):")
print_multiplication_subtable(9, 9, 10, 11)