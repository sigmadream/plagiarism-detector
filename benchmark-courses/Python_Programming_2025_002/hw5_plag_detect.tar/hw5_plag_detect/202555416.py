x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

for j in range(y1,y2+1):
    print("+-----" * (x2-x1+1) + '+\n|',end='')
    for i in range(x1,x2+1):
        print(f" {i*j:3} |",end='')
    print()

print("+-----" * (x2-x1+1) + '+')