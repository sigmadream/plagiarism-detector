x1 = int(input())
y1 = int(input())

x2 = int(input()) + 1
y2 = int(input()) + 1

print(upper_side := '+' + "-----+" * (x2 - x1))
for x in range(y1, y2):
    print('|', end='')
    for y in range(x1, x2):
        print(f"{x * y:^5}|", end='')
    print('\n' + upper_side)