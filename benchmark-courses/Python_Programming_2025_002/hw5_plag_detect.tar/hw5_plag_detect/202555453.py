x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())

def print_frontier():
  print(("+" + "-" * 5) * (x2 - x1 + 1) + "+")

print_frontier()

for i in range(y1, y2 + 1):
  print("|", end="")

  for j in range(x1, x2 + 1):
    print(f" {i*j:3} ", end="")
    print("|", end="")

  print()
  print_frontier()
