def ch_person(word):
    """
    Capitalize the first letter of personal pronouns regardless of index.
    """
    person = ("i", "you", "we", "she", "he", "they")
    if word.lower() in person:
        return word[0].upper() + word[1:]
    else:
        return word


def ch_cap(word, n):
    """
    Capitalizes the nth character of a word (1-based), and lowercases the rest.
    """
    if len(word) < n:
        return word
    return ''.join(
        word[i].upper() if i == n - 1 else word[i].lower()
        for i in range(len(word))
    )


def myin():
    """
    Main input/output function.
    """
    n = int(input())
    string = input().split()

    for word in string:
        if word.lower() in ("i", "you", "we", "she", "he", "they"):
            word = ch_person(word)
        else:
            word = ch_cap(word, n)
        print(word, end=" ")

    return 0


if __name__ == "__main__":
    myin()
