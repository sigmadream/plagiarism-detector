def capitalize(ind, word):
    "ii"
    # checking for pronouns
    pronoun_capitalized = check_pronouns(word)
    if pronoun_capitalized:
        return pronoun_capitalized
    # converting to lowercase word
    word = word.lower()
    # capitalizing the index character
    if len(word) >= ind:
        return word[:ind-1] + word[ind-1].upper() + word[ind:]
    # returning unchanged word if the length < index
    return word


def check_pronouns(word):
    "ii"
    pronouns = {"i", "you", "we", "she", "he", "they"}
    # checking if the word is a pronoun
    if word.lower() in pronouns:
        # capitalizing 1st char
        return word[0].upper() + word[1:].lower()


def split_sentence(ind, sentence):
    "ii"
    # splitting the sentence
    words = sentence.split()
    # capitalizing each word
    result = [capitalize(ind, word) for word in words]
    return " ".join(result)


def main():
    "ii"
    # waiting for user's input
    ind = int(input())
    sentence = input()
    # processing the capitalization process
    result = split_sentence(ind, sentence)
    print(result)

if __name__ == "__main__":
    main()
