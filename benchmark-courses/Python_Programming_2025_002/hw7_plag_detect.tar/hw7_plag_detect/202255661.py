def should_capitalize_first(word: str) -> bool:
    pronouns = {"i", "you", "we", "she", "he", "they"}
    return word.lower() in pronouns


def capitalize_at_index(word: str, index: int) -> str:
    if len(word) <= index:
        return word.lower()
    return word[:index].lower() + word[index].upper() + word[index + 1:].lower()


# 실행 코드
index = int(input())
words = input().split()

result = []
for word in words:
    if should_capitalize_first(word):
        new_word = word[0].upper() + word[1:].lower()
    else:
        new_word = capitalize_at_index(word, index - 1)
    result.append(new_word)

print(" ".join(result))
