def is_special_word(word):
    """특정 대명사 키워드가 존재하는지 확인하는 함수입니다."""
    pronouns = {"i", "you", "we", "she", "he", "they"}
    return word.lower() in pronouns


def capitalize(word, index):
    """지정한 인덱스(index)의 문자를 대문자로 변환하고, 나머지는 소문자로 만듭니다."""
    if len(word) <= index:
        return word
    return word[:index] + word[index].upper() + word[index+1:].lower()


def main():
    """입력을 받아 각 단어를 조건에 맞게 대문자로 변환한 후 출력합니다."""
    index = int(input())
    words = input().split()
    for word in words:
        if is_special_word(word):
            capitalized = word[0].upper() + word[1:].lower()
        else:
            capitalized = capitalize(word, index-1)
        print(capitalized, end =" ")

if __name__ == "__main__":
    main()
    