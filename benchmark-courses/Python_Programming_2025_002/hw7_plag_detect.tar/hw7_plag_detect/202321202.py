def capitalize_word(word, i):
    special_pronouns = {"i", "you", "we", "she", "he", "they"}
    if word.lower() in special_pronouns:
        return word.capitalize()

    if len(word) < i:
        return word.lower()

    return word[:i - 1].lower() + word[i - 1].upper() + word[i:].lower()


def process_input(i, input_string):
    words = input_string.split()
    capitalized_words = [capitalize_word(word, i) for word in words]
    return ' '.join(capitalized_words)


def main():
    i = int(input())
    input_string = input().strip()

    result = process_input(i, input_string)
    print(result)


if __name__ == "__main__":
    main()
