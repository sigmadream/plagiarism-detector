def is_pronoun(word):
    pronouns = {"i", "you", "we", "she", "he", "they"}
    return word.lower() in pronouns

def process_word(word, index):
    if is_pronoun(word):
        return word[0].upper() + word[1:]
    if len(word) < index:
        return word
    return word[:index-1] + word[index-1].upper() + word[index:]

def main():
    i = int(input().strip())
    words = input().split()
    processed_words = [process_word(word, i) for word in words]
    print(" ".join(processed_words))

if __name__ == "__main__":
    main()
