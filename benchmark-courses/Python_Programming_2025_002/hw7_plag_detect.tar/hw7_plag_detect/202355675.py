def capitalize_ith_character(word: str, index: int) -> str:

    if len(word) >= index:
        return word[:index - 1] + word[index - 1].upper() + word[index:]
    return word

def capitalize_pronouns(word: str) -> str:

    pronouns = {"i", "you", "we", "she", "he", "they"}
    return word.capitalize() if word.lower() in pronouns else word

def main():
 
    index = int(input().strip())
    words = input().strip().split()
    
    processed_words = [
        capitalize_pronouns(capitalize_ith_character(word, index)) for word in words
    ]
    
    print(" ".join(processed_words))

if __name__ == "__main__":
    main()
