i = int(input())  # 첫 번째 줄: 인덱스 i 입력받기
words = input().split()  # 두 번째 줄: 단어들 입력받기

pronouns = {"i", "you", "we", "she", "he", "they"}  # 대명사 목록
result = []

for word in words:
    if word.lower() in pronouns:
        result.append(word.capitalize())  # 대명사는 첫 글자 대문자
    elif len(word) >= i:
        result.append(word[:i-1] + word[i-1].upper() + word[i:])  # i번째 글자 대문자화
    else:
        result.append(word)  # 변경 없이 추가

print(" ".join(result))  # 결과 출력
