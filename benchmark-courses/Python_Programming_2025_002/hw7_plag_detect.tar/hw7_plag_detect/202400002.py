def is_even(n):
    "is_even checks if the argument n is even or not"
    if int(n / 2) * 2 == n:
        print("E")
    else:
        print("O")

a = int(input())
b = int(input())

is_even(a)
is_even(b)
