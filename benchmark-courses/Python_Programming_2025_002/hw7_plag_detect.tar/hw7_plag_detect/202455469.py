#coding: utf-8

i = int(input())
words = input().split()

pronouns = {"i", "you", "we", "she", "he", "they"}

result = []
for word in words:
    lower_word = word.lower()
    if lower_word in pronouns:
        new_word = word[0].upper() + word[1:]
    elif len(word) >= i:
        idx = i - 1
        new_word = word[:idx] + word[idx].upper() + word[idx+1:]
    else:
        new_word = word
    result.append(new_word)

print(" ".join(result))
