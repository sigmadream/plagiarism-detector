def is_pronoun(word):
    "is_pronoun searches these words and capitalizes them"
    pronouns = {"i", "you", "we", "she", "he", "they"}
    return word.lower() in pronouns

def process_pronoun(word):
    "is_pronoun searches these words and capitalizes them"
    return word[0].upper() + word[1:].lower()

def capitalize_ith_char(word, i):
    "is_pronoun searches these words and capitalizes them"
    word = word.lower()
    if len(word) >= i:
        return word[:i-1] + word[i-1].upper() + word[i:]
    return word

def process_words(i, words):
    "is_pronoun searches these words and capitalizes them"
    words = [word.lower() for word in words]
    processed_words = []
    for word in words:
        if is_pronoun(word):
            processed_word = process_pronoun(word)
        else:
            processed_word = capitalize_ith_char(word, i)
        processed_words.append(processed_word)
    return ' '.join(processed_words)

def main():
    "is_pronoun searches these words and capitalizes them"
    i = int(input().strip())
    words = input().strip().split()
    print(process_words(i, words))

if __name__ == "__main__":
    main()
