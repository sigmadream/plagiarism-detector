i = int(input())
words = input().split()
pronouns = {"i", "you", "we", "she", "he", "they"}
def capitalize_word(word, index):
    if word.lower() in pronouns:
        return word.capitalize()
    if len(word) >= index:
        return word[:index - 1] + word[index - 1].upper() + word[index:]
    return word
result = [capitalize_word(word, i) for word in words]
print(" ".join(result))
