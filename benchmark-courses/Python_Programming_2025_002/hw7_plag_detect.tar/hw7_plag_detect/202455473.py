def capitalize_words(word_index, words_list):
    """Capitalizes the i-th character of each word if its length is at least i.
    Special pronouns are always capitalized."""
    special_pronouns = {"i", "you", "we", "she", "he", "they"}
    result = []
    for word in words_list:
        if word.lower() in special_pronouns:
            word = word.capitalize()
        elif len(word) >= word_index > 0:
            word = word[:word_index-1].lower() + word[word_index-1].upper() + word[word_index:].lower()
        else:
            word = word.lower()
        result.append(word)
    return " ".join(result)

# Read input
word_index = int(input().strip())
words_list = input().strip().split()

# Ensure index is within valid range
if word_index <= 0 or word_index > 20:
    raise ValueError("Index must be between 1 and 19.")

# Process and print result
print(capitalize_words(word_index, words_list))
