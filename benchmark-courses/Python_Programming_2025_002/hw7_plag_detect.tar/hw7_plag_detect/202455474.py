index = int(input())
user_input = input()

def convert_to_lowered(sentence):
    lowered = ''
    for char in sentence:
        lowered += char.lower()
    return lowered

def convert_to_list(lowered):
    return lowered.split()

def main(sentence, index):
    pronouns = {"i", "you", "we", "she", "he", "they"}
    result = ''
    lowered = convert_to_list(convert_to_lowered(sentence))
    for word in lowered:
        if word in pronouns:
            result += word[0].upper() + word[1:]
        elif len(word) >= index:
            result += word[0:index-1] + word[index-1].upper() + word[index:]
        else:
            result += word
        result += " "
    result = result[:-1]
    return result

print(main(user_input, index))
