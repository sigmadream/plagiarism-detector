upp_case = 'you can speak the reason'
words = upp_case.split()
answer_words = []

for word in words:
    if word.lower() == 'you':
        if len(word) >= 1:
            answer_words.append(word[0].upper() + word[1:])
        else:
            answer_words.append(word)
    elif word.lower() in ['speak', 'reason']:
        if len(word) >= 4:
            answer_words.append(word[:3]+ word[3].upper() + word[4:])
        else:
            answer_words.append(word)
    else:
        answer_words.append(word)

answer = ' '.join(answer_words)
print(answer)