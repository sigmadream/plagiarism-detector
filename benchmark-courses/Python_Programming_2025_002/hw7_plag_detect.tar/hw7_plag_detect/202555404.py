
 def capitalize_ith_character(word, i):
    """Capitalize the i-th character of the word if it exists."""
    if i < len(word):
        return word[:i] + word[i].upper() + word[i+1:]
    return word

def capitalize_pronoun(word):
    """Capitalize the first character if the word is a pronoun."""
    pronouns = {"i", "you", "we", "she", "he", "they"}
    if word in pronouns:
        return word.capitalize()
    return word

def capitalize_words(i, words):
    """Capitalize the i-th character of each word in the sequence."""
    result = []
    for word in words:
        word = capitalize_pronoun(word)
        word = capitalize_ith_character(word, i - 1)  # Adjust for 0-based index
        result.append(word)
    return result

def main():
    # Read input
    i = int(input().strip())
    words = input().strip().split()

    # Capitalize words
    capitalized_words = capitalize_words(i, words)

    # Print the result
    print(" ".join(capitalized_words))

if __name__ == "__main__":
    main()  
