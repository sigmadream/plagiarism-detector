def capitalize_ith_letter(word, i):
    if len(word) >= i:
        return word[:i-1] + word [i-1].upper() + word[i:]
    return word
def process_sentence(i, sentence):
    pronouns = {"i","you","we","she","he","they"}
    words = sentence.split()

    result = [
        word.capitalize() if word.lower() in pronouns else capitalize_ith_letter(word, i)
        for word in words]
    return " ".join(result)
def main():
    i =int(input().strip())
    sentence = input().strip()
    print(process_sentence(i, sentence))
if __name__ == "__main__":
    main()
