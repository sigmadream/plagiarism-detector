def check_ref_person_string(word):
    """
    check_ref_person_string is the function that checks string refers persons.
    """
    return word.lower() in ["i", "you", "we", "she", "he", "they"]

def check_word_index(word, i):
    """
    check_word_index is the function that checks len(word) < i
    """
    return len(word) < i

def main():
    """
    main function
    """
    
    i = int(input())
    string = input()
    words = string.split()

    for word in words:
        if check_ref_person_string(word):
            print(word[0].upper() + word[1:].lower(), end=" ")
            continue

        if check_word_index(word, i):
            print(word, end=" ")
            continue

        for j in range(0, len(word)):
            if i - 1 == j:
                print(word[j].upper(), end="")
            else:
                print(word[j].lower(), end="")
        print(" ", end="")

if __name__ == "__main__":
    main()
