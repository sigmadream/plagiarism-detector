def vow_detector(suspect_char):
    "find the vow and return False"
    match suspect_char:
        case 'a':
            return False
        case 'e':
            return False
        case 'i':
            return False
        case 'o':
            return False
        case 'u':
            return False
        case _:
            return True


def lower_str(upper_str):
    "make string to lower_string"
    no_upper_str = ""
    for i in range(len(upper_str)):
        no_upper_str += upper_str[i].lower()
    return no_upper_str


def extract_vow(input_str):
    "extract all the vows in the input string"
    no_vow_str = ""
    for i in range(len(input_str)):
        if len(input_str) == 1 or vow_detector(input_str[i]):
            no_vow_str += input_str[i]
    return no_vow_str


def extract_vow_last_word(input_str):
    "extract all the vows in the input string for last word"
    no_vow_str_last_word = ""
    for i in range(len(input_str)):
        if vow_detector(input_str[i]):
            no_vow_str_last_word += input_str[i]
        else:
            break
    return no_vow_str_last_word


def main():
    "make snake case string without vows in some rules"
    function_name = input().split()
    return_name = ""
    for i in range(len(function_name)):
        if i != 0:
            return_name += "_"
        if i == len(function_name) - 1 and i != 0:
            return_name += extract_vow_last_word(lower_str(function_name[i]))
        elif i == 0:
            return_name += extract_vow(lower_str(function_name[i]))
        else:
            return_name += lower_str(function_name[i])
    print(return_name)

if __name__ == "__main__":
    main()
