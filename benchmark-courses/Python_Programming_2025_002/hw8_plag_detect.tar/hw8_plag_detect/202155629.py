def check_vwls(word):
    "Checking & removing vowels in the first word"
    # all vowel characters
    vwls = "AEIOUaeiou"
    result = ""
    # iteratting through each character in the word
    for char in word:
        # checking if the character is not a vowel => including to the result
        if char not in vwls:
            result += char
    return result


def remove_vwls(word):
    "Removing all characters at the first vowel found in the last word"
    # all vowel characters
    vowels = "AEIOUaeiou"
    i = 0
    # looping through each char in the last word
    while i < len(word):
        # checking if a vowel is found => removing all chars after
        if word[i] in vowels:
            return word[:i]
        # moving to the next character
        i += 1
    # if no vowel is found => remaining unchanged
    return word


def make_func_name(sequence):
    "Converting the sequence into a function name"
    # splitting the input sequence into a list of words
    words = sequence.split()
    # checking if there is only one word => processing it
    if len(words) == 1:
        return check_vwls(words[0]).lower()
    # removing all vowels in the first word
    first_word = check_vwls(words[0]).lower()
    # removing all chars at the first vowel found in the last word
    last_word = remove_vwls(words[-1]).lower()
    # converting middle words to lowercase
    middle_words = [word.lower() for word in words[1:-1]]
    result = first_word
    # constructing the final function name
    for word in middle_words:
        # joining all the middle words using _
        result += "_" + word
    # adding the last word to the final result
    result += "_" + last_word
    return result


def main():
    "Main function"
    # reading input from the user
    sequence = input()
    # processing the creation of function name
    result = make_func_name(sequence)
    print(result)

if __name__ == "__main__":
    main()
