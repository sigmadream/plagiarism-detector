VOWELS = "aeiou"

def remove_vowels(word):
    """단어에서 모음만 제거하는 함수"""
    result = ""
    for ch in word:
        if ch not in VOWELS:
            result += ch
    return result


def remove_vowels_to_end(word):
    """단어의 첫 모음 이후로 제거하는 함수"""
    i = 0
    while i < len(word):
        if word[i] in VOWELS:
            return word[:i]
        i += 1
    return word


def make_concat(words):
    """단어 리스트를 snake방식으로 출력"""
    result = ""
    i = 0
    while i < len(words):
        result += words[i]
        if i < len(words) - 1:
            result += "_"
        i += 1
    return result


def main():
    """사용자에게 input을 받고, snake 방식으로 만든 output을 출력하는 함수"""
    words = input().split()
    words = [w.lower() for w in words]

    result = []

    # 첫 단어 처리
    result.append(remove_vowels(words[0]))

    # 중간 단어들 그대로
    for word in words[1:-1]:
        result.append(word)

    # 마지막 단어 처리
    if len(words) > 1:
        result.append(remove_vowels_to_end(words[-1]))

    print(make_concat(result))

if __name__ == "__main__":
    main()
