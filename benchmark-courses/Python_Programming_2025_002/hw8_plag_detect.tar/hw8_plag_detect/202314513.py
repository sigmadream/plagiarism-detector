def remove_vowels(word):
    result = ""
    vowels = "aeiouAEIOU"
    for ch in word:
        if ch not in vowels:
            result += ch
    return result

def cut_after_first_vowel(word):
    result = ""
    vowels = "aeiouAEIOU"
    for ch in word:
        if ch in vowels:
            break
        result += ch
    return result

def process(words):
    n = len(words)
    parts = []
    for i in range(n):
        w = words[i]
        if i == 0:
            parts.append(remove_vowels(w.lower()))
        elif i == n - 1 and n > 1:
            parts.append(cut_after_first_vowel(w.lower()))
        else:
            parts.append(w.lower())
    result = ""
    for i in range(len(parts)):
        result += parts[i]
        if i != len(parts) - 1:
            result += "_"
    return result

def main():
    line = input()
    words = line.split()
    print(process(words))

if __name__ == "__main__":
    main()