def remove_vowels(word):
    s = ""
    for c in word:
        if c not in "aeiou":
            s += c
    return s

def trim_last(word):
    for i, c in enumerate(word):
        if c in "aeiou":
            return word[:i]
    return word

def main():
    words = input().strip().split()
    for i in range(len(words)):
        words[i] = words[i].lower()
    if len(words) == 1:
        result = remove_vowels(words[0])
    else:
        result = remove_vowels(words[0])
        for i in range(1, len(words) - 1):
            result += "_" + words[i]
        result += "_" + trim_last(words[-1])
    print(result)

if __name__ == "__main__":
    main()
