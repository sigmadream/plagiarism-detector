import sys

def find_vowels(word):
    vowels = "aeiouAEIOU"
    result = []
    i = 0
    while i < len(word):
        j = 0
        while j < len(vowels):
            if word[i] == vowels[j]:
                result.append(word[i])
                break
            j += 1
        i += 1
    return result

def delete_vowels(vov, word):
    real = []
    for i in range(len(word)):
        if not word[i] in vov:
            real.append(word[i])
    return real

def process_last_word(word):
    vowels = "aeiouAEIOU"
    index = 0
    while index < len(word):
        if word[index] in vowels:
            return word[:index]  # Remove characters after the first vowel
        index += 1
    return word  # If no vowels, return as is

def to_lowercase(word):
    result = ""
    for char in word:
        if 'A' <= char <= 'Z':
            result += chr(ord(char) + 32)
        else:
            result += char
    return result

def split_sentence(sentence):
    words = []
    word = ""
    for char in sentence:
        if char == " ":
            if word:
                words.append(word)
                word = ""
        else:
            word += char
    if word:
        words.append(word)
    return words

def convert_to_function_name(sentence):
    words = split_sentence(sentence)
    if not words:
        return ""
    
    vowels_in_first = find_vowels(words[0])
    first_word = delete_vowels(vowels_in_first, words[0])
    first_processed = to_lowercase("".join(first_word))
    
    real = [first_processed]
    
    if len(words) > 1:
        middle_words = []
        for j in range(1, len(words) - 1):
            middle_words.append(to_lowercase(words[j]))
        
        last_word = process_last_word(words[-1])
        last_processed = to_lowercase(last_word)
        
        real.extend(middle_words)
        real.append(last_processed)
    
    return "_".join(real)

if __name__ == "__main__":
    sentence = ""
    while True:
        char = sys.stdin.read(1)
        if char == "\n" or char == "":
            break
        sentence += char
    print(convert_to_function_name(sentence))