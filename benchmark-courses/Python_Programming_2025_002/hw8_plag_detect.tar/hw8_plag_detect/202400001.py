i = int(input())
words = input().split()
pronouns = ["i", "you", "we", "she", "he", "they"]

for index in range(len(words)):
    word = words[index]
    if i == 1:
        words[index] = word[0].upper() + word[1:].lower()
    else:
        if word.lower() in pronouns:
            word = word[0].upper() + word[1:]
        if len(word) >= i:
            word = word[:i-1] + word[i-1].upper() + word[i:]
        words[index] = word

print(" ".join(words))
