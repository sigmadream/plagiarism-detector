def remove_vowels(word):
    vowels = "aeiou"
    result = ""
    for char in word:
        if char not in vowels:
            result += char
    return result

def trim_after_first_vowel(word):
    vowels = set("aeiou")
    i = 0
    while i < len(word):
        if word[i] in vowels:
            return word[:i]
        i += 1
    return word

def convert_to_function_name(sentence):
    words = sentence.lower().split()
    if not words:
        return ""
    
    words[0] = remove_vowels(words[0])
    if len(words) > 1:
        words[-1] = trim_after_first_vowel(words[-1])
    
    function_name = words[0]
    for word in words[1:]:
        function_name += "_" + word
    
    return function_name

def main():
    sentence = input().strip()
    print(convert_to_function_name(sentence))

if __name__ == "__main__":
    main()
