def remove_vowels(word):
    "Removes all vowels from a given word."
    vowels = "aeiou"
    return "".join(char for char in word if char not in vowels)

def truncate_at_first_vowel(word):
    "Removes the first vowel and everything after it from the word."
    vowels = "aeiou"
    for i, char in enumerate(word):
        if char in vowels:
            return word[:i]
    return word

def generate_function_name(text):
    "Processes the text into a snake_case function name."
    words = text.lower().split()

    if not words:
        return ""

    words[0] = remove_vowels(words[0])

    if len(words) > 1:
        words[-1] = truncate_at_first_vowel(words[-1])

    return "_".join(words)

user_input = input().strip()
print(generate_function_name(user_input))
