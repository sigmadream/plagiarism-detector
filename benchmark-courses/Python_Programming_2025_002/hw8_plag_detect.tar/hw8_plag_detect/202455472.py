input_string = input().strip()
words = input_string.split()


def remove_vowels(word):
    """Function to remove vowels from the first word"""
    vowels = "aeiouAEIOU"
    result =""
    for char in word:
        if char.lower() not in vowels:
            result += char
    return result

def letters_after_first_vowel(word):
    """Function to remove letters in the last word except the first one"""
    vowels = 'aeiouAEIOU'
    index = 0
    while index < len(word):
        if word[index].lower() in vowels:
            break
        index += 1
    return word[:index]

def main():
    """Function to check middle words"""
    first_word = remove_vowels(words[0])
    if len(words)>1:
        last_word = letters_after_first_vowel(words[-1])
    else:
        last_word = ""
    if len(words)>2:
        middle_words = words[1:-1]
    else:
        middle_words = []
    result = first_word
    for word in middle_words:
        result += "_" + word
    if len(words)>1:
        result += "_"+ last_word
    print(result.lower())
main()
