def convert_to_function_name(sentence):
    vowels = "aeiou"
    words = sentence.lower().split()  # Convert to lowercase and split into words

    # Remove vowels from first word
    words[0] = "".join(c for c in words[0] if c not in vowels)

    # Remove everything after the first vowel in the last word (if more than one word exists)
    if len(words) > 1:
        for i, c in enumerate(words[-1]):
            if c in vowels:
                words[-1] = words[-1][:i]
                break

    print("_".join(words))  # Join with underscores and print

# Get input and process
convert_to_function_name(input().strip())
