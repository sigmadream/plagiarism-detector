user_input = input()
vowels = {'a','e','i','o','u','A','E','I','O','U'}


def main(sentence):
    """ This is the entry point of the script.
        This function takes user input and returns the answer"""
    words_list = sentence.split(" ")
    result = process_first_word(words_list[0]) + "_"

    for word in words_list[1:-1]:
        result += word + "_"

    result += process_last_word(words_list)

    return result[:-1].lower() if result[-1] == "_" else result.lower()

def process_first_word(word):
    """This functions processes the first word"""
    result = ""
    for char in word:
        if char in vowels:
            continue
        result += char
    return result

def process_last_word(words_list):
    """This function processes the last word"""
    result = ""
    last = words_list[-1]
    if len(words_list) > 1 and len(last) > 1:
        index = find_vowel_index(last)
        result += last[:index]
    elif len(words_list) > 1 and len(last) == 1:
        result += last
    return result

def find_vowel_index(word):
    """ This function takes word as input and
        returns the index of the first vowel found from the word"""
    for i in range(len(word)):
        if word[i] in vowels:
            return i
    return 0

print(main(user_input))
