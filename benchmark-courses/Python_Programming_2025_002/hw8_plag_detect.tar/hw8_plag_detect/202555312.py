VOWELS = "aeiou"


def strip_vowels(w):
    "Removes all vowels from a given string."
    stripped_word = ""
    for letter in w:
        stripped_word += "" if letter in VOWELS else letter
    return stripped_word

def strip_after_vowel(w):
    "Removes all characters from the first vowel and after from a given string"
    stripped_word = ""
    for letter in w:
        if letter in VOWELS:
            return stripped_word
        stripped_word += letter
    return stripped_word


def main():
    "main function"
    input_string = input().lower()
    list_of_words = input_string.split()
    output_string = ""

    index = 0
    for word in list_of_words:
        if index == 0:
            output_string += strip_vowels(word) + "_"
        elif index == len(list_of_words) - 1:
            output_string += strip_after_vowel(word) + "_"
        else:
            output_string += word + "_"

        index += 1
    print(output_string[:-1])

if __name__ == "__main__":
    main()
