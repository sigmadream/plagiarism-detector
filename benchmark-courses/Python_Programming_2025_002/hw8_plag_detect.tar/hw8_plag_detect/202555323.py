def main():
    
    words = input().strip().split()
    result = ""
    
    first_word = words[0].lower()
    first_processed = ""
    for char in first_word:
        if char not in "aeiou":
            first_processed += char
    result = first_processed
    
    
    if len(words) > 1:
        for i in range(1, len(words) - 1):
            result += "_" + words[i].lower()
            

        last_word = words[-1].lower()
        last_processed = ""
        found_vowel = False
        
        for char in last_word:
            if char in "aeiou":
                found_vowel = True
                break
            last_processed += char
        
        if not found_vowel:
            last_processed = last_word
            
        result += "_" + last_processed
        
    print(result)

if __name__ == "__main__":
    main()