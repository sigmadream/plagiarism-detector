def remove_vowels(word, vowels="aeiou"):
    return ''.join(char for char in word if char not in vowels)
def cut_at_first_vowel(word, vowels="aeiou"):
    result = []
    for char in word:
        if char in vowels:
            break
        result.append(char)
    return ''.join(result)
def process_text(input_text):
    vowels = "aeiou"
    if not input_text:
        return ""
    words = input_text.lower().split()
    if len(words) == 1:
        return remove_vowels(words[0], vowels)
    first_processed = remove_vowels(words[0], vowels)
    middle_words = words[1:-1]
    last_processed = cut_at_first_vowel(words[-1], vowels)
    result = '_'.join([first_processed] + middle_words + [last_processed])
    return result

