def process_first_word(word):
    result = ""
    for char in word:
        if char.lower() not in "aeiou":
            result += char
    return result

def process_last_word(word):
    result = ""
    for char in word:
        if char.lower() in "aeiou":
            break
        result += char
    return result

def main():
    user_input = input().strip()
    words = user_input.split()
    words[0] = process_first_word(words[0])
    if len(words) > 1:
        words[-1] = process_last_word(words[-1])
    function_name = "_".join([word.lower() for word in words])
    print(function_name)

if __name__ == "__main__":
    main()