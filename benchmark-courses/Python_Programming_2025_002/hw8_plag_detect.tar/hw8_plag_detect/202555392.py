target = input().lower().split()


def remove_vowels(word: str):
    """모음 제거"""
    vowels = "aeiou"
    result = ""
    for char in word:
        if char not in vowels:
            result += char
    return result


def remove_from_first_vowel(word: str):
    """첫번째 모음부터 제거"""
    vowels = "aeiou"
    i = 0
    while i < len(word):
        if word[i] in vowels:
            return word[:i]  # 첫 모음 앞까지 잘라서 return
        i += 1
    return word  # 모음이 없는 경우


def function_name(words: list):
    """함수 이름으로 변환"""
    if len(words) == 1:
        return remove_vowels(words[0])  # 테스트 케이스 3번

    first = remove_vowels(words[0])
    last = remove_from_first_vowel(words[-1])
    middle = words[1:-1]

    result = first
    for word in middle:
        result += "_" + word
    result += "_" + last

    return result

fnc_name = function_name(target)
print(fnc_name)
