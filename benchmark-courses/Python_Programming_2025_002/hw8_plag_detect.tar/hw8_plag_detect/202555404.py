
def remove_vowels(word):
    vowels = "AEIOUaeiou"
    result = ""
    for char in word:
        if char not in vowels:
            result += char
    return result

def truncate_after_first_vowel(word):
    vowels = "AEIOUaeiou"
    for i, char in enumerate(word):
        if char in vowels:
            return word[:i]
    return word

def process_words(words):
    if len(words) == 0:
        return ""

    # Process the first word
    first_word = remove_vowels(words[0]).lower()

    # Process the last word if there is more than one word
    if len(words) > 1:
        last_word = truncate_after_first_vowel(words[-1]).lower()
        middle_words = ""
        for word in words[1:-1]:
            middle_words += word.lower() + "_"
        # Remove the trailing underscore from middle_words if it exists
        if middle_words.endswith("_"):
            middle_words = middle_words[:-1]
        return first_word + "_" + middle_words + "_" + last_word
    else:
        return first_word

def main():
    # Read input
    input_line = input().strip()
    words = input_line.split()

    # Process words and print the result
    function_name = process_words(words)
    print(function_name)

if __name__ == "__main__":
    main()



  
