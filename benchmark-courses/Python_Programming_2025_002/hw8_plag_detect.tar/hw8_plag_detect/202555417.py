def process_word(word, i, words, vowels):
    normalized_word = word.lower()
    result = ""
    
    for j in range(len(word)):
        if i == 0 and normalized_word[j] not in vowels:
            result += normalized_word[j]
        elif i == 0 and normalized_word[j] in vowels:
            continue
        elif i == len(words) - 1 and normalized_word[j] in vowels:
            result += normalized_word[:j]
            break
        elif i != len(words) - 1:
            result += normalized_word
            break
    
    return result

def process_words():
    words = input().split()
    vowels = 'aeiou'
    result = ""
    i = 0
    
    for word in words:
        processed_word = process_word(word, i, words, vowels)
        result += processed_word
        
        if i < len(words) - 1:
            result += "_"
        
        i += 1
    
    print(result)

process_words()
