def remove_vowels_from_first_word(word):
    """Removes all vowels from the first word."""
    vowels = "aeiou"
    new_word = ""
    for char in word:
        if char not in vowels:
            new_word += char
    return new_word

def truncate_last_word(word):
    """Keeps only the part of the last word up to and including the first vowel."""
    vowels = "aeiou"
    for i in range(len(word)):
        if word[i] in vowels:
            return word[:i + 1]  # Keep up to and including the first vowel
    return word  # Return the whole word if no vowels found

def convert_to_function_name(sentence):
    """Converts a sentence into a function name following given rules."""
    words = sentence.lower().split()  # Convert to lowercase and split words

    # Process words
    first_word = remove_vowels_from_first_word(words[0])
    last_word = truncate_last_word(words[-1]) if len(words) > 1 else first_word

    # Construct function name without using join()
    function_name = first_word
    for word in words[1:-1]:  # Middle words stay the same
        function_name += "_" + word
    if len(words) > 1:
        function_name += "_" + last_word

    return function_name

def main():
    """Reads input, converts it to function name, and prints it."""
    input_string = input().strip()
    function_name = convert_to_function_name(input_string)
    print(function_name)

if __name__ == "__main__":
    main()
