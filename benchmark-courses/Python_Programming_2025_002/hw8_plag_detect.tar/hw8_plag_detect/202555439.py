def print_last_word(lst):
    """Print characters in the last word until vowel character"""
    for idx in range(len(lst)):
        if lst[idx] in ["a", "e", "i", "o", "u"]:
            break
        print(lst[idx], end="")


def process_til_last_word(sq):
    """Process input in one pass character-wise except the last word"""
    nw_str = crr_str = ""
    for idx in range(len(sq)):
        crr_ch = sq[idx].lower()
        if crr_ch == " ":
            nw_str += crr_str + "_"
            crr_str = ""
            continue
        if (crr_ch in ["a", "e", "i", "o", "u"]) and (nw_str == ""):
            pass
        else:
            crr_str += crr_ch
    return nw_str, crr_str


processed, remainder = process_til_last_word(input())
if processed == "":
    print(remainder)
else:
    print(processed, end="")
    print_last_word(remainder)
