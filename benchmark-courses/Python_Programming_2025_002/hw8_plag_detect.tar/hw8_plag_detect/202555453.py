def is_vowel(char):
    """Check char is volwel"""
    if char.lower() in ["a", "e", "i", "o", "u"]:
        return True

    return False


def remove_vowel(string):
    """Remove all vowels in a string"""
    result = ""

    for i in range(len(string)):
        if not is_vowel(string[i]):
            result += string[i]

    return result


"""
설계 :

1. 첫 단어의 모음을 모두 제거하자.
  => 단어가 만약 하나라면 => 상관 ㄴㄴ 이건 무조건 실행
2. 마지막 단어의 first vowel 를 포함한 뒤에 오는 문자를 제거하자.
  => 단어가 두 개 이상이라면
3. snake-cased인데 join을 안 써야함..
  => 이거는 반복문을 이용해야할듯
  => every letter in small case도 유의해야함.
4. main 함수를 만들자
5. indent를 space 2칸으로 제출해야함
"""


def main():
    """main function"""
    result = ""
    words = input().split()

    # 첫 단어의 모음을 모두 제거하자

    result += remove_vowel(words[0])

    if len(words) > 1:
        result += "_"

    for i in range(1, len(words) - 1):
        result += words[i]
        result += "_"

    # 마지막 단어 처리
    if len(words) > 1:
        for i in range(0, len(words[-1])):
            if is_vowel(words[-1][i]):
                break

            result += words[-1][i]

    result = result.lower()
    print(result)


if __name__ == "__main__":
    main()
