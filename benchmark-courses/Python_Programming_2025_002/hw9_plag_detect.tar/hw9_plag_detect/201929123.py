def main():
    '''
    input string and split the first value with others
    repeat as the follwing order
    '''
    symbols = input()
    symlist = symbols.split()
    first = symbols[0]
    for sym in symlist[1:]:
        n = int(sym)
        for _ in range(n):
            print(first, end = '')
        print()


if __name__ == "__main__":
    main()
