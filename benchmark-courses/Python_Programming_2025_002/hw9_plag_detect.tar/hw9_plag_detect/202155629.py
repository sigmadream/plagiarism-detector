def repeat_pattern(char, times):
    "Repeating the char for several number of times"
    result = ''
    # getting ascii code of character
    code = ord(char)
    # converting it back to char
    char = chr(code)
    # repeating the "char" for "times"
    for _ in range(times):
        # adding the char to the result
        result =  result + char
    return result


def main():
    "Printing the graph for the integer sequence"
    # waiting for the user's input
    input_line = input()
    # splitting the input into a list
    parts = input_line.split()
    # pattern symbol
    symbol = parts[0]
    for i in range(1, len(parts)):
        # converting the string number to int
        number = int(parts[i])
        # getting the repeated string
        result = repeat_pattern(symbol, number)
        # printing the final result
        print(result)

if __name__ == "__main__":
    main()
