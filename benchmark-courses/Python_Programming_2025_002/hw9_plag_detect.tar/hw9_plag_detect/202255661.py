def print_graph():
    line = input()
    pattern = line[0]
    numbers = line[1:].strip().split()
    
    def print_line(count, symbol):
        i = 0
        while i < count:
            print(symbol, end="")
            i += 1
        print()

    index = 0
    length = len(numbers)
    while index < length:
        num = int(numbers[index])
        print_line(num, pattern)
        index += 1

print_graph()
