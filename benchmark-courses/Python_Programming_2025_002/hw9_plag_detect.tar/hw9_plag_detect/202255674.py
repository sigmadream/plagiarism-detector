def printli(li):
    """조건에 맞게, 입력받은 리스트를 출력"""
    for a in range(1,len(li)):
        print(li[0]*int(li[a]))

def main():
    """input을 받은 데이터를 list구조로 바꾸고, print하는 함수 호출"""
    tmp = input()
    li = tmp.split()
    printli(li)

if __name__ == "__main__":
    main()
    