def main():
    user_input = input().split()
    
    # Extract the pattern character and the list of integers
    pattern = user_input[0]
    numbers = list(map(int, user_input[1:]))
    
    # Loop through each number and print the pattern
    for num in numbers:
        print(pattern * num)

if __name__ == "__main__":
    main()