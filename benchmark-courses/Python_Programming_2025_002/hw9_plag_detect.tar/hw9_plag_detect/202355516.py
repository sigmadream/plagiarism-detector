def repeat_character(ch: str, count: int) -> str:
    """Return a string consisting of `ch` repeated `count` times."""
    return "".join([ch for _ in range(count)])


def parse_input(text: str) -> tuple[str, list[int]]:
    """Split the input string into pattern and numbers."""
    parts = text.strip().split()
    return parts[0], list(map(int, parts[1:]))


def main() -> None:
    pattern, counts = parse_input(input())
    for count in counts:
        print(repeat_character(pattern, count))


if __name__ == "__main__":
    main()