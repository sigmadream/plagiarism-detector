def main():
    line = input()
    parts = line.strip().split()
    pattern = parts[0]
    numbers = parts[1:]

    def make_line(n):
        return ''.join([pattern for _ in range(int(n))])

    list(map(lambda x: print(make_line(x)), numbers))

main()
