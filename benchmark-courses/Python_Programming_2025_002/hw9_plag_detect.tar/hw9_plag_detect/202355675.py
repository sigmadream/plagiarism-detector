def changer(words):
    real = []
    cha = words[0]
    for k in range(1, len(words)):
        words[k] = int(words[k])
        real.append(cha * words[k])
    return real
def main():
    words = input().split()
    real = changer(words)
    for i in range(len(real)):
        print(real[i])

if __name__ == "__main__":
    main()