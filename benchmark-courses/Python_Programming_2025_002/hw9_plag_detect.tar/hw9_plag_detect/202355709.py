ANS = input().split()

for i in range(1, len(ANS)):
    for j in range(int(ANS[i])):
        print(ANS[0], end ="")
    print("")
