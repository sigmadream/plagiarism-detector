def join_string(char_list):
    """Join a list of characters into a string."""
    result = chr(0)
    i = 0
    while i < len(char_list):
        result = result + char_list[i]
        i += 1
    return result[1:]


def build_line(pattern_char, count):
    """Build a line of the graph with the given pattern character and count."""
    result = []
    i = 0
    while i < count:
        result.append(pattern_char)
        i += 1
    return join_string(result)


def parse_input(input_text):
    """Parse the input text to extract the pattern and counts."""
    parts = input_text.strip().split()
    pattern = parts[0]
    numbers = list(map(int, parts[1:]))
    return pattern, numbers


def print_graph(input_text):
    """Print the graph based on the input text."""
    pattern, counts = parse_input(input_text)
    for count in counts:
        print(build_line(pattern, count))


if __name__ == "__main__":
    input_text = input()
    print_graph(input_text)
