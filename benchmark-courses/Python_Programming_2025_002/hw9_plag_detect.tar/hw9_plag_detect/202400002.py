#coding: utf-8

def prrepeat(sym, n):
    """print n symbols namely sym
       sym을 n번 출력합니다.
    """
    for _ in range(n):
        print(sym, end="")
    print()


def main():
    """ draw a horizontal graph of some symbols.
    """
    symbols = "! @ # $ & *"
    symlist = symbols.split()
    for sym in symlist:
        n = ord(sym) - 20
        prrepeat(sym, n)


if __name__ == "__main__":
    main()
