def print_repeat(sym, n):
    """Function repeated printing."""
    for n in range(n):
        print(sym, end='')
    print()

def main():
    """Main function."""
    symlist = input().split()
    sym = symlist[0]
    for i in range(1,len(symlist)):
        n = int(symlist[i])
        print_repeat(sym, n)
        i += 1

if __name__ == "__main__":
    main()
