def main():
    "it inputs a string of symbols and a list of numbers"
    input1 = input("")
    input1 = input1.split()
    symbols = input1[0]
    numbers = list(map(int, input1[1:]))
    for num in numbers:
        print("".join(symbols for _ in range(num)))
if __name__ == "__main__":
    main()
