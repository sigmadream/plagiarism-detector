#coding: utf-8
def main():
    """Main function to read input"""
    sym_list = input().split()
    sym = sym_list[0]
    for num_str in range(1,len(sym_list)):
        num_str += 0
        n = int(sym_list[num_str])
        rep(sym, n)
        num_str += 1

def rep(sym, n):
    """Function to print a symbol multiple times """
    for num_str in range(n):
        num_str += 0
        print(sym, end='')
    print()
    # End-of-file (EOF)

if __name__ == "__main__":
    main()
