def repeat(char, times):
    """Repeat a character 'times' number of times without using '*'."""
    return ''.join(char for _ in range(times))

def main():
    line = input().split()
    symbol = line[0]
    numbers = map(int, line[1:])

    for num in numbers:
        print(repeat(symbol, num))

if __name__ == "__main__":
    main()
