user_input = input()
input_list = user_input.split()

EXTENDED_STR  = str()
for i in range(77):
    EXTENDED_STR  += input_list[0]

for i in input_list[1:]:
    print(EXTENDED_STR [:int(i)])
    