def print_multiple(c, n):
    '''prints a given character(string) n times'''
    for _ in range(n):
        print(c, end="")
    print()


def main():
    '''main'''
    raw_input = input().split()
    input_char = raw_input[0]
    input_numbers = raw_input[1:]
    for n in input_numbers:
        print_multiple(input_char, int(n))

if __name__ == "__main__":
    main()
