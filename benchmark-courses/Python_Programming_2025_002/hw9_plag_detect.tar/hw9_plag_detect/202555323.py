def print_graph():
    input_line = input().strip()

    parts = input_line.split()

    pattern = parts[0]
    numbers = []

    for num in parts[1:]:
        numbers.append(int(num))

    for num in numbers:
        print(pattern * num)

print_graph()