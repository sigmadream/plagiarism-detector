def main():
    """사용자로부터 입력을 받아 특정 형태의 출력값을 생성한다."""
    line = input().strip()
    split_line = line.split()
    shape = split_line[0]
    number = []
    for i in range(1, len(split_line)):
        num = int(split_line[i])
        num = min(num, 77)
        number.append(num)
    for num in number:
        result = ""
        for _ in range(num):
            result += shape
        print(result)
if __name__ == "__main__":
    main()
