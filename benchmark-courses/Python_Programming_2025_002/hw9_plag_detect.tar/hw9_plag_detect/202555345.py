def graph(pat, n):
    """Repeats a given character a given number of times"""
    print(pat * n)


def main():
    """The main function"""
    pattern = input().split()
    for i in range(1, len(pattern)):
        graph(pattern[0], int(pattern[i]))


if __name__ == "__main__":
    main()
