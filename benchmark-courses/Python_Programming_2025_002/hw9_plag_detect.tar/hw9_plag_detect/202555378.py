def drawing_graph(pattern, numbers):
    for num in numbers:
        print(pattern * num)

def main():
    input_line = input()
    parts = input_line.split()
    pattern = parts[0]  
    numbers = [int(part) for part in parts[1:]] 
    drawing_graph(pattern, numbers)

if __name__ == "__main__":
    main()