"""
Additional requirements for bonus points
1. Do not use nested loops, string literals, nor the string repetition operator (*).
2. Check the quality of your code to make it have fewer than three quality issues.
"""

def repeat_string(char: str, num: int):
    """ make repeated string(without nested loop and string repetition operator)"""
    result = [char for _ in range(num)]
    return str().join(result)

user_input = input().split()
character = user_input[0]
repetition = user_input[1:]

for i in repetition:
    print(repeat_string(character, int(i)))
