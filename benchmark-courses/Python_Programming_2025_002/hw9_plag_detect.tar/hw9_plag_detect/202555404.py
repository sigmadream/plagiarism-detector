def print_graph(pattern, sequence):
    for number in sequence:
        # Create a list with the pattern character repeated `number` times
        line = [pattern] * number
        # Join the list into a string and print it
        print(''.join(line))

def main():
    # Read the input line
    input_line = input().strip()

    # Separate the pattern character and the sequence of integers
    pattern = input_line[0]
    sequence = list(map(int, input_line[2:].split()))  # Skip the space after the pattern character

    # Print the graph
    print_graph(pattern, sequence)

if __name__ == "__main__":
    main()

