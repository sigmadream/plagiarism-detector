def print_graph():
    import sys

    # Read the input line
    input_line = sys.stdin.readline().strip()
    if not input_line:
        return

    parts = input_line.split()
    pattern = parts[0]
    numbers = map(int, parts[1:])

    def generate_line(ch, count):
        # Generator that yields a character 'count' times
        return ''.join(map(lambda _: ch, range(count)))

    for num in numbers:
        if 1 <= num <= 77:
            print(generate_line(pattern, num))

# Example usage:
# Input: # 8 1 5
# Output:
# ########
# #
# #####

# If running as a script
if __name__ == "__main__":
    print_graph()