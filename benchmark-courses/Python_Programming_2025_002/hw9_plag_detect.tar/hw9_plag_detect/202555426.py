def print_graph():
    # Read the input line
    input_line = input().strip()
    
    # Extract the pattern character (first character) and the sequence of numbers
    parts = input_line.split()
    pattern = parts[0]  # First part is the pattern character
    numbers = list(map(int, parts[1:]))  # Remaining parts are the numbers
    
    # Print the graph
    for num in numbers:
        # Create the line to be printed without using string repetition operator
        line = ''
        for _ in range(num):
            line += pattern  # Append the pattern character each time
        print(line)

# Call the function to run the program
print_graph()
