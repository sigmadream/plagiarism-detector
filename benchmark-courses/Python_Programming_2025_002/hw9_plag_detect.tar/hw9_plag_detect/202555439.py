input_seq = input().split()
symbol = input_seq.pop(0)

IDX = 0
CHRS = 0

while IDX < len(input_seq):
    if CHRS == int(input_seq[IDX]):
        IDX += 1
        CHRS = 0
        print()
        continue
    print(symbol, end=chr(32))
    CHRS += 1
