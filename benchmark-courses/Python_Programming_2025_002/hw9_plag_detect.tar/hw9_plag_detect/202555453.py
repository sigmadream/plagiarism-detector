def main():
    """
    main is the function for program
    """
    input_splited = input().split()

    symbol = input_splited[0]
    seq = list(map(int, input_splited[1:]))

    i = 0
    j = 0

    while i < len(seq):
        if j == seq[i]:
            i += 1
            j = 0

            print()
        else:
            print(symbol, end=chr(32))
            j += 1


if __name__ == "__main__":
    main()
