import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class Average3 {

	public static void main(String[] args) throws FileNotFoundException {
			Scanner sc = new Scanner(System.in);
			PrintStream ps = new PrintStream(System.out);
			int n1 = sc.nextInt();
			int n2 = sc.nextInt();
			int n3 = sc.nextInt();
			double share = (n1+n2+n3)/3.0;
			ps.printf("%.2f\n", share);
			ps.close();
			sc.close();
	}
}
