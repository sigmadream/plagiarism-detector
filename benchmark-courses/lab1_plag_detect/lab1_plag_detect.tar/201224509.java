import java.util.Scanner;

public class Lab01inprogram {
	
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
			
		int first = sc.nextInt();
		int second = sc.nextInt();
		int third = sc.nextInt();
		
		double average = (first + second + third)/3.0;
		
		System.out.printf("%.2f%n", average);
		
		sc.close();
		
		}
}

