import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class Average3 {
public static void main(String[] args) throws FileNotFoundException {
	Scanner sc = new Scanner(System.in);
	PrintStream ps = new PrintStream(System.out);
	
	int a = sc.nextInt();
	int b = sc.nextInt();
	int c = sc.nextInt();
	
	double share = (a + b + c)/ 3.0;
	
	System.out.printf("%.2f\n", share);

	sc.close();
	}
}