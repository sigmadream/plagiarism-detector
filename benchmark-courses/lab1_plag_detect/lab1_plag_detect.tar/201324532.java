import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintStream;


public class Average3 {
	public static void main(String[] args) throws FileNotFoundException {
		//Scanner sc = new Scanner(new File("in.txt"));
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		//PrintStream ps = new PrintStream(new File("out.txt"));
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		double share = (a+b+c) / 3.0;
		//System.out.printf("%.2f\n", share);
		ps.printf("%.2f\n", share);
		
		ps.close();
		sc.close();
	}
}


