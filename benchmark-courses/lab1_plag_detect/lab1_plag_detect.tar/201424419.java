import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class Average3 {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc= new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		
		int sum = 0;
		double avg;
		for(int i = 0 ; i< 3 ; i++){
			sum += sc.nextInt();
		}
		avg = sum/3.0;
//		System.out.printf("%.2f", avg);
		ps.printf("%.2f%n", avg);
	
		sc.close();
		ps.close();

	}

}
