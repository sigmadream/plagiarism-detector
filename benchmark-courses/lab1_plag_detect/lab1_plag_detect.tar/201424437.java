import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class Share {
	public static void main(String[] args) throws FileNotFoundException{
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double share1 = a + b + c;
		double share2 = share1 / 3 ;
		PrintStream ps = System.out;
		ps.printf("%.2f%n",share2);
		//double share = 1.0 / a;
		//System.out.printf("%.2f%n", share);
		sc.close();
		
	}
}
