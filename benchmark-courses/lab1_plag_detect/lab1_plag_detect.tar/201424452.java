import java.io.PrintStream;
import java.util.Scanner;

public class average {
	public static void main(String[] args) { 
		Scanner sc = new Scanner(System.in);
		int st,nd,rd;
		st=sc.nextInt();
		nd=sc.nextInt();
		rd=sc.nextInt();
		PrintStream ps = System.out;
		int a = st+nd+rd;
		double aver=a/3.0;
		ps.printf("%.2f%n",aver);
		ps.close();
		sc.close();
	}
}