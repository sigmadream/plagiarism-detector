import java.util.Scanner;
import java.io.PrintStream;


public class Average3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double Average = (a+b+c) / 3.0;
		
		System.out.printf("%.2f%n", Average);
		sc.close();
		ps.close();
	}
}