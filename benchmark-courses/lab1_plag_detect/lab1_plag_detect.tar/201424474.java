import java.io.PrintStream;
import java.util.Scanner;

public class Average3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = new PrintStream(System.out); // == PrintStream ps = System.out;
		double a = sc.nextDouble();
		double b = sc.nextDouble();
		double c = sc.nextDouble();
		double average = (a+b+c) / 3.0;
		ps.printf("%.2f\n", average);
		sc.close();
		ps.close();
	}
}