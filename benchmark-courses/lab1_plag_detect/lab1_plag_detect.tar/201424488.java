import java.io.PrintStream;
import java.util.Scanner;

public class Average {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double average = (a+b+c) / 3.00;
		
		ps.printf("%.2f%n",average);
		ps.close();
		sc.close();
	}
}
