
import java.io.PrintStream;
import java.util.Scanner;

public class Average3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int a1 = sc.nextInt();
		int a2 = sc.nextInt();
		int a3 = sc.nextInt();
		double share =  (a1+a2+a3)/3.0 ;
		ps.printf("%.2f%n",share);
		sc.close();
		
	}
}