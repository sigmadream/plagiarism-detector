import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.File;


public class Average3 {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in); 
		PrintStream ps = System.out;  
		int a = sc.nextInt();	
		int b = sc.nextInt();	
		int c = sc.nextInt();	
		double Average = (a + b + c) / 3.0;	
		ps.printf("%.2f\n", Average);
		ps.close();
		sc.close();
	}
}