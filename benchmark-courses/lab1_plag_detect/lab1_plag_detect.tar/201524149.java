import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class Average3{
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double average = (a+b+c)/3.0;
		//double share = 1.0 / a;
		//System.out.printf("%.2f%n", share);
		ps.printf("%.2f%n", average);
		ps.close();
		sc.close();
	}
}