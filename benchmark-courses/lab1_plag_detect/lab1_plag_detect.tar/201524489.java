import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class share {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int a =sc.nextInt();
		int b =sc.nextInt();
		int c =sc.nextInt();
		double sum = a+b+c;
		double avg=sum/3.0;
		ps.printf("%.2f%n",avg);
		sc.close();
		ps.close();
	}

}
