
import java.io.PrintStream;
import java.util.Scanner;

public class Average3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double ave=(a+b+c)/3.0;
		System.out.printf("%.2f%n", ave);
		sc.close();
		
	}
}