import java.io.IOException;
import java.util.Scanner;

public class Average3 {
	private static Scanner sc;

	public static void main(String[] args) throws IOException {
		sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		double average=(a+b+c)/3.0;
		System.out.printf("%.2f%n", average);
	}
}