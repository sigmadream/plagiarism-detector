import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.PrintStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;

@SuppressWarnings("serial")
public class Calculator extends JFrame implements ActionListener {
    private JTextField input;
    private JButton[] btn = new JButton[15];
    private String[] btnName = {"7", "8", "9", "4", "5", "6", "1", "2", "3", "0", "+", "*", "D", "C", "="};
    String opt = null;
    String sNum1 = "0";
    String sNum2 = "0";
    String result = "0";

    public void initOpts() {
        opt = null;
        sNum1 = "0";
        sNum2 = "0";
    }

    public Calculator() {
        JPanel panel;
        setTitle("Calculator");
        setSize(200, 260);
        init(panel = new JPanel(null));
        setContentPane(panel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void init(JPanel panel) {
        JPanel inPanel = new JPanel(new BorderLayout());
        inPanel.setBounds(10, 10, 165, 200);
        panel.add(inPanel);
        input = new JTextField("0", 15);
        input.setHorizontalAlignment(JTextField.RIGHT);
        inPanel.add(input, "North");
        JPanel btnPanel = new JPanel(new GridLayout(5, 3, 4, 4));
        inPanel.add(btnPanel, "South");
        for (int i = 0; i < btn.length; i++) {
            btnPanel.add(btn[i] = new JButton(btnName[i]));
            btn[i].addActionListener(this);
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            if (e.getActionCommand().equals("=")) {
                if (opt == "+") {
                    BigInteger sum = addition();
                    result = sum.toString();
                } else if (opt == "*") {
                    BigInteger product = multilp();
                    result = product.toString();
                } else {
                    ;
                }
                input.setText(result);
                //System.out.printf("1: %s %s %s = %s\n", sNum1, opt, sNum2, result);
                sNum1 = "0";
                sNum2 = "0";
                opt = null;
            } else if (e.getActionCommand().equals("C")) {
                initOpts();
                result = "0";
                input.setText(result);
            } else if (e.getActionCommand().equals("+")) {
                if (opt == null || sNum2 == "0") {
                    sNum1 = input.getText();
                    opt = "+";
                } else {
                    //System.out.printf("2.1: %s %s %s = %s\n", sNum1, opt, sNum2, result);
                    calculateIntermediate();
                }
                //System.out.printf("2: %s %s %s = %s\n", sNum1, opt, sNum2, result);
                opt = "+";
            } else if (e.getActionCommand().equals("*")) {
                if (opt == null || sNum2 == "0") {
                    sNum1 = input.getText();
                    opt = "*";
                } else {
                    //System.out.printf("3.1: %s %s %s = %s\n", sNum1, opt, sNum2, result);
                    calculateIntermediate();
                }
                //System.out.printf("3: %s %s %s = %s\n", sNum1, opt, sNum2, result);
                opt = "*";
            } else if (e.getActionCommand().equals("D")) {
                if (opt == null) {
                    BigInteger dUp = new BigInteger(input.getText());
                    dUp = dUp.multiply(new BigInteger("2"));
                    result = dUp.toString();
                } else if (opt.equals("*")) {
                    BigInteger product = multilp();
                    opt = null;
                    result = product.toString();
                    BigInteger dUp = new BigInteger(result);
                    dUp = dUp.multiply(new BigInteger("2"));
                    result = dUp.toString();
                } else if (opt.equals("+")) {
                    BigInteger sum = addition();
                    opt = null;
                    result = sum.toString();
                    BigInteger dUp = new BigInteger(result);
                    dUp = dUp.multiply(new BigInteger("2"));
                    result = dUp.toString();
                }
                sNum1 = result;
                sNum2 = "0";
                input.setText(result);
                //System.out.printf("4: %s %s %s = %s\n", sNum1, opt, sNum2, result);
                opt = null;
            } else {
                if (opt == null) {
                    String digit = e.getActionCommand();
                    input.setText(sNum1.equals("0") ? digit : sNum1 + digit);
                    sNum1 = input.getText();
                } else {
                    //sNum1 = input.getText();
                    //sNum2 = "0";
                    String digit = e.getActionCommand();
                    input.setText(sNum2.equals("0") ? digit : sNum2 + digit);
                    sNum2 = input.getText();
                }
            }
            //initOpts();
        }
    }

    public BigInteger addition() {
        BigInteger sum = new BigInteger(sNum1).add(new BigInteger(sNum2));
        return sum;
    }

    public BigInteger multilp() {
        BigInteger product = new BigInteger(sNum1).multiply(new BigInteger(sNum2));
        return product;
    }

    public void calculateIntermediate(){
        if (opt.equals("+")) {
            BigInteger sum = addition();
            result = sum.toString();
            //opt = "*";
        } else if (opt.equals("*")) {
            BigInteger product = multilp();
            result = product.toString();
            //opt = "*";
        }
        //System.out.printf("2: %s %s %s = %s\n", sNum1, opt, sNum2, result);
        input.setText(result);
        sNum1 = result;
        sNum2 = "0";
    }

    public static void main(String[] args) {
        JFrame jf = new Calculator();
        jf.setVisible(true);
        Scanner sc = new Scanner(System.in);
        PrintStream ps = new PrintStream(System.out);
        BigInteger res = new BigInteger("0");
        BigInteger num1 = new BigInteger(sc.next());
        String opt = sc.next();
        if (opt.equals("D"))
            res = num1.multiply(new BigInteger("2"));
        else {
            BigInteger num2 = new BigInteger(sc.next());
            if (opt.equals("+"))
                res = num1.add(num2);
            else if (opt.equals("*"))
                res = num1.multiply(num2);
        }
        ps.print(res);
        sc.close();
        ps.close();
    }
}