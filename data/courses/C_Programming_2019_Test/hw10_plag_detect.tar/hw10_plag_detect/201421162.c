#include <stdio.h>

typedef
int (*fun)(int,int);
int add(int a, int b) {return a+b;}
int sub(int a, int b) {return a-b;}
int mul(int a, int b) {return a*b;}
int div(int a, int b) {return a%b;}
int xor(int a, int b) { return a^b; }
fun f[] = {add, sub, mul,div, xor};

int reduce(char oper, int a[], int size){
    int result;
if(oper =='+'){
    for(int i =0; i < size-1 ; i++){
        a[i+1] = f[0](a[i],a[i+1]);
    }
}
else if(oper =='-'){
   for(int i =0; i < size-1 ; i++){
        a[i+1] = f[1](a[i],a[i+1]);
    }
}
else if(oper =='*'){
   for(int i =0; i < size-1 ; i++){
        a[i+1] = f[2](a[i],a[i+1]);
    }
}
else if(oper =='%'){
    for(int i =0; i < size-1 ; i++){
        a[i+1] = f[3](a[i],a[i+1]);
    }
}
else if(oper =='^'){
    for(int i =0; i < size-1 ; i++){
        a[i+1] = f[4](a[i],a[i+1]);
    }
}
return a[size-1];
}

int main() {

char operat;
scanf("%c", &operat);
int a[100]={0};
int ch=0 ,i=0;

while(scanf("%d",&ch) == 1)
{
    a[i]= ch;
    i++;

}


printf("%d", reduce(operat, a, i));


return 0;
}
