#include <stdio.h>

int add()
{
    int i;
    int total=0;
    while(scanf("%d",&i)==1)
    {
        total+=i;
    }
    return total;
}

int multiply()
{
    int i;
    int total=1;
    while(scanf("%d",&i)==1)
    {
        total*=i;
    }
    return total;
}



int remance()
{
    int i, a;
    int total=0;
    scanf("%d",&a);
    while(scanf("%d",&i)==1)
    {

        a = a%i;
    }
    return a;
}

int asdf()
{
    int i, a;
    int total=0;
    scanf("%d",&a);
    while(scanf("%d",&i)==1)
    {

        a = a^i;
    }
    return a;
}

int asdz()
{
    int i, a;
    int total=0;
    scanf("%d",&a);
    while(scanf("%d",&i)==1)
    {

        a = a-i;
    }
    return a;
}

typedef int (*fun)(int);
int main()
{
char mul;
int result;
scanf("%c",&mul);
if(mul=='+')
    result=add();
else if (mul=='*')
    result=multiply();
else if (mul=='%')
    result=remance();

else if (mul=='^')
    result=asdf();
    else if (mul=='-')
    result=asdz();

fun f[]={result};
printf("%d",f[0]);

return 0;
}
