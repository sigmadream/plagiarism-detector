#include <stdio.h>

int add(int a, int b){return a + b;}
int sub(int a, int b){return a - b;}
int mul(int a, int b){return a*b;}
int div(int a, int b){return a/b;}
int xor(int a, int b){return a^b;}

typedef int (*fun)(int,int);

fun f[]={add,sub,mul,div,xor};

int main()
{
    int n,c=0,d,l;
    scanf("%c",&d);

    if (d=='+')
        l=0;
    else if (d=='-')
        l=1;
    else if (d=='*')
        l=2;
    else if (d=='/')
        l=3;
    else if (d=='^')
        l=4;

    while (scanf("%d",&n) == 1){
        c++;
    }

    int *x=n,e,h;
    h=f[l](x,x+1);

    for (int i=0; i<c-1; i++)
    {
        e=f[l](h,x+i+2);
        h=e;
    }

    printf("%d",h);

    return 0;
}
