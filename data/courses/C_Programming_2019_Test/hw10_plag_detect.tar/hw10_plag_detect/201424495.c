#include <stdio.h>

int sum(int* a, int n){
    int i;
    int result=0;
    for(i=0; i < n; i++)
        result = result + a[i];
    return result;
}

int min(int* a, int n){
    int i;
    int result=a[0];
    for(i=1; i < n; i++)
        result = result - a[i];
    return result;
}

int mul(int* a, int n){
    int i;
    int result=1;
    for(i=0; i < n; i++)
        result = result * a[i];
    return result;
}

int div(int* a, int n){
    int i;
    int result=a[0];
    for(i=1; i < n; i++)
        result = result % a[i];
    return result;
}

int xor(int* a, int n){
    int i;
    int result=a[0];
    for(i=1; i < n; i++)
        result = result ^ a[i];
    return result;
}


typedef int (*fun_arr[])(int*, int);



int main(){
    int i = 0;
    int result = 0;
    char op = 0;
    int num[100] = {0,};
    scanf("%c",&op);
    fun_arr cal = {sum, min, mul, div, xor};

    while(scanf("%d",&num[i])==1){
        i++;
    }

    if(op == '+')
       printf("%d",cal[0](num,i));
    else if(op == '-')
        printf("%d",cal[1](num,i));
    else if(op == '*')
        printf("%d",cal[2](num,i));
    else if(op == '%')
        printf("%d",cal[3](num,i));
    else if(op == '^')
        printf("%d",cal[4](num,i));


    return 0;
}
