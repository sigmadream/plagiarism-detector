#include <stdio.h>

typedef int (*fun)(int, int);

int add(int a, int b) {
    return a + b;
}

int sub(int a, int b) {
    return a - b;
}

int mul(int a, int b)
{
    return a * b;
}

int div(int a, int b)
{
    return a % b;
}

int squ(int a, int b)
{
    return a ^ b;
}



int main() {
    char c1;
    int num[100];
    scanf("%c",&c1);
    while(scanf("%d",&num)== 1);




    fun f[] = { add, sub, mul, div, squ };

    int i = 0;

    int sz2 = sizeof *num;
    switch(c1) {
        case '+':
            for(i=1;i<=sz2;i++)
                num[i] = f[0](num[i-1],num[i]);
            printf("%d",num[sz2]);
            break;
        case '-':
            for(i=1;i<=sz2;i++)
                num[i] = f[1](num[i-1],num[i]);
            printf("%d",num[sz2]);
            break;
        case '*':
            for(i=1;i<=sz2;i++)
                num[i] = f[2](num[i-1],num[i]);
            printf("%d",num[sz2]);
            break;
        case '%':
            for(i=1;i<=sz2;i++)
                num[i] = f[3](num[i-1],num[i]);
            printf("%d",num[sz2]);
            break;
        case '^':
            for(i=1;i<=sz2;i++)
                num[i] = f[4](num[i-1],num[i]);
            printf("%d",num[sz2]);
            break;

    }

    return 0;
}
