#include <stdio.h>

int pl(int a, int b) {return a + b;}
int mu(int a, int b) {return a * b;}
int de(int a, int b) {return a % b;}
int mi(int a, int b) {return a - b;}
int dd(int a, int b) {return a ^ b;}
typedef int (*fun)(int, int);
int main(void)
{
    int n, i, sz;
    char b;
    fun f[] = {pl, mu, de, mi, dd};
    scanf("%c", &b);
    scanf("%d", &n);
    while(scanf("%d", &i) == 1){
        if (b == '+') n = f[0](n, i);
        if (b == '*') n = f[1](n, i);
        if (b == '%') n = f[2](n, i);
        if (b == '-') n = f[3](n, i);
        if (b == '^') n = f[4](n, i);
    }
    printf("%d\n", n);
    return 0;
}
