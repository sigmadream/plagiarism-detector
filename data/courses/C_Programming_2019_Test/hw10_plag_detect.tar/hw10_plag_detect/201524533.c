#include <stdio.h>
#include <math.h>

int add(int *a, int b) {
	int i, p = 0;
	for (i = 0; i < b; i++)
		p += a[i];
	return p;
}

int sub(int *a, int b) {
	int i, p = a[0];
	for (i = 1; i < b; i++)
		p -= a[i];
	return p;
}

int mul(int *a, int b) {
	int i, p = a[0];
	for (i = 1; i < b; i++)
		p *= a[i];
	return p;
}

int div(int *a, int b) {
	int i, p = a[0];
	for (i = 1; i < b; i++)
		p %= a[i];
	return p;
}

int xor(int *a, int b) {
	int i, p = a[0];
	for (i = 1; i < b; i++)
		p = p ^ a[i];
	return p;
}

typedef int (*fun)(int*, int);

int main()
{
	char op;
	int i = 0, j;
	int in[100] = {0, };
	fun f[] = { add, sub, mul, div, xor };
	
	scanf("%c", &op);
	
	while(scanf("%d", &in[i])==1) {
		i++;
	}
		
	switch(op) {
		case '+':
			j = 0;
			break;
		case '-':
			j = 1;
			break;
		case '*':
			j = 2;
			break;
		case '%':
			j = 3;
			break;
		case '^':
			j = 4;
			break;
	}
	
	printf("%d\n", f[j](in, i));
	
	return 0;
}
