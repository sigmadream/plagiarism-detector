#include <stdio.h>

int add(int* b, int len)
{
	int i;
	int add=0;
	for(i=0; i<len; ++i)
		add += b[i];
	return add;
}

int sub(int* b, int len)
{
	int i;
	int sub=b[0];
	for(i=1; i<len; ++i)
		sub += -b[i];
	return sub;
}

int mul(int* b, int len)
{
	int i;
	int mul = 1;
	for(i=0; i<len; ++i)
		mul *= b[i];
	return mul;
}

int mod(int* b, int len)
{
	int i;
	int mod=b[0];
	for(i=1; i<len; ++i)
		mod %= b[i];
	return mod;
}

int XORXOR(int* b, int len)
{
	int i;
	int XORXOR = b[0];
	for(i=1; i<len; ++i)
		XORXOR = XORXOR ^ b[i];
	return XORXOR;
}

typedef int (*fun)(int*, int);

int main(void) {
	int i=0;
	char a[5];
	int b[81] = {0,};
		
	scanf("%c", a);
	while(scanf("%d", b+i) != EOF)
	{
		i++;
	}
	fun f[] = {add, sub, mul, mod, XORXOR};
	if(a[0] == '+')
		printf("%d", f[0](b,i));
	else if(a[0] == '-')
		printf("%d", f[1](b,i));
	else if(a[0] == '*')
		printf("%d", f[2](b,i));
	else if(a[0] == '%')
		printf("%d", f[3](b,i));
	else if(a[0] == '^')
		printf("%d", f[4](b,i));
	
	return 0;
}
