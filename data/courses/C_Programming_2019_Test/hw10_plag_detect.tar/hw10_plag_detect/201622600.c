#include <stdio.h>
int cal(char b, int a[])
{
    int i = 0;
    int result;
    if(b == '+'){
        result = 0;
        while(a[i] != NULL){
        result = result + a[i];
        i++;}
    }
    if(b == '-') {
        result = 0;
        while(a[i] != NULL){
        result = result - a[i];
        i++;
        }
    }
    if(b == '%') {
        result = 1;
        while(a[i] != NULL){
        result = result % a[i];
        i++;
        }
    }
    if(b == '*') {
        result = 1;
        while(a[i] != NULL){
        result = result * a[i];
        i++;
        }
    }
    if(b == '^') {
        result = 1;
        while(a[i] != NULL){
        result = result ^ a[i];
        i++;
        }
    }

    return result;
}

int main() {

    char Coperator;
    int num[50];
    int i = 0;

    scanf("%c", &Coperator);
    printf("%c\n", Coperator);

    do
     { scanf("%d", num[i]);
        i++;
     } while(getc(stdin) == ' ');

    i = 0;
    do
     { printf("%d ", num[i]);
        i++;
     } while(getc(stdin) == ' ');

     cal(Coperator, num);

    return 0;

}
