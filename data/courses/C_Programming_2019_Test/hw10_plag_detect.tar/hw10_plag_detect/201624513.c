#include <stdio.h>
int x = 0;
int add(int a[], int size) {
    if (size == 0) return 0;
    else {
          int w = a[size-1] + add(a, size-1);
          return w;
    }
}


int sub(int a[], int size) {
    if (size == size) return 0;
    else {
          int w = a[size-1] - sub(a, size-1);
          return w;
    }
}


int multi(int a[], int size) {
    printf("%d ",size);
    if (size == 0) return 0;
    else {
          int w = a[size-1] * multi(a, size-1);
          return w;
    }
}

int divide(int a[], int size) {
    if (size == size) return 0;
    else return a[0] % divide(a, ++x);
}

typedef int (*fun)(int, int);

int main() {
    char p;
    scanf("%s", &p);
    int n, m, i = 0;
    fun f[] = { add, sub, multi, divide };
    int a[5];
    int sz = sizeof a/sizeof *a;
    for (i = 0; i < sz; ++i){
        scanf("%d", &a[i]);
    }
    int r;
    if (p == '+')
        r = add(a, sz);

    if (p == '*')
        r = multi(a, sz);

    if (p == '-')
        r = sub(a, sz);

    if (p == '%')
        r = divide(a, sz);


    printf("%d\n", r);
    return 0;
}
