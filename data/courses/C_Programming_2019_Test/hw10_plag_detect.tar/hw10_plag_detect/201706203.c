#include <stdio.h>
typedef int (*reduce)(int, int);

int add(int a, int b){
	return a+b;
}
int sub(int a, int b){
	return a-b;
}
int mul(int a, int b){
	return a*b;
}
int xorl(int a, int b){
	return a^b;
}
int mol(int a, int b){
	return a%b;
}

int main(){
	char *ope;
	scanf("%s\n",&ope);
	int *a,x=0;
	scanf("%d %d %d %d %d",&a[0], &a[1], &a[2], &a[3], &a[4]);

	if (ope=="+"){
		reduce r[]={add};
		int i=0, sz=sizeof r/sizeof *r;
		for(i =0;i<sz;i++)
			x=x+r[i](a[i],a[i+1]);
		printf("%d\n",x);
		return x;
	}
	if (ope=="-"){
		reduce r[]={sub};
		int i=0, sz=sizeof r/sizeof *r;
		for(i =0; i<sz;i++)
			x=r[i](a[i],a[i+1]);
		printf("%d\n",x);
	}
	
	if (ope=="*"){
		reduce r[]={mul};
		int i=0, sz=sizeof r/sizeof *r;
		for(i =0; i<sz;i++)
				x=r[i](a[i],a[i+1]);
		printf("%d\n",x);
	}
	
	if (ope=="^"){
		reduce r[]={xorl};
		int i=0, sz=sizeof r/sizeof *r;
		for(i =0; i<sz;i++)
			x=r[i](a[i],a[i+1]);
		printf("%d\n",x);
	}
	
	if (ope=="%"){
		reduce r[]={mol};
		int i=0, sz=sizeof r/sizeof *r;
		for(i =0; i<sz;i++)
				x=r[i](a[i],a[i+1]);
		printf("%d\n",x);
	}
	
	printf("%d\n",x);
	return x;
}
