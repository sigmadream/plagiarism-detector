#include <stdio.h>

int add(int i, int t){
	int q[100];
	for(t = 0; t < sizeof q ; t++){
		scanf("%d", q[t]);
	}
	int leng, result;
	leng = sizeof q;
	for(i = 0; i < sizeof q ; i++){
		scanf("%d", q[i]);
		result = result + q[i];
	}
	return result;
}

int sub(int i, int t){
	int q[100];
	for(t = 0; t < sizeof q ; t++){
		scanf("%d", q[t]);
	}
	int leng, result;
	leng = sizeof q;
	for(i = 0; i < sizeof q ; i++){
		scanf("%d", q[i]);
		result = result - q[i];
	}
	return result;
}

int mul(int i, int t){
	int q[100];
	for(t = 0; t < sizeof q ; t++){
		scanf("%d", q[t]);
	}
	int leng, result;
	leng = sizeof q;
	for(i = 0; i < sizeof q ; i++){
		scanf("%d", q[i]);
		if(i = 0)
			result = q[i];
		result = result * q[i];
	}
	return result;
}

int nan(int i, int t){
	int q[100];
	for(t = 0; t < sizeof q ; t++){
		scanf("%d", q[t]);
	}
	int leng, result;
	leng = sizeof q;
	for(i = 0; i < sizeof q ; i++){
		scanf("%d", q[i]);
		if(i = 0)
			result = q[i];
		result = result % q[i];
	}
	return result;
}

int jeg(int i, int t){
	int q[100];
	for(t = 0; t < sizeof q ; t++){
		scanf("%d", q[t]);
	}
	int leng, result;
	leng = sizeof q;
	for(i = 0; i < sizeof q ; i++){
		scanf("%d", q[i]);
		if(i = 0)
			result = q[i];
		else
			result = result ^ q[i];
	}
	return result;
}

typedef int (*fun)(int);

int main(){
	int g;
	int *q[100];
	scanf("%s\n", &g);
	
	if(g == "+"){
		fun f[] = { add };
		int i = 0, sz = sizeof f/sizeof *f;
		for(i=0 ; i<sz ; i++)
			printf("%d\n",f[i](q[i]));
	}
	else if(g == "-"){
		fun f[] = { sub };
		int i = 0, sz = sizeof f/sizeof *f;
		for(i=0 ; i<sz ; i++)
			printf("%d\n",f[i](q[i]));
	}
	else if(g == "*"){
		fun f[] = { mul };
		int i = 0, sz = sizeof f/sizeof *f;
		for(i=0 ; i<sz ; i++)
			printf("%d\n",f[i](q[i]));
	}
	else if(g == "%"){
		fun f[] = { nan };
		int i = 0, sz = sizeof f/sizeof *f;
		for(i=0 ; i<sz ; i++)
			printf("%d\n",f[i](q[i]));
	}
	else if(g == "^"){
		fun f[] = { jeg };
		int i = 0, sz = sizeof f/sizeof *f;
		for(i=0 ; i<sz ; i++)
			printf("%d\n",f[i](q[i]));
	}
	
	return 0;
	
}
