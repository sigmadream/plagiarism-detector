#include <stdio.h>


typedef int(*fun)(int,int);
int add(int a,int b){return a+b;}
int sub(int a,int b){return a-b;}
int mul(int a,int b){return a*b;}
int div(int a,int b){return a%b;}
int xor(int a,int b){return a^b;}
fun f[]={add,sub,mul,div,xor};

int rec(int n, int c[n],fun f)
{
    if (n==1)return c[0];
    else return(*f)(rec(n-1,c,f),c[n-1]);

}

int main() {
    char c;
    scanf("%c",&c);
    int n[100], i=0;
    while(scanf("%d",n+i) == 1){
        i++;
    }
    fun f;
    switch(c){
    case '+' :
        f=add;
        break;
    case '-' :
        f=sub;
        break;
    case '*' :
        f=mul;
        break;
    case '%' :
        f=div;
        break;
    case '^' :
        f=xor;
        break;
    }
    printf("%d",rec(i,n,f));
    return 0;
}
