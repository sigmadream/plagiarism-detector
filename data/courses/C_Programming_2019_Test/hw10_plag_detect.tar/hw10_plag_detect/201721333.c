#include <stdio.h>

int add(int a, int b) {return a+b;}
int sub(int a, int b) {return a-b;}
int mul(int a, int b) {return a*b;}
int red(int a, int b) {return a%b;}
int ex(int a, int b) {return a^b;}

int len(int x[80])
{
	int i=0,cnt=0;
	while(x[i++]!='\0') {cnt++;
	}
	return cnt;
}

int main()
{
	char c;
	scanf("%c",&c);
	
	int x[80],cnt=0,i=0;
	while(scanf("%d",&x[i++])==1){}

	cnt=x[0];
	switch(c){
		case '+':if(len(x)!=1){for(i=1;i<len(x);i++){cnt+=x[i];}} break;
		case '-':if(len(x)!=1){for(i=1;i<len(x);i++){cnt-=x[i];}} break;
		case '*':if(len(x)!=1){for(i=1;i<len(x);i++){cnt*=x[i];}} break;
		case '%':if(len(x)!=1){for(i=1;i<len(x);i++){cnt%=x[i];}} break;
		case '^':if(len(x)!=1){for(i=1;i<len(x);i++){cnt^=x[i];}} break;
	}
	
	printf("%d",cnt);
	
	return 0;
}
