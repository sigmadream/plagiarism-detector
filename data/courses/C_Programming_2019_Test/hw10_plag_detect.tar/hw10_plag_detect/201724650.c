#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int sum(int *inputs, int count);
int sub(int *inputs, int count);
int mul(int *inputs, int count);
int mod(int *inputs, int count);
int xor(int *inputs, int count);

typedef int(*func)(int *arr, int count);
int main()
{
	char op;
	int opn;
	int i = 0;
	int x;
	int inputs[99];
	func f[] = { sum, sub, mul, mod, xor };

	scanf("%c", &op);
	if (op == '+') opn = 0;
	else if (op == '-') opn = 1;
	else if (op == '*') opn = 2;
	else if (op == '%') opn = 3;
	else if (op == '^') opn = 4;

	while (scanf("%d", &inputs[i])== 1)
	{
		i++;
	}
	printf("%d", f[opn](inputs, i - 1));
	return 0;
}

int sum(int *inputs, int count)
{
	if (count == 0)
		return *inputs;

	return *(inputs + count) + sum(inputs, count -1);
}

int sub(int *inputs, int count)
{
	if (count == 0)
		return *inputs;

	return   sub(inputs, count - 1) - *(inputs + count);
}

int mul(int *inputs, int count)
{
	if (count == 0)
		return *inputs;
	
	return mul(inputs, count - 1) * *(inputs + count);
}

int mod(int *inputs, int count)
{
	if (count == 0)
		return *inputs;
	
	return mod(inputs, count - 1) % *(inputs + count);

}

int xor(int *inputs, int count)
{
	if (count == 0)
		return *inputs;
	
	return xor(inputs, count - 1) ^ *(inputs + count);
}
