#include <stdio.h>

int add(int *arr,int size) {
	if (size == 0)
		return *arr;
	else
		return  add(arr, size - 1) + *(arr + size);
}

int sub(int *arr, int size) {
	if (size == 0)
		return *arr;
	else
		return   sub(arr, size - 1) - *(arr + size);
}
int multi(int *arr, int size) {
	if (size == 0)
		return *arr;
	else
		return *(arr + size) * multi(arr, size - 1);
}
int divi(int *arr, int size) {
	if (size == 0)
		return *arr;
	else
		return divi(arr, size - 1) / *(arr + size)  ;
}
int mod(int *arr, int size) {
	if (size == 0)
		return *arr;
	else
		return mod(arr, size - 1) %  *(arr + size);
}
int xor(int *arr, int size) {
	if (size == 0)
		return *arr;
	else
		return xor (arr, size - 1) ^ *(arr + size)  ;
}
int check(int *num, char oper, int size) {
	if (oper == '+') {
		add(num, size);
	}
	else if (oper == '-') {
		sub(num, size);
	}
	else if (oper == '*') {
		multi(num, size);
	}
	else if (oper == '/') {
		divi(num, size);
	}
	else if (oper == '%') {
		mod(num, size);
	}
	else if (oper == '^') {
		xor(num, size);
	}
}

typedef int(*fun)(int, int);

int main(){
	char oper;
	int num[20], temp, answer;
	fun f[] = { add, sub, multi, divi }; //function pointer
	int i = 0, sz = sizeof f / sizeof *f;
	
	scanf("%c", &oper);
	while (scanf("%d", &temp) != EOF) {
		num[i++] = temp;
	}
	answer = check(num, oper, i - 1);
	printf("%d\n", answer);
	return 0;
}