#include <stdio.h>

typedef int (*fun)(int, int);

int add(int a, int b) {return a + b;}
int sub(int a, int b) {return a - b;}
int mul(int a, int b) {return a * b;}
int xor(int a, int b) {return a ^ b;}
int per(int a, int b) {return a % b;}

int main() {
    fun f[] = { add, sub,mul,xor,per };
    int o;
    scanf("%d", &o);
    int *n;
    int sz=sizeof n/sizeof *n;
    int i=0;
    int result=0;
    int funtemp=0;

    while(1)
        scanf("%d",n);

    switch (o) {
        case '+' :
            for(i=0;i<sz;i++)
                funtemp=add(n[i],funtemp);
            result=funtemp;
            printf("%d", result);
            break;

        case '-' :
            funtemp=sub(n[0],n[1]);
            for(i=2;i<sz;i++)
                funtemp=sub(funtemp,n[i]);
            result=funtemp;
            printf("%d", result);
            break;

        case '*' :
            funtemp=mul(n[0],n[1]);
            for(i=2;i<sz;i++)
                funtemp=mul(funtemp,n[i]);
            result=funtemp;
            printf("%d", result);
            break;

        case '%' :
            funtemp=per(n[0],n[1]);
            for(i=2;i<sz;i++)
                funtemp=per(funtemp,n[i]);
            result=funtemp;
            printf("%d", result);
            break;

        case '^' :
            funtemp=xor(n[0],n[1]);
            for(i=2;i<sz;i++)
                funtemp=xor(funtemp,n[i]);
            result=funtemp;
            printf("%d", result);
            break;

    }

    return 0;
}
