#include<stdio.h>

typedef int (*biop)(int, int);

int add(int a, int b) {return a+b;}
int sub(int a, int b) {return a-b;}
int mul(int a, int b) {return a*b;}
int mod(int a, int b) {return a%b;}
int xor(int a, int b) {return a^b;}

int calc(int len, int c[len], biop f){
    if(len==1) return c[0];
    else return (*f)(calc(len-1,c,f),c[len-1]);
}

int main(){
    int inp[100];
    biop f;
    char op;
    scanf("%c",&op);
    switch(op){
    case '+':
        f=add; break;
    case '-':
        f=sub; break;
    case '*':
        f=mul; break;
    case '%':
        f=mod; break;
    case '^':
        f=xor; break;
    default:
        return 1;
    }
    int i=0;
    while(scanf("%d",inp+i)==1)
        i++;
    printf("%d",calc(i,inp,f));
    return 0;
}
