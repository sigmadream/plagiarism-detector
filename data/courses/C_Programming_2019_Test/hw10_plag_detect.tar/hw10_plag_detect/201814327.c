#include <stdio.h>

typedef int (*fun)(int,int);

    int add(int a, int b){return a+b;}
    int sub(int a, int b){return a-b;}
    int mul(int a, int b){return a*b;}
    int xor(int a, int b){return a^b;}
    int rem(int a, int b){return a%b;}

int main()
{
    int a[5];
    int i=0, num;
    char c;
    int n=0;
    fun f[]={add, sub, mul, xor, rem};

    scanf("%c", &c);

    while (scanf("%d", &num) == 1){
        a[i]=num;
        //printf("%d",num);
        i++;
    }
    int sz=i;

    if (c=="+"){
        for (int i=0; i<sz; i++)
            n=(*f[0])(n,a[i]);
    }
    else if (c=="-"){
        for (int i=0; i<sz; i++)
            n=(*f[1])(n,a[i]);
    }
    else if (c=="*"){
            n=1;
        for (int i=0; i<sz; i++)
            n=(*f[2])(n,a[i]);
    }
    else if (c=="^"){
        for (int i=0; i<sz; i++)
            n=(*f[3])(n,a[i]);
    }
    else if (c=="%"){
        for (int i=0; i<sz; i++)
            n=(*f[4])(n,a[i]);
    }

    printf("%d",n);
    return 0;
}
