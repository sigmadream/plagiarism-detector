#include <stdio.h>

typedef (*fun)(int, int);

int add(int a, int b) {return a+b;}
int sub(int a, int b) {return a-b;}
int mul(int a, int b) {return a*b;}
int xor(int a, int b) {return a ^ b;}
int res(int a, int b) {return a % b; }



int main()
{
    char op ;
    scanf("%c",&op);
    int i,j = 0 ;
    int *a[100];
    while (scanf("%d", a+i) == 1)
        i++ ;


    int sum = 0 ;

    fun f [] = { add, sub, mul, xor, res};

    if (op == 43){
        for (j = 0; j <i  ; j++)
            sum = f[0](a[j],sum);
        printf("%d", sum);
    }
    else if (op == 45){
        for (j = 0; j <i ; j++)
            sum = f[1](a[j],a[j+1]);
        printf("%d", sum);
    }
    else if (op == 42){
        for (j = 0; j <i ; j++)
            sum = f[2](a[j],sum);
        printf("%d", sum);
    }
    else if (op == 94){
        for (j = 0; j <i ; j++)
            sum = f[3](a[j],a[j+1]);
        printf("%d", sum);
    }
    else {
        for ( j = 0; j <i ; j++)
            sum = f[4](a[j],a[j+1]);
        printf("%d", sum);
    }

    return 0 ;
}
