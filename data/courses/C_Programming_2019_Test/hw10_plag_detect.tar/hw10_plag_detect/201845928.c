#include <stdio.h>

typedef int (*fun)(int, int, int*);

int deohagi(int sum, int x, int y[]) {
	if (x == 0) {
		sum = y[x] + y[x+1];
		return deohagi(sum, x+2, y);
	}
	else if (y[x] == '\0')
		return sum;
	else {
		sum += y[x];
		return deohagi(sum, x+1, y);
	}
}

int minus(int answer, int x, int y[]) {
	if (x == 0) {
		answer = y[x] - y[x+1];
		return minus(answer, x+2, y);
	}
	else if (y[x] == '\0')
		return answer;
	else {
		answer -= y[x];
		return minus(answer, x+1, y);
	}
}

int gob(int answer, int x, int y[]) {
	if (x == 0) {
		answer = y[x] * y[x+1];
		return gob(answer, x+2, y);
	}
	else if (y[x] == '\0')
		return answer;
	else{
		answer *= y[x];
		return gob(answer, x+1, y);
	}
}

int nameogi (int answer, int x, int y[]) {
	if (x == 0) {
		answer = y[x] % y[x+1];
		return nameogi(answer, x+2, y);
	}
	else if (y[x] == '\0')
		return answer;
	else {
		answer = answer % y[x];
		return nameogi(answer, x+1, y);
	}
}

int zegob(int answer, int x, int y[]) {
	if (x == 0) {
		answer = y[x] ^ y[x+1];
		return zegob(answer, x+2, y);
	}
	else if (y[x] == '\0')
		return answer;
	else {
		answer = answer ^ y[x];
		return zegob(answer, x+1, y);
	}
}

int main() {
	char oper;
	scanf("%c", &oper);
	int num;
	int i = 0;
	int numlst[256];
	fun f[] = { deohagi, minus, gob, nameogi, zegob };
	while (scanf("%d", &num) == 1) {
		numlst[i] = num;
		i++;
	}
	numlst[i] = '\0';
	int ans = 0;
	switch (oper){
		case '+': ans = f[0](0, 0, numlst); break;
		case '-': ans = f[1](0, 0, numlst); break;
		case '*': ans = f[2](0, 0, numlst); break;
		case '%': ans = f[3](0, 0, numlst); break;
		case '^': ans = f[4](0, 0, numlst); break;
	}

	printf("%d", ans);


	return 0;
}