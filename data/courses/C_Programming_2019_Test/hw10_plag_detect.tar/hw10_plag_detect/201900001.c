#include <stdio.h>

typedef int (*func)(int, int);

int add(int *a, int sz)
{
    if (sz == 0)
        return 0;
    else
        return a[sz-1] + add(a, sz-1);
}

int sub(int *a, int sz)
{
	//printf("%d \n", sz);
    if (sz == 0)
        return 0;
    else if (sz == 1)
        return a[0];
    else
        return - a[sz-1] + sub(a, sz-1);
}

int mul(int *a, int sz)
{
    if (sz == 0)
        return 1;
    else
        return a[sz-1] * mul(a, sz-1);
}

int rmd(int *a, int sz)
{
    int ans = a[0];
    for (int i = 1; i < sz; i++)
        ans = ans % a[i];
    return ans;
}

int xor(int *a, int sz)
{
    int ans = a[0];
    for (int i = 1; i < sz; i++)
        ans = ans ^ a[i];
    return ans;
}

func f[] = {add, sub, mul, rmd, xor};                   //tried in the function 'main', but also got 0 scores.

int main()
{

    char op;
    int box[80], i = 0;
    scanf("%c", &op);
    while (scanf("%d", &box[i]) == 1)
        i++;
    const int SIZE = i;

    if (op == '+')
        printf("%d\n", f[0](box, SIZE));                //tried without new line, but also got 0 scores.
    else if (op == '-')
        printf("%d\n", f[1](box, SIZE));
    else if (op == '*')
        printf("%d\n", f[2](box, SIZE));
    else if (op == '%')
        printf("%d\n", f[3](box, SIZE));
    else if (op == '^')
        printf("%d\n", f[4](box, SIZE));
    return 0;
}