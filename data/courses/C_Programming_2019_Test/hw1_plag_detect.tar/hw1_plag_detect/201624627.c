#include <stdio.h>
int main()
{
    int n = 0;
    int c = 0;
    scanf("%d",&n);
    c=n%2;

    if(c==0)
        printf("Hola %d?",n);
    else
        printf("Hello %d?",n);

    return 0;
}
