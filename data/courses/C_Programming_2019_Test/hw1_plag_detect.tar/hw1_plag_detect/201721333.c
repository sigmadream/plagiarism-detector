#include <stdio.h>
// build and run�� F9

int main()
{
    int n=0;

    scanf("%d", &n);
    if (n%2==0)
        printf("Hola %d?\n",n);
    else
        printf("Hello %d?\n",n);

    return 0;
}
