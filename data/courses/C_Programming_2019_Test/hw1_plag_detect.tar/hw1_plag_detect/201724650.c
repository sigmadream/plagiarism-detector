#include <stdio.h>
#pragma warning(disable: 4996)

int main()
{
	int n = 0;
	scanf("%d", &n);
	
	/*
	printf("%d is ", n);
	if (n % 2 == 0)		//odd when n%2 =="1" or "-1"
		puts("even");
	else
		puts("odd");
		*/
	/**/
	if (n % 2 == 0)
		printf("Hola %d?\n", n);
	else
		printf("Hello %d?\n", n);
		
	return 0;
}
