#include <stdio.h>

int main(){
    int N;
    scanf("%d",&N);
    printf("%s %d?",(N%2)?("Hello"):("Hola"),N);
    return 0;
}
