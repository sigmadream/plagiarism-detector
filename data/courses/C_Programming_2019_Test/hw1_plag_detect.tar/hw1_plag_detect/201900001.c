#include <stdio.h>

int main()
{
	int i = 0;
	int num = 0;
	char buf[81];
	char* msg = &buf[0];
	scanf("%s", buf);

	while (*msg != NULL)
	{
		num++;
		msg++;
	}
	msg = buf;
	while (i<num)
	{
		printf("%c\n", *msg);
		msg++;
		msg++;
		i++;
		i++;
	}
	return 0;

}