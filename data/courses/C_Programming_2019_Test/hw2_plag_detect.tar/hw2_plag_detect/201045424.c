#include <stdio.h>

int main(void)
{
    char input[81];
    int i = 0;
    
    scanf("%s", input);
    
    while (input[i] != '\0') {
        if (i % 2 == 0) {
            printf("%c\n", input[i]);
        }
        i++;
    }
}
