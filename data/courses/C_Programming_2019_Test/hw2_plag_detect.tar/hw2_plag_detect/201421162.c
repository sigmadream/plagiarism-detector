#include <stdio.h>

int main(){

    char msg[80];
    char *p = msg;
    int i =0;


    scanf("%s", msg); // reads a string

    while (*p != '\0') {

        if (i % 2 == 0)
            printf("%c\n", *p);
        p++;
        i++;
    }

    return 0;
}
