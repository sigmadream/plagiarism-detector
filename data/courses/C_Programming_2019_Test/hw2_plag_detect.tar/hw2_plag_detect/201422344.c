#include <stdio.h>

int main()
{
	char str[80];
	char *p = str;
	//printf("Enter a string: ");
	scanf("%s",str);
	
	int n = 0;
	while (*p != '\0') {
		if (n % 2 == 0){
			printf("%c\n", *p);
			}
		p++;
		n++;
	}
	return 0;
}