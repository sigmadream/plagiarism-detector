#include <stdio.h>

int main()
{
    int n = 0;
    char buf[81];

    scanf("%s",buf);

    while(buf[n] != '\0'){
        if (n % 2 == 0)
            printf("%c\n",buf[n]);

        n++;
    }
    return 0;
}
