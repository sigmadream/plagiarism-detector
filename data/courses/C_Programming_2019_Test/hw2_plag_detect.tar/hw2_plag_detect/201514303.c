#include <stdio.h>

int main()
{
    int n;
    char msg[81];
    char *p = msg;

    scanf("%s", msg);

    while (*p != '\0') {
        if (n % 2 == 0)
             if(*p>=65 && *p<=90)
                printf("%c\n", *p);
                n++;
                p++;
    }

    return 0;
}
