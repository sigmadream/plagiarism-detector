#include <stdio.h>

int main()
{
	char buf[100];
	int n = 0;
	
	char* msg = buf;
	scanf("%s", buf);
	
	while ( *msg != '\0' ) {
		if ( n % 2 == 0 )
			printf("%c\n", *msg);
		n++;
		msg++;
	}
	
	return 0;
}
