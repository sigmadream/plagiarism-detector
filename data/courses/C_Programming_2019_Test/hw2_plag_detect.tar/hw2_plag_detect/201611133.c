
#include <stdio.h>
int main()
{
    int n = 0;
    char buf[81];
    char* msg = buf;
    scanf("%s", msg);

    while (*msg != '\0')
        {
        if(n % 2 == 0)
            printf("%c\n", *msg); // print the chracter pointed by msg
            msg++; // msg moves to the next character
            n++;
        };

    return 0;
}

