#include <stdio.h>

int main()
{
    char n[80];
    char *p = n;

    scanf("%s", n);
    while(*p != '\0'){
       if( *p % 2 ==0)
          printf("%c\n", *p);
       p++;
    }
    return 0;

}
