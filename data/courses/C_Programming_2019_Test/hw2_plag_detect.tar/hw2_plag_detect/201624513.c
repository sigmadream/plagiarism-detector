 #include <stdio.h>

 int main()
 {

    int n = 0;
    char buf[200];
    int a;
    char *msg = &buf;
    scanf("%s", buf);
    while (*msg !='\0') {
        if (n % 2 == 0)
        printf("%c\n", *msg);
        msg++;
        n++;
    }

    return 0;
 }
