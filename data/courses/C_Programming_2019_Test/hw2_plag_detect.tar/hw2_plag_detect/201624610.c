#include <stdio.h>

int main()
{

    char msg[81];
    char *p = msg;

    scanf("%s", msg);
    int n = 0;
    while (*p != '\0') {
        if (n % 2 == 0)
            printf("%c\n", *p);
        n ++;
        p ++;
    }
    return 0;
}
