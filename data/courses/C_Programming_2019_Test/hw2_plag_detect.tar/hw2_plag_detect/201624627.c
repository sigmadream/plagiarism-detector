#include <stdio.h>
int main()
{
    char msg[81];
    int n=0;
    char *p=msg;
    scanf("%s",msg);
    while(*p!='\0'){
        if(n%2==0)
            printf("%c\n",*p);
            p++;
            n++;
    }

    return 0;
}
