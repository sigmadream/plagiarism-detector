#include <stdio.h>

int main()
{
    int n = 0;
    char buf[81];
    char *msg = &buf[0];
    scanf("%s", buf);
    while (*msg != '\0') {
     if(n%2==0)
     printf("%c\n",*msg);
     msg++;
     n++;
    }
    return 0;
}
