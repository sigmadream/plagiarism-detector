#include <stdio.h>

int main()
{
    char nm[81];
    char *p=nm;
    int i=0;

    scanf("%s",nm);

    while(*p!='\0') {
        if (i%2==0)
            printf("%c\n",*p);
        p++;
        i++;
    }

    return 0;
}
