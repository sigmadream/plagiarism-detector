#include <stdio.h>

int main()
{
    char msg[81];
    int index = 0;
    char *p = msg;
    scanf("%s", msg); // reads a string
    while (*p != '\0')
    {
        if (index %2 == 0)
            printf("%c\n", *p);
        p++;
        index ++;
    }
    return 0;
}
