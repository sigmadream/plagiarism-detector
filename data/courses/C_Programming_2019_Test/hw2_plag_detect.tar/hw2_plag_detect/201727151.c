#include <stdio.h>

int main()
{
    int n = 0;
    int i = 0;
    char buf[80];
    buf[i];
    char* msg = &buf[0];
    //printf("Enter a string: ");
    scanf("%s", buf);
    while (buf[i] != '\0') {
        if (i % 2 == 0)
        printf("%c\n", buf[i]);
        i++;
    }
    return 0;
}
