#include <stdio.h>

int main(void)
{	

	char ch[]="v";
	int v;
	int i = 0;
	scanf("%s",&ch);
	printf("%s\n",ch);

    if (i % 2 != 0)
        puts("ch[i]\n");
    else
        puts("\n");

    return 0;
}

