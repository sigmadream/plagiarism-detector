#include <stdio.h>
int main(){
    int i=0;
    char msg[80];
    scanf("%s",msg);
    while(msg[i]!='\0'){
        if(i%2!=1){
            printf("%c\n",msg[i]);
        }
        i++;
    }
    return 0;
}
