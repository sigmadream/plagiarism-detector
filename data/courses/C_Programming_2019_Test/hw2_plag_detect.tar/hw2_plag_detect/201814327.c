#include<stdio.h>

int main(){
   char msg[81] ="\0";
   char *p;
   int i = 0;

   printf("Enter a string: ");
   scanf("%s", msg);
   p = msg;

   while(i<=80){
      if(i % 2 == 0){
         printf("%c", p[i]);
         printf("\n");
      }
      i++;
   }
   return 0;
}
