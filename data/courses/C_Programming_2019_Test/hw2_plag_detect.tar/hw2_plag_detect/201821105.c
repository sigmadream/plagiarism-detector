#include <stdio.h>

int main(void) {

   char p[80];

   scanf("%s", p);

   int num = 0;
   while (p[num] != '\0') {
      if(num % 2 ==0)
         printf("%c\n", p[num]);
      num++;
   }
   return 0;
}
