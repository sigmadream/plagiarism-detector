#include <stdio.h>
#include <stdbool.h>

bool isNotSymbol(char word)
{
   if (word >= 48 && word <= 57) {
        // number
        return true;
   } else if (word >= 65 && word <= 90) {
       // uppercase
       return true;
   } else if (word >= 97 && word <= 122) {
       return true;
   } else {
       return false;
   }
}
char lastchar(char word[])
{
    int i = 0;
    char currentCharacter = '\0';
    while (word[i] != '\0')
    {
        currentCharacter = word[i];
        i++;
    }
    return currentCharacter;
}

int main()
{
    char str[81];
    char result[81];
    int currentIndex = 0;

    while (scanf("%s", str) == 1) {
        char lastChracter = lastchar(str);

        if (isNotSymbol(lastChracter)) {
            result[currentIndex] = lastChracter;
            currentIndex++;
        }
    }
    result[currentIndex] = '\0';
    printf("%s\n", result);
    return 0;
}
