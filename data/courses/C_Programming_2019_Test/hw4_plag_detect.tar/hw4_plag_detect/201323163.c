#include <stdio.h>
#include <stdbool.h>


bool notSymbol(char word)
{
    if ((word>47 && word<58) || (word>64 && word<91) || (word>96 && word<123))
        return true;
    else
        return false;
}

char lastchar(char word[])
{
    int i = 0;
    while(word[i] != '\0'){
        i++;
    }
    return word[i - 1];
}

int main()
{
    char str[81];
    char newstr[81];
    int i = 0;

    while(scanf("%s", str) == 1){
        char lastCharac = lastchar(str);
        if (notSymbol(lastCharac) == true) {
            newstr[i] = lastCharac;
            i++;
        }

    }
    newstr[i] = '\0';
    printf("%s", newstr);
    return 0;
}
