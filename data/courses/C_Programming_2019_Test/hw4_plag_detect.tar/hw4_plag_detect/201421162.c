#include <stdio.h>
#include <stdbool.h>
#include <string.h>

char lastchar(char word[])
{   int size = 0;
    for (int i=0; i < sizeof(word); i++)
    {
        if (word[i] != '\0')
            size ++;
    }
    return word[size];


}

bool isnotsymbols(int num)
{

    if (num >= 65&& num <=90)
        return true;
    if (num>=97&&num<=122)
        return true;
    else
        return false;
}

int main()
{
    char str[81];
    int scnt = 0;
    char lastword = 'a';
    int a=0;


    while (scanf("%s", str) == 1)
    {
        lastword = lastchar(str);
        a = lastword;

        if (isnotsymbols(a) == true)
            printf("%c", a);
    }

    return 0;

}
