#include <stdio.h>
#include <stdbool.h>
char lastchar(char word[])
{
int num=0;
char *msg=&word[0];
scanf("%s",word);
    while(*msg !=NULL && *msg!='!'&&*msg!=','&&*msg!='.'&&*msg!='?'&&*msg!='+'&&*msg!='=')
    {
        num++;
        msg++;
    }
return word[num-1];
}

bool issingle(char word[])
{
    if (word[0] != '\0' && word[1] == '\0')
        return true;
    else
        return false;
}

int main()
{
char word[80];
while(scanf("%c",word)==1)
{
        printf("%c",lastchar(word));
}
return 0;
}
