#include <stdio.h>
#include <stdbool.h>

bool issingle(char word[])
{
	if (word[0] != '\0' && word[1] == '\0')
		return true;
	else
		return false;
}

int main()
{
	char word[81];
	int scnt = 0;

	while (scanf("%s", word) == 1) {
		int i = 0;
		if (issingle(word)) {
			printf("%c", word[0]);
		}
		else {
			while (word[i] != '\0')
				i++;
		}
		printf("%c", word[i - 1]);
	}
	return 0;
}