#include <stdio.h>
#include <stdbool.h>

char lastchar(char word[])
{
    int i = 0;
    while (word[i] != '\0'){
    i++;
    }
    return word[i-1];
}
int main(void)
{
    char str[81];
    while (scanf("%s", str) == 1) {
        if (65 <=lastchar(str) && 90>= lastchar(str) || 97 <=lastchar(str) && 122>= lastchar(str) || 48 <=lastchar(str) && 57>= lastchar(str))
            printf("%c",lastchar(str));
    }
    printf("\n");
    return 0;
}
