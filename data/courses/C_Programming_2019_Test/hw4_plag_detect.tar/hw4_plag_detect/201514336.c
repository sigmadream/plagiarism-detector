#include <stdio.h>
#include <stdbool.h>

char lastchar(char word[])
{
    if (word[0] != '\0' && word[81] == '\0')
        return true;
    else
        return false;
}

//bool lchar(char word[])
//{
//    if (lastchar != )
//}

int main()
{
    char str[81];
    char *scnt = str;
    int n = 0;

    while (scanf("%s", str) < sizeof(str)) {
        if (lastchar(str) == true)
            scnt++;
            n++;
            printf("%c", *scnt);
    }


    return 0;
}
