#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>

char lastchar(char word[])
{	
	int n = 0;
	char last;
	
	while (word[n] != '\0') {
		last = word[n];
		n++;
	}
	
	return last;
}

bool isschar(char str)
{
	if ((str >= 48 && str <= 57 ) || (str >= 65 && str <= 90) || (str >= 97 && str <=122))
		return true;
	else
		return false;
}

int main()
{
	char str[81];
	char printstr[1000];
	int n = 0;
	
	while (scanf("%s", str) == 1) {
		if (isschar(lastchar(str))) {
			printstr[n] = lastchar(str);
			n++;
		}
	}
	
	printf("%s\n", printstr);
	
	return 0;
}
