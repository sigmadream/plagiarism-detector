#include <stdio.h>
#include <stdbool.h>

bool issingle(char word[])
{
    for (int i = 0; i <81; i++){
    if (word[i] != '\0')
        return true;
    else
        return false;
    }
}

int main()
{
    char str[81];
    char lastchar(char word[]);

    while (scanf("%s", str) == 1) {
        for (int i = 0; i <81; i++){
        if (str[i] == '\0')
            lastchar = str[i-1];
        }
        printf("%c", lastchar);

    }

    return 0;
}
