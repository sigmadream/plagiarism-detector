#include <stdio.h>
#include <stdbool.h>

bool issingle(char word[])
{
    return (word[0] != '\0' && word[1] == '\0');
}

char symbol =

bool issymbol(char word[])
{
    return (!symbol);
}

int main ()
{

    char str[81];
    char lastchar(char word[]);

    while (scanf("%s", str) == 1) {
        if (issingle(str) == true, issymbol(str) == true)
        print ("%c", lastchar(str));
    }
}
