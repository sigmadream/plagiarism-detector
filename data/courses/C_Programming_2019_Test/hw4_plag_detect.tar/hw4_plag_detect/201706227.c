#include <stdio.h>
#include <stdbool.h>
#include <string.h>

char lastchar(char word[]);

int main(){
    char str[80];
    char *word;
    char *e_word;
    int s_word;

    while(scanf("%s", str) == 1){
        if(lastchar(str) == true){
            e_word += word[s_word];
        }
    }
    printf("%s", e_word);
}

char lastchar(char word[]){
    if (word[0] != '\0' && word[1] == '\0'){
        int s_word;
        s_word = sizeof(word)-2;
        return true;
    }
    else
        return false;
}
