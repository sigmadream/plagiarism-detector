#include <stdio.h>
#include <stdbool.h>

bool issingle(char word[])
{
    if (word[0] != '\0' && word[1] == '\0')
        return true;
    else
        return false;
}
char lastchar(char word[]){
}
int main()
{
    char str[81];
    int scnt = 0;

    while (scanf("%s", str) == 1) {
        if (issingle(str) == true)
            scnt++;
    }
    printf("The number of single-character words = %d\n", scnt);

    return 0;
}
