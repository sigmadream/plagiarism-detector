#include <stdio.h>
#include <stdbool.h>
#include <string.h>

char lchar(char word[])
{
    int i=0;

    while (word[i]!='\0')
        i++;
    return word[i-1];
}

bool issym(char word[])
{
    if ((48<=lchar(word)&&lchar(word)<=57) || (65<=lchar(word)&&lchar(word)<=90))
        return true;
    else
        return false;
}

int main()
{
    char word[81];

    while (scanf("%s",word)==1){
        if (issym(word)==1)
            printf("%c",lchar(word));
    }

    return 0;
}
