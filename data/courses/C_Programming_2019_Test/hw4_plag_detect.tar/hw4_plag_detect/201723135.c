#include <stdio.h>
#include <stdbool.h>

char lastchar(char word[])
{
    int i = 0;
    while (word[i] != '\0') {
        i += 1;
    }
    return word[i-1];
}

bool itsnotsymbol(char word)
{
    if (word >= 48 && word <= 57){
        return true;

    }
    else if (word >= 65 && word <= 90){
        return true;
    }
    else if (word >= 97 && word <= 122){
        return true;
    }
    else{
        return false;
    }
}

int main()
{
    char str[81];
    char res[80];
    int curIndex = 0;

    while (scanf("%s", str) == 1) {
        char lastcharac = lastchar(str);
        if (itsnotsymbol(lastcharac) == true) {
            res[curIndex] = lastcharac;
            curIndex++;
        }
    }

    res[curIndex] = '\0';
    printf("%s\n", res);

    return 0;
}
