#include <stdio.h>
#include <stdbool.h>

bool isword(char word)
{
    if (47 < word &&word < 58)
        return true;
    else if (64 < word &&word < 91)
        return true;
    else if (96 < word &&word < 123)
        return true;
    else
        return false;
}

char lastchar(char word[]);

int main()
{
    char str[81];
    char result[81] = {0};
    int scnt = 0;

    while (scanf("%s", str) == 1) {
            result[scnt] = lastchar(str);
            if (isword(result[scnt]))   scnt ++;
    }

    for (int i = 0; i < scnt; i ++)
    {
        printf("%c", result[i]);
    }

    return 0;
}

char lastchar(char word[])
{
    int i = 0;

    while (word[i] > 0)
        i ++;

    while (isword(word[i]) == false)
    {
        i --;

        if (word[i] == 0)
        {
            word[i] = 0;
            break;}
    }

    return word[i];

}
