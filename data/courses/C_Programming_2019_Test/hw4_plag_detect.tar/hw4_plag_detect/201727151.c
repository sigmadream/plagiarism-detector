#include <stdio.h>
#include <stdbool.h>

bool issingle(char word[])
{
    return (word[0] != '\0');
}

char lastchar(char word[]){
    int n = 0;
    while (word[n] != '\0')
        n++;
    return word[n-1];
}

int main()
{
    char str[81];

    while (scanf("%s", str) == 1) {

    printf("%c", lastchar(str));
    }

    return 0;
}
