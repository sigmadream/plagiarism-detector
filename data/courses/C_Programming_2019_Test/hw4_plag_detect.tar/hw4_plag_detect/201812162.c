#include <stdio.h>
#include <stdbool.h>

bool isalpha(char ch){
    return ('a'<=ch&&'z'>=ch)||('A'<=ch&&'Z'>=ch)||('0'<=ch&&'9'>=ch);
}

char lastchar(char word[]){
    int i=0;
    char lchar;
    while(word[i]!='\0'){
        lchar=word[i];
        i++;
    }
    return lchar;
}

int main(){
    char s[81];
    char lchar;
    while(scanf("%s",s)==1){
        lchar=lastchar(s);
        if(isalpha(lchar))
            printf("%c",lastchar(s));
    }
    return 0;
}
