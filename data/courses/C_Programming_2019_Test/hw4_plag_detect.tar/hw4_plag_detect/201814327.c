#include <stdio.h>
#include <stdbool.h>

char lastchar(char word[])
{
    int i=0;
    char last;

    while (i<sizeof(word)){
        if (word[i+1]=='\0')
            last=word[i];
    }

    return last;
}

bool is_not_symbol(char last)
{
    if (last>48 && last<57)
        return true;
    else if (last>65 && last<90)
        return true;
    else if (last>97 && last<122)
        return true;
    else
        return false;
}

int main()
{
    char str[81];

    while (scanf("%s", str)<sizeof(str)) {
        if (is_not_symbol(str) == true)
            printf("%s",lastchar(str));
    }

    return 0;
}
