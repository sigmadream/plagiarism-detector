#include <stdio.h>
#include <stdbool.h>

bool charcheck(char word[])
{
    int num = 0 ;
    int i = 0 ;
    for(i = 0 ; word[i] != '\0'; i ++)
        num ++ ;
    if (word[num]>47 && word[num] <58)
        return true;
    else if (word[num]>64 && word[num] <91)
        return true;
    else if (word[num] >96 && word[num] <123)
        return true;
    else
        return false;
}

char charprint(char word[])
{
    int num = 0 ;
    if (word[num] != '\0')
        num++ ;
    else
        num -- ;
    return word[num];
}

int main()
{

    char str[81];

    while (scanf("%s", str) == 1) {
        if (charcheck(str) == true)
            printf ("%c", charprint(str));
    }

    return 0;
}
