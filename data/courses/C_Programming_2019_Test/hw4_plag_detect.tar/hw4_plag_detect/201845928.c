#include <stdio.h>
#include <stdbool.h>

bool isstring(char a[1]]){

    if (a[0] == '!' || a[0]== '?')
        return false;
    else
        return true;
}

char lastchar(char word[]){
    char *p = word;
    while (*p != '\0') p++;
    p = p-1;
    return *p;
}

int main(){
	char str[81];

	char output[81] ;
	int n=0;
	while (scanf("%s", str) == 1){
        char a = lastchar(str);
        bool x= isstring(a);
        if (x=true){

		output[n] = a;
        n++;
        }
	}
	for (n; n<=81;n++)
        output[n] = '\0';

	printf("%s", output);
	return 0;
}

