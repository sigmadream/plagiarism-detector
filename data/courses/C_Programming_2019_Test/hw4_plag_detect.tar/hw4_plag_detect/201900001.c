#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>

char lastchar(char word[])
{
	int n = 0;
	char last;

	while (word[n] != '\0') {
		last = word[n];
		n++;
	}
	//printf("%c  %d\n", last,n);
	return last;
}

bool isschar(char str)
{
	if (ispunct(str))
		return false;
	else
		return true;
}

int main()
{
	char str[81];
	char laststr[1000] = { NULL };
	int n = 0;
	//printf("%d\n", ' ');
	while (scanf("%s", str) == 1) {
		if (isschar(lastchar(str))) {
			//printf("%c\n", lastchar(str));
			laststr[n] = lastchar(str);
			n++;
		}
	}
	//printf("%d\n", n);
	printf("%s\n", laststr);

	return 0;
}
