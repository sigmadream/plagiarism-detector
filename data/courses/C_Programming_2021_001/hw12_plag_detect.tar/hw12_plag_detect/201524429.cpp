#include<stdio.h>
#include<stdlib.h>


int main(){

    int n, i,j;
    double temp;
    double *a;

    

    scanf("%d", &n);

    a = (double *)malloc(sizeof(double)*n);

    for(i = 0; i < n; i++)
    {
        scanf("%lf", &a[i]);
    }

    //qsort ( a, sizeof(a)/sizeof(double), sizeof (double), compare);
    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
        {
            if(a[j+1]<a[j])
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }


    if( n % 2 == 1)
    {
        double mid1 = a[(n-1) / 2];
        printf("%.2f", mid1);
    }

    else
    {
        double mid2= (a[n/2-1] + a[n/2]) / 2;
        printf("%.2f", mid2);
    }

    return 0;
}
