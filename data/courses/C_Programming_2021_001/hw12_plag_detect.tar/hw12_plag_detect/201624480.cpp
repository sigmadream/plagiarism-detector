#include <stdio.h>
#include <stdlib.h>

double median(double a[], int n){
    double medianNumber;
    if (n % 2 == 0){
        medianNumber = (a[(n/2)]+a[(n/2)-1])/2;
    }
    else
        medianNumber = a[n/2];

    return medianNumber;
}

int main(){
int n, i;
scanf("%d", &n);
double data[n+1];
double temp;
for (i = 0; i < n; i++) {    // n�� �Է�
    scanf("%lf", &data[i]);
}

for (i = 0; i < n; i++) {
    for (int j = 0; j < n - 1; j++){
        if (data[j] > data[j+1]){
            temp = data[j];
            data[j] = data[j+1];
            data[j+1] = temp;
        }
    }
}

printf("%.2f", median(data, n));

return 0;
}
