#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double* ascending(double arr[],int n)
{
    double* res=(double*)malloc(sizeof(double)*n);
    int i,j;
    double tmp;
    for(i=0;i<n;++i){
        for(j=i;j<n;++j){
            if(arr[i]>arr[j]){
                tmp = arr[i];
                arr[i]=arr[j];
                arr[j]=tmp;
            }
        }
    }
    for(i=0;i<n;++i){
        res[i] = arr[i];
    }
    return res;
}

double median(double a[],int n)
{
    int k = n/2;
    if (n%2)
        return a[k];
    else
        return (a[k-1]+a[k])/2;
}

int main()
{
    int n,i;
    scanf("%d",&n);
    double* num = (double*)malloc(sizeof(double)*n);
    for(i=0;i<n;++i){
        scanf("%lf",&num[i]);
    }
    double* num_ascending = ascending(num,n);
    double result = median(num_ascending,n);
    printf("%.2f",result);
    free(num);
    free(num_ascending);
    return 0;
}
