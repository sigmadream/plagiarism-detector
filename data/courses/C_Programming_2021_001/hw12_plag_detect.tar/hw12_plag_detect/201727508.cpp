#include <stdio.h>
#include <stdlib.h>

double median(double a[], int n);
int compare(const void *a, const void *b);

int main()
{
    int n;
    double m;
    scanf("%d", &n);
    double a[n];
    for (int i=0; i<n; i++)
    {
        scanf("%lf", &a[i]);
    }
    qsort(a, n, sizeof(double), compare);

    m = median(a, n);
    printf("%.2f", m);
    return 0;
}

double median(double a[], int n)
{
    if (n % 2 ==0)
    {
        return (a[n/2] + a[n/2 -1])/2;
    }
    else
        return a[(n-1)/2];
}

int compare(const void *a, const void *b)
{
    double num1, num2;
    num1 = *(double*)a;
    num2 = *(double*)b;
    if (num1 > num2)
        return 1;
    if (num1 < num2)
        return -1;

    return  0;  //  ascending
    // return *(int*)b - *(int*)a // descending

}
