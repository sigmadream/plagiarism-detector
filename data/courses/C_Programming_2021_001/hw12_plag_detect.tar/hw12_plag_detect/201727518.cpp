#include <stdio.h>
#include <stdlib.h>


int cmp(const void *a , const void *b){
    const double *x =a;  
    const double *y =b;
    if(*x < *y){
        return -1;
    }
    else if(*x > *y){
        return 1;
    }
    else return 0;
}

double median(double a[] , int n){
   if(n%2==0){
        //index 6이면 2 3 4이면 1 2 가운데
        return (a[n/2-1] + a[n/2])/2;
    }
    else{
        return a[n/2];

    }
}


int main(){

    int n;
    scanf("%d" , &n);
    getchar();
    double arr[n];
    for(int i=0; i<n; ++i){
        scanf("%lf" , &arr[i]);
    }
    qsort(arr , sizeof(arr)/sizeof(double) , sizeof(*arr) , cmp);
    printf("%.2f" , median(arr , n));
   
    
    






    return 0;
}