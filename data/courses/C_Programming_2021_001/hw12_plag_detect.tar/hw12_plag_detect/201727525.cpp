#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdlib.h> //qsort

// double형을 읽고 값이 크기 상 가운데인 중앙값 출력
// 개수가 홀수 개라면 정중앙값, 짝수개라면 그두놈의 평균

// int cmp(const void *a, const void *b)
// {
//     const int *x = a, *y = b;
//     return *x - *y;
// } 이렇게하면 잘 안됨

int cmp(const void *a, const void *b)
{
    const double *x = a, *y = b;
    if (*x < *y)
        return -1;
    else
        return 1;
}

double median(double a[], int n)
{
    double result;
    // 홀수경우
    if (n % 2 != 0)
    {
        // int index = floor(n / 2); // 버림함수 (올림은 ceil)
        result = a[n / 2];
        return result;
    }
    // 짝수경우
    else
    {
        result = (a[n / 2 - 1] + a[n / 2]) / 2;
        return result;
    }
}

int main()
{
    int count;
    scanf("%d", &count);
    double arr[count];
    for (int i = 0; i < count; ++i)
    {
        //arr[i] = 이따구로 하는거아님
        scanf("%lf", &arr[i]); // 실수형 입력받을때는 %d가 아닌 %lf
    }
    qsort(arr, count, sizeof *arr, cmp); // 그전에 정렬먼저 해줘야함
    double result = median(arr, count);
    printf("%.2f", result); // 여기도 lf
}