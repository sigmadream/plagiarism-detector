#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int cmpfunc(const void *a, const void *b)
{
    return (*(int *)a - *(int *)b);
}

void median(double arr[], int length)
{
    if (length % 2 == 0)
    {
        double median = (arr[length / 2] + arr[length / 2 - 1]) / 2;
        printf("%.2f", median);
    }
    else
    {
        double median = arr[length / 2];
        printf("%.2f", median);
    }
    return;
}

int main()
{
    double arr[500];
    int length = 0;

    scanf("%d", &length);
    getchar();

    for (int i = 0; i < length; ++i)
        scanf("%Lf", &arr[i]);

    qsort(arr, length, sizeof(double), cmpfunc);
    median(arr, length);

    return 0;
}
// 3
// 3.12 1.53 2.79
// 4
// 3.12 1.53 2.79 0.98
