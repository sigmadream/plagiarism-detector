#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double median(double a[],int n)
{
    double m;
    if(n%2==0)
        {
            m=(a[n/2]+a[(n/2)-1])/2;
        }
    else
        m=a[(n-1)/2];
    return m;
}

int cp(const void *a, const void *b)
{
    double n1 = *(double *)a;
    double n2 = *(double *)b;
    if (n1 < n2)
        return -1;
    else if (n1 > n2)
        return 1;
    else
        return 0;
}

int main()
{
    int n;
    int i;
    scanf("%d", &n);
    double a[n];

    for(i = 0; i<n; i++)
    {
        scanf("%lf", &a[i]);
    }
    qsort(a, sizeof(a)/sizeof(double), sizeof(*a),cp);

    printf("%.2f", median(a,n));
    return 0;
}
