#include<stdio.h>
#include<stdlib.h>

int cmp(const void *a, const void *b){
    int x=*(int *)a, y=*(int *)b;
    return x-y;
}

void median(double a[], int n){
    double m1=0, m2=0;

    if(n%2 == 1){                         // Ȧ���� �Է� -> ��� �� ���
        m1 = a[(n-1)/2];
        printf("%.2lf", m1);
    }
    else{                                 // ¦���� �Է� -> �� �� ���
        m2 = (a[n/2-1] + a[n/2])/2;
        printf("%.2lf", m2);
    }
}

int main(){
    int n,i;
    scanf("%d", &n);
    double a[n];

    int size = sizeof a / sizeof *a;
   // a=(int *)malloc(sizeof(int)*n);

    for(i=0; i<n; ++i){
        scanf("%.2lf", &a[i]);
    }

    qsort(a, size, sizeof *a, cmp);
    median(a, n);
    return 0;
}
