//
//  main.c
//  Problem12
//
//  Created by 황승한 on 2021/07/14.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int cmp (const void *a,const void *b ){
    const double *x = a, *y = b;
    if(*x < *y)
        return -1;
    else return 1;
        
}


double median(double a[] , int n){
    if(n % 2 == 0){
        return (a[n/2-1] + a[n/2])/2;
        
    }else{
        return a[n/2];
    }
}

int main(int argc, const char * argv[]) {
    // insert code here...
    int n = 0;
    scanf("%d", &n);
    double arr[n];
    for(int i=0; i<n ; ++i){
        scanf("%lf",&arr[i]);
    }
    qsort(arr, n, sizeof *arr, cmp);
    printf("%.2f",median(arr, n));
    return 0;
}
