#include <stdio.h>
#include <stdlib.h>

int compare(const void *a,const void*b){
    double num1 = *(double *)a;
    double num2 = *(double *)b;

    if(num1 <num2)
        return -1;
    if(num1 > num2)
        return 1;

    return 0;
}

void median(double *arr,int n){
    int oddindex = (n-1)/2;
    int evenindex = n/2-1;
    if(n%2==0){
        printf("%.2f",(arr[evenindex]+arr[evenindex+1])/2);
    }
    else{
        printf("%.2f",arr[oddindex]);
    }
}
int main(){
    int n;
    scanf("%d",&n);
    getchar();
    double *arr = malloc(sizeof(double)*(n+1));
    for(int i=0; i<n; i++){
        scanf("%lf",&arr[i]);
    }
    qsort(arr,n,sizeof(double),compare);
    median(arr,n);
    return 0;
}