#include <stdio.h>

double median(double a[], int *n) {
	double median = 0;
	if (*n % 2 == 0) {
		median = a[*n / 2] + a[(*n / 2) + 1];
		median /= 2;
	}
	else {
		median = a[(*n / 2) + 1];
	}
	return median;
}




int main() {
	int t;
	double num[501] = { 0, };
	double temp = 0;

	scanf("%d", &t);
	for (int i = 1; i <= t; i++) {
		scanf("%lf", &num[i]);
	}
	for (int i = 1; i <= t; i++) {
		for (int j = 1; j <= t - 1; j++) {
			if (num[j] >= num[j + 1]) {
				temp = num[j];
				num[j] = num[j + 1];
				num[j + 1] = temp;
			}
		}
	}
	printf("%.2lf", median(num, &t));
	return 0;
}