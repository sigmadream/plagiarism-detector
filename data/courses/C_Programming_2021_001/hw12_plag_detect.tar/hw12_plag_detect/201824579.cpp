#include <stdio.h>
int main(void)
{
	int size;
	
	scanf("%d",&size);
	
    double a[size];
    
    
    int i, j = 0;
    
    for(i = 0 ; i < size ; i++)
	{
		scanf("%lf",&a[i]);
	}
    
    double median=0.00;
    
    double temp;
    for(i=0;i<size-1;i++)
        for(j=0;j<size-i-1;j++)
        {
            if(a[j+1]<a[j])
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
        
    if(size%2==0)
        median=(a[size/2]+a[size/2-1])/2;
    else
        median=a[((size+1)/2)-1];
        
        
    printf("%.2f\n", median);
    return 0;
}



