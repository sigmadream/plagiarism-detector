#include <stdio.h>
#include <stdlib.h>

int cmp (const void *x, const void *y){
    double *a=x;
    double *b=y;
    if (*a>*b){
        return 1;
    }
    else if (*a<*b){
        return -1;
    }
    else{
        return 0;
    }
//    return a-b;
}
//
//void printArr(double * arr, int len){
//    for (int i=0; i<len; ++i){
//        printf("[%d]%f\n", i, arr[i]);
//    }
//}

double median(double * arr, int len){
    double result;
    if (len % 2 == 0){
        result = (arr[len/2]+arr[len/2-1])/2;
    }
    else{
        result = arr[len/2];
    }
    return result;

}
int main()
{
    int inputNum;
    scanf("%d", &inputNum);

    double arr[inputNum];
    for (int i=0; i<inputNum; ++i){
        scanf("%lf", &arr[i]);
    }
//    printArr(arr, inputNum);
    qsort(arr, sizeof(arr)/sizeof(double), sizeof(double), cmp);
//    printf("after sort\n");
//    printArr(arr, inputNum);

    printf("%.2f", median(arr, inputNum));

    return 0;
}
