#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int cmp (const void * a, const void * b)
{
    if (*(double*)a > *(double*)b) return 1;
    else if (*(double*)a < *(double*)b) return -1;
    else return 0;
}

int main()
{
    int n;
    scanf("%d", &n);
    double M_arr[n];

    for (int i = 0; i < n; ++i)
        scanf("%lf", &M_arr[i]);

    qsort(M_arr, n, sizeof(double), cmp);

    if (n%2 == 0)
        printf("%.2f", (M_arr[n/2]+M_arr[(n/2)-1])/2);
    else
        printf("%.2f", M_arr[(n/2)]);
    return 0;
}
