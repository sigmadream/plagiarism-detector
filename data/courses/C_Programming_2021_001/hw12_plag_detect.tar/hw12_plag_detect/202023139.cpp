#include <stdio.h>


int main() {
	
	int n, i, a, j;
	
	scanf("%d",&n);
	
	double b, tmp; 
	
	double num[n-1];
	
	for(i=0;i<n;i++) {
		scanf(" %lf", &num[i]);
	}

	for (j=0;j<(n-1);j++) {
		for(i=0;i<n-1;i++) {
			if (num[i] > num[i+1]) {
				tmp = num[i];
				num[i] = num[i+1];
				num[i+1] = tmp;
			}
		}
	}
	
	if (n % 2 == 1) {
		a = (n-1)/2;
		printf("%.2f",num[a]);
	}
	else {
		a = n/2;
		b = (num[a]+num[a-1])/2;
		printf("%.2f", b);
	}
	
	return 0;
	
}
