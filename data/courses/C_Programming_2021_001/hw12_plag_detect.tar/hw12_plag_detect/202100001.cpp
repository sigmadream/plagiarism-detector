#include <stdio.h>

void sort(double a[], int n) {
    double tmp;
    for (int i=0; i<n; i++) {
        for (int j=0; j<n-1; j++) {
            if (a[j] > a[j+1]) {
                tmp = a[j];
                a[j] = a[j+1];
                a[j+1] = tmp;
            }
        }
    }
}

double median(double a[], int n) {
    double res = 0;
    if (n % 2 == 0) {
        // printf("median at %d and %d: ", (n/2)-1,n/2);
        res = (a[(n/2)-1] + a[n/2]) / 2;
    }
    else {
        // printf("median at %d: ", n/2);
        res = a[n/2];
    }
    return res;
}

int main()
{
    int n;
    scanf("%d", &n);
    double ns[n], sorted[n], m;
    for (int i=0; i<n; i++)
        scanf("%lf", &ns[i]);
    
    // puts("ordinary:");
    // for (int i=0; i<n; i++)
    //     printf("%.2f ", ns[i]);
    // puts("");
    sort(ns, n);
    // puts("sorted:");
    // for (int i=0; i<n; i++)
    //     printf("%.2f ", ns[i]);
    // puts("");
    
    m = median(ns, n);
    printf("%.2f",m);
    
    return 0;
}