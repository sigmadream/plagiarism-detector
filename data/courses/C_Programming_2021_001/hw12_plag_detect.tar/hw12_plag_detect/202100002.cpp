#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// double* ascending(double arr[],int n)
// {
//     double* res=(double*)malloc(sizeof(double)*n);
//     int i,j;
//     double tmp;
//     for(i=0;i<n;++i){
//         for(j=i;j<n;++j){
//             if(arr[i]>arr[j]){
//                 tmp = arr[i];
//                 arr[i]=arr[j];
//                 arr[j]=tmp;
//             }
//         }
//     }
//     for(i=0;i<n;++i){
//         res[i] = arr[i];
//     }
//     return res;
// }

int cmp(const void *a, const void *b) {
    const double *x = a, *y = b;
    int val = 0;
    val = (*x < *y)? -1: +1;
    return val;
}

double median(double a[],int n)
{
    int k = n/2;
    return (n%2 != 0)? a[k]: (a[k-1]+a[k])/2;
}

int main()
{
    int n,i;
    scanf("%d",&n);
    double num[n];
    for (i=0;i<n;++i) {
        scanf("%lf",&num[i]);
    }
    // double* num_ascending = ascending(num, n);
    qsort(num, n, sizeof *num, cmp);
    double result = median(num, n);
    printf("%.2f\n",result);
    // free(num_ascending);
    return 0;
}

