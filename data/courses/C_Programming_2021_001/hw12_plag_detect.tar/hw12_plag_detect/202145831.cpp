#include <stdio.h>
#include <assert.h>

void median(double a[], int n);

int last;

int main()
{
    int n = 0;

    scanf("%d", &n);
    assert(0 < n && n <= 500);
    double a[n];

    for (int i = 0; i < n; i++)
        scanf("%lf", &a[i]);

    for (int i = 0; i < n; i++){
            for (int j = i + 1; j < n; j++){
                if (a[i] > a[j]){
                    int temp = a[j];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
    }

    last = n - 1;

    median(a, n);


    return 0;
}

void median(double a[], int n)
{
    if (last % 2 == 0)
    {
        printf("%.2f\n", a[last / 2]);
    }
    else
    {
        printf("%.2f\n", (a[last / 2] + a[(last / 2) + 1]) / 2);
    }

}
