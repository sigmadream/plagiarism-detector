#include <stdio.h>
#include <stdlib.h>

int cmp(const void *a, const void *b){
    int x = *(int *)a, y = *(int *)b;
    return x - y;
}

int main()
{
    int num;
    scanf("%d", &num);

    float a[num];

    for (int i=0; i < num; i++)
        scanf("%f", &a[i]);

    int size = sizeof a / sizeof *a;

    qsort(a, size, sizeof *a, cmp);

    if (num % 2 == 0){ //짝수 경우
        int middle = num / 2;
        float avg = (a[middle] + a[middle - 1]) / 2;
        printf("%.2f\n", avg);

    } //홀수 경우
    else{
        printf("%.2f", a[num / 2]);
    }
    return 0;
}
