#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int cmp(const void *a, const void *b) {
    if(*(double *)a>*(double *)b)
		return 1;
	else if(*(double *)a<*(double*)b)
		return -1;
	else return 0;
}

double median(double a[], int n){
qsort(a, n, sizeof *a, cmp);
    if(n % 2 == 0){
        return (a[n/2] + a[n/2-1])/2;}
    else
        return a[(n)/2];
}

int main() {
const int MAX = 0;
scanf("%d", &MAX);
double a[MAX];
int size = MAX;

for (int i = 0; i < MAX; ++i)
    scanf("%lf", &a[i]);

printf("%.2f", median(a, size));
return 0;
}
