#include <stdio.h>

int main() {
    int n;

    scanf("%d",&n);
    if(n % 2 == 0){
        printf("Hola %d\n",n);
    }
    else {
        printf("Hello %d\n", n);
    }
    return 0;
}
