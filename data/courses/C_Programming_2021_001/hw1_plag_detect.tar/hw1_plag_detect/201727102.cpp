#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
	int n = 0;
	
	scanf("%d", &n);
	
	if(n%2 == 0)
		printf("Hola %d\n",n);
	else
		printf("Hello %d\n",n);
	
	return 0;
}
