#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;

    scanf("%d", &n);
    if (n % 2 == 0)
    {
        printf("Hola %d", n);
    }
    else
    {
        printf("Hello %d", n);
    }

    return 0;

}
