#include <stdio.h>

int main()
{
    int num = 0;
    scanf("%d", &num);

    if (num % 2 == 0)
        printf("Hola %d\n", num); // 짝수
    else
        printf("Hello %d\n", num); // 홀수

    return 0;
}
