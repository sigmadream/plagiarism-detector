//
//  main.c
//  Problem1
//
//  Created by 황승한 on 2021/06/23.
//

#include <stdio.h>

int main()
{
    int n = 0;
    scanf("%d", &n);
    
    if(n%2 == 0){
        printf("Hola %d\n",n);
    }else{
        printf("Hello %d\n",n);
        
    }
    return 0;
}

// puts new line까지 자동 추력
//printf 는 new line 지원 안해준다
//c 언어로 할 때는 return을 0으로 하는게 좋다 다른 수는 에러값으로 인식한다.
