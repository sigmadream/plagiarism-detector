#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	if (n % 2 == 0)
		printf("Hola ");
	else
		printf("Hello ");
	printf("%d", n);

	return 0;

}