#include <stdio.h>

int main(){
    int N;

    scanf("%d", &N);
    if(N%2 == 0)
        printf("Hola %d\n", N);
    else
        printf("Hello %d\n", N);

    return 0;
}

