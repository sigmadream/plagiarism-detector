#include <studio.h>
#include <stdlib.h>

int main()
{
    int n = 0;

    scanf ("%d", &n);

    if (n % 2 == 0)
        puts ("even.");
        printf("Hola %d is ", n);
    else
        puts ("odd.");
        printf("Hello %d is ", n);

    return 0;
