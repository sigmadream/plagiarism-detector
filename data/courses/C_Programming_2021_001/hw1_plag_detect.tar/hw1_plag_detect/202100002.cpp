#include <stdio.h>

int main()
{
    int n = 0;

    scanf("%d", &n);
    printf("%s %d\n", (n % 2 == 0)?"Hola":"Hello", n); 

    return 0;
}
