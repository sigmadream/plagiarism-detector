#include <stdio.h>

int main()
{
	int N = 0;

	scanf("%d", &N);
	printf("%d\r ",N);

	if (N % 2 == 0)
		puts("Hola");
	else
		puts("Hello");

	return 0;

}
