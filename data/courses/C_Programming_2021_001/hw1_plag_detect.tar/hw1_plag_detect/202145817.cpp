/*
    hello.c
*/
#include <stdio.h>

int main(void)
{
    int num;

    scanf("%d", &num);

    if(num % 2 == 0)
        printf("    Hola %d\n\n", num);
    else
        printf("    Hello %d\n\n", num);

    return 0;
}