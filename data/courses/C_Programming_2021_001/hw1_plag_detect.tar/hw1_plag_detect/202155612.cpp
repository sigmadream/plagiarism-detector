#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n = 0;
    scanf("%d", &n);
    if (n % 2 == 0)
        printf("Hola %d\n",n);
    else
        printf("Hello %d\n",n);
    return 0;
}
