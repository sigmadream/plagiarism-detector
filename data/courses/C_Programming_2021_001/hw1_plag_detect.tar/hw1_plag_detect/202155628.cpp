#include <stdio.h>


int main()

{
    int n = 0;

    scanf("%d",&n);
    printf("%d",n);

    if (n % 2 == 0)
        printf("Hola"," ",n);
    else
        printf("Hello"," ",n);

    return 0;
}
