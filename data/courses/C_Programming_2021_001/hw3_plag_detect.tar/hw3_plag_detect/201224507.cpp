#include <stdio.h>

int main() {

    int wish_py = 0;
    double provided_m2 = 0.0;
    double temp_m2 = 0.0;

    scanf("%d", &wish_py);
    while (scanf("%lf", &provided_m2) == 1) {
        if(provided_m2 >= temp_m2 && (provided_m2/3.3058) <= (double)wish_py) {
            temp_m2 = provided_m2;
        }
    }

    provided_m2 = temp_m2 / 3.3058;

    printf("%.2f\n", provided_m2);
    printf("%.2f", temp_m2);

    return 0;
}