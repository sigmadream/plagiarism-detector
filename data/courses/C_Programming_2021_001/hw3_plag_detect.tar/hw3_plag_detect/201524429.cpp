#include <stdio.h>


int main() {
    int pyeong;
    double square;
    double MaxSquare = 0.0;

    scanf("%d",&pyeong);
    while(scanf("%lf",&square) == 1)
    {
            if(square > MaxSquare && (square/3.3058 <= pyeong)){
              MaxSquare = square;
            }
    }
    //printf("%f\n",MaxSquare);

    printf("%0.2f\n",MaxSquare/3.3058);
    printf("%0.2f",MaxSquare);
    
    return 0;
}
