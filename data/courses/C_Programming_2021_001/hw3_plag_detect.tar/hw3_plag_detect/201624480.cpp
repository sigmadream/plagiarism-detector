#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N = 0;
    double h1, h2, h3, h4, h5;
    scanf("%d", &N);
    scanf("%f %f %f %f %f", &h1, &h2, &h3, &h4, &h5);
    double pyeong1 = h1 / 3.3058;
    double pyeong2 = h2 / 3.3058;
    double pyeong3 = h3 / 3.3058;
    double pyeong4 = h4 / 3.3058;
    double pyeong5 = h5 / 3.3058;

    double savep = 0;
    double savem = 0;

    if (pyeong1 <= N){
        savep = pyeong1;
        savem = h1;
    }

    else if (pyeong2 <= N){
        if (savep >= pyeong2)
        {
            savep = savep;
            savem = h1;
        }
        else
        {
            savep = pyeong2;
            savem = h2;
        }
    }

   else if (pyeong3 <=N){
        if (savep >= pyeong3){
            savep = savep;
            savem = h2;
        }
        else{
            savep = pyeong3;
            savem = h3;
        }
    }
    else if (pyeong4 <=N){
        if (savep >= pyeong4){
            savep = savep;
            savem = h3;
        }
        else{
            savep = pyeong4;
            savem = h4;
        }
    }

    else if (pyeong5 <=N){
        if (savep >= pyeong5){
            savep = savep;
            savem = h4;
        }
        else{
            savep = pyeong5;
            savem = h5;
        }
    }

    printf("%.2f\n", savep);
    printf("%.2f\n", savem);

    return 0;
}
