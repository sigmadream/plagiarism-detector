#include <stdio.h>
int main()
{
    int n;
    double h1, h2, h3, h4, h5;
    scanf("%d%lf%lf%lf%lf%lf",&n,&h1,&h2,&h3,&h4,&h5);


    if(n>(h1/3.3058) && n<=(h2/3.3058))
    {
        printf("%.2f\n",h1/3.3058);
        printf("%.2f\n",h1);

    }
    else if(n>(h2/3.3058) && n<=(h3/3.3058))
    {
        printf("%.2f\n",h2/3.3058);
        printf("%.2f\n",h2);
    }
    else if(n>(h3/3.3058) && n<=(h4/3.3058))
    {
        printf("%.2f\n",h3/3.3058);
        printf("%.2f\n",h3);
    }

    else if(n>(h4/3.3058) && n<=(h5/3.3058))
    {
        printf("%.2f\n",h4/3.3058);
        printf("%.2f\n",h4);
    }
    else if(n>=(h5/3.3058))
    {
        printf("%.2f\n",h5/3.3058);
        printf("%.2f\n",h5);
    }
    return 0;
}