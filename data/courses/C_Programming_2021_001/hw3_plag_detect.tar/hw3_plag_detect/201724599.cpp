#include <stdio.h>

int main()
{
	int py;
	double house;
	double house_o = 0.0;
	scanf("%d", &py);
	do {
		scanf("%lf", &house);
		if (house < py * 3.3 && house > house_o)
		{
			house_o = house;
		}
	} while (getc(stdin) != '\n');
	printf("%.2lf\n", house_o / 3.3058);
	printf("%.2lf", house_o);

	return 0;
}