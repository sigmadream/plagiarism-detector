#include<stdio.h>

int main()
{
	int py;
	double h,h1,h2=0;
	
	scanf("%d",&py);
	h=3.3058*py;
	
	while(scanf("%lf",&h1)==1)
	{
		if(h1<h && h2<h1)
		{	
			h2=h1;
		}
	}
	printf("%3.2f\n",h2/3.3058);
	printf("%3.2f\n",h2);
	
}
