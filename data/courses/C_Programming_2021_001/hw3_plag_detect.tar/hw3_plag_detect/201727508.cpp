#include <stdio.h>

int main()
{
    int n;
    float m;
    float max = 0;

    scanf("%d", &n);
    while (scanf("%f", &m)==1)
    {
        if (n >= m / 3.3058 && m >= max)
            max = m;
    }

    printf("%.2f\n%.2f", max / 3.3058, max);






    return 0;
}
