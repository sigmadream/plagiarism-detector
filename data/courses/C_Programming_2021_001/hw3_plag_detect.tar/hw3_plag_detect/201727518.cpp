#include <stdio.h>
#include <stdlib.h>



int main(){

    int criteria = 0;
    double real_area = 3.3058;
    double y= 0.0;
    double max_element = 0.0;
    double max_y=0.0;



    scanf("%d" , &criteria);

    while(scanf("%lf" , &y)==1){
        
        if((y/real_area) > criteria){
            continue;
        }
        else{
            if((y/real_area) > max_element){
                max_y= y;
                max_element = (y/real_area);

            }


        }
    }

    printf("%.2f\n" , max_element);
    printf("%.2f\n" , max_y);


    return 0;


}
