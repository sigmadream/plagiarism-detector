#include <stdio.h>

// 애매하면 손코딩으로 먼저해보자
int main()
{
    float meter = 0.0f;
    float py = 0.0f;
    float max_me = 0.0f; // 이거 두개 변수를 정의한다는것을 이해하기
    float max_py = 0.0f;

    scanf("%f", &py);                // 원하는 평수
    while (scanf("%f", &meter) == 1) // 이게 scanf 연속적으로 입력받게 되는 로직임을 이해하자 (이게 몇개만 되고 그런게 아니라 이렇게하면 항상 되는듯)
    {
        if (meter < py * 3.3058) // 나누는 방법을 통상적으로 먼저 생각할 수 있음..
        {
            if (max_me > meter)
                continue;
            max_me = meter;
            max_py = max_me / 3.3058;
        }
        else
            continue;
    }

    printf("%.2f\n", max_py);
    printf("%.2f\n", max_me);

    return 0;
}

// double float유사하지만 double이 더 정확할것..크기차이