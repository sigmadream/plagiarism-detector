#include <stdio.h>

int main()
{
    float meter = 0.0f;
    float py = 0.0f;
    float max_me = 0.0f;
    float max_py = 0.0f;

    // double meter = 0.0;
    // double py = 0.0;
    // double max_me = 0.0;
    // double max_py = 0.0;

    scanf("%f", &py); // 원하는 크기
    while (scanf("%f", &meter) == 1)
    {
        if (meter < 0)
            continue;
        if (meter < py * 3.3058)
        {
            if (max_me > meter)
                continue;
            max_me = meter;
            max_py = max_me / 3.3058;
        }
        else
            continue;
    }

    printf("%.2f\n", max_py);
    printf("%.2f\n", max_me);

    return 0;
}