#include <stdio.h>

int main() {
    int N = 0;
    float h = 0.0;
    float N1 = 0.0;
    float N2 = 0.0;
    float h1 = 0.0;
    float stdh = 0.0;
    scanf("%d", &N);
    stdh = N * 3.3058;
    while(scanf("%f", &h) == 1) {

        if(stdh > h) {
            if(h > h1) {
                h1 = h;
            }
            else
                continue;
        }
        else
            continue;

    }
    N1 = h1 / 3.3058;
    printf("%.2f\n", N1);
    printf("%.2f\n", h1);

    return 0;
}

