#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N = 0;
    double h=0, py=0, maxpy=0, maxh=0;
  char Inh;


    fscanf(stdin, "%d", &N);

    while (1)

       {
          fscanf(stdin, "%c", &Inh);
          if(Inh=='\n')
             break;
          h=atof(Inh);
          py=h/3.3058;

    if (py <= N){
        if (py > maxpy){
            maxpy = py;
            maxh = h;
}
}
       }



    fprintf(stdout, "%.2f\n", maxh);
    fprintf(stdout, "%.2f\n", maxpy);

    return 0;
}
