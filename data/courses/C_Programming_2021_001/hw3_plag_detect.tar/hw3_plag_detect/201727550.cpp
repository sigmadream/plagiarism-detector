//
//  main.c
//  Problem3
//
//  Created by 황승한 on 2021/06/28.
//

#include <stdio.h>

int main(){
    int n  = -1;
    scanf("%d", &n);
    double n_m2 = n *3.3058;
    double pyeng = -1;
    double target_pyeng = -1;
    double max = -1;
    while(scanf("%lf",&pyeng) == 1 ){
        if(pyeng <= n_m2 && max < pyeng){
            max = pyeng;
            target_pyeng = max / 3.3058;
        }else{
            continue;
        }
    }
    printf("%.2f\n" , target_pyeng);
    printf("%.2f", max);
    
    //scanf의 값은 읽어들인 수
}
