int main()
{
    double py = 3.3058;
    int n;
    int i = 0;
    double h[i];
    double hp[i];
    double max = 0;


    scanf("%d\n %lf %lf %lf %lf %lf", &n, &h[i]);

    h[i]/py = hp[i];

    if(hp[i]<=n)
	for(i=0;i<5;i++)
	{
	scanf("%lf",&hp[i]);
		if(max < hp[i])
		{
			max = hp[i];
			h[i]=hp[i]*py
		}


    printf("%.2lf\n%.2lf",max,h[i]);
}
    return 0;

}

