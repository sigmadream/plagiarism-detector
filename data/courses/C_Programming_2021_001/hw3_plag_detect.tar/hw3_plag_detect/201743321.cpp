#include <stdio.h>

int main(){
    float divide = 3.3058;
    int n; //주어진 평수
    float h; //제곱미터
    float max = 0;
    scanf("%d",&n);
    while (scanf("%f",&h)==1){
        if (h/divide<n && h>max)
            max = h;
    }
    printf("%.2f \n",max/divide);
    printf("%.2f",max);
}