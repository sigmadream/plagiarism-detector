#include <stdio.h>

int main() {
	int n,i=0;
	double h=0.0;
	double max=0.0;
	scanf("%d\n", &n);
	while (1) {
		scanf("%lf", &h);
		if (h / 3.3058 > max && h / 3.3058 <=n) {
			max = h / 3.3058;
		}
		if (i < 5) {
			i = i + 1;
		}
		else
			break;


	}
	printf("%.2f\n%.2f", max,max*3.3058);
	return 0;
}