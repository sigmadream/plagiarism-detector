#include <stdio.h>

int main(void)
{
	double N;
	double H;
	
	scanf("%lf", &N);
	N = H/3.3058;
	printf("%.2lf\n", N);

	
	return 0;
}
