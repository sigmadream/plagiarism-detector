#include <stdio.h>

int main()
{

    float n = 3.3058;
    int N = 0;
    double h = 0.0;

    fscanf(stdin,"%d\n%lf\n", &N, &h);
    if(h/n <= N)
        printf("%.2lf\n%.2lf\n", h/n, h);


    return 0;

}
