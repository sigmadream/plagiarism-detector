#include<stdio.h>
#define PP 3.3058

int main(void)
{
    int py = 0;
    double N = 0.0;
    double store=0.0;

    scanf("%d",&py);

    while(scanf("%lf",&N)==1)
    {
        if(N>=py*PP)
            continue;

        else if(N<=py*PP)
        {
            if(store<=N)
                store = N;
        }
    }

    printf("%.2lf\n",store/PP);
    printf("%.2lf",store);



    return 0;
}

