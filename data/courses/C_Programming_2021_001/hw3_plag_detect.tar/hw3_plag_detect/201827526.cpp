#include <stdio.h>
#include <stdlib.h>

int main()
{
    double input1=0;
    double input2=0;
    double temp=0;
    double result=0;

    scanf("%lf", &input1);
    input1=input1*3.3058;
    scanf("%lf", &temp);
//    int count=0;
    while (1==scanf("%lf[\n]", &input2)){
//            printf("input2 : %f", input2);
            if (input2=='\n'){
//                    printf("%s", "break!!");
                break;
            }
        if (temp<=input2 && input2<=input1){
            result=input2;
        }
//    ++count;
    }

    printf("%.2f\n%.2f", result/3.3058, result);

    return 0;
}
