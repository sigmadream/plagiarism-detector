#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N = 0;
    double m2 = 0.0;
    double want = 0.0;
    double vari1 = 0.0;


    scanf("%d", &N);
    while (scanf("%lf", &m2) == 1)
        if (m2/3.3058 < N)
            if (want < m2/3.3058)
                want = m2/3.3058, vari1 = m2;



    printf("%.2lf\n%.2lf", want, vari1);

    return 0;

}
