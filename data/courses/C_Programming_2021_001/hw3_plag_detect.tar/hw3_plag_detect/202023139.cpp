#include <stdio.h>

int main() {
    int py, a = 1, n = 0 ;
    double y, z, x = -100.0, h[100] ;
    double py1 = 3.3058 ;

    scanf("%d", &py);
    n = scanf ("%lf", &h);

    y = (double)py*py1 ;

    if (a <= n) {
            if(*h<y) {
                    if(((y-*h)<(y-x))) x = *h ;
            }

            *h = *h+1 ;
            a++ ;
        }

    z = x / py1 ;

    printf("%.2f \n", z);
    printf("%.2f", x);

    return 0 ;

}
