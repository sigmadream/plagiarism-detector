#include <stdio.h>

int main()
{
    double limit, area, u = 3.3058, maxMinAreaMeter = 0, maxMinAreaPy = 0;
    scanf("%lf", &limit);
    while (scanf("%lf", &area) == 1) {
        double py = area / u;
        if (py < limit) {
            if (py > maxMinAreaPy) {
                maxMinAreaPy = py;
                maxMinAreaMeter = area;
            }
        }
    }
    printf("%.2f\n", maxMinAreaPy);
    printf("%.2f\n", maxMinAreaMeter);
    
    return 0;
}