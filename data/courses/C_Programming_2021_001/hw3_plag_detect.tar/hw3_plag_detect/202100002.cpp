#include <stdio.h>

int main(void) {
    const double P2M = 3.3058;
    int limit_py = 0;
    double limit_m = 0.0;
    double candidate_m = 0.0;
    double result_py = 0.0;
    double result_m = 0.0;

    // 평 > 제곱미터 계산해서 한계 정한다
    scanf("%d", &limit_py);
    limit_m = limit_py * P2M;

    // 여러 제곱미터 입력받는다
    while (scanf("%lf", &candidate_m) == 1) {
        if (candidate_m <= limit_m && candidate_m > result_m) {
            result_m = candidate_m;
            result_py = result_m / P2M;
        }
    }
    printf("%.2f\n%.2f\n", result_py, result_m);
    
    return 0;
}
