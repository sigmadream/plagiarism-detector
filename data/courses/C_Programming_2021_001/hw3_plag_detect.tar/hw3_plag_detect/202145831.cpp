#include <stdio.h>

int main()
{
    const double PYEONG = 3.3058;

    int n = 0;

    double max1 = 0.0;
    double max2 = 0.0;
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;

    scanf("%d", &n);
    scanf("%lf %lf %lf", &x, &y, &z);

   if (((x / PYEONG ) < (n / PYEONG)) || ((y / PYEONG ) < (n / PYEONG)) || ((z / PYEONG ) < (n / PYEONG)))
   {
       max1 = (x > y) ? x : y;
       max1 = (max1 > z) ? max1 : z;

       max2 = (x / PYEONG > y / PYEONG) ? x / PYEONG : y / PYEONG;
       max2 = (max1 > z / PYEONG) ? max1 : z / PYEONG;



   }
    printf("%.2f\n", max2);
    printf("%.2f\n", max1);


   return 0;
}


