#include <stdio.h>
#include <stdlib.h>

int main()
{

    float want, pyeong, max, num;
    pyeong = 3.3058;
    max = 0.0;
    num = 0.0;

    scanf("%f", &want);
    want = want * pyeong;

    while (scanf("%f", &num) == 1){
        if (num < want)
            if (num > max)
                max = num;
    }

    printf("%.2f\n%.2f", max / 3.3058, max);
}
