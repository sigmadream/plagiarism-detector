#include <stdio.h>

int main()
{
    double N = 0.0, a = 0.0, p = 0.0, Nh = 0.0, hp = 0.0;

    fscanf(stdin, "%lf", &N);
    Nh = N * 3.3058;

    while (scanf("%lf", &a) == 1){
        if (a > p && a < Nh){
            p = a;
        }
    }

    hp = p / 3.3058;
    printf("%.2lf\n%.2lf",hp,p);
}
