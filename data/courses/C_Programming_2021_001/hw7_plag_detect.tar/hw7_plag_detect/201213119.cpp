#include <stdio.h>
#include <string.h>

int main ()
{
    char line [ ] = "C programming is good!";
    char word [ ] = "programming";

    printf ("%s\n", strstr(line, word));

    return 0;
}
