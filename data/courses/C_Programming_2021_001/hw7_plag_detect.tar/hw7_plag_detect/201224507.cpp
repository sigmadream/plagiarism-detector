#include <stdio.h>
#include <string.h>
#define MAX_STR_SIZE 257

int find_index(char* a, char* b) {
    return strstr(a, b) - a;
}

int main() {
    char search_word[MAX_STR_SIZE];
    char input_str[MAX_STR_SIZE];

    scanf("%s", search_word);

    while (1) {
        fgets(input_str, MAX_STR_SIZE, stdin);
        input_str[strlen(input_str) - 1] = '\0';
        if (strstr(input_str, search_word) != NULL) {
            printf("%s (%d)\n", input_str, find_index(input_str, search_word));
        }
    }

    return 0;
}