#include <stdio.h>
#include <string.h>
#include <stdlib.h>



int main ()
{   char temp[100];
    char word[100];
    char *pPos ;

    //int i=0;


    fgets(word,100,stdin);
    word[strlen(word)-1] = '\0';

    while(fgets(temp,100,stdin)){
        temp[strlen(temp)-1]='\0';
        pPos = strstr(temp,word);
        if(temp[0] == '\0'){
            return 0;
        }
        if(pPos != NULL){
            int idx = pPos - temp;
            printf("%s (%d)\n",temp,idx);
        }
        //loc = strstr(string, word); // loc-line
        //if (loc != NULL) {
        //int idx = loc - string;
        //printf("%s (%d)\n", string, idx);
        //}
    }
    //printf("%s %d",word,nCount);



    return 0;
}
