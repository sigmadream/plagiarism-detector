#include <stdio.h>
#include <string.h>

int charmap(char a[],char b[])
{
    int j = 1;
    int i;
    int k = -1;

    for(i=0;i<strlen(b);i++){
        if(a[0] == b[i]){
            while(1){
                if(j == strlen(a)){
                    k = i;
                    break;
                }
                if(a[j] != b[i+j]){
                    j = 1;
                    break;
                }
                else
                    j++;
            }
        }
        if (k == i)
            break;
    }
    return k;
}

int main()
{
    char word[256];
    char line[256];
    scanf("%s",word);
    getchar();

    while(1){
        if(scanf("%[^\n]s",line) == EOF)
            break;
        char *loc = strstr(line,word);
        if (loc != NULL)
            printf("%s (%d)\n",line,charmap(word,line));
        getchar();
    }

    return 0;
}
