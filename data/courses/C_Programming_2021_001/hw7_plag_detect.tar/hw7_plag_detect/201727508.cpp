#include <stdio.h>
#include <string.h>

int main()
{
    char word[257];
    char line[257][257];

    scanf("%s", word);

    int i = 0;
    while(1)
    {
        if (scanf(" %[^\n]s", line[i]) == 0)
            break;
        else
            i++;
    }

    for (int j=0; j<i; j++)
    {
        char *loc = strstr(line[j], word);
        if (loc != NULL)
            printf("%s (%d)", line[j], loc-line[j]);
    }











}
