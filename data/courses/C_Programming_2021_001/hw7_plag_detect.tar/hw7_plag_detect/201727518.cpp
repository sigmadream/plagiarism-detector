#include <stdio.h>
#include <string.h>
#include <stdbool.h>

const int MAX = 256;
int main(){
    
    char criteria[10];
    scanf("%s" , criteria);
    char word[256];
    while(fgets(word , sizeof(word) , stdin)){
        for (int i=0; i<MAX; ++i){
            if(word[i]=='\n'){
                word[i]=='\0';
                break;
            }
        }
        
        char *loc = strstr(word , criteria);
        
        if(loc!= NULL){
            fputs(word , stdout);
            printf(" (%d)\n" ,loc);
            
        

    }
    

    return 0;
}