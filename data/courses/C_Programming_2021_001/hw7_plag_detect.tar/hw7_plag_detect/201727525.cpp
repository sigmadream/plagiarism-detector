#include <stdio.h>
#include <string.h>

int def(char line[], char wonder[])
{ // 이거 함수정의가 매우중요함
    char *definition = strstr(line, wonder);
    if (definition != NULL)
    {
        int result = definition - line;
        return result;
    }
    return -1; // -1이 리턴된다는것 주의!!!!
}
int main(int argc, const char *argv[])
{
    const int MAXWORD = 257;
    char wonder[MAXWORD];
    scanf("%s", wonder);
    char str[MAXWORD];
    while (fgets(str, sizeof(str), stdin))
    { //fgets 쓴다활용!!
        for (int i = 0; i < MAXWORD; ++i)
        {
            if (str[i] == '\n')
            {
                str[i] = '\0';
                break; // 여기에 break된다는거 주의
            }
        }
        int index = def(str, wonder);
        if (index != -1)
        {
            fputs(str, stdout); // fgets에 이어 fputs사용되었다 알기
            printf(" (%d)\n", index);
        }
    }
    return 0;
}
