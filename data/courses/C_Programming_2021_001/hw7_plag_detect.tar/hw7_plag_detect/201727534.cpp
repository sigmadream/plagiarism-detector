#include <stdio.h>
#include <string.h>

int return_index(char *line, char *word)
{
    int index = 0;
    index = strstr(line, word) - line;
    return index;
}

int main()
{
    char line[256];
    char word[256];
    int index = 0;

    scanf("%255s", &word); // buffer 값 제거
    getchar();

    // while (scanf(" %[^\n]s", line) == 1)
    while (fgets(line, 256, stdin))
    {
        // length = strlen(line);
        // printf("%d", length);
        for (int i = 0; i < strlen(line); i++)
        {
            if (line[i] == '\n')
                line[i] = '\0';
        }
        index = return_index(line, word);
        if (index >= 0)
            printf("%s (%d)\n", line, index);
    }

    return 0;
}
// C
// Do you know C programming?
// C is very interesting language.
// OK, I see!

// the
// this nation, under God,
// shall have a new birth of freedom -
// and that government
// of the people,
// by the people, for the people,
// shall not perish from the earth.
