#include <stdio.h>
#include <string.h>

int main()
{
    char line[256];
    char word[256];
    char* str;
    scanf("%s\n", word);

    while(gets(line)){
        if(line[0]=='^Z') break;
        str = strstr(line, word);
        if(str!=NULL){
            printf("%s (%d)\n",line, str-line);
        }
    }

    return 0;
}
