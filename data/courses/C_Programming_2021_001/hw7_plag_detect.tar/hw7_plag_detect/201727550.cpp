//
//  main.c
//  Problem7
//
//  Created by 황승한 on 2021/07/06.
//

#include <stdio.h>
#include <string.h>

int chum(char str[], char target[]){
    
    char *loc = strstr(str,target);
    if(loc != NULL){
        int idx = loc- str;
        return idx;
    }
    return -1;
}
int main(int argc, const char * argv[]) {
    // insert code here...
    const int MAX_WORD = 257;
    char target[MAX_WORD];
    scanf("%256s", target);
    //printf("%s", target);
    char str[MAX_WORD];
    
    while(fgets(str,sizeof(str),stdin)){
        for(int i=0;i <MAX_WORD ; ++i){
            if(str[i] == '\n'){
                str[i] = '\0';
                break;
            }
        }
        int idx = chum(str,target);
        if(idx != -1){
            fputs(str, stdout);
            printf(" (%d)\n",idx);
        }
       
        
    }
    return 0;
}
