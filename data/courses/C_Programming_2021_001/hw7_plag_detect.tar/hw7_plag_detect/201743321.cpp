#include <stdio.h>
#include <string.h>

int idx(char word[],char line[]){
    char *loc = strstr(line,word);
    if (loc != NULL){
        int idx = loc-line;
        return idx;
    }
    else{
        return 500;
    }
}
int main(){
    char word[257];
    fgets(word,257,stdin);
    word[strlen(word)-1]='\0';
    char line[257];
    char answer[257][257];
    while(fgets(line,257,stdin) != NULL){
        line[strlen(line)-1]='\0';
        int result = idx(word,line);
        if(result != 500){
            answer[0]=printf("%s (%d)\n",line,result);
        }
    }
}