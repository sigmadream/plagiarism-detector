#include <stdio.h>
#include <string.h>

int main() {
	char word[256];
	char line[256];

	scanf("%s\n", word);
	while (line != NULL) {
		scanf("%[^\n]s", line);
		char* p;
		p = strstr(line, word);
		if (p != NULL) {
			printf("%s (%d)", line, p - line);
			break;
		}
		else break;

	}
}