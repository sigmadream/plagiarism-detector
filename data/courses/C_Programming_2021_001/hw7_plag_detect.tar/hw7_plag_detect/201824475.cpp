#include <stdio.h>
#include <string.h>

int main(){
	const int MAX_LINE = 256;

	char word;
	char line[MAX_LINE];
	
	
	int t;
	
	scanf("%s", &word);
	scanf("%s", &line);
	
	printf("%s\n", strstr(line, word));
	
	
	return 0;
}
