
#include <stdio.h>
#include <string.h>

int main()
{
    const int MAX_WORD = 30;
    char line[] = "Do you know C programming";
    char word[MAX_WORD];

    scanf("%30s", word);
    char *loc = strstr(line, word);
    if(loc != NULL)
    {
        int idx = loc - line;
        printf("%s (%d)\n", line, idx);


    }
    else {
        puts(">>Not found<<");
    }

    return 0;
}







