#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int find(char * str, char * wantToFind)
{
//��ã���� -1��ȯ
    int result=-1;
    for (int i=0; i<strlen(str); ++i)
    {
        if (str[i]==wantToFind[0])
        {
            result = i;
            for (int j=0; j<strlen(wantToFind); ++j)
            {
                if (str[i+j] != wantToFind[j])
                {
                    result=-1;
                    break;
                }
            }
        }
        if (result != -1){
            break;
        }
    }
    return result;
}

int main()
{
//    char str[100]="abcdeabcde";
//    printf("%d", find(str, "bca"));

    char word[260];
    scanf("%s", word);
    int trash;
    scanf("%c", &trash);

//    printf("resutl : %d\n", strlen(word));

    char line[260];
    while (NULL != fgets(line, 260, stdin)){


//        printf("%s strlen() : %d\n", line,  strlen(line));

//        printf("%c\n", line[strlen(line)]);
//        printf("%c\n", line[strlen(line)-1]);

        line[strlen(line)-1]='\0';

//        line[strlen(line)]='10';
//                printf("strlen() : %d\n", strlen(line));
//        printf("%s strlen() : %d\n", line,  strlen(line));

        int index = find(line, word);
        if (index != -1){
            printf("%s (%d)\n", line, index);
        }
    }
}
