#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    const int MAX_WORD = 256;
    char line[MAX_WORD];
    char word[MAX_WORD];

    scanf("%s", word);

    for (int i = 0; i < 1000; ++i){
        fgets(line, MAX_WORD, stdin);
        line[strlen(line)-1] = '\0';
        if (strstr(line, word) != NULL){
            char *loc = strstr(line, word);
            int idx = loc - line;
            printf("%s (%d)\n", line, idx);
        }

    }



    return 0;
}
