#include <stdio.h>
#include <string.h>
#define MAX 256

int main()
{
    char word[MAX];
    char line[MAX];
    char *c;
    fgets(word, MAX, stdin);
    int sizeOfWord = 0;
    strtok(word, "\n");
    int idx = 0;
    
    while (fgets(line, MAX, stdin)) {
        strtok(line, "\n");
        if ((c = strstr(line, word)) != NULL) {
            idx = (c - line) / sizeof(char);
            printf("%s (%d)\n", line, idx);
        }
    }
    return 0;
}