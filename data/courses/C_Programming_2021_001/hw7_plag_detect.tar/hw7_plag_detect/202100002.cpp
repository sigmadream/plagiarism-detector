#include <stdio.h>
#include <string.h>

int def(char line[], char wonder[])
{ // 이거 함수정의가 매우중요함
    char *definition = strstr(line, wonder);
    if (definition != NULL)
        return definition - line;
    return -1; // -1이 리턴된다는것 주의!!!!
}

int main(int argc, const char *argv[])
{
    const int MAXWORD = 257;
    char wonder[MAXWORD], str[MAXWORD];
    scanf("%256s", wonder);
    while (fgets(str, sizeof(str), stdin) != NULL)
    { //fgets 쓴다활용!!
        size_t len = strlen(str);
        if (str[len-1] == '\n')
            str[len-1] = '\0';
        int index = def(str, wonder);
        if (index != -1)
            printf("%s (%d)\n", str, index);
    }
    return 0;
}

