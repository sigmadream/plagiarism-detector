/*
    210706tue
    find.c
*/
#include <stdio.h>
#include <string.h>

int main(void)
{
    const int MAX_WORD = 30;
    char st[257];
    char word[MAX_WORD];

    // 찾을 단어 입력받기
    scanf("%30s", word);

    // 여러 문장(최대 256) 입력받기
    while() {
        fgets(st, 257, stdin);
    }

    // 한 행에 찾는 단어가 있다면?
    char *loc = strstr(st, word);
    if (loc != NULL) {
        int idx = loc - st;
        fputs(st, stdout);
        printf(" (%d)", idx);
    }

    return 0;
    // 행 똑같이 출력
    // (인덱스) 출력
}