#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 256

int MyGetString(char *ap_string, int a_max_length)
{
    int i;
    for (i=0;i<a_max_length; i++)
    {
        *ap_string = getchar();
        if (*ap_string == '\n') break;
        ap_string++;
    }
    *ap_string = 0;

    return i;
}

int main()
{
    int i,find_len, len, find_count = 0;
    char find_str[MAX];
    char str[MAX];

    find_len = MyGetString(find_str, MAX);
    len = MyGetString(str, MAX);

    for (i=0;i<len;i++)
    {
        int find_num = 0;
        for (int j=0;j<find_len; j++)
        {
            if(str[i+j] == find_str[j])
            {
                find_num = find_num + 1;
            }
        }
        if (find_num == find_len)
        {
            printf("%s (%d)\n", str, i);
            break;
        }
    }

    return 0;
}
