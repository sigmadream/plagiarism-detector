#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int findstr(char line1[257],char word1[257]){
    for (int i = 0; i < 257; i++){
        if(line1[i] == '\n')
            line1[i] = '\0';
    }

    char *loc = strstr(line1,word1);
    if(loc != NULL){
        return (loc - line1);
    }
    else return -1;
}


int main()
{
    char line[257];
    char word[257];
    char output[2048][256];
    int outputline = 0;

    scanf("%256s",&word);
    while(fgets(line,257,stdin) != NULL){
        if (findstr(line,word) != -1){
        int k = findstr(line,word);
        sprintf(output[outputline],"%s (%d)",line,k);
        outputline++;}
    }

    for(int i = 0; i < outputline; i++){
        puts(output[i]);
    }
    return 0;
}


