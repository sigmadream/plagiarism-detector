#include <stdio.h>
#include <string.h>

#define MAX_STR_SIZE 256

void revstr(char* s) {
    if (strlen(s) % 2 == 0) {
        for (int i = 0; i < (strlen(s) / 2); i++) {
            swapchar(&s[i], &s[strlen(s) - 1 - i]);
        }
    }
    else {
        for (int i = 0; i < ((strlen(s) - 1) / 2); i++) {
            swapchar(&s[i], &s[strlen(s) - 1 - i]);
        }
    }
}

void swapchar(char* a, char* b) {
    char temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

int main() {
    char input_str[MAX_STR_SIZE];
    fgets(input_str, MAX_STR_SIZE, stdin);
    input_str[strlen(input_str) - 1] = '\0';

    revstr(input_str);

    printf("%s", input_str);

    return 0;
}