#include <stdio.h>
#include <string.h>
void swapchar(char *a,char *b);
void revstr(char s[]);

int main() {

    char s[256];
    fgets(s,sizeof(s),stdin);
    s[strlen(s)-1] ='\0';
    revstr(s);
    printf("%s", s);

    return 0;
}



void swapchar(char *a,char *b){

    char temp = *a;
    *a = *b;
    *b = temp;

}

void revstr(char s[]) {
    int size = strlen(s);


    for (int i = 0; i < size / 2; i++) {

        swapchar(&s[i],&s[(size-1)-i]);

    }
}