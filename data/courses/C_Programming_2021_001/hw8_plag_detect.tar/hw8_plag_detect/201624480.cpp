#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
    char arr[256];
    char temp;
    int leng = 0;
    fgets(arr, 256, stdin);

    while (arr[leng] != '\n')
          leng++;

 for (int i = 0; i < leng/2; i++){
      temp = arr[i];
      arr[i] = arr[leng - i - 1];
      arr[leng - i - 1] = temp;
 }

 printf("%s\n", arr);
     return 0;
}


// strcpy(t,s) => save s to t
