#include <stdio.h>
#include <string.h>

char* revstr(char a[])
{
    static char result[257];
    for(int i=0;i<strlen(a);++i)
    {
        result[i] = a[strlen(a)-1-i];
    }
    return result;
}

void swapchar(char a[],char b[])
{
    char tmp[256];
    char *p = tmp;
    strcpy(p,a);
    strcpy(a,b);
    strcpy(b,tmp);
}

int main()
{
    char input[257];
    fgets(input,sizeof(input),stdin);
    input[strlen(input)-1] = '\0';
    char* rev = revstr(input);
    swapchar(input,rev);
    printf("%s",input);
    return 0;
}
