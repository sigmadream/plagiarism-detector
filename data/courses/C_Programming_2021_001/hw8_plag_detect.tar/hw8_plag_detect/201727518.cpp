#include <stdio.h>
#include <string.h>

#define MAX 256

void swapstr(char *word , int first_index , int last_index){

    char temp = *(word+first_index); //임시 저장
    *(word+first_index) = *(word+last_index);//첫번째에 마지막 문자

    *(word+last_index) = temp; //마지막에 첫번째 문자


}
char *revstr(char word[]){
    //반씩 양쪽으로 바꾸기 ex) 짝수면 반 홀수(7)이면 3 그리고 중간은 바꿀 필요 없음
    int middle_index = strlen(word)/2;
    int last = strlen(word);
    for (int i=0; i<middle_index ; i++){
        swapstr(word , i , last-i-1); //바꿀 문자 index(i , strlen(word)-i-1)
    }


    return word;
}




int main(){

    char word[MAX];

    fgets(word, MAX, stdin);
    for(int i=0; i<strlen(word); i++){
        if(word[i]=='\n')
            word[i]='\0';
    }

    printf("%s" , revstr(word));

    return 0;
}
