// fgets를 통해 입력 행 읽을 때 줄바꿈 문자가 함께 저장된단 점 주의
// 즉 단어 거꾸로 작업 전에 줄바꿈 문자 적절히 제거가 먼저
// char배열 주어지면 거꾸로 만드는 함수 revstr(s) 제작해야함
// 포인터를 이용하여 두 char 형 변수 값을 바꾸는 함수 swapchar 제작해야

#include <stdio.h>
#include <string.h>
#define max 256

void swapchar(char *string, int front, int finish)
{ // string은 *들어간다 주의 , swap원리 숫자그거랑 같음
    char temp_box = *(string + front);
    *(string + front) = *(string + finish);
    *(string + finish) = temp_box;
}

void revstr(char *string)
{
    for (int i = 0; i < (strlen(string) / 2); i++)
        swapchar(string, i, strlen(string) - 1 - i);
}

int main()
{
    char string[max];

    scanf("%255[^\n]%*c", string); // 줄 입력받는 원리
    // 이거랑 fgets 방식 차이 학습
    revstr(string);
    printf("%s", string);

    return 0;
}