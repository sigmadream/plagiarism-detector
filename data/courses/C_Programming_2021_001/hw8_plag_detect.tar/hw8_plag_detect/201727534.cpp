#include <stdio.h>
#include <string.h>

void swapchar(char *first, char *end)
{
    char temp = *first;
    *first = *end;
    *end = temp;
}

void revstr(char *line)
{
    for (int i = 0; i < strlen(line) / 2; ++i)
        swapchar(line + i, line + strlen(line) - 1 - i);
}

int main()
{
    char line[256];

    scanf("%255[^\n]%*c", line);

    revstr(line);
    printf("%s", line);

    return 0;
}