#include <stdio.h>
#include <string.h>

void swapchar(char *a, int s, int e)
{
    char x = *(a + s);
    *(a + s) = *(a + e);
    *(a + e) = x;
}

void revstr(char*a)
{
    int i;
    for (i=0; i<strlen(a)/2; i ++)
    {
        swapchar(a, i, strlen(a)-i-1);
    }
}


int main() {
    char a[256];

    fgets(a, 256, stdin);
    a[strlen(a) - 1] = '\0';

    revstr(a);

    printf("%s", a);
    return 0;
}
