#include <stdio.h>
#include <string.h>

#define MAX 256

void swapchar(char *s1, char *s2){
    char temp;

    temp=*s1;
    *s1=*s2;
    *s2=temp;
}

void revstr(char* s){
    int leng;
    leng = strlen(s);
    for(int i = 0; i<leng/2; ++i){
        swapchar(s+i,s+leng-i-1);
    }

}

int main()
{
    char s[MAX];
    scanf("%[^\n]",s);
    revstr(s);
    printf("%s\n",s);

    return 0;
}
