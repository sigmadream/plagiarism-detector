//
//  main.c
//  Problem8
//
//  Created by 황승한 on 2021/07/07.
//

#include <stdio.h>
#include <string.h>

void swapchar(char* a, char* b){
    char temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void revstr(char str[]){
    unsigned long len = strlen(str);
    for(int i=0 ; i<len/2 ; ++i){
        swapchar(str+i, str+len-i-1);
    }
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    char str[257];
    fgets(str,sizeof(str),stdin);
    for(int i=0; i<257 ; i++){
        if(str[i] == '\n'){
            str[i] = '\0';
            break;
        }
    }
    revstr(str);
    for(int i=0; i<strlen(str) ; i++){
        putchar(*(str+i));
    }
    
    return 0;
}
