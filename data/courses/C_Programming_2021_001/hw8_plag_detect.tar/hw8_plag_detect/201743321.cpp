#include <stdio.h>
#include <string.h>

char *revstr(char str[],int len){
    int i;
    static char reverse_s[257];
    for(i=0; i< len; i++){
        reverse_s[i] = str[len-(i+1)];
    }
    return reverse_s;
}
void swapchar(char str[]){
    int i;
    int len= strlen(str);
    char *re = revstr(str,len);
    for(i=0; i<len; i++){
        char temp;
        temp = str[i];
        str[i] = re[i];
        re[i] = temp;
    }
}
int main(){
    char str[257];
    fgets(str,sizeof(str),stdin);
    str[strlen(str)-1]='\0';
    swapchar(str);
    for(int i=0; i<strlen(str); i++){
        printf("%c",str[i]);
    }
    return 0;
}