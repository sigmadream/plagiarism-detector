#include <stdio.h>
#include <string.h>

#define MAX 256
int main()
{
	int len, i;
	char str[MAX];
	fgets(str,MAX,stdin);
	
	len = strlen(str)-1;
	
	for(i=len-1;i>=0;i--)
	printf("%c", str[i]);
	
	printf("\n");
}



