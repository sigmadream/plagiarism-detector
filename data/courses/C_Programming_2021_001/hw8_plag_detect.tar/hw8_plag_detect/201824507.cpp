#include <stdio.h>

int main(void) {
	char string[256];
	int count = 0;
	int i = 0;
	char temp;

	gets(string);


	while (string[i++]>0)
		count++;

	for (i = 0; i < count / 2; i++) {
		temp = string[i];
		string[i] = string[count - i - 1];
		string[count - i - 1] = temp;
	}

	printf("%s", string);
}


