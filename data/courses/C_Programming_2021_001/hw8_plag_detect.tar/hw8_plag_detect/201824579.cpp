#include<stdio.h>

#define MAX_LENGTH    256

void revstr(char a_str[])
{
	int t, len =0;
	
	while (a_str[len] != 0)
	{
		len++;
	}
	
	int i;
	for(i = len -1 ; i>=0 ; i--)
	{
		printf("%c",a_str[i]);
	}
	
	
}


int main()
{
	char str[MAX_LENGTH];
	
	
	scanf("%[^\n]s",str,MAX_LENGTH-1);
	
	
	revstr(str);
	
	return 0;
}
