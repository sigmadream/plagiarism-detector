#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void swapchar(char * a, char * b){
    char temp=*a;
    *a=*b;
    *b=temp;
}

void revstr (char str[]){
    for (int i=0, j=strlen(str)-1; i <= j ; ++i, --j){
        swapchar(&str[i], &str[j]);
    }
//    str[strlen(str)]='\0';
}

int main()
{
    char str[257];
    scanf("%256[^\n]s", str);
    getchar();// �����б�
//    str[strlen(str)-1]='\0';
//    printArr(str);
    revstr(str);
//    printf("%s\n", "------");
//    printArr(str);
    printf("%s", str);
    return 0;
}
