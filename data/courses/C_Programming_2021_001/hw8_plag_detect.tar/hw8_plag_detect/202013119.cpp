#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 256
void revstr(char s[]);

int main()
{
    char s1[MAX] = "A";

    fgets(s1, MAX, stdin);

    s1[strlen(s1)-1] = '\0';

    revstr(s1);

    return 0;
}

void revstr(char s[]){
    if (s[strlen(s)-1] == ' ')
        for (int i = strlen(s)-2; i>=0 ; i--)
            printf("%c", s[i]);
    else
        for (int i = strlen(s)-1; i>=0 ; i--)
            printf("%c", s[i]);


    }
