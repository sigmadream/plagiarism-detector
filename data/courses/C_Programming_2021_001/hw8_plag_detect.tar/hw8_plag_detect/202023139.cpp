#include <stdio.h>
#include <string.h>

void swapchar(char *a, char *b) {
	int tmp;
	tmp = *a;
	*a = *b;
	*b = tmp;
	printf("%c",a);
	
}

void revstr(char *x) {
	
	size_t n = strlen(x);
	int i = 0;
	char tmp;
	
	
	
	n = n-1;
	
	if (n%2 == 0) {
		do {
			tmp = x[n];
			x[n] = x[i];
			x[i] = tmp;
			i = i+1;
			n = n-1;
			
		} while (n != i);
	}
	else {
		do {
			tmp = x[n];
			x[n] = x[i];
			x[i] = tmp;
			i = i+1;
			n = n-1;
	
		} while ((n-i) != -1);
	}
	
}


int main() {
	
	char word[256];
	char *nword;
	int i, n, s;
	
	fgets(word,256,stdin);
	word[strlen(word)-1] = '\0';

	revstr(word);

	fputs(word,stdout);
	
	
	
}
