#include <stdio.h>
#include <string.h>
#define MAX 256

void revstr(char s[]) {
    size_t sz = strlen(s);
    for (int i=sz-1; i>=0; i--)
        printf("%c", s[i]);
    puts("");
}

int main()
{
    char inp[MAX];
    fgets(inp, MAX, stdin);
    strtok(inp, "\n");
    revstr(inp);
}