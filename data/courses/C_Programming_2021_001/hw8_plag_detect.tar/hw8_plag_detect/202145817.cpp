/*
    210707wed
    revstr.c
*/