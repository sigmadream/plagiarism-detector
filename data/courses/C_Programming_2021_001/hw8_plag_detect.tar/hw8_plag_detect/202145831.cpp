#include <stdio.h>
#include <string.h>

#define MAX 256

void revstr(char* arr);

int main()
{
    char arr[MAX];

    scanf("%s", arr);

    revstr(arr);

    printf("%s\n", arr);

    return 0;

}

void revstr(char* arr){
  size_t size = strlen(arr);
  char temp;

  for (size_t i = 0; i < size / 2; i++) {
    temp = arr[i];
    arr[i] = arr[(size - 1) - i];
    arr[(size - 1) - i] = temp;
  }
}
