#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 256




int main()
{
    char string[MAX];

    fgets(string, MAX, stdin);

    string[strlen(string) - 1] = '\0';
    //�ٹٲ� ���Ÿ� ���� �� ���� ���� ����� �˴ϴ�.

    int i=0, count=0;
    while(string[i++]>0)
        count++;

    for (i=0 ; i < count / 2 ; i++)
    {

        char temp;
        temp = string[i];
        string[i] = string[count - i - 1];
        string[count - i -1] = temp;
    }
    printf("%s", string);

    return 0;
}
