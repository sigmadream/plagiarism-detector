#include <stdio.h>
#include <stdlib.h>

/*char revstr(char s[256]){
    char output[256];
    for (int i = 0; i < strlen(s); i++){
        output[i] = s[strlen(s)-i-1];
    }
    return output;
}*/

void swapchar(char *p, char*q){
    char r = *p;
    *p = *q;
    *q = r;
}

char *revstr(char s[256]){

    for (int i = 0; i < strlen(s)/2; i++){
        swapchar(&s[i],&s[strlen(s)-i-1]);
    }

    char *output = s;
    return output;
}


int main()
{
    char input[256];
    fgets(input,256,stdin);
    if ((input[strlen(input) - 1] == '\r')|(input[strlen(input) - 1] == '\n')){
        input[strlen(input) - 1] = '\0';}

    printf("%s",revstr(input));
    return 0;
}
