#include <stdio.h>

//#define PTOM = 3.3058

int main() {
	int pyeong_i_want = 0;
	double PTOM = 3.3058;

	double greatest_pyeong = 0;
	double greatest_meter_squre = 0;

	double house_meter_square = 0;

	fscanf(stdin, "%d", &pyeong_i_want);

	while (fscanf(stdin, "%lf", &house_meter_square) != EOF) {
		double house_to_pyeong = house_meter_square / PTOM;
		if (house_to_pyeong <= pyeong_i_want && house_to_pyeong > greatest_pyeong) {
			greatest_pyeong = house_to_pyeong;
			greatest_meter_squre = house_meter_square;
		}
	}
	
	fprintf(stdout, "%.2lf\n%.2lf", greatest_pyeong, greatest_meter_squre);


	return 0;
}