#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	double pyeong = 3.3058;
	int n;
	char c_list[1000];
	
	char *result;
	
	double max= 0.00;
	
	fscanf(stdin, "%d",&n);
	fscanf(stdin, " %999[^\n]s", c_list);
	
	result = strtok(c_list, " ");
	while(result != NULL){
		double num = atof(result);
		if (num <= pyeong*n){
			if (max < num)
				max = num;
		}
		
		result = strtok(NULL, " ");
	}
	fprintf(stdout,"%.2f\n%.2f",max/pyeong,max);
}
