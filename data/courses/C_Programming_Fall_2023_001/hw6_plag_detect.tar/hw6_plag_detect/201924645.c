#include <stdio.h>

int main() {

	int bound = 0, satis_condition = 0;
	double house_list[10] = { 0.0, };
	double pyeong[10] = {0.0, };	

	fscanf(stdin, "%d", &bound);
	for (int i = 1; i < 10; i++) {
		fscanf(stdin, "%lf", &house_list[i]);
		if (house_list[i] == '\n') break;
		pyeong[i] = house_list[i] / 3.3058;
		if (pyeong[i] < bound && pyeong[i] >= pyeong[satis_condition]) {
			satis_condition = i;
		}
	}

	fprintf(stdout, "%.2lf\n%.2lf\n", pyeong[satis_condition], house_list[satis_condition]);

	return 0;

}