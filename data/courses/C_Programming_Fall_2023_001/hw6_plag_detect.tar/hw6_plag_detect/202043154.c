﻿#include <stdio.h>
#include <math.h> // for rounding functions

int main() {
    double n_pyeong;

    // Input the lower bound N in pyeong
    fscanf(stdin, "%lf\n", &n_pyeong);

    // Input the sizes of houses as a space-separated list
    double largest_size = 0.0;
    double size_m2;

    // Read house sizes in a loop
    while (fscanf(stdin, "%lf", &size_m2) == 1) {
        // Convert size from square meters to pyeong
        double size_pyeong = size_m2 / 3.3058;

        // Check if the size is less than or equal to N and larger than the current largest size
        if (size_pyeong <= n_pyeong && size_pyeong > largest_size) {
            largest_size = size_pyeong;
        }
    }

    if (largest_size > 0) {
        // Calculate the translated N′ in pyeong
        double h = largest_size * 3.3058;

        // Round to three decimal places
        h = round(h * 1000.0) / 1000.0;
        largest_size = round(largest_size * 100.0) / 100.0;

        // Output the results
        fprintf(stdout, "%.2lf\n%.2lf\n", largest_size, h);
    } else {
        // If no house satisfies the condition, print "0.00" in both lines
        fprintf(stdout, "0.00\n0.00\n");
    }

    return 0;
}