#include <stdio.h>

int main() {
	
	int pyeong;
	double meter_value, TOP_METER = 0.0, TOP_PYEONG, temp_meter;
	fscanf(stdin,"%d",&pyeong);
	getchar();
	meter_value = pyeong * 3.3058;
		do {
			temp_meter = 0.0;
			fscanf(stdin,"%lf", &temp_meter);
			if (temp_meter >= TOP_METER && temp_meter <= meter_value){
			TOP_METER = temp_meter;
			}
		} while (temp_meter != '\0');
	
	if (TOP_METER == 0.0){
		TOP_PYEONG = 0.0;
	} else{
		TOP_PYEONG = TOP_METER / 3.3058;
	}
	fprintf(stdout,"%.2f\n%.2f", TOP_PYEONG, TOP_METER);
	
	return 0;
}