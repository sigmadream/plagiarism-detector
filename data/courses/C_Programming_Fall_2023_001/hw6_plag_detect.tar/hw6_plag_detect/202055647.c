#include <stdio.h>

int main()
{
    int n_pyeong = 0;

    fscanf(stdin,"%d",&n_pyeong);

    float n_msq = n_pyeong * 3.3058f;

    float h_msq = 0.0f;
    float h_msq_max = 0.0f;

    while(fscanf(stdin,"%f",&h_msq) != EOF)
    {
        if(h_msq <= n_msq && h_msq>h_msq_max){
            h_msq_max = h_msq;
        }
    }

    float h_pyeong_max =  h_msq_max / 3.3058f;

    fprintf(stdout,"%.2f\n%.2f",h_pyeong_max,h_msq_max);


    return 0;
}
