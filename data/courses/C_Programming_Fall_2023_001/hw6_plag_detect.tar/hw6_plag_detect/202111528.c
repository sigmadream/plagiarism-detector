#include <stdio.h>

double findMax(double arr[], int n) {
    double max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}

int main() {
    int N = 0;
    double h[4]; 
    double resultNumbers[4];
    int resultCount = 0;

    scanf("%d", &N);

    for (int i = 0; i < 4; i++) {
        scanf("%lf", &h[i]);
    }

    for (int i = 0; i < 4; i++) {
        if (h[i] < N * 3.305) {
            resultNumbers[resultCount] = h[i];
            resultCount++;
        }
    }

    if (resultCount > 0) {
        double max = findMax(resultNumbers, resultCount);
        printf("%.2f\n", max/3.308);
        printf("%.2lf", max);
    } else {
        printf("0.0");
    }

    return 0;
}
