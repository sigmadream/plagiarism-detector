#include <stdio.h>

int main() {
    int N;
    if (fscanf(stdin, "%d", &N) != 1) {
        fprintf(stderr, "Error reading N from input.\n");
        return 1;
    }
    getchar();

    double maxValidSize = 0.0;
    double numbersM = 0.0;

    while (1) {
        double number;
        if (fscanf(stdin, "%lf", &number) != 1) {
            break;
        }
        double sizeInPyeong = number / 3.3058;
        if (sizeInPyeong <= N && sizeInPyeong > maxValidSize) {
            maxValidSize = sizeInPyeong;
            numbersM = number;
        }
    }

    fprintf(stdout, "%.2lf\n", maxValidSize);
    fprintf(stdout, "%.2lf\n", numbersM);

    FILE *outputFile = fopen("output.txt", "w");
    if (outputFile == NULL) {
        fprintf(stderr, "Error opening output file.\n");
        return 1;
    }

    fprintf(outputFile, "%.2lf\n", maxValidSize);
    fprintf(outputFile, "%.2lf\n", numbersM);

    fclose(outputFile);

    return 0;
}
