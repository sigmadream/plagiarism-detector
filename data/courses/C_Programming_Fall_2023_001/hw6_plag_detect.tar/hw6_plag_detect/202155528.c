#include <stdio.h>
#include <math.h>

int main(){
    double want_pyeong , size , max_size = 0 , meters = 3.3058 ;
    fscanf(stdin , "%lf\n" , &want_pyeong) ;

    while(fscanf(stdin , "%lf" , &size) == 1) {
        double size_pyeong = size / meters ;
        if(size_pyeong <= want_pyeong && size_pyeong > max_size){
            max_size = size_pyeong ;
        }
    }

    if (max_size > 0){

        fprintf(stdout, "%.2lf\n" , max_size);
        fprintf(stdout , "%.2lf\n" , round(max_size * 3.3058 * 1000) / 1000) ;

    }
    if (max_size == 0){
        fprintf(stdout , "0.00\n");
        fprintf(stdout , "0.00\n") ;
    }


    return 0 ;
}
