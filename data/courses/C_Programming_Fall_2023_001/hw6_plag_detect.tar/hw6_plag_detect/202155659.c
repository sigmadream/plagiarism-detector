#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{

	int N;
	char str[10000];
	
	fscanf(stdin, "%d%*c", &N);
	fscanf(stdin, "%[^\n]", &str);
	
	const double PYEONG = 3.3058;
	char *token;
	double array[1000], h[1000];
	int top = -1, down = -1;
	int i;

	token = strtok(str, " ");
	while (token != NULL){
		top++;
		array[top] = atof(token);

		token = strtok(NULL, " ");
	}

	for (i = 0; i <= top; i++){
		if (array[i] / PYEONG <= N){
			down++;
			h[down] = array[i];
		}
	}
	float max;
	if (down < 0){
		fprintf(stdout,"%.2lf\n%.2lf",0,0);
	}
	else{
		max = h[0];
		for (i = 1; i <= down; i++){
			if (h[i] > max){
				max = h[i];
			}
		}
		fprintf(stdout, "%.2lf\n%.2lf ", max / PYEONG, max);
	}

	return 0;
}
