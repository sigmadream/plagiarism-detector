
#include <stdio.h>
#include <stdlib.h>

int main() {
    int a;
    scanf("%d", &a);

    double* li;
    int i;

    li = (double*)malloc(a * sizeof(double));

    for (i = 0; i < a; i++) {
        scanf("%lf", &li[i]);
    }

    // Sort the array in ascending order (you can implement a sorting algorithm here)
    // You can use libraries like qsort for sorting.

    double b = a * 3.3058;
    double* answer = (double*)malloc(a * sizeof(double));
    int answerCount = 0;

    for (i = 0; i < a; i++) {
        if (b >= li[i]) {
            answer[answerCount] = li[i];
            answerCount++;
        }
    }

    if (answerCount == 0) {
        printf("0.00\n");
        printf("0.00\n");
    }
    else {
        double c = answer[0];
        for (i = 1; i < answerCount; i++) {
            if (answer[i] > c) {
                c = answer[i];
            }
        }
        double d = c / 3.3058;
        printf("%.2lf\n", d);
        printf("%.2lf\n", c);
    }

    // Free allocated memory
    free(li);
    free(answer);

    return 0;
}
