#include <stdio.h>

int main()
{
    int N;
    double h[5], p, m, lar = 0.0;
    fscanf(stdin, "%d", &N);
    for (int i=0; i<5; i++)
        {
            fscanf(stdin, "%lf", &h[i]);
        }
    p=N*3.30579;
    for (int j=0; j<5; j++)
        {
            if((h[j]<=p)&& lar < h[j])
            {
                lar = h[j];
            }
        }
    m = lar/3.30579;
    fprintf(stdout,"%4.2lf\n%4.2lf", m, lar);

}