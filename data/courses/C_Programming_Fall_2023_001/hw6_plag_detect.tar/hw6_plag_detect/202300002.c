#include <stdio.h>

int main() {
    int n = 0;
    double ub = 0.0;
    double m2 = 0.0;
    double py = 0.0;
    double min = 0.0;
    double min_m2 = 0.0;

    scanf("%d", &n);
    ub = n;
    //printf("py = %.2f\n", ub);
    while (scanf("%lf", &m2) == 1) {
        py = m2 / 3.3058;
        if (py <= ub) {
            //printf(" %.2f ", m2);
            if (py > min) {
                min = py;
                min_m2 = m2;
            }
        }
    }
    printf("%.2f\n", min);
    printf("%.2f\n", min_m2);

    return 0;
}

