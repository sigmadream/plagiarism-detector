#include <stdio.h>

int main(){
    int after_point = 0;
    float num = 0.0;

    scanf("%d", &after_point);
    scanf("%f", &num);

    printf("0.");
    for(int i = 0; i < after_point; i++){
        num *= 2;
        if(num >= 1.0){
            printf("1");
            num -= 1.0;
        }
        else{
            printf("0");
        }
    }

    return 0;
}


// #include <stdio.h>

// int main(){
//     int pizza = 0, person = 1;
//     double share = 0.0;

//     fscanf(stdin, "%d%d", &pizza, &person);
//     share = pizza;
//     share /= person;
//     fprintf(stdout, "%f pizza/person\n", share);
//     if (share >= 0.5)
//         fputs("No less than 0.1 (in binary) pizzas can be shared!\n", stdout);

//     return 0;
// }