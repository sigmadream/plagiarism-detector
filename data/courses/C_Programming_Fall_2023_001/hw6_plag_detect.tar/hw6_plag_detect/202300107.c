#include <stdio.h>

int main(){
    
    int lower_bound;
    int count = 0; //the index where the element is to be inserted
    //float arr[100];//initialize an array
    float pyeong = 3.3058;
    float input_num;
    float output = 0;
    

    //get lower bound
    scanf("%d", &lower_bound);
    float area = lower_bound*pyeong;

    while (1)
    {
        if(scanf("%f",&input_num) == 1){
            if(input_num < area){
            if (input_num > output){
                output = input_num;
            }
        }
        }
        else
        {
            break;
        }
    }
    
    /*
        //get the size(float numbers)
    do {
        scanf("%f", &input_num);
        //printf("%.3f\n", input_num);
        if(input_num < area){
            if (input_num > output){
                output = input_num;
            }
            //arr[count++] = input_num;
            //printf("%.3f\n", input_num);
        }
    } while (getchar() != '\n');
    */
    //print array element
    /*for (int i = 0; i < count; i++){
        if( output < arr[i]){
            output = arr[i];
        } 
    }
    */
    
    //printf("%.2f\n", lower_bound*pyeong);
    printf("%.2f\n", output/pyeong);
    printf("%.2f\n", output);
    
    return 0;
}