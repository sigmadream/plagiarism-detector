#include <stdio.h>

int main ()
{
    int N;
    double h[5];
    scanf("%d", &N);

    int i;
    double max = 0;
    double max_m= 0;
    for (i=0;i<5;i++){
    scanf("%Lf",&h[i]);
    if ((h[i]/3.3058) <= N && (h[i]/3.3058)> max){
        max = h[i]/3.3058;
        max_m = h[i];
    }

    }
    printf("%.2f\n",max);
    printf("%.2f",max_m);

 return 0;
}
