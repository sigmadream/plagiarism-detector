#include <stdio.h>
#include <math.h>

int main() {
    double N, N_m2, m2;
    int num_sizes;

    fscanf(stdin,"%lf", &N);
    fscanf(stdin,"%d", &num_sizes);

    N_m2 = N * 3.3058;
    double sizes_m2[num_sizes];
    for (int i = 0; i < num_sizes; i++) {
        fscanf(stdin,"%lf", &sizes_m2[i]);
    }
    m2 = 0;
    for (int i = 0; i < num_sizes; i++) {
        if (sizes_m2[i] <= N_m2) {
            m2 = fmax(m2, sizes_m2[i]);
        }
    }
    double pyeong = m2 / 3.3058;

    fprintf(stdout,"%.2f\n", pyeong);
    fprintf(stdout,"%.2f\n", m2);
    return 0;
}
