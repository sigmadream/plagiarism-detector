#include <stdio.h>
#include <math.h>

int main() {
    double N, N_m2;
    int num_sizes;

    // Read the upper limit N and the number of sizes
    scanf("%lf", &N);
    scanf("%d", &num_sizes);

    // Convert N to square meters
    N_m2 = N * 3.3058;

    // Initialize max_size_m2 to zero
    double max_size_m2 = 0;

    // Input and process sizes
    for (int i = 0; i < num_sizes; i++) {
        double size_m2;
        scanf("%lf", &size_m2);

        // Update max_size_m2 if the size is within the limit and larger
        if (size_m2 <= N_m2 && size_m2 > max_size_m2) {
            max_size_m2 = size_m2;
        }
    }

    // Convert max_size_m2 back to pyeong
    double max_size_pyeong = max_size_m2 / 3.3058;

    // Print the results with two decimal places
    printf("%.2f\n", max_size_pyeong);
    printf("%.2f\n", max_size_m2);

    return 0;
}
