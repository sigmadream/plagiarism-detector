#include <stdio.h>
#include <math.h>

int main() {
    double N, N_m2, max_size_m2;
    int h1;

    scanf("%lf", &N);
    scanf("%d", &h1);

    N_m2 = N * 3.3058;

// Input a tab and read all the elemet from the tab
    double sizes_m2[h1];
    for (int i = 0; i < h1; i++) {
        scanf("%lf", &sizes_m2[i]);
    }

// Setting up the max to zero and then comparing each tab[i] with the N_m2 to find the biggest one
    max_size_m2 = 0;
    for (int i = 0; i < h1; i++) {
        if (sizes_m2[i] <= N_m2) {
            max_size_m2 = fmax(max_size_m2, sizes_m2[i]);
        }
    }

// Converting back to pyeong before printing the output
    double max_size_pyeong = max_size_m2 / 3.3058;

    printf("%.2f\n", max_size_pyeong);
    printf("%.2f\n", max_size_m2);
    return 0;
}
