#include <stdio.h>
#include <math.h>

int main()
{
    double N, Np, max_pyeong, max;
    int hi;


    fscanf(stdin, "%lf", &N);
    fscanf(stdin, "%d", &hi);
    Np = N * 3.3058;

    double sizes[hi];

    for(int i = 0; i < hi; i++) {
        scanf("%lf", &sizes[i]);
    }

    max = 0;

    for (int i = 0; i < hi; i++) {
        if (sizes[i] <= Np) {
            max = fmax(max, sizes[i]);
        }
    }

    max_pyeong = max / 3.3058;

    printf("%.2f\n", max_pyeong);
    printf("%.2f\n", max);

    return 0;
}
