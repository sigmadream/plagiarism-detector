#include <stdio.h>
#include <math.h>

int main()
{
    //declaring all the variables
    int N;
    double h[100];
    double hresult=0.0;
    double storage = 0;
    int k=0;

    fscanf(stdin, "%d\n", &N);

    while (k < 100) { //while loop for using input of the {hi} list of sizes (assumign maximum array length is 100)
        if (fscanf(stdin,"%lf", &h[k]) == 1) {
            k++;
        } else {
            break; //here, we stop the user from continuing to input values of {hi} if he presses enter (or if the input is invalid)
        }
    }

    for (int i=0; i<N; i++){
        double size = h[i];
        double pyeong = size / 3.3058; //conversion to pyeong unit from square meters
        if (pyeong<=N && pyeong>=storage){
            storage = pyeong; //value where we store the current value of h[i] for future comparison
            hresult = size; //we store the value of the highest h that satisfies the condition
        }
    }
    fprintf(stdout, "%.2f\n%.2f", storage, hresult); //by using the %.2f we can round up to up to three after the decimal point

return 0;
 }
