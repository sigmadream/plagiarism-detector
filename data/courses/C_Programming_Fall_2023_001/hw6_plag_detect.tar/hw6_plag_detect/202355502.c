#include <stdio.h>

int main() {
    int n;
    double sizes[5];
    float pyeong = 3.3058;
    fscanf(stdin, "%d", &n);
    for (int i = 0; i < 5; i++) {
        fscanf(stdin, "%lf", &sizes[i]);
    }
    double smaller_pyeong[5];
    int count = 0;
    double max_value = -1.0;
    double max_pyeong = 0.0;

    for (int i = 0; i < 5; i++) {
        if (sizes[i] < n * pyeong) {
            smaller_pyeong[count] = sizes[i];
            count++;
            if (sizes[i] > max_value) {
                max_value = sizes[i];
                max_pyeong = max_value / pyeong;
            }
        }
    }

    printf("%.2lf\n", max_pyeong);
    printf("%.2lf\n", max_value);

    return 0;
}
