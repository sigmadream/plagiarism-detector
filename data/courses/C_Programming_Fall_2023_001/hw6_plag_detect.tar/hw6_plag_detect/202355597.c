#include <stdio.h>

double custom_ceil(double x) {
    int int_part = (int)x;
    if (x == int_part) {
        return (double)int_part;
    } else {
        return (double)(int_part + 1);
    }
}

int main() {
    double N;
    scanf("%lf", &N);

    int num_sizes;
    scanf("%d", &num_sizes);

    double sizes[num_sizes];
    for (int i = 0; i < num_sizes; i++) {
        scanf("%lf", &sizes[i]);
    }

    double largest_size = 0;
    for (int i = 0; i < num_sizes; i++) {
        if (sizes[i] <= N * 3.3058 && sizes[i] > largest_size) {
            largest_size = sizes[i];
        }
    }

    if (largest_size > 0) {
        double N_prime = largest_size / 3.3058;
        printf("%.3lf\n", custom_ceil(N_prime * 1000) / 1000); // Round to three decimal places
        printf("%.3lf\n", largest_size);
    } else {
        printf("0.000\n");
        printf("0.000\n");
    }

    return 0;
}

