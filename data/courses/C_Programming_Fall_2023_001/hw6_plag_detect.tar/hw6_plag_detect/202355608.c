#include <stdio.h>
#include <math.h>

int main() {
    double N;
    fscanf(stdin, "%lf", &N);
    double largest_h = 0.0;
    double hs[100];
    int count = 0;

    while (1) {
        int result = fscanf(stdin, "%lf", &hs[count]);
        if (result == EOF) {
            break;
        }
        if (hs[count] < N * 3.3058 && hs[count] > largest_h) {
            largest_h = hs[count];
        }
        char ch = fgetc(stdin);
        if (ch == '\n') {
            break;
        }
        count++;
    }

    double N_ = largest_h / 3.3058;

    if (largest_h > 0.0) {
        fprintf(stdout, "%.2lf\n", N_);
        fprintf(stdout, "%.2lf\n", largest_h);
    }
    else {
        fprintf(stdout, "0.00\n0.00\n");
    }

    return 0;
}

