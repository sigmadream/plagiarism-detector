#include <stdio.h>

int main() {
    const double meter_to_pyeong = 3.3058;
    double upperLimitPyeong;
    if (fscanf(stdin, "%lf", &upperLimitPyeong) != 1) {
        fprintf(stderr, "Invalid input format.\n");
        return 1;
    }

    double houseSize;
    double largestSize = 0;

    while (fscanf(stdin, "%lf", &houseSize) == 1) {
        if (houseSize <= upperLimitPyeong * meter_to_pyeong && houseSize > largestSize) {
            largestSize = houseSize;
        }
    }

    if (largestSize == 0) {
        fprintf(stdout, "0.00\n0.00\n");
    } else {

        double largestSizePyeong = largestSize / meter_to_pyeong;

        fprintf(stdout, "%.2lf\n%.2lf\n", largestSizePyeong, largestSize);
    }

    return 0;
}
