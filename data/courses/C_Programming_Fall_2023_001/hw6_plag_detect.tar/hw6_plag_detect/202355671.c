#include <stdio.h>
int main(){
    const double PYEONG = 3.3058;
    double n = 0, ans = 0;
    fscanf(stdin, "%lf", &n);
    double h;
    while(fscanf(stdin, "%lf", &h) == 1){
        if (h / PYEONG <= n && ans < h) {
            ans = h;
        }
        
    }
    fprintf(stdout, "%.2lf\n%.2lf", ans / PYEONG, ans);
    return 0;
}