#include <stdio.h>

int main(){

    int N, i;
    float h[10];
    fscanf(stdin, "%d", &N);

    int n = 10;
    float value = 0.0;
    while (i < n){

        int ch = getchar();

        if (ch == '\n'){
            break;
        }

        if (scanf("%f", &value) == 1) {
            h[i] = value;
            i++;
        }
    }


    double N_m2, largest_size_m2 = 0, largest_size_pyeong;


    N_m2 = N * 3.3058;


    for(int i = 0; i < n; i++)
    {
        if(h[i] <= N_m2 && h[i] > largest_size_m2)
        {
            largest_size_m2 = h[i];
        }
    }

    largest_size_pyeong = largest_size_m2/3.3058;
    fprintf(stdout,"%.2lf\n", largest_size_pyeong);
    fprintf(stdout,"%.2lf\n", largest_size_m2);
    return 0;
}
