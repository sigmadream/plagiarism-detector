#include <stdio.h>
#include <stdlib.h>

int main() {
    double pyeong = 3.3058;
    double n, size, max_size = 0;

    scanf("%lf", &n);

    while (1) {
        int result = scanf("%lf", &size);

        if (result == EOF || result == 0) {
            break;
        }

        if (size <= n * pyeong && size > max_size) {
            max_size = size;
        }
    }

    if (max_size > 0) {
        double max_pyeong = max_size / pyeong;
        printf("%.2lf\n %.2lf\n", max_pyeong, max_size);
    } else {
        printf("0.00\n0.00");
    }

    return 0;
}
