#include <stdio.h>

int main()
{
    double N_pyeong, N_square_meters;

    fscanf(stdin,"%lf", &N_pyeong);

    int numFloats = 0;
    float value = 0.00;

    N_square_meters = N_pyeong * 3.3058;

    int n;
    fscanf(stdin,"%d", &n);


    float floatSet[n];
    while (numFloats < n)
    {
        int ch = getchar();

        if (ch == '\n')
        {
            break;
        }


        if (fscanf(stdin, "%f", &value)==1)
        {
            floatSet[numFloats] = value;
            numFloats++;
        }
    }



    int num_sizes = sizeof(floatSet) / sizeof(floatSet[0]);

    double largest_size_square_meters = 0;


    for (int i = 0; i < num_sizes; i++)
    {
        if (floatSet[i] <= N_square_meters && floatSet[i] > largest_size_square_meters)
        {
            largest_size_square_meters = floatSet[i];
        }
    }


    double largest_size_pyeong = largest_size_square_meters / 3.3058;
    if (floatSet[n]> N_square_meters)
    {
        fprintf(stdout,"0.00");

    }
    else
    {
        fprintf(stdout,"%.2lf\n", largest_size_pyeong);
        fprintf(stdout,"%.2lf\n",largest_size_square_meters);
    }
    return 0;
}
