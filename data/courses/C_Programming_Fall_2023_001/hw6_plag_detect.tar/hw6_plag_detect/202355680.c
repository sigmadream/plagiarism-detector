#include <stdio.h>

int main()
{
	double n;
	fscanf(stdin, "%f", &n);
	double h;
	double mx = 0;
	n = n * 3.3058;
	while(fscanf(stdin, "%f", &h))
	{
		if(h <= n && mx < h)
			mx = h;
	}
	fprintf(stdout, "%.2f\n%.2f\n", mx/3.3058, mx);
}
