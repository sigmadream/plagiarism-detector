#include <stdio.h>

int main() {
    int n;
    float k;
    const int max_elements = 100;
    float a[max_elements];
    const float pyeong = 3.3058;

    fscanf(stdin, "%d", &n);

    int count = 0;

    while (count < max_elements && fscanf(stdin, "%f", &k) == 1) {
        a[count++] = k;
    }

    float max = 0;
    for (int i = 0; i < count; i++) {
        if (a[i] <= pyeong * n && a[i] > max) {
            max = a[i];
        }
    }
    float cp = max / pyeong;

    fprintf(stdout, "%.*f\n", 2, cp);
    fprintf(stdout, "%.*f\n", 2, max);
    fflush(stdout);

    return 0;
}
