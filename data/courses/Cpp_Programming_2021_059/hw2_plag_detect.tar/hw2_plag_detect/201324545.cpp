#include <cstdio>

int findodd(int a[], int sz  )
{
   if (a[sz-1]%2 ==0)
        return sz>0? findodd(a,sz-1) : 0;
    else
        return sz>0? 1+findodd(a,sz-1) : 0;

}

int findeven(int b[], int sz  )
{
    if (b[sz-1]%2 ==0)
        return sz>0? 1+findeven(b,sz-1) : 0;
    else
        return sz>0? findeven(b,sz-1) : 0;


}


int main()
{
    int a[]= {1,9,1,0,8,2,9}, sz= sizeof a/ sizeof *a;

    printf("even= %d\n",findeven(a,sz));
    printf("odd= %d\n",findodd(a,sz) );


}
