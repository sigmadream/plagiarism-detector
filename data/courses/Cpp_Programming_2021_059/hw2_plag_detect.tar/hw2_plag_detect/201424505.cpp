#include <cstdio>

int main(){
  int i,j,k,odd=0, even=0;
  int num[100] = {0};
  int len = sizeof(num) / sizeof(int);
  printf("숫자의 갯수 입력 : ");
  scanf("%d",&k);
  for(j=0;j<k;j++){
  scanf("%d",&num[j]);
  }
  for(i=0;i<k ;i++ ){
    if(num[i] % 2 == 1){
      odd = odd+1;}
      else{
        even = even + 1;
      }
}
printf("%d %d",odd,even);

return 0;

}
