//  main.cpp
//  walk
//  Created by 강동기 on 2021/03/17.

#include <iostream>
#include <stdio.h>

//int graph(int getNum[], int sz) {
//
//
//
//}

 
int main() {
    
    int getNum[100];
    for(int i=0; i<100; i++) {
        scanf("%d", &getNum[i]);
        if (getNum[i] < 0) {
            break;
        }
    }
    
    printf("%d\n", getNum);
}
