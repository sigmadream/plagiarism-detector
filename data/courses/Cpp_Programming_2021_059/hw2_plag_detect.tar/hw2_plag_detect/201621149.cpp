#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>

void moving(int a[], int sz) {
	int xy[2] = { 0 };
	for (int i = 0; i < sz; i++) {
		++xy[a[i] % 2];
	}
	printf("%d %d", xy[0], xy[1]);
}


int main(void) {
	int n, sz = 0;
	int a[1000];
	do {
		scanf("%d", &n);
		a[sz++] = n;
	} while (getc(stdin) == ' ');

	moving(a, sz);
	return 0;

}