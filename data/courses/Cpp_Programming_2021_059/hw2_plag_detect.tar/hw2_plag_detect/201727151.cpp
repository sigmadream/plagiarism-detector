#include <cstdio>

int chkEven(int a[], int sz, int ecnt) {
    
    if (a[sz]/2==0) {
        ecnt++;
        chkEven(a,sz-1,ecnt);
    }
    else if (a[sz]/2 !=0)
        chkEven(a,sz-1,ecnt);
    
    if (sz=0)
        return ecnt;
    
    
}

const int Max = 20;

int main() {
    int a, x[Max], i=0;
    while (scanf("%d", &a)==1) {
        x[i++] = a;
        if (i>=Max) break;
    }
    int ecnt = 0;
    int sz = sizeof x/sizeof *x;
    int evenNum = chkEven(x,sz,ecnt);
    printf("%d %d\n", evenNum,sz-evenNum);



    return 0;
}