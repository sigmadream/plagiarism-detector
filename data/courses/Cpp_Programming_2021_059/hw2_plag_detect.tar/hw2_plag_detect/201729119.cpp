#include <cstdio>

int x_value = 0, y_value = 0;

void cal_point(int a[], int n, int sz){
	
	if(n == (sz-1)) return;
	if(a[n]%2==0) x_value = x_value + 1;
	else y_value = y_value + 1;
	
	cal_point(a, n+1, sz);
	
}


int main(){
	
	int a[] = {1, 9, 1, 0, 8, 2, 9};
	int i = 0, sz = sizeof a / sizeof *a;
	
	printf("%d\n", sizeof a / sizeof *a);
	
	cal_point(a, i, sz);
	
	printf("%d %d", x_value, y_value);
	
}

