#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int i = 0;

int get_nums(int *arr){
    
}
int main()
{
    int n;
    int arr[100];
    int x = 0, y =0;
    for(int j = 0; j < 100; j++){
        arr[j] = -1;
    }
    
    while (scanf("%d", &n) != EOF){
        if(arr[i] != ' '){
            arr[i] = n;
            i++;
        }
    }
    i = 0;
    while(arr[i] != -1){
        if(arr[i] % 2 == 1)
            ++x;
        else ++y;
        i++;
    }
    printf("%d %d", x, y);

}