#include <iostream>
using namespace std;
int n, arr[105], cnt;
int walk_x(int cur) {
	if (cur == cnt) return 0;
	return walk_x(cur + 1) + (arr[cur] % 2 == 0);
}
int walk_y(int cur) {
	if (cur == cnt) return 0;
	return walk_y(cur + 1) + (arr[cur] % 2 == 1);
}
int main() {
	while (cin >> arr[++cnt]) {}
	cout << walk_x(1) << " " << walk_y(1);
}