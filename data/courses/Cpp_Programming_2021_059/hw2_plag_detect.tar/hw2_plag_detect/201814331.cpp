//201814331 Haemin Lee 
#include <cstdio>

int odd = 0, even = 0;

void oddeven(int num)
{
	if (num % 2 == 1)
	{
		odd++;
	}
	else
		even++;	
		
}

int main()
{
	int i = 0;
	int a[1000];
	
	while(1)
	{
		if (scanf("%d", &a[i]) == 1 && a[i] >= 0)
		{
			oddeven(a[i]);
			
			i++;
		}
		else
			break;

	}	
	
	printf("%d %d", even, odd);

}
