#include<cstdio>

#define INT_MAX 100
#define LEN_MAX 200

int getLocation1(int *arr,int sz);


int main()
{
    char str[LEN_MAX];
    int num_list[INT_MAX];

    int count=0,num=0,i;

    fgets(str,sizeof str,stdin);

    for(i=0;count<INT_MAX &&str[i];i++){
        if(str[i]!=' '){

            num=num*10+str[i]-'0';

        }else{

        if(num>=0) {
            num_list[count++]=num;
            num=0;
            }

        }

    }
    if(num>=0) num_list[count++]=num;

    printf("%d %d",getLocation1(num_list,count),count-getLocation1(num_list,count));


}

int getLocation1(int *arr,int sz)
{
    if(sz==1)
    {
        if(arr[0]%2==0) return 1;
        else return 0;
    }

    if(sz>0&&arr[sz-1]%2==0){
        return getLocation1(arr,sz-1)+1;
    }else return getLocation1(arr,sz-1);

}



