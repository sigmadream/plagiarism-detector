#include <cstdio>

int num_odd(int a[], int sz)
{
	if(sz == 0)
		return 0;
	else if(a[sz-1] % 2 == 1)
		return 1 + num_odd(a, sz-1);
	else
		return num_odd(a, sz-1);
}

int num_even(int a[], int sz)
{
	if(sz == 0)
		return 0;
	else if(a[sz-1] % 2 == 0)
		return 1 + num_even(a, sz-1);
	else
		return num_even(a, sz-1);
}

int main()
{
	int a[100] = {};
	int sz = 0;
	int i;
	
	for(i=0; i<100; i++)
	{
		int j = scanf("%d", &a[i]);
		if(j == 0)
			break;
		sz++;
	}
	
	int x = num_even(a, sz);
	int y = num_odd(a, sz);
	
	printf("%d %d", x, y);
}
