#include <cstdio>
int main() {

  int arr[10];
  for(int i=0;i<10;i++){
    scanf("%1d",&arr[i]); 
  }
  int x=0;
  int y=0;
  for(int i=0;i<10;i++){
    if (arr[i]%2==0)
    	x=x+1;
    else
    	y=y+1;
  }
	printf("%d %d",x,y);
	return 0;
}
