#include <cstdio>

int move;
int x,y = 0;
int main(){
    int a[100];
    while()
    scanf("%d", &a[i]);
    move()
    printf("%d %d",x,y);
}

int move(int *a, int n)
{
    if(n == 0) return 0;
    else
        if(*(a+i)%2 == 0){
                x+=1;
            }
            else{
                y+=1;
        }
        return move(n-1);
}
