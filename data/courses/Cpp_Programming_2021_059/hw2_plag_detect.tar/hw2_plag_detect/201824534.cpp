#include <cstdio>

int deo(int a[], int sz,int eo[]) {
    eo[0]=0;
    eo[1]=0;
    if(a[sz]%2==0)
        eo[0] = eo[0]+1;
    else
        eo[1] = eo[1]+1;
    return sz > 0 ? deo(a,sz-1,eo) : 0;
    
}

int main() {
    int INT_MAX = 100;
    int r[2];
    int a[INT_MAX];
    for(int i=0;i<INT_MAX;i++) {
        scanf("%p\n", a[i]);
    }
    deo(a,INT_MAX,r);
    printf("%d%d\n", r[0],r[1]);
}