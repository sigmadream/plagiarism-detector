#include <cstdio>

void location_calculate(int arr[], int arrIdx, int xPos, int yPos)
{
	if (arrIdx < 0)
	{
		printf("%d %d\n", xPos, yPos);
		return;
	}

	if (arr[arrIdx] % 2 == 0)
	{
		xPos++;
	}
	else
	{
		yPos++;
	}

	location_calculate(arr, arrIdx - 1, xPos, yPos);
}

int main()
{
	int a[101] = { 0 };
	int count = 0;

	while (scanf("%d", (a + count)) != EOF)
	{
		count++;
	}

	location_calculate(a, count - 1, 0, 0);
}