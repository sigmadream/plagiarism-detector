#include <cstdio>


int main()
{
    int a[7];
    for(int i=0; i<7; i++)
    {
        scanf("%d", &a[i]);
    }
    int x=0;
    int y=0;
    for(int j=0; j<7; j++){
        if(a[j]%2 == 0){        
            x=x+1;
        }
        else{
            y=y+1;
        }
    }
    printf("%d    %d",x,y);
}