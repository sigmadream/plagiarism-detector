#include <cstdio>
const int MAX = 1000;

void findCartesian(int *a, int index, int max, int *coordinate)
{
    if (index == max)
    {
        return;
    }
    if (a[index] % 2 == 0)
    {
        coordinate[0] += 1;
    }
    else
    {
        coordinate[1] += 1;
    }
    findCartesian(a,index+1,max,coordinate);
}

int main()
{
    int num,i;
    int a[MAX];
    i = 0;
    while (scanf("%d", &num) == 1)
    {
        a[i++] = num;
    }
    int coordinate[2] = {0,0};
    findCartesian(a, 0, i, coordinate);
    printf("%d %d", coordinate[0], coordinate[1]);
}