#include <cstdio>

const int INT_MAX = 100;

void allocate_location(int *given_array, int pos, int sz, int *location)
{
    if(pos != sz) {
        given_array[pos] % 2 == 0 ? location[0] += 1 : location[1] += 1;
        allocate_location(given_array, pos+1, sz, location);
    }
}

int main()
{
    int a[INT_MAX];

    int num;
    int i = 0;

    while(scanf("%d", &num) == 1){
        a[i++] = num;
    }

    int location[2] = {0, 0}; // origin

    allocate_location(a, 0, i, location);
    printf("%d %d", *location, *(location+1));

    return 0;
}