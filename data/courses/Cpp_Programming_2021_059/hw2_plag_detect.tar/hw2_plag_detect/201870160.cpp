#include <iostream>
#include <cmath>
using namespace std;
int main(){
    int i = 0;
    int a;
    int arr[1000];
    while(cin>>a){
        arr[i] = a;
        if(cin.get()=='\n'){
            break;
        }
        i++;

    }
    int odd = 0;
    int even = 0;

    for (int j = 0;j < i+1; j++){
        if(arr[j] %2 == 1){
            odd++;
        }else{
            even++;
        }
    }
    cout<<even<<" "<<odd<<endl;

    return 0;
}
