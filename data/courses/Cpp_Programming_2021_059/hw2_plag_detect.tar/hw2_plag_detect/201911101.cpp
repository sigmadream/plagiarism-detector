#include <cstdio>

void scan_num(int *num, int sz) {
    if(sz!=0) {
        scanf("%d",num + sz - 1);
        return scan_num(num, sz-1);
    }
    else return;
}

void motivation(int x, int y,int *num,int sz) {
    if(num[sz-1]%2==0 && sz>0) {
        x+=1;   
        return motivation(x,y,num,sz-1);
    }
    else if (num[sz-1]%2==1 && sz>0) {
        y+=1;
        return motivation(x,y,num,sz-1);
    }

    else {
        printf("%d %d",x,y);
        return;
    }
}

int main() {
    int sz;
    scanf("%d",&sz);

    int num[sz];
    scan_num(num,sz);
    
    int x = 0;
    int y = 0;
    motivation(x,y,num,sz);

    return 0;
}