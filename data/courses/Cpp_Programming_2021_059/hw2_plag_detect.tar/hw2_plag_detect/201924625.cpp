#include <cstdio>
#define INT_MAX 10000

int direction(int input) {
	return input % 2; //even -> 0
}

void scan_and_execute(int* ad_x, int* ad_y) {
	int input_value;
	if (scanf("%d", &input_value) == EOF) return;
	if (direction(input_value)) (*ad_y)++;
	else (*ad_x)++;
	scan_and_execute(ad_x, ad_y);
}
int main() {
	int x = 0, y = 0;
	int* ad_x = &x, * ad_y = &y;
	scan_and_execute(ad_x, ad_y);
	printf("%d %d", *ad_x, *ad_y);
	return 0;
}
