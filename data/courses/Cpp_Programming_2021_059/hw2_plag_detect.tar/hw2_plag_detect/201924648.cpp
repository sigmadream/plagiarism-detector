#include <iostream>
#include <cstdio>

using namespace std;


void find_point(int * arr,int size)
{
  int x=0,y=0;
     for(int i=0;i<size;i++)
     {
          if(arr[i]%2==0)
          {
               x++;
          }
          else{
               y++;
          }
     }

     cout<<x<<" "<<y<<endl;


}
int main()
{
     int num;
     int i=0;

     int arr[10000];
    while(scanf("%d",&num)==1)
    {
        arr[i++]=num;
    }

   
   find_point(arr,i);
    
}