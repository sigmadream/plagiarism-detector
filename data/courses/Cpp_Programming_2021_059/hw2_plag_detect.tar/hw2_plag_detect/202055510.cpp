#include <cstdio>

int count_arr[2] = {0,0};

void counting_xy(int * arr, int len){
	if(len == 0)	return;
	else{
		if(arr[len-1] % 2 == 0) count_arr[0]++;
		else	count_arr[1]++;
		counting_xy(arr, len-1);
	}
}

int main(){
	int sz = 0;
	int num_arr[100] = {};
	
	while(scanf("%d", &num_arr[sz]) == 1)	sz++;
	
	counting_xy(num_arr, sz);
	
	printf("%d %d\n", count_arr[0], count_arr[1]);
}
