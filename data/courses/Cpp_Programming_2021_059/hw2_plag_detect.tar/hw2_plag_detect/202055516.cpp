#include <cstdio>

const int INT_INPUT  = 1000;
const int INT_MAX = 100;

int walk(int *arr, int sz, int *path)
{
    if (sz == 0 ) return 0;
    if(*(arr + sz -1)%2 ==0) {
        path[0]+=1;
        sz = sz -1;
        walk(arr, sz, path);
    }
    else if(*(arr + sz -1)%2 ==1) {
        path[1]+=1;
        sz = sz -1;
        walk(arr, sz, path);
    }
}
int main() {
    int num, arr_walk[INT_INPUT], i =0;
    while(scanf("%d", &num) ==1) {
        if(num <= INT_MAX) {
            arr_walk[i++] = num;
        }
    }
      int path[2] = {0, };
      walk(arr_walk, i, path);
      printf("%d %d", path[0], path[1]);
    }



