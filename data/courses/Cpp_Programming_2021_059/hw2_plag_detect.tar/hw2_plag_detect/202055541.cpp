#include <cstdio>


int holjjak (int a)
{
	if (a % 2 == 0) {
		
		return 1;
		// 1�� ¦��
	}
	else {
	
		return 0;
		// 0�� Ȧ��
	}

}



int main() {
	int hol = 0;
	int jjak = 0;
	

	int x, num[1000] , i=0;
	while (scanf("%d", &x) != EOF) {
		num[i++] = x;
		
	}


	for (int j = 0; j < i; j++) {
		if (holjjak(num[j]) == 1) {
			hol += 1;
		}
		else {
			jjak += 1;
		}
	}



	printf("%d %d", hol , jjak);
	return 0;
}