#include <cstdio>
const int INT_MAX = 1000;

int main() {
    int x = 0 ;
    int y = 0 ;
    int n, a[INT_MAX], i = 0;
    while (scanf("%d", &n)==1) {
        a[i++] = n;
        if (i >= INT_MAX) break;
    }
    for (int l = 0; l < i; l++) {
        if (a[l] % 2 == 0) {
            x++;
        }
        else if ((a[l] % 2 == 1)){
            y++;
        }
    }
    printf("%d %d", x, y);
}