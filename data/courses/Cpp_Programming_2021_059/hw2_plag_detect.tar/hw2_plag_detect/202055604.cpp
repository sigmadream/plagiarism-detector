#include <cstdio>
int convert_input(int K[],char string[200])
{
int j=0,i=0,temp=0;
while(string[i]!='\0')
{
    temp=0;
    while(string[i]!=' ' && string[i]!='\0')
        temp=temp*10 + (string[i++]-'0') ;
    if(string[i]==' ')
        i++;
    K[j++]=temp;
}
return j-1;
}

int even_odd(int a){
    if(a%2 == 0){
        return (0);
    }
    if(a%2 == 1){

        return (1);
    }

}

int main()
{
char string[200];
int g,a,i,G[20],A[20],met;
int x = 0;
int y = 0;

gets(string);
g=convert_input(G,string);

for(i=0;i<=g;i++)
    ///printf("\n%d",even_odd(G[i]));
    if(even_odd(G[i]) ==0 ){
        x = x + 1;
    }
    else y = y + 1;

printf("%d %d",x,y);
return 0;
}


