#include <cstdio>
#include <string.h>

int main()
{
    int i;
    int x=0, y=0;
    char str[100];
    scanf("%[^\n]", str);
    for(i=0;i<strlen(str);i++){
        if(str[i]==' '){
            if(((str[i-1])-'0')%2==1)
                y+=1;
            else
                x+=1;
        }
    }
    if(((str[i-1])-'0')%2==1)
        y+=1;
    else
        x+=1;
    printf("%d %d",x,y);
    return 0;
}
