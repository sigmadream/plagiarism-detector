#include<cstdio>

const int MaxElements = 100;

void walking(int x, int y,int num[], int i, int inp_sz)
{
    if (i == inp_sz)
    {
        printf("%d %d", x, y);
    }else{
        if (num[i] % 2 == 0)
        {
            x++;
        }else{
            y++;
        }
        i++;
        walking(x, y, num, i, inp_sz);
    }
}

int main()
{
    int inp_sz = 0;
    int num[MaxElements];
    while(1){
        scanf("%d", &num[inp_sz]);
        if (feof(stdin))
        {
            break;
        }
        inp_sz++;
    }
    walking(0, 0, num, 0, inp_sz);
}