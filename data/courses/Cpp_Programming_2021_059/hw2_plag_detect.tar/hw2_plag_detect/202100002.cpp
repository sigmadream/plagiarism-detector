#include <cstdio>

struct Point {
private:
    int _x, _y;
public:
    Point() {
        _x = _y = 0;
    }
    void Print() {
        printf("%d %d\n", _x, _y);
    }
    void Move(int n) {
        (n % 2 == 0? _x: _y) += 1;
    }
};

int main() {
    Point p;
    int n;
    while (scanf("%d", &n) == 1)
        p.Move(n);
    p.Print();
}
