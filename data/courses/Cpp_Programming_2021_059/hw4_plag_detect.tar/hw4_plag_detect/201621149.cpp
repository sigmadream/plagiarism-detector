#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>
#include <vector>

class IntBag
{
private:
	std::vector<int> _vec;
	int _cnt;
	void returnvector() { 
		int _sz = _vec.size();
		for (int i = 0; i < _vec.size(); i++) {
			if (i < _sz) {
				printf("%d ", _vec[i]);
			}
			else {
				printf("%d", _vec[i]);
			}
		}
	};
	void Add(int _val) {
		_vec.push_back(_val);
	}
	void Extend(int _cnt) {
		if (_cnt <= 0) {
			return;
		}
		int _sz = _vec.size();
		Add(_vec.back());
		
		for (int i = _sz - 1; i > 0; i--) {
			_vec[i] += _vec[i-1];
			_vec[i] %= 100;
		}
		Extend(--_cnt);
	}
public:
	IntBag(std::vector<int>& b) {
		_vec = b;
	}
	void myfunc(int _cnt) {
		Extend(_cnt);
		returnvector();
	}

};

int main() {
	int n, cnt = 0;
	std::vector<int> v;
	scanf("%d\n", &cnt);
	do {
		scanf("%d", &n);
		v.push_back(n);
	} while (getc(stdin) == ' ');

	IntBag mybag = IntBag(v);
	mybag.myfunc(cnt);

	return 0;
}