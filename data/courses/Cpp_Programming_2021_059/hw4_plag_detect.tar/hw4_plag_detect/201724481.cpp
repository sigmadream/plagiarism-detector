#include <stdio.h>


int main(){
    int m,i,n,j=0,k,a[1000];
    scanf("%d", &m);
    while (scanf("%d", &n)==1){
    	if(n<100){
        a[i] = n;
        i++;
     	}
     	else
     	return 0;
    }
    if (i==1){
    	a[1] = a[0];
    	i=2;
    	m--;
	}
    for (k=1;k<=m;k++){
    	a[k+1] = a[k];
        for (i=k;i>=1;i--){
            int A = a[i-1] + a[i];
            a[i] = A%100;
        }
    }
    while (a[j]<100 && 0<a[j]){
			
    	printf("%d ", a[j]);
    	j++;
	}	
}	
