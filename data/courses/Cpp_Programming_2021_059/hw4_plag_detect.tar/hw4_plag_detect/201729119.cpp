#include <cstdio>
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
 
using namespace std;
 
class IntBag {
	vector<int> vec;
	int size, m;
	
public:
	
	IntBag(string str) {
        istringstream iss(str);
       
    	int input;
    	while(iss >> input) {
        	vec.push_back(input);
    	}  
	}
	void extend(int m) {
   		int size = vec.size();
   		int j = 0;
    	while(j < m) {
       		vec.push_back(vec[size-1]);
        	for(int i=size-1; i>0; i--) {
           	vec[i] = (vec[i] + vec[i-1])%100;
            }
            size = vec.size();
            j++;
    	}
    	for(int i=0;i<size;i++) printf("%d ", vec[i]);
	}

};
 
int main(void)
{
	string str;
	int m;
   
	scanf("%d", &m);
	fflush(stdin);
   
	getline(cin, str);

	IntBag intBag(str);   
	intBag.extend(m);
 
	return 0;   
}
