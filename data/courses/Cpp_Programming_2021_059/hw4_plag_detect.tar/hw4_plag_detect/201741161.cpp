#include <cstdio>
#include <iostream>
#include <vector>

using namespace std;
int num;

class IntBag{
    vector<int> v;
    int arr[101];
public:
    IntBag(){
    	int i = 0, n = 0;
    	for(int k = 0; k < 101; k++)
    		arr[k] = 0;
        while (scanf("%d", &n) != EOF){
            arr[i] = n;
            i++;
        }
    }
    void add(){
    	int i = 0;
    	while(arr[i]){
            v.push_back(arr[i]);
            i++;
        }
	}
    void extend(int x){
        vector<int> tmp;
        for(int j = 0; j < x; j++){
            if(v.size() == 1){
                v.push_back(v[0]);
                continue;
            }
            else if(v.size() == 2){
                v.insert(v.begin() + 1, (v[0] + v[1]) % 100);
                continue;
            }
            for(int k = 0; k < v.size() - 1; k++)
                tmp.push_back((v[k] + v[k+1]) % 100);
            v.erase(v.begin() + 1, v.end() - 1);
            for(int idx = 0; idx < tmp.size(); idx++)
                v.insert(v.begin() + idx + 1, tmp[idx]);
            tmp.clear();
        }
    }
    void print_vector(){
        for(int j = 0; j < v.size(); j++)
            printf("%d ", v[j]);
    }
};

int main()
{
    cin >> num;
    IntBag a;
    a.add();
    a.extend(num);
    a.print_vector();
}
