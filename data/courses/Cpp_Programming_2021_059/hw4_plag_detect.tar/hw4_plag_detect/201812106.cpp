#include <iostream>
#include <vector>
using namespace std;
class IntBag {
private:
	vector<int> item;
public:
	void Extend() {
		Add(item[size() - 1]);
		for (int i = size() - 2; i >= 1; i--) {
			item[i] = (item[i-1] + item[i]) % 100;
		}
	}
	void Add(int x) {
		item.push_back(x);
	}
	int size() {
		return item.size();
	}
	int getitem(int x) {
		return item[x];
	}
};
int main() {
	int x, m;
	IntBag Bag;

	cin >> m;

	while (cin >> x) {
		Bag.Add(x);
	}

	while (m--) {
		Bag.Extend();
	}

	for (int i = 0; i < Bag.size(); i++) {
		cout << Bag.getitem(i) << " ";
	}
}