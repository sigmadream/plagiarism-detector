#include<vector>
#include<cstring>
#include<cstdio>

#define INT_MAX 1000
#define LEN_MAX 200

using namespace std;

vector<int> get_number();

class intBag
{
    vector<int> Arr;
    int arrSize;
public:
     intBag(vector<int> arr,int sz)
    {
        for(int i=0;i<sz;i++)
        {
            Arr.push_back(arr[i]);
        }
        arrSize=sz;
    }
    void Extend(int n)
    {

        int i;
        for(int j=0;j<n;j++)
        {
            if(arrSize==1) Arr.push_back(Arr[0]);
            else
            {
                auto tmp=Arr[0];
                for(i=1;i<arrSize;i++)
                {
                    Arr[i]=Arr[i]+tmp;
                    tmp=Arr[i]-tmp;
                    Arr[i]=Arr[i]%100;
                }
                Arr[i]=tmp;
            }
            arrSize++;
        }
     for(int k=0;k<arrSize;k++) printf("%d ",Arr[k]);
    }
};

int main(void)
{
    int timecount=0;//�� �� �ݺ�?
    scanf("%d\n",&timecount);//\n�־����,,,,

    vector<int> nonRedusedArr = get_number();
    intBag a(nonRedusedArr,nonRedusedArr.size());

    a.Extend(timecount);
}

vector<int> get_number()
{
    char str[LEN_MAX];
    vector<int> numArr;
    int num=0;

    fgets(str,LEN_MAX,stdin);
    str[strlen(str)-1]='\0';


    for(int i=0;str[i];i++)
    {

        if(str[i]!=' ') num=num*10+str[i]-'0';
        else
        {
            if(num>0)
            {
                numArr.push_back(num);
                num=0;
            }
        }
    }

    if(num>=0) numArr.push_back(num);


    return numArr;
}

