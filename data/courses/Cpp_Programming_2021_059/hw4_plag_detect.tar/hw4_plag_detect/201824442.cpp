#include <cstdio>
#include <vector>

class IntBag{
public:
    std::vector<int> v;
    void Putnum(int n)
    {
        v.push_back(n);
    }
    std::vector<int> Add(std::vector<int> v, int i, int temp)
    {
        v.resize(i+1);
        v[i] = temp;
        return v;
    }
    std::vector<int> Extend(std::vector<int> v, int n)
    {
        for(int i = 0; i < n; i++)
        {
            int temp = v.back();
            for(int j = v.size() -1; j > 0; j--)
            {
                v[j] = (v[j] + v[j-1]) % 100;
            }
            v = Add(v, v.size(), temp);
        }
        return v;
    }
}IntBag;

int main()
{
    std::vector<int> result;
    int Ext_num;
    int temp;

    scanf("%d", &Ext_num);

    while(scanf("%d", &temp) == 1)
        IntBag.Putnum(temp);

    result = IntBag.Extend(IntBag.v, Ext_num);

    for(int i = 0; i < result.size(); i++)
        printf("%d ", result[i]);
}
