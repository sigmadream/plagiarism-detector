#include <cstdio>

int main(){
	int a[100], b, i, j, n, m;
	scanf("%d/n", &i);
	scanf("%d %d", &n, &m);
	a[0]=n;
	if(m<=0)
	b=n, a[1]=n, j=i+1;
	else
	b=m, a[1]=m, j=i+2;
	int o=j/2+1;
	for(int l=0; l<i; l++){
		a[l+2]=a[l+1];
		a[l+1]=a[l]+a[l+2];
	}
	for(int p=1; p<o; p++)
	a[p]+=p*n;
	for(int q=j-2; q>o-2; q--)
	a[q]+=(j-q-2)*b;
	a[j-1]=b;
	a[1]+=n;
	for(int k=0;k<j;k++)
	printf("%d ", a[k]%100);
	return 0;
}
