#include <cstdio>

int main() {
   int n,m,i=0;
   scanf("%d",&m);
   int a[100];
   int b[100];
   while(scanf("%d", &n)==1){
   a[i]=n;
   i++;
   }
   b[0]=a[0];
   int k,j,x,l=0;
   for(k=1; k<=m; k++){
      for(j=1; j<i+k-1; j++){
         b[j]=a[j]+a[j-1];
      }
      b[i+k-1]=a[i+k-2];
      for(x=0; x<j+1; x++){
         a[x]=b[x];
         
      }
   }
   
   for(l=0; l<m+i; l++){
      printf("%d ",b[l]);
   }
   
   return 0;
}
