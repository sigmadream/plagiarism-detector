#include <cstdio>
#include <vector>
#define INT__MAX 1000
using namespace std;

int n;

class IntBag {
private:
    int arr[INT__MAX][INT__MAX];
public:
    vector<int> v;
    void set_arr (int num, int index);
    void solution (int index);
    void printSolution(int index);
};

void IntBag:: set_arr(int num, int index) {
    arr[0][index] = num;
}

void IntBag:: solution(int index) {
    for (int w =0; w < n;w++) {
        if (w == 0 && index == 1) {
            arr[w+1][0] = arr[w][0];
            arr[w+1][1] = arr[w][0];
        }
        for (int z=0; z<index-1+w;z++) {
            if (z == 0) 
                arr[w+1][z] = arr[w][z];
            arr[w+1][z+1] = (arr[w][z] + arr[w][z+1]) % 100;
            if (z == index+w-2) 
                arr[w+1][z+2] = arr[w][z+1];
        }
    }
    for (int z = 0; z < index + n; z++) 
        v.push_back(arr[n][z]);
}

void IntBag:: printSolution(int index) {
    for (int z = 0; z < index + n; z++) 
        printf("%d ", v[z]);
}


int main() {
    char ch[INT__MAX];
    int k=0,i=0;
    scanf("%d",&n);
    getchar();
    IntBag getSol;
    while (true) {
        scanf("%c",&ch[k]);
        if (ch[k++] == '\n')
            break;
    }
    for(int z= 0;z<k-1;z++) {
        int num = 0,isspace=0;
        while (ch[z] != ' ' && ch[z] != '\n') {
            isspace += 1;
            num *= 10;
            num +=(ch[z++]-'0');
        }
        
        if (isspace != 0)
            getSol.set_arr(num,i++);
    }
    
    getSol.solution(i);
    getSol.printSolution(i);
}



