#include <cstdio>
#include <vector>

class IntBag{

    private:

    std::vector<int> v;
    
    public:

    void Input(int n){
        v.push_back(n);
    }

    void Extend(){
        v.push_back(v[v.size()-1]);
    }

    void Add(){

        for(int i=v.size()-2;i>0;i--)
            (v[i-1]+v[i])>=100 ?v[i]=(v[i-1]+v[i])%100:v[i]=v[i-1]+v[i];
            
        }

    void Print(){
        for(int i=0;i<v.size();i++)
            printf("%d ", v[i]);
    }

};

int main(){

    IntBag p;
    int n;
    int count;
    scanf("%d", &count);
    while(scanf("%d", &n)==1)
        p.Input(n);
    for(int i=0;i<count;i++){
        p.Extend();
        p.Add();
    }
    p.Print();

}
