#include <cstdio>
#include <vector>

class IntBag{
private:
    std::vector<int> v;
public:
    void Input(int n){
        v.push_back(n);
    }
    void Add(){
        int sz= v.size();
        int i;
        for(i = sz-2; i > 0 ; i--){
            v[i] = v[i]+v[i-1];
            if (v[i] >= 100)
                v[i] = v[i] % 100;
        }     
    }
    void Extend(){
        int sz = v.size();
        v.push_back(v[sz-1]);
    }
    void Print(){
       for (int i = 0; i < v.size(); i++)
        printf("%d ", v[i]);
    }
};

int main(){
    IntBag a;
    int n;
    int loop;

    scanf("%d", &loop);
    while (scanf("%d", &n) == 1) {
        a.Input(n);
        }
    
    for(n=0; n <loop; n++){
        a.Extend();
        a.Add();
    }
    
    a.Print();
}
