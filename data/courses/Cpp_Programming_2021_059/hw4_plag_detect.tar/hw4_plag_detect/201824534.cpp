#include <cstdio>

const int INT_MAX = 1000;

int main() {
    int a[INT_MAX];
    int m,n,r,i=0;
    scanf("%d", &m);
    while(scanf("%d",&n)==1){
        a[i++] = n;
    }

    int b[INT_MAX];
    int k;
    int sz = i;

    for(int y=0;y<m;y++){
        for(int j=0;j<sz;j++){
        b[j] = a[j];
        }
        for(k=0;k<=sz;k++){
            if(k==0)
                a[k]=b[k]%100;
            else if(k==sz)
                a[k]=b[k-1]%100;
            else if(k>0&&k<sz)
                a[k]=(b[k-1]+b[k])%100;
        }
        sz=sz+1;
    }

    for(int l =0;l<sz;l++)
        printf("%d ",a[l]);
}