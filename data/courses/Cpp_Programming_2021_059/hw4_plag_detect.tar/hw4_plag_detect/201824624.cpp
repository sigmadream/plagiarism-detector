#include <cstdio>
#include <vector>
using namespace std;

class IntBag {
    private:
        vector <int> nums;
        int first;

    public:
        void Initialize(int *arr, int sz)
        {
            for (int i = 0; i < sz; i++)
                this->nums.push_back(arr[i]);
            
            this->first = arr[0];
        }

        void Add() // insert first element in the beginning of the array
        {
            this->nums.insert(nums.begin(), this->first);
        }

        void Extend()
        {
            if(this->nums.size() == 1) 
            {
                this->Add();
            }
            else 
            {
                int i = 0;
                while(nums.size() - 1 != i)
                    this->nums[i++] = (nums[i] + this->nums[i + 1]) % 100;

                this->Add();
            }
        }

        void Printing()
        {
            for (int i = 0; i < this->nums.size(); i++)
                printf("%d ", this->nums[i]);

        }
};

int main()
{
    int ext, arr[1000], i = 0;
    IntBag Arr;

    scanf("%d", &ext);

    int num;
    while(scanf("%d", &num) == 1)
        arr[i++] = num;

    Arr.Initialize(arr, i);
    for (int j = 0; j < ext; j++)
        Arr.Extend();

    Arr.Printing();
    return 0;
}
