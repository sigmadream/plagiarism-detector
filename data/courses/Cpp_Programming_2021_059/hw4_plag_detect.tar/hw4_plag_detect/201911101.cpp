#include <cstdio>
#include <vector>

class IntBag {
    private:
        std::vector<int> v;
    public:
        IntBag() {
            int n;
            while (scanf("%d", &n)==1) v.push_back(n);
        }
        int Add(int i) {
            return (i == v.size()-1? v[i] : (v[i]+v[i+1])%100);
        }
        void Extend(int m) {
            for(int j=1;j<=m;j++){
                std::vector<int> u={v[0]};
                for(int i=0;i<v.size();i++) u.push_back(IntBag::Add(i));
                v = u;
            }
            return;
        }
        void print() {
            for (int n:v) printf("%d ", n);
        }
};

int main() {
    int m;
    scanf("%d",&m);
    IntBag v;
    v.Extend(m);
    v.print();
    return 0;
}