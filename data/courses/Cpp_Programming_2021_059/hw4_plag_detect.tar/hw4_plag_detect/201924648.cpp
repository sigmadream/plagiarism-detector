#include <iostream>
#include <string>
#include <vector>

using namespace std;

class IntBag
{
    public:
    IntBag(const string & str)  //문자열로 vec를 받는 생성자
    {
        string temp="";
        for(const char ch:str)
        {
            if(ch>='0' && ch<='9')
            {
                temp+=ch;
            }
            else
            {
                vec.push_back(stoi(temp));
                temp.clear();
            }
        }

        if(temp.size()!=0)
        {
            vec.push_back(stoi(temp));
        }
    }
    void Add(int num)
    {
        vec.push_back(num);
    }
    void Extend(int m)
    {
        if(vec.size()==1)
        {
            vec.push_back(vec[0]);
            m--;  //한번 복제하는데 m을 소비
        }

        for(int i=0;i<m;i++)
        {
            int left = vec[0];
            int right =  vec[1];
            int end = vec.back();
            for(int i=0;i<vec.size()-1;i++)
            {
                int num =left + right;
                num = num % 100;
                
                left = vec[i+1];
                right = vec[i+2];
                vec[i+1]=num;
            }
           vec.push_back(end);
        }
    }
    void print()
    {
        for(int i:vec)
        {
            cout<<i<<" ";
        }
    }
    private:
    vector<int> vec;
};

int main()
{
    int m;
    string str;
    cin>>m;
    cin.ignore(256,'\n');

    getline(cin,str);

    IntBag A(str);
    A.Extend(m);
    A.print();

}