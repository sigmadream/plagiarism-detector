#include <cstdio>
#include <vector>

class IntBag{
	private:
		std::vector<int> v;
		
	public:
		IntBag(int arr[1000], int i){
			for(int idx = 0; idx < i; idx++)	v.push_back(arr[idx]);
		}
		void Extend(int t){
			while(t > 0){
				if(v.size() == 1)	this->Add(v[0]);
				else{
					this->Add(v[v.size()-1]);
					for(int i = v.size()-2; i > 0; i--){
						v[i] = (v[i] + v[i-1]) % 100;
					}
				}
				t--;
			}
			for(int n : v)	printf("%d ", n);
		}
		void Add(int val){
			v.resize(v.size()+1);
			v[v.size()-1] = val;
		}
};

int main(){
	int times = 0;
	scanf("%d", &times);
	int arr[1000];
	int i = 0;
	while(scanf("%d", &arr[i]) == 1)	i++;
	
	IntBag b(arr, i);
	b.Extend(times);
}
