#include <cstdio>
#include <vector>

const int MAX_SIZE=1000;
const int INT_MAX = 100;

class IntBag {
    public:
        std::vector<int> Extend(std::vector<int> v, int m) {
            if(m< 1) return v;
            else {
                v = Add(v);
                for(int i=v.size()-2;i > 0;i--) {
                    v[i] = (v[i-1] +v [i])%100;
                }
                if(v.size() >= 1000) return v;
                return Extend(v, m-1);
            }
        }

        std::vector<int> Add(std::vector<int> v) {
            v.push_back(v[v.size()-1]);
            return v;
        }

        void print(std::vector<int> v) {
            for(int i=0; i< v.size(); i++) {
                printf("%d ", v[i]);
            }
        }
};

int main() {
    IntBag intbag;
    int m, num;
    scanf("%d\n", &m);
    std::vector<int> v;
    while (scanf("%d", &num)==1) {
            if (num < INT_MAX)
                v.push_back(num);
    }
    v = intbag.Extend(v, m);
    intbag.print(v);

}
