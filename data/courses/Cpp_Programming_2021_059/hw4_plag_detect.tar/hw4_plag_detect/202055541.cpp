#include<stdio.h>
#include<string.h>

int mod(int a, int b) {
	return (a + b) % 100;
}



int main() {
	int time;
	int num;
	int  a[1000];
	int b[1000];
	int j = 1;
	int first = 1;


	scanf("%d ", &time);

	while (scanf("%d", &num) != EOF) {
		a[j++] = num;
	}
	
	int fin = j;
	int hi = j-1 + time;
	
	
	
	for (int k = 1; k <= time; k++) {
		
		a[fin] = 0;
		for (int i = 1; i <= j; i++) {
			
			b[i] = mod(a[i], a[i - 1]);
			
		}
		memcpy( a+2, b+2, 1000);
		fin = fin + 1;
		j = j + 1;


	}
	


	
		

	for (int i = 1; i <= hi; i++) {
		printf("%d ", a[i]);
		
	}


}

