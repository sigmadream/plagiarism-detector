#include <cstdio>
#include <vector>

class IntBag
{
	private: 
		std::vector<int> v;
	public:
		initial(int a[])
		{
			for (int i = 1; a[i] != 0 ; i++ )
			{
				if(a[i] == 111)
				{
					break;
				}
				add(a[i]);

			}
		}
		add(int number)
		{
			v.push_back(number);
		}
		extend()
		{
			int size = v.size();

			add(v[size-1]);
			int i = size-1;
			
			while(i >= 1)
			{
				v[i] = v[i] + v[i-1];
				i--; 
			}
		}
		result()
		{
			int i = 0;
			while(i < (v.size()))
			{
				printf("%d\n", v[i]);
				i++;
			}
		}		     
};

int main() 
{
	int array[1000];
	int i = 0;
	int read;
	
	while(scanf("%d", &read) == 1)
	{
		array[i] = read;
		i = i + 1;
	}
	
	
	IntBag bag;
	bag.initial(array);
	for(int m=0; m < array[0]; m++)
	{
		bag.extend();
	}
	bag.result();
}

