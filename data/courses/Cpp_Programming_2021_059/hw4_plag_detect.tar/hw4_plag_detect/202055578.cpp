#include <cstdio>
using namespace std;
const int MAX = 1000;

int main(){
	int sum= 0 ;
	int h, num = 0;
    int n, a[1000], i = 0;
    
	scanf("%d", &num);


    while (scanf("%d", &n)==1) {
        a[i++] = n;
        if (i >= 1000) break;
    }
    
 
	i = i-1;
	
//	printf("num : %d\n",num);
//	printf("i : %d\n",i);	
	if(i ==0 ) {
		a[i+1] = a[i];
		i++;
		num--;	
	}
	

	while( h < num){
		a[i+1] = a[i];	
//		printf("a[%d] : %d\t",i+1,a[i+1]);
		for(int k = i ; k > 0 ; k--){
		
//			printf("k:%d i:%d\t h:%d\t",k,i,h);
			a[k] = ( a[k] + a[k-1] ) % 100;
//			printf("a[%d] : %d\t",k,a[k]);
		}
//		printf("a[0] : %d\t",a[0]);
//		printf("\n");
		i++;
		h++;
		if (h == num) break;
	}
	
	for(int p = 0 ; p <= i ; p++){
		printf("%d ", a[p]);
	}
	

}
