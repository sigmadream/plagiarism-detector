#include <iostream>
#include <vector>
#include<cstdio>
class intbag
{
	public:
		intbag()
		{}
		~intbag()
		{}
		void AddInt(int num)
		{
			m_VectorOfInts.push_back(num);
		}
		void increase()
		{
		    saved.clear();
            int last = m_VectorOfInts[m_VectorOfInts.size()-1];
            int first = m_VectorOfInts[0];
            saved.push_back(first);
			for( unsigned int i = 0; i < m_VectorOfInts.size()-1; i++ )
			{
				saved.push_back( (m_VectorOfInts[i] + m_VectorOfInts[i+1])%100);
			}
			saved.push_back(last);
			m_VectorOfInts = saved;
		}


		void show(){
		    for(int j =0;j<saved.size();j++){
                printf("%d ",saved[j]);
		    }
		}

	private:
		std::vector<int> m_VectorOfInts;
		std::vector<int> saved;
};

int main()
{
	// Create our class an add a few ints
	intbag obj;
	int howmany;
	scanf("%d",&howmany);
	int getter;
    while(scanf("%d",&getter)!=EOF){
        obj.AddInt(getter);
    }
	// Display the vector contents so far
	for(int i=0;i<howmany;i++){
        obj.increase();
	}
	obj.show();

	return 0;
}
