#include<cstdio>
#include<vector>

using namespace std;

class IntBag
{
private:
    vector<int> v;
    int m;
public:
    void SetRange(int r) {
        m = r;
    }
    void Add(int n) {
        v.push_back(n);
    } 
    vector<int> Extend(int t, vector<int> curV) {
        if (t == m)
        {
            return curV;
        }else{
            vector<int> tmpV;
            if (curV.size() == 1)
            {
                tmpV.push_back(curV[0]);
                tmpV.push_back(curV[0]);
            }else{
                int flag = 1;
                tmpV.push_back(curV[0]);
                while(flag < curV.size()) {
                    tmpV.push_back((curV[flag-1]+curV[flag]) % 100);
                    flag++;
                }
                tmpV.push_back(curV.back());
            }
            t++;
            return Extend(t, tmpV);
        }
    }
    void PrintV() {
        vector<int> finalSequence = Extend(0,v);
        for (int n : finalSequence) {
            printf("%d ", n);
        }
    }
};

int main() {
    int m,n;
    IntBag myBag;
    scanf("%d",&m);
    myBag.SetRange(m);
    while(scanf("%d", &n) == 1) {
        myBag.Add(n);
    }
    myBag.PrintV();
}
