#include <cstdio>

int gcd(int a, int b){
    int tmp, n;

//a에 큰 값을 위치시키기 위한 조건문입니다.
    if(a<b){
        tmp = a;
        a = b;
        b = tmp;
    }
    while(b!=0){
        n = a%b;
        a = b;
        b = n;
    }
    return a;
}

 int main()
 {
 int a, b,n1,n2, res;
 scanf("%d %d", &a, &b);
 n1 = ((2*a)+b) * 7;
 n2 = ((4*a)+b) * 2;

 res = gcd(n1, n2);
 printf("%d",res);
 //printf("%d",res);

 }
