#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>

int GCD(int a, int b) {
	if (!(a % b)) return b;
	if (!(b % a)) return a;
	if (a > b) return GCD(b, a % b);
	return GCD(a, b % a);
}

class Nat {
	int num_a;
	int num_b;
private:
	Nat mulup(const Nat &m) {
		int a = (m.num_a * 2 + m.num_b) * 7;
		int b = (m.num_a * 4 + m.num_b) * 2;
		Nat k(a, b);
		return k;
	}
public:
	Nat(int a, int b) {
		num_a = a;
		num_b = b;
	}
	int show_GCD(Nat& m) {
		Nat k = m.mulup(m);
		return GCD(k.num_a, k.num_b);
	}
};

int main(void) {
	int a, b;
	scanf("%d%d", &a, &b);
	Nat m(a, b);
	printf("%d\n", m.show_GCD(m));
}