#include <cstdio>

class Nat{
    int t;
public:
    Nat(int n){
        t = n;
    }
    int GCD(int x, int y){
        int n1, n2;
        n1 = (x*2+y)*7;
        n2 = (x*4+y)*2;
        while(n2!=0){
            int temp = n1%n2;
            n1 = n2;
            n2 = temp;
        }
        return n1;
    }

};

int main(){
    int a, b;
    Nat n=2;
     scanf("%d %d", &a, &b);
    int A = n.GCD(a,b);
    printf("%d", A);
}
