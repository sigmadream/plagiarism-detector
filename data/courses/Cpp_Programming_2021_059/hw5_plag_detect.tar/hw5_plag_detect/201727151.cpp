#include <cstdio>

class Nat{
private:
    int a;
public:
    Nat(int n) {
        a = n;
    }
    Nat sumup(const Nat & m) {
        a += m.a;
        return *this;
    }
    Nat mulup(const Nat & m) {
        a *= m.a;
        return *this;
    }
    int ival() {
        return a;
    }
};

Nat add(Nat &n, Nat &m) {
    Nat k(n.ival() + m.ival());
    return k;
}

Nat gcd(Nat n, Nat m) {
    if (m.ival() == 0) return n;
    else return gcd(m, n.ival() % m.ival());
}

int main() {
    int a, b;
    scanf("%d%d", &a, &b);
    Nat n = a;
    n.mulup(2);
    n.sumup(b);
    n.mulup(7);
    
    Nat m = a;
    m.mulup(4);
    m.sumup(b);
    m.mulup(2);
    
    Nat k = gcd(n, m);
    printf("%d", k.ival());
    
    return 0;
    
}
