#include <cstdio>
//recursive
//private members
using namespace std;

class Nat{
	private:
		int n1, n2,a ,b;
		int gcd;
	
	public:
	
	void input(){
		scanf("%d %d", &a, &b);
	}
	
	void mulup(){
		n1 = (2*a+b)*7;
		n2 = (4*a + b)*2;
	}
	
	void GCD(){
		static int i=1;
		
		if((n1%i)==0 & (n2%i)==0){
			gcd = i;
		}
		
		if((n1<i)||(n2<i)) {
			printf("%d", gcd);
			return;
		}
		
		i++;
		GCD();
		}
	
};

int main(){
	
	int i = 1;
	Nat num;
	num.input();
	num.mulup();
	num.GCD();
	
	return 0;
}
