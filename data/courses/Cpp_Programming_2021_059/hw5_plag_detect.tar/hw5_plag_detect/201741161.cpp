#include <cstdio>

using namespace std;

// class Nat{
//     int a;
// public:
//     Nat(int n){
        
//     }
// };

int gcd(int a, int b){
    int tmp, n;
    if(a < b){
        tmp = a;
        a = b;
        b = tmp;
    }
    while(b != 0){
        n = a % b;
        a = b;
        b = n;
    }
    return a;
}
int main()
{
    int a, b;
    int n1, n2;
    scanf("%d %d", &a, &b);
    n1 = (2 * a + b) * 7;
    n2 = (4 * a + b) * 2;
    printf("%d", gcd(n1, n2));
}