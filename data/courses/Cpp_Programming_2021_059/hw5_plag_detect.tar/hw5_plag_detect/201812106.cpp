#include <cstdio>
class Nat {
private:
	int a;
public:
	Nat(int x) {
		a = x;
	}
	Nat sumup(const Nat &m) {
		a += m.a;
		return *this;
	}
	Nat mulup(int x) {
		a *= x;
		return *this;
	}
	int ival() {
		return a;
	}
};
Nat add(Nat &n, Nat &m) {
	Nat k(n.ival() + m.ival());
	return k;
}
int gcd(int n, int m) {
	if (m == 0) return n;
	else return gcd(m, n%m);
}
int main() {
	int a, b;
	scanf("%d %d", &a, &b);
	Nat m = a, n = b;
	m.mulup(2);
	Nat p = add(m, n);
	m.mulup(2);
	Nat q = add(m, n);

	printf("%d", gcd(7 * p.ival(), 2 * q.ival()));
}