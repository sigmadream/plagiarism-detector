//201814331 Haemin Lee
#include <cstdio>

class Nat {
	int a;
public:
	Nat(int n) {
		a = n;
	}
	Nat mulup(const Nat &m) {
		a *= m.a;
		return *this;
	}
	int ival() {
		return a;
	}
};

Nat add(Nat &n, Nat &m) {
	Nat w(n.ival() + m.ival());
	return w;
}


int GCD(Nat m, Nat k) {
	int n1, n2;
	
	n1 = add(m, k) * 7;
	n2 = add(m, k) * 2;
	
	if(n2==0)return n1;
	else return GCD(n2, n1%n2);
}

int main()
{
	int a, b;
	
	scanf("%d%d", &a, &b);
	
	Nat m = a, n = b;
	
	GCD(m.mulup(2), m.mulup(2));
	printf("%d", GCD(m, n));
}
