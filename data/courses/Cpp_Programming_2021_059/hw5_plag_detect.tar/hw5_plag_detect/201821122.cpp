#include<cstdio>

class Nat
{
    int a;

public:
    Nat(int n)
    {
        a=n;
    }
    Nat mulup(Nat &m,int i)
    {
        if(i==2) a*=2;
        else a*=4;
        return *this;
    }
    int ival()
    {

       return a;

    }
};

int gcd(int a,int b)
{
    if(b==0) return a;
    else return gcd(b,a%b);

}

int main(void)
{
    int a,b;
    scanf("%d %d",&a,&b);
    Nat m(a);
    Nat n(a);
    m.mulup(m,2);
    n.mulup(n,4);

    int n1=(m.ival()+b)*7;
    int n2=(n.ival()+b)*2;

    printf("%d",gcd(n1,n2));
}
