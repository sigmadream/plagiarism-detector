#include <cstdio>

class Nat {
	int a;
public:
	Nat (int n) {
		a = n;
	}
	Nat sumup(const Nat &m) {
		a += m.a;
		return *this;
	}
	Nat mulup(int C) {
		a *= C;
		return *this;
	}
	int ival() {
		return a;
	} 

};

Nat add(Nat &n, Nat &m) {
	Nat k(n.ival()+m.ival());
	return k;
}

Nat GCD(Nat &n, Nat &m) {
	Nat k(n.ival() % m.ival());
	if (k.ival() == 0) {
	return m;
	}
	else {
	n = m;
	m = k;
	GCD(n, m);
	} 
}


int main(){
	int a, b;
	scanf("%d%d", &a, &b);
	Nat m = a, n = a;
	m.mulup(2);
	m.sumup(b);
	m.mulup(7);
	
	n.mulup(4);
	n.sumup(b);
	n.mulup(2);
	
	Nat K = GCD(m,n);
	printf("%d\n", K.ival());
}


