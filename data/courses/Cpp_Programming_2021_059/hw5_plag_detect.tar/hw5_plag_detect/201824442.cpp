#include <cstdio>

class Nat {
private:
    int a;
public:
    Nat (int n) {
        a = n;
    }
    Nat sumup(const Nat &m) {
        a += m.a;
        return *this;
    }
    Nat mulup(int m) {
        a *= m;
        return *this;
    }
    int ival () {
        return a;
    }
};

int gcd (Nat &n1, Nat &n2, int i) {
    if(i == 1)
        return i;
    else{
        if(((n1.ival() % i) == 0) & ((n2.ival() % i) == 0) )
            return i;
        else
            return gcd(n1, n2, i-1);
    }
}

int main()
{
    int a, b;

    scanf("%d%d", &a, &b);

    Nat n1 = a, n2 = a;
    n1.mulup(2);
    n1.sumup(b);
    n2.mulup(2);
    n2.sumup(n1);
    n1.mulup(7);
    n2.mulup(2);

    int i;
    if(n1.ival() > n2.ival())
        i = n2.ival();
    else
        i = n1.ival();

    Nat result = gcd(n1, n2, i);

    printf("%d", result.ival());
}
