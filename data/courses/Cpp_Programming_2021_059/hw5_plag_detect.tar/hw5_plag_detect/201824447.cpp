#include <cstdio>

int main(){
	int a, b, c;
	scanf("%d %d", &a, &b);
	c=a;
	a=(2*a+b)*7;
	b=(4*c+b)*2;
	int gcd=0;
	for(int i=1;i<=a;i++){
		if (a%i==0 && b%i==0)
		gcd=i;
	}
	printf("%d",gcd);
	
	return 0;
}
