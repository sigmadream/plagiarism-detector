#include <cstdio>

int main() {

	int x, y;
	scanf("%d %d", &x, &y);
	int n1 = (2*x+y)*7 ;
	int n2 = (4*x+y)*2;
	int i;
	int g=0;
	for(i=1; i<=n1; i++){
		if (n1%i==0 && n2%i==0){
		g=i;	
		}
		
	}
	printf("%d",g);

	return 0;

}

