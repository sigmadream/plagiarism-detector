#include <cstdio>
    
class Nat {
    int a;
public :
    Nat (int n) {
        a=n;
    }
    int num1 = 0,num2 = 0;
    Nat mulup (const Nat &m) {
        // if (num == 1 ) {
        //     num1 = (2*a + m.a) * 7;
        //     return num1;
        // }
        // else {
        //     num2 = (4*a + m.a) * 2;
        //     return num2;
        // }
        num1 = (2*a + m.a) * 7;
        num2 = (4*a + m.a) * 2;
        return *this;
    }
    int ival(int num) {
        if (num==1) {
            return num1;
        }
        else {
            return num2;
        }
    }

};

Nat gcd(int num1, int num2, int div) {
    while (!(num1 % div == 0 && num2 % div == 0)) {
        div -= 1;
    }
    printf("%d",div);
    return 0;
    // if (num1 % div ==0 && num2 % div == 0) {
    //     printf("%d",div);
    //     return div;
    // }
    // Nat g(num1,num2,div-1);
}

int main() {
    int a,b;
    scanf("%d %d",&a,&b);
    Nat one = a, two = b;
    // a = one.mulup(b,1);
    // b = one.mulup(b,0);
    one.mulup(b);
    Nat g = gcd(one.ival(1),one.ival(0),one.ival(0));
}

