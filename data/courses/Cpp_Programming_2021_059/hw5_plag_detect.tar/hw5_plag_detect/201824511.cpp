#include <cstdio>

class Nat{
   int a;
public:
   Nat(int n) {
    a = n;
    }
   Nat sumN1(const Nat &m, const Nat &n) {
      a = (m.a * 2 + n.a) * 7;
      return *this;
   }
   Nat sumN2(const Nat &m, const Nat &n) {
      a = (m.a * 4 + n.a) * 2;
      return *this;
   }
   int ival() {
    return a;
    }
};

int gcd(int a, int b){
   if(b == 0) return a;
   else return gcd(b, a % b);
}

int main(){
   int a, b;
   scanf("%d %d", &a, &b);
   Nat m = a, n = b;
   m.sumN1(a, b);
   n.sumN2(a, b);

    printf("%d\n",gcd(m.ival(),n.ival()));
}
