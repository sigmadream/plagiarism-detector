#include <cstdio>

class Nat{
    private:
        int a,b,p,q;
    public:
        Nat(int m){
            a = m;
        }
        Nat(int n){
            b = n;
        }
        Nat mulup_a(Nat p){
            p = p.a*2;
            return p;
        }
        Nat mulup_b(Nat q){
            q = q.a*4;
            return q;
        }
        int a_ival(){
            return a;
        }
        int b_ival(){
            return b;
        }
        Nat comput(Nat m,Nat n){
            a = mulup_a(m);
        }
};

Nat compute(Nat m,Nat n){
    Nat k(+n.b_ival())
}

int main() {
    int a, b;
    scanf("%d%d", &a,&b);
    Nat m = a, n = b;
    m.mulup_a(a);
    m.mulup_b(a);
    Nat k = compute(m,n)
}