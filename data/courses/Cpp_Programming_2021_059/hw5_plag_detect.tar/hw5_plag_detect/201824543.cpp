#include <cstdio>

class Nat {
private:
	int a;
	
public:
	Nat(int n);
	Nat sumup(const Nat& sumNat);
	Nat mulup(const Nat& mulNat);
	int ival();
};

int gcd(int a, int b);

int main()
{
	int a, b;
	scanf("%d%d", &a, &b);
	Nat m(a);
	m.mulup(2);
	m.sumup(b);
	m.mulup(7);

	Nat n(a);
	n.mulup(4);
	n.sumup(b);
	n.mulup(2);

	printf("%d\n", gcd(m.ival(), n.ival()));

	return 0;
}

Nat::Nat(int n) : a(n)
{
}

Nat Nat::sumup(const Nat& sumNat)
{
	a += sumNat.a;
	return *this;
}

Nat Nat::mulup(const Nat& mulNat)
{
	a *= mulNat.a;
	return *this;
}

int Nat::ival()
{
	return a;
}

int gcd(int a, int b)
{
	if (b == 0)
	{
		return a;
	}
	else
	{
		return gcd(b, a % b);
	}
}