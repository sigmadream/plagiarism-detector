#include <cstdio>

class Nat {
private:
    int a;
public:
    Nat(int n){
        this->a = n;
    }
    Nat sumup(const Nat &m) {
        this->a += m.a;
        return *this;
    }
    Nat sub(const Nat &m) {
        this->a -= m.a;
        return *this;
    }
    Nat mulup(const int k) {
        this->a *= k;
        return *this;
    }
    Nat div(const int k) {
        this->a /= k;
        return *this;
    }
    int ival() {
        return this->a;
    }
};

Nat add(Nat &n, Nat &m) {
    Nat k(n.ival() + m.ival());
    return k;
}

bool get_int(int &n) {
    return scanf("%d", &n) == 1;
}

Nat gcd(Nat &a, Nat &b)
{
    if (a.ival() == b.ival())
        return a;

    if (a.ival() == 0) 
        return b;
        
    if (b.ival() == 0) 
        return a;
    
    if (a.ival() % 2 == 0) {
        if (b.ival() % 2 == 1) {
            a.div(2);
            return gcd(a,b);
        }
        else {
            a.div(2);
            b.div(2);
            Nat k = gcd(a,b);
            return k.mulup(2);
        }
    }
    else {
        if (b.ival() % 2 == 0) {
            b.div(2);
            return gcd(a,b);
        }
        if (a.ival() > b.ival()) {
            a.sub(b);
            a.div(2);
            return gcd(a,b);
        }
        else {
            b.sub(a);
            b.div(2);
            return gcd(b,a);
        }
    }
    return 0;
}

int main() {
    int x,y;
    get_int(x);
    get_int(y);
    Nat a = x, b = y;
    Nat n1 = a, n2 = a;
    n1.mulup(2);
    n1.sumup(b);
    n1.mulup(7);
    n2.mulup(4);
    n2.sumup(b);
    n2.mulup(2);
    Nat gcdNum = gcd(n1,n2);
    printf("%d", gcdNum.ival());
}