#include <cstdio>

class Nat {
    int a;

    public: 
        Nat(int n) {
            a = n;
        }

        Nat mulup(int num) {
            this-> a *= num;
            return *this;
        }

        Nat sumup(const Nat &m) {
            a += m.a;
            return *this;
        }

        int ival() {
            return a;
        }
};

int Gcd(int n1, int n2) {
    if(n1 == 0) {
        return n2;
    }

    if(n2 == 0) {
        return n1;
    }
    
    if(n1 == n2) {
        return n1;
    }

    if(n1 > n2) {
        return Gcd(n1 - n2, n2);
    }
    return Gcd(n1, n2 - n1);
}

int main()
{
    int a, b;
    scanf("%d%d", &a, &b);

    Nat n1(a), n1cp(b);
    Nat n2(a), n2cp(b);
    n1.mulup(14);
    n1cp.mulup(7);
    
    n2.mulup(8);
    n2cp.mulup(2);

    n1.sumup(n1cp);
    n2.sumup(n2cp);

    int gcd = Gcd(n1.ival(), n2.ival());
    printf("%d", gcd);
}
