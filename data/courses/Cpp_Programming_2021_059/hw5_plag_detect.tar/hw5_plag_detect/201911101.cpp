#include <cstdio>

class Nat {
private:
    int a;
public:
    Nat(int n) {
        a = n;
    }
    
    Nat sumup(const Nat &m) {
        a += m.a;
        return *this;
    }

    Nat mulup(const Nat &m) {
        a *= m.a;
        return *this;
    }

    int ival() {
        return a;
    }
};

Nat add(Nat &n, Nat &m) {
    Nat k(n.ival()+m.ival());
    return k;
}

Nat gcd(Nat n, Nat m) {
    if (n.ival()<m.ival()) return gcd(m, n);
    else if (m.ival() == 1) return m;
    else if (m.ival() == 0) return n;
    else{ 
        n.sumup(-1 * (m.ival()) * (n.ival() / m.ival()));
        return gcd(m, n);
    }
}

int main() {
    int a,b;
    scanf("%d %d", &a, &b);
    Nat A(a), B(b), C(7), D(2);
    Nat N1(2), N2(4);
    N1.mulup(A); N1.sumup(B); N1.mulup(C);
    N2.mulup(A); N2.sumup(B); N2.mulup(D);
    Nat GCD = gcd(N1,N2);
    printf("%d",GCD.ival());
}