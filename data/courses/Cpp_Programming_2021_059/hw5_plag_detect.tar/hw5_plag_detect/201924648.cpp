#include <iostream>

using namespace std;

class Net
{
    public:
Net(int a)
{
    this->a = a;
}

Net& mulup(int num)
{
    a *= num;
    return *this;
}
Net& addup(int num)
{
    
     a+=num;
    return *this;
}
Net& add(const Net &rhs)
{
    
    a+=rhs.a;
    return *this;
}
int getval()
{
    return a;
}

private: 
int a;
};

int GCD(Net a , Net b)
{
    if(a.getval()<b.getval()) swap(a,b);
    if(b.getval()==0) return a.getval();
    return GCD(b,Net(a.getval()-b.getval()));
}



int main()
{
    int x,y;
    cin>>x>>y;

    Net a(x);
    Net b(y);
    
    Net n1 = a;
    Net n2 = a;

    n1.mulup(2);
    n2.mulup(4);
    
    n1.add(b).mulup(7);
    n2.add(b).mulup(2);
    
    cout<<GCD(n2,n1);
    
}
