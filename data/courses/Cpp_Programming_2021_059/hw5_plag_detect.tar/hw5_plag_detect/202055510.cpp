#include <cstdio>

class Nat {
	private:
		int a;
		
	public:		
		Nat mulup(int mul, const Nat &n){
			a = mul * n.a;
			return *this;
		}
		Nat(int x){
			a = x;
		}
		void sumup(int n){
			a += n;
		}
		int chk_val(){
			return a;
		}
};

int gcd(Nat &n, Nat &m){
	if(m.chk_val() == 0)	return n.chk_val();
	else{
		Nat t(n.chk_val() % m.chk_val());
		return gcd(m, t);
	}	
}

int main(){
	int a, b;
	scanf("%d%d", &a,&b);
	
	Nat m = a, n = b, tmp = a;
	m.mulup(2, m);
	m.sumup(b);
	m.mulup(7, m);
	
	n.mulup(4, tmp);
	n.sumup(b);
	n.mulup(2, n);
	
	printf("%d", gcd(m, n));
	
	
}
