#include <stdio.h>



int gcd(int a, int b) {

    int gcdNum = 0;

    for (int i = 1; i < a; i++) {
        if (a % i == 0 && b % i == 0) {
            gcdNum = i;
        }
    }
    return gcdNum;

}


int main(void) {

    int a, b;
    int n1, n2;

    scanf("%d %d", &a, &b);

    n1 = (2 * a + b) * 7;
    n2 = (4 * a + b) * 2;

    printf("%d", gcd(n1, n2));


    return 0;
}

