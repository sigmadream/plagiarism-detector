#include <cstdio>


class Nat {
private:
	int a ;
	int b;
public:
	int mulup_1(int &a){
		this->a = 2* a;
		return this->a;
	}
	int mulup_2(int &b){
		this->b = 4 *b;
		return this->b;
	}
};

int gcd(int a, int b){
    
    if(b == 0){
        return a;
    }else{
        return gcd(b, a%b);
    }
}

int main(){
	Nat m  , n ;
	int x  , y =0 ;
	int n1, n2 = 0;
	scanf("%d%d", &x, &y);
	n1 = (m.mulup_1(x)+	y) * 7;
	n2 = (m.mulup_2(x) +y) *2;
	printf("%d",gcd(n1,n2));
	
	
}
