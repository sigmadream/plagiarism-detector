#include <cstdio>
 class Nat {
 int a;
 public:
 Nat(int n) {
 a = n;
 }
 Nat mulup(const Nat &m) {
 a *= m.a;
 return *this;
 }
 int ival() {
 return a;
 }
 };

 int gcd(int x, int y){
 	if(y==0){
 		return x;
	}
	else {
		return gcd(y, x%y);
	}
 }

 int main()
 {
 int a, b, n1, n2;
 scanf("%d %d", &a, &b);
 Nat m = a, n = a;
 m.mulup(2);
 n.mulup(4);
 
 n1 = (m.ival() + b)*7;
 n2 = (n.ival() + b)*2;
 
 printf("%d\n",gcd(n1, n2));
 }

