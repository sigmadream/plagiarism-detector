
#include<cstdio>
class Nat {
    int a;
  public:
    Nat(int n) {
        a = n;
    } Nat sumup(const Nat &m) {
        a += m.a;
        return *this;
    }
    int ival() {
        return a;
    }
};
Nat n1(Nat &n, Nat &m) {
    Nat k((2*n.ival()+m.ival())*7);
    return k;
}
Nat n2(Nat &n, Nat &m) {
    Nat k((4*n.ival()+m.ival())*2);
    return k;
}
Nat gcd(Nat &n, Nat &m){
    int a = n.ival();
    int b = m.ival();
    int temp;
    int n3;
    if(a<b){
        temp = a;
        a = b;
        b = temp;
    }

    while(b!=0){
        n3 = a%b;
        a = b;
        b = n3;
    }
    return a;
}


int main() {
    int a, b;
    scanf("%d %d", &a, &b);
    Nat m = a, n = b;
    Nat k1 = n1(m, n);
    Nat k2 = n2(m, n);
    //printf("a%d b%d",a,b);
    //printf("\n%d    %d  ->   %d",k1,k2,gcd(k1,k2));
    printf("%d",gcd(k1,k2));
}
