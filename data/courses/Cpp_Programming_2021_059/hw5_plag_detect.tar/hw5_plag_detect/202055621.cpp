#include <cstdio>
class Nat{
int a;
public:
    Nat(int n){
        a=n;
    }
    Nat Mulup(const Nat &m){
        a*=m.a;
        return *this;
    }

    int Ival(){
        return a;
    }
};

Nat gcd(Nat &m, Nat &n){
    if(m.Ival() != 0 && n.Ival() != 0){
        m.Ival()>n.Ival() ? m=m.Ival()%n.Ival() : n=n.Ival()%m.Ival();
        gcd(m, n);
    }
    return m.Ival()>n.Ival() ? m : n;
}
int main()
{
    int a, b;
    scanf(" %d%d", &a, &b);
    Nat m = a, n = b;
    m.Mulup(2);
    Nat new_m = 7*(m.Ival()+n.Ival());
    m.Mulup(2);
    Nat new_n = 2*(m.Ival()+n.Ival());


    printf("%d", gcd(new_m,new_n));
}
