#include <cstdio>
#include <vector>

using namespace std;

class Nat
{
    int a;
public:
    Nat(int n): a(n) {};
    int ival() const { return a; } //
    Nat mulup(const int &n) {
        Nat m(a*n);
        return m;
    }
};

Nat add(const Nat &n, const Nat &m) {
    Nat k(n.ival()+m.ival()); //
    return k;
}

Nat resOfPoly1(Nat &n1, Nat &n2) {
    Nat mulV = n1.mulup(2);
    mulV = add(mulV, n2);
    mulV = mulV.mulup(7);
    return mulV;
}

Nat resOfPoly2(Nat &n1, Nat &n2) {
    Nat mulV = n1.mulup(4);
    mulV = add(mulV, n2);
    mulV = mulV.mulup(2);
    return mulV;
}

Nat gcd(const Nat &n1, const Nat &n2, int a, vector<Nat> cds) {
    if (a == n2.ival())
    {
        return cds[cds.size()-1];
    }else{
        a++;
        if (n1.ival() % a == 0 && n2.ival() % a == 0)
        {
            cds.push_back(Nat(a));
        }
        return gcd(n1, n2, a, cds);
    }
}

int main()
{
    int a, b;
    scanf("%d%d", &a, &b);
    Nat myGcd(0);
    vector<Nat> cds;
    Nat n1 = a;
    Nat n2 = b;
    Nat res1 = resOfPoly1(n1, n2);
    Nat res2 = resOfPoly2(n1, n2);
    if (res1.ival() > res2.ival())
    {
        myGcd = gcd(res1, res2, 0, cds);
    } else {
        myGcd = gcd(res2, res1, 0, cds);
    }
    printf("%d", myGcd.ival());
}