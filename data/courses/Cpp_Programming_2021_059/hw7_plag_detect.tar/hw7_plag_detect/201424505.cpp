#include<iostream>
#include<cstdio>
using namespace std;

int hamingDistance(string str1, string str2){
	int i = 0;
	int distance = 0;
	while(i < str1.length() || i < str2.length()){
		if(str1[i] != str2[i]){
			distance++;
		}
		i++;
	}
	cout  << distance;
	return distance;
}
int main(){
	char str1[100];
  char str2[100];
  scanf("%s %s",str1,str2);
  hamingDistance(str1, str2);
}

