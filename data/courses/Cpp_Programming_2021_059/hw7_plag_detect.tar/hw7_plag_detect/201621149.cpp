#include <iostream>
#include <string>

using namespace std;

namespace dist{
	class HamString {
	private:
		string line;
	public:
		HamString(string in_line) {
			this->line = in_line;
		}
		void show(HamString ano_line) {
			int result = 100;

			string w1, w2;
			if (this->line.length() >= ano_line.line.length()) {
				w1 = this->line;
				w2 = ano_line.line;
			}
			else {
				w2 = this->line;
				w1 = ano_line.line;
			}

			for (int i = 0; i <= w1.length()-w2.length(); i++) {
				string cut_w1 = w1.substr(i);
				int max_repeat = min(cut_w1.length(), w2.length());
				int cnt = 0;
				for (int j = 0; j < max_repeat; j++) {
					if (cut_w1[j] != w2[j]) {
						++cnt;
					}
				}
				if (cnt == 0) {
					result = 0;
					break;
				}
				result = min(result, cnt);
			}

			cout << result << endl;
		}
	};
}



int main()
{
	string line_a, line_b;
	cin >> line_a >> line_b;
	dist::HamString l1 = dist::HamString(line_a);
	dist::HamString l2 = dist::HamString(line_b);

	l1.show(l2);
}