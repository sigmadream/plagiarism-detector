#include <iostream>
#include <string>
#define MAX_LENGTH 100
using namespace std;

class HamString {
private:
    string str;
public:
    HamString() { cin >> str; }
    HamString(string s) { str = s; }
    
    int dist(HamString &H) {
        int distance = MAX_LENGTH;
        string longString;
        string shortString;
        if (str.length() < H.str.length()) {
            longString = H.str;
            shortString = str;
        }
        else {
            longString = str;
            shortString = H.str;
        }
        
        for (int i = 0; i < longString.length(); i++) {
            string subString = longString.substr(i);
            if (subString.length() < shortString.length()) break;
            
            int tempDistance = (int) shortString.length();
            for (int j = 0; j < shortString.length(); j++) {
                if (subString[j] == shortString[j]) tempDistance--;
            }
            if (distance > tempDistance) distance = tempDistance;
        }
        return distance;
    }
};

int main(void) {
    HamString a, b;
    cout << a.dist(b);
    return 0;
}
