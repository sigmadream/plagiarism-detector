#include<iostream>
#include<string>

using namespace std;

class HamString{
    string _s1, _s2;
public:
    HamString();
    HamString(string s1, string s2)
        :_s1(s1), _s2(s2){}
    int dist(string s1, string s2);
};

int HamString::dist(string s1, string s2){
    int cnt = 0;
    int dif = 0, max_cnt = 0;
    if(s2.length() > s1.length())
        s1.swap(s2);
    dif = s1.length() - s2.length();
    for(int k = 0; k <= dif; k++){
        for(int j = 0; j < s2.length(); j++){
            if(s1.at(j + k) == s2.at(j))
                cnt++;
        }
        if(cnt > max_cnt)
            max_cnt = cnt;
        cnt = 0;
    }
    return s2.length() - max_cnt;
}
int main()
{
    string h1, h2;
    cin >> h1 >> h2;
    HamString s(h1, h2);
    cout << s.dist(h1, h2);
}
