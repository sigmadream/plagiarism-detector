#include <iostream>
#include <string>
using namespace std;
class HamString {
	string s;
	int len;
public:
	HamString(string x, int y) {
		s = x;
		len = y;
	}
	int dist(HamString x) {
		string s1 = this->s;
		string s2 = x.s;
		int len1 = this->len;
		int len2 = x.len;

		if (len1 > len2) {
			swap(s1, s2);
			swap(len1, len2);
		}

		int ret = 111;
		for (int i = 0; i < len2 - len1 + 1; i++) {
			int cnt = 0;
			for (int j = 0; j < len1; j++) {
				if (s1[j] != s2[i + j]) {
					cnt++;
				}
			}
			if (ret > cnt) {
				ret = cnt;
			}
		}
		return ret;
	}
};
int main() {
	string a, b;
	cin >> a >> b;

	HamString x(a, a.length());
	HamString y(b, b.length());

	cout << x.dist(y);
}