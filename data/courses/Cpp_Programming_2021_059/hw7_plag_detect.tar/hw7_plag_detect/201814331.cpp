//201814331 Haemin Lee
#include<cstdio>
#include <cstring>

int main(void)
{
    int i, j, len1, len2, max_len, dif_len, cnt1, cnt2 = 100, temp = 0, n;
	char s1[100], s2[100];
    
	scanf("%s", s1);
	scanf("%s", s2); 

	len1 = strlen(s1);
	len2 = strlen(s2);
	printf("%d %d\n", len1, len2); //���� 
	
	max_len = len1 > len2 ? len1 : len2;
	dif_len = len1 > len2 ? len1-len2 : len2-len1;
	printf("max : %d\n", max_len); //����
	printf("dif : %d\n", dif_len); //���� 
	
	while(temp <= dif_len)
	{
		for (i = 0, j = temp, cnt1 = 0; i < max_len; i++)
		{
			printf("j : %d\n", j);
			
			if (len2 < len1)
			{
				n = i;
				i = j;
				j = n;
			}			
			
			if ( s1[i] != s2[j] && (s1[i] != NULL && s2[j] != NULL) )	
				cnt1++;
				
			j = j + 1;
			
			if (len2 < len1)
			{
				n = j;
				j = i;
				i = n;
			}
		
		}
		
		
		
		printf("temp %d cnt1 : %d\n", temp, cnt1);
		cnt2 = cnt1 < cnt2 ? cnt1 : cnt2;
		printf("cnt2 : %d\n", cnt2);
		
		temp++;
	}
	
	printf("\nfinal : %d", cnt2);


    return 0;
}
