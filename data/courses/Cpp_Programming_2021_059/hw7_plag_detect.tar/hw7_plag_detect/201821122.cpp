#include <iostream>
#include <string>
using namespace std;

class HamString
{
private:
    string line1;
    string line2;

public:
    HamString(string line1,string line2) : line1(line1),line2(line2)
    {}
    int dist()
    {
        int mincount=100;
        int countnum=0;

        for (int i=0;i<(line1.length()-line2.length()+1);i++)
        {
            string line3 = line1.substr(i);
            for(int j=0;line2[j];j++)
            {
                if(line2[j]!=line3[j])
                    countnum++;
            }
            if(mincount>countnum) mincount=countnum;
            countnum=0;
        }

        return mincount;
    }

};


int main()
{
    string line1,line2;

    cin>>line1;
    cin>>line2;

    string temp;

    if(line1.length()<line2.length())
    {
        temp=line1;
        line1=line2;
        line2=temp;
    }
    HamString st(line1,line2);


    cout<<st.dist()<<endl;


 }
