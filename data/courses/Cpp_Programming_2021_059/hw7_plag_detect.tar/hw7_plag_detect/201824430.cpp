#include <iostream>
#include <cstring>

using namespace std;

int main() {
	char str1[100], str2[100];
	cin >> str1;
	cin >> str2;
	
	int lenstr = strlen(str1);
	int lenstr2 = strlen(str2);
	
	
	if (lenstr2>lenstr) {
		char tmp[100];
		strcpy(tmp, str1);
		strcpy(str1, str2); 
		strcpy(str2, tmp);
		lenstr = strlen(str1);
		lenstr2 = strlen(str2);
	}
	
	int ans = 300;
	int diff = lenstr - lenstr2;
	int i,j;
	
	for (i=0; i<=diff; i++){
		int num = 0;
		for (j=i; j<=i+lenstr2-1; j++) {
			if (str1[j] != str2[j-i]) {
				num++;
			}
		}
		
		if (ans>num) {ans=num;}	;	
	} 
	
	cout << ans;
}

