#include <iostream>
#include <string>
using namespace std;

class HamString {
private:
	string x;
	int leng;
public:
	HamString (string a) {
		x = a;
		leng = a.length();
	}
	HamString () {
		x = "";
		leng = 0;
	}
	int dist(HamString m) {
		int temp = 0, min = leng;
		int i, j;
		
		if(leng == m.leng) {
			for(i=0; i < leng; i++) {
				if(x[i] != m.x[i])
					temp++;
			}
			return temp;
		}
		
		if(leng > m.leng) {
			for(i=0; i < (leng-m.leng+1); i++) {
				for(j=0; j < m.leng; j++) {
					if(x[i+j] != m.x[j])
						temp++;
				}
				if(min > temp)
					min = temp;
				temp = 0;
			}
			return min;
		}
		if(m.leng > leng) {
			for(i=0; i < (m.leng-leng+1); i++) {
				for(j=0; j < leng; j++) {
					if(m.x[i+j] != x[j])
						temp++;
				}
				if(min > temp)
					min = temp;
				temp = 0;
			}
			return min;
		}
		return 0;
	}
};

istream& operator >> (istream& in, HamString &n) {
	string a;
	in >> a;
	HamString temp(a);
	n = temp;
	return in;
}

int main()
{
	HamString a, b;
	cin >> a >> b;
	int result = a.dist(b);
	printf("%d\n", result);
}
