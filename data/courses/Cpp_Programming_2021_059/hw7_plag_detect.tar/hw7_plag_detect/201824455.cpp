#include <cstdio>
#include <string.h>

int main(){
	char string1[20];
	char string2[20];
	scanf("%s %s",string1,string2);
	char firststring[20];
	char secondstring[20];
	int a, b;
	int i;
	for(i=0; i<20; i++){
		if(string1[i]!=0) a+=1;
		if(string2[i]!=0) b+=1;
		if(string1[i]==0 && string2[i]==0) break;
	}
	if (a>b){
		strcpy(firststring,string1);
		strcpy(secondstring,string2);
	}
	else {
		strcpy(secondstring,string1);
		strcpy(firststring,string2);
	}
	// firststring �� ��� secondstring�� ª���ŵ��մ»� 
	int k=0,count=0;
	for(k=0; secondstring[k]!=0; k++){
		if(firststring[k]!=secondstring[k]) count=count+1;
		
	}
	
	printf("%d",count);
	return 0;
}
