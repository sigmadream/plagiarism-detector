#include <iostream>
#include <string>
using namespace std;

class HamString {
private:
    string first,second;
    int diff, minDiff;
public:
    HamString(): first(""), second(""), diff(0), minDiff(100) {}
    HamString getstr() {
        cin >> first >> second;
        return *this;
    }
    void dist();
    void print() {
        cout << minDiff << endl;
    }
     
};

void HamString::dist() {
        if (first.length() >= second.length()) {
            for(int i =0; i <= (first.length() - second.length()); i++) {
                diff = 0;
                for (int j =0; j < second.length(); j++) { 
                    if (first[i+j] != second[j]) 
                        diff += 1;
                }
            if (minDiff >= diff)
                minDiff = diff;
            }
        }
        else {
            for(int i =0; i <= (second.length() - first.length()); i++) {
                diff = 0;
                for (int j =0; j < first.length(); j++) {
                    if (first[j] != second[i+j])
                        diff += 1;
                }
            if (minDiff >= diff)
                minDiff = diff;
            }
        }
    }

int main() {
    HamString h;
    h.getstr();
    h.dist();
    h.print();
}