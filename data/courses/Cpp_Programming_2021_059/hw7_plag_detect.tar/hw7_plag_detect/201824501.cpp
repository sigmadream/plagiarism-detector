#include <iostream>
#include <string>
using namespace std;

class HamString{
    string line1;
    string line2;
public:
    HamString(string l1, string l2){
        line1 = l1;
        line2 = l2;
    }

    int dist(){
        int result =1000;
        if(line1.length() < line2.length()){
            string temp;
            temp = line1;
            line1= line2;
            line2= temp;
        }
        for( int i = 0; i <= line1.length() - line2.length(); i++){
            int sum =0;
            for( int j =0; j < line2.length(); j++){
                if(line1.substr(i)[j] != line2[j])
                    sum += 1;
            }
            if(sum < result)
                result = sum;
        }
        return result;
    }
};

int main(){
    string a;
    string b;
    cin >> a;
    cin >> b;
    HamString p(a,b);
    cout << p.dist() << endl;

}

