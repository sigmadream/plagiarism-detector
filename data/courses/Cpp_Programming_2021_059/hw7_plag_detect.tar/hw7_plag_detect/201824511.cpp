#include <iostream>
#include <string>
using namespace std;

class HamString{
    string line;
public:
    HamString(string l = 0){ line = l;}
    int dist(HamString l2);
};

int main(){
    string a,b;
    cin >> a;
    cin >> b;
    HamString word1(a);
    HamString word2(b);
    cout << word1.dist(word2) << endl;
}

int HamString::dist(HamString l2){
        int result;
        if(line.length() < l2.line.length()){
            string temp;
            temp = line;
            line= l2.line;
            l2.line= temp;
        }
        for( int i = 0; i <= line.length() - l2.line.length(); i++){
            int sum =0;
            for( int j =0; j < l2.line.length(); j++){
                if(line.substr(i)[j] != l2.line[j])
                    sum += 1;
            }
            if(i==0)
                result = sum;
            else
                if (sum < result) result = sum;
        }
        return result;
    }
