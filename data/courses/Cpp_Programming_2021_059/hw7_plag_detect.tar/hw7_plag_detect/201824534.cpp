#include <iostream>
#include <string>
using namespace std;

class HamString{
    string L1, L2, s;
    int i,p=0,q=100;
public:
    HamString() {
        L1 = "asdf";
        L2 = "asdf";
    }
    HamString(string line1, string line2){
        L1 = line1;
        L2 = line2;
    }
    void dist(){
        if(L1.length()>=L2.length()){
            i = L1.length()-L2.length();
            for(int j=0;j<L2.length();j++){
                s = L1.substr(i);
                for(int k=0;k<L2.length();k++){
                    if(L1[j+k]!=L2[k])
                        p = p+1;
                }
                if(p<q)
                    q = p;
            }
        }
        else {
            i = L2.length()-L1.length();
            for(int j=0;j<L1.length();j++){
                s = L2.substr(i);
                for(int k=0;k<L1.length();k++){
                    if(L2[j+k]!=L1[k])
                        p = p+1;
                }
                if(p<q)
                    q=p;
            }
        }
    }
    int ival(){
        return q;
    }
};

int main(){
    string line1, line2;
    cin >> line1 >> line2;
    HamString a(line1,line2);
    a.dist();
    cout << a.ival();
}