#include <iostream>
#include <string>

class HamString
{
private:
	std::string s;

public:
	HamString();
	~HamString();
	int dist(HamString s2);
};

int main()
{
	HamString myString1;
	HamString myString2;

	std::cout << myString1.dist(myString2) << std::endl;

	return 0;
}

HamString::HamString()
{
	std::cin >> s;
}

HamString::~HamString()
{
}

int HamString::dist(HamString ham2)
{
	if (s.size() < ham2.s.size())
	{
		std::string temp = s;
		s = ham2.s;
		ham2.s = temp;
	}

	int minDiff = 101;
	for (int sIdx = 0; sIdx <= s.size() - ham2.s.size(); sIdx++)
	{
		std::string sSub = s.substr(sIdx);
		int countDiff = 0;
		for (int i = 0; i < ham2.s.size(); i++)
		{
			if (sSub[i] != ham2.s[i])
			{
				countDiff++;
			}
		}

		if (countDiff < minDiff)
		{
			minDiff = countDiff;
		}
	}

	return minDiff;
}