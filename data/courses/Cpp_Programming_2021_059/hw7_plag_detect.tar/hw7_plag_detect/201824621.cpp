#include <iostream>
#include <string>
using namespace std;

class HamString {
    public:
    HamString(string s) {
        _s = s;
    }
    int dist(HamString str) {
        string t = str.getString();
        int minDistance = 101;
        int diff;
        string l,s;
        if (t.length() > _s.length()) {
            diff = t.length() - _s.length();
            l = t;
            s = _s;
        }
        else if (_s.length() > t.length()) {
            diff = _s.length() - t.length();
            l = _s;
            s = t;
        }
        else {
            return calcEqualDist(t,_s);
        }

        for (int i = 0; i <= diff; i++) {
            string cutString = l.substr(i,s.length());
            int currDist = calcEqualDist(s,cutString);
            if (currDist < minDistance) {
                minDistance = currDist;
            }
        }
        return minDistance;
        
    }
    int calcEqualDist(string s1,string s2) {
        if (s1.length() == s2.length()) {
            int count = 0;
            for (int i = 0; i < s1.length(); i++) {
                if (s1[i] != s2[i]) {
                    count++;
                }
            }
            return count;
        }
        else {
            return 0;
        }
    }
    string getString() {
        return _s;
    }
    void setString(string s) {
        _s = s;
    }
    private:
    string _s;
};

int main()
{
    string s1,s2;
    cin >> s1 >> s2;
    HamString h1(s1);
    HamString h2(s2);
    cout << h1.dist(h2);
}