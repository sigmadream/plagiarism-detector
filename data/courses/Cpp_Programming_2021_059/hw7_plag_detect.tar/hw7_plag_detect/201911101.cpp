#include <iostream>
#include <string>

using namespace std;

class HamString {

public:
    string str;
    HamString(string buf) {str = buf;}
    void Set_Hamstring(string line) {str = line;}

    int dist(HamString ham2) {
        int H = 0;
        for (int i = 0; i < str.length(); i++) {
            char c = str[i];
            if(c >= 'A' && c <= 'Z') c +=32;
            int I = i;
            int h = 0;
            for (int j = 0; j < ham2.str.length(); j++){
                int J = j;
                char c2 = ham2.str[j];
                if(c2 >= 'A' && c2 <= 'Z') c2 +=32;
                while(c1 == c2 && (i<str.length() && j<ham2.str.length())) {
                    h+=1;
                    c = str[++i];
                    c2 = str[++j];
                    if(c >= 'A' && c <= 'Z') c +=32;
                    if(c2 >= 'A' && c2 <= 'Z') c2 +=32;
                }
                if(H<h) H = h;
                i = I;
                j = J;
            }
        }
        return H;
    }
};




int main()
{
    string line1, line2;
    cin >> line1 >> line2;
    HamString A(line1), B(line2);

//  A.Set_Hamstring(line1); B.Set_Hamstring(line2);
    cout << A.str << " " << B.str << endl;
    cout << A.dist(B);
}