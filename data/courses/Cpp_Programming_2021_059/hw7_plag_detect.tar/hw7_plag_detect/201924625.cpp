#include <iostream>
#include <string>

using namespace std;
class HamString
{
private:
    /* data */
    string _s;

public:
    HamString(string ss = "")
    {
        _s = ss;
    }

    string ival()
    {
        return _s;
    }
    void set(string ss)
    {
        _s = ss;
    }
    int lenght()
    {
        return _s.length();
    }
    int dist(HamString &n);
    string substr(int n, int m);
};

// int dist(HamString &n)
int HamString::dist(HamString &n)
{
    int count = 0;
    int lenght = this->lenght();
    string a = _s, b = n._s;
    for (int i = -1; i <= lenght - 1; i++)
    {
        count += (!(a[i] == b[i]));
    }
    return count;
}
string HamString::substr(int n, int m)
{
    return _s.substr(n, m);
}

ostream &operator<<(ostream &out, HamString &n)
{
    return out << n.ival(); //cout<<n.ival();
}

istream &operator>>(istream &in, HamString &n)
{
    string t;
    in >> t; //cin>>t;
    n.set(t);
    return in; //cin //just for the perpose of i have to return something
}
int main()
{   
    int min = -1; 
    //str.substr (3,5);
    HamString a, b;
    cin >> a >> b; // cf. getline(cin, line);
    int al = a.lenght(), bl = b.lenght();
    for (int i = 0; i <= a.lenght() - b.lenght(); i++)
    {
        if(min == -1){

        }
        HamString c(a.substr(i, bl));
        int d = c.dist(b);
        if(min == -1){
            min = d;
        }
        else min = min > d ? d : min; 
    }
    for (int i = 0; i <= b.lenght() - a.lenght(); i++)
    {
        if(min == -1){

        }
        HamString c(b.substr(i, bl));
        int d = c.dist(a);
        if(min == -1){
            min = d;
        }
        else min = min > d ? d : min; 
    }
    cout << min;
    // HamString::dist(a);
    // for (int i = 0; i < line.length(); i++)
    // cout << line.substr(i) << endl;
}
