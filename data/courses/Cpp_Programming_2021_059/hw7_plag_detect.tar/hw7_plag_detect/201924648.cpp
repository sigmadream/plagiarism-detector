#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

class HamString
{
    friend bool operator<(const HamString & l,const HamString &R);
    string str;
    int len;
    public:

    HamString(string str = "") :str(str){len = str.length();}

    int dist(const HamString & rhs)
    {
        int minimum=100;

        for(int i=0;i<len-rhs.len+1;i++)
        {
            int hamcode=0;
            for(int j=0;j<rhs.len;j++)
            {
                if(str[i+j]!=rhs.str[j])
                {
                    hamcode++;
                }
            }

            minimum = min(minimum,hamcode);
        }

        return minimum;

    }
    
};

bool operator<(const HamString & l,const HamString &R)
{
    return l.len < R.len;
}
int main()
{
    string s,t;

    cin>>s>>t;
    
   
    HamString hamstr(s);
    HamString substr(t);
   
   if(substr < hamstr)
   {
       cout<<hamstr.dist(substr);
   }
   else
   {
       cout<<substr.dist(hamstr);
   }

}