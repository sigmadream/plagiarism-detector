#include <iostream>
#include <string>
using namespace std;

class HamString{
	string str;
	
	public:
		HamString(){
			str = "";
		}
		HamString(string s){
			str = s;
		}
		
		int dist(HamString h){
			string str1;
			string str2;
			if(str.length() > h.str.length()){
				str1 = str;
				str2 = h.str;
			}
			else{
				str1 = h.str;
				str2 = str;
			}
			int ret = 100;
			for(int i = 0; i <= str1.length()-str2.length(); i++){
				string tmp = str1.substr(i, str2.length());
				int count = 0;
				for(int j = 0; j < tmp.length(); j++){
					if(tmp[j] != str2[j])	count++;
				}
				ret = min(ret, count);
			}
			return ret;
		}
};

int main(){
	string s1, s2;
	cin >> s1 >> s2;
	
	HamString H1(s1), H2(s2);
	int ret = H1.dist(H2);
	cout << ret << endl;
}
