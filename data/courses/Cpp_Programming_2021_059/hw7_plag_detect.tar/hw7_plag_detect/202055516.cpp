#include <iostream>
#include <string>
using namespace std;


int main() {
    string s1,s2, s3;
    cin >> s1;
    cin >> s2;
    int count = 0, len=0, min=100;
    if(s1.length() > s2.length()) {
        s3 = s1;
        s1 = s2;
        s2 = s3;
    }
    len = s2.length() - s1.length();
    for (int j =0; j < len+1; j++) {
        count = 0;
        for (int i=0; i< s1.length(); i++) {
            if(s1.substr(i,1).compare(s2.substr(i+j,1))<0) {
                count ++;
            }
            if (count < min) {
                min = count;
            }
        }
    }
    cout << count<<endl;


}
