// C++ program to find hamming distance b/w
// two string
#include<stdio.h>
using namespace std;

// function to calculate Hamming distance
int hammingDist(char* str1, char* str2)
{
	int i = 1, count = 0;

	while (str1[i] != '\0' )
	{

		if (str1[i] != str2[i] && str1[i -1] != str2[i - 1]) {
			if (str1[i] != str2[i])
				count++;
			i++;
		}
		i++;

	}
	return count;
}



// driver code
int main()
{
	char str1[100] ;
	char str2[100] ;
	int x;
	scanf("%s %s", str1, str2);
	int i = 0;
	//int k = 0;

	int a1 = 0;
	int a2 = 0;

	while (1) {
		
		if (str1[i] == '\0') {
			a1 = i;
			break;
		}
		i++;
	}

	i = 0;
	while (1) {
		
		if (str2[i] == '\0') {
			a2 = i;
			break;
		}
		i++;
	}

	
	if (a1 >= a2) {
		printf("%d", hammingDist(str1, str2));
	}
	else if (a1 < a2){
		printf("%d", hammingDist(str2, str1));
	}
	

	return 0;
}
