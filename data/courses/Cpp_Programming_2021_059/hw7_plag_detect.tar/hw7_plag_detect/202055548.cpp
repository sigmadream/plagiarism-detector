#include <cstdio>


int main(void)
{
	char first[100];
	char second[100];
	scanf("%s", &first);
	scanf("%s", &second);
	
	int i = 0;
	while(first[i] != 0)
	{
		i = i + 1;
	}
	int first_num = i;
	i = 0;
	while(second[i] != 0)
	{
		i = i + 1;
	}
	int second_num = i;
	
	if(first_num < second_num)
	{
		char box;
		i = 0;
		while(i < second_num)
		{
			box = first[i];
			first[i] = second[i];
			second[i] = box;	
			i = i + 1;
		}	
		int box2 = first_num;
		first_num = second_num;
		second_num = box2;
		first[first_num] = 0;
		second[second_num] = 0;
	}

	
	int differ = first_num - second_num;
	i = 0;
	int count = 100;
	
	while(i <= differ)
	{	
		int m = 0;
		int count_temp = 0;
		while(m < second_num)
		{
			if(first[m+i] != second[m])
			{	
				
				count_temp = count_temp + 1;
			
			}
			m = m + 1;
		}
		if(count_temp < count)
		{
			
			count = count_temp;
		}
		i = i + 1;	
	}
	printf("%d",count);


}
