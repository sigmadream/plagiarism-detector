#include <iostream>
#include <string>
using namespace std;





int main(){
	
	string s1, s2 ,tmp ;
	cin >> s1;
	cin >> s2;
	
	int count = 0;

	
	if( s1.length() == s2.length()){
		for( int i = 0 ; i < s1.length() ; i ++){
			if(s1[i] != s2[i]) count++;
		}
		cout << count << endl;
	}
	
	
	else{
		if ( s1.length() < s2.length()){	//s1�� �� �� ���ڿ� ����  
			tmp = s1;
			s1 = s2;
			s2 = tmp;
		} 
	
		int c = s1.length() - s2.length() + 1;
		int ss2 = s2.length();
		int m = 0;
		int i = 0;
		int g = ss2;
		for (int m = 0 ; m < c ; m++){
			i = m ;	
//			cout << " i : " <<  i << endl;
				for( int l = 0 ; l < s2.length() + 1 ; l++){
				
					if(s1[i] != s2[l]) {
//						cout << s1[i] << " \t" << s2[l] << endl;
						count++;
						i++;
					}
					else {
//						cout << s1[i] << " \t" << s2[l] << endl;
						i++;
					}
					
				}
			if (count <= g)
					g = count;

			
		}
	
		
		cout << g << endl;
		
		
		
	}

	
}
