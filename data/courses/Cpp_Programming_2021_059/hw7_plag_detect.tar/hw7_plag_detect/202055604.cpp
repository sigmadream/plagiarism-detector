#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

int comp(string x, string y){
    int counter = 0;
    for(int i = 0;i<x.length();i++){
        if(x.at(i) != y.at(i)) counter =counter + 1;

    }
    return counter;
}

class hamstring {
  public:
    hamstring() {
        x = "";
        y = "";
    }
    hamstring(string xinp,string yinp) {
        x = xinp;
        y = yinp;
    }
    void dist() {
        string longer;
        string shorter;


        int l1 = x.length();
        int l2 = y.length();

        if(l1 >= l2) {
            longer = x;
            shorter = y;
        } else {
            longer = y;
            shorter = x;
        }
        string blank = "";
        int sl = shorter.length();
        int dist = shorter.length();
        for (int i = 1; i <= abs(l1-l2)+1; i++ ) {

            string finally = blank + shorter;
            //cout << longer.substr(i-1,sl)+" "+shorter  << endl;
            int subdist = comp(longer.substr(i-1,sl),shorter);
            if(subdist <= dist) {
                dist = subdist;
            }

        }
        cout << dist << endl;
    }


  private:
    string x, y;
};



int main() {
    string line;
    string line2;
    cin >> line >> line2;
    hamstring ss(line,line2);
    ss.dist();





}
