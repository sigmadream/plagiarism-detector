#include <iostream>
#include <string>
using namespace std;

int main()
{
    int ans=0, temp;
    string str_1, str_2;
    cin >> str_1 >> str_2;
    if(str_1.length() < str_2.length())
        str_1.swap (str_2);
    int rep = str_1.length()-str_2.length()+1;
    for(int i = 0; i<rep;i++){
        temp=0;
        for(int j =0; j<str_2.length();j++){
            if(str_1[j]==str_2[j])
            temp++;
        }
        if(temp > ans){
            ans=temp;
        }
        str_1=str_1.substr(1);
    }
    cout << str_2.length()-ans << endl;
}
