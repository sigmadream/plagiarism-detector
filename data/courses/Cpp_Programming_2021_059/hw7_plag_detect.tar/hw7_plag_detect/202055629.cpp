#include <iostream>
#include <string> 
using namespace std;

class Hamstring {
    string l;
    int len;
public:
    Hamstring(string s = "Hello"){
        l = s;
        len = l.length();
    }

    int dist(Hamstring a){
        int ham_dist = 0;
        if (len > a.len) {
            int dis = 0;
            for (int j = 0; j < (len - a.len)+1; j++){
                dis = j;
                for (int k = 0; k < len; k++){
                    
                    if (l.substr(j+k, 1) != a.l.substr(k, 1))
                        dis++;
                    if (j == 0) ham_dist = dis;
                }
                if (ham_dist > dis)
                    ham_dist = dis;
            }
        } else if (len == a.len){
            for (int i = 0; i < len; i++){
                if (l.substr(i,1) != a.l.substr(i,1))
                    ham_dist++;
            }
        } else if (a.len > len){
            int dis = 0;
            for (int j = 0; j < (a.len - len)+1; j++){
                dis = j;
                for (int k = 0; k < a.len; k++){
                    
                    if (a.l.substr(j+k, 1) != l.substr(k, 1))
                        dis++;
                    
                }
                if (j == 0) ham_dist = dis;
                if (ham_dist > dis)
                    ham_dist = dis;
            }
        }
        return ham_dist;
    }
};

int main(){
    string l1, l2;
    int dist;
    cin >> l1 >> l2;
    Hamstring line1(l1), line2(l2);
    dist = line1.dist(line2);
    cout << dist;
}