#include <iostream>
#include <string>

using namespace std;

class HamString
{
private:
    string line;
public:
    HamString() {line = "";}
    string getLine() {return line;}
    void setLine(string s) {line = s;}
    int dist(HamString);
};

int HamString::dist(HamString hamStr) {
    string s2 = hamStr.getLine();
    int hamDist = s2.length();
    for (int i = 0; i <= line.length()-s2.length(); i++)
    {
        int j = i;
        int tmpDist = 0;
        for (int m = 0; m < s2.length(); m++)
        {
            if (line[j] != s2[m])
            {
                tmpDist++;
            }
            j++;
        }
        if (tmpDist < hamDist)
        {
            hamDist = tmpDist;
        }
    }
    return hamDist;
}

int main()
{
    string s1, s2;
    HamString ham1, ham2;
    cin >> s1 >> s2;
    if (s1.length() > s2.length())
    {
        ham1.setLine(s1);
        ham2.setLine(s2);
    } else{
        ham1.setLine(s2);
        ham2.setLine(s1);
    }
    int hamDistance = ham1.dist(ham2);
    cout << hamDistance << endl;
}