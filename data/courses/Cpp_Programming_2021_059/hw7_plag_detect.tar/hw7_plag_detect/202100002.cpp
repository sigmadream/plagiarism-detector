#include <bits/stdc++.h>
using namespace std;

class HamString {
    string _s;
public:
    HamString(string s=""): _s(s) {}
    int dist(HamString s) {
        int l1 = _s.length(), l2 = s._s.length();
        if (l1 < l2)
            return s.dist(*this);
        if (l1 > l2) {
            HamString s1(_s.substr(0, l2));
            HamString s2(_s.substr(1));
            return min(s1.dist(s), s2.dist(s));
        }
        return eqdist(s._s);
    }
    int eqdist(string s) {
        return (s.length() == 0)? 0 
             : (_s[0] == s[0]? 0 : 1) + HamString(_s.substr(1)).eqdist(s.substr(1));
    }
};

int main() {
    string s1, s2;
    cin >> s1 >> s2;
    HamString h1(s1), h2(s2);
    cout << h1.dist(h2) << endl;
}
