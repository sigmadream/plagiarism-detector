#include<iostream>
#include<string>
using namespace std;


int main(){

    string line, line2;
    int hm_dist=0;
    int match_dist=0;

    cin >> line;
    cin >> line2;

    const char * stringP = line.c_str();
    const char * stringP2 = line2.c_str();

    if(line.length() == line2.length()){
        for(int i=0; i<line.length(); i++){
            if(stringP[i] != stringP2[i]){
                hm_dist += 1;
            }
        }
    }
/*    else{
        if(line.length() > line2.length()){
            
        }
        else{

        }
    }
*/

    cout << hm_dist << endl;

    return 0;
}