#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
using namespace std;

int main()
{
    string words[] = { "Apple", "Banana" , "Cheese Stick" };
    ostringstream buf;
    buf << "+-------+" << endl;
    for (string word: words)
        buf << "i " << setw(5) << word << " i" << endl;
    char prev = buf.fill('-');
    buf << "+-" << setw(5) << "" << "-+" << endl;
    buf.fill(prev);
    cout << buf.str(); 
}