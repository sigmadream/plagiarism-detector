#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

int main() {
   vector<string> sv;
    string s1;
    int max_len = 0;
    while(!cin.eof()){
        cin >> s1;
        sv.push_back(s1);
    }
   ostringstream buf;
   buf << "+-------+" << endl;
   for (string s0: sv)
   buf << "| " << setw(5) << s0 << " |" << endl;
    char prev = buf.fill('-');
    buf << "+-" << setw(5) << "" << "-+" << endl;
    buf.fill(prev);
    cout << buf.str();
}
