#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

class Menu
{
private:
    vector<string> words;
    int m_len = 0;

public:
    Menu() {}
    void Add_word(string word)
    {
        this->words.push_back(word);
        this->m_len = max(this->m_len, (int)word.length());
    }
    void print()
    {
        print_basic();
        for (string word : this->words)
            cout << "| " << setw(this->m_len) << word << " |\n";
        print_basic();
    }
    void print_basic()
    {
        string mystring = "+";

        for (int i = 0; i < this->m_len + 2; i++)
            mystring += "-";
        cout << mystring << "+\n";
    }
};

int main()
{
    Menu myword = Menu();
    string in_string;
    while (cin >> in_string)
        myword.Add_word(in_string);
    myword.print();
}
