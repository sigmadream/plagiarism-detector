#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
using namespace std;

int main()
{	
 	ostringstream buf;
	string str;
	int i=0;

	while ( cin >> str ){
		if (i ==0){
			buf << "+-" << setw(5) << "" << "-+" << endl;
		}
		buf << "| " << setw(5) << str << " |" << endl;
		i++;
	}

	char prev = buf.fill('-');
 	buf << "+-" << setw(5) << "" << "-+" << endl;
 	buf.fill(prev);

 	cout << buf.str();
}
