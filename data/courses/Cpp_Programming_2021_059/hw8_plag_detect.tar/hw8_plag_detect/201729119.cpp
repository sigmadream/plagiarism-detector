#include <cstdio>
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
using namespace std;

class Menu{
	int max, i, len_;
	vector<string> words;
	string k;
	public:
		Menu(){
			max = 0; i = 0;
		}
		void print_line(){
		cout << "+-";
		for(int k = 0; k < max; k++) cout << "-";
		cout << "-+" << endl;
		}
		void print_word(){
			for(int k = 0; k < i; k++) cout << "| " << setw(max) << words[k]<< " |" << endl;
		}
		void input(){
			while(cin >> k){
			words.push_back(k);
			i++;
			len_ = k.length();
			len_ > max ? max = len_ : max = max; 
			}
		}
};

int main(){
	Menu word;
	
	word.input();
	word.print_line();
	word.print_word();
	word.print_line();
	
}
