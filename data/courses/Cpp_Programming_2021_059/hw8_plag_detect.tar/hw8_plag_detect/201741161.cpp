#include<iostream>
#include<vector>
#include <sstream>
#include <string>
#include <iomanip>

using namespace std;
int max_len = 0;
class Menu{
    vector<string> sv;
public:
    Menu(){}
    void f(){
        string s1;

    while(!cin.eof()){
        cin >> s1;
        sv.push_back(s1);
        }
    for(int i = 0; i < sv.size(); i++){
        if(sv[i].length() > max_len){
            max_len = sv[i].length();
        }
    }
    cout << "+";
    for(int i = 0; i < max_len + 2; i++){
        cout << "-";
        }
    cout << "+" << '\n';
    }
    void print(ostream&);
};
void Menu::print(ostream& out){
        for(int i = 0; i < sv.size(); i++){
        out << "|" << ' ' << sv[i] << ' ';
        for(int j = 0; j < max_len - sv[i].length(); j++){
            out << ' ';
        }
        out << "|" << '\n';
    }
    out << "+";
    for(int i = 0; i < max_len + 2; i++){
        out << "-";
    }
    out << "+" << '\n';
}


int main(){
    Menu a;
    a.f();
    a.print(cout);
}