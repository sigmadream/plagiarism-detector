#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <string.h>
using namespace std;
class Menu {
public:
	vector<string> words;
	int mlen = 0;
	void print(ostream& x) {
		ostringstream buf;
		buf << "+-";
		for (int i = 0; i < mlen; i++) {
			buf << "-";
		}
		buf << "-+" << endl;
		for (string word : words) {
			buf << "| " << setw(mlen) << word << " |" << endl;
		}
		char prev = buf.fill('-');
		buf << "+-" << setw(mlen) << "" << "-+" << endl;
		buf.fill(prev);
		x << buf.str();
	}
};
int main() {
	Menu me;
	string s;
	while (cin >> s) {
		me.words.push_back(s);
		me.mlen = max(me.mlen, (int)s.length());
	}
	me.print(cout);
}