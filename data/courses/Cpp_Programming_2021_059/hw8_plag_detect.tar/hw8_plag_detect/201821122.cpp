#include<iostream>
#include<iomanip>
#include<sstream>
#include<string>
#include<vector>
#include<cstdio>
#include<cstring>

using namespace std;

class Menu
{
private:
    vector<string> v;
    int maxlen;

public:
    Menu(vector<string> v,int maxlen) :v(v),maxlen(maxlen)
    {}
    void print()
    {
        ostringstream buf;
        char prev = buf.fill('-');
        buf << "+-" << setw(maxlen) << "" << "-+" << endl;
        buf.fill(prev);
        for (string word: v)
        buf << "| " << setw(maxlen) << word << " |" << endl;
        prev = buf.fill('-');
        buf << "+-" << setw(maxlen) << "" << "-+" << endl;
        buf.fill(prev);
        cout << buf.str();
    }

};

int main(void)
{
    vector<string> a;
    string temp;
    string temp2;
    int max=0;
    for(int i=0;i<40;i++)
    {
        cin>>temp;
        if(temp2==temp) break;
        temp2=temp;
        
        a.push_back(temp);
        if(temp.size()>max) max=temp.size();
        
    }
  
    Menu menu1(a,max);
    menu1.print();


}