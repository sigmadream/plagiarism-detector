#include <iostream>
#include <cstring>

using namespace std;

string menu[100];

int main() {
	cin >> menu[0];
	
	int i=1;
	int maxlen=0;
	while(getline(cin, menu[i])){
		cin >> menu[i];
		i++;
	}	
	
	int W_num = i;
	
	for (int j=0; j<=W_num; j++) {
		if (maxlen<menu[j].length()) maxlen = menu[j].length();
	}
	
	for (int j=0; j<=W_num; j++) {
		int space = maxlen - menu[j].length();
		for (int k=0; k<space; k++) {
			menu[j].insert(0, " ");
		}
	}
	
	string first_last;
	
	first_last.append("+");
	
	for (int j=0; j<maxlen+2; j++) {
		first_last.append("-");
	}
	first_last.append("+");
	
	cout << first_last << '\n';
	
	for (int j=0; j<W_num-1; j++) {
		cout << "l " << menu[j] << " l" << '\n'; 
	}
	
	cout << first_last;
}
