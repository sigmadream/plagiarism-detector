#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

class Menu{
private:
	vector<string> m;
	int max_leng;
public:
	void input(string a){
		m.push_back(a);
		if(max_leng < a.length())
			max_leng = a.length();
	}
	Menu (){
		m.resize(0);
		max_leng = 0;
	}
	ostream& print(ostream& out){
		ostringstream buf;
		char prev = buf.fill('-');
		buf << "+-" << setw(max_leng) << "" << "-+" << endl;
		buf.fill(prev);
		for(int i = 0; i < m.size(); i++){
			string word = m[i];
			buf << "| " << setw(max_leng) << word << " |" << endl;
		}
		prev = buf.fill('-');
		buf << "+-" << setw(max_leng) << "" << "-+" << endl;
		buf.fill(prev);
		out << buf.str();
		return out;
	}
};

int main()
{
	string word;
	Menu menu;
	
	while(cin >> word)
		menu.input(word);
	
	menu.print(cout);
}
