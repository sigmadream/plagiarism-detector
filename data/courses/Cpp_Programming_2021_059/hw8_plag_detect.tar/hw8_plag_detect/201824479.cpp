#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

class Menu {
    vector <string> v;
    int len_each, len_max,idx;
public:
    Menu(): len_each(0), len_max(0), idx(0) {}
    Menu getstr() {
        string s;
        while (cin >> s) {
            v.push_back(s);
            idx++;
            len_each = s.length();
            if (len_each > len_max) len_max = len_each;
        }
        return *this;
    }
    void print(ostream& out);
};
void Menu::print(ostream&) {
    int len;
    ostringstream buff,content;
    char bar = buff.fill('-');
    buff << "+-" << setw(len_max) << "" << "-+" << endl;
    buff.fill(bar);
    cout << buff.str();
    for (int i =0;i<idx;i++) {
        len = len_max - v[i].length();
        content << "| " << setw(len) << "" << v[i] << " |" << endl;
    }
    cout << content.str();
    cout << buff.str();
}

int main() {
    Menu str;
    str.getstr();
    str.print(cout); 
}

