#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;

class Menu{
private:
    vector<string> s;
    int maxsz = 0;
public:
    void input(string sample) { s.push_back(sample); }
    void getstring(){
        string sample_string;
        while (cin >> sample_string){
            input(sample_string);
            if(sample_string.length()>=maxsz)
                maxsz = sample_string.length();
        }
    }
    void print(ostream& out){
        ostringstream buf;
        int width;
        width = maxsz;
        char prev = buf.fill('-');
        buf << "+-" << setw(width) << "" << "-+" << endl;
        buf.fill(prev);
        for (string word: s)
            buf << "| " << setw(width) << word << " |" << endl;
        prev = buf.fill('-');
        buf << "+-" << setw(width) << "" << "-+" << endl;
        buf.fill(prev);
        out << buf.str();
    }
};

int main(){
    Menu words;
    words.getstring();
    words.print(cout);
}