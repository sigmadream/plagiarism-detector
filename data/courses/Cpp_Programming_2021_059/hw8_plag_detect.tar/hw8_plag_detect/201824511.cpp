#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

class Menu{
    string input;
    vector<string> words;
    int maxsz=0;
public:
    void getnum();
    void print(ostream &buf);
};
int main()
{
    Menu a;
    a.getnum();
    a.print(cout);
}

void Menu::getnum(){
    while(cin >> input){
            int sz = input.length();
            if(maxsz<sz) maxsz = sz;
            words.push_back(input);
        }
}

void Menu::print(ostream &buf){
    int width = maxsz;
    char prev = buf.fill('-');
    buf << "+-" << setw(width) << "" << "-+" << endl;
    buf.fill(prev);
    for (string word: words)
        buf << "| " << setw(width) << word << " |" << endl;
    prev = buf.fill('-');
    buf << "+-" << setw(width) << "" << "-+" << endl;
    buf.fill(prev);
    buf.flush();
}