#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
using namespace std;

int main(){
    int i=0,k,width=0;
    string words[100];
    while(getline(cin,words[i++]));
    for(k=0;k<i;k++){
        if(words[k].length()>width){
            width = words[k].length();
        }
    }
    ostringstream buf;
    char prev1 = buf.fill('-');
    buf << "+-" << setw(width) << "" << "-+" << endl;
    buf.fill(prev1);
    for(int j=0;j<i-1;j++)
        buf << "| " << setw(width) << words[j] << " |" << endl;
    char prev2 = buf.fill('-');    
    buf << "+-" << setw(width) << "" << "-+" << endl;
    buf.fill(prev2);
    cout << buf.str();
}