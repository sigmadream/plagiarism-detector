#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

class Menu
{
private:
	std::vector<std::string> items;
	int maxStrLength;

public:
	Menu();
	~Menu();
	void print(std::ostringstream& buf);

};

int main()
{
	Menu myMenu;
	std::ostringstream menuBuf;
	myMenu.print(menuBuf);

	return 0;
}

Menu::Menu() : maxStrLength(0)
{
	std::string temp;
	while (std::cin >> temp)
	{
		if (temp.size() > maxStrLength)
		{
			maxStrLength = temp.size();
		}
		items.push_back(temp);
	}
}

Menu::~Menu()
{
}

void Menu::print(std::ostringstream& buf)
{
	char prev = buf.fill('-');
	buf << "+-" << std::setw(maxStrLength) << "" << "-+" << std::endl;
	buf.fill(prev);
	for (std::string word : items)
	{
		buf << "| " << std::setw(maxStrLength) << word << " |" << std::endl;
	}
	prev = buf.fill('-');
	buf << "+-" << std::setw(maxStrLength) << "" << "-+" << std::endl;
	buf.fill(prev);
	std::cout << buf.str();
}