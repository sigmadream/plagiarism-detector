#include <iostream>
#include <string>
#include <iomanip>
#include <sstream>
#include <vector>

using namespace std;

class Menu
{
    public:
    Menu(vector<string> w);
    Menu();
    void print(ostream& o);
    void setMaxLength(int m);
    private:
    vector<string> words;
    int maxLength;
};

Menu::Menu(vector<string> w) 
{
    this->words = w;
}

Menu::Menu() 
{
    this->maxLength = 0;
}

void Menu::print(ostream& o) 
{
    ostringstream buf;
    char prev = buf.fill('-');
    buf << "+-" << setw(this->maxLength) << "" << "-+" << endl;
    buf.fill(prev);
    for (string word: this->words) {
        buf << "| " << setw(this->maxLength) << word << " |" << endl;
    }
    prev = buf.fill('-');
    buf << "+-" << setw(this->maxLength) << "" << "-+" << endl;
    buf.fill(prev);
    o << buf.str();
}

void Menu::setMaxLength(int m) 
{
    this->maxLength = m;
}

int main()
{
    string word;
    vector<string> words;
    int maxLength = 0;
    while(cin >> word) {
        int current = word.size();
        maxLength = max(maxLength, current);
        words.push_back(word);
    }
    Menu m(words);
    m.setMaxLength(maxLength);
    m.print(cout);
}