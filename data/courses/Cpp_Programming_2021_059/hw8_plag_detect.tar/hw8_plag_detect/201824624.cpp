#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

class Menu {
    vector<string> list;
    ostringstream buf;
    int maxLength;

private:
    void FindMaxLength() {
        int max = 0;

        for(int i = 0; i < list.size(); i++) {
            if(max < list[i].length())
                max = list[i].length();
        }

        this->maxLength = max;
    };
public: 
    Menu(vector<string> inputList) {
        for(int i = 0; i < inputList.size(); i++)
            list.push_back(inputList[i]);
    }

    void MakeMenu();
    void Print(ostream &out);

    void Frame() {
        char pre = buf.fill('-');
        this->buf << "+" << setw(maxLength + 2) << "" << "+" << endl;
        this->buf.fill(pre);
    }
};

void Menu::Print(ostream &out ) {
    out << this->buf.str();
}

void Menu::MakeMenu() {
    this->FindMaxLength();

    this->Frame();
    for(int i = 0; i < this->list.size(); i++)
        buf << "| " << setw(maxLength) << this->list[i] << " |" << endl;
    this->Frame();
}

int main() {
    vector<string> list;
    string str;

    while(cin >> str)
        list.push_back(str);

    Menu menu(list);
    menu.MakeMenu();
    menu.Print(cout);
}
