#include <cstdio>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

class Menu
{
    vector<string> menu;
public:
    Menu() {menu={};}
    
    void append_menu(string item) {
        menu.push_back(item);
    }
    
    int max_len() {
        int len=0;
        for (string item:menu) {
            if (item.length()>len) len = item.length();
        }
        return len;
    }

    ostream& print(ostream&) {
        
        ostringstream buf;
        int width = max_len();
        
        char prev = buf.fill('-');
        buf << "+-" << setw(width) << "" << "-+" << endl;
        buf.fill(prev);
        
        for (string item:menu) {
            buf << "| " << setw(width) << item << " |" << endl;
        }

        prev = buf.fill('-');
        buf << "+-" << setw(width) << "" << "-+" << endl;
        buf.fill(prev);

        return cout << buf.str();
    }
};

int main() {

    string item;
    Menu m;
    while(cin >> item){
        m.append_menu(item);
    }
    m.print(cout);

    return 1;
}





/*
    string words[] = {"Hello","C++","World"};
    ostringstream buf;
    int width = 10;
    buf << "+------------+" << endl;
    for (string word: words)
        buf << "| " << setw(width) << word << " |" << endl;
    char prev = buf.fill('-');
    buf << "+-" << setw(width) << "" << "-+" << endl;
    buf.fill(prev);
    cout << buf.str();
*/