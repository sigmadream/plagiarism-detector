#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

using namespace std;
class Menu
{
private:
    vector<string> menu;
    int vsize;
    int maxlen;

public:
    Menu()
    {
        maxlen = 0;
        vsize = 0;
    }
    void push(string _s)
    {
        menu.push_back(_s);
        if (maxlen < _s.length())
            maxlen = _s.length();
        vsize++;
    }
    vector<string> valout()
    {
        return menu;
    }
    string vali(int i)
    {
        return menu[i];
    }
    int size()
    {
        return menu.size();
    }
    void print(ostream &out);
};

void Menu::print(ostream &out)
{
    ostringstream buf;
    buf << "+";
    for (int i = 0; i < maxlen + 2; i++)
        buf << '-';
    buf << "+" << endl;
    for (int i = 0; i < vsize; i++)
    {
        int y = maxlen - menu[i].length();
        buf << "| ";
        for (int j = 0; j < y; j++)
            buf << " ";
        buf << menu[i] << " |" << endl;
    }

    buf << "+";
    for (int i = 0; i < maxlen + 2; i++)
        buf << '-';
    buf << "+" << endl;
    cout << buf.str();
}
int main()
{
    string wordin;
    ostringstream buf;
    int max = 0;
    Menu a;
    while (cin >> wordin)
    {
        a.push(wordin);
    }
    // vector<string> _s = a.valout();
    a.print(cout);
    // for (int i = 0; i < a.size(); i++)
    // {
    //     cout << a.vali(i) << endl;
    // }
    // for (string word : words)
    //     buf << "| " << setw(5) << word << " |" << endl;
    // char prev = buf.fill('-');
    // buf << "+-" << setw(5) << ""
    //     << "-+" << endl;
    // // buf.fill(prev);
    // cout << buf.str();
}