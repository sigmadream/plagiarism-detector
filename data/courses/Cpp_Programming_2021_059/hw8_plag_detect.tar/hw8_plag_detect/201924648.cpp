#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;


class Menu
{
    public:
        Menu(vector<string> vec):vec(vec){}
        void print()
        {
            ostringstream buf;
            char prev;
            int width = getmaxlen();
            int height = vec.size();
            prev = buf.fill('-');

            buf << "+-" << setw(width) << "" << "-+" << endl;
            buf.fill(' ');
            for(string str : vec)
            {
                buf << "| " << setw(width) << str << " |" << endl;
            }
            buf.fill('-');
            buf << "+-" << setw(width) << "" << "-+" << endl;

            cout<<buf.str();
            
        }

        int getmaxlen()
        {
            int maximum=0;
            for(string str:vec)
            {
                int num = str.length();
                maximum = max(maximum,num);
            }
            return maximum;
        }

    private:
        vector<string> vec;
};

int main()
{
    string str;
    vector<string> vec;
    while(cin>>str)
    {
        vec.push_back(str);
        str.clear();
    }

    Menu menu(vec);
    menu.print();

}