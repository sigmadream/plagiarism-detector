#include <iostream>
#include <iomanip>
#include <sstream>
#include <String>
#include <vector>

class Menu
{
private:
    std::vector <std::string> foods;
    int count=0;
public:
    std::vector<std::string> get_menu()
    {
        std::string word;
        while(getline(std::cin,word))
        {
            foods.push_back(word);
            if(word.length() > count)
            {
                count= word.length();
            }
        }
        return foods;
    }

    void print(std::ostream& out)
    {
        std::ostringstream buf;
        int width = count, i=0;
        char prev = buf.fill('-');
        buf << "+-" << std::setw(width) << "" << "-+" <<std::endl;
        buf.fill(prev);
        while(i<foods.size())
        {
            buf << "| " << std::setw(width) << foods[i++] << " |" <<std::endl;
        }
        prev = buf.fill('-');
        buf << "+-" << std::setw(width) << "" << "-+" <<std::endl;
        buf.fill(prev);
        out << buf.str();
    }
};

int main()
{
    Menu menu;
    std::vector<std::string> food_menu;
    food_menu = menu.get_menu();
    menu.print(std::cout);
}
