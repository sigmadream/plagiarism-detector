#include<iostream>
#include<vector>
#include<string>
#include <iomanip>
#include <sstream>
#include <algorithm>


using namespace std;

class Menu {
public:
	int n;
	int max;
	vector<string> v;

};


int line(int k) {
	printf("+");
	for (int i = 0; i <= k + 1; i++) {
		printf("-");
	}
	printf("+\n");
	return 0;

}


int main() {
	Menu m;
	string a;

	while (getline(cin , a) ) {
		if (a == "\n") {
			break;
		}
		m.v.push_back(a);
	}
/*
	

	
	cout << k << endl;
	*/
	int num[1000]; 
	int k = m.v.size();

	for (int i = 0; i < k; i++) {
		num[i] = m.v[i].size();
	}
	sort(num , num + k );

	int max = num[k-1];

	


	ostringstream buf;
	
	// buf << "+-------+" << endl;
	line(max);
	 for (string word : m.v)
		 buf << "| " << setw(max) << word << " |" << endl;
	 char prev = buf.fill('-');
	buf << "+-" << setw(max) << "-" << "-+" << endl;
    buf.fill(prev);
	 cout << buf.str();
	
	

}