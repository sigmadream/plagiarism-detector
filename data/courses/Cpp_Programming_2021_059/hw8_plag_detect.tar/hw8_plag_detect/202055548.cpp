#include <cstdio>

int main(void)
{
	char name[100][42] = {0, };
	int i = 0;
	fgets(name[0], 40, stdin);
	
	while(name[i][0] != 10)
	{
		i = i + 1;
		fgets(name[i], 40, stdin);
	}
	
	int menu_number = i;
	i = 0;
	int j = 0;
	
	while(i < menu_number)
	{
		while(name[i][j] != 10)
		{
			j = j + 1;
		}
		name[i][j] = 0;
		name[i][41] = j;
		j = 0;
		i = i + 1;
	}
	i = 0;

	int longest_menu = 0; 
	while(i < menu_number)
	{
		if(name[i][41] > longest_menu)
		{
			longest_menu = name[i][41];
		}
		i = i + 1;
	}
	
	//ù�� 
	printf("+"); 
	i = 0;
	while(i < longest_menu + 2)
	{
		printf("-");
		i = i + 1; 
	}
	i = 0;
	printf("+\n");
	
	//�߰� ���� ��
	i = 0;
	while(i < menu_number)
	{
		printf("|"); 
		printf(" ");
		j = 0;
		while(j < longest_menu - name[i][41])
		{
			printf(" ");
			j = j + 1;	
		}
		printf("%s", name[i]);
		printf(" ");
		printf("|\n");
		i = i + 1;	
	} 
	
	
	
	//�������� 
	printf("+"); 
	i = 0;
	while(i < longest_menu + 2)
	{
		printf("-");
		i = i + 1; 
	}
	i = 0;
	printf("+\n");
		
}
