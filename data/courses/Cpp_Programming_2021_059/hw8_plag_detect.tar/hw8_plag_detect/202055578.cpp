#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
using namespace std;

int main(){
	ostringstream buf;
	string menu[100];
	int i = 0;
	while(cin>>menu[i]){
	
		i++;
	}
//		while(1){
//		getline(cin,menu[i]);
//		 if(cin.eof() == true) {break;}
//		i++;
//	}
	
	int k = 0;
	int tmp=0;
	for(int j = 0 ; j<i  ; j++) { 
		k = menu[j].length();
		if (tmp < k ) tmp = k;
		}


	
	
	char prev = buf.fill('-');

	int width = tmp  ;

	buf << "+-" << setw(width ) << "" << "-+" << endl;
	buf.fill(prev);

	for(int l = 0 ; l < i ; l++){
		buf << "|"<<" " << setw(width) << menu[l] <<" " <<"|" << endl;
	}	
	
	prev = buf.fill('-');

	buf << "+-" << setw( width) << "" << "-+" << endl;
	buf.fill(prev);
	
	cout << buf.str();
	
	
	
}



