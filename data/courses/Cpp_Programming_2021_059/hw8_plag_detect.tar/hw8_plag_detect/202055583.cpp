#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;

int main(void){
	string words[]={"coffe", "egg"};
	ostringstream buf;
	cout << "+-------+"  << endl;
	
	for (string word: words)
	buf << "| " << setw(5) << word << " |" << endl;
	char prev = buf.fill('-');
	cout << "+-" << setw(5) << "" << "-+" << endl;
	
	buf.fill(prev);
	cout << buf.str();
}
