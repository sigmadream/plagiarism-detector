#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include<vector>
using namespace std;



int main() {
    std::vector<string>strbox;

    int largelen =0;
    while(!cin.eof()) {
        string aa;
        cin >> aa;
        if(aa.length() >= largelen)
            largelen = aa.length();
        if(aa != "") strbox.push_back(aa);
    }




    ostringstream buf;
    char prev = buf.fill('-');
    buf << "+-" << setw(largelen) << "" << "-+" << endl;
    buf.fill(prev);

    for(int i = 0; i<strbox.size(); i++) {
        char sp = buf.fill(' ');
        buf << "| " << setw(largelen - strbox[i].length())<< "" << strbox[i]<< " |" << endl;
        buf.fill(sp);
    }


    char prev2 = buf.fill('-');
    buf << "+-" << setw(largelen) << "" << "-+";
    buf.fill(prev2);
    cout << buf.str();

}
