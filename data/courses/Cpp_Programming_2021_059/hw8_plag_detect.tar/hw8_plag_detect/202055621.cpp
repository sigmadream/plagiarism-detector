#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
#include <string.h>
using namespace std;
class Menu{
public:
    vector<string> m;
    int length_max=0;
    int Len(){
        return length_max;
    }
};
void print(Menu menu){
    ostringstream buf;
    int length_max=menu.Len();
    buf << "+" ;
    for(int i =0; i<length_max+2;i++) buf << "-";
    buf << "+" << endl;
    for (int j=0;j<menu.m.size();j++){
        buf << "| " << setw(length_max) << menu.m[j] << " |" << endl;
    }
    char prev = buf.fill('-');
    buf << "+-" << setw(length_max) << "" << "-+" << endl;
    buf.fill(prev);
    cout << buf.str();
}
int main()
{
    char cbuf[40];
    int sz = sizeof cbuf/sizeof *cbuf;
    Menu menu;
    while (cin.getline(cbuf,sz)){
        menu.m.push_back(cbuf);
        if(menu.length_max<strlen(cbuf))
            menu.length_max= strlen(cbuf);
    }
    print(menu);

}
