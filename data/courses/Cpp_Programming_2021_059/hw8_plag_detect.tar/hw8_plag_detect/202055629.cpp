#include <iostream>
#include <vector>
#include <sstream>
#include <string>
#include <iomanip>
using namespace std;

class Menu {
    vector<string> str;
    int max_len;
public:
    Menu (vector<string> s, int l) : str(s) , max_len(l) {}

    void print(){
        ostringstream out;
        char prev = out.fill('-');
        out << "+-" << setw(max_len) << "" << "-+" << endl;
        out.fill(prev);
        for (string word: str)
            out << "| " << setw(max_len) << word << " |" << endl;
        out << "+-";
        for(int i = 0; i<max_len; i++)
            out << '-';
        out << "-+" << endl;
        
        cout << out.str();
    }
};
int main(){
    vector<string> a;
    string t;
    int len = 0;
    while(cin >> t) 
    {
        a.push_back(t);
        if(len < t.length())
            len = t.length();
    }
    Menu m(a,len);
    m.print();
    
}