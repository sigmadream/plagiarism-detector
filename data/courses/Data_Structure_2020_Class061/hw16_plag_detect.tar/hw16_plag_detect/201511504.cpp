#include <iostream>
#include <vector>
#include <list>

using namespace std;

class Edge {
public:
    int src, dst;
};

class Graph {
    int sz;
    vector<list<int>> adjlist;
public:
    Graph(int n, vector<Edge> &edges) : sz(n) {
        adjlist.resize(sz);
        for (Edge &e: edges){
            adjlist[e.src].push_back(e.dst);
            adjlist[e.dst].push_back(e.src);
        }
    }
    ostream& print(ostream &out=cout){
        int start;
        int a[20];
        out << start << endl;
        for(start; start<sz; start++){
            auto lst = adjlist[start];
            auto p = lst.begin();
            out << *p << endl ;
        }
        return out;
    }

};

int main(){
    int n, k, start;
    int input[2];
    cin >> n >> k ;
    cin >> start;
    vector<Edge> edges;
    for(int i=0; i<k; i++){
        cin >> input[0] >> input[1];
        edges.push_back({input[0], input[1]});
    }
    Graph g(k, edges);
    g.print(cout);
}
