#include<iostream>
#include<vector>
using namespace std;

void DFS(vector<int>* graph, bool* visited, int start){
    visited[start] = true;
    cout << start << endl;

    for(int i = 0 ; i < graph[start].size(); i++){
        int next = graph[start][i];
        if (!visited[next]) DFS(graph, visited, next);
    }
}

int main(){
    int nodes, edges, start;
    cin >> nodes >> edges;
    int n, m;
    vector<int>* graph = new vector<int>[nodes];
    bool* visited = new bool[nodes];
    for(int i = 0; i < edges;i ++){
        cin >> n >> m;
        graph[n].push_back(m);
        graph[m].push_back(n);
    }
    cin >> start;
    DFS(graph, visited, start);
}