#include <iostream>
#include <vector>

using namespace std;
 
class Graph {
    int V; 
    vector<int>* adj;
    void DFS_run(int v, bool* visited);
 
public:
    Graph(int V);
    void addEdge(int v, int w);
    void DFS(int v);
};
 
Graph::Graph(int V)
{
    this->V = V;
    adj = new vector<int>[V];
}
 
void Graph::addEdge(int v, int w)
{
    adj[v].push_back(w);
    adj[w].push_back(v);
}
 
void Graph::DFS_run(int v, bool visited[])
{
    visited[v] = true;
    cout << v << endl;

    vector<int>::iterator it;
    for (it = adj[v].begin(); it != adj[v].end(); ++it)
        if (!visited[*it])
            DFS_run(*it, visited);
}

void Graph::DFS(int v)
{

    bool* visited = new bool[V];
    for (int i = 0; i < V; i++)
        visited[i] = false;
 
    DFS_run(v, visited);
}
 
int main()
{
	int v, e;
	int start, to, from;
	
	cin >> v >> e;
	Graph g(v);
	for(int i=0; i<e; ++i){
		cin >> to >> from;
		g.addEdge(to, from);
	}
	cin >> start;
    g.DFS(start);
 
    return 0;
}
