#include <iostream> 
#include <list> 
#include <vector>
using namespace std;
//DS last lab 12 dfs
// Chunsu Kim 201624458
// 2020-12-02
//Thank you for teaching DS course. 
class Edge {
public:
    int src, dst;
};

class Graph
{
    int sz;    
    vector<list<int>> adjlist;    
    void DFS_util(int v, bool visited[]); 
    int start;
public:
    Graph(int n, vector <Edge>& edges) :sz(n) {
        adjlist->resize(sz);
        for (Edge& e : edges) { //edges�� �ִ� Edge �Ӽ��� e�� for������
            adjlist[e.src].push_back(e.dst);
            adjlist[e.dst].push_back(e.src);
        }
    }
    Graph(int n)
    {
        sz = n;
        //&(adjlist) = new list<int>[n];
    }
    void addEdge(int v, int w) {
        adjlist[v].push_back(w);
    }
     void getStart(int b) {
         start = b;
     }
    void DFS()
    {
         bool* visited = new bool[sz];
         for (int i = 0; i < sz; i++)
             visited[i] = false;

         for (int i = 0; i < sz; i++)
             if (visited[i] == false)
               DFS_util(i, visited);
    }
    ostream& print(ostream& out = cout) {
        for (int i = 0; i < sz; i++) {
            auto lst = adjlist[i];
            out << i << ": ";
            for (auto p = lst.begin(); p != lst.end(); p++)
                out << *p << endl;
        }
        return out;
    }
};

void Graph::DFS_util(int v, bool visited[])
{
    visited[v] = true;
    cout << v << " ";
    for (int i = 0; i < sz; i++) {
        auto lst = adjlist[i];
        for (auto i = adjlist[v].begin(); i != adjlist[v].end(); ++i)
            if (!visited[*i])
                DFS_util(*i, visited);
    }
}

int main()
{
    int n, m;
    cin >> n >> m;
    Graph gdfs(n);
    
    for (int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        gdfs.addEdge(x, y);
    }
 
    int b;
    cin >> b;
    gdfs.getStart(b);
    gdfs.DFS();
    gdfs.print(cout);

    return 0;
}