#include <iostream>
#include <vector>
#include <list>

using namespace std;

class Edge {
public:
    int src, dst;
};

class Graph {
    int sz; //number of nodes
    vector<list<int>> adjlist;
public:
    Graph(int n, vector<Edge> &edges) : sz(n) { //&는 값 복사를 방지하는데 사용
        adjlist.resize(sz);
        for (Edge &e: edges) {
            adjlist[e.src].push_back(e.dst);
            adjlist[e.dst].push_back(e.src);
        }
    }

    ostream& DFS(int start, bool arr[], ostream &out=cout) {
        if(arr[start]){
            return out;
        }
        
        arr[start] = true;
        out << start << endl;
        auto lst = adjlist[start];
        for (auto p = lst.begin(); p != lst.end(); p++) {
            int next = *p;
            DFS(next, arr, out);
        }
        return out;
    }
};

int main() {
    int node = 0;
    int edge = 0;
    int start = 0;
    
    cin >> node >> edge;

    vector<Edge> edges;
    edges.reserve(edge);
    Edge *input = new Edge[edge];
    bool *visit = new bool[node];

    for (int i=0; i<edge; i++) {
        cin >> input[i].src;
        cin >> input[i].dst;
        edges.push_back(input[i]);
    }

    for (int i=0; i<node; i++) {
        visit[i] = false;
    }

    Graph g(node, edges);

    cin >> start;
    g.DFS(start,visit,cout);
    
    return 0;
}
