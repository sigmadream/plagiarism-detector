#include <iostream>
#include <string>
using namespace std;

bool a[10000][10000];
bool chk[10000];

int main() {
	int n,k,b;
	int i;
	
	cin >> n >> k;
	
	for(i=0; i<k; i++) {
		int s,t;
		cin >> s >> t;
		a[s][t] = 1;
		a[t][s] = 1;
		chk[s]=1;
		chk[t]=1;
	}
		
	cin >> b;
	cout << b;
	
	int count = 0;
	int index = b;
	chk[b] = 0;
	
	while(count<n) {
		for(i=0;i<n;i++) {
			if(a[index][i] && chk[i]) {
				cout << endl << i;
				a[index][i] = 0;
				a[i][index] = 0;
				chk[i] = 0;
				index = i;				
				break;
			}
		}
		
		if(i==n) {
			for(i=0;i<n;i++) {
				if(chk[i]) {
					cout << endl << i;
					chk[i] = 0;
					index = i;
					break;
				}
			}
		}
		
		count++;
	}
	
	return 0;
}
