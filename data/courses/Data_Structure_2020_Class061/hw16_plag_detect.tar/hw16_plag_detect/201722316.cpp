#include <iostream>
#include <vector>
#include <list>
#include <algorithm>

using namespace std;

class Edge
{
public:
    int src, dst;
};

class Graph
{
    vector<list<int>> adjlist;
    vector<int> usednum;

public:
    explicit Graph(int size)
    {
        adjlist.resize(size);
    }
    void Insert(int src, int dst)
    {
        adjlist[src].push_back(dst);
        adjlist[dst].push_back(src);
    }
    ostream &Print(int first, ostream &out = cout)
    {
        int now;
        out << first << endl;
        usednum.push_back(first);
        now = adjlist[first].front();
        adjlist[first].pop_front();
        while (true)
        {
            if (!(find(usednum.begin(), usednum.end(), now) != usednum.end()))
            {
                out << now << endl;
                usednum.push_back(now);
            }
            int b = adjlist[now].front();
            while (true)
            {
                if (!(find(usednum.begin(), usednum.end(), adjlist[now].front()) != usednum.end()))
                {
                    break;
                }
                adjlist[now].push_back(adjlist[now].front());
                adjlist[now].pop_front();
                if (adjlist[now].front() == b)
                    break;
            }
            int temp_data = now;
            now = adjlist[temp_data].front();
            if (adjlist[now].empty())
                break;
            adjlist[temp_data].pop_front();
        }
        return out;
    }
};

int main()
{
    int size, edgenum;
    cin >> size;
    cin >> edgenum;
    Graph NumGragh(size);
    int num1, num2;
    for (int i = 0; i < edgenum; i++)
    {
        cin >> num1;
        cin >> num2;
        NumGragh.Insert(num1, num2);
    }
    int firstnum;
    cin >> firstnum;
    NumGragh.Print(firstnum);
    return 0;
}
