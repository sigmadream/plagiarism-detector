#include <iostream>
#include <vector>
#include <list>
using namespace std;

class Edge {
public:
    int src, dst;
};

class Graph {
    int sz;
    vector<list<int>> adjlist;
    bool *check;
public:
    Graph(int n, vector<Edge> &edges) : sz(n) {
        adjlist.resize(sz);
        for (Edge &e: edges) {
            adjlist[e.src].push_back(e.dst);
            adjlist[e.dst].push_back(e.src);
        }
        check = new bool[n];
        for (int i = 0; i < n; i++) {
            check[i] = false;
        }
    }

    ostream& DFS(int index, ostream &os = cout) {
        os << index << endl;
        check[index] = true;

        list<int>::iterator iter;
        for (iter = adjlist[index].begin(); iter != adjlist[index].end(); ++iter) {
            int next = *iter;

            if (check[next] == false)
                DFS(next);
        }

        return os;
    }
};

int main() {
    int n, k;
    cin >> n >> k;
    vector<Edge> edges(k);
    for (int i = 0; i < k; i++) {
       cin >> edges[i].src >> edges[i].dst;
    }
    int b;
    cin >> b;
    Graph graph(n, edges);
    graph.DFS(b);
    return 0;
}