#include <iostream>
#include <vector>
#include <list>

using namespace std;

class Edge {
public:
  int src, dst;
};

class Graph {
  int sz;
  vector<list<int>> adjlist;
public:
  Graph(int n, vector<Edge> &edges) : sz(n) {
    adjlist.resize(sz);
    for (Edge &e: edges) {
    adjlist[e.src].push_back(e.dst);
    adjlist[e.dst].push_back(e.src);
    }
  }

  void Traverseal(int key, bool visited[]){
    visited[key]=true;
    cout<<key<<endl;
    list<int>::iterator i;
    for(i=adjlist[key].begin(); i!=adjlist[key].end();++i)
        if(!visited[*i])
            Traverseal(*i, visited);
  }

  void GetTraversal(int key){
    bool* visited = new bool[key];
    for (int i = 0; i < key; i++)
      visited[i] = false;
    Traverseal(key, visited);
  }

};

int main() {
  int n = 0;
  int k=0;
  int source,target;
  cin>>n>>k;
  vector<Edge> edges;

  for(int i = 0 ; i < k; i ++){
    cin>>source>>target;
    edges.push_back({source,target});
  }
  Graph g(n, edges);

  int startPoint;
  cin>>startPoint;
  g.GetTraversal(startPoint);

}
