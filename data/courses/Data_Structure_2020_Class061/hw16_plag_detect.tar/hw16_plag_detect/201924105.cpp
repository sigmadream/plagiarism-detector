#include <iostream>
#include <vector>
#include <list>

using namespace std;

class Edge {
public:
  int src, dst;
  Edge(int s, int d): src(s), dst(d) {}
};

class Graph {
  int sz;
  bool *visited;
  vector<list<int>> adjlist;
public:
  Graph(int n, vector<Edge> &edges) : sz(n) {
    adjlist.resize(sz);
    for(Edge &e: edges) {
      adjlist[e.src].push_back(e.dst);
      adjlist[e.dst].push_back(e.src);
    }
    visited = new bool[sz];
    for(int i=0; i<sz; i++)
      visited[i] = false;
  }
  ~Graph() {
    delete[] visited;
  }

  void DFS(int v) {
    visited[v] = true;
    Print(v, cout);
    auto lst = adjlist[v];
    int u;
    for(auto p = lst.begin(); p != lst.end(); p++) {
      if(visited[*p] == false) {
        u = *p;
        DFS(u);
      }
    }
  }
  ostream& Print(int v, ostream &out=cout) {
    out << v << endl;
    return out;
  }
  ostream& Print(ostream &out=cout) {
    for (int i = 0; i < sz; i++) {
      auto lst = adjlist[i];
      out << i << ": ";
      for (auto p = lst.begin(); p != lst.end(); p++)
        out << *p << "->";
      out << "//" << endl;
    }
    return out;
  }
};

int main() {
  int n, k, s, d, b;
  cin >> n >> k;
  vector<Edge> edges;
  for(int i=0; i<k; i++) {
    cin >> s >> d;
    edges.push_back(Edge(s, d));
  }
  Graph g(n, edges);
  cin >> b;
  g.DFS(b);
}
