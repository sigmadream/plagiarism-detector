#include <iostream>
#include <vector>
#include <list>

using namespace std;
class Node{
private:
    int data;
    Node* next;
public:
    Node(){};
    Node(int d, Node *p): data(d), next(p) {}
    friend class Queue;
};

class Queue{
private:
    Node* fst;

public:
    void Insert(int n){
        Node *prev = fst;
        fst = new Node(n, prev);
    }

    bool Empty(){
        return fst == nullptr;
    }

    int Delete(){
        int value = fst->data;
        cout << fst->data << endl;
        Node *temp = new Node;
        temp = fst->next;
        delete fst;
        fst = temp;
        return value;
    }

    friend class Graph;
};

class Edge {
public:
    int src, dst;
};

class Graph {
private:
    int sz;
    vector<list<int>> adjlist;
    bool* visited;
    Queue* queue;
public:
    Graph(int n, vector<Edge> &edges) : sz(n) {
        adjlist.resize(sz);
        for (Edge &e: edges) {
            adjlist[e.src].push_back(e.dst);
            adjlist[e.dst].push_back(e.src);
    }
    }

    void BFS(int v) {
    visited = new bool[sz];
    for (int i = 0 ;i < sz ; i++){
        visited[i]=false;
    }

    queue = new Queue;
    queue->Insert(v);
    visited[v]=true;
    while (queue->Empty()!=true) {
        v = queue->Delete();
        auto lst = adjlist[v];
        for(auto w = lst.end(); w != lst.begin(); ) {
            w--;
            if (visited[*w]==false) {
                queue->Insert(*w);
                visited[*w]=true;
            }
        }
    }
    delete[] visited;
    }

};


int main() {
    int n , k , v1 , v2 , p;
    vector<Edge> edges;
    cin >> n >> k;
    for (int i = 0 ; i < k ; i++){
        cin >> v1 >> v2;
        edges.push_back({v1,v2});
    }
    Graph g(n, edges);
    cin >> p ;
    g.BFS(p);
}
