/*20201130
충남과학고등학교 26기 informatica
윤성배, 권승원, 이힘찬
terryaccount@cnsh.hs.kr*/
 
/*상하좌우 1~4 각눈 깜기 5, 무시 0*/
#include <iostream>
#include <time.h>
#define _CRT_SECURE_NO_WARNINGS
 
//<OpenCV Include>
#include <opencv2/opencv.hpp> 
#include <opencv2\core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
//</OpenCV Include>
 
#include <stdio.h>
#include <Windows.h> //콘솔 지우기 용 윈도우 헤더
#include <algorithm> //max, min 함수 사용용
#include <tchar.h>
#include <string>
#include "SerialClass.h"
 
//<패턴인식 관련 값 설정> 
#define boundarySize 100 //중심점으로부터 눈동자 검출하는 영역의 크기
#define EMupSize 20
#define EMdownSize 13 
#define EMleftSize 13
#define EMrightSize 20
#define shutPxThresh 10
#define cStart 40 
#define cropFactor 3
#define patDurThx 5
 
//<패턴 인식 관련>
 
 
#define FF 1
#define BB 2
#define LL 3
#define RR 4
 
#define TL 5
#define TR 6
 
#define STOP 0
//end
 
 
using namespace cv;
using namespace std;
 
//눈동자 좌표 출력 어레이
char xLsize[64];
char yLsize[64];
char cLsize[64];
 
char xRsize[64];
char yRsize[64];
char cRsize[64];
 
char dxRV[64];
char dyRV[64];
//end
 
int patL =0, patR =0, patDur =0;
 
int prevIn =0;//직전 패턴
 
//<눈 크롭 관련>
int hxL =100;//0
int hyL =300;//0
int lxL =200;//480
int lyL =400;//680
 
int hxR =250;//0
int hyR =250;//0
int lxR =350;//680
int lyR =350;//480
//</눈 크롭 관련>
 
Serial* SP;
 
 
int init(){//초기화
	SP =new Serial("\\\\.\\COM17");//Port allocation needed when run
 
	if (SP->IsConnected()){
		printf("Connection Established\n");
		return 0;
	}
 
	else {
		printf("Connection Failed\n");
		return 1;
	}
	return 0;
}
 
void send_Serial(const char msg[]){
	SP->WriteData(msg, sizeof(msg));
}
 
 
 
 
int main()
{
 
	//왼눈
	Mat img_uncutL;//카메라로 입력받은 영상 
	Mat img_colorL;//적정 크기로 자른 영상
	Mat img_convertL;//그레이 스케일 변환 영상
	Mat img_thresholdL;//바이너리 스케일 변환 영상
 
 
	//오른눈
	Mat img_uncutR;
	Mat img_colorR;
	Mat img_convertR;
	Mat img_thresholdR;
 
	//결과
	//Mat runResult;
 
	//비디오 캡쳐 초기화
	VideoCapture capL(0);
	VideoCapture capR(1);
 
 
 
	if (!(capL.isOpened()&& capR.isOpened())){
		cerr <<"에러 - 카메라를 열 수 없습니다.\n";
		return -1;
	}
 
	capL.read(img_uncutL);
	capR.read(img_uncutR);
 
	if (img_uncutL.empty()|| img_uncutR.empty()){
		cerr <<"빈 영상이 캡쳐되었습니다.\n";
		return -2;
	}
 
	//자르기전 크기 저장
	int uch = img_uncutR.rows;
	int ucw = img_uncutR.cols;
 
	printf("%d %d\n", uch, ucw);
 
 
	int i, j;
	int xL =0, yL =0, numL =0, dxL =0, dyL =0;//눈동자의 x좌표, y좌표, 왼쪽 눈 검은 픽셀 수, x축 이동 픽셀수, y 축 이동 픽셀수
	int xR =0, yR =0, numR =0, dxR =0, dyR =0;
	int b;
	int xLm, yLm, xRm, yRm;//각 눈동자의 중심으로 추정되는 위치
 
	int curPatL =0, curPatR =0, curPatTot =0;//왼눈 입력패턴, 오른눈 입력패턴, 최종 입력패턴
 
	int prevPat =0, curPat =0;//이전 패턴, 지금 패턴
 
	int imgCnt =0;
 
	namedWindow("ValuesL");
	namedWindow("ValuesR");
	createTrackbar("hxL", "ValuesL", &hxL, ucw);
	createTrackbar("hyL", "ValuesL", &hyL, uch);
	createTrackbar("lxL", "ValuesL", &lxL, ucw);
	createTrackbar("lyL", "ValuesL", &lyL, uch);
 
	createTrackbar("hxR", "ValuesR", &hxR, ucw);
	createTrackbar("hyR", "ValuesR", &hyR, uch);
	createTrackbar("lxR", "ValuesR", &lxR, ucw);
	createTrackbar("lyR", "ValuesR", &lyR, uch);
 
	init();
 
	while (1)//infinite Loop
	{
 
 
		//<Clear by frame>
        long long int timeS, timeE, timeT;
		timeS =clock();
		xL =0, yL =0, numL =0, dxL =0, dyL =0;
		xR =0, yR =0, numR =0, dxR =0, dyR =0;
 
		int curPatL =0, curPatR =0, curPatTot =0;
        //</Clear by frame>
 
		capL.read(img_uncutL);
		capR.read(img_uncutR);
 
		int cxL, cyL, cxR, cyR;
		cxL =((hxL + lxL)/2)- hxL;
		cyL =((hyL + lyL)/2)- hyL;
		cxR =((hxR + lxR)/2)- hxR;
		cyR =((hyR + lyR)/2)- hyR;
 
		//자를 영역의 가로 세로 크기 계산
		int hL = lyL - hyL;
		int wL = lxL - hxL;
		int hR = lyR - hyR;
		int wR = lxR - hxR;
 
		Point BHL(hxL, hyL), BLL(lxL, lyL), BHR(hxR, hyR), BLR(lxR, lyR);
 
		//자를 영역 직사각형 모양으로 지정
		Rect cropRoiL(BHL, BLL);
		Rect cropRoiR(BHR, BLR);
 
 
		transpose(img_uncutL, img_uncutL);
		flip(img_uncutL, img_uncutL, 0);
 
 
		flip(img_uncutR, img_uncutR, 0);
		//카메라를 역방향으로 달았을 경우 화면 반전
 
 
		//</이전에 지정한 영역으로 이미지 자르기>
 
		Mat tempL(img_uncutL, cropRoiL);
		tempL.copyTo(img_colorL);
 
		Mat tempR(img_uncutR, cropRoiR);
		tempR.copyTo(img_colorR);
        //</이전에 지정한 영역으로 이미지 자르기>
 
		// 영상을 화면에 보여줍니다.
		cvtColor(img_colorL, img_convertL, COLOR_BGR2GRAY);//그레이 스케일 변환
		threshold(img_convertL, img_thresholdL, 80, 255, THRESH_BINARY);//바이너리 스케일 변환
 
 
		//모폴로지 연산
		dilate(img_thresholdL, img_thresholdL, Mat(), Point(-1, -1), 1);//팽창
		erode(img_thresholdL, img_thresholdL, Mat(), Point(-1, -1), 1);//풍화
 
		cvtColor(img_colorR, img_convertR, COLOR_BGR2GRAY);
		threshold(img_convertR, img_thresholdR, 80, 255, THRESH_BINARY);
 
		erode(img_thresholdR, img_thresholdR, Mat(), Point(-1, -1), 1);
		dilate(img_thresholdR, img_thresholdR, Mat(), Point(-1, -1), 1);
 
 
		///왼눈 눈동자 위치 얻기
		for (i =0; i < img_thresholdL.cols; i++){//y
			for (j =0; j < img_thresholdL.rows; j++){//x
 
				b = img_thresholdL.at<uchar>(j, i);
 
				if (b ==0){
					xL += i; 
					yL += j;
					numL++;
				}
			}
		}
 
		///오른눈
		for (i =0; i < img_thresholdR.cols; i++){//y
			for (j =0; j < img_thresholdR.rows; j++){//x
 
				b = img_thresholdR.at<uchar>(j, i);
 
				if (b ==0){
					xR += i;
					yR += j;
					numR++;
				}
			}
		}
 
		//<중심점 표시>
 
		Point cxL1(cxL -20, cyL), cxL2(cxL +20, cyL), cyL1(cxL, cyL -20), cyL2(cxL, cyL -20);
		Point cxR1(cxR -20, cyR), cxR2(cxR +20, cyR), cyR1(cxR, cyR -20), cyR2(cxR, cyR -20);
		line(img_colorL, cxL1, cxL2, Scalar(255, 0, 0), 2);
		line(img_colorL, cyL2, cyL1, Scalar(255, 0, 0), 2);
		line(img_colorR, cxR1, cxR2, Scalar(255, 0, 0), 2);
		line(img_colorR, cyR2, cyR1, Scalar(255, 0, 0), 2);
 
		//Point BHL(hxL, hyL), BLL(lxL, lyL), BHR(hxR, hyR), BLR(lxR, lyR);
		rectangle(img_uncutL, BHL, BLL, Scalar(0, 0, 255), 2);
		rectangle(img_uncutR, BHR, BLR, Scalar(0, 0, 255), 2);
        //</중심점 표시>
 
		//왼눈 눈동자 위치 표시
		if (numL >0){
 
			xLm = xL / numL;
			yLm = yL / numL;
			Point ptL1(xLm +20, yLm), ptL2(xLm -20, yLm), ptL3(xLm, yLm +20), ptL4(xLm, yLm -20);
			line(img_colorL, ptL1, ptL2, Scalar(0, 0, 255), 2);
			line(img_colorL, ptL3, ptL4, Scalar(0, 0, 255), 2);
 
			Point ptLP1(xLm +20 + hxL, yLm + hyL), ptLP2(xLm -20 + hxL, yLm + hyL), ptLP3(xLm + hxL, yLm +20 + hyL), ptLP4(xLm + hxL, yLm -20 + hyL);
			line(img_uncutL, ptLP1, ptLP2, Scalar(0, 0, 255), 2);
			line(img_uncutL, ptLP3, ptLP4, Scalar(0, 0, 255), 2);
 
			Point ptLC1(cxL +20 + hxL, cyL + hyL), ptLC2(cxL -20 + hxL, cyL + hyL), ptLC3(cxL + hxL, cyL +20 + hyL), ptLC4(cxL + hxL, cyL -20 + hyL);
			line(img_uncutL, ptLC1, ptLC2, Scalar(255, 0, 0), 2);
			line(img_uncutL, ptLC3, ptLC4, Scalar(255, 0, 0), 2);
 
		}
		else {
 
			xLm = yLm =-1;
		}
 
		///R font
		if (numR >0){
 
			xRm = xR / numR;
			yRm = yR / numR;
			Point ptR1(xRm +20, yRm), ptR2(xRm -20, yRm), ptR3(xRm, yRm +20), ptR4(xRm, yRm -20);
			line(img_colorR, ptR1, ptR2, Scalar(0, 0, 255), 2);
			line(img_colorR, ptR3, ptR4, Scalar(0, 0, 255), 2);
			Point ptRP1(xRm +20 + hxR, yRm + hyR), ptRP2(xRm -20 + hxR, yRm + hyR), ptRP3(xRm + hxR, yRm +20 + hyR), ptRP4(xRm + hxR, yRm -20 + hyR);
			line(img_uncutR, ptRP1, ptRP2, Scalar(0, 0, 255), 2);
			line(img_uncutR, ptRP3, ptRP4, Scalar(0, 0, 255), 2);
 
 
			Point ptRC1(cxR +20 + hxR, cyR + hyR), ptRC2(cxR -20 + hxR, cyR + hyR), ptRC3(cxR + hxR, cyR +20 + hyR), ptRC4(cxR + hxR, cyR -20 + hyR);
			line(img_uncutR, ptRC1, ptRC2, Scalar(255, 0, 0), 2);
			line(img_uncutR, ptRC3, ptRC4, Scalar(255, 0, 0), 2);
 
			line(img_colorR, ptR1, ptR2, Scalar(0, 0, 255), 2);
			line(img_colorR, ptR3, ptR4, Scalar(0, 0, 255), 2);
		}
 
		else {
 
			xRm = yRm =-1;
		}
		if (numL < shutPxThresh){//눈동자 픽셀이 일정 수 아래면 감았다고 판단
 
			printf("왼쪽눈 감음\t");
			curPatL =5;
		}
		else {
 
			curPatL =0;
		}
 
		if (numR > shutPxThresh){
 
			dxR = xRm - cxR;
			dyR = yRm - cyR;
 
			Point xRPoint2 ={150, 40 };
			Point yRPoint2 ={220, 40 };
			putText(img_colorR, dxRV, xRPoint2, 2, 0.5, Scalar::all(255));
			putText(img_colorR, dyRV, yRPoint2, 2, 0.5, Scalar::all(255));
 
			//R Pattern analyze 오른눈 패턴 처리하기
			if (dyR <-EMupSize){
 
				printf("위----Forward----\n");
				curPatR =1;
			}
			else if (dyR > EMdownSize){
 
				printf("아래----Backward----\n");
				curPatR =2;
			}
			else if (dxR > EMrightSize){
 
				printf("오른쪽----Right----\n");
				curPatR =4;
			}
			else if (dxR <-EMleftSize){
 
				printf("왼쪽----Left----\n");
				curPatR =3;
			}
 
			else {//무시
 
				printf("패턴 없음\n");
				curPatR =0;
			}
		}
		else {
 
			printf("깜----STOP----\n");
			curPatR =5;
		}
 
		//total Pattern decision
		if (curPatL ==5 && curPatR ==5){
 
			curPatTot =7;
		}//두눈 다 감았을 때
 
		else if (curPatL ==5){
 
			curPatTot =5;
		}//왼눈만 감았을 때
 
		else if (curPatR ==5){
 
			curPatTot =6;
		}//오른눈만 감았을 때
 
		else if (curPatR >=1 && curPatR <=4){
 
			curPatTot = curPatR;
		}//4방향 중 한방향이 입력되었을 때
 
		else {
 
			curPatTot =0;
		}//아무 패턴도 입력되지 않았을 때
 
        //L img
		imshow("BinL", img_thresholdL);
		imshow("BinR", img_thresholdR);
		imshow("ColorL", img_colorL);
 
		///R img
		imshow("ColorR", img_colorR);
		imshow("uncutL", img_uncutL);
		imshow("uncutR", img_uncutR);
 
		if (waitKey(20)>=0){//Delay
 
		}
		printf("curPat: %d\n", curPatTot);
 
		if (curPatTot == prevIn){
 
			++patDur;
		}//consecutive pattern input length
 
		else {
			patDur =1;
		}
 
		prevIn = curPatTot;//직전 패턴 갱신
 
 
		if (patDur > patDurThx){
 
			patDur =0;
			switch (curPatTot){
 
			case 1:{//위 Channel Up
 
				printf("Channel Up\n");
				SP->WriteData("CU\n", sizeof("CU\n"));
				break;
			}
 
			case 2:{//아래 Channel Down
 
				printf("Channel Down\n");
				SP->WriteData("CD\n", sizeof("CD\n"));
				break;
			}
 
			case 3:{//좌 Sound Decrease
 
				printf("Sound Decrease\n");
				SP->WriteData("SD\n", sizeof("SD\n"));
				break;
			}
 
			case 4:{//우 Sound Increase
 
				printf("Sound Increase\n");
				SP->WriteData("SI\n", sizeof("SI\n"));
				break;
			}
 
			case 5:{//왼눈 감기 Mute/Unmute
 
				printf("Mute/Unmute\n");
				SP->WriteData("M\n", sizeof("M\n"));
				break;
			}
 
			case 6:{//오른눈 감기 OK
 
				printf("OK\n");
				SP->WriteData("O\n", sizeof("O\n"));
				break;
			}
 
			case 7:{//양눈 감기 Power on/off
 
				printf("Power On/Off");
				SP->WriteData("P\n", sizeof("P\n"));
				break;
			}
			}
		}
	}
	return 0;
}
