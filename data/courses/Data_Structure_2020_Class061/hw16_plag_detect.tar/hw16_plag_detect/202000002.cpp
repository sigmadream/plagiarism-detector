//14
/*상하좌우 1~4 각눈 깜기 5, 무시 0*/
#include <iostream>

//<OpenCV Include>
#include <opencv2/opencv.hpp> 
#include <opencv2\core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
//</OpenCV Include>

#include <stdio.h>
#include <Windows.h> //콘솔 지우기 용 윈도우 헤더
#include <algorithm> //max, min 함수 사용용
#include <locale.h> //한글 출력 로케일 설정용
#include <wchar.h> //와이드 캐릭터 출력

//<패턴인식 관련 값 설정> 
#define boundarySize 100 //중심점으로부터 눈동자 검출하는 영역의 크기
#define EMupSize 40 
#define EMdownSize 20 
#define EMleftSize 40
#define EMrightSize 70
#define shutPxThresh 10
#define cStart 40 
#define cropFactor 3
//end

//유니코드 처리 관련 값
#define korBegin 44032 //U+AC00 '가' 한글시작
#define midCase 21
#define botCase 28
//end

using namespace cv;
using namespace std;

//눈동자 좌표 출력 어레이
char xLsize[64];
char yLsize[64];
char cLsize[64];

char xRsize[64];
char yRsize[64];
char cRsize[64];

char dxRV[64];
char dyRV[64];
//end

//한글 처리 완료 결과 저장
wchar_t prcStr[2001];
//end

int patL = 0, patR = 0;

int prevIn = 0; //직전 패턴

int dat = 91;

int K[93][81]; //자체 코드 간 변환
int a[93][2] = {}; //자체코드 유니코드로 변환

int datQue[3]; //0,1,2 초성 중성 종성 자체코드 각각 저장


void init() { //초기화
	int i, j;
	for (i = 0; i <= 90; i++) {
		for (j = 0; j <= 80; j++) {
			K[i][j] = -1;
		}
	}
	K[0][0] = 0; //구분
	K[10][0] = 10; //.
	K[11][0] = 11; //..
	K[12][0] = 12; //ㅓ
	K[13][0] = 13; // ㅕ
	K[14][0] = 14; // ㅗ
	K[15][0] = 15; // ㅛ
	K[16][0] = 16; // ㅔ
	K[17][0] = 17; // ㅖ
	K[18][0] = 18; // ㅚ
	K[20][0] = 20; // ㅣ
	K[21][0] = 21; // ㅏ
	K[22][0] = 22; // ㅑ
	K[23][0] = 23; // ㅐ
	K[24][0] = 24; // ㅒ
	K[30][0] = 30; // ㅡ
	K[31][0] = 31; // ㅜ
	K[32][0] = 32; // ㅠ
	K[33][0] = 33; // ㅟ
	K[34][0] = 34; // ㅝ
	K[35][0] = 35; // ㅞ
	K[40][0] = 40; // ㄱ
	K[41][0] = 41; // ㄲ
	K[42][0] = 42; // ㅋ
	K[50][0] = 50; // ㄴ
	K[51][0] = 51; // ㄹ
	K[52][0] = 52; // ㄷ
	K[53][0] = 53; // ㄸ
	K[54][0] = 54; // ㅌ
	K[60][0] = 60; // ㅅ
	K[61][0] = 61; // ㅆ
	K[62][0] = 62; // ㅈ
	K[63][0] = 63; // ㅉ
	K[64][0] = 64; // ㅊ
	K[70][0] = 70; // ㅇ
	K[71][0] = 71; // ㅁ
	K[72][0] = 72; // ㅎ
	K[73][0] = 73; // ㅂ
	K[74][0] = 74; // ㅍ
	K[75][0] = 75; // ㅃ
	K[77][0] = 77; // ㄳ
	K[78][0] = 78; // ㄵ
	K[79][0] = 79; // ㄶ
	K[80][0] = 80; // ㄺ
	K[81][0] = 81; // ㄾ
	K[82][0] = 82; // ㅀ
	K[83][0] = 83; // ㄻ
	K[84][0] = 84; // ㄼ
	K[85][0] = 85; // ㄿ
	K[86][0] = 86; // ㄽ
	K[87][0] = 87; // ㅄ
	K[88][0] = 88; // ㅢ
	K[89][0] = 89; // ㅘ
	K[90][0] = 90; // ㅙ

	K[10][10] = 11; // ..
	K[10][20] = 12; //ㅓ
	K[10][30] = 14; // ㅗ
	K[11][20] = 13; // ㅕ
	K[11][30] = 15; // ㅛ
	K[12][20] = 16; // ㅔ
	K[13][20] = 17; // ㅖ
	K[14][20] = 18; // ㅚ
	K[14][21] = 89; // ㅘ
	K[14][23] = 90; // ㅙ
	K[20][10] = 21; // ㅏ
	K[20][11] = 22; // ㅑ
	K[21][20] = 23; // ㅐ
	K[22][20] = 24; // ㅒ
	K[30][10] = 31; // ㅜ
	K[30][11] = 32; // ㅠ
	K[30][20] = 88; // ㅢ
	K[31][12] = 34; // ㅝ
	K[31][16] = 35; // ㅞ
	K[31][20] = 33; // ㅟ
	K[40][3] = 41; // ㄲ
	K[40][4] = 42; // ㅋ
	K[50][3] = 51; // ㄹ
	K[50][4] = 52; // ㄷ
	K[52][3] = 53; // ㄸ
	K[52][4] = 54; // ㅌ
	K[60][3] = 61; // ㅆ
	K[60][4] = 62; // ㅈ
	K[62][3] = 63; // ㅉ
	K[62][4] = 64; // ㅊ
	K[70][3] = 71; // ㅁ
	K[70][4] = 72; // ㅎ
	K[71][3] = 73; // ㅂ
	K[71][4] = 74; // ㅍ
	K[73][3] = 75; // ㅃ
	K[40][60] = 77; // ㄳ
	K[50][62] = 78; // ㄵ
	K[50][72] = 79; // ㄶ
	K[51][40] = 80; // ㄺ
	K[51][54] = 81; // ㄾ
	K[51][60] = 86; // ㄽ
	K[51][71] = 83; // ㄻ
	K[51][72] = 82; // ㅀ
	K[51][73] = 84; // ㄼ
	K[51][74] = 85; // ㄿ
	K[73][60] = 87; // ㅄ

	//초성 자음
	a[40][0] = 0; // ㄱ 
	a[41][0] = 1; // ㄲ
	a[50][0] = 2; // ㄴ
	a[52][0] = 3; // ㄷ
	a[53][0] = 4; // ㄸ
	a[51][0] = 5; // ㄹ
	a[71][0] = 6; // ㅁ
	a[73][0] = 7; // ㅂ
	a[75][0] = 8; // ㅃ
	a[60][0] = 9; // ㅅ
	a[61][0] = 10; // ㅆ A_(16)
	a[70][0] = 11; // ㅇ B_(16)
	a[62][0] = 12; // ㅈ C_(16)
	a[63][0] = 13; // ㅉ D_(16)
	a[64][0] = 14; // ㅊ E_(16)
	a[42][0] = 15; // ㅋ F_(16)
	a[54][0] = 16; // ㅌ 10_(16)
	a[74][0] = 17; // ㅍ 11_(16)
	a[72][0] = 18; // ㅎ 12_(16)

	// 중성 모음
	a[21][0] = 0; // ㅏ
	a[23][0] = 1; // ㅐ
	a[22][0] = 2; // ㅑ
	a[24][0] = 3; // ㅒ
	a[12][0] = 4; //ㅓ
	a[16][0] = 5; // ㅔ
	a[13][0] = 6; // ㅕ
	a[17][0] = 7; // ㅖ
	a[14][0] = 8; // ㅗ
	a[89][0] = 9; // ㅘ
	a[90][0] = 10; // ㅙ A_(16)
	a[18][0] = 11; // ㅚ B_(16)
	a[15][0] = 12; // ㅛ C_(16)
	a[31][0] = 13; // ㅜ D_(16)
	a[34][0] = 14; // ㅝ E_(16)
	a[35][0] = 15; // ㅞ F_(16)
	a[33][0] = 16; // ㅟ 10_(16)
	a[32][0] = 17; // ㅠ 11_(16)
	a[30][0] = 18; // ㅡ 12_(16)
	a[88][0] = 19; // ㅢ 13_(16)
	a[20][0] = 20; // ㅣ 14_(16)

	//종성 자음
	a[40][1] = 1; // ㄱ
	a[41][1] = 2; // ㄲ
	a[77][1] = 3; // ㄳ
	a[50][1] = 4; // ㄴ
	a[78][1] = 5; // ㄵ
	a[79][1] = 6; // ㄶ
	a[52][1] = 7; // ㄷ
	a[51][1] = 8; // ㄹ
	a[80][1] = 9; // ㄺ
	a[83][1] = 10; // ㄻ
	a[84][1] = 11; // ㄼ
	a[86][1] = 12; // ㄽ
	a[81][1] = 13; // ㄾ
	a[85][1] = 14; // ㄿ
	a[82][1] = 15; // ㅀ
	a[71][1] = 16; // ㅁ
	a[73][1] = 17; // ㅂ
	a[87][1] = 18; // ㅄ
	a[60][1] = 19; // ㅅ
	a[61][1] = 20; // ㅆ
	a[70][1] = 21; // ㅇ
	a[62][1] = 22; // ㅈ
	a[64][1] = 23; // ㅊ
	a[42][1] = 24; // ㅋ
	a[54][1] = 25; // ㅌ
	a[74][1] = 26; // ㅍ
	a[72][1] = 27; // ㅎ

	setlocale(LC_ALL, "korean");
}



int main()
{
	//왼눈
	Mat img_uncutL; //카메라로 입력받은 영상 
	Mat img_colorL; //적정 크기로 자른 영상
	Mat img_convertL; //그레이 스케일 변환 영상
	Mat img_thresholdL; //바이너리 스케일 변환 영상


	//오른눈
	Mat img_uncutR;
	Mat img_colorR;
	Mat img_convertR;
	Mat img_thresholdR;


	//비디오 캡쳐 초기화
	VideoCapture capL(0);
	VideoCapture capR(1);

	if (!(capL.isOpened() && capR.isOpened())) {
		cerr << "에러 - 카메라를 열 수 없습니다.\n";
		return -1;
	}

	capL.read(img_uncutL);
	capR.read(img_uncutR);

	if (img_uncutL.empty() || img_uncutR.empty()) {
		cerr << "빈 영상이 캡쳐되었습니다.\n";
		return -2;
	}

	//자르기전 크기 저장
	int uch = img_uncutL.rows;
	int ucw = img_uncutL.cols;

	//자를 영역의 가로 세로 크기 계산
	int h = ((double)(cropFactor - 2) / cropFactor) * uch;
	int w = ((double)(cropFactor - 2) / cropFactor) * ucw;

	//자를 영역 직사각형 모양으로 지정
	Rect cropRoi(ucw / cropFactor, uch / cropFactor, ucw / cropFactor + w, uch / cropFactor + h);


	/*
	눈동자 중심점 좌표를 저장하는 변수
	초기값은 프레임의 정중앙*/
	int cxL, cyL, cxR, cyR;
	cxL = h / 2;
	cyL = w / 2;
	cxR = h / 2;
	cyR = w / 2;

	int i, j;
	int xL = 0, yL = 0, numL = 0, dxL = 0, dyL = 0; //눈동자의 x좌표, y좌표, 왼쪽 눈 검은 픽셀 수, x축 이동 픽셀수, y 축 이동 픽셀수
	int xR = 0, yR = 0, numR = 0, dxR = 0, dyR = 0;
	int b;
	int xLm, yLm, xRm, yRm; //각 눈동자의 중심으로 추정되는 위치

	int curPatL = 0, curPatR = 0, curPatTot = 0; //왼눈 입력패턴, 오른눈 입력패턴, 최종 입력패턴

	int prevPat = 0, curPat = 0; //이전 패턴, 지금 패턴

	int lcnt = 0, cnt = 0; //지금까지 입력한 글자 수, 한 글자에서 지금까지 입력한 음운 수

	init(); //초기화

	while (1) //무한반복
	{
	re:
		xL = 0, yL = 0, numL = 0, dxL = 0, dyL = 0;
		xR = 0, yR = 0, numR = 0, dxR = 0, dyR = 0;

		int curPatL = 0, curPatR = 0, curPatTot = 0;

		//프레임마다 초기화

		// 카메라로부터 캡쳐한 영상을 frame에 저장합니다.
		capL.read(img_uncutL);
		capR.read(img_uncutR);

		//imshow("unCutR", img_uncutR);
		//flip(img_colorL, img_uncutL, 0);
		//flip(img_colorR, img_uncutR, 0);
		//카메라를 역방향으로 달았을 경우 화면 반전


		//이전에 지정한 영역으로 이미지 자르기
		Mat tempL(img_uncutL, cropRoi);
		tempL.copyTo(img_colorL);

		Mat tempR(img_uncutR, cropRoi);
		tempR.copyTo(img_colorR);

		// 영상을 화면에 보여줍니다.
		cvtColor(img_colorL, img_convertL, COLOR_BGR2GRAY); //그레이 스케일 변환
		threshold(img_convertL, img_thresholdL, 80, 255, THRESH_BINARY); //바이너리 스케일 변환


		//모폴로지 연산
		dilate(img_thresholdL, img_thresholdL, Mat(), Point(-1, -1), 5); //팽창
		erode(img_thresholdL, img_thresholdL, Mat(), Point(-1, -1), 5); //풍화

		cvtColor(img_colorR, img_convertR, COLOR_BGR2GRAY);
		threshold(img_convertR, img_thresholdR, 80, 255, THRESH_BINARY);

		dilate(img_thresholdR, img_thresholdR, Mat(), Point(-1, -1), 5);
		erode(img_thresholdR, img_thresholdR, Mat(), Point(-1, -1), 5);

		///왼눈 눈동자 위치 얻기
		for (i = max(0, cxL - boundarySize); i < min(cxL + boundarySize, h); i++) { //y
			for (j = max(0, cyL - boundarySize); j < min(cyL + boundarySize, w); j++) { //x

				b = img_thresholdL.at<uchar>(i, j);

				if (b == 0) {
					xL += j;
					yL += i;
					numL++;
				}
			}
		}
		///오른눈
		for (i = max(0, cxR - boundarySize); i < min(cxR + boundarySize, h); i++) { //y
			for (j = max(0, cyR - boundarySize); j < min(cyR + boundarySize, w); j++) { //x

				b = img_thresholdR.at<uchar>(i, j);

				if (b == 0) {
					xR += j;
					yR += i;
					numR++;
				}
			}
		}

		//중심점 표시
		Point cxL1(cxL - 20, cyL), cxL2(cxL + 20, cyL), cyL1(cxL, cyL - 20), cyL2(cxL, cyL - 20);
		Point cxR1(cxR - 20, cyR), cxR2(cxR + 20, cyR), cyR1(cxR, cyR - 20), cyR2(cxR, cyR - 20);
		line(img_colorL, cxL1, cxL2, Scalar(255, 0, 0), 2);
		line(img_colorL, cyL2, cyL1, Scalar(255, 0, 0), 2);
		line(img_colorR, cxR1, cxR2, Scalar(255, 0, 0), 2);
		line(img_colorR, cyR2, cyR1, Scalar(255, 0, 0), 2);
		
		//왼눈 눈동자 위치 표시
		if (numL > 0) {
			xLm = xL / numL;
			yLm = yL / numL;
			Point ptL1(xLm + 20, yLm), ptL2(xLm - 20, yLm), ptL3(xLm, yLm + 20), ptL4(xLm, yLm - 20);
			line(img_colorL, ptL1, ptL2, Scalar(0, 0, 255), 2);
			line(img_colorL, ptL3, ptL4, Scalar(0, 0, 255), 2);

			Point xLPoint = { 10, 40 };
			Point yLPoint = { 80, 40 };

			//sprintf_s(xLsize, "X(%d)", xLm);
			//sprintf_s(yLsize, "Y(%d)", yLm);

			putText(img_colorL, xLsize, xLPoint, 2, 0.5, Scalar::all(255));
			putText(img_colorL, yLsize, yLPoint, 2, 0.5, Scalar::all(255));
			
			
			//count++;
		}
		///R font
		if (numR > 0) {
			xRm = xR / numR;
			yRm = yR / numR;
			Point ptR1(xRm + 20, yRm), ptR2(xRm - 20, yRm), ptR3(xRm, yRm + 20), ptR4(xRm, yRm - 20);
			line(img_colorR, ptR1, ptR2, Scalar(0, 0, 255), 2);
			line(img_colorR, ptR3, ptR4, Scalar(0, 0, 255), 2);

			Point xRPoint = { 10, 40 };
			Point yRPoint = { 80, 40 };

			//sprintf_s(xRsize, "X(%d)", xRm);
			//sprintf_s(yRsize, "Y(%d)", yRm);

			putText(img_colorR, xRsize, xRPoint, 2, 0.5, Scalar::all(255));
			putText(img_colorR, yRsize, yRPoint, 2, 0.5, Scalar::all(255));
			
		}


		if (numL < shutPxThresh) { //눈동자 픽셀이 일정 수 아래면 감았다고 판단
			printf("깜");
			curPatL = 5;
		}
		else {
			curPatL = 0;
		}

		if (numR > shutPxThresh) {
			dxR = xRm - cxR;
			dyR = yRm - cyR;

			//sprintf_s(dxRV, "X(%d)", dxR);
			//sprintf_s(dyRV, "Y(%d)", dyR);

			Point xRPoint2 = { 150, 40 };
			Point yRPoint2 = { 220, 40 };
			putText(img_colorR, dxRV, xRPoint2, 2, 0.5, Scalar::all(255));
			putText(img_colorR, dyRV, yRPoint2, 2, 0.5, Scalar::all(255));

			


			//R Pattern analyze 오른눈 패턴 처리하기
			if (dxR > EMleftSize) {
				printf("ㄴ");
				curPatR = 3;
			}
			else if (dxR < -EMrightSize) {
				printf("ㅇ");
				curPatR = 4;
			}
			else if (dyR < -EMupSize) {
				printf("ㄱ");
				curPatR = 1;
			}
			else if (dyR > EMdownSize) {
				printf("ㅅ");
				curPatR = 2;
			}

			else { //무시
				printf("패턴 없음");
				curPatR = 0;
			}
		}
		else {
			printf("깜");
			curPatR = 5;
		}
		printf("dxR:%d dyR:%d\n", dxR, dyR);
		//total Pattern decision
		if (curPatL == 5 && curPatR == 5) {
			curPatTot = 7;
		} //두눈 다 감았을 때

		else if (curPatL == 5) {
			curPatTot = 5;
		} //왼눈만 감았을 때

		else if (curPatR == 5) {
			curPatTot = 6;
		}//오른눈만 감았을 때

		else if (curPatR >= 1 && curPatR <= 4) {
			curPatTot = curPatR;
		} //4방향 중 한방향이 입력되었을 때

		else {
			curPatTot = 0;
		} //아무 패턴도 입력되지 않았을 때

		printf("curPatTot: %d\n", curPatTot);

		if (curPatTot == prevIn) {
			continue;
		} //직전 패턴과 지금 패턴이 같다면 무시

		switch (curPatTot) {
		case 1: { //위 패턴 입력
			if (cnt % 3 == 0 || cnt % 3 == 2) { //자음 입력중이라면
				if (dat == 91) dat = 40; //ㄱ
			}
			else { //모음
				if (dat == 92) dat = 10; //해당 음운을 처음 입력 시작한다면
				else {
					if (K[dat][10] > 0) { //가능한 조합이면
						dat = K[dat][10]; //갱신
					}
					else {
						printf("불가능한 조합입니다.\n");
					}
				}
			}
			break;
		}
		case 2: { //아래 패턴 입력
			if (cnt % 3 == 0 || cnt % 3 == 2) { //자음
				if (dat == 91) dat = 60; //ㅅ
			}
			else { //모음
				printf("불가능한 모음\n");
			}
			break;
		}
		case 3: { //좌 패턴 입력
			if (cnt % 3 == 0 || cnt % 3 == 2) { //자음
				if (dat == 91) dat = 50; //ㄴ
			}
			else { //모음
				if (dat == 92) dat = 30;
				else {
					if (K[dat][30] > 0) {
						dat = K[dat][30];
					}
					else {
						printf("불가능한 조합입니다.\n");
					}
				}
			}
			break;
		}
		case 4: { //우 패턴 입력
			if (cnt % 3 == 0 || cnt % 3 == 2) { //자음
				if (dat == 91) dat = 70; //ㅇ
			}
			else { //모음
				if (dat == 92) dat = 20;
				else {
					if (K[dat][20] > 0) {
						dat = K[dat][20];
					}
					else {
						printf("불가능한 조합입니다.\n");
					}
				}
			}
			break;
		}
		case 5: { //왼눈 감기 획추가
			if (dat >= cStart && dat <= 87) { //자음이면
				if (K[dat][4] > 0) {
					dat = K[dat][4];
				}
				else {
					printf("불가능한 조합입니다.\n");
				}
			}
			else {
				printf("모음에서는 획추가를 사용할 수 없습니다.\n");
			}
			break;
		}
		case 6: { //오른눈 감기 쌍자음
			if (dat >= cStart && dat <= 87) {
				if (K[dat][3] > 0) {
					dat = K[dat][3];
				}
				else {
					printf("불가능한 조합입니다,\n");
				}
			}
			else {
				printf("모음에서는 쌍자음을 사용할 수 없습니다.\n");
			}
			break;
		}
		case 7: { //두눈 모두 감기 구분 입력
			if (dat > 90 && cnt % 3 != 2) {
				printf("초성 혹은 중성을 꼭 입력해주세요.\n");
				goto re;
			}

			datQue[cnt++] = dat;
			printf("구분 입력\n");
			printf("현재 입력 상태:%d\n", dat);

			if (cnt % 3 == 1) dat = 92;
			else dat = 91;
			printf("curdat: %d %d %d\n", datQue[0], datQue[1], datQue[2]); //현재 초중종성 자체코드 출력

			if (cnt == 3) { //한 글자가 완성되면
				cnt = 0;
				//한글 출력
				prcStr[lcnt++] = korBegin + (a[datQue[0]][0] * midCase * botCase) + ((a[datQue[1]][0] - a[datQue[0]][0]) * botCase) + a[datQue[2]][1]; //결과 문자열에 지금 문자 추가
				system("cls"); //콘솔 초기화

				printf("\ncur dat Val: %d %d %d\n", datQue[0], datQue[1], datQue[2]); //현재 초중종성 자체코드 출력
				wprintf(L"%s\n%d\n", prcStr, prcStr[lcnt - 1]); //현재 입력된 글자와 유니코드				
				datQue[0] = datQue[1] = datQue[2] = 0; //초중종성 초기화 출력
			}
			break;
		}
		}

		printf("%d\n", dat); //현재 입력하고 있는 음운의 표시

		//처리된 이미지 출력(왼눈)
		imshow("ColorL", img_colorL);
		//imshow("GrayL", img_convertL);
		//imshow("ThresholdL", img_thresholdL);
		///R img
		imshow("ColorR", img_colorR);
		if (waitKey(20) >= 0) { //f키를 누르면 현위치를 중심점으로 갱신
			printf("pressed\n");
			if (numL && numR) {
				cxL = xLm;
				cyL = yLm;
				cxR = xRm;
				cyR = yRm;
				printf("%d %d %d %d\n", cxL, cyL, cxR, cyR); //갱신된 값 출력
			}
		}
		//imshow("GrayR", img_convertR);
		//imshow("ThresholdR", img_thresholdR);
		prevIn = curPatTot; //직전 패턴 갱신
	}
	//"이미지 크기 세로 : 480 " 
	//"이미지 크기 가로 : 680" 
	//bound 125

	return 0;
}