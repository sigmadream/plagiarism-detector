#include <iostream>

using namespace std;

int visited[10] = {0};
int numOfNode;int numOfEdge;
int maps[10000][10000];

void
init(int v)
{
    for (int i = 0; i < v; i++)
        for (int j = 0; j < v; j++){
            maps[i][j] = 0;
        }
}

void
dfs(int v)
{
    cout << v << endl;
    visited[v] = 0;
    for (int i = 0; i <= numOfEdge; i++){
        if (maps[v][i] && visited[i]){
            dfs(i);
        }
    }
}

void
dfs2(int v)
{
    cout << v << endl;
    visited[v] = 0;
    for (int i = 0; i <= numOfEdge; i++){
        if (maps[v][i] && visited[i]){
            dfs2(i);
        }
    }
}

int
main(int argc, char **argv)
{
    int v1, v2;
    cin >> numOfNode >> numOfEdge;
    init(numOfNode);
    for (int i = 0; i < numOfEdge; i++){
        cin >> v1 >> v2;
        if (v2 == 0){
            v2 = 0;
        }
        maps[v1][v2] = maps[v2][v1] = 1;
        visited[v1] = visited[v2] = 1;
    }
    int startNum;
    cin >> startNum;
    if (startNum != 0){
        dfs2(startNum);
    }else {
        dfs(startNum);
    }
    return 0;
}