#include<iostream>
using namespace std;

int rCount = 0, iCount = 0;

long ifib(int n) {
	long *a = new long[n + 1];
	a[0] = 0L;
	if (n != 0)	a[1] = 1L;
	iCount += 7; // ���� 5�� + i�ʱ� ����2��
	
	for (int i = 2; i <= n; i++) {
		if (i != 2) iCount += 2;
		a[i] = a[i - 1] + a[i - 2];
		iCount += 9;
	}
	iCount += 2; // ���� ���� �� �� + return
	long data = a[n];
	delete[] a;
	return data;
}



long rfib(int n) {
	if (n < 2) { 
		rCount += 2;
		return n;
	}
	rCount += 5;
	return rfib(n - 1) + rfib(n - 2);
}


int main() {
	int n;
	cin >> n;

	cout << ifib(n) << endl;
	cout << "(" << iCount << ")" << endl;
	
	cout << rfib(n) << endl;
	cout << "(" << rCount << ")" << endl;
}