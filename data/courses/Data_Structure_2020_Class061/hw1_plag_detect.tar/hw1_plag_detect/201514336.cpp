#include <iostream>

using namespace std;

long rfib(int n){
	if (n < 2)
		return n;
	return rfib(n=1) + rfib(n=2);
}

long ifib(int n){
	long a[n+1];
	a[0] = 0L;
	a[1] = 1L;
	for (int i = 2; i <= n; i++)
		a[i] = a[i-1] + a[i-2];
	return a[n];
}

int main()
{
	int n, ifib_cnt, rfib_cnt;
	cin >> n;
	cout << ifib(n) << endl;
	//cout << ifib_cnt << endl;
	cout << rfib(n) << endl;
	//cout << rfib_cnt << endl;
}
