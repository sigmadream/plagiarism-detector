#include <iostream>
using namespace std;
int count=0;

long rfib(int n){
	if(n<2){
		count++;
		return n;
	}
	return rfib(n-1)+rfib(n-2);
}

long ifib(int n){
	long a[n+1];
	a[0] = 0L;
	a[1] = 1L;
	for (int i=2; i<=n; i++)
	{	count++;
		a[i] = a[i-1] + a[i-2];
	}
	return a[n];
}

int main(){
	int n;
	cin >>n;
	cout<< ifib(n) << endl;
	cout<< rfib(n) << endl;
	cout<< count << endl;
}
