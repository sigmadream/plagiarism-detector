#include <iostream>

using namespace std;

int op_cnt=0;

long rfib(int n){
	op_cnt++; //if condition
	if(n < 2){
		op_cnt++; // return
		return n;
	}
	op_cnt += 4; // return and plus and function operator
	return rfib(n-1) + rfib(n-2);
}

long ifib(int n){
	long a[n+1]; op_cnt++;
	a[0] = 0L;	op_cnt+=2; // array and assignment
	a[1] = 1L;	op_cnt+=2; // array and assignment
	op_cnt++; //for int i=2;
	for (int i = 2; i <= n; i++){
		a[i] = a[i-1] + a[i-2];
		op_cnt += 2; //for condition
		op_cnt += 7; //assignment and array operator;
	}
	op_cnt++; //for i<=n;
	op_cnt += 2; //return + array operator
	return a[n];
}

int main(){
	int n;
	cin >> n;
	cout << ifib(n) << endl;
	cout << "(" << op_cnt << ")" << endl;
	op_cnt = 0;
	cout << rfib(n) << endl;
	cout << "(" << op_cnt << ")" << endl;
}
