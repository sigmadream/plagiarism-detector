#include <iostream>

 using namespace std;
 int cntnum1, cntnum2 = 0;

long rfib(int n) {
 if (n < 2)
    return n ;
 return rfib(n-1) + rfib(n-2);

}

long ifib(int n) {
 long a[n+1];
 a[0] = 0L;
 a[1] = 1L;
 for (int i = 2; i <= n; i++)
    a[i] = a[i-1] + a[i-2];
 return a[n];
}

int main() {
 int n;
 cin >> n;
 cout << ifib(n) << endl;

 cntnum1 = n + 1;
 cntnum2 = n + cntnum1 ;

 cout << "(" << cntnum1 << ")" << endl;
 cout << rfib(n) << endl;
 cout << "(" << cntnum2 << ")" << endl;
 }
