#include <iostream>

using namespace std;
static int op_cnt;

//ignore the + and = in op_cnt=op_cnt+2; or op_cnt; etc.

long rfib(int n) {
 if (n < 2){   
  op_cnt++;
  op_cnt++;
  return n;
 }
 op_cnt++; // for +
 op_cnt++; // for return
 op_cnt=op_cnt+2; // n-1 and n-2
 return rfib(n-1) + rfib(n-2);
}

long ifib(int n) {
 long a[n+1];
 op_cnt=op_cnt+2;
 a[0] = 0L;   op_cnt=op_cnt+2;   
 a[1] = 1L;   op_cnt=op_cnt+2;
 for (int i = 2; i <= n; i++){
  a[i] = a[i-1] + a[i-2];  
  op_cnt=op_cnt+5;
  op_cnt=op_cnt+3;  // in the for-statement
 }
 op_cnt=op_cnt+2;
 return a[n];
}

int main() {
 int n;
 cin >> n;     op_cnt++;
 cout << ifib(n) << endl; 
 cout << rfib(n) << endl; 
 cout << "(" << op_cnt << ")" << endl;
}
