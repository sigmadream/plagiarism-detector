#include <iostream>

using namespace std;

long rfib(int n) {
	int op_cnt;
	if (n < 2)   
	{
		op_cnt += 2;
		return n;	
	}
	op_cnt += 4;
	cout << "(" << op_cnt << ")" << endl;
	return rfib(n-1) + rfib(n-2);  
}

long ifib(int n) {
	int op_cnt;
	long a[n+1];   
	op_cnt += 2;
	a[0] = 0L;   
	op_cnt += 2;
	a[1] = 1L;   
	op_cnt += 2;
	for (int i = 2; i <= n; i++) 
	{
		op_cnt += 2;
		a[i] = a[i-1] + a[i-2];  
		op_cnt += 7; 
		op_cnt += 1;	
	}
	op_cnt += 2;
	cout << "(" << op_cnt << ")" << endl;
	return a[n]; 
}

int main() {
	int n;
	
	cin >> n;
	cout << ifib(n) << endl; 
	cout << rfib(n) << endl;
	
}


