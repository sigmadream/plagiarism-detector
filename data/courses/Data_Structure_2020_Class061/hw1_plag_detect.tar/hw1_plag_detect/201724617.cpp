#include <iostream>
using namespace std;

int op_cnt; // counting operations.

long rfib(int n) {
	op_cnt += 1; // <
	if (n < 2){
		op_cnt += 1; // return
		return n;
	}
	op_cnt += 4; // -1, -2, +, return
	return rfib(n - 1) + rfib(n - 2);
}

long ifib(int n) {
	long a[n+1];
	a[0] = 0L;
	a[1] = 1L;
	op_cnt += 5; // n+1, index0, =, index1, =
	op_cnt += 2; // i=2, <=
	for (int i = 2; i <= n; i++){
		op_cnt += 2; // <=, ++
		a[i] = a[i - 1] + a[i - 2];
		op_cnt += 7; // index, =, index, -1, +, index, -2
	}
	op_cnt += 2; // return, index
	return a[n];
}

int main() {
	int n;
	cin >> n;
	
	op_cnt = 0;
	cout << ifib(n) << endl;
	cout << "(" << op_cnt << ")" << endl;
	
	op_cnt = 0;
	cout << rfib(n) << endl;
	cout << "(" << op_cnt << ")" << endl;
}
