#include <iostream>

using namespace std;

int count1=0;
int count=0;

long rfib(int n) {
  count1++;
  if (n < 2){
      count1++;
      return n;
  }
    count1++;
    count1++;
    count1++;
    count1++;
  return rfib(n-1) + rfib(n-2);
}

long ifib(int n) {
  count++;
  long a[n+1];
  count++;
  count++;
  a[0] = 0L;
  count++;
  count++;
  a[1] = 1L;
  count++;
  count++;
  count++;

  for (int i = 2; i <= n; i++){
    count++;
    count++;
    count++;
    count++;
    count++;
    count++;
    count++;
    count++;
    count++;
   a[i] = a[i-1] + a[i-2];
   }
  count++;
  return a[n];
}

int main() {
  int n;
  cin >> n;
  cout << ifib(n) << endl;
  cout <<"("<<count<<")"<<endl;
  cout << rfib(n) << endl;
  cout <<"("<<count1<<")"<<endl;
 }
