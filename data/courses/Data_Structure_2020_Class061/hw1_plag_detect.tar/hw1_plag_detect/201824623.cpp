#include <iostream>

using namespace std;

long rfib(int n) {
    if (n < 2)
        return n;
    return rfib(n-1) + rfib(n-2);
    }

long ifib(int n) {
    long a[n+1];
    a[0] = 0L;
    a[1] = 1L;
    for (int i = 2; i <= n; i++)
            a[i] = a[i-1] + a[i-2];
    return a[n];
    }


int main()
{
    int n;
    int op_cntr = 0;
    int op_cnti = 0;
    cin >> n;
    cout << ifib(n) << endl; op_cnti += 9;
    if (n < 2)

    else {
        op_cnti += 9 * (n-1);
        cout << "(" << op_cnti << ")" << endl;
    }


    cout << rfib(n) << endl; op_cntr += 2;
    if (n < 2)
        cout << "(" << op_cntr << ")" << endl;
    else {
        op_cntr += 7 * (n-1);
        cout << "(" << op_cntr << ")" << endl;
    }

}
