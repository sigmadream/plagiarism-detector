#include <iostream>

 using namespace std;
 int countop = 0;

 long rfib(int n) {
	 if (n < 2)
	 {
		 countop += 2;
		 return n;
	 }
		
	
		 
	countop += 5;
	 return rfib(n - 1) + rfib(n - 2);
	
}

 long ifib(int n) {
	 long a[100];
	 a[0] = 0L;
	 a[1] = 1L;
	 countop += 5;
	 for (int i = 2; i <= n; i++)
	 {
		 if (i == 2)
		 {
			 countop += 3;
		 }
		 else
		 {
			 countop += 2;
		 }
		 a[i] = a[i - 1] + a[i - 2];
		 countop += 7;
	 }
	 if (countop == 5)
	 {
		 countop += 3;
	 }
	 else
	 {
		 countop += 2;
	 }
	 countop += 1;
	return a[n];
	
}

 int main() {
	 int n;
	cin >> n;
	cout << ifib(n) << endl;
	cout << '(' << countop << ')' << endl;
	countop = 0;
	cout << rfib(n) << endl;
	cout << '(' << countop << ')' << endl;
}