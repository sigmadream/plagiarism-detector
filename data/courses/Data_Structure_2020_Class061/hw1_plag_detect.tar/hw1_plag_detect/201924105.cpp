#include <iostream>
using namespace std;

int ocnt = 0;

long rfib(int n) {
  ocnt = 0;
  if (n < 2)
  {
    ocnt += 2;
    return n;
  }
  ocnt += 4;
  return rfib(n-1) + rfib(n-2);
}

long ifib(int n) {
  ocnt = 0;
  long a[n+1]; ocnt += 1;
  a[0] = 0L; ocnt += 2;
  a[1] = 1L; ocnt += 2;
  for (int i = 2; i <= n, ocnt += 2; i++, ocnt += 1)
  a[i] = a[i-1] + a[i-2]; ocnt += 5;
  ocnt += 2;
  return a[n];
}

int main() {
int n;
cin >> n;
cout << ifib(n) << endl;
cout << "(" << ocnt << ")" << endl;
cout << rfib(n) << endl;
cout << "(" << ocnt << ")" << endl;
}
