#include <iostream>

using namespace std;

int *a=0;
int *b=0;
long rfib(int n) {
if (n < 2)
    *a+=1;
    return n;
    *a+=2;
    return rfib(n-1) + rfib(n-2);
}

long ifib(int n) {
    long a[n+1];
    *b+=1;
    a[0] = 0L;
    *b+=2;
    a[1] = 1L;
    *b+=2;
    for (int i = 2; i <= n; i++)
    a[i] = a[i-1] + a[i-2];
    *b+=4;
    return a[n];
}

int main() {
    int n;
    cin >> n;
    cout << ifib(n) << endl;
    cout << *b << endl;
    cout << rfib(n) << endl;
    cout << *a << endl;
}
