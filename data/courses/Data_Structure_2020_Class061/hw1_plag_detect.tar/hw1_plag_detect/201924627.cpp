#include <iostream>
using namespace std;

long rfib(int n, int &counter) {
    counter++;
	if(n < 2) {
        counter++;
		return n;
	}
	counter+=4;
	return rfib(n - 1, counter) + rfib(n - 2, counter);
}

long ifib(int n, int &counter) {
	long a[n + 1];  counter++;
	a[0] = 0L;      counter+=2;
	a[1] = 1L;      counter+=2;
	counter+=2;
	for(int i = 2; i <= n; i++) {
        counter+=9;
		a[i] = a[i - 1] + a[i - 2];
	}
	counter+=2;
	return a[n];
}

int main() {
	int n, rcounter = 0, icounter = 0;
	cin >> n;
	cout << ifib(n, icounter) << endl;
	cout << "(" << icounter << ")" << endl;
	cout << rfib(n, rcounter) << endl;
	cout << "(" << rcounter << ")";
	return 0;
}

