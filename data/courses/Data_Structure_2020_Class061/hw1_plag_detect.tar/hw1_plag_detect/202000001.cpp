#include<iostream>

using namespace std;

int rfib_op_cnt = 0;
int ifib_op_cnt = 0;

long rfib(int n) {
    if (n < 2){
        rfib_op_cnt += 2; // n<2 and return
        return n;
    }else{
        rfib_op_cnt += 1; // n < 2
    }
    rfib_op_cnt += 4; // return+1, n-1:+1, n-2:+1, rfib()+rfib(): +1
    return rfib(n-1) + rfib(n-2);
}

long ifib(int n) {
    long a[n+1];
    ifib_op_cnt += 1; //a[n+1]
    a[0] = 0L;
    ifib_op_cnt += 2; //a[0] = 0L
    a[1] = 1L;
    ifib_op_cnt += 2; //a[1] = 1L
    ifib_op_cnt += 2; // int i = 2; i <= n; enter for loop at the 1st time.
    bool isInLoop = false;
    for (int i = 2; i <= n; i++){
        if(isInLoop) {
            ifib_op_cnt += 1; // i <= n;
        }
        else{
            isInLoop = true;
        }
        a[i] = a[i-1] + a[i-2];
        ifib_op_cnt += 7; // a[i] = a[i-1] + a[i-2];
        ifib_op_cnt += 1; // i++
    }
    if(isInLoop){
        ifib_op_cnt += 1; // last i <=n for getting out loop
    }
    ifib_op_cnt += 2; // return with index;
    return a[n];
}

int main()
{
    int n;
    cin >> n;
    cout << ifib(n) << endl;
    cout <<"("<<ifib_op_cnt<<")"<<endl;
    cout << rfib(n) << endl;
    cout <<"("<<rfib_op_cnt<<")"<<endl;
    return 0;
}
