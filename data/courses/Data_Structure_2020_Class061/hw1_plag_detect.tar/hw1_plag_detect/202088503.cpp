#include <iostream>

using namespace std;
int cnt = 0;

inline long rfib(int n)
{
	if(n < 2){
		cnt += 2;
		return n;
	}else{
		cnt += 1;
	}
	cnt += 4;
	return rfib(n - 1) + rfib(n - 2);
}

inline long ifib(int n){
	long a[n+1];		cnt += 1;
	a[0] = 0L;			cnt += 2;
	a[1] = 1L;			cnt += 2;
	for(int i = 2; i <= n; i++){
		a[i] = a[i-1] + a[i-2];
		cnt += 9;
	}
	cnt += 2;
	cnt += 2;
	return a[n];
}

int main(){
	int n;
	cin >> n;
	cout << ifib(n) << endl;
	cout << "(" << cnt << ")" << endl;
	cnt = 0;
	cout << rfib(n) << endl;
	cout << "(" << cnt << ")" << endl;
	return 0;
}