#include <iostream>

using namespace std;

int cur_cnt = 0;
int max_cnt = 0;

int inc(int n) {
    cur_cnt += 3;
    cur_cnt += 1;
    if (cur_cnt > max_cnt)
        max_cnt = cur_cnt;
    return cur_cnt -= 4, n + 1;
}

int add(int a, int b) {
    cur_cnt += 3;
    cur_cnt += 2;
    if (cur_cnt > max_cnt)
        max_cnt = cur_cnt;
    int _rv;
    return a == 0? b: (_rv = add(a - 1, inc(b)), cur_cnt -= 5, _rv);
}

long rfact(int n) {
    return n == 0? 1: n*rfact(n-1);
}

long ifact(int n) {
    long f = 1;
    for (int i = 1; i <= n ; i++)
        f *= i;
    return f;
}

int main() {
    int n;
    cin >> n;
    add(n,n);
    cout << rfact(n) << endl;
    cout << "(" << cur_cnt << ")" << endl;
    cout << ifact(n) << endl;
    cout << "(" << max_cnt << ")" << endl;
}
