#include <iostream>
using namespace std;

int rcur_cnt = 0;
int rmax_cnt = 0;
int icur_cnt = 0;
int imax_cnt = 0;

long rfact(int n) {
	rcur_cnt += 4;
	if (rcur_cnt > rmax_cnt) rmax_cnt = rcur_cnt;
	return  n == 0 ? 1 : n * rfact(n - 1);
}

long ifact(int n) {
	icur_cnt += 4;
	long f = 1;
	icur_cnt += 1;
	for (int i = 1; i <= n; i++) {
		f *= i;
	}
	icur_cnt += 1;  // i�� �� 1����
	if (icur_cnt > imax_cnt) imax_cnt = icur_cnt;
	return f;
}

int main() {
	int n;
	cin >> n;
	cout << rfact(n) << endl;
	cout << "(" <<  rmax_cnt << ")" << endl;
	cout << ifact(n) << endl;
	cout << "(" <<  imax_cnt << ")" << endl;
}