 #include <iostream>

 using namespace std;
int cur_cnt = 0;
int max_cnt = 0;
int cur_cnt2 = 0;
int max_cnt2 = 0;

 int inc(int n) {
 cur_cnt += 3; // for the function call
 cur_cnt += 1; // for the parameter
 if (cur_cnt > max_cnt)
 max_cnt = cur_cnt;
 return cur_cnt -= 4, n + 1;
 }
int add(int a, int b) {
 cur_cnt += 3; // for the function call
 cur_cnt += 2; // for the parameters
 if (cur_cnt > max_cnt)
 max_cnt = cur_cnt;
 int _rv;
 return a == 0? b: (_rv = add(a - 1, inc(b)), cur_cnt -= 5, _rv);
 }


 long rfact(int n) {
 cur_cnt += 3;
 cur_cnt += 1;
 if (cur_cnt > max_cnt)
 max_cnt = cur_cnt;	
 return n == 0? 1: n * rfact(n-1);
 }

 long ifact(int n) {
 cur_cnt2 += 6;


 
 long f = 1;
 for (int i = 1; i <= n; i++)
 f *= i;
 
 if (cur_cnt2 > max_cnt2)
 max_cnt2 = cur_cnt2;
 return f;
 }

 int main() {
 int n;
 cin >> n;
 cout << rfact(n) << endl;
 cout << "(" << max_cnt << ")" << endl;
 cout << ifact(n) << endl;
 cout << "(" << max_cnt2 << ")" << endl;
 }


