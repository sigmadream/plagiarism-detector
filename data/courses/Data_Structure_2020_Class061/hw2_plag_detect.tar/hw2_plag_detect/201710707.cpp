#include <iostream>

using namespace std;

int rcnt;

long rfact(int n) {
	rcnt += 4;
	return n == 0? 1: n * rfact(n-1);
}

long ifact(int n) {
	long f = 1;

	for (int i = 1; i <= n; i++)
		f *= i;
		
	return f;
}

int main() {
	int n;
	cin >> n;
	cout << rfact(n) << endl;
	cout << "(" << rcnt << ")" << endl;
	cout << ifact(n) << endl;
	cout << "(6)" << endl;
}

