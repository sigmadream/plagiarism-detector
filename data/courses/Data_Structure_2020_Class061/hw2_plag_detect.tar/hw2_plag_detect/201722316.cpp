#include <iostream>

using namespace std;
int count = 0;

long rfact(int n)
{
    count += 3; // for the function call
    count += 1; // for the int n
    return n == 0 ? 1 : n * rfact(n - 1);
}

long ifact(int n)
{
    long f = 1;
    count += 3; // for the function call
    count += 3; // for int n, long f, int i
    for (int i = 1; i <= n; i++)
        f *= i;
    return f;
}

int main()
{
    int n;
    cin >> n;
    cout << rfact(n) << endl;
    cout << "(" << count << ")" << endl;
    count = 0;
    cout << ifact(n) << endl;
    cout << "(" << count << ")" << endl;
}