#include <iostream>
using namespace std;

int cur_cnt = 0;
int max_cnt = 0;

long rfact(int n) {
	cur_cnt += 3;
	cur_cnt += 1;
	if (cur_cnt > max_cnt)
		max_cnt = cur_cnt;
	long _rv;
	return n == 0 ? 1 : (_rv = n * rfact(n-1), cur_cnt -= 5, _rv);

}

long ifact(int n) {
	cur_cnt += 3;
	cur_cnt += 3;
	if (cur_cnt > max_cnt)
		max_cnt = cur_cnt;
	long f = 1;
	for (int i = 1; i <= n; i++)
		f *= i;
	return f;
	
}
int main() {
	int n;
	cin >> n;
	cout << rfact(n) << endl;
	cout << "(" << max_cnt << ")" << endl;
	max_cnt = 0;
	cur_cnt = 0;
	cout << ifact(n) << endl;
	cout << "(" << max_cnt << ")" << endl;

}