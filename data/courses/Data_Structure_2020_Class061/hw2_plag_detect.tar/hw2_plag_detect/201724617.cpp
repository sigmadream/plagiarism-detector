#include <iostream>
using namespace std;

int cur_cnt, max_cnt;
// �ϴ� ��� ������ ũ��� 1��.

long rfact(int n){
    cur_cnt += 3; // sp, bp, rv
    cur_cnt += 1; // parameter n
    if(cur_cnt > max_cnt) max_cnt = cur_cnt;
    int _rv;
    return n == 0? 1: (_rv = n * rfact(n-1), cur_cnt -=4, _rv); // free memory.
    // Recursive ver.
}

long ifact(int n) {
    cur_cnt += 3; // sp, bp, rv
    cur_cnt += 1; // parameter n
    long f = 1;
    cur_cnt += 2; // parameter f, i
    for (int i = 1; i <= n; i++)
        f *= i;
    if(cur_cnt > max_cnt) max_cnt = cur_cnt;
    return cur_cnt -= 6, f; // free memory.
    // Just Iterative ver.
}

int main() {
    int n;
    cin >> n;

    cur_cnt = 0; max_cnt = 0;
    cout << rfact(n) << endl;
    cout << "(" << max_cnt << ")" << endl;

    cur_cnt = 0; max_cnt = 0;
    cout << ifact(n) << endl;
    cout << "(" << max_cnt << ")" << endl;
}
