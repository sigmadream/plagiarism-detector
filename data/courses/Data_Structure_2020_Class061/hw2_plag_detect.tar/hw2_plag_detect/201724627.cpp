#include <iostream>

using namespace std;

int rcount=0;
int icount=0;

long rfact(int n) {
  rcount=rcount+4;
  return n == 0? 1: n * rfact(n-1);
}

long ifact(int n) {
  long f = 1;
  icount= icount+6;
  for (int i = 1; i <= n; i++){
  f *= i;
  }
  return f;
}

int main() {
  int n;
  cin >> n;
  cout << rfact(n) << endl;
  cout <<"("<< rcount << ")"<< endl;
  cout << ifact(n) << endl;
  cout <<"("<< icount << ")"<< endl;
}
