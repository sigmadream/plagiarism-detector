#include <iostream>

using namespace std;

long rfact(int n, int *cur, int *max) 
{
	*cur += 3;
	*cur += 1;
	return n == 0? 1: n * rfact(n-1, cur, max);
}

long ifact(int n, int *cur, int *max) 
{
	*cur += 3;
	*cur += 1;
	long f = 1;
	*cur += 2;
	for (int i = 1; i <= n; i++)
	f *= i;
	return f;
}

 int main() 
 {
	int n;
	cin >> n;
	int i_cur_cnt = 0, i_max_cnt = 0;
	int r_cur_cnt = 0, r_max_cnt = 0;
	cout << rfact(n, &r_cur_cnt, &r_max_cnt) << endl;
	cout << "(" << r_cur_cnt << ")" << endl;
	cout << ifact(n, &i_cur_cnt, &i_max_cnt) << endl;
	cout << "(" << i_cur_cnt << ")" << endl;
 }
