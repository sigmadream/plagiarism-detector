#include <iostream>

using namespace std;

int cur_cnt = 0;
int r_max_cnt = 0;
int i_max_cnt = 0;

long rfact(int n) 
{
	cur_cnt += 3; // for the function call
	cur_cnt += 1; // for the parameter
	
	if (cur_cnt > r_max_cnt)
	r_max_cnt = cur_cnt;
	
	int re;
	return n == 0? 1: ( re = n * rfact(n-1), cur_cnt -= 4, re);
}

long ifact(int n) 
{
	cur_cnt += 3; // for the function call
	cur_cnt += 3; // for the parameter
	
	long f = 1;
	for (int i = 1; i <= n; i++)
	f *= i;

	if (cur_cnt > i_max_cnt)
	i_max_cnt = cur_cnt;
	
	return cur_cnt -= 6, f;
}
int main() 
{
	int n;
	cin >> n;
	cout << rfact(n) << endl;
	cout << "(" << r_max_cnt << ")" << std::endl;
	cur_cnt = 0;
	cout << ifact(n) << endl;
	cout << "(" << i_max_cnt << ")" << std::endl;
}
