#include <iostream>

using namespace std;

int cur_cnt = 0;
int max_cnt = 0;

int cur_cnt2 = 0;
int max_cnt2 = 0;

long rfact(int n) {
    cur_cnt2  += 4;

    if(cur_cnt2  > max_cnt2)
        max_cnt2 = cur_cnt2 ;
        
    return cur_cnt2  -=4, n == 0 ? 1 : n * rfact(n-1);
}

long ifact(int n) {
    cur_cnt += 6;
    long f = 1;

    if(cur_cnt > max_cnt)
        max_cnt = cur_cnt;

    for (int i = 1; i <= n; i++)
        f *= i;

    return cur_cnt -= 6, f;
}

int main() {
    int n;
    cin >> n;
    cout << rfact(n) << endl;
    cout << "(" << max_cnt2 << ")" << endl;

    cout << ifact(n) << endl;
    cout << "(" << max_cnt << ")" << endl;

    return 0;
}