#include <iostream>

using namespace std;

int maxcnt = 0;
int curcount = 0;

long rfact(int n)
{
	curcount += 3;
	curcount += 1;

	if (curcount > maxcnt)
	{
		maxcnt = curcount;
	}

	int _rv;
	return n == 0 ? 1 : (_rv = n * rfact(n - 1), curcount -= 4,  _rv);
}

long ifact(int n) 
{
	curcount += 3;
	curcount += 1;
	long f = 1;
	curcount += 2;
	for (int i = 1; i <= n; i++)
	{
		f *= i;
	}
	if (maxcnt < curcount)
	{
		maxcnt = curcount;
	}
	return f;
}

int main() 
{
	int n;
	cin >> n;
	cout << rfact(n) << endl;
	cout << '(' << maxcnt << ')' << endl;
	curcount = maxcnt = 0;
	cout << ifact(n) << endl;
	cout << '(' << maxcnt << ')' << endl;
}
