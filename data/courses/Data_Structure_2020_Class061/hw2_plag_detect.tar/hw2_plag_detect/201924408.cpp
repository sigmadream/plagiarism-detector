#include <iostream>

using namespace std;

int a = 0;
int b= 0;



long rfact(int n) {

    return a+=4,n == 0? 1: n * rfact(n-1);
}

long ifact(int n) {
    long f = 1;
    for (int i = 1; i <= n; i++)
    f *= i;
    return b+=6,f;
}

int main() {
    int n;
    cin >> n;
    cout << rfact(n) << endl;
    cout << "(" << a << ")" << endl;
    cout << ifact(n) << endl;
    cout << "(" << b << ")" << endl;
}
