#include <iostream>

using namespace std;

int rfcnt=0;
int ifcnt=0;

long rfact(int n) {
 rfcnt +=4;
 return n == 0 ? 1: (n*rfact(n-1));
}

long ifact(int n) {
 long f = 1;
 for (int i = 1; i <= n; i++){
  f *= i;
  ifcnt += 4;
 }
 ifcnt += 2;
 return f;
}
int main() {
int n;
cin >> n;
cout << rfact(n) << endl;
cout << "(" << rfcnt << ")" <<endl;
cout << ifact(n) << endl;
cout << "(" << ifcnt << ")" <<endl;
}
