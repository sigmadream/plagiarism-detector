#include <iostream>

using namespace std;

long rfact(int n, int &counter) {
    counter += 4;
    return n == 0? 1: n * rfact(n - 1, counter);
}

long ifact(int n, int &counter) {
    counter+=2;
    long f = 1l; counter+=2;
    counter+=2;
    for(int i = 1; i <= n; i++) {
        f *= i;
    }
    return f;
}

int main()
{
    int n, rcounter = 0, icounter = 0;
    cin >> n;
    cout << rfact(n, rcounter) << endl;
    cout << "(" << rcounter << ")" << endl;
    cout << ifact(n, icounter) << endl;
    cout << "(" << icounter << ")";
    return 0;
}

