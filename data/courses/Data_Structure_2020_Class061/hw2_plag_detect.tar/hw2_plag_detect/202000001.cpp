#include <iostream>

int cur_cnt = 0;
int max_cnt = 0;

using namespace std;

long rfact(int n) {
    cur_cnt += 3;
    cur_cnt += 1;
    if (cur_cnt > max_cnt)
        max_cnt = cur_cnt;
    int _rv;
    return n == 0? 1: (_rv = n * rfact(n-1), cur_cnt -= 4, _rv);
}

long ifact(int n) {
    cur_cnt += 3;
    cur_cnt += 1;
    long f = 1;
    cur_cnt += 1;
    for (int i=1; i <= n; i++)
        f *= i;
    cur_cnt += 1;
    max_cnt = cur_cnt;
    return f;
}

int main() {
    int n;
    cin >> n;
    cout << rfact(n) << endl;
    cout << "(" << max_cnt << ")" << endl;
    cur_cnt = 0;
    max_cnt = 0;
    cout << ifact(n) << endl;
    cout << "(" << max_cnt << ")" << endl;
    return 0;
}
