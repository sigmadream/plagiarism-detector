#include <iostream>

using namespace std;


template<class t>
class Count{
public:
    Count(int a = 0, int b = 0):cur_cnt(a),max_cnt(b){};
    long inc(int n){
        cur_cnt += 3;
        cur_cnt += 1;
        max_cnt += cur_cnt;
        return cur_cnt -= 4;
    }
    long rfact(int n){
        inc(n);
        return n == 0 ? 1  : n * rfact(n - 1);
    }
    long ifact(int n){
        cur_cnt+= 3;
        long f = 1;
        for (int i = 1; i <= n; i++){
            f *= i;
        }
        cur_cnt += 3;
        if (max_cnt < cur_cnt) max_cnt = cur_cnt;
        return f;
    }
    long cur_cnt;
    long max_cnt;

protected:
};





int main(){
    int n;
    Count<int> *c = new Count<int>();
    cin >> n;
    cout << c ->rfact(n) << endl;
    cout << "(" << c -> max_cnt << ")"<< endl;
    c -> cur_cnt = 0;c -> max_cnt  = 0;
    cout << c -> ifact(n)<< endl;
    cout << "(" << c -> max_cnt << ")"<< endl;
}