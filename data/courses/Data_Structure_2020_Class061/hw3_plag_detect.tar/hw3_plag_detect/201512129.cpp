#include <iostream>
#include <sstream>
#include <vector>
using namespace std;

class Term{
private:
    int coep;
    int exp;
public:
    Term() {}
    Term(int coep, int exp) : coep(coep), exp(exp) {}
    ~Term() {}
    int getCoep() {return coep;}
    int getExp() {return exp;}
    void setCoep(int input) {coep += input;}
    Term operator+(Term&);
};

Term Term :: operator+(Term& t){
    int tmpCoep = getCoep() * t.getCoep();
    int tmpExp = getExp() + t.getExp();
    Term newTerm = Term(tmpCoep, tmpExp);
    return newTerm;
}

class Polynomial {
private:
    vector<Term> polynomial;
    int maxExp;
    int size;
public:
    Polynomial(vector<Term> array){
        maxExp = array.back().getExp();
        polynomial = array;
        size = array.size();
    }
    ~Polynomial() {}
    int getmaxExp() {return maxExp;}
    int getSize() {return size;}
    Polynomial operator* (Polynomial& p);
    friend ostream& operator<<(ostream&, Polynomial&);
};

Polynomial Polynomial :: operator*(Polynomial& p){
    int max = maxExp + p.getmaxExp() + 1;
    vector<Term> mul(max, Term(0,0));
    for(int i = 0; i < getSize(); i++){
        for(int j = 0 ; j < p.getSize(); j++){
            Term tmpTerm = polynomial[i] + p.polynomial[j];
            int index = tmpTerm.getExp();
            mul[index].setCoep(tmpTerm.getCoep());
        }
    }
    Polynomial result = Polynomial(mul);
    return result;
}

ostream& operator<<(ostream& os, Polynomial& p){
    for(int i = 0 ; i<p.getSize() ; i++) {
        Term tmp = p.polynomial.back();
        cout << tmp.getCoep() << " ";
        p.polynomial.pop_back();
    }
    return os;
}

vector<int> getInput() {
    string stringInput;
    getline(cin, stringInput);
    vector<int> intTmp;
    int tmp;
    istringstream is(stringInput);
    while(is >> tmp) intTmp.push_back(tmp);
    return intTmp;
}

vector<Term> changeToTerm(vector<int> array){
    int arraySize = array.size();
    int exp = 0;
    vector<Term> polynomial;
    while(exp < arraySize) {
        int tmp = array.back();
        if(tmp) {
            Term newTerm = Term(tmp,  exp);
            polynomial.push_back(newTerm);
        }
        array.pop_back();
        exp += 1;
    }
    return polynomial;
}

int main(){
    Polynomial a = Polynomial(changeToTerm(getInput()));
    Polynomial b = Polynomial(changeToTerm(getInput()));
    Polynomial mul = a * b;
    cout << mul;
    return 0;
}