#include <iostream>
using namespace std;
#define MAX_TERMS 20

struct Term
{
        int expn; //����
        float coef; //���
};

void sortPoly(Term term[], int nTerms)
{
        for (int i = 0; i < nTerms; i++)
        {
               for (int j = i; j < nTerms; j++)
               {
                       if (term[i].expn < term[j].expn)
                       {
                              Term temp = term[i];
                              term[i] = term[j];
                              term[j] = temp;
                       }
               }
        }
}

class Polynomial
{
private:
        int nTerms; //����� 0�� �ƴ� ���� ����
        Term term[MAX_TERMS]; //����� 0�� �ƴ� ���� �迭
public:
        Polynomial(){}

        void read()
        {
               cin >> nTerms;
               for (int i = 0; i < nTerms; i++)
               {
                       struct Term temp;
                       cin  >> temp.coef >> temp.expn;
                       term[i] = temp;
               }
        }

        void multi(Polynomial a, Polynomial b)
        {
               struct Term multi;
               for(int i=0 ; i <a.nTerms; i++)
               {
               		for(int i=0 ; i <b.nTerms; i++)
               		{
						
					}
			   }
		}

        void display()
        {
        		sortPoly(term, nTerms);
               cout<<nTerms<< "_";
               for (int i = 0; i < nTerms; i++)
               {
                       cout << term[i].coef;
                       if(term[i].expn)
                              cout<< "_" << term[i].expn;
                       if (i != nTerms - 1)
                              cout << "_";
               }
               cout << endl;
        }
};

int main(void)
{
        Polynomial p1, p2, p3;
        p1.read();
        p2.read();
        
        p3.multi(p1, p2);
        p3.display();
        return 0;
}
