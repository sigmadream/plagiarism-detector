#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

class polynomial{
public:
	polynomial(int* v, int size);
	polynomial(string& poly);
	void operator*(const polynomial A)const;
private:
	vector< pair<int, int> > value;
	int max_degree;
};

polynomial::polynomial(string& a){
	int* arr = new int[100];
	int len = 0;
	
	for(int i=0; i<a.length(); ++i){
		if(a[i] == ' '){
			continue ;
		}
		else if(a[i] == '-'){
			++i;
			arr[len++] = -(a[i] - '0');
		}
		else{
			arr[len++] = a[i] - '0';
		}
	}
	
	max_degree = arr[2];
	
	for(int i=1; i<len; i+=2){
		value.push_back(make_pair(arr[i], arr[i+1]));
	}
	
}

void polynomial::operator*(const polynomial A)const{
	int len = this->max_degree + A.max_degree + 1;
	int* arr = new int[len];
	int not_zero=0;
	
	for(int i=0; i<len; ++i)
		arr[i] = 0;
	
	for(int i=0; i<this->value.size(); ++i){
		for(int j=0; j<A.value.size(); ++j){
			
			int degree = value[i].second + A.value[j].second;
			int coef = value[i].first * A.value[j].first;
			
			arr[degree] += coef;
		}
	}
	
	for(int i=0; i<len; ++i){
		if(arr[i] != 0)
			not_zero++;
	}
	cout << not_zero << ' ';
	
	for(int i=len-1; i>=0; --i){
		if(arr[i] != 0 && not_zero > 1){
			cout << arr[i] << ' ' << i << ' ';
			not_zero--;
		}
		else if(arr[i] != 0 && not_zero == 1){
			cout << arr[i] << ' ' << i;
		}
	}
}

int main(void) 
{ 
	char a[100];
	char b[100];
	int c;
	int i=0;
	
	while(1){
		c = getchar();
		if(c == '\n') break;
		a[i++] = c;
	}
	a[i] = 0;
	i=0;
	
	while(1){
		c = getchar();
		if(c == '\n') break;
		b[i++] = c;
	}
	b[i] = 0;
	
	string str1(a);
	string str2(b);
	
	polynomial p1(str1);
	polynomial p2(str2);
	
	p1*p2;
	
    return 0; 
} 
