/*
 *	author: 201624458 Chunsu Kim
 *  date: 2020-09-23
*/
#include <iostream>
using namespace std;
class Polynomial {
public:
	Polynomial() {
		mine = new int[100];
	}
	Polynomial(int *x, int length) {
		mine = new int[length];
		for (int i = 0; i < length; i++)
			mine[i] = x[i];
	}
	Polynomial operator+(Polynomial y) {
		int m = sizeof(mine) / sizeof(int);
		int n = sizeof(y) / sizeof(int);
		if (m == n) { //x^2-1 (2,0,-1) and x^2+x-1 (1,1,-1)
			for (int i = 0; i < m; i++) {
				mine[i] += y.mine[i];
			}
		}
		else if(m>n) {
			for (int i = m - n; i < m; i++) {
				mine[i] += y.mine[i];
			}
		}
		else {		//ignore big bit
			for (int i = n - m; i < n; i++) {
				mine[i] += y.mine[i];
			}
		}
	}
	Polynomial operator*(Polynomial y) {
		int m = sizeof(mine) / sizeof(int);
		int n = sizeof(y) / sizeof(int);
		if (m >= n) { //x^2-1 (2,0,-1) and x^2+x-1 (1,1,-1)
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					mine[i] *= y.mine[j];
				}
			}
		}
		else {
			for (int i = 0; i < n;i++) {
				for (int j = 0; j < m; j++) {
					y.mine[i] *= mine[j];
				}
			}
		}
	}
	Polynomial(int x[]) {
		int k = sizeof(x) / sizeof(int);
		mine = new int[k];
		for (int i = 0; i < k; i++)
			mine[k] = x[k];
	}
	Polynomial(const Polynomial& y) { //copy constructor
		int k = sizeof(y.mine) / sizeof(int);
		mine = new int[k];
		for (int i = 0; i < k; i++)
			mine[k] = y.mine[k];
	}
	Polynomial& operator =(const Polynomial& y) {
		int m = sizeof(mine) / sizeof(int);
		int n = sizeof(y) / sizeof(int);
		delete[] mine;
		mine = new int[n];
		for (int i = 0; i < n; i++) {
			mine[i] = y.mine[i];
		}
		return *this;
	}
friend ostream& operator<<(ostream& stream, Polynomial z) {
	int k = sizeof(z.value()) / sizeof(int);
	for (int i = 0; i < k; i++) {
		if (z.mine[i] == 0)
			k--;
	}
	cout << k << "_";
	for (int i = 0; i < sizeof(z.value())/sizeof(int); i++) {
		if (z.mine[i] != 0) {
			cout << z.mine[i] << "_" << k;
			k--;
		}
		if (z.mine[i] == 0) k--;
	}
	return stream;
}
int value() {
	int m = sizeof(mine) / sizeof(int);
	return m;
}
~Polynomial() { delete[] mine; }
private:
	int* mine;
	int _val;
};
int main() {
	int a[3] = { 1,0,-1 };
	int b[4] = { 3,0,1,0 };
	Polynomial A(a,3);
	Polynomial B(b,4);
	cout << A << endl;
	cout << B << endl;
	Polynomial C = A * B;
	cout << C << endl;
	return 0;
}