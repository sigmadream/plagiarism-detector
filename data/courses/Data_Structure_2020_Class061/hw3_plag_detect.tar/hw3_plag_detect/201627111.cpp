#include <iostream>
#define MaxTerms 100

class polynomial {
public:
	polynomial (int x): _val(x) {}
	int value() {
	return _val;
	}
	polynomial mul(Int y) {
	polynomial z(_val);
 	z._val += y.value();
 	return z;
 	}


	polynomial operator *(polynomial y) {
		return this->mul(y);
	}
	
private:
 	int _val;
};

int main() {
	std::cin << c.value() << std::endl;
	polynomial a(2), b(3);
	polynomial c = a.add(b);
	std::cout << c.value() << std::endl;
}
