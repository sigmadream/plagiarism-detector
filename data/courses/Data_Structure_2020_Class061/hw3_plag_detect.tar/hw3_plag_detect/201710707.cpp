#include <iostream>
using namespace std;

int main() {
	int i, j, k;
	int n1, n2;

	int a[101];
	int acnt;
	int alen;	
	cin >> acnt;
	
	for(i=0; i<acnt; i++)
	{
		cin >> n1 >> n2;		
		if(i == 0) {
			alen = n2;
			for(j=0; j<=alen; j++)
				a[j] = 0;
			}
		a[n2] = n1;
	}
		
	int b[101];
	int bcnt;
	int blen;	
	cin >> bcnt;
	
	for(i=0; i<bcnt; i++)
	{
		cin >> n1 >> n2;		
		if(i == 0) {
			blen = n2;
			for(j=0; j<=blen; j++)
				b[j] = 0;
			}
		b[n2] = n1;
	}
	
	int clen = alen + blen;
	int c[clen];
	
	for(i=0; i<=clen; i++)
		c[i] = 0;
	
	for(i=alen; i>=0; i--) {
		for(j=blen; j>=0; j--) {
			c[i+j] += a[i]*b[j];
		}
	}
	
	int len = 0;
	int d[101];
	int e[101];
	
	for(i=clen; i>=0; i--) {
		if(c[i] != 0) {
			d[len] = c[i];
			e[len] = i;
			len++;
		}
	}
	
	cout << len;
	for(i=0; i<len; i++)
		cout<<' '<<d[i]<<' '<<e[i];
		
	return 0;
}
