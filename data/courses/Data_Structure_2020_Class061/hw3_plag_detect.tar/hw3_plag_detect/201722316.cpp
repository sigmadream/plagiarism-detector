#include <iostream>
#include <algorithm>

class Int
{
public:
    Int(int x) : _val(x) {}
    int value()
    {
        return _val;
    }
    Int operator*(Int y)
    {
        Int z(_val);
        z._val *= y.value();
        return z;
    }
    Int operator+(Int y)
    {
        Int z(_val);
        z._val += y.value();
        return z;
    }

private:
    int _val;
};

int main()
{
    int maxnum1; // 첫번째 다항식 길이
    int maxnum2; // 두번째 다항식 길이

    std::cin >> maxnum1;                  // 첫번째 다항식 길이 입력
    int arr1[maxnum1 * 2];                // 첫번째 다항식 배열 선언
    for (int i = 0; i < maxnum1 * 2; i++) // 첫번째 다항식 입력단계
    {
        std::cin >> arr1[i];
    }

    std::cin >> maxnum2;                  // 두번째 다항식 길이 입력
    int arr2[maxnum2 * 2];                // 두번째 다항식 배열 선언
    for (int i = 0; i < maxnum2 * 2; i++) // 두번째 다항식 배열 입력단계
    {
        std::cin >> arr2[i];
    }

    int arr3[maxnum1][maxnum2 * 2]; // 하나씩 곱한 값 배열
    int n = 0;
    for (int i = 0; i < maxnum1 * 2; i += 2) // 곱할 값 반복문
    {
        for (int j = 0; j < maxnum2 * 2; j += 2) // 곱해지는 다항식 반복
        {
            Int a(arr1[i]), b(arr2[j]);
            Int c = a * b;
            arr3[n][j] = c.value();
            Int d(arr1[i + 1]), e(arr2[j + 1]);
            Int f = d + e;
            arr3[n][j + 1] = f.value(); // x 곱 (차수라서 덧셈으로 계산)
        }
        n++;
    }
    int arr4[(maxnum1 + maxnum2) * 2] = {0}; // 최종 곱해진 다항식 배열 선언
    int arr5[(maxnum1 + maxnum2) * 2] = {0};
    int num;
    for (int i = 0; i < maxnum1; i++)
    {
        std::copy(arr4, arr4 + (maxnum1 + maxnum2) * 2, arr5);
        int index2 = 1; // arr3 index
        int index1 = 1; // arr5 index
        num = 0;
        while (index2 < maxnum2 * 2)
        {
            if (arr5[index1] > arr3[i][index2])
            {
                arr4[num] = arr5[index1 - 1];
                arr4[num + 1] = arr5[index1];
                index1 += 2;
            }
            else if (arr5[index1] < arr3[i][index2])
            {
                arr4[num] = arr3[i][index2 - 1];
                arr4[num + 1] = arr3[i][index2];
                index2 += 2;
            }
            else
            {
                arr4[num] = arr5[index1 - 1] + arr3[i][index2 - 1];
                arr4[num + 1] = arr5[index1];
                index2 += 2;
                index1 += 2;
            }
            num += 2;
        }
    }
    std::cout << num / 2 << " ";
    for (int i = 0; i < num - 1; i++)
    {
        std::cout << arr4[i] << " ";
    }
    std::cout << arr4[num - 1] << std::endl;
}