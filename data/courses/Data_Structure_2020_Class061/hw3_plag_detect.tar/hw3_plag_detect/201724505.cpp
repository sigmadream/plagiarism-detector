#include <iostream>

using namespace std;

class Polynomial;

class Term {
private:
	float coef;
	int exp;
	friend class Polynomial;
	friend ostream& operator << (ostream& os, Polynomial& poly);
	friend istream& operator >> (istream& is, Polynomial& poly);
};

class Polynomial {
private:
	Term* termArray;
	int capacity;
	int terms;
public:
	Polynomial() : capacity(1), terms(0) {	// �⺻������
		termArray = new Term[capacity];
	}

	void addNewTerm(const float _coef, const int _exp) {
		if (terms == capacity) {
			capacity++;
			Term* temp = new Term[capacity];
			copy(termArray, termArray + terms, temp);
			delete[] termArray;
			termArray = temp;
		}

		termArray[terms].coef = _coef;
		termArray[terms++].exp = _exp;
	}

	void sortArray() {
		for (int i = 0; i < terms; i++) {
			for (int j = i+1; j < terms; j++)
				if (termArray[i].exp < termArray[j].exp) {
					Term temp = termArray[i];
					termArray[i] = termArray[j];
					termArray[j] = termArray[i];
				}
		}
	}

	Polynomial operator + (Polynomial& b) {
		Polynomial c;
		int aIndex = 0, bIndex = 0;

		while ((aIndex < terms) && (bIndex < b.terms)) {
			if (termArray[aIndex].exp == b.termArray[bIndex].exp) {
				float t = termArray[aIndex].coef + b.termArray[bIndex].coef;
				if (t != 0)
					c.addNewTerm(t, termArray[aIndex].exp);
				aIndex++; bIndex++;
			}
			else if (termArray[aIndex].exp < b.termArray[bIndex].exp) {
				c.addNewTerm(b.termArray[bIndex].coef, b.termArray[bIndex].exp);
				bIndex++;
			}
			else {
				c.addNewTerm(termArray[aIndex].coef, termArray[aIndex].exp);
				aIndex++;
			}
		}
		for (; aIndex < terms; aIndex++)
			c.addNewTerm(termArray[aIndex].coef, termArray[aIndex].exp);
		for (; bIndex < b.terms; bIndex++)
			c.addNewTerm(b.termArray[bIndex].coef, b.termArray[bIndex].exp);
		return c;
	}
	
	Polynomial operator * (Polynomial& b) {
		Polynomial c;
		int aIndex, bIndex;
		for (aIndex = 0; aIndex < terms; aIndex++) {
			for (bIndex = 0; bIndex < b.terms; bIndex++) {
				int place = -1;
				float tempCoef = termArray[aIndex].coef * b.termArray[bIndex].coef;
				int tempExp = termArray[aIndex].exp + b.termArray[bIndex].exp;
				for (int i = 0; i < c.terms; i++)
					if (c.termArray[i].exp == tempExp)
						place = i;
				if (place == -1 && (tempCoef != 0))
					c.addNewTerm(tempCoef, tempExp);
				else
					c.termArray[place].coef += tempCoef;
			}
		}
		return c;
	}
	friend istream& operator >> (istream& is, Polynomial& poly);
	friend ostream& operator << (ostream& os, Polynomial& poly);
};

istream& operator >> (istream& is, Polynomial& poly) {
	int terms;
	float coef;
	int exp;
	is >> terms;
	for (int i = 0; i < terms; i++) {
		is >> coef >> exp;
		poly.addNewTerm(coef, exp);
	}
	return is;
}

ostream& operator << (ostream& os, Polynomial& poly) {
	poly.sortArray();
	os << poly.terms;
	for (int i = 0; i < poly.terms; i++) {
			os << " " << poly.termArray[i].coef
				<< " " << poly.termArray[i].exp;
	}
	os << endl;

	return os;
}

int main() {
	Polynomial a, b;

	cin >> a >> b;
	Polynomial c = a * b;

	cout << c;

	return 0;
}