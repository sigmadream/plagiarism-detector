#include <iostream>
using namespace std;

class Polynomial;

class Term{
    friend Polynomial;
private:
    int c; int e;
};

class Polynomial{
private:
    Term* tArray;
    int termCnt; // ���� ���� �ִ� ���̽�
    int start; // �պ����� �� ������
public:
    Polynomial(const int n): termCnt(n){
        start = 0;
        tArray = new Term[termCnt];
        for(int i=0; i<termCnt; i++) cin >> tArray[i].c >> tArray[i].e;
    }
    Polynomial(const Polynomial& another): // �ڱ� ���� ����
        termCnt(another.termCnt){
            start = 0;
            tArray = new Term[termCnt];
            for(int i=0; i<termCnt; i++) tArray[i] = another.tArray[i];
    }
    Polynomial(const Term* tmpArr, const int len):
        termCnt(len){
            start = 0;
            tArray = new Term[termCnt];
            for(int i=0; i<termCnt; i++){
                tArray[i].c = tmpArr[i].c; // �迭ó�� ������ ���
                tArray[i].e = tmpArr[i].e;
            }
    }
    void polyOut() const {// ���Ŀ� �߰��� ,�� ��ĭ���� ����!
        cout << termCnt;
        for(int i=0; i<termCnt; i++) cout << " " << tArray[i].c << " " << tArray[i].e;
    }

    Polynomial operator +(Polynomial p){
        int maxLen = this->termCnt + p.termCnt;
        Term* tempArr = new Term[maxLen]; // �� ����� �ӽ� array.
        int realLen = 0;
        for(int i=0; i<maxLen; i++){
            if(this->start == this->termCnt){ // �� Poly �� �Ҹ� ��,
                if(p.start == p.termCnt){ // �� Poly�� �� �Ҹ� ��,
                    break; // ����
                }else{ // �� Poly'��' �Ҹ� ��,
                    tempArr[i].c = p.tArray[p.start].c;
                    tempArr[i].e = p.tArray[p.start].e;
                    p.start++;
                }
            }else if(p.start == p.termCnt){ // �� Poly�� �� �Ҹ��,
                tempArr[i].c = this->tArray[this->start].c;
                tempArr[i].e = this->tArray[this->start].e;
                this->start++;
            }else{ // �� �� ���� ���� ��,
                if(this->tArray[this->start].e > p.tArray[p.start].e){ // �� Poly�� exp�� Ŭ ��,
                    tempArr[i].c = this->tArray[this->start].c;
                    tempArr[i].e = this->tArray[this->start].e;
                    this->start++;
                }else if(this->tArray[this->start].e < p.tArray[p.start].e){ // �� Poly�� exp�� Ŭ ��,
                    tempArr[i].c = p.tArray[p.start].c;
                    tempArr[i].e = p.tArray[p.start].e;
                    p.start++;
                }else{ // ���� ��,
                    tempArr[i].c = (this->tArray[this->start].c) + (p.tArray[p.start].c);
                    tempArr[i].e = (this->tArray[this->start].e);
                    this->start++; p.start++;
                }
            }
            realLen++;
        }
        Polynomial returnP(tempArr, realLen); // ���� ����
        delete [] tempArr;
        return returnP;
    }
    Polynomial operator *(Polynomial p){
        // this-> �̿�!
        // this->termCnt & p.termCnt ����!
        Term *beforeSumPoly = new Term[p.termCnt];
        Term *afterOnePoly = new Term[p.termCnt];

        for(int j=0; j<p.termCnt; j++){
            beforeSumPoly[j].c = (this->tArray[0].c) * (p.tArray[j].c);
            beforeSumPoly[j].e = (this->tArray[0].e) + (p.tArray[j].e);
        }
        Polynomial pReturn(beforeSumPoly, p.termCnt); // Polyȭ

        for(int i=1; i<this->termCnt; i++){
            for(int j=0; j<p.termCnt; j++){
                afterOnePoly[j].c = (this->tArray[i].c) * (p.tArray[j].c);
                afterOnePoly[j].e = (this->tArray[i].e) + (p.tArray[j].e);
            }
            Polynomial pAdd(afterOnePoly, p.termCnt); // Polyȭ
            pReturn = pReturn+pAdd; // ���� ���� ����
        }

        delete [] beforeSumPoly, afterOnePoly;

        return pReturn;
    }
};

int main() {
    int n;

    cin >> n;
    Polynomial P1(n);

    cin >> n;
    Polynomial P2(n);

    Polynomial P3(P1*P2);

    P3.polyOut();

    //-------- ���� �ۼ� �ڵ�

	return 0;
}
