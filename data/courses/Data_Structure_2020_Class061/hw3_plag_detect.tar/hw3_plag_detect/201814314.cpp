#include<iostream>

using namespace std;

class Polynomial
{
private:
	int* _num1;
	int* _num2;
	int _size;
	int k;
public:
	Polynomial(int size)
	{
		k = 0;
		_size = size;
		_num1 = new int[size];
		_num2 = new int[size];
	}
	void inPoly()
	{
		int size;
		cin >> size;
		_size = size;
		_num1 = new int[_size];
		_num2 = new int[_size];
		for(int i=0;i<_size;i++)
		{
			cin >> _num1[i];
			cin >> _num2[i];
		}
	}
	void outPoly()
	{
		cout << _size << " ";
		for(int i=0;i<_size;i++)
		{
			cout << _num1[i] << " " << _num2[i] << " ";
		}
		cout << endl;
	}
	int getSize()
	{
		return _size;
	}
	int getNum1(int n)
	{
		return _num1[n];
	}
	int getNum2(int n)
	{
		return _num2[n];
	}
	void inNum(int n1, int n2)
	{
		_num1[k] = n1;
		_num2[k] = n2;
		k++;
	}
	void mulPoly(Polynomial p1, Polynomial p2)
	{
		int mulSize = p1.getSize() * p2.getSize();
		Polynomial _mulPoly(mulSize);
		for(int i=0;i<p1.getSize();i++)
		{
			for(int j=0;j<p2.getSize();j++)
			{
				_mulPoly.inNum(p1.getNum1(i) * p2.getNum1(j),p1.getNum2(i) + p2.getNum2(j)) ;
			}
		}
		_mulPoly.sumPoly();
		_mulPoly.outPoly();
	}
	void sumPoly()
	{
		int cnt=0;
		int testCnt=0;
		for(int i=0;i<_size;i++)
		{
			for(int j=i+1;j<_size;j++)
			{
				if( _num2[i]==_num2[j] )
				{
					_num1[i]+=_num1[j];
					_num2[j]=100;
				}
			}
		}
		for(int i=0; i<_size;i++)
		{
			if(_num2[i] == 100)
			{
				for(int j=i;j<_size-1;j++)
				{
					_num1[j] = _num1[j+1];
					_num2[j] = _num2[j+1];
					cnt++;
				}
			}
			
		}
		_size -= cnt;
		
	}
};
	
int main()
{
	Polynomial p1(0), p2(0), p3(0);
	p1.inPoly();
	p2.inPoly();
	p3.mulPoly(p1, p2);
	
}
