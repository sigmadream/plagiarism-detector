#include <iostream>

using namespace std;

int main() {
	int num, num2;
	cin >> num;
	int **array;
	array = new int*[num];
	for(int i = 0; i < num; i++){
    	array[i] = new int[2];
    	cin >> array[i][0] >> array[i][1];
	}
	cin >> num2;
	int **array2;
	array2 = new int*[num2];
	for(int i = 0; i < num; i++){
    	array2[i] = new int[2];
    	cin >> array2[i][0] >> array2[i][1];
	}
	
	cout << num << endl;
	for(int i = 0; i < num; i++) {
		cout << array[i][0] << endl;
		// cout << array[i][1] << endl;
	}
	cout << num2 << endl;
	for(int i = 0; i < num; i++) {
		cout << array2[i][0] << endl;
		//cout << array2[i][1] << endl;
	}
}
