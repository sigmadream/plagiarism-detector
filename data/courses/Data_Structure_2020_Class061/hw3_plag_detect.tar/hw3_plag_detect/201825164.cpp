#include <iostream>
using namespace std;

class Polynomial {
public:
	class Term {
	friend Polynomial;
	public:
		Term();
		virtual ~Term();
	private:
		int exp;
		int coef;
};
	static int MaxTerms;
	Polynomial();
	virtual ~Polynomial();
	void NewTerm(float c, float e);
	
	void NewTerm(int c, int e) {
		termArray[free].coef = c;
		termArray[free].exp = e;
		free++;
	}
	
	void Print() {
		cout << "\n";
		if(Start < Finish) {
			for(int i=Start; i<=Finish; i++) {
				for(int j=i+1; j<=Finish; j++) {
					if(termArray[i].exp == termArray[j].exp) {
						termArray[i].coef = termArray[i].coef + termArray[j].coef;
						termArray[j].coef = 0;
					}
				}
			}
		}
	}
	
	Polynomial operator *(const Polynomial P2) {
	Polynomial P3;
	int a = Start;
	int b = P2.Start;
	P3.Start = free;
	int c_coef;
	int c_exp;
	
	for(;a<=Finish;a++) {
		b = P2.Start;
		for(;b<P2.Finish;b++) {
			c_coef = termArray[a].coef * termArray[b].coef;
			c_exp = termArray[a].exp + termArray[b].exp;
			NewTerm(c_coef, c_exp);
		}
		P3.Finish = free - 1;
		return P3;
	}
}

	void setStart() {
		Start = free;
	}

	void setFinish() {
		Finish = free - 1;
	}

	private:
	static Term termArray[MaxTerms];
	static int free;
	int Start, Finish;
};

Polynomial::Polynomial(){
}
Polynomial::~Polynomial(){
}


Term Polynomial::termArray[MaxTerms];
int Polynomial::free = 0;


int main() {
	Polynomial P1, P2, P3;
	int a,b,c;
	
	cin >> a;
	P1.setStart();
	for(int i=1; i<=a;i++) {
		cin >> b >> c;
		P1.NewTerm(b, c);
	}
	P1.setFinish();
	
	cin >> a;
	P2.setStart();
	for(i=1; i<=a;i++) {
		cin >> b >> c;
		P2.NewTerm(b, c);
	}
	P2.setFinish();
	
	P3 = P1 * P2;
	P3.Print();
	
	return 0;
}
