#include <iostream>
using namespace std;

class Term {
	friend class Polynomial;
private :
	float coef;
	float exp;
};

class Polynomial {
private :
	static Term termArray[100];
	static int free;
	int Start, Finish;
	int count;
public :
	Polynomial() {}
	
	Polynomial(int count) : Start(free), Finish(free+2*count) {free += 2*count+1;}
	
	void setStart() {
		Start = free;
		cin >> count;
		Finish = Start + 2*count;
		free = Finish + 1;
	}
	
	void read() {
		setStart();
		float _co, _exp;
		for(int i=Start; i<Start+count; i++) {
			cin >> _co >> _exp;
			termArray[i].coef = _co;
			termArray[i].exp = _exp;
		}
	}
	
	Polynomial operator *(Polynomial b)
	{
		int maxCount = count*b.count;
		Polynomial c(maxCount);
		int index = c.Start;
//		while(index < maxCount)
//		{
//			for(int i=Start; i<Start+count; i++)
//				for(int j=b.Start; j<b.Finish; j++) {
//					c.termArray[index].coef = termArray[i].coef * b.termArray[j].coef;
//					c.termArray[index].exp = termArray[i].exp + b.termArray[j].exp;
//					index++;
//				}
//		}
//		
//		c.sparseSort();
//		
//		for(int i=1; i<maxTerms; i++) {
//			if(c.term[i-1].expon == c.term[i].expon) {
//				c.term[i-1].coeff += c.term[i].coeff;
//				c.term[i].coeff = 0;
//				c.term[i].expon = 0;
//			}
//		}
		return c;
	}
//	
//	void sparseSort() {
//		for(int i=0; i<nTerms; i++) {
//			for(int j=0; j<nTerms; j++) {
//				if(term[i].expon > term[j].expon) {
//					Term temp = term[i];
//					term[i] = term[j];
//					term[j] = temp;	
//				}
//			}
//		}
//	}
//	
//	int countNotZero() {
//		int count = 0;
//		for(int i=0; i<nTerms; i++) {
//			if(term[i].expon != 0)
//				count++;	
//		}
//		return count;
//	}
	
	void display() {
		float _co, _exp;
		cout << count << ' ';
		for(int i=Start; i<Start+count; i++) {
			_co = termArray[i].coef;
			_exp = termArray[i].exp;
			cout << _co << ' ';
			cout << _exp << ' ';	
		}
		cout << endl;
	}
};

Term Polynomial::termArray[100] = {};
int Polynomial::free = 0;

int main() {
	Polynomial a;
	a.read();
	Polynomial b;
	b.read();
	a.display();
	b.display();
	Polynomial c = a*b;
	c.display();
}
