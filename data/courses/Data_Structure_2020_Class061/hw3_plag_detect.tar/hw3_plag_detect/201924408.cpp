#include <iostream>
using namespace std;


int *multiply(int A[], int B[], int m, int n)
{
   int *prod = new int[m+n-1];


   for (int i = 0; i<m+n-1; i++)
     prod[i] = 0;


   for (int i=0; i<m; i++)
   {

     for (int j=0; j<n; j++)
         prod[i+j] += A[i]*B[j];
   }

   return prod;
}



void printPoly(int poly[], int n)
{
    cout << n/2 << " ";
    for (int i=n-1; i>=0; i--)
    {
        if( i != 0 && (poly[i] != 0))
        cout << poly[i];
        if (i != 0 && (poly[i] != 0))
            cout << " " << i << " ";
    }
}


int main()
{

    int A[] = {-1,0,1}; //{0,0,0,2};
    int B[] = {0,1,0,2}; // {1,1};



    int m = sizeof(A)/sizeof(int);
    int n = sizeof(B)/sizeof(int);


    int *prod = multiply(A, B, m, n);

    cout << "nProduct polynomial is ";
    printPoly(prod, m+n-1);
    cout << endl;



    return 0;
}
