#include <iostream>

using namespace std;

#define MAX_DEGREE 100

class Pmul {
public:
	Pmul() {	//�ʱ�ȭ
		num[0] = 0;
		exp[0] = 0;
		k = 0;
	}
	void getdata() {	//�� �Է�
		cin >> k;
		for (int i = 0;i < k; i++) {
			cin >> num[i] >> exp[i];
		}
	}
	void display() {	//�� ���
		cout << k;
		for (int i = 0;i < k;i++) {
			cout <<" "<< num[i]<<" " << exp[i];
		}
	}

	Pmul operator *(Pmul y) {
		Pmul z;
		int t = 0;
		for (int i = 0;i < k;i++) {	//p1 
			for (int j = 0;j < y.k;j++) {	//p2 
				for (int t = 0;t <= z.k;t++) {
					if (z.exp[t] < exp[i] + y.exp[j]) {
						for (int ti = j;ti < z.k;ti++) {
							z.num[ti + 1] = z.num[ti];
							z.exp[ti + 1] = z.exp[ti];
						}
						z.num[t] = num[i] * y.num[j];
						z.exp[t] = exp[i] + y.exp[j];
						z.k++;
						break;
					}
					else if (z.exp[t] == exp[i]+y.exp[j]) {	//������
						z.num[t] += num[i] * y.num[j];
						break;
					}
					
					
				}
				
				
			}
		}
		for (int i = 0;i < z.k;i++) {
			if (z.num[i] == 0) {
				for (int j = i;j < z.k-1;j++) {
					z.num[j] = z.num[j + 1];
					z.exp[j] = z.exp[j + 1];
				}
				z.k--;
			}
		}




		return z;
	}
private:
	int num[MAX_DEGREE];	//�� ���� ��
	int exp[MAX_DEGREE];	//�� ���� ����
	int k;	//�� ���� ����
};

int main() {
	Pmul p1,p2;
	p1.getdata();
	p2.getdata();
	Pmul p3 = p1 * p2;
	p3.display();

	return 0;
}