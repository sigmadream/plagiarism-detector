#include <iostream>
using namespace std;

typedef struct term {
	int power;
	int coof;
} term;

class Polynomial {
private:
	term *terms = NULL;
	int term_num, pol_size;
public:
	Polynomial(int size = 0) {
		term_num = size;
		pol_size = 0;
		terms = new term[term_num];
		if(terms == NULL) {
			cerr << "Memory Allocation Failed\n";
			return;
		}
		for(int i = 0; i < term_num; i++) {
			terms[i].coof = 0;
			terms[i].power = 0;
		}
	}
	
	Polynomial(Polynomial& obj) {
		pol_size = obj.pol_size;
		term_num = obj.term_num;
		terms = new term[term_num];
		for(int i = 0; i < term_num; i++) {
			terms[i].coof = obj.terms[i].coof;
			terms[i].power = obj.terms[i].power;
		}
	}
	
	void input() {
		for(int i = 0; i < term_num; i++) {
			cin >> terms[i].coof >> terms[i].power;
		}
		pol_size = terms[0].power + 1;
	}
	
	void print() {
		cout << term_num << " ";
		for(int i = 0; i < term_num; i++) {
			if(i != term_num - 1) cout << terms[i].coof << " " << terms[i].power << " ";
			else cout << terms[i].coof << " " << terms[i].power;
		}
	}
	
	Polynomial operator * (Polynomial &obj) {
		int new_size = term_num + obj.term_num - 1;
		Polynomial temp(new_size);
		for(int i = 0; i < term_num; i++) {
			for(int j = 0; j < obj.term_num; j++){
				temp.terms[i + j].coof += terms[i].coof * obj.terms[j].coof;
			}
		}
		for(int i = 0; i < new_size; i++) {
			temp.terms[i].power = terms[i/2].power + obj.terms[(i+1)/2].power;
		}
		return temp;
	}
};

int main() {
	int size1 = 0;
	cin >> size1;
	Polynomial a(size1);
	a.input();
	cin >> size1;
	Polynomial b(size1);
	b.input();
	Polynomial c;
	c = a * b;
	c.print();
	return 0;
}
