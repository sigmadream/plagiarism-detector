#include <iostream>
using namespace std;

class Polynomial;

class Term{
    friend Polynomial;
private:
    int c; int e;
};

class Polynomial{
private:
    Term* tArray;
    int termCnt; // ½ÇÁ¦ °ªÀÌ ÀÖ´Â ÄÉÀÌ½º
    int start; // ÇÕº´¿¬»ê ½Ã ÂüÁ¶¿ë
public:
    Polynomial(const int n): termCnt(n){
        start = 0;
        tArray = new Term[termCnt];
        for(int i=0; i<termCnt; i++) cin >> tArray[i].c >> tArray[i].e;
    }
    Polynomial(const Polynomial& another): // ÀÚ±â ÂüÁ¶ ¼±¾ð
        termCnt(another.termCnt){
            start = 0;
            tArray = new Term[termCnt];
            for(int i=0; i<termCnt; i++) tArray[i] = another.tArray[i];
    }
    Polynomial(const Term* tmpArr, const int len):
        termCnt(len){
            start = 0;
            tArray = new Term[termCnt];
            for(int i=0; i<termCnt; i++){
                tArray[i].c = tmpArr[i].c; // ¹è¿­Ã³·³ Æ÷ÀÎÅÍ »ç¿ë
                tArray[i].e = tmpArr[i].e;
            }
    }
    void polyOut() const {// Â÷ÈÄ¿¡ Áß°£¿¡ ,¸¦ ºóÄ­À¸·Î ¼öÁ¤!
        cout << termCnt;
        for(int i=0; i<termCnt; i++) cout << " " << tArray[i].c << " " << tArray[i].e;
    }

    Polynomial operator +(Polynomial p){
        int maxLen = this->termCnt + p.termCnt;
        Term* tempArr = new Term[maxLen]; // °ª ÀúÀå¿ë ÀÓ½Ã array.
        int realLen = 0;
        for(int i=0; i<maxLen; i++){
            if(this->start == this->termCnt){ // ¾Õ Poly ´Ù ¼Ò¸ð ½Ã,
                if(p.start == p.termCnt){ // µÞ Polyµµ ´Ù ¼Ò¸ð ½Ã,
                    break; // Á¾·á
                }else{ // ¾Õ Poly'¸¸' ¼Ò¸ð ½Ã,
                    tempArr[i].c = p.tArray[p.start].c;
                    tempArr[i].e = p.tArray[p.start].e;
                    p.start++;
                }
            }else if(p.start == p.termCnt){ // µÞ Poly¸¸ ´Ù ¼Ò¸ð½Ã,
                tempArr[i].c = this->tArray[this->start].c;
                tempArr[i].e = this->tArray[this->start].e;
                this->start++;
            }else{ // µÑ ´Ù ³²¾Æ ÀÖÀ» ½Ã,
                if(this->tArray[this->start].e > p.tArray[p.start].e){ // ¾Õ PolyÀÇ exp°¡ Å¬ ½Ã,
                    tempArr[i].c = this->tArray[this->start].c;
                    tempArr[i].e = this->tArray[this->start].e;
                    this->start++;
                }else if(this->tArray[this->start].e < p.tArray[p.start].e){ // µÞ PolyÀÇ exp°¡ Å¬ ½Ã,
                    tempArr[i].c = p.tArray[p.start].c;
                    tempArr[i].e = p.tArray[p.start].e;
                    p.start++;
                }else{ // °°À» ½Ã,
                    tempArr[i].c = (this->tArray[this->start].c) + (p.tArray[p.start].c);
                    tempArr[i].e = (this->tArray[this->start].e);
                    this->start++; p.start++;
                }
            }
            realLen++;
        }
        Polynomial returnP(tempArr, realLen); // ±æÀÌ Á¶Á¤
        delete [] tempArr;
        return returnP;
    }
    Polynomial operator *(Polynomial p){
        // this-> ÀÌ¿ë!
        // this->termCnt & p.termCnt ÁÖÀÇ!
        Term *beforeSumPoly = new Term[p.termCnt];
        Term *afterOnePoly = new Term[p.termCnt];

        for(int j=0; j<p.termCnt; j++){
            beforeSumPoly[j].c = (this->tArray[0].c) * (p.tArray[j].c);
            beforeSumPoly[j].e = (this->tArray[0].e) + (p.tArray[j].e);
        }
        Polynomial pReturn(beforeSumPoly, p.termCnt); // PolyÈ­

        for(int i=1; i<this->termCnt; i++){
            for(int j=0; j<p.termCnt; j++){
                afterOnePoly[j].c = (this->tArray[i].c) * (p.tArray[j].c);
                afterOnePoly[j].e = (this->tArray[i].e) + (p.tArray[j].e);
            }
            Polynomial pAdd(afterOnePoly, p.termCnt); // PolyÈ­
            pReturn = pReturn+pAdd; // µ¡¼À ¿¬»ê ¼öÇà
        }

        delete [] beforeSumPoly, afterOnePoly;

        return pReturn;
    }
};

int main() {
    int n;

    cin >> n;
    Polynomial P1(n);

    cin >> n;
    Polynomial P2(n);

    Polynomial P3(P1*P2);

    P3.polyOut();

    //-------- ÀÚÀ¯ ÀÛ¼º ÄÚµå

    return 0;
}
