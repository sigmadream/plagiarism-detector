#include <iostream>
#include <string>
#include <ostream>
#include <vector>
using namespace std;

class Poly {
public:
    void operator * (const Poly &poly);
    int MulPoly(int (&coef)[100][2], int (&exp)[100][2], int (&newOne)[100][2], int num1, int num2) {
        int r = 0;vector<int> result;
        for (int m = 0; m < num2; m++) {
            for (int n = 0; n < num1; n++, r++) {
                newOne[r][0] = coef[n][0] * exp[m][0];
                newOne[r][1] = coef[n][1] + exp[m][1];
            }
        }
        for (int m = 0; m < r; m++) {
            for (int n = m + 1; n < r; n++) {
                if (newOne[m][1] == newOne[n][1]) {
                    newOne[m][0] += newOne[n][0];
                    for (int l = n; l < r - 1; l++) {
                        newOne[l][0] = newOne[l + 1][0];
                        newOne[l][1] = newOne[l + 1][1];
                    }
                    r--;
                }
            }
        }
        for(int j=0;j<r-1;j++) {
            if(newOne[j][1] < newOne[j + 1][1]){
                int temp,temp2;
                temp = newOne[j][1];temp2 = newOne[j][0];
                newOne[j][1] = newOne[j + 1][1];newOne[j][0] = newOne[j + 1][0];
                newOne[j + 1][1] = temp;newOne[j + 1][0] = temp2;
            }
        }

        return r;
    }

    void getpolynomial(int (&g)[100][2], int &num) {
        cin >> num;
        for (int j = 0; j < num; j++)
            cin >> g[j][0] >> g[j][1];
    }
    int sizechecker(int a, int b){
        if(a == b){
            if(a == 1) return a;
            return (a + 1);
        }
        else if(a >= 2 && b >= 2){
            return (a + b + 1);
        }else if(a > b){
            return a;
        }else if(a < b){
            return b;
        }else{
            return a;
        }
    }

private:
    int coef[100][2];int exp[100][2]; int newOne[100][2];
};
int main(){
    Poly *poly;
    int coef[100][2],exp[100][2],newONe[100][2],num1,num2,num3,size;

    poly -> getpolynomial(coef, num1);
    poly -> getpolynomial(exp, num2);
    size = poly -> sizechecker(num1, num2);
    num3= poly->MulPoly(coef, exp, newONe, num1, num2);

    cout << size << " ";
    for(int j=0;j<num3-1;j++) {
       cout << newONe[j][0] << " " << newONe[j][1] << " ";
    }
    cout << newONe[num3 - 1][0] << " " << newONe[num3 - 1][1] << endl;
    return 0;
}