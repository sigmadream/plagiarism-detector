#include <iostream>

using namespace std;

#define MaxElements 100

class MatrixElement {
public:
    int row,col;
    int value;
};

class SparseMatrix {
public:
    int nRows, nCols, nElements;
    MatrixElement smArray[MaxElements];
    SparseMatrix(int r, int c): nRows(r), nCols(c), nElements(0) { }
    void addElement(int r, int c, int v) {
        smArray[nElements].row = r;
        smArray[nElements].col = c;
        smArray[nElements].value = v;
        nElements++;
    }
    void print() {
        for (int i = 0; i < nElements; i++)
            cout << "(" << smArray[i].row << ", "
                        << smArray[i].col << ", "
                        << smArray[i].value << ")" << endl;
    }
};


int main () {
    int row, col;
    int hang_1[col], hang_2[col];
    int a[2][col];
    cin >> row >> col;
    cin >> hang_1[col];
    cin >> hang_2[col];
    cout << hang_1[col];
    for(int i =0; i < col ; i++)
        int a[2][col] = {{hang_1[i]}, {hang_2[i]}};
    SparseMatrix sm(row, col);
    for (int i = 0; i < row; i++)
        for (int j = 0; j < col; j++)
            if (a[i][j] != 0)
                sm.addElement(i, j, a[i][j]);

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++)
            cout << (j == col-1? "\n":" ");
    }
    sm.print();
    return 0;
}
