#include<iostream>
using namespace std;
#define MaxElement 100
class Element{
public:
    int row ,col;
    int value;
    Element() {}
    Element(int r, int c, int v): row(r), col(c), value(v){}

};

class SparseMatrix{
private:
    int nRows, nCols, nElements;
    Element smArray[MaxElement];
    int* colIndex;
public:
    SparseMatrix() {}
    SparseMatrix(int r, int c): nRows(r), nCols(c), nElements(0) {
        colIndex = new int[nCols];
    }
    // ~SparseMatrix() {
    //     cout << "destructor is called, colindex = " << colIndex[0] << endl;
    //     for(int i = 0; i < nElements; i++) cout << "\t" << colIndex[i] << endl;
    //     delete[] colIndex;}
    void addElement(int r, int c, int v){
        smArray[nElements++] = Element(r,c,v);
        colIndex[c] += 1;
    }

    void setColIndex(){
        int tmp[nCols];
        for(int i =0 ; i < nCols; i++){
            tmp[i] = colIndex[i];
            colIndex[i] = 0;
        }
        int sum = 0;
        for(int i = 0; i < nCols ; i++){ 
            colIndex[i] += sum;
            sum += tmp[i];
        }
    }
    SparseMatrix transpose(){
        setColIndex();
        SparseMatrix trans = SparseMatrix(nCols, nRows);
        for(int i = 0; i < nElements; i++){
            // 1. 원래 희소행렬에서 원소 1개 꺼내고 transpose된 원소 생성
            int row = smArray[i].row, col = smArray[i].col, value = smArray[i].value;
            Element tmp = Element(col, row, value);
            // 2. col을 참조해 colIndex에서 가져와 해당하는 smArray에 집어넣는다.
            int index = colIndex[col];
            trans.smArray[index] = tmp;
            trans.nElements += 1;
            // 3. 가져온 colIndex의 해당 값을 1 증가 => 나중에 재참조시 smArray에 들어가는 위치가 겹치지 않게 하기위함
            colIndex[col] += 1;
        }
        return trans;
    }
    
    int getElement(int i, int j, SparseMatrix& sm){ // i행과 j열을 곱했을 때 결과를 리턴한다.
        int result = 0;
        int currA = 0, currB = 0;
        while(currA < nElements){
            if (smArray[currA].row != i){
                currA += 1;
                continue;
            }
            currB = 0;
            while (currB < sm.nElements
            ){
                if (smArray[currA].col == sm.smArray[currB].row && sm.smArray[currB].col == j){
                    result += smArray[currA].value * sm.smArray[currB].value;
                    break; // 위 조건 만족은 1번뿐이므로
                }
                currB += 1;
            }
            currA += 1;
        }
        return result;
    }


    SparseMatrix operator*(SparseMatrix& sm){
        SparseMatrix multipled = SparseMatrix(nRows, sm.nCols);
        int sum;
        for(int i = 0 ; i < nRows; i++){
            for(int j = 0; j < sm.nCols; j++){
                sum = getElement(i, j, sm);
                if (sum) multipled.addElement(i, j, sum);
            }
        }
        return multipled;
    }
    void print(){
        cout << nRows << " " << nCols << " " << nElements;
        for(int i = 0 ; i < nElements; i++){
            cout << endl << "(" << smArray[i].row << "," << smArray[i].col << "," << smArray[i].value << ")";
        }
    }
};


int main (){
    int row, col;
    cin >> row >> col;
    int matrix[row][col];
    SparseMatrix A = SparseMatrix(row ,col);
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            cin >> matrix[i][j];
            if (matrix[i][j]) A.addElement(i, j, matrix[i][j]);
        }
    }
    // A.print();
    SparseMatrix B = A.transpose();
    // cout << "Transposed result" << endl;
    // B.print();

    // cout << "multipled sparsMatrix result " << endl;
    SparseMatrix mul = A * B;
    mul.print();


}