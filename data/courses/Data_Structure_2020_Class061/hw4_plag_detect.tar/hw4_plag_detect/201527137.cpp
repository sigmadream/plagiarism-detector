#include <iostream>
using namespace std;

class SparseMatrix;

class MatrixTerm
{
        friend class SparseMatrix;
        friend ostream &operator<<(ostream &os, const SparseMatrix S);
public:
        int row, col, value;
};

class SparseMatrix
{
private:
        int rows, cols, terms, capacity;
public:
	    MatrixTerm *smArray;
        SparseMatrix(int MaxRow=1, int MaxCol=1, int term=0)
        {
               rows = MaxRow;
               cols = MaxCol;
               terms = term;
               if (term > 0)
                       capacity = term;
               else
                       capacity = 1;
               smArray = new MatrixTerm[capacity];
        }

        friend ostream &operator<<(ostream &os, const SparseMatrix S); //���
};

ostream &operator<<(ostream &os, const SparseMatrix S)
{
        os << S.rows << " " << S.cols << " " << S.terms << endl;
        for (int i = 0; i < S.terms; i++)
        {
               os << "(" << S.smArray[i].row << ", " << S.smArray[i].col << ", " << S.smArray[i].value << ")" << endl;
        }
        return os;
}

int main(){
	int m,n,i,j,k,num,count=0;
	int matrix[100][100];
	int Tmatrix[100][100];
	int Product[100][100];
	
	SparseMatrix mul;
	
	cin >> m >> n;
	
	for(i=0 ; i<m ; i++)
	{
		for(j=0 ; j<n ; j++)
		{
			cin >> num;
			matrix[i][j]=num;
			Tmatrix[j][i]=num;
		}	
	}
	
	for(i=0 ; i<m ; i++)
	{
		for(j=0 ; j<n ; j++)
		{
			for(k=0;k<3;k++)
			Product[i][j]+=matrix[i][k]*Tmatrix[k][i];
		}
	}
	
	for(i=0 ; i<m ; i++)
	{
		for(j=0 ; j<n ; j++)
		{
			if(Product[i][j]!=0)
			{
			mul.smArray[count].row=i;
			mul.smArray[count].col=j;
			mul.smArray[count].value=Product[i][j];
			count++;
			}
		}
	}	
	cout << mul;

	return 0;
}
