#include <iostream>
 
using namespace std;
 
class Matrix
{
public:
    int** mat; 
    int row;
    int col;
public:
    Matrix(int row, int col);
    Matrix(Matrix& m);
    ~Matrix(){
        if(mat != NULL) {
            for(int i = 0; i < row; i++) delete []mat[i];
            delete []mat;
        }
    }
    void transpose(Matrix &T);
    void operator*(Matrix &T);
    friend ostream& operator<<(ostream& o, Matrix& m);\
};

Matrix::Matrix(Matrix& m)
{
    row = m.row;
    col = m.col;
    mat = new int*[row];
    for(int i = 0; i < row; i++)
    {
        mat[i] = new int[col];
        for(int j = 0; j < col; j++)
        {
            mat[i][j] = 0;
        }
    }
}

Matrix::Matrix(int _row, int _col) 
{
    row = _row;
    col = _col;
    mat = new int*[_row];
    for(int i = 0; i < _row; i++)
    {
        mat[i] = new int[_col];
        for(int j = 0; j < _col; j++)
        {
            mat[i][j] = 0;
        }
    }
}

void Matrix::transpose(Matrix &T){
	    
    for(int i=0; i<row; ++i)
    	for(int j=0; j<col; ++j)
    		T.mat[j][i] = mat[i][j];
}

void Matrix::operator*(Matrix &T){
	int** ptr = new int*[row];
	for(int i=0; i<row; ++i)
		ptr[i] = new int[T.col];
	
	int i, j, k;
	
	for(i=0; i<row; ++i){
		for(j=0; j<T.col; ++j){
			ptr[i][j] = 0;
			for(k=0; k<col; ++k)
				ptr[i][j] += mat[i][k] * T.mat[k][j];
		}
	}
	
	int count=0;
	
	for(i=0; i<row; ++i){
		for(int j=0; j<T.col; ++j){
			if(ptr[i][j] != 0){
				count++;
			}
		}
	}
	
	cout << row << ' ' << T.col << ' ' << count << endl;
	
	for(i=0; i<row; ++i){
		for(int j=0; j<T.col; ++j){
			if(ptr[i][j] != 0)
				cout << '(' << i << ',' << j << ',' << ptr[i][j] << ')' << endl;
		}
	}
		
}
ostream& operator<<(ostream& o, Matrix& m) // operator overloading 
{ 
    for(int i = 0; i < m.row; i++)
    {
        for(int j = 0; j < m.col; j++)
        {
            o << m.mat[i][j] << "\t";
        }
        o << endl;
    }
    return o;
}

int main(void)
{
	int _row, _col;
	cin >> _row >> _col;
	
    Matrix A(_row, _col);
    Matrix AT(_col, _row);
    
    for(int i=0; i<_row; ++i)
    	for(int j=0; j<_col; ++j)
    		cin >> A.mat[i][j];
    
    A.transpose(AT);
    A*AT;

}
 

