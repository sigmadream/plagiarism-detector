/*
* Author: Chunsu Kim
* Number: 201624458
* Programming Lap04
*/
#include <iostream>
using namespace std;
#define MaxElements 100

class MatrixElement {
public:
    int row, col;
    int value;
};

class SparseMatrix {
public:
    int nRows, nCols, nElements;
    MatrixElement smArray[MaxElements];
    SparseMatrix(int r, int c) : nRows(r), nCols(c), nElements(0) {}
    void addElement(int r, int c, int v) {
        smArray[nElements].row = r;
        smArray[nElements].col = c;
        smArray[nElements].value = v;
        nElements++;
    }
    void transpose(int *a[], int *b[]) {
        int m = sizeof(*a) / sizeof(**a);
        int n = sizeof(*b) / sizeof(**b);
        
        for (int i = 0; i < m; i++)
            for (int j = 0; j < n; j++)
                b[i][j] = a[j][i];
    }
    void multi(int *a[], int *b[],int *c[])
    {
        int m = sizeof(*a) / sizeof(**a);
        int n = sizeof(*b) / sizeof(**b);

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < m; k++) {
                    c[i][j] += a[i][k] * b[k][j];
                }
            }
        }
    }
    ostream& print(ostream& out) {
        out << nRows << " "
            << nCols << " "
            << nElements << endl;
        for (int i = 0; i < nElements; i++)
            out << "(" << smArray[i].row << " "
            << smArray[i].col << " "
            << smArray[i].value << ")" << endl;
        return out;
    }
};

int main()
{
    int row = 4, col = 4;
    int a[row][col] = { {0,0,9,0},
                        {5,0,8,1},
                        {7,0,0,2},
                        {0,0,0,1} };
    int row = sizeof(a) / sizeof(a[0]);
    int col = sizeof(a[0]) / sizeof(a[0][0]);
    SparseMatrix sm(row, col);
    for (int i = 0; i < row; i++)
        for (int j = 0; j < col; j++)
            if (a[i][j] != 0)
                sm.addElement(i, j, a[i][j]);
    int b[row][col] = { 0, };
    int c[row][col] = { 0, };
    sm.transpose(a,b);
    sm.multi(a, b,c);
    /*cout << "The matrix is:" << endl;
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++)
            cout << a[i][j] << (j == col - 1 ? "\n" : " ");
        cout << endl;
    }
    cout << "transposed " << endl;
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++)
            cout << b[i][j] << (j == col - 1 ? "\n" : " ");
        cout << endl;
    }
    cout << "multi" << endl;
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++)
            cout << c[i][j] << (j == col - 1 ? "\n" : " ");
        cout << endl;
    }
    */
    sm.print(cout);
    return 0;
}