#include <iostream>
using namespace std;

int main() {
	int i, j, k;
	int row, col;
	int cnt = 0;
	cin >> row >> col;
	
	int a[row][col];
	int b[col][row];
	int c[row][row];
	
	for(i=0; i<row; i++) {
		for(j=0; j<col; j++) {
			int t;
			cin >> t;
			a[i][j] = t;
			b[j][i] = t;
		}
	}
	
	for(i=0; i<row; i++) {
		for(j=0; j<row; j++) {
			c[i][j] = 0;
			
			for(k=0; k<col; k++) {
				c[i][j] += a[i][k] * b[k][j];
			}
			
			if (c[i][j] != 0) cnt++;
		}
	}
	
	cout << row << " " << row << " " << cnt << endl;

	for(i=0; i<row; i++) {
		for(j=0; j<row; j++) {
			if(c[i][j] != 0) {
				cout << "(" << i << "," << j << "," << c[i][j] << ")" << endl;		
			}
		}
	}
}
