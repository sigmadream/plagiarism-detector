#include <iostream>

using namespace std;

#define MaxElements 100

class MatrixElement
{
public:
    int row, col;
    int value;
};

class SparseMatrix
{
public:
    int nRows, nCols, nElements, state;
    MatrixElement smArray[MaxElements];
    SparseMatrix(int r, int c) : nRows(r), nCols(c), nElements(0) {}
    void addElement(int r, int c, int v)
    {
        for (int i = 0; i < nElements; i++)
        {
            if (r == smArray[i].row && c == smArray[i].col)
            {
                state = 1;
                smArray[i].value += v;
                break;
            }
        }
        if (state == 0)
        {
            smArray[nElements].row = r;
            smArray[nElements].col = c;
            smArray[nElements].value = v;
            nElements++;
        }
        state = 0;
    }

    void nonzero()
    {
        for (int i = 0; i < nElements; i++)
        {
            while (smArray[i].value == 0)
            {
                for (int j = i + 1; j < nElements; j++)
                {
                    smArray[j - 1].value = smArray[j].value;
                    smArray[j - 1].col = smArray[j].col;
                    smArray[j - 1].row = smArray[j].row;
                }
                nElements -= 1;
            }
        }
    }
    void sort()
    {
        int temp;
        for (int i = 0; i < nElements; i++)
        {
            for (int j = i; j < nElements; j++)
            {
                if (smArray[i].row > smArray[j].row)
                {
                    temp = smArray[i].row;
                    smArray[i].row = smArray[j].row;
                    smArray[j].row = temp;
                    temp = smArray[i].col;
                    smArray[i].col = smArray[j].col;
                    smArray[j].col = temp;
                    temp = smArray[i].value;
                    smArray[i].value = smArray[j].value;
                    smArray[j].value = temp;
                }
                else if (smArray[i].row == smArray[j].row && smArray[i].col > smArray[j].col)
                {
                    temp = smArray[i].row;
                    smArray[i].row = smArray[j].row;
                    smArray[j].row = temp;
                    temp = smArray[i].col;
                    smArray[i].col = smArray[j].col;
                    smArray[j].col = temp;
                    temp = smArray[i].value;
                    smArray[i].value = smArray[j].value;
                    smArray[j].value = temp;
                }
            }
        }
    }
};

ostream &operator<<(ostream &out, SparseMatrix n)
{
    out << n.nRows << " "
        << n.nCols << " "
        << n.nElements << endl;
    for (int i = 0; i < n.nElements; i++)
        out << "(" << n.smArray[i].row << ","
            << n.smArray[i].col << ","
            << n.smArray[i].value << ")" << endl;
    return out;
}

int main()
{
    int row, col, val, num;
    cin >> row;
    cin >> col;
    SparseMatrix sm(row, col);
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cin >> val;
            if (val != 0)
                sm.addElement(i, j, val);
        }
    }
    SparseMatrix rm(row, row);
    for (int i = 0; i < sm.nElements; i++)
    {
        for (int j = 0; j < sm.nElements; j++)
        {
            if (sm.smArray[i].col == sm.smArray[j].col)
                rm.addElement(sm.smArray[i].row, sm.smArray[j].row, sm.smArray[i].value * sm.smArray[j].value);
        }
    }
    rm.sort();
    rm.nonzero();
    cout << rm;
    return 0;
}