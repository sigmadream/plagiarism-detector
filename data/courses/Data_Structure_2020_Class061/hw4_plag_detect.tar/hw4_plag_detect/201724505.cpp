#include <iostream>

using namespace std;

#define MaxElements 100

class MatrixElement
{
private:
	int row, col;
	int value;
	friend class SparseMatrix;
};

class SparseMatrix
{
private:
	int nRows, nCol, nElements;
	MatrixElement smArray[MaxElements];
public:
	SparseMatrix() {}
	SparseMatrix(int r, int c) : nRows(r), nCol(c), nElements(0) {}
	void addElement(int r, int c, int v)
	{
		smArray[nElements].row = r;
		smArray[nElements].col = c;
		smArray[nElements].value = v;
		nElements++;
	}

	void print() const
	{
		cout << nRows << " " << nCol << " " << nElements << endl;
		for (int i = 0; i < nElements; i++)
		{
			cout << "(" << smArray[i].row
				<< "," << smArray[i].col
				<< "," << smArray[i].value << ((i < nElements -1)? ")\n":")");
		}
	}

	SparseMatrix* transpose()
	{
		int* colCount = new int[nCol];
		int* startPoint = new int[nCol];
		SparseMatrix* tranMatrix = new SparseMatrix[1];
		tranMatrix->nElements = nElements;
		tranMatrix->nCol = nCol;
		tranMatrix->nRows = nRows;
		startPoint[0] = 0;
		for (int i = 0; i < nCol; i++)
			colCount[i] = 0;
		
		for (int i = 0; i < nElements; i++)
		{
			colCount[smArray[i].col]++;
		}
		
		for (int i = 1; i < nCol; i++)
		{
			startPoint[i] = startPoint[i - 1] + colCount[i - 1];
		}
		for (int i = 0; i < nElements; i++)
		{
			int j = startPoint[smArray[i].col]++;
			tranMatrix->smArray[j].row = smArray[i].col;
			tranMatrix->smArray[j].col = smArray[i].row;
			tranMatrix->smArray[j].value = smArray[i].value;
		}
		delete colCount;
		delete startPoint;

		return tranMatrix;
	}

	void array_addValue(int index, int value)
	{
		smArray[index].value += value;;
	}

	SparseMatrix operator *(SparseMatrix aT)
	{
		SparseMatrix* a = aT.transpose();
		SparseMatrix result(nRows, nRows); 
		int state = 0;
	
		for (int i = 0; i < nElements; i++) 
		{
			for (int j = 0; j < nElements; j++) 
			{
				if (smArray[i].col == a->smArray[j].col)
				{
					
					if (state == 0)
					{
						result.addElement(smArray[i].row, a->smArray[j].row, smArray[i].value * a->smArray[j].value);
						state = 1;
					}
					else
					{
						int _k = result.nElements;
						for (int k = 0; k < _k; k++)
						{

							if (result.smArray[k].row == smArray[i].row && result.smArray[k].col == a->smArray[j].row)
							{
								result.array_addValue(k, smArray[i].value * a->smArray[j].value);
							}
							else if (k == _k - 1)
							{
								result.addElement(smArray[i].row, a->smArray[j].row, smArray[i].value * a->smArray[j].value);
							}
						}
					}
				}
			}

		}

		return result;
	}
};

ostream& operator << (ostream& os, SparseMatrix sm)
{
	sm.print();
	return os;
}

int main()
{
	int m;
	int n;
	cin >> m >> n; 
	int** array = new int* [m];
	SparseMatrix sm(m, n);
	for (int i = 0; i < m; i++)
	{
		array[i] = new int[n];
		for (int j = 0; j < n; j++)
		{
			cin >> array[i][j];
			if (array[i][j] != 0)
			sm.addElement(i, j, array[i][j]);
		}
	}

	SparseMatrix* sm_T = sm.transpose();

	cout << sm * *(sm_T);
	return 0;
}