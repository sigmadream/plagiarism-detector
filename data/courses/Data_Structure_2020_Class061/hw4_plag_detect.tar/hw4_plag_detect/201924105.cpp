#include <iostream>

using namespace std;

#define MaxElements 100

class MatrixElement {
public:
    int row,col;
    int value;
};

class SparseMatrix {
public:
    int nRows, nCols, nElements;
    MatrixElement smArray[MaxElements];
    SparseMatrix(int r, int c): nRows(r), nCols(c), nElements(0) { }
    void addElement(int r, int c, int v) {
        smArray[nElements].row = r;
        smArray[nElements].col = c;
        smArray[nElements].value = v;
        nElements++;
    }
    ostream& operator <<(ostream& out) {
        out << nRows << " "
            << nCols << " "
            << nElements << endl;
        for (int i = 0; i < nElements; i++)
            out << "(" << smArray[i].row << "," 
                        << smArray[i].col << ","
                        << smArray[i].value << ")" << (i == nElements-1? "":"\n");

        return out;
    }
    SparseMatrix transpose()
    {
        SparseMatrix B(nCols, nRows);
        B.nElements = nElements;
        if(nElements != 0)
        {
            int colSize[nCols] = {0};
            for(int i=0; i<nElements; i++)
                colSize[smArray[i].col] += 1;

            int rowIndex[nCols] = {0};
            for(int i=0, sum=0; i<nCols; i++)
            {
                rowIndex[i] = sum;
                sum += colSize[i];
            }

            for(int i=0; i<nElements; i++)
            {
                B.smArray[rowIndex[smArray[i].col]].row = smArray[i].col;
                B.smArray[rowIndex[smArray[i].col]].col = smArray[i].row;
                B.smArray[rowIndex[smArray[i].col]].value = smArray[i].value;
                rowIndex[smArray[i].col]++;
            }
        }

        return B;
    }
    SparseMatrix operator *(SparseMatrix B)
    {
        SparseMatrix sm(nRows, nRows);
        for(int i=0; i<nElements; i++)
            for(int j=0; j<B.nElements; j++)
                if(smArray[i].col == B.smArray[j].row)
                {
                    if((sm.nElements != 0) && (sm.smArray[sm.nElements-1].row == smArray[i].row) && (sm.smArray[sm.nElements-1].col == B.smArray[j].col))
                    {
                        sm.smArray[sm.nElements-1].value += smArray[i].value * B.smArray[j].value;
                    }
                    else
                    {
                        sm.smArray[sm.nElements].row = smArray[i].row;
                        sm.smArray[sm.nElements].col = B.smArray[j].col;
                        sm.smArray[sm.nElements].value = smArray[i].value * B.smArray[j].value;
                        sm.nElements++;
                    }
                }
        
        return sm;
    }
};


int main () {
    int row, col;
    cin >> row >> col;
    int a[row][col] = {{0}};
    for(int i=0; i<row; i++)
        for(int j=0; j<col; j++)
            cin >> a[i][j];

    SparseMatrix A(row, col);
    for (int i = 0; i < row; i++)
        for (int j = 0; j < col; j++)
            if (a[i][j] != 0)
                A.addElement(i, j, a[i][j]);

    SparseMatrix B = A.transpose();
    SparseMatrix sm = A*B;
    sm << cout;

    return 0;
}