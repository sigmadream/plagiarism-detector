

#include <iostream>

using namespace std;

 

class SparseMatrix;

 

class MatrixTerm

{

        friend class SparseMatrix;

        friend ostream &operator<<(ostream &os, const SparseMatrix S); //���

        friend istream &operator>>(istream &is, SparseMatrix S); //�Է�

private:

        int row, col, value;

};

 

class SparseMatrix

{

private:

        int rows, cols, total, capacity;

        MatrixTerm *smArray;

public:

        SparseMatrix(int MaxRow=1, int MaxCol=1)

        {

               rows = MaxRow;

               cols = MaxCol;
               
               total = rows * cols;
			   smArray = new MatrixTerm[total];
        }
		
		SparseMatrix Transpose_Matrix()
		{
			int j = 0;
			SparseMatrix t(cols, rows);
			for(int i = 0; i<rows; i++){
				for(int m =0; m<cols ; (j++,m++)){
					t.smArray[j].row=m ;
					t.smArray[j].col=i;
					t.smArray[j].value= smArray[j].value;
				}
			}
			
			return t;
			
			
		}
		int store(SparseMatrix b, int t= 0, int j = 0){
			int store =0;	
			for(; t<j; t++){
					store = store + smArray[t].value * b.smArray[t].value;
				}
			
			return store;		
		}
			
		

        SparseMatrix Multiply(SparseMatrix b) 

        {	int k = 0;
        	int a_value = 0;
        	int count =1;
        	SparseMatrix a(rows, b.cols);
        	
        	for(int i = 0 ; i<a.rows ; i++){
        	 	for(int j = 0 ; j <a.cols; (j++,k++)){
						a.smArray[k].row=i ;
						a.smArray[k].col=j;		
						cout <<  a.smArray[k].col << endl;
						cout <<  a.smArray[k].row << endl;
								
					}
				a.smArray[k].value = store(b, cols*i, cols*(i+1));
				cout <<  a.smArray[k].value << endl;
			
					
					
				}
			 
			 return a;
        	
        	
      



        }
        

        friend ostream &operator<<(ostream &os, const SparseMatrix S); //���

        friend istream &operator>>(istream &is, SparseMatrix S); //�Է�

};

 

ostream &operator<<(ostream &os, const SparseMatrix S)

{
		int count = 0;

		for (int i = 0; i < S.total; i++)

        {	if(S.smArray[i].value != 0)
				count = count +1 ;

        }
        
        os << S.rows  << " "<< S.cols  << " "<<count <<endl;
        
        for (int i = 0; i < S.total; i++)

        {
			if(S.smArray[i].value != 0)
            	os << "(" << S.smArray[i].row << ", " << S.smArray[i].col << ", " << S.smArray[i].value << ")" << endl;

        }





        return os;

}

 

istream &operator>>(istream &is, SparseMatrix S)

{		int j= 0;
		int k[3];
	
        for (int i = 0; i < S.rows; i++)
        {		if(S.cols==1)
        		is >> k[0];
        		else if(S.cols==2)
        		is >> k[0] >> k[1];
        		else
        		is >> k[0] >>k[1] >>k[2];
            	for(int m=0; m < S.cols; (j++,m++)){
               		S.smArray[j].row=i ;
					S.smArray[j].col=m;
					S.smArray[j].value=k[m];

			   }

        } 

        return is;

}

 

int main(void)

{		int m, n = 0 ;
		cin >> m >> n;
        SparseMatrix s(m, n);

   

        cin >> s;
	
        
        SparseMatrix t = s.Transpose_Matrix();
       
      
        SparseMatrix y = t.Multiply(s);
        
        cout  << y <<endl;



        return 0;

}
