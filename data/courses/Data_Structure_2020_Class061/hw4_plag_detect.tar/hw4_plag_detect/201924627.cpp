#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

template <typename T> class Matrix {
private:
    int msize[2]; 
    vector<vector<T> > matrix;

    vector<T> get_row(int row_num) const {
        return matrix[row_num];
    }

    vector<T> get_col(int col_num) const {
    	Matrix<T> copy = *this;
        copy.transpose();
        return copy.matrix[col_num];
    }

    T dot_product(const vector<T> v1, const vector<T> v2) const {
        if(v1.size() != v2.size()) {
            cout << "Can not multiply vectors";
            return 0;
        }
        T result = 0;
        for(unsigned int i = 0; i < v1.size(); i++)
            result += v1[i] * v2[i];
        return result;
    }
public:
    Matrix<T>(const int row_num = 0, const int col_num = 0) {
        matrix.resize(row_num);
        for(int i = 0; i < row_num; i++) {
            matrix[i].resize(col_num, 0);
        }
        msize[0] = row_num;
        msize[1] = col_num;
    }

    template <typename T1>
    Matrix<T> (const Matrix<T1> &obj) {
        msize[0] = obj.get_row_num();
        msize[1] = obj.get_col_num();
        matrix.resize(msize[0]);

        for(int i = 0; i < msize[0]; i++) {
            matrix[i].resize(msize[1]);
        }

        for(unsigned int i = 0; i < matrix.size(); i++) {
            for(unsigned int j = 0; j < matrix[i].size(); j++) {
                matrix[i][j] = static_cast<T>(obj.get_entry(i, j));
            }
        }
    }

    Matrix<T> operator* (Matrix<T> const &obj) {
        if(msize[1] != obj.msize[0]) {
            cout << "Can not multiply matrices.\n";
            return obj;
        }

        Matrix<T> result(msize[0], obj.msize[1]);

        for(int i = 0; i < msize[0]; i++) {
            for(int j = 0; j < obj.msize[1]; j++) {
                result.matrix[i][j] = dot_product(get_row(i), obj.get_col(j));
            }
        }

        return result;
    }
    
    int count_non_zero() {
    	int res = 0;
    	for(int i = 0; i < msize[0]; i++) {
    		for(int j = 0; j < msize[1]; j++) {
    			if(matrix[i][j] != 0) {
    				res++;
				}
			}
		}
		return res;
	}

    friend ostream& operator<< (ostream &os, Matrix<T> &obj) {
    	int non_zero_num = obj.count_non_zero(), k = 0;
    	os << obj.msize[0] << " " << obj.msize[1] << " " << non_zero_num << "\n";
    	
        for(int i = 0; i < obj.msize[0]; i++) {
            for(int j = 0; j < obj.msize[1]; j++) {
            	if(obj.matrix[i][j] != 0){
            		k++;
            		os << "(" << i << "," << j << "," << obj.matrix[i][j] << ")";
            		if(k != non_zero_num) {
		            	os << "\n";
					}
				}
            }
        }
        return os;
    }

    int get_row_num() const{
        return msize[0];
    }

    int get_col_num() const{
        return msize[1];
    }

    T get_entry(int i, int j) const {
        return matrix[i][j];
    }
    
    void assign(int row_pos, int col_pos, T val) {
    	matrix[row_pos][col_pos] = val;
	}
	
	void transpose() {
		Matrix<int> copy(msize[0], msize[1]);
		for(int i = 0; i < msize[0]; i++) {
			for(int j = 0; j < msize[1]; j++) {
				copy.matrix[i][j] = matrix[i][j];
			}
		}
		
		matrix.resize(msize[1]);
        for(int i = 0; i < msize[1]; i++) {
            matrix[i].resize(msize[0], 0);
        }
		
		for(int i = 0; i < msize[0]; i++) {
			for(int j = 0; j < msize[1]; j++) {
				matrix[j][i] = copy.matrix[i][j];
			}
		}
		msize[0] = msize[0] + msize[1];
		msize[1] = msize[0] - msize[1];
		msize[0] = msize[0] - msize[1];
	}

    ~Matrix() {}
};

int main()
{
	int row_num = 0, col_num = 0, val = 0;
	cin >> row_num >> col_num;	
    
	Matrix<int> A(row_num, col_num);
	for(int i = 0; i < row_num; i++){
		for(int j = 0; j < col_num; j++) {
			cin >> val;
			A.assign(i, j, val);
		}
	}
	Matrix<int> B(row_num, col_num);
	B = A;
	A.transpose();
	
	Matrix<int> C(row_num, col_num);
	C = B * A;
	
	cout << C;

    return 0;
}
