#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <stdlib.h>
#include <string.h>

using namespace std;
class SparseMatrix{
public:
    SparseMatrix(){this->_nrow = 100; this->_ncol = 100;};
    SparseMatrix(int _nrow1, int _ncol1):_nrow(_nrow1),_ncol(_ncol1){}
    ~SparseMatrix(){}
    void make();
    void detailShow();
    SparseMatrix transpose();
    SparseMatrix mulMatrix(SparseMatrix *sm2);
    void print();
private:
    int _nrow, _ncol;
    int matrix[100][100];
    vector<string> printMatrix;
};

ostream &operator<<(ostream& os, SparseMatrix sm);
SparseMatrix SparseMatrix::mulMatrix(SparseMatrix *sm2) {
    SparseMatrix sm3(_nrow, sm2-> _ncol);
    for(int i = 0; i < _nrow; i++){
        for(int j = 0; j < sm2->_ncol; j++){
            for(int z = 0; z < _ncol; z++){
                sm3.matrix[i][j] += this->matrix[i][z] * sm2->matrix[z][j];
            }
        }
    }
    return sm3;
}
SparseMatrix SparseMatrix::transpose() {
    SparseMatrix sm2(_ncol, _nrow);
    for(int i = 0; i < _nrow; ++i){
        for(int j = 0; j < _ncol; ++j){
            sm2.matrix[j][i] = matrix[i][j];
        }
    }
    return sm2;
}
void SparseMatrix::make() {
    for(int i = 0; i <_nrow; i++){
        for(int j = 0; j < _ncol; j++){
            cin >> matrix[i][j];
        }
    }
}
void SparseMatrix::print() {
    for(int i = 0; i < _nrow; i++){
        for(int j = 0; j < _ncol; j++){
            cout << matrix[i][j] << "  ";
        }
        cout << endl;
    }
}

void SparseMatrix::detailShow() {
    int val_cnt = 0;
    for(int i = 0; i < _nrow; i++){
        for(int j = 0; j < _ncol; j++){
            if(matrix[i][j] != 0) {
                val_cnt++;
                stringstream ss,ss1,ss3;
                ss << i;
                ss1 << j;
                ss3 << matrix[i][j];
                string temp1 = ss.str();
                string temp2 = ss1.str();
                string temp3 = ss3.str();
                string sentence;
                sentence = "("+ temp1 + "," + temp2+ "," + temp3 + ")";
                printMatrix.push_back(sentence);
            }
        }
    }
    cout <<_nrow << ' ' << _ncol << ' ' << val_cnt << endl;
    for (int i = 0; i < printMatrix.size(); i++){
        cout << printMatrix[i] << endl;
    }
}
int main()
{
    int a, b;
    cin >> a >> b;
    SparseMatrix sm(a, b);
    sm.make();
    SparseMatrix sm2 = sm.transpose();
    SparseMatrix sm3 = sm.mulMatrix(&sm2);
    sm3.detailShow();
    return 0;
}