#include <iostream>
#include <stack>

using namespace std;

int main(){

    stack<int> Stack1;
    stack<int> Stack2;
    int num;
    cin >> num;
    int arr_1[num];
    int arr_2[num];
    for (int i=0; i<num; i++)
    {
        cin >> arr_1[i] >> arr_2[i];
    }
    for (int i=num-1; i>=0; i--)
    {
        Stack1.push(arr_1[i]);
        Stack2.push(arr_2[i]);
    }

    while(!Stack1.empty() && !Stack2.empty()){
        int i = 0;
        if(Stack1.top() >= Stack2.top()){
            cout << Stack1.top() << endl ;
            Stack1.pop();
        }
        else if(Stack1.top() < Stack2.top()){
            cout << Stack2.top() << endl;
            Stack2.pop();
        }
    }
    while(!Stack1.empty()){
        cout << Stack1.top() << endl;
        Stack1.pop();
    }
    while(!Stack2.empty()){
        cout << Stack2.top() << endl;
        Stack2.pop();
    }
    return 0;
}
