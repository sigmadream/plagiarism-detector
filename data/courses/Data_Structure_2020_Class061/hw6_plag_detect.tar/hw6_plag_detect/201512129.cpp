#include<iostream>
using namespace std;
class Term{
private:
    int priority;
    Term* next;
public:
    Term() {}
    Term(int p): priority(p) {next = NULL;}
    void setNext(Term* t) {next = t;}
    Term* getNext() {return next;}
    int getPrior() {return priority;}
};

class Queue{
private:
    Term* root;
    Term* rear;
    int nElement;
public:
    Queue(): nElement(0) {root = NULL; rear = NULL;}
    bool empty() {return !nElement;}
    void enqueue(int data){
        Term* newTerm = new Term(data);
        this->enqueue(newTerm);
    }
    void enqueue(Term* t){
        if(empty()) root = t;
        else(rear->setNext(t));
        rear = t;
        nElement++;
    }
    Term* dequeue() {
        if (empty()) return new Term(-1);
        Term* pop = root;
        root = root->getNext();
        nElement--;
        return pop;
    }
    Queue makeSchedule(Queue& q);
    void print(){
        Term* curr = root;
        while(curr) {
            cout << curr->getPrior() << endl;
            curr = curr->getNext();
        }
    }
};
Queue Queue :: makeSchedule(Queue& q){
    Queue queue;
    Term* it = root, *qIt = q.root;
    int tmp, qTmp;
    while(it != NULL || qIt != NULL){
        tmp = it ? it->getPrior() : 0;
        qTmp = qIt ? qIt->getPrior() : 0;
        if (tmp < qTmp){
            queue.enqueue(q.dequeue());
            qIt = qIt->getNext();
        }
        else{
            queue.enqueue(dequeue());
            it = it->getNext();
        }
    }
    return queue;
}

int main(){
    int testcase;
    cin >> testcase;
    int plane[testcase][2];
    for(int i = 0; i < testcase; i++){
        cin >> plane[i][0] >> plane[i][1];
    }
    Queue A, B;
    for(int i = 0 ; i < testcase; i++){
        A.enqueue(plane[i][0]);
        B.enqueue(plane[i][1]);
    }
    Queue schedule = A.makeSchedule(B);
    schedule.print();
}