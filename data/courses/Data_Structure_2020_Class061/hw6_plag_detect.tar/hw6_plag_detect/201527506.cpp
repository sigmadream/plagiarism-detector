#include <iostream>

using namespace std;

class Node
{
public:
	int value;
	Node* next;
	
public:
	Node() : value(0), next(nullptr) {};
	~Node() {};
};

class Queue
{
public:
	Queue() :head(nullptr), tail(nullptr), size(0) {};
	~Queue() {};
	void Enqueue(int _value);
	int Dequeue();
	int get_size();
	int peek();
	int IsEmpty();
	void error(){
		throw -1;
	}
	
private:
	Node* head;
	Node* tail;
	int size;
};

void Queue::Enqueue(int _value)
{
	Node* newNode = new Node;
	newNode->value = _value;
	size+=1;
	
	if(this->head == nullptr)
	{
		head = newNode;
		tail = newNode;
	}
	else
	{
		tail->next = newNode;
		tail = tail->next;
	}
}

int Queue::Dequeue()
{
	try{
		size-=1;
		IsEmpty();
	}
	catch (int _){
		return -1;
	}
	
	Node* ptr = head;
	int value = head->value;
	
	if(head == tail)
	{
		head = nullptr;
		tail = nullptr;
		delete(head);
	}
	else
	{
		ptr = ptr->next;
		delete(head);
		head = ptr;
	}
	return value;
}

int Queue::get_size()
{
	return this->size;
}

int Queue::peek()
{
	try{
		size-=1;
		IsEmpty();
	}
	catch (int _){
		return -1;
	}
	
	return head->value;
}

int Queue::IsEmpty()
{
	if(tail == nullptr)
		error();
	return 1;
			
}

int main(void){
	Queue runway;
	Queue lane1;
	Queue lane2;
	
	int n, p1, p2;
	cin >> n;
	
	for(int i=0; i<n; ++i){
		cin >> p1 >> p2;
		lane1.Enqueue(p1);
		lane2.Enqueue(p2);
	}
	
	int runway_sz = lane1.get_size() + lane2.get_size();
	
	for(int i=0; i<runway_sz; ++i){
		int t1, t2;
		t1 = lane1.peek();
		t2 = lane2.peek();
		
		if(t1 > t2){
			lane1.Dequeue();
			runway.Enqueue(t1);
		}
		else{
			lane2.Dequeue();
			runway.Enqueue(t2);
		}
	}
	
	while(true){
		try{
			runway.IsEmpty();
			cout << runway.Dequeue() << endl;
		}
		catch (int _){
			break;
		}		
	}
	return 0;
}
