#include <iostream>
#include <queue>

using namespace std;

int main(){
	int a=0;
	int b=0;
	int k=0;
	int i=0;
	queue<int> q1;
	queue<int> q2;
	cin >> k;
	while(i<k)
	{
		cin >> a >> b;
		q1.push(a);
		q2.push(b);
		++i;
	}	
	// ť ����
	i=0;
	while(i<2*k){
		++i;
		a=q1.front();
		b=q2.front();
		
		if(a>1000001) a=0;
		if(b>1000001) b=0;
		if(a<b)
		{
		cout << q2.front() << '\n';
			q2.pop();
		}
		else
		{
		cout << q1.front() << '\n';
			q1.pop();
		}

	}


	return 0;

}
