/*
* Author: Chunsu Kim
* Number: 201624458
* Date: 2020-10-14
* Title: plane.cpp
*/

#include <iostream>
using namespace std;

class Node {
	friend class CircularList;
private:
	int data;
	Node* next;
public:
	Node(int a) :data(a) {}
};

class CircularList {
private:
	Node* first;
public:
	CircularList(int number) {
		
	}
	CircularList(){}
	void insert(int data);
	int deleteNode();
	int QueueEmpty();
	int getData();
};

int CircularList::deleteNode() {
	try {
		int true_and_false = QueueEmpty();
	}
	catch (int _) {	//empty so we can't process delete function anymore
		return -1;
	}
	int tmpData = last->next->data;
	Node* first = last->next;
	last->next = first->next;
	delete first;
	return tmpData;
}

void CircularList::insert(int data) {
	Node* newNode = new Node(data);
	newNode->next = first->next; //... = head->next;
	first->next = newNode;
}

int CircularList::getData() {
	return first->data;
}
int CircularList::QueueEmpty() {
	//I have to make try/catch statement here... but i don't have any idea now.
		if (first == NULL)
		return true; // empty
	else
		return false; // not empty
}

int main() {
	CircularList queue1;
	CircularList queue2;
	CircularList queue3;
	queue1.insert(12);
	queue1.insert(6);
	queue1.insert(5);
	queue1.insert(2);
	queue1.insert(10);
	queue2.insert(14);
	queue2.insert(3);
	queue2.insert(22);
	queue2.insert(17);
	queue2.insert(8);

	while (!queue1.QueueEmpty()) {
		if (queue1.getData() > queue2.getData())
		{
			queue3.insert(queue1.getData());
			queue1.deleteNode();
		}
		else
		{
			queue3.insert(queue2.getData());
			queue2.deleteNode();
		}
	}
	if (!queue2.QueueEmpty()) {
		while (!queue2.QueueEmpty()) {
			queue3.insert(queue2.getData());
			queue2.deleteNode();
		}
	}


}