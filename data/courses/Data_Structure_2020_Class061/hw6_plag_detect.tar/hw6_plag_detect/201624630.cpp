#include <iostream>
#include <stack>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
class Counter {
	private : 
		int _cnt;
	public : 
		Counter(int n) : _cnt(n){ }
		int operator --(int){
			if (_cnt < 0) error();
			return _cnt--;
		}
		void error(){
			throw -1;
		}
};
int main() {
	int b;
	int n=0;
	int z=1;
	int i=1;
	int a[100010];
	cin >> b;
	for(int i =0;i < b * 2 ;i++){
		cin >> a[i];
	} 
	/*
	Counter cnt(b);
	try {
		while(true) cout << cnt-- << endl;
	}
	catch (int err){
		cerr << "Negative counter" << endl;
		return err;
	}
	*/

	
	stack<int>mystack1;
	
	stack<int>mystack2;
	
	stack<int>mystack3;
	
	mystack1.push(a[0]);
	mystack2.push(a[1]);
	
	for (int i = 2*b ; i >=0; i--){
		mystack1.push(a[2*i]);
		mystack2.push(a[2*i+1]);
	}
	
	while(!mystack1.empty() && !mystack2.empty()){
		if(mystack1.top() > mystack2.top()){
			mystack3.push(mystack1.top());
			mystack1.pop();
			cout << mystack3.top() <<endl;
		}
		else if(mystack2.top() >mystack1.top()){
			mystack3.push(mystack2.top());
			mystack2.pop();
			cout << mystack3.top() << endl;
		}
		else 
		return 0;
	}
	return 0; 
	
	
	/*
	
	while(!mystack1.empty() && !mystack2.empty() && i < b*2 && z < b*2){
		if (mystack1.top() < mystack2.top()){
			mystack3.push(mystack1.top());
			mystack1.pop();
			i++;
			mystack1.push(a[2*i]);
			cout << mystack3.top();
		}
		else if(mystack1.top() < mystack2.top())
		{
			mystack3.push(mystack2.top());
			mystack2.pop();
			z++;
			mystack2.push(a[2*z + 1]);
			cout << mystack3.top();
		}
	}
	/*
	while (!mystack3.empty() && n < 2*b){ 
			cout << mystack3.top() << endl;
            mystack3.pop();
            n++; 
        } 
*/
}

