#include <iostream>

using namespace std;

class Node {
    friend class Queue;
public:
    Node(const int data);
private:
    int data;
    Node *next;
};

class Queue {
private:
    Node *last;
    int nElements;
	void init();
public:
    void insert(int data, int index);
    int remove();
};

Node::Node(const int data) {
	this->data = data;
	this->next = NULL;
}

void Queue::insert(int data, int index) {
    Node *newNode= new Node(data);
    if (last==NULL){
        last=newNode;
        last->next=last;
    }
    else {
        newNode->next=last->next;
        last->next=newNode;
        last=newNode;
    }
    nElements++;
}

int Queue::remove() { 
    if (last == NULL)
        cout << "queue is empty" << endl;
    int tmpData=last->next->data;
    Node *first=last->next;
    last->next=first->next;
    delete first;
    return tmpData;
};


void Queue::init() {
	last = NULL;
    nElements = 0;
}

int main() {
    Queue AirPlain1, AirPlain2, Total;
    int setNum = 0;
    int AP1, AP2;
    cin >> setNum;
    if (setNum <= 0)
        cout << "wrong number" <<endl;
    else {
        for(int i=0; i < setNum; i++) {
            
            cin >> AP1 >> AP2;
            AirPlain1.insert(AP1,i);
            AirPlain2.insert(AP2,i);
        }

        
    }

    return 0;
}