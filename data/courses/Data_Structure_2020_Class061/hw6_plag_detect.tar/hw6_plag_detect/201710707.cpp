#include <iostream>
#include <stdlib.h>
using namespace std;

int A[1000000];
int B[1000000];
int C[2000000];

int main() {
	int n;
	int i,j;
	int cA=0,cB=0;
	
	cin >> n;
	for(i=0;i<n;i++)
		cin >> A[i] >> B[i];
		
	for(i=0;i<2*n;i++) {
		if(cA==n) C[i] = B[cB++];
		else if(cB==n) C[i] = A[cA++];
		else if(A[cA] > B[cB]) C[i] = A[cA++];
		else if(A[cA] <= B[cB]) C[i] = B[cB++];
	}
	
	for(i=0;i<2*n;i++)
		cout << C[i] << endl;
		
	return 0;
}
