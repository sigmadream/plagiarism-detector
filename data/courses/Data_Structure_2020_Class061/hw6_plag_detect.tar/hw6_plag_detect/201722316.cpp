#include <iostream>

class Node
{
    friend class CircularList;

private:
    int data;
    Node *next;

public:
    Node(int Num) { data = Num; };
};

class CircularList
{
private:
    Node *last = NULL;

public:
    void insert(int data)
    {
        Node *newNode = new Node(data);
        if (last == NULL)
        {
            last = newNode;
            newNode->next = last;
            return;
        }
        newNode->next = last->next;
        last->next = newNode;
        last = newNode;
    };
    void QueueEmpty()
    {
        throw -1;
    };
    int Del()
    {
        if (last == NULL)
        {
            QueueEmpty();
            return 0;
        }
        int tmpData;
        if (last->next == last)
        {
            tmpData = last->data;
            last = NULL;
        }
        else
        {
            Node *first = last->next;
            tmpData = first->data;
            last->next = first->next;
            delete first;
        }
        return tmpData;
    };
    int show_data(Node *p)
    {
        return p->data;
    };
};

int main()
{
    int linenum;
    std::cin >> linenum;
    CircularList firstline, secondline;
    int a, b;
    for (int i = 0; i < linenum; i++)
    {
        std::cin >> a;
        firstline.insert(a);
        std::cin >> b;
        secondline.insert(b);
    }
    CircularList final_line;
    int num1, num2;
    num1 = firstline.Del();
    num2 = secondline.Del();
    for (int i = 0; i < linenum * 2; i++)
    {
        if (num1 >= num2)
        {
            final_line.insert(num1);
            try
            {
                num1 = firstline.Del();
            }
            catch (int x)
            {
                num1 = x;
            }
        }
        else
        {
            final_line.insert(num2);
            try
            {
                num2 = secondline.Del();
            }
            catch (int x)
            {
                num2 = x;
            }
        }
    }
    for (int i = 0; i < linenum * 2; i++)
    {
        std::cout << final_line.Del() << std::endl;
    }
    return 0;
}