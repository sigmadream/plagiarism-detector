#include <iostream>

using namespace std;

class Node {
	friend class Queue;
private:
	int value;
	Node* next;
public:
	Node(int value) : value(value) {}
};

class Queue {
private:
	Node* last;
public:
	Queue() : last(NULL) {}
	void push(int value) {
		Node* newNode = new Node(value);
		if (last == NULL) {
			last = newNode;
			last->next = last;
			return;
		}
		newNode->next = last->next;
		last->next = newNode;
		last = newNode;
	}
	void pop() {
		if (last == NULL) return;
		if (last->next == last) {
			delete last;
			last = NULL;
			return;
		}
		Node* first = last->next;
		last->next = first->next;
		delete first;
	}
	void print() {
		Node* p = last->next;
		while (p != last) {
			cout << p->value << "\n";
			p = p->next;
		}
		cout << p->value << "\n";
	}
	Queue NewQue(Queue& q2) {
		Queue newQue;
		while (last != NULL && q2.last != NULL) {
			if (last->next->value == q2.last->next->value) {
				newQue.push(last->next->value);
				pop(); q2.pop();
			}
			else if (last->next->value > q2.last->next->value) {
				newQue.push(last->next->value);
				pop();
			}
			else if (last->next->value < q2.last->next->value){
				newQue.push(q2.last->next->value);
				q2.pop();
			}
		}
		while (last != NULL) {
			newQue.push(last->next->value);
			pop();
		}
		while (q2.last != NULL) {
			newQue.push(q2.last->next->value);
			q2.pop();
		}
		return newQue;
	}
};
int main() {
	int n;
	int a, b;
	Queue q1, q2, q3;
	cin >> n;
	while (n > 0) {
		cin >> a >> b;
		q1.push(a); q2.push(b);
		n--;
	}
	q3 = q1.NewQue(q2);
	q3.print();
	return 0;
}