#include <iostream>
using namespace std;

class myQueue;

class Node{
    friend myQueue;
private:
    int Number;

    Node* next;
public:
    Node(){}
    Node(const int n){ Number = n; }
    const int returnNo(){ return Number; }
};

class myQueue{
private:
    Node* last;
public:
    myQueue(){
    	last = NULL;
	}

    void Insert(const int n){
        Node* tmpNode = new Node(n);
        if(last == NULL){
        	last = tmpNode;
        	last -> next=last;
        	return;
		}
        tmpNode->next = last->next; // �߰��� ����� ���� ���� ������ ��. (��ġ)
        last->next = tmpNode; // ���� ��Ʈ�� ���� Node�� temp
        last = tmpNode; // tmpNode�� ����������.
    }

    const int Delete(){
    	if(last == NULL) NULL_DATA(); // �ƹ��͵� ���� ��, return 0
    	
        if(last == last->next){
        	int returnVal = last->returnNo();
        	last = NULL;
        	return returnVal;
		}
        
        int returnVal = last->next->returnNo();
		Node* first = last->next;
        last->next = first->next;
        
        delete first;
        return returnVal;
    }
    
    void NULL_DATA(){
    	throw 0;
	}
};

int main(){
    int planeNo;
    cin >> planeNo;
    if (planeNo == 0) return 0;
    
    myQueue Q1, Q2;
    int x, y;
    for(int i=0; i<planeNo; i++){
        cin >> x >> y;
        Q1.Insert(x);
        Q2.Insert(y);
    }
    
    x = Q1.Delete(); y = Q2.Delete();
    while(true){
    	if(x>y){
    		cout << x << endl;
    	try{
    		x = Q1.Delete();
		}catch(int _){ // x�� NULL data 
			try{
				while(true){
					cout << y << endl;
					y = Q2.Delete();
				}
			}catch(int _){ // ���� ���� 
				return 0;
			}
		}
		}
		
		else{
			cout << y << endl;
		try{
			y = Q2.Delete();
		}catch(int _){ // y�� NULL data 
			try{
				while(true){
					cout << x << endl;
					x = Q1.Delete();
				}
			}catch(int _){ // ���� ���� 
				return 0;
			}
		}
		}
	}

    return 0;
}
