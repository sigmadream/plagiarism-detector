#include <iostream>


using namespace std;

class Queue {
public:
  struct Node {
    int data;
    Node* link;
  };


  struct Node* front=NULL;
  struct Node* rear=NULL;
  void enQueue(int value)
  {
      struct Node* temp = new Node;
    temp->data = value;
    if (this->front == NULL)
        this->front = temp;
    else
        this->rear->link = temp;

    this->rear = temp;
    this->rear->link = this->front;
  }
  int deQueue()
  {
      if (this->front == NULL) {
        return -1;
    }
    int value;
    if (this->front == this->rear) {
        value = this->front->data;
        delete(this->front);
        this->front = NULL;
        this->rear = NULL;
    }
    else
    {
        struct Node* temp = this->front;
        value = temp->data;
        this->front = this->front->link;
        this->rear->link = this->front;
        delete(temp);
    }

    return value;
  }
};

int main() {

Queue lane1;
Queue lane2;
Queue takeoff;
int size;
int temp1,temp2;

cin>>size;

for(int i=0;i<size;i++){
  cin>>temp1>>temp2;
  lane1.enQueue(temp1);
  lane2.enQueue(temp2);
}

temp1=lane1.deQueue();
temp2=lane2.deQueue();

for(int i=0;i<2*size+2;i++){
  
   if(temp1 > temp2){
    takeoff.enQueue(temp1);
    //cout<<temp1<<endl;
    temp1=lane1.deQueue();
  }else if(temp1 < temp2){
    takeoff.enQueue(temp2);
    // cout<<temp2<<endl;
    temp2=lane2.deQueue();
  }else{
    if(temp1 == -1 && temp2 != -1){
    takeoff.enQueue(temp2);
    //cout<<temp2<<endl;
    temp2=lane2.deQueue();
  }else if(temp2 == -1 && temp1 != -1){
    takeoff.enQueue(temp1);
    //cout<<temp1<<endl;
    temp1=lane2.deQueue();
  }
  }

}

for(int i=0;i<2*size;i++){
  try{
    cout<<takeoff.deQueue()<<endl;
  }
  catch(int __){
    cerr <<"Embty Queue" <<endl;
    return -1;
  }
  
}


}
