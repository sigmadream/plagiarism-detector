#include <iostream>

using namespace std;

class Node {
friend class Flightlist;
private:
	int priority;
	Node *next;
public:
	Node(int a) : priority(a) {}
	int returnPrior() {
		return priority;
	}
	Node* returnNext() {
		return next;
	}
};

class Flightlist {
private:
	Node *first = NULL;
public:
	void insert(int p) {
		Node *newNode = new Node(p);
		if(first==NULL) {
			first=newNode;
			newNode->next=NULL;
		}
		else {
			Node* current;
			current = first;
			while(current->next != NULL) {
				current = current->next;
			}
			current->next = newNode;
			current = newNode;
			newNode->next=NULL;
		}
	}
	
	Node* firstReturn() {
		return first;
	}
	int isEmpty() {
		if(first==NULL) return 1;
		else return 0;
	}
	void pop() {
		Node *temp = first;
		first = temp->next;
		delete temp;
	}
	//Node *search();
};

int main(void)
{
	Flightlist Runway_1, Runway_2, sequence;
	Node *rw_1, *rw_2;
	int n, i, prior_1, prior_2;
	
	cin >> n;
	
	for(i = 0; i < n; i++) {
		cin >> prior_1 >> prior_2;
		Runway_1.insert(prior_1);
		Runway_2.insert(prior_2);
	}
	rw_1 = Runway_1.firstReturn();
	rw_2 = Runway_2.firstReturn();
	
	while( Runway_1.isEmpty() == 0 && Runway_2.isEmpty() == 0 ) {
		rw_1 = Runway_1.firstReturn();
		rw_2 = Runway_2.firstReturn();
		prior_1 = rw_1->returnPrior();
		prior_2 = rw_2->returnPrior();
		if(prior_1 >= prior_2) {
			cout << prior_1 << endl;
			Runway_1.pop();
		}
		else {
			cout << prior_2 << endl;
			Runway_2.pop();
		}
	}
	if( Runway_1.isEmpty() == 1 && Runway_2.isEmpty() == 0 ) {
		while(Runway_2.isEmpty() == 0) {
			rw_2 = Runway_2.firstReturn();
			prior_2 = rw_2->returnPrior();
			cout << prior_2 << endl;
			Runway_2.pop();
		}
	}
	if( Runway_1.isEmpty() ==0 && Runway_2.isEmpty() == 1) {
		while(Runway_1.isEmpty() == 0) {
			rw_1 = Runway_1.firstReturn();
			prior_1 = rw_1->returnPrior();
			cout << prior_1 << endl;
			Runway_1.pop();
		}
	}
	
	return 0;
}
