#include<iostream>

using namespace std;

class ControlTower{
private:    
    int planeNum;
    int* lane1;
    int* lane2;
public:
    ControlTower(int _planeNum): planeNum(_planeNum) {
        if(this->IsEmpty()) empty();
        lane1 = new int[_planeNum];
        lane2 = new int[_planeNum];
    }
    //set method
    void setLane(){
        for(int i=0;i<planeNum;++i)
            cin >> lane1[i] >> lane2[i];
    }
    //empty
    bool IsEmpty(){
        bool rt;
        if(planeNum == 0) rt = true;
        return rt;
    }
    void empty() {
        cout << "This is Empty lane." << endl;
    }
    //another
    void print(){
        int i=0;
        int j=0;
        while(true) {
        	if(i == planeNum || j == planeNum) break;
            if(lane1[i]>lane2[j]) {
                cout << lane1[i] << endl;
                i++;
            }
            else {
                cout << lane2[j] << endl;
                j++;
            }
        }
        if(i < planeNum)
            for(int k=i;k<planeNum;++k)
                cout << lane1[k] << endl;
        if(j< planeNum)
            for(int k=j;k<planeNum;++k)
                cout << lane1[k] << endl;
    }
};

int main() {
    int num;
    cin >> num;
    ControlTower ct(num);
    ct.setLane();
    ct.print();
}
