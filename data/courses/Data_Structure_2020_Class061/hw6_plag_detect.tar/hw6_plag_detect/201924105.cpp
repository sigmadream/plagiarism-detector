#include <iostream>
using namespace std;

class Node {
  friend class Que;
private:
  int data;
  Node *next;
public:
  explicit Node(int newData): data(newData), next(NULL) {}
};

class Que {
private:
  Node *last;
public:
  Que() {
    last = NULL;
  }
  void Insert(int data) {
    Node *newNode = new Node(data);
    newNode->data = data;
    newNode->next = NULL;
    if(IsEmpty()) {
      last = newNode;
      last->next = last;
      return;
    }
    newNode->next = last->next;
    last->next = newNode;
    last = newNode;
  }
  int DeleteQ() {
    if(IsEmpty())
      cerr << "This Que is empty" << endl;
    int tmpData = last->next->data;
    Node *first = last->next;
    if(first == last)
      last = NULL;
    else
      last->next = first->next;
    delete first;
    return tmpData;
  }
  bool IsEmpty() {
    return (last == NULL);
  }
  int GetFirstData() {
    if(IsEmpty())
      return 0;
    else
      return last->next->data;
  }
};

int main(void) {
  int num, dataA, dataB, dataC;
  cin >> num;
  Que A;
  Que B;
  for(int i=0; i<num; i++) {
    cin >> dataA >> dataB;
    A.Insert(dataA);
    B.Insert(dataB);
  }

  Que C;
  for(int i=0; i<(2*num); i++) {
    if(A.GetFirstData() > B.GetFirstData())
      dataC = A.DeleteQ();
    else
      dataC = B.DeleteQ();
    C.Insert(dataC);
  }

  for(int i=0; i<(2*num); i++) {
    dataC = C.DeleteQ();
    cout << dataC << endl;
  }
  return 0;
}
