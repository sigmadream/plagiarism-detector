#include <iostream>
using namespace std; 
   
struct Node 
{ 
    int data; 
    struct Node* link; 
}; 
   
struct PQueue 
{ 
    struct Node *front, *last; 
}; 
   

void enQueue(PQueue *pq,int elem) 
{ 
     
   struct Node *temp = new Node; 
    temp->data = elem; 
    if (pq->front == NULL) 
        pq->front = temp; 
    else
        pq->last->link = temp; 
   
    pq->last = temp; 
    pq->last->link = pq->front; 
}


int deQueue(PQueue *pq) 
{ 
   if (pq->front == NULL) 
    { 
        return -1; 
    } 
   
    int elem;
    if (pq->front == pq->last) 
    { 
        elem = pq->front->data; 
        delete(pq->front); 
        pq->front = NULL; 
        pq->last = NULL; 
    } 
    else 
    { 
        struct Node *temp = pq->front; 
        elem = temp->data; 
        pq->front = pq->front->link; 
        pq->last->link= pq->front; 
        delete(temp); 
    } 
   
    return elem ; 
} 
  


int main() 
{ 
    PQueue *pq = new PQueue; 
    pq->front = pq->last = NULL; 
    PQueue *pm = new PQueue; 
    pm->front = pm->last = NULL; 
  
    int k,m,n;
    cin >> k;
    
    for(int j=0; j<k; j++){
    	cin >> m >> n;
    	enQueue(pq, m);
    	enQueue(pm, n);
	}
	
	int a = deQueue(pq);
	int b = deQueue(pm);
	while( a!= -1 || b!= -1){
		if(a>b){
			cout<< a <<endl;
			a = deQueue(pq);
		}
		else if(a<b){
			cout<< b <<endl;
			b= deQueue(pm);
		}
		
	}
}


