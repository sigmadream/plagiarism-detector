#include <iostream>
#include <climits>
using namespace std;

typedef struct Node {
	int value;
	struct Node* next;
} Node;

class Queue {
private:
	Node *head, *tail;
	int size;
public:
	Queue() {
		head = NULL;
		tail = NULL;
		size = 0;
	}
	
	void append(int val) {
		Node *tmp = new Node;
		tmp->value = val;
		tmp->next = NULL;
		size++;
		
		if(head == NULL) {
			head = tmp;
			tail = tmp;
			tmp = NULL;
		} else {
			tail->next = tmp;
			tail = tmp;
		}
	}
	
	int pop() {
		if(size == 0) {
			cerr << "List is empty.";
			return -1;
		}
		
		int val;
		size--;
		Node *tmp = new Node;
		tmp = head;
		val = head->value;
		head = tmp->next;
		delete tmp;
		return val;
	}
	
	bool isEmpty() {
		return size == 0;
	}
	
	int lastValue() {
		if(size == 0) return -INT_MAX;
		return head->value;
	}
	
	void print() {
		Node *tmp = new Node;
		tmp = head;
		
		while(tmp != NULL) {
			if(!isEmpty())
				cout << tmp->value << "\n";
			else
				cout << tmp->value;
			tmp = tmp->next;
		}
	}
};

inline bool isGreater(int a, int b) {
	return a >= b;
}

int main() {
	Queue line1, line2, result;
	int size, tmp1, tmp2;
	cin >> size;
	
	for(int i = 0; i < size; i++) {
		cin >> tmp1;
		line1.append(tmp1);
		cin >> tmp2;
		line2.append(tmp2);
	}
	
	do {
		if(isGreater(line1.lastValue(), line2.lastValue())) {
			result.append(line1.pop());
		} else {
			result.append(line2.pop());
		}
	} while(!(line1.isEmpty() && line2.isEmpty()));
	
	result.print();
	
	return 0;
}







