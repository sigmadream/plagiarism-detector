#include <iostream>
#include <string>
#include <vector>


using namespace std;


class Node{
    public:
        Node(){next = NULL;}
        int lanes;
        Node *next;
};

class Queue{
    public:
        Queue(){front = NULL; rear = NULL;}
        ~Queue(){delete [] front; delete [] rear;}
        bool error(){throw -1;};
        bool isEmpty(){if(front == NULL) error(); return true;}
        bool isFull();
        void push(int n);
        int pop();
        void battleLanes(Queue *q);
        void show();
    private:
        Node *front, *rear;
};

void Queue::push(int n){
    Node *temp = new Node;
    temp->lanes = n;
    if(front == NULL){
        front = temp;
    }else{
        rear->next = temp;
    }
    rear = temp;
    rear->next = front;
}

int Queue::pop(){
    if(front == NULL){
        isEmpty();
        return -1;
    }
    int value;
    if(front == rear){
        value = front->lanes;
        free(front);
        front = NULL; rear = NULL;
    }else{
        Node *temp = front;
        value = temp->lanes;
        front = front->next;
        rear->next = front;
        free(temp);
    }
    return value;
}

void Queue::show(){
    Node *temp = front;
    while(temp->next != front){
        cout << temp->lanes << " ";
        temp = temp->next;
    }
    cout << temp->lanes << endl;
}

void Queue::battleLanes(Queue *q){
    Node *ptr1 = new Node(); Node *ptr2 = new Node();vector<int> result;vector<int> result2;
    ptr1 = front; ptr2 = q->front;
    while(ptr1->next != front && ptr2->next != front){
        result.push_back(ptr1->lanes);result2.push_back(ptr2->lanes);
        ptr1 = ptr1->next; ptr2 = ptr2->next;
    }
    result.push_back(ptr1->lanes);result2.push_back(ptr2->lanes);
    vector<int>finalReturn;
    int i =0, j = 0;

    while(i != result.size() && j != result.size()){
        if(result[i] > result2[j]){
            finalReturn.push_back(result[i]);
            i++;
        }else if(result[i] < result2[j]){
            finalReturn.push_back(result2[j]);
            j++;
        }else if(result[i] == result2[j]){
            finalReturn.push_back(result[i]);
            finalReturn.push_back(result2[j]);
            i++;j++;
        }else if(i == j) break;
    }

    if(i != result.size()){
        for(int n = i; n < result.size(); n++) finalReturn.push_back(result[n]);
    }
    if(j != result2.size()){
        for(int n = j; n < result.size(); n++) finalReturn.push_back(result2[n]);
    }
    for (int i = 0; i < finalReturn.size(); ++i) {
        cout << finalReturn[i] << endl;
    }
}
int main(){
    int size;
    int linput, rinput;
    cin >> size;
    Queue *q1 = new Queue();Queue *q2 = new Queue();
    for(int i = 0; i < size; i++){
        cin >> linput >> rinput;
        q1->push(linput);q2->push(rinput);
    }
    q1->battleLanes(q2);
}