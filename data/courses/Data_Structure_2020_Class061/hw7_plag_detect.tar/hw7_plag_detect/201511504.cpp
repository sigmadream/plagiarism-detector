#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

int main(){
    int cnt;
    int num;
    int arr[10];
    string que;
    cin >> cnt;
    for (int i=0; i<cnt; i++){
            cin >> que >> num ;
            if (que == "enqueue"){
                arr[i] = num;
                cout << "[" << que << ": " << arr[i] << "]" << endl ;
                cout << "[flist: ]" << endl ;
            }
            else cout << "[" << que << ": " << num << "]" << endl ;
    }
}
