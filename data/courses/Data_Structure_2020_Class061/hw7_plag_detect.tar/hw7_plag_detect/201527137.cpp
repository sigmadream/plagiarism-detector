#include <iostream>
#include <cstdlib>
#include <bits/stdc++.h> 
using namespace std;

class Node {
	static Node FreeArr[10];
	static int FreePtr;
	public:
	int data;
	Node *next;
	Node() {}
	Node(int data): data(data), next(NULL) {}
	ostream& print(ostream& out) {
		return out << data << endl;
}

void * operator new(size_t size) {
	if (FreePtr < 10)
		return FreeArr + FreePtr++;
	return ::new Node();
}

void operator delete(void *p) {
	if (FreeArr <= p && p < FreeArr+FreePtr)
		--FreePtr;
	else
		free(p);
}

static void prFreeArr(ostream& out) {
	out << "[FreeArr:";
	for (Node& n: FreeArr) {
		out << " " << n.data;
	}
	out << "]" << endl;
	}
};
	
class LinkedQueue {
private:
	int len;
public:
	Node *front, *rear;
	LinkedQueue() :len(0) {
        front = rear = NULL;}
        
	bool isEmpty()
		{return len == 0;}
		
    void enqueue(int data) {
        Node *node = (Node*)malloc(sizeof(Node));
        node->data = data;
        node->next = NULL;
        if (isEmpty())
            front = rear = node;
        else {
            rear->next = node;
            rear = rear->next;
        }
        len++;
    }
    
    int dequeue(){
        Node *delNode = front;
        int ret = delNode->data;
        front = delNode->next;
        free(delNode);
        len--;
        return ret;}
    ~LinkedQueue(){}
};

int main(){
	string str="";
	int count=0 ,number=0 , i=0;
	cin >> count;
	LinkedQueue p,temp_1[count],temp_2[count];
	for(i=0;i<count;i++)
	{
		cin >> str;
		if(str=="enqueue"){
			cin >> number;
			p.enqueue(number);
			temp_1[i]=p;
			}
		else if(str=="dequeue")
			{
			temp_2[i].enqueue(p.dequeue());
			temp_1[i]=p;
			}
	}
	
	for(i=0;i<count;i++)
	{
		cout << "[queue:";
		while (!temp_1[i].isEmpty())
    		cout << " " << temp_1[i].dequeue();
		cout <<"]"<<endl;
		cout << "[flist:";
		while (!temp_2[i].isEmpty())
    		cout << " " << temp_2[i].dequeue();
		cout <<"]"<<endl;
	}

}
