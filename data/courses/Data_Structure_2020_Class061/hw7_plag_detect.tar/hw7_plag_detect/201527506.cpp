#include <iostream>
#include <cstdlib>
#define INF 10000

using namespace std;
class Node {
public:
	static Node FreeArr[10];
	static int FreePtr;
    int data;
    Node *next;
public:
	Node() {}
	Node(int _data): data(_data), next(NULL) {}
	ostream& print(ostream& os){
		return os << data << endl;
	}
	void* operator new(size_t size){
		if(FreePtr < 10)
			return FreeArr + FreePtr++;
	
		return ::new Node();
	}
	void operator delete(void *p){
		if(FreeArr <= p  && p < FreeArr+FreePtr)
			--FreePtr;
		else
			free(p);
	}
	static void prFreeArr(ostream& os) {
		os << "[flist:";
		for(int i=0; i<FreePtr; ++i){
			os << ' ' << FreeArr[i].data;
		}
		os << "]" << endl;
	}
};

Node Node::FreeArr[10];
int Node::FreePtr = 0;

class LinkedQueue {
public:
    Node *front, *rear;
public:
    int len = 0;
    LinkedQueue() {
        front = rear = NULL;
    }
    int size() {
        return len;
    }
 
    bool isEmpty() {
        return len ==0;
    }
 
    void enqueue(int data) {
        Node *node = (Node*)malloc(sizeof(Node));
        node->data = data;
        node->next = NULL;
        
        	
        if (isEmpty()) {
            front = rear = node;
        }
        else {
            rear->next = node;
            rear = rear->next;
        }
        len++;
    }
 
    int dequeue(LinkedQueue* dq) {
        if (isEmpty()) {
            cout << "Q is empty" << endl;
            return INF;
        }
 
        Node *delNode = front;
        int ret = delNode->data;
        dq->enqueue(ret);
        front = delNode->next;
        delete(delNode);
        len--;
        return ret;
    }
    
    void Print_Queue(void){
    	Node* temp = front;
		cout << "[queue:";
    	while(temp != NULL){
			cout << ' ' << temp->data;  
    		temp = temp->next;
		}
		cout << "]" << endl;  
	}
	
    void Print_flist(void){
    	Node* temp = front;
		cout << "[flist:";
    	while(temp != NULL){
			cout << ' ' << temp->data;  
    		temp = temp->next;
		}
		cout << "]" << endl;  
	}
	
};
 
int main() {
	int n;
	cin >> n;
	int* x = new int[n];
	string* temp = new string[n];
    LinkedQueue* q = new LinkedQueue[n];
    LinkedQueue* dq = new LinkedQueue[n];
    LinkedQueue* tq = new LinkedQueue[n];
    
    for(int i = 0; i <n; ++i){
    	cin >> temp[i];
    	if(temp[i] == "enqueue"){
    		cin >> x[i];
		}
	}
	
	for(int i = 0; i <n; ++i){
		if(temp[i]=="enqueue"){
			q->enqueue(x[i]);
			while(dq->isEmpty()==false){
				dq->dequeue(tq);
			}
		}
		else if(temp[i]=="dequeue"){
			q->dequeue(dq);
		}
		q->Print_Queue();
		dq->Print_flist();
	}
	
	return 0;
}
