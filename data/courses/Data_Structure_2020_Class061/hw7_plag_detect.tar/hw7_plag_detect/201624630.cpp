#include <iostream>
#include <queue>
using namespace std;

void showq(queue <int> gq)
{
    queue <int> g = gq;
    while (!g.empty())
    {
        cout << ' ' << g.front();
        g.pop();
    }
    cout << "]"<<'\n';
}
int main(){
  queue<int> q;
  queue<int> flist;
  int n;
  cin >> n;
  for(int i = 0; i < n; i++){
    
    string s;
    cin >> s;
    if(s == "enqueue"){
      int a;
      cin >> a;
      q.push(a);
      //queue<int> outq;
      cout << "[queue:";
      showq(q);
      //cout << "]" << endl;
      if(!flist.empty()){
        flist.pop();
      }
      cout << "[flist:]" << endl;
    }else{
      flist.push(q.front());
      q.pop();
      cout << "[queue:";
      showq(q);
      //cout << "]" << endl;
      cout << "[flist:";
      showq(flist);
      //cout <<"]" << endl;
    }
  }
}
