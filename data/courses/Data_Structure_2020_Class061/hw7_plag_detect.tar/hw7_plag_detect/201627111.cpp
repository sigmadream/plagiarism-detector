#include <iostream>
#include <cstdlib>
#define MAXVALUE 101

using namespace std;

class Queue
{
public:
	int front;
	int rear;
	int size;
	int *values;

	Queue()
	{
		size = MAXVALUE;
		values = new int[size];
		front = 0;
		rear = 0;
	}
	~Queue()
	{
		delete[] values;
	}

	void enqueue(int value)
	{
		if(!isFull())
		{
			values[rear] = value;
			rear = (rear + 1) % size;
		}
		//else
			//cout << "Queue is Full" << endl;
	}

	int dequeue()
	{
        int temp = values[front];
		if(!empty())
			front = (front + 1) % size;
		//else
			//cout << "Queue is Empty" << endl;
        return temp;
	}

	bool empty()
	{
		if(rear == front)
			return true;
		else 
			return false;
	}

	bool isFull()
	{
		if((rear + 1) % size == front) 
			return true;
		else 
			return false;
	}
};

ostream& operator <<(ostream &out, Queue &q){
	int *temp = q.values;
	for(int i=q.front; i<q.rear; i++){
	    out << temp[i];
	    if(i < q.rear-1) out << " ";
	}
	out << "]" << endl;
    return out;
}


int main() {
    Queue q, flist;
    int n_oper = 0;
    int input = 0;
    string kind_oper;
    
    cin >> n_oper;
    int type_oper[n_oper];
    int value[n_oper];
    int tpflag=0;
    int vlflag=0;

    int j=0;

    while (j<n_oper) {
        cin >> kind_oper;
        if (kind_oper == "enqueue"){
            cin >> input;
            type_oper[j]=0;
            value[j]=input;
            j++;
            input = 0; 
        } else if (kind_oper == "dequeue"){
            type_oper[j]=1;
            j++;
        } else {
            cout << "wrong operation" << endl;
        }
        kind_oper = "";
    }

    int flflag =0;

    for(int i=0;i<n_oper;i++){
        if (type_oper[i] == 0){
            q.enqueue(value[i]);
            for(int k=0;k<flflag;k++){
                flist.dequeue();
            }
        } else if (type_oper[i] == 1){
            flist.enqueue(q.dequeue());
            flflag++;
        }
    	cout << "[queue : ";
        cout << q;
       	cout << "[flist : ";
        cout << flist;
    }

}
