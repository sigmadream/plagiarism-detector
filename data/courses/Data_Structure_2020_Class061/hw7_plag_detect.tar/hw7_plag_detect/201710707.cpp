#include <iostream>
#include <string>
using namespace std;

string a[1000];
int b[1000];

typedef struct _Queue
{
	int front;
	int rear;
	int queArr[1000];
} Queue;


void QueueInit(Queue *pq)
{
	pq->front = 0;
	pq->rear = 0;
}

int QIsEmpty(Queue *pq)
{
	if(pq->front == pq->rear)
		return 1;
	else
		return 0;
}

int NextPosIdx(int pos)
{
	if(pos == 999)
		return 0;
	else
		return pos+1;
}

void Enqueue(Queue *pq, int data)
{
	pq->rear = NextPosIdx(pq->rear);
	pq->queArr[pq->rear] = data;
}

int Dequeue(Queue *pq)
{
	if(QIsEmpty(pq)) return 0;
	
	pq->front = NextPosIdx(pq->front);
	return pq->queArr[pq->front];
}

void QPeek(Queue *pq)
{
	for(int i=pq->front+1; i<=pq->rear; i++)
		cout << " "<< pq->queArr[i];
}

int main() {
	int n;
	int i,j;
	
	Queue A, B;
	QueueInit(&A);
	QueueInit(&B);
	
	cin >> n;
	
	for(i=0;i<n;i++) {
		cin >> a[i];		
		if(a[i] == "enqueue") {
			cin >> b[i];
		}
	}
	
	for(i=0;i<n;i++) {		
		if(a[i] == "enqueue") {
			Enqueue(&A, b[i]);
			Dequeue(&B);
			
			cout << "[queue:";
			QPeek(&A);
			cout << "]" << endl;
			
			cout << "[flist:";
			QPeek(&B);
			cout << "]" << endl;
		}
		else {
			Enqueue(&B, Dequeue(&A));
			
			cout << "[queue:";
			QPeek(&A);
			cout << "]" << endl;
			
			cout << "[flist:";
			QPeek(&B);
			cout << "]" << endl;
		}
	}
	
	return 0;
}
