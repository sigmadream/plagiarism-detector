#include <iostream>
#include <string>

using namespace std;

class Node
{
    friend class CircularList;

private:
    int data;
    Node *next = NULL;

public:
    Node(int Num) { data = Num; };
};

class CircularList
{
private:
    Node *last;
    int length;
    Node *now;

public:
    CircularList() { last = NULL; length = 0;};

    void insert(int data)
    {
        Node *newNode = new Node(data);
        if (last == NULL)
        {
            last = newNode;
            newNode->next = last;
            length++;
            return;
        }
        newNode->next = last->next;
        last->next = newNode;
        last = newNode;
        length++;
    };

    int Del()
    {
        if (last == NULL)
        {
            return 0;
        }
        int tmpData;
        if (last->next == last)
        {
            tmpData = last->data;
            last = NULL;
            length--;
        }
        else
        {
            Node *first = last->next;
            tmpData = first->data;
            last->next = first->next;
            delete first;
            length--;
        }
        return tmpData;
    };
    int show_data(Node *p)
    {
        return p->data;
    };

    void prFlist(ostream &out)
    {
        if (length == 0)
        {
            out << "[flist:]" << endl;
        }
        else
        {

            now = last->next;
            out << "[flist:";
            for (int i = 0; i < length; i++)
            {
                out << " " << now->data;
                now = now->next;
            }
            out << "]" << endl;
        }
    };

    void prlist(ostream &out)
    {
        if (length == 0)
        {
            out << "[queue:]" << endl;
        }
        else
        {

            now = last->next;
            out << "[queue:";
            for (int i = 0; i < length; i++)
            {
                out << " " << now->data;
                now = now->next;
            }
            out << "]" << endl;
        }
    };
};

int main()
{
    int num1, data, tmpdata;
    CircularList l1;
    CircularList flist;
    string s1;
    cin >> num1;
    for (int i = 0; i < num1; i++)
    {
        cin >> s1;
        if (s1 == "enqueue")
        {
            cin >> data;
            l1.insert(data);
            tmpdata = flist.Del();
            l1.prlist(cout);
            flist.prFlist(cout);
        }
        else if (s1 == "dequeue")
        {
            flist.insert(l1.Del());
            l1.prlist(cout);
            flist.prFlist(cout);
        }
    }
    return 0;
}
