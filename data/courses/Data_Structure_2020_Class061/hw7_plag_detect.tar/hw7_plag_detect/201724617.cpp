#include <iostream>
using namespace std;

class CircularList;

class Node{
	friend CircularList;
	private:
		int val;
		Node* next;
	public:
		Node(){
			next = NULL;
		}
};

class CircularList{
	private:
		Node *last;
		Node *av;
	public:
		CircularList(){
			last = NULL; av = NULL;
		}
		~CircularList(){
			if(last == NULL) return;
			while(last->next != last){
				Node* tmp = last->next;
				last->next = tmp->next;
				delete tmp;
			}
			last->next = NULL;
		}

	void insert(const int n){
		Node* temp = new Node();
		temp->val = n;
		if(last == NULL){
			last = temp;
			last->next = last;
			return;
		}
		temp->next = last->next;
		last->next = temp;
		last = temp;
	}

	const int remove(){
		if(last == NULL) exit(-1);
		int returnVal = last->next->val;
		if(last == last->next){
				last = NULL;
				return returnVal;
        }
        Node* first = last->next;
        last->next = first->next;
        delete first;
        return returnVal;
	}

	void printQueue(string str){
	    cout << "[" << str << ":";
	    if(last != NULL){
            Node* nowN = last->next;
            while(nowN != last){
                cout << " " << nowN->val;
                nowN = nowN->next;
            }
            cout << " " << nowN->val;
	    }
	    cout << "]" << endl;
	}

	bool isLastNull(){
        if(last == NULL) return true;
        return false;
	}
};

int main(){
	CircularList CL, AV;

	int n, value;
	cin >> n;
	string command;
	for(int i=0; i<n; i++){
        cin >> command;
        if(command == "enqueue"){
            cin >> value;
            if(AV.isLastNull())
                CL.insert(value);
            else{
                AV.remove();
                CL.insert(value);
            }
        }else{
            AV.insert(CL.remove());
        }
        CL.printQueue("queue");
        AV.printQueue("flist");
	}

	return 0;
}
