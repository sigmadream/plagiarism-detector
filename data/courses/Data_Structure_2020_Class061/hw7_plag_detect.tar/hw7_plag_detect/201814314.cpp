#include<iostream>
#include<cstdlib>

using namespace std;

class Node {
	int data;
	Node* next;
public:
	Node() {}
	Node(int _data): data(_data), next(NULL) {}
	ostream& print(ostream& out) {
		return out << data << endl;
	}
	void setData(int n) { data = n; }
	int getData() {return data;}
	
};

int main() {
	int n;
	int k=0, t=0;
	
	cin >> n;
	int* isEn = new int[n];
	int* dataArr = new int[n];
	Node fl;
	Node* q = new Node[n];
	
	string s1 = "enqueue";
	string s2 = "dequeue";
	string s3;
	
	for(int i=0;i<n;++i){
		cin >> s3;
		if(!s3.compare(s1)) {
			cin >> dataArr[i];
			isEn[i] = 1;
		}
		if(!s3.compare(s2)) {
			isEn[i] = 0;	
		}
	}
	
	for(int i=0;i<n;++i) {
		if(isEn[i] == 1){
			q[t].setData(dataArr[i]);
			t++;
		}
		else if(isEn[i] == 0) {
			fl = q[0];
			for(int j=0;j<t-1;++j) q[j] = q[j+1];
			k++;
			t--;
		}
		cout << "[queue:";
		for(int j=0;j<t;++j) 
			cout << " " << q[j].getData();
		cout << "]" << endl;
		cout << "[flist:";
		if(isEn[i] == 0)
			cout << " " << fl.getData();
		cout << "]" << endl;
	}
}
