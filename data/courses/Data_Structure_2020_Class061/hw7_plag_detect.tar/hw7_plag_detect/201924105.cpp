#include <iostream>
#include <cstdlib>

using namespace std;

class Node {
  friend class Que;
private:
  static Node FreeArr[5];
  static int FreePtr;
  int _data;
  Node *_next;
public:
  Node() {}
  Node(int data): _data(data), _next(NULL) {}
  int data() {
    return _data;
  }
  ostream& print(ostream& out) {
    return out << _data << endl;
  }
  void * operator new(size_t size) {
    if(FreePtr < 5)
      return FreeArr + FreePtr++; // alloc 0
    return ::new Node();          // alloc 1
  }
  void operator delete(void *p) {
    if(FreeArr <= p && p < FreeArr+FreePtr)
      --FreePtr;                  // dealloc 0
    else
      free(p);                    // dealloc 1
  }
  static void prFreeArr(ostream& out) {
    out << "[FreeArr:";
    for (Node& n: FreeArr) {
      if(n._data != 0)
        out << " " << n._data;
    }
    out << "]" << endl;
  }
  static void getPtr() {
    cout << FreePtr << endl;
  }
};

Node Node::FreeArr[5];
int Node::FreePtr = 0;

class Que {
private:
  Node *last;
public:
  Que() {
    last = NULL;
  }
  void enqueue(int data) {
    Node *newNode = new Node(data);
    newNode->_data = data;
    newNode->_next = NULL;
    if(last==NULL) {
      last = newNode;
      last->_next = last;
      return;
    }
    newNode->_next = last->_next;
    last->_next = newNode;
    last = newNode;
  }
  int dequeue() {
    int tmpData = last->_next->_data;
    Node *first = last->_next;
    if(first == last)
      last = NULL;
    else
      last->_next = first->_next;
    delete first;
    return tmpData;
  }
};

int main(void) {
  Node *arr[5];
  int len, item, count=0, data;
  Que q;

  cin >> len;
  string str[len];
  int num[len];
  for(int i=0; i<len; i++) {
    cin >> str[i];
      if(str[i] == "enqueue") {
        cin >> num[i];
      } else if(str[i] == "dequeue") {
        num[i] = 0;
      }
  }

  for(int i=0; i<len; i++) {
    if(str[i] == "enqueue") {
      q.enqueue(num[i]);
      cout << "enqueue" << endl;
      Node::prFreeArr(cout);
    } else if(str[i] == "dequeue") {
      cout << "dequeue" << endl;
      item = q.dequeue();
      Node::prFreeArr(cout);
    }
  }

  // Node *arr[10];
  // int i = 0;
  // for (i = 0; i < 10; i++) {
  //   arr[i] = new Node(i+1);
  //   star(arr[i]->data());
  //   Node::prFreeArr(cout);
  // }
  // for (int j = 0; j < 3; j++)
  //   delete arr[--i];
  // for (int d = 20, j = 0; d < 50; d += 10, j++) {
  //   arr[j] = new Node(d);
  //   arr[j]->print(cout);
  //   Node::prFreeArr(cout);
  // }
  return 0;
}
