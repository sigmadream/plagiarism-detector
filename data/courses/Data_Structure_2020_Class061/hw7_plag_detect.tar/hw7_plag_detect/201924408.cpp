# include<iostream>

using namespace std;

class Stack
{
private:
    int top;
    public:
    int* a;
    int _siz;
public:
    Stack(int k): _siz(k){
        a = new int[k];
        top = -1;
    }


    void push(int x);
    int pop();
    bool isEmpty();
};

void Stack::push(int x)
{
    if(top >= _siz)
    {

    }
    else
    {
        a[++top] = x;
    }
}

// function to remove data from the top of the stack
int Stack::pop()
{
    if(top < 0)
    {

        return 0;
    }
    else
    {
        int d = a[top--];
        return d;
    }
}

// function to check if stack is empty
bool Stack::isEmpty()
{
    if(top < 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// implementing the queue class
class Queue {
private:
    int _size;
    int cnt_1 ;
    int cnt_2 ;
    Stack* S1 ;
    Stack* S2 ;
    Stack* S3;
public:

    Queue(int k): _size(k){
		S1 = new Stack(_size) ;
    	S2 = new Stack(_size) ;
   		S3 = new Stack(_size) ;
	}

    ~Queue(){
        delete S1;
        delete S2;
        delete S3;
    }
    //declaring enqueue method
    void enqueue(int x);

    //declaring dequeue method
    int dequeue();
    void print();
};

// enqueue function
void Queue :: enqueue(int x)
{
    cnt_1++;
    cnt_2 = 0;
    S1->push(x);
    while(!S3->isEmpty())
    {
        S3->pop();
    }
}

// dequeue function
int Queue :: dequeue()
{
    cnt_1 -= 1;
    cnt_2 ++;
    int x, y;
    while(!S1->isEmpty())
    {
        x = S1->pop();

        S2->push(x);
    }

    y = S2->pop();
    S3->push(y);
    // moving back the elements to the first stack
    while(!S2->isEmpty())
    {
        x = S2->pop();
        S1->push(x);
    }

    return y;
}
void Queue :: print(){
    cout << "[enqueue:";
    for(int i=0; i<cnt_1; i++){
        cout << " "<< S1->a[i];
    }
    cout << "]"<< endl;
    cout << "[dequeue:";
    for(int i=0; i<cnt_2; i++){
        cout << " "<< S3->a[i];
    }
    cout << "]"<< endl;
}

// main function
int main()
{
    int k,b;
    int* c ;
    int* d ;
    string a;
    cin >> k;
    c = new int[k];
    d = new int[k];
    for(int j =0; j<k ; j++){
        cin >> a ;
        if( a== "enqueue"){
            cin >> b;
            c[j] = 0;
        }
        else if(a =="dequeue")
            c[j]= 1;
        else
            c[j]= -1;
        d[j]=b;
    }
    Queue q(k);

    for(int u =0; u<k; u++){
        if(c[u] == 0){
            q.enqueue(d[u]);
            q.print();
        }
        else if(c[u] == 1){
            q.dequeue();
            q.print();
        }
        else
            return 0;

    }

    return 0;
}
