#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

class Node {
private:
	int _data;
public:
	Node *next;
	
	Node() {}
	
	Node(int data): _data(data), next(NULL) {}
	
	friend ostream& operator << (ostream &out, const Node &node) {
		return out << node._data << endl;
	}
	
	void * operator new(size_t size) {
		return ::new Node();
	}
	
	void operator delete(void *p) {
		free(p);
	}
	
	int getData() {
		return _data;
	}
	
	void setData(int value) {
		_data = value;
	}
};

class Flist{
private:
	Node *head, *tail;
	int size;
public:
	Flist()	{
		head = NULL;
		tail = NULL;
		size = 0;
	}
	
	bool isEmpty() {return size == 0;}
	
	void enqueue(Node* node) {
		size++;
		if(head == NULL) {
			head = node;
			tail = node;
			node->next = NULL;
		}
		tail->next = node;
		tail = node;
		tail->next = NULL;
	}
	
	Node* dequeue() {
		if(size == 0) {
			cerr << "No elements in list.\n";
			return new Node(0);
		}
		size--;
		Node* tmp = new Node();
		tmp = head;
		head = head->next;
		tmp->next = NULL;
		return tmp;
	}
	
	void printList() {
		if(size != 0) {
			Node* tmp = new Node;
			tmp = head;
			cout << "[flist:";
			while(tmp != NULL) {
				cout << " " << tmp->getData();
				tmp = tmp->next;
			}
			cout << "]\n";
		} else {
			cout << "[flist:]\n";
		}
	}
};

class Queue{
private:
	Flist flist;
	Node *head, *tail;
	int size;
public:
	Queue() {
		head = NULL;
		tail = NULL;
		size = 0;
	}
	
	void enqueue(int value) {
		size++;
		Node *tmp = new Node(value);
		if(flist.isEmpty()) {
			if(head == NULL) {
				head = tmp;
				tail = tmp;
			} else {
				tail->next = tmp;
				tail = tmp;
			}
		} else {
			tmp = flist.dequeue();
			tmp->setData(value);
			tail->next = tmp;
			tail = tmp;
		}
		
		cout << "[queue:";
		tmp = head;
		while(tmp != NULL) {
			cout << " " << tmp->getData();
			tmp = tmp->next;
		}
		cout << "]\n";
		flist.printList();
	}
	
	int dequeue() {
		if(size == 0) {
			cerr << "No elements is list.\n";
			return 404;
		}
		size--;
		Node* tmp = new Node();
		tmp = head;
		head = head->next;
		tmp->next = NULL;
		int value = tmp->getData();
		flist.enqueue(tmp);
		
		cout << "[queue:";
		tmp = head;
		while(tmp != NULL) {
			cout << " " << tmp->getData();
			tmp = tmp->next;
		}
		cout << "]\n";
		flist.printList();
		
		return value;
	}
};

int main() {
	int n, value;
	string operation;
	Queue q;
	cin >> n;
	for(int i = 0; i < n; i++) {
		cin >> operation;
		if(operation == "enqueue") {
			cin >> value;
			q.enqueue(value);
		} else {
			q.dequeue();
		}
	}
	return 0;
}
