#include <iostream>
#include <string>

using namespace std;


class Queue {
public:
  struct Node {
    int data;
    Node* link;
  };

  struct Node* front=NULL;
  struct Node* rear=NULL;
  void enQueue(int value)
  {
      struct Node* temp = new Node;
    temp->data = value;
    if (this->front == NULL)
        this->front = temp;
    else
        this->rear->link = temp;

    this->rear = temp;
    this->rear->link = this->front;
  }
  int deQueue()
  {
      if (this->front == NULL) {
        return -1;
    }
    int value;
    if (this->front == this->rear) {
        value = this->front->data;
        delete(this->front);
        this->front = NULL;
        this->rear = NULL;
    }
    else
    {
        struct Node* temp = this->front;
        value = temp->data;
        this->front = this->front->link;
        this->rear->link = this->front;
    }
    return value;
  }


  void print_queue(){

   struct Node* temp = new Node;
    if(this->front != NULL){
      temp->data=this->front->data;
      temp->link=this->front->link;

      cout<<" "<<temp->data;
      temp=temp->link;
      
      while((temp->link)!= this->front->link){
        cout<<" "<<temp->data;
        temp=temp->link;
      }
    }
  }
 
};


 



int main() {
  int no_inputs;
  int input_data;
  string input_operation;
  Queue q;
  Queue flist;

  cin>>no_inputs;
  
  for(int i=0;i<no_inputs;i++){
    cin>>input_operation; 
    if(input_operation == "enqueue"){
      cin>>input_data;
      flist.deQueue();
      q.enQueue(input_data);
      cout<<"queue:";
      q.print_queue();
      cout<<endl;
      cout<<"flist:";
      flist.print_queue();
      cout<<endl;
    }else{
      flist.enQueue(q.front->data);
      q.deQueue();
      cout<<"queue:";
      q.print_queue();
      cout<<endl;
      cout<<"flist:";
      flist.print_queue();
      cout<<endl;
    }

    
  }
  
    
  

}