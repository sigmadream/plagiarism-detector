#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <list>
using namespace std;


class Queue;
class Node{
    friend class Queue;
    int val;
    Node *link;
public: Node(){link = NULL;}
};

class Queue{
private:
    Node *front, *rear;int size = 0;
public:
    void enqueue(int value);
    int dequeue();bool isFront() const;string show()const;void voidReturnShow()const;
    Queue(){front = NULL; rear = NULL;}
};
bool Queue::isFront()const{return size == 0; }

string Queue::show()const{
    string newOne;stringstream ss;
    Node *temp = front;
    if(front == NULL){return "";}
    if(temp -> link == front){
        ss << temp -> val; newOne += " ";
        newOne += ss.str(); ss.str("");
        if(temp -> val == 0){return 0;}
        return newOne;
    }
    while(temp -> link != front){
        ss << temp -> val;newOne += " ";
        newOne += ss.str();ss.str("");
        temp = temp -> link;
    }
    ss << temp -> val; newOne += " ";
    newOne += ss.str(); ss.str("");
    return newOne;
}
void Queue::enqueue(int value){
    Node *newNode = new Node;
    newNode -> val = value;
    if(front == NULL){ front = newNode; }
    else {rear -> link = newNode;}
    rear = newNode;
    rear -> link = front;
    size++;
}

int Queue::dequeue(){
    if(front == NULL){
        return -1;
    }
    int value;
    if(front == rear){
        value = front -> val;
        free(front);
        front = NULL; rear = NULL;
    }else{
        Node *temp = front;
        value = temp -> val;
        front = front -> link;
        rear -> link = front;
        free(temp);
    }
    size--;
    return value;
}

int main(){
    cin.tie(0);
    ios::sync_with_stdio(0);
    int countOp;string Op; int val, temp;
    string op1 = "[queue:";
    string op2 = "[flist:";string wholeOne;string wholeOne2;
    string opClose = "]";vector<string> result;
    Queue *newQueue = new Queue();Queue *flist = new Queue();
    cin >> countOp;
    for(int i = 0; i < countOp; i++){
        cin >> Op;

        if(Op == "enqueue") {
            cin >> val;
            if (val != 0) {
                newQueue->enqueue(val);
                wholeOne += op1;
                wholeOne += newQueue->show();
                wholeOne += opClose;
                flist->dequeue();
                wholeOne2 += op2;
                wholeOne2 += opClose;
                result.push_back(wholeOne);
                result.push_back(wholeOne2);wholeOne2 = "";wholeOne ="";Op = "";
            }
        }

        if(Op == "dequeue"){
            temp = newQueue->dequeue();
            flist->enqueue(temp);
            wholeOne += op1; wholeOne2 += op2;
            wholeOne += newQueue->show(); wholeOne2 += flist->show();
            wholeOne += opClose; wholeOne2 += opClose;
            result.push_back(wholeOne);
            result.push_back(wholeOne2);wholeOne2 = "";wholeOne ="";Op = "";
        }
    }
    for(int j = 0; j < result.size(); j++)
        cout << result[j] << endl;
    return 0;
}