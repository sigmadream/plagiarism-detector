#include <iostream>
#include <string>
#include <stack>

using namespace std;

class TreeNode {
    friend class BinaryTree;
private:
    string data;
    TreeNode *lchild;
    TreeNode *rchild;
public:
    TreeNode(string d, TreeNode *l=nullptr, TreeNode *r=nullptr):
        data(d), lchild(l), rchild(r) {}
};


class BinaryTree {
private:
    TreeNode *root;
public:
    BinaryTree(TreeNode *p) : root(p) {}
    void print(ostream &out, int indent=0){
        string indstr = string(indent, ' ');
        if(root){
            out << indstr << root->data << endl;
            BinaryTree ltree(root->lchild);
            ltree.print(out, indent+3);
            BinaryTree rtree(root->rchild);
            rtree.print(out, indent+3);
        }
    }
};

int main() {
    stack<string> Stack;
    int num;
    cin >> num;
    string arr[num];
    for(int i=0; i<num; i++){
        cin >> arr[i] ;
    };
    for(int i=0; i<num; i++){
        if(arr[i]=="*"||arr[i]=="+"||arr[i]=="-"||arr[i]=="/"){
            string c = arr[i];
            string s1 = Stack.top();
            Stack.pop();
            string s2 = Stack.top();
            Stack.pop();
            string temp = "("+s2+c+s1+")";
            Stack.push(temp);
        }
        else{
            Stack.push(arr[i]+"");
        }
    };
    string result = Stack.top();
    cout << result ;

}
