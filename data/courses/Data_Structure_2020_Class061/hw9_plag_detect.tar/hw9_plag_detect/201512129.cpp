#include<iostream>
using namespace std;

class Node{
private:
    char op;
    Node* left, *right, *below;
public:
    Node() {}
    Node(char op) : op(op), left(NULL), right(NULL) {}
    Node(char op, Node* l, Node* r) : op(op), left(l), right(r){}
    bool hasLeft() {return (left != NULL);}
    bool hasRight() {return (right != NULL);}
    void setBelow(Node* b) {below = b;}
    Node* getBelow() {return below;}
    Node* getLeft() {return left;}
    Node* getRight() {return right;}
    friend ostream& operator<<(ostream& os, Node& n);
};
ostream& operator<<(ostream& os, Node& n){
    os << n.op;
    return os;
}

class Stack{
private:
    Node* top;
public:
    Stack() : top(NULL){}
    void push(Node* n){
        n->setBelow(top);
        top = n;
    }
    void push(char op){
        Node* num = new Node(op);
        this->push(num);   
    }
    Node* pop(){
        Node* tmp = top;
        top = top->getBelow();
        return tmp;
    }
};

void inorder(Node* tmp){
    if(tmp->hasLeft()) {
        cout << "(";
        inorder(tmp->getLeft());
    }
    cout << *tmp;
    if (tmp->hasRight()){
        inorder(tmp->getRight());
        cout << ")";
    }
}

int main() {
    int size;
    cin >> size;
    string input;
    getline(cin, input);
    getline(cin, input);
    Stack s;
    
    for(int i = 0; i < size; i++){
        char tmp = input[2*i];
        if (isdigit(tmp)) { // 숫자면 node만들어 추가한다.
            s.push(tmp);
        }
        else {  // 2개 pop을 한다.
            Node* right = s.pop();
            Node* left = s.pop();
            Node* num = new Node(tmp, left, right);
            s.push(num);
        }
    }
    Node* last = s.pop();
    inorder(last);
}
