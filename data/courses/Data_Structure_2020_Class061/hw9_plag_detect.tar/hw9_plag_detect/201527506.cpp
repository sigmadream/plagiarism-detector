#include <iostream>
using namespace std;

class node
{
 public:
    string data;
    node* next;
};

class Stack
{
public:
	Stack(int max)
	{
	    top = NULL;
	    maxnum = max;
	    count=0;
	}
	void push(string element)
	{
	    if(count == maxnum)
	            cout<<"stack is full";
	    else
	    {
	        node *newTop = new node;
	        if(top == NULL)
	        {       
	            newTop->data = element;
	            newTop->next = NULL;
	            top = newTop;
	            count++;
	        }
	        else
	        {
	            newTop->data = element;
	            newTop->next = top;
	            top = newTop;
	            count++;
	        }
	    }
	}
	void pop()
	{
	    if(top == NULL)
	            cout<< "nothing to pop";
	    else
	    {
	        node * old = top;
	        top = top->next;
	        count--;
	        delete(old);
	    }
	}
	string Top()
	{
	    if(top == NULL)
	            cout<< "nothing to top";
	    return top->data;
	}
	void print()
	{
	    node *temp;
	    temp = top;
	    while(temp!=NULL)
	    {
	        cout<<temp->data;
	        temp=temp->next;
	    }
	}
private:
    node *top;
    int count;
    int maxnum;
    int stackData;      
};

bool isDigit(char x) 
{ 
   return (x >= '0' && x <= '9');
} 
  
string infix2postfix(string postfix) 
{ 
    Stack s(100); 
  
    for (int i=0; i<postfix.length(); i++) 
    { 
        if (isDigit(postfix[i])) 
        {
        	char temp[2];
        	temp[0] = postfix[i];
        	temp[1] = '\0';
			string operand = temp;
			s.push(operand); 
        } 
        else
        { 
            string operand1 = s.Top(); 
            s.pop(); 
            string operand2 = s.Top(); 
            s.pop(); 
            s.push("(" + operand2 + postfix[i] + operand1 + ")"); 
        } 
    } 
    return s.Top(); 
}

int main(void) 
{
	int n;
	cin >> n;
	
	char* temp = new char[n];
	for(int i=0; i<n; ++i)
		cin >> temp[i];
	
	string postfix = temp;
    cout << infix2postfix(postfix); 
    return 0; 
} 
