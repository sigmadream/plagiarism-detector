#include <iostream>
#include <string>
using namespace std;

//201624458 ����� 2020�� 11�� 11��
//lab 9.  post2infx.cpp

class TreeNode {
    friend class BinaryTree;
private:
    string data;
    TreeNode* lchild;
    TreeNode* rchild;
public:
    TreeNode(string d, TreeNode* l = nullptr, TreeNode* r = nullptr) :
        data(d), lchild(l), rchild(r) {}
};

class BinaryTree {
private:
    TreeNode* root;
public:
    BinaryTree(TreeNode* p) : root(p) {}
    void print(ostream& out, int indent = 0) {
        string indstr = string(indent, ' ');
        if (root) {  // root != nullptr
            out << indstr << root->data << endl;
            BinaryTree ltree(root->lchild);
            ltree.print(out, indent + 4);
            BinaryTree rtree(root->rchild);
            rtree.print(out, indent + 4);
        }
    }
    TreeNode* getRoot() {
        return root;
    }
    void visit(TreeNode* current) {
        if ((current->data).compare("+") == 0) {
            cout << " ";
            cout << current->data << " ";
        }
        else if ((current->data).compare("/") == 0) {
            cout << " ";
            cout << current->data << " ";
        }
        else if((current->data).compare("*") == 0) {
            cout << " ";
            cout << current->data << " ";
        }
        else if ((current->data).compare("-") == 0) {
            cout << " ";
            cout << current->data << " ";
        }
        else {
            cout << "(" << current->data << ")";
        }
    }
    void inorder(TreeNode* current) {
        if (current != NULL) {   
            inorder(current->lchild);           
            visit(current);           
            inorder(current->rchild);         
        }
    }
};

int main() {
    TreeNode* lnode = new TreeNode("2");
    TreeNode* rnode = new TreeNode("3");
    rnode = new TreeNode("*", lnode, rnode);
    lnode = new TreeNode("1");
    TreeNode* root = new TreeNode("+", lnode, rnode);
    BinaryTree t(root);
    cout << "(";
    t.inorder(t.getRoot());
    cout << ")" << endl;

    TreeNode* left = new TreeNode("1");
    TreeNode* right = new TreeNode("2");
    right = new TreeNode("*", left, right);
    TreeNode* left2 = new TreeNode("9");
    TreeNode* right2 = new TreeNode("3");
    left2 = new TreeNode("/", left2, right2);
    TreeNode* root2 = new TreeNode("-", left2, right);
    BinaryTree t2(root2);
    cout << "(";
    t2.inorder(t2.getRoot());
    cout <<")"<< endl;

    return 0;
}


