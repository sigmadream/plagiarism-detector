#include <iostream>
#include <string>
using namespace std;

class TreeNode {
friend class BinaryTree;
private:
    string data;
    TreeNode *lchild;
    TreeNode *rchild;
public:
    TreeNode(string d, TreeNode *l=nullptr, TreeNode *r=nullptr):
    data(d), lchild(l), rchild(r) {}
    void setTree(string d, TreeNode *l, TreeNode *r) {
        data = d;
        lchild = l;
        rchild = r;
    }
};

class BinaryTree {
private:
    TreeNode *root;
public:
    BinaryTree(TreeNode *p): root(p) {}
    void print(ostream &out, int indent=0) {
        string indstr = string(indent, ' ');
        if (root) {
            BinaryTree ltree(root->lchild);
            if (root->data == "+" || root->data == "-" || root->data == "*" || root->data == "/")
                out << "(";
            ltree.print(out);
            out << root->data;
            BinaryTree rtree(root->rchild);
            rtree.print(out);
            if (root->data == "+" || root->data == "-" || root->data == "*" || root->data == "/")
                out << ")";
        }
    }
};

int main() {

    string *input;
    TreeNode **Tree;
    int op;
    cin >> op;
    if (!(op%2))
        throw invalid_argument("The number of input items is invalid");
    input = new string[op];
    Tree = new TreeNode*[op];

    for(int i=0;i<op;i++) {
        cin >> input[i];
    }
    int flag = 0;
    for(int j=0;j<op;j++) {
        if (input[j] == "+" || input[j] == "-" || input[j] == "*" || input[j] == "/") {
            Tree[flag-2] = new TreeNode(input[j],Tree[flag-2],Tree[flag-1]);
            flag = flag-1;
        }
        else {
            Tree[flag] = new TreeNode(input[j]);
            flag++;
        }
    }

    BinaryTree t(Tree[0]);
    t.print(cout);
    delete[] input;
    delete[] *Tree;

    return 0;
}