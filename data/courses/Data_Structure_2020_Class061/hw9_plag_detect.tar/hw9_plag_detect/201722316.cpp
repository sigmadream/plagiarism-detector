#include <iostream>
#include <string>

using namespace std;

class BinaryTree
{
public:
    class TreeNode
    {
    public:
        string data;
        TreeNode *lchild;
        TreeNode *rchild;
        TreeNode(string d, TreeNode *l = nullptr, TreeNode *r = nullptr) : data(d), lchild(l), rchild(r) {}
        TreeNode() {}
    };
    class Node
    {
    public:
        Node(TreeNode *Tn)
        {
            data = Tn;
        }
        TreeNode *data;
        Node *next;
    };
    class Stack
    {
    private:
        Node *top;

    public:
        void push(TreeNode *data)
        {
            Node *newNode = new Node(data);
            newNode->next = top;
            top = newNode;
        };
        TreeNode *pop()
        {
            TreeNode *tmpdata = top->data;
            Node *tmpNode = top;
            top = top->next;
            delete tmpNode;
            return tmpdata;
        };
    };

private:
    TreeNode *root;
    TreeNode *lnode;
    TreeNode *rnode;
    Stack stk;

public:
    BinaryTree() {}
    BinaryTree(TreeNode *p) : root(p) {}
    void print(ostream &out)
    {
        if (root && root->lchild)
        {
            out << "(";
            BinaryTree ltree(root->lchild);
            ltree.print(out);
            out << root->data;
            BinaryTree rtree(root->rchild);
            rtree.print(out);
            out << ")";
        }
        else if (root)
        {
            out << root->data;
        }
    }
    void Insert(string data)
    {
        if (data == "+" || data == "-" || data == "*" || data == "/")
        {
            rnode = stk.pop();
            lnode = stk.pop();
            stk.push(new TreeNode(data, lnode, rnode));
        }
        else
        {
            stk.push(new TreeNode(data));
        }
    }
    void Insert_root(string data)
    {
        rnode = stk.pop();
        lnode = stk.pop();
        root = new TreeNode(data, lnode, rnode);
    }
};

int main()
{
    int Input_num;
    cin >> Input_num;
    string Input;
    BinaryTree result;
    for (int i = 0; i < Input_num - 1; i++)
    {
        cin >> Input;
        result.Insert(Input);
    }
    cin >> Input;
    result.Insert_root(Input);
    result.print(cout);
}