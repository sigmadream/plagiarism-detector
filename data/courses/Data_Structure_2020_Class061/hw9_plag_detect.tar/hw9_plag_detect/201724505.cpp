#include <iostream>
#include <stack>

using namespace std;

class TreeNode {
    friend class BinaryTree;
private:
    char data;
    TreeNode *lchild;
    TreeNode *rchild;
public:
    TreeNode(char d, TreeNode *l=NULL, TreeNode* r=NULL):
        data(d), lchild(l), rchild(r) {}
    void setLeft(TreeNode *p) {
        lchild = p;
    }
    void setRight(TreeNode *p) {
        rchild = p;
    }
};

class BinaryTree {
private:
    TreeNode *root;
public:
    BinaryTree(TreeNode *p) : root(p) {}

    void print(ostream &os, int indent = 0) {
        string indstr = string(indent, ' ');
        if (root) {
            os << indstr << root->data << endl;
            BinaryTree ltree(root->lchild);
            ltree.print(os, indent+4);
            BinaryTree rtree(root->rchild);
            rtree.print(os, indent+4);
        }
    }

    void inorder(TreeNode *p) {
        if (p) {
            if (p->lchild)
                cout << "(";
            inorder(p->lchild);
            cout << p->data;
            inorder(p->rchild);
            if (p->rchild)
                cout << ")";
        }
    }

    void inorderPrint() {
        inorder(root);
    }
};

bool isOperator(char c) { // char c가 operator인지 아닌지 판별하는 함수
    if (c == '+' || c == '-' || c == '*' || c == '/')
        return true;
    return false;
}

int main() {
    stack<TreeNode*> st;
    TreeNode *n1, *n2, *n3;
    int n;
    cin >> n;
    while (n-- > 0) 
    {
        char c;
        cin >> c;
        if (!isOperator(c)) { // c가 operator 아니면
            n1 = new TreeNode(c);
            st.push(n1);
        }
        else { // operator인 경우
            n1 = new TreeNode(c);
            
            n2 = st.top();
            st.pop();
            n3 = st.top();
            st.pop();

            n1->setLeft(n3);
            n1->setRight(n2);

            st.push(n1);
        }
    }
    n1 = st.top();
    st.pop();

    BinaryTree tree(n1);
    tree.inorderPrint();
}