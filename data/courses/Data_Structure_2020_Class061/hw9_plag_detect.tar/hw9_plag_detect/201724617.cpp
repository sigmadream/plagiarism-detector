#include <iostream>
#include <string>
using namespace std;

class BinaryTree; class NodeStack;

class TreeNode{
	friend class BinaryTree;
	friend class NodeStack;
	private:
		string data;
		TreeNode *left, *right;
		TreeNode *next; // for making stack
	public:
		TreeNode(const string str, TreeNode *l=nullptr, TreeNode *r=nullptr):
		    data(str), left(l), right(r) {}
        string returnData(){ return data; }
};

class NodeStack{
    private:
        TreeNode* top;
    public:
        NodeStack(){ top = NULL; }
        void push(TreeNode* trn){
            TreeNode* temp = trn;
            temp->next = top;
            top = temp;
        }
        TreeNode* pop(){
            if(top == NULL) exit(-1); // error
            TreeNode *temp;
            TreeNode *ret = new TreeNode(top->data, top->left, top->right);
            temp = top;
            top = top->next;
            delete temp;
            return ret;
        }

};

class BinaryTree{
	private:
		TreeNode* root;
	public:
		BinaryTree(TreeNode *p) : root(p) {}
		void inPrint(ostream &out){
			inPrint(out, root);
		}

		void inPrint(ostream &out, TreeNode* node){ // �� ���� �����ϳ� ����������
			if(node != NULL){
                if((node->left) != NULL) out << "(";
				inPrint(out, node->left);
				out << node->data;
				inPrint(out, node->right);
                if((node->right) != NULL) out << ")";
			}
		}

};

int main() {

    NodeStack NS;

    int n;
    cin >> n;

    string op;
    for(int i=0; i<n; i++){
        cin >> op;
        if((op == "+") || (op == "-") || (op == "*") || (op == "/")){
            TreeNode *R = NS.pop();
            TreeNode *L = NS.pop();
            NS.push(new TreeNode(op, L, R));
        }else{
            NS.push(new TreeNode(op));
        }
    }

    TreeNode *root = NS.pop();

    BinaryTree BT(root);

    BT.inPrint(cout);


    return 0;
}
