#include <iostream>
#include<string>
#include<stack>
using namespace std;


class TreeNode{
  friend class BinaryTree;
public:
  string data;
  TreeNode *lchild;
  TreeNode *rchild;
public:
TreeNode(string d, TreeNode *l=NULL, TreeNode *r=NULL): data(d), lchild(l), rchild(r){}

};

class BinaryTree{
private:
  TreeNode *root;
public:
  BinaryTree(TreeNode *p, stack<string> s): root(p){
    string input;
    TreeNode** temp;
    *temp=root;
    while(!s.empty()){
      input=s.top();
      s.pop();
      TreeNode* node= new TreeNode(input);
      if((*temp)->rchild == NULL){
        (*temp)->rchild=node;
        if(input == "*" || input == "/"){
          (*temp)=(*temp)->rchild;
        }
      }else{
        (*temp)->lchild=node;
        if(input == "*" || input == "/"){
          (*temp)=(*temp)->lchild;
        }else if( (*temp)->data == "*" || (*temp)->data == "/"){
          (*temp)=root;
        }
      }
    
    }

  }


  void Inorder(TreeNode* node){
    if( node == NULL){
      return;
    }
      
    if(node->data == "*" || node->data == "/"){
      cout<<"(";
      Inorder(node->lchild);
      cout <<node->data;
      Inorder(node->rchild);
      cout<<")";
    }else if(node->data == "+" || node->data == "-"){
      Inorder(node->lchild);
      cout <<node->data;
      Inorder(node->rchild);
    }else{
      Inorder(node->lchild);
      cout <<node->data;
      Inorder(node->rchild);
    }

  }

  void infix(){
    TreeNode* temp;
    temp = this->root;
    cout<<"(";
    Inorder(temp);
   cout<<")";
  }

};


int main(){
  
int size;
string input;
stack<string> s;

cin>>size;

for(int i=0;i<size;i++){
  cin>>input;
  s.push(input);
}

input = s.top();

s.pop();

TreeNode *root = new TreeNode(input);

BinaryTree tree(root,s);
tree.infix();

}






/*if(input == "+" || input == "-" || input == "*" || input == "/"){  
    temp->data=input;
  }     

TreeNode *lnode = new TreeNode("2");
TreeNode *rnode = new TreeNode("3");
rnode = new TreeNode("*", lnode, rnode);
lnode = new TreeNode("l");
TreeNode *root = new TreeNode("+", lnode, rnode);
BinaryTree t(root);
*/