#include<iostream>
#include<string>
#include<cctype>

using namespace std;

int nElements = 0;

void test(int n) {cout << "test" << n << endl;}
// class TreeNode {
//     friend class BinaryTree;
// private:
//     char data;
//     TreeNode *lchild;
//     TreeNode *rchild;
// public:
//     TreeNode(char d, TreeNode *l=nullptr, TreeNode *r=nullptr):
//         data(d), lchild(l), rchild(r) {}
// };

// class BinaryTree {
// private:
//     TreeNode *root;
//     int k;
// public:
//     BinaryTree(TreeNode *p): root(p) {}
//     void print(ostream &out, int indent=0) {
//         out << "(";
//         string indstr = string(indent,' ');
//         if(root){
//             out << indstr << root->data ;
//             BinaryTree ltree(root->lchild);
//             ltree.print(out, indent + 4);
//             BinaryTree rtree(root->rchild);
//             rtree.print(out, indent + 4);
//         }
//         out << ")";
//     }
//    void set() {
//        int cnt = nElements - 1;
//        while(true) {
//            if(isdigit(arr[cnt]) == 0)
//        }
//    }
//     void insert(int lr, char c, TreeNode* t) {
//         if(lr == 0) {
//             t->lchild = new TreeNode(c);
//         }
//         else if(lr == 1) {
//             t->rchild = new TreeNode(c);
//         }
//     }
        
// };

int main() {
    cin >> nElements;
    char *arrChar = new char[nElements];
    int* check = new int[nElements];

    for(int i=0;i<nElements;++i) {
        cin >> arrChar[i];
        check[i] = 0;
    }

    for(int i=0;i<nElements;++i) 
        if(isdigit(arrChar[i]) == 0) 
            check[i] = 1;
    
    char* arrChar2 = new char[nElements];
    int dp = 2;
    int cnt1 = 1;
    int cnt2 = nElements - 1;
    for(int i=nElements-1;i>=0;--i) {
        if(check[i] == 1) {
            arrChar2[cnt1] = arrChar[i];
            cnt1 += 2;
        }
        else {
            arrChar2[cnt2] = arrChar[i];
            cnt2 -= 2;
        }
    }

    for(int i=0;i<nElements;++i) {
        cout << arrChar2[i];
    }
    
}