#include <iostream>
#include <string>

using namespace std;

class TreeNode {
  friend class BinaryTree;
private:
  string data;
  TreeNode *lchild;
  TreeNode *rchild;
public:
  TreeNode(string d, TreeNode *l=nullptr, TreeNode *r=nullptr):
  data(d), lchild(l), rchild(r) {}
  string getData() {
    return data;
  }
};

class BinaryTree {
private:
  TreeNode *root;
public:
  BinaryTree(TreeNode *p): root(p) {}
  void print(ostream &out, int indent=0) {
    string indstr = string(indent, ' ');
    if (root) {
      out << indstr << root->data << endl;
      BinaryTree ltree(root->lchild);
      ltree.print(out, indent + 4);
      BinaryTree rtree(root->rchild);
      rtree.print(out, indent + 4);
    }
  }
};

class Node {
  friend class Stack;
private:
  TreeNode *data;
  Node *next;
public:
  Node(TreeNode* newData) : data(newData) {}
};

class Stack {
private:
  Node *top;
public:
  Stack(): top(NULL) {}
  void push(TreeNode* data) {
    Node *newNode = new Node(data);
    newNode->next = top;
    top = newNode;
  }
  TreeNode *pop() {
    if(top==NULL) ListEmpty();
    TreeNode *tmpData = top->data;
    Node *tmpNode = top;
    top = top->next;
    delete tmpNode;
    return tmpData;
  }
  void ListEmpty() {
    cout << "List is empty" << endl;
  }
};

int main() {
  int num;
  cin >> num;
  char word[num];
  Stack s;
  string str, str2;

  for(int i=0; i<num; i++) {
    cin >> word[i];
  }

  TreeNode *tNode;
  TreeNode *lnode;
  TreeNode *rnode;
  for(int i=0; i<num; i++) {
    if((48<=word[i]) && (word[i]<=57)) {
      str = word[i];
      tNode = new TreeNode(str);
      s.push(tNode);
    } else {
      rnode = s.pop();
      lnode = s.pop();
      str = "(" + lnode->getData() + word[i] + rnode->getData() + ")";
      tNode = new TreeNode(str, lnode, rnode);
      s.push(tNode);
    }
  }
  TreeNode *result = s.pop();
  cout << result->getData() << endl;
}
