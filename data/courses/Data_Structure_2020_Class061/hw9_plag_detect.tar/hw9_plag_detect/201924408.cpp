#include <iostream>
#include <string>

using namespace std;

class TreeNode {
    friend class BinaryTree;
private:
    string data;
    TreeNode *lchild;
    TreeNode *rchild;
public:
    TreeNode(string d, TreeNode *l=nullptr, TreeNode *r=nullptr): 
        data(d), lchild(l), rchild(r) {
            if (l !=nullptr)
                l->data = '('+ l->data;
            if (r !=nullptr)
                r->data =  r->data + ')';
        }
};
class Node {
    string   data;
    Node *next;
public:
    friend class Stack;
    Node(){}
    Node(string d, Node *n): data(d), next(n) {}
};

class Stack {
    Node *fst;
public:
    Stack(): fst(nullptr) {}
    void push(string n) {
        Node *prev = fst;
        fst = new Node(n, prev);
    }
    string pop() {
        Node* newNode = new Node;
        string m =fst->data;
        newNode = fst;
        fst = fst->next;
        free(newNode);
        return m;
    }
};

class BinaryTree {
private:
    TreeNode *root;
public:
    BinaryTree(TreeNode *p): root(p) {} 
    void print(ostream &out) {
        if (root) {	
        	BinaryTree ltree(root->lchild);
            ltree.print(out);
            out << root->data ;
            BinaryTree rtree(root->rchild);
            rtree.print(out);
            
        }
    }
};

int main() {
	int k;
    Stack s;
    cin >> k;
    string m;
    for(int i = 0 ; i<k; i++){
        cin >> m;
        if( m == "+" || m == "-" || m == "/" || m == "*" && i<k-1){
            string r = s.pop();
            string l = s.pop();
            string newm = '(' + l + m + r + ')';
            s.push(newm);
        }
        else{
            s.push(m);
        }
    }
    m = s.pop();
    string right = s.pop();
    string left = s.pop();

    TreeNode *lnode = new TreeNode(left);
    TreeNode *rnode = new TreeNode(right);
    
    TreeNode *root = new TreeNode(m, lnode , rnode);
    BinaryTree t(root);
    t.print(cout);
}