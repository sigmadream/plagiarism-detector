#include <iostream>
using namespace std;

typedef struct Node {
	string data;
	struct Node *next;
} Node;

class Stack {
private:
	string arr[20];
	int counter;
public:
	Stack() {
		counter = 0;
	}
	
	void push(string d) {
		arr[counter++] = d;
	}
	
	string pop() {
		return arr[--counter];
	}
	
	void print() {
		for(int i = 0; i < counter; i++) {
			cout << arr[i];
		}
	}
};

int main() {
	string exp;
	int n;
	cin >> n;
	getline(cin >> ws, exp);
	
	Stack stack;
	
	for(int i = 0; i < exp.length(); i++) {
		if(exp[i] == ' ')
			continue;
			
		if(isdigit(exp[i])) {
			string tmp(1, exp[i]);
			stack.push(tmp);
		} else {
			string tmp1 = stack.pop();
			string tmp2 = stack.pop();
			stack.push("(" + tmp2 + exp[i] + tmp1 + ")");
		}
	}
	
	stack.print();
	
	return 0;
}
