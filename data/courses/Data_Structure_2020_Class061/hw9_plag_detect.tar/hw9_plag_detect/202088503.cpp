#include <iostream>
#include <string>
#include <vector>
#include <algorithm>


using namespace std;

class TreeNode{
    friend class BinaryTree;
private:
    string val;
    TreeNode *left, *right;
public:
    TreeNode(string data): val(data){ left = NULL; right = NULL;}

    TreeNode *link;
};

class BinaryTree{
public:
    void pushStack(const string &value);
    string pop();
    string makeResult();
    void show()const;
    void returnTail()const{cout << head -> val << endl;}
    void knowSize()const{cout << "Size : " << size << endl;}
    BinaryTree(){ head = NULL;}
private:
    TreeNode *head;TreeNode *topPointer;int size;
};

void BinaryTree::pushStack(const string &value) {
    TreeNode *temp = new TreeNode(value);
    temp -> link = head;
    head = temp;
    size++;
}

string BinaryTree::pop() {
    if(head -> link != NULL) {
        TreeNode *temp = head;
        head = head->link;
        string data = temp->val;
        delete temp;
        size--;
        return data;
    }else{
        return head -> val;
    }
}

void BinaryTree::show() const{
    TreeNode *temp = head;
    while(temp -> link != NULL){
        cout << temp -> val << " ";
        temp = temp -> link;
    }
    cout << temp -> val << " ";
}

int main(){
    int j;string input;
    cin >> j;
    BinaryTree *newStack = new BinaryTree();
    string result;
    vector<string> arith;
    for(int i = 0; i < j; i++){
        cin >> input;
        if(input == "+" || input == "-" || input == "*" || input == "/"){
            string temp1 = newStack -> pop();
            arith.push_back(temp1);
            arith.push_back(input);
            string temp2 = newStack -> pop();
            arith.push_back(temp2);
            result += "(";
            reverse(arith.begin(), arith.end());
            for(int i = 0; i < arith.size(); i++){
                result += arith[i];
            }
            result += ")";
            newStack -> pushStack(result);
            result = "";
            while(arith.size() != 0){
                arith.pop_back();
            }
        }
        else
            newStack->pushStack(input);
    }
    newStack->returnTail();
    return 0;
}