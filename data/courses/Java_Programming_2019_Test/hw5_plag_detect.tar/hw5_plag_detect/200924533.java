import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> al = new ArrayList<>();
		
		int N = Math.abs(sc.nextInt());
		for(int i = 2; i < N; ++i) 
			if(N % i == 0) al.add(i);
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(",", ""));
		sc.close();
	}
}