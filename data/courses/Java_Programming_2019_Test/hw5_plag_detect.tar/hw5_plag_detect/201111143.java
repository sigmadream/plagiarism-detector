import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Factors {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps =System.out;
		int a = sc.nextInt();
		int x = Math.abs(a);
		ArrayList<Integer> al = new ArrayList<>();
	
		for(int i=2;i<x;i++)
			if(x%i==0)
				al.add(i);
		
		for(int j=0;j<al.size();j++)
		{
			ps.printf("%d%s", al.get(j),(j==al.size()-1)?"":" ");
		}
		sc.close();
	}
}
