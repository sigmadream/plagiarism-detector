import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Factors {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		n = Math.abs(n);
		ArrayList<Integer> al = new ArrayList<>();
		for(int ftr=2;ftr<n;++ftr)
			if(n%ftr==0)
				al.add(ftr);
		for(int i=0;i<al.size();++i)
			ps.printf("%d%s",al.get(i), i==al.size()-1 ? "" : " " );
		sc.close();

	}
}
 