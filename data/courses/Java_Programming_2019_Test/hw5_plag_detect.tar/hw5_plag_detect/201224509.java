import java.util.*;
import java.io.PrintStream;

public class Lab03 {
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		//ps.println("Enter some integer: ");
		int input = sc.nextInt();
		int absolute = Math.abs(input);
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		
		for(int i=2; i<absolute; i++)
			if(absolute % i == 0)
				al.add(i);
	
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		
		sc.close();
		ps.close();
	}
}
