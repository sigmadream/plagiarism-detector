import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		ps.println("Enter an integers: ");
		ArrayList<Integer> al = new ArrayList<>();
		int x = 0;
		
		x = sc.nextInt();
		
		for(int i = 2; i < Math.abs(x); i++)
			if(Math.abs(x) % i == 0)
				al.add(i);
		
		
//		ps.println(al);
		
		for (int i = 0; i < al.size(); ++i)
			ps.printf("%d%s", al.get(i), i == al.size()-1?"":" ");
		
		sc.close();
	}
}
