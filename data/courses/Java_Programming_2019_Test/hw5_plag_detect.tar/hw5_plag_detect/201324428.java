import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;


public class Factors {
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int[] number = new int[10000];

        System.out.println("Input N: ");
        int valforfac = sc.nextInt();
       
        int i=0;
        
        if(valforfac > 0)
        {
        	
        	for(i = 2; i < valforfac; i++) 
        {
        if (valforfac % i == 0) 
           {
               System.out.print(i + " ");
           }
        }
        }
        else
        {
        valforfac = 0 - valforfac;
        for(i = 2; i < valforfac; i++) {
            
        	if (valforfac % i == 0) 
        	{
            System.out.print(i + " ");
        	}
        }
        }
	}
}