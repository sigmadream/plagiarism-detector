import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> al = new ArrayList<Integer>();
					
		int x = Math.abs(sc.nextInt());
		int half_x = x / 2;
		for(int i = 2; i <= half_x; i++  ) 
			if(x % i == 0)
				al.add(i);
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		ps.println();
		
		sc.close();
	}
}
