import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ps.println("Enter integers: ");
		ArrayList<Integer> al = new ArrayList<>();
		int a = sc.nextInt();
		if(a<0)
			a = -a;
		for(int i=2; i<a-1; ++i)
			if(a%i==0) al.add(i);
		
		for (int i=0; i<al.size(); ++i)
			ps.printf("%d%s", al.get(i), i==al.size()-1?"": " ");
		ps.println();
		
		/*
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		*/
		sc.close();
	}
}