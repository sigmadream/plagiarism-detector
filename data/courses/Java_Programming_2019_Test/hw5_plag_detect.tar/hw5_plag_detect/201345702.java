import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> arr = new ArrayList<>();
		int num = sc.nextInt();
		num = Math.abs(num);
		for(int i = 2; i < num ; ++i) {
			if(num % i == 0)
				arr.add(i);
		}
		String line = arr.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		sc.close();
	}
	
}
