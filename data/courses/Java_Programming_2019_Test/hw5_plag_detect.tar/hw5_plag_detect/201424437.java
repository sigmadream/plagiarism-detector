
import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> al = new ArrayList<>();
		ArrayList<Integer> al2 = new ArrayList<>();
		al.add(sc.nextInt());
		for (Integer n: al)
			if(n.intValue()>0) {
				for(int i =2; i < n.intValue(); ++i)
					if(n.intValue()%i==0)
						al2.add(i);
			}
			else
			{
				for(int i =2; i < -n.intValue(); ++i)
					if(n.intValue()%i==0)
						al2.add(i);
			}
			
		String line = al2.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));

		sc.close();
	}
}