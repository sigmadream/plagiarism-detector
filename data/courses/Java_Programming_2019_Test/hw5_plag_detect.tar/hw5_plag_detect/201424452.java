import java.io.PrintStream;
import java.util.*;
 class FindFactors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
//		ps.println("Enter some integers: ");
		ArrayList<Integer> al = new ArrayList<>();
		int num=sc.nextInt();
//		while (sc.hasNextInt())
//			al.add(sc.nextInt());
//		ps.println(al);
//		for (Integer n : al)
//			ps.printf("%d ", n.intValue());
//		ps.println();
		if(num>=0)
		{
			for(int i=2; i<num ; i++) {
				if(num%i==0) {
					al.add(i);
				}
			}
		}
		else {
			num= -1*num;
			for(int i=2; i<num ; i++) {
				if(num%i==0) {
					al.add(i);
				}
			}
		}
		for(int i =0; i<al.size(); ++i) {
			ps.printf("%d%s", al.get(i), (i==al.size()-1)?"":" ");
		}
////		for (int i = 0; i < al.size(); ++i) {
//			ps.printf("%d ", al.get(i));
//		}
//		ps.println();
//		String line = al.toString();
////		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
//		ps.println();
		sc.close();
		// System.out.println(Arrays.toString(a))
	}
}
