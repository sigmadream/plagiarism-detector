import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class abcd {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		PrintStream ps= System.out;
		

		ArrayList<Integer> al = new ArrayList<>();
		
		int a = sc.nextInt();
		
		int b = Math.abs(a);
				
		int i = 2;
		do {
			if (b%i==0)
				al.add(i);
			
			i ++;
		}while ( i < b);
				
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		
		sc.close();
	}
}


