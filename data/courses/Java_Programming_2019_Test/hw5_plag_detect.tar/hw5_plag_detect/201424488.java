import java.io.PrintStream;
import java.util.*;

public class Factors {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		ArrayList<Integer> al = new ArrayList<>();
		int n = sc.nextInt();
		if(n<0)
			n= -n;
		for(int i=2;i<n;i++) {
			if(n%i == 0)
			{
				al.add(i);
			}
			else;
		}
		for (int i = 0; i < al.size(); ++i) {
			ps.printf("%d%s", al.get(i),i==al.size()-1?"":" ");
		}
		ps.println();
	}
}
