import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> al = new ArrayList<>();
		int num1 = sc.nextInt();
		int num2 = Math.abs(num1);
		for(int i=2; i < num2; i++) {
			if((num2%i) == 0) {
				al.add(i);
			}
		}
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(",", ""));
		sc.close();
	}
}