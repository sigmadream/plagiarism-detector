import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int i = sc.nextInt();
		int ABSi = Math.abs(i);
		ArrayList<Integer> al = new ArrayList<Integer>();
		for(int index = 2;index<ABSi;index++){
			if(ABSi%index==0)
				al.add(new Integer(index));
		}
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		
		sc.close();
	}
}