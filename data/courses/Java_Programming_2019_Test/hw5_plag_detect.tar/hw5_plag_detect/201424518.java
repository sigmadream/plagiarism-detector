import java.io.PrintStream;
import java.util.*;

public class Lab03 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		x = Math.abs(x);
		ArrayList<Integer> al = new ArrayList<>();
		
		for (int i = 2; i < x ;i++){
			if( x % i == 0)
				al.add(i);	
		}
		
		PrintStream ps = System.out;
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " ")); // replace [, |, ] to comma+space -> only space
		
		sc.close();
	}
}
