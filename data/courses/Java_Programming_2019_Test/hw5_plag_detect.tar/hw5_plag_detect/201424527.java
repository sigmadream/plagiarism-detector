import java.io.PrintStream;
import java.util.*;
import java.lang.Math;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> al = new ArrayList<Integer>();
		int thefactors = sc.nextInt();
		int thefactor;
		thefactor = Math.abs(thefactors);
		for(int i = 2; i < thefactor; i++)
		{
			
			if(thefactors%i == 0)
			{
				al.add(i);
			}
			else;
		}

			String line = al.toString();
			ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
			sc.close();

	}
}
