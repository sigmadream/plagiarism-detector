import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ps.println("Enter one integers: ");
		ArrayList<Integer> al = new ArrayList<>();
		int a = sc.nextInt();
		a = Math.abs(a);
		for (int i=2; i<a; i++) {
			if (a % i == 0) {
				al.add(i);
			}

		}
		
		
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " ")); //
		ps.println();
		sc.close();
	}
}