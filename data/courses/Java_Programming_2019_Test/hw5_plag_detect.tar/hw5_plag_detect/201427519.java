import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class e2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> al = new ArrayList<>();
		
		 
		int b=sc.nextInt();
		int n=Math.abs(b);
		
		
		for (int i=2; i<n;i++){
			if(n%i==0)
			  al.add(i);
		}
		
		String line=al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		ps.println();
		sc.close();	
		
	}

}
