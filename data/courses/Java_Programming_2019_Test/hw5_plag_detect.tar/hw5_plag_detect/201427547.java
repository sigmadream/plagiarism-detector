import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintStream;
public class Factors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> al = new ArrayList<Integer>();
		PrintStream ps = System.out;
		int a = Math.abs(sc.nextInt());
		for(int i = 2; i < a; i++){
			if(a % i == 0){
				al.add(i);
			}
		}
		
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));

	}

}
