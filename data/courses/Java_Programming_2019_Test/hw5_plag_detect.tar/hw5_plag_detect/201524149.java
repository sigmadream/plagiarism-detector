import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		ArrayList<Integer> al = new ArrayList<>();

		n=Math.abs(n);
		
		for(int i=2;i<n;i++) {
			if(n%i==0)
				al.add(i);
		}

		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		ps.println();
		sc.close();
	}
}