import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ps.println("Enter some integr: ");
		int num = sc.nextInt() ;
		num = Math.abs(num);
		ArrayList<Integer> a = new ArrayList<>();
		int i;
		for(i=2; i < num; i++) 
			if(num%i==0)
				a.add(i);
		for(int j=0; j<a.size(); ++j) {
		ps.printf("%d%s", a.get(j), (j==a.size()-1)?"":" ");		
		}
		sc.close();		
	}
}



