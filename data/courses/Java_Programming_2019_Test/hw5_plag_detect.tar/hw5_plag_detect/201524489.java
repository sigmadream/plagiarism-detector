import java.io.PrintStream;
import java.util.Scanner;
import java.util.ArrayList;

public class Factors {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> al = new ArrayList<Integer>();
		
		int numb=sc.nextInt();
		
		if(numb<0)
			numb=Math.abs(numb);
		for(int i=2;i<numb;i++) {
			if(numb%i==0)
				al.add(i);
		}
		
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replaceAll(", ", " "));
		ps.println();
		
		sc.close();
	}
 
}
