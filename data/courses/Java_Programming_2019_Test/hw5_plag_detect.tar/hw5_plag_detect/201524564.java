import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintStream;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> a = new ArrayList<Integer>();
		int Number= sc.nextInt();
		if (Number<0)
			Number=Math.abs(Number);
		
		for (int i=2;i<Number;i++){
			if(Number%i==0)
				a.add(i);		
		}
		String line=a.toString();

		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		sc.close();
	}
}