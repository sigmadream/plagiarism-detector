import java.io.PrintStream;
import java.util.*;
public class lab03 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int cnt=0;
		ArrayList<Integer> al = new ArrayList<Integer>();
		int number = Math.abs(sc.nextInt());
		for(int i=2;i<number;i++){
			if(number%i==0){
				al.add(i);
				cnt++;
			}
		}
		for(int j=0;j<cnt-1;j++){
			ps.printf("%d ", al.get(j));
		}
		ps.printf("%d",al.get(cnt-1));
		sc.close();
	}
}
