import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n=Math.abs(sc.nextInt()), a=0;
		for(int i=2; i<n; i++) {
			if(n%i==0) {
			a=n/i;
			break;
			}
			}
		
		for(int i=2; i<n; i++) {
			if(n%i==0) { 
				ps.printf("%d", i);
				if(i!=a) ps.printf(" ");
			}
			}
			
	sc.close();
	}

}
