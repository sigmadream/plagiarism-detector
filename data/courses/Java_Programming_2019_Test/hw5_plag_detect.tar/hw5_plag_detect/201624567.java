import java.io.PrintStream;
import java.util.*;

public class Factors2 {
	public static void main(String[] args) { 
		Scanner sc = new Scanner(System.in);  
		PrintStream ps = System.out;
		int N = sc.nextInt();
		N = Math.abs(N);
		ArrayList<Integer> al = new ArrayList<>();
		for(int i = 2; i <N ; i++) {
			if(N % i == 0) {
				al.add(i);
			}
		}
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " ")); 
		
		
	}
		

}
