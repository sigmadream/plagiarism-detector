import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Factors {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		PrintStream ps = System.out;
		Scanner sc = new Scanner(System.in);
		
		ArrayList<Integer> al = new ArrayList<>();
		int n = sc.nextInt();
		int factor;
		n = Math.abs(n);
		
		if (n > 1 && n < 100000) {
			for (int i = n-1; i > 1; i--)
				if (n % i == 0) {
					factor = n / i;
					al.add(factor);
				}
				
			String line = al.toString();
			ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
			ps.println();
		}
		
		else {
			throw new Exception();
		} 
		
		sc.close();
		
	}

}
