import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
 
public class Factors {
	private static Scanner sc;
	
	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		int Number, i;
		sc = new Scanner(System.in);
		PrintStream ps=System.out;
		Number = sc.nextInt();
		int a= Math.abs(Number);
		//ps.print("|");
		for(i = 2; i < a; i++) {
			if(a%i == 0) {
				al.add(i);
			}	
		}
	
		String line = al.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));

	}
}