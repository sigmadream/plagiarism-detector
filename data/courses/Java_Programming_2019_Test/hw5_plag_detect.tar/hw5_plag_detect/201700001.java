import java.util.ArrayList;
import java.util.Scanner;
public class Factors {

    public static void main(String[] args) {
        int myInt = getInt();
        ArrayList<Integer> tmpAL = getFactors(myInt);
        String myStr = formatAL(tmpAL);
        System.out.print(myStr);
    }
    public static int getInt(){
        Scanner sc = new Scanner(System.in);
        int tmp = sc.nextInt();
        return Math.abs(tmp);
    }
    public static ArrayList<Integer> getFactors(int myInt){
        ArrayList<Integer> al = new ArrayList<Integer>();
        for (int i=2; i<myInt;i++){
            if (myInt % i == 0)
                al.add(i);
        }
        return al;
    }
    public static String formatAL(ArrayList<Integer> tmpAL){
        String str = tmpAL.toString();
        str = str.replaceAll("\\[|\\]","");
        str = str.replace(", "," ");
        return str;
    }

}
