import java.io.PrintStream;
import java.util.*;

public class Factors {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		//ps.println("Enter some integers: ");
		int n = sc.nextInt();
		n = Math.abs(n);
		
		ArrayList<Integer> al = new ArrayList</*Integer*/>();
		
		for (int i = 2; i<n; i++) 
			if (n % i == 0)
				al.add(i);

//		ps.println(al);  //X al.toString()
		

//		for (Integer n: al)
//			ps.printf("%d ", n.intValue());
		
		for (int i = 0; i < al.size(); ++i) {
			ps.printf("%d%s", al.get(i), (i == al.size()-1)?"":" "); //conditional operator: c?v1:v2
		}

//		String line = al.toString();
//		//ps.println("|"+line+"|");
//		String line2 = line.replaceAll("^.|.$", "");
//		//ps.println("|"+line2+"|");
//		String line3 = line2.replace(", ", " ");
//		//ps.println("|"+line3+"|");
		sc.close();
	}
}