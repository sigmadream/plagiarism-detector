import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintStream;

public class PolynomialValue {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int N = sc.nextInt();
		double x;
		double y;
		double p = 0;
		double min;
		Double[] al_F = new Double[100];
		Double[] al_D = new Double[100];
		Double[] result = new Double[3];
		
		for(int i=N; i>=0; i--){
			x = sc.nextDouble();
			al_F[i] = x;
		}
		for(int i=0; i<3; i++){
			y = sc.nextDouble();
			al_D[i] = y;
		}
		for(int i=0; i<3; i++){
			p = 0.0;
			for(int j=0; j<=N; j++){
				p += al_F[j] * Math.pow(al_D[i], j);
			}
			result[i] = p;
		}
		min = result[0];
		for(int i=1; i<3; i++){
			if(result[i] < min) min = result[i];
		}
		ps.printf("%.2f", min);
		sc.close();
	}
}
