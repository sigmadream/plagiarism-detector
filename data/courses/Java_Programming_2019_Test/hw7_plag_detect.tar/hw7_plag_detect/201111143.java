import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PolynomailValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n =sc.nextInt();
		ArrayList<Double> al = new ArrayList<>();
		int i = 0,j =0;
		
		for(i=0;i<(n+1);i++) {
			double f=sc.nextDouble();
			al.add(f);
		}
		
		
		double sum1 = 0,sum2=0, sum3=0;
		double res=0;
		double x = sc.nextDouble();
		double y = sc.nextDouble();
		double z = sc.nextDouble();
		
		for(i=n;i>=0;i--) {
			sum1 += al.get(n-i)*Math.pow(x,i);
		}
		for(i=n;i>=0;i--) {
			sum2 += al.get(n-i)*Math.pow(y,i);
		}
		for(i=n;i>=0;i--) {
			sum3 += al.get(n-i)*Math.pow(z,i);
		}
		if((sum1<sum2) && (sum1<sum3))
			res=sum1;
		if((sum2<sum1) && (sum2<sum3))
			res=sum2;
		if((sum3<sum2) && (sum3<sum1))
			res=sum3;
		
		ps.printf("%.2f",res);
		
		sc.close();
	}
}
