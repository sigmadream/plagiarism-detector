import java.io.PrintStream;
import java.util.Scanner;

public class PolynomialValue {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		double[] coef = new double[n+1];
		double[] pmtr = new double[3];
		double[] res = new double[3];
		double ans;
		for(int i=0;i<n+1;i++)
			coef[i] = sc.nextDouble();
		for(int i=0;i<3;i++)
			pmtr[i] = sc.nextDouble();
		
		for(int j=0;j<3;j++)
			res[j] = result(n, j, coef, pmtr);
		
		ans = min_in_list(res);
		
		ps.printf("%.2f",ans);
		sc.close();		
	}

	private static double min_in_list(double[] res) {
		double ans = res[0];
		for(int i=1;i<3;++i)
			if(ans>res[i])
				ans = res[i];
		return ans;
	}

	private static double result(int n, int j, double[] cef, double[] p) {
		double s=0;
		for(int i=0;i<n+1;i++) 
			s+=cef[i]*Math.pow(p[j],n-i);
		return s;
	}

}
