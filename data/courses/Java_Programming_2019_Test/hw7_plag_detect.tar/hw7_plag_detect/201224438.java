import java.io.PrintStream;
import java.util.Scanner;

public class PolynomialValue {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int size = 0;
		double[] test = null;
		size = sc.nextInt();
		test = new double[size+1];
		for(int i=size; i>=0; --i){
			test[i] = sc.nextDouble();
		}
 		double[] result = new double[3];
		for(int i=0; i<3; i++){
			double sum = test[0];
			double x = sc.nextDouble();
			for(int j=1; j<=size; j++ ){
				double y = test[j]*(Math.pow(x, j));
				sum += y;
			}
			result[i] = sum;
		}
		double Min = result[0];
		for(int i=0; i<3; i++){
			if(Min > result[i]) Min = result[i];
		}
		ps.printf("%.2f\n", Min);
		sc.close();
	}

}
