import java.io.PrintStream;
import java.util.*;

public class Lab04 {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int n = sc.nextInt();
		ArrayList<Double> x = new ArrayList<Double>(n);
		for(int i=0; i<n+1; i++){
			x.add(sc.nextDouble());
		}
		
		ArrayList<Double> y = new ArrayList<Double>(n);
		for(int i=0; i<3; i++){
			y.add(sc.nextDouble());
		}
		
		
		ArrayList<Double> result = new ArrayList<Double>(n);
		double total = 0;
		double minimum = Integer.MAX_VALUE;
		for(int i=0; i<3; i++){
			total = 0;
			for(int j=0; j<n+1; j++){
				total += (x.get(j) * Math.pow(y.get(i), n-j));
			}
			result.add(total);
			if(minimum > result.get(i))
				minimum = result.get(i);
		}		
		
		
		ps.printf("%.2f",minimum);
		sc.close();
		
	}
}
