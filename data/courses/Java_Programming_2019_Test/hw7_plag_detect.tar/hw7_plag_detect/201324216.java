import java.io.PrintStream;
import java.util.*;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		ArrayList<Double> c = new ArrayList<>();
		for(int i = 0 ; i <= n ; i++) {
			c.add(sc.nextDouble());
		}
		double[] x = new double[3];
		double[] f = new double[3];
		for(int i = 0 ; i < 3 ; i++) {
			x[i] = sc.nextDouble();
			for(int j = 0; j <= n ; j++ ) {
				f[i] += c.get(j)*Math.pow(x[i], n-j);
			}
		}
		ps.printf("%.2f", Math.min(f[0],Math.min(f[1],f[2])));
		
		
		sc.close();
		
		
	}
}
