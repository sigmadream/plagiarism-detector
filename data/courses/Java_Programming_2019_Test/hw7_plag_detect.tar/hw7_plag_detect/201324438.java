import java.io.PrintStream;
import java.util.Scanner;

public class PolynomialValue {
	
	public static double min(double a, double b){
		if(a > b)
			return b;
		else
			return a;
	}
	
	public static double cal_Poly(double[] E,double[] E2, int n){
		double result = 0.0;
		double compare = 0.0;
		for(int j = 0; j < 3; j++){
			for(int i =n; i != -1; i--)
				result += E[n-i] * Math.pow(E2[j], i); 
			if(j == 0) compare = result;
			else compare = min(compare, result);
			result = 0;
		}
		
		return compare;
	}
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int n = sc.nextInt();
		double p = 0.0;
		double[] E = new double[n + 1];
		double[] E2 = new double[4];
		
		for(int i = n; i != -1; i--)
			E[n - i] = sc.nextDouble();
		
		for(int j = 0; j < 3; j++)
			E2[j] = sc.nextDouble();
		
		p = cal_Poly(E, E2, n);
		
		ps.printf("%.2f%n", p);
		ps.close();
		sc.close();
	}
}

