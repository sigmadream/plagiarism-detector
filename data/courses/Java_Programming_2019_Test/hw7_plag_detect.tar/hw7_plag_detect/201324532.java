import java.io.PrintStream;
import java.util.Scanner;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		double[] a = new double[512];
		double[] b = new double[512];
		int i,j;
		for(i=0; i<n+1; ++i)
			a[i] = sc.nextDouble(); 
		for(j=0; j<3; ++j)
			b[j] = sc.nextDouble();
		
		
		double f1=0.0, f2=0.0, f3=0.0;
		for(int k=0; k<n+1; ++k)
			f1 += a[k]*Math.pow(b[0], n-k);
		for(int k=0; k<n+1; ++k)
			f2 += a[k]*Math.pow(b[1], n-k);
		for(int k=0; k<n+1; ++k)
			f3 += a[k]*Math.pow(b[2], n-k);
		
		double min_f = f1;
		if(min_f>f2) min_f = f2;
		if(min_f>f3) min_f = f3;
		ps.printf("%.2f%n", min_f);
		sc.close();
	}
}
