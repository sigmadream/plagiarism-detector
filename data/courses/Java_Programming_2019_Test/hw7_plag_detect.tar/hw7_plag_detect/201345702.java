import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PolynomialValue {
	public static void main(String[] args) {
		int topOfCoef;
		double retNum = 1e9;
		ArrayList<Double> list, arrX;
		
		list = new ArrayList<>(); arrX = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		topOfCoef = sc.nextInt();
		for(int i = 0 ; i <= topOfCoef ; ++i)
			list.add(sc.nextDouble());
		for(int i = 0; i < 3 ; ++i)
			arrX.add(sc.nextDouble());
		for(double x : arrX) 
			retNum = Math.min(retNum, calPoly(list, x));
		ps.printf("%.2f", retNum);
		sc.close();
	}
	private static double calPoly(ArrayList<Double> arr, double x) {
		int top = arr.size()-1;
		double ret = 0;
		for(double val : arr)
			ret += val*Math.pow(x, top--);
		
		return ret;
	}
}