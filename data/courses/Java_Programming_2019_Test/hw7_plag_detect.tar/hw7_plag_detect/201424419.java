import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PolynomialValue {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		ArrayList<Double> fun = new ArrayList<>();
		ArrayList<Double> input = new ArrayList<>();
		for (int i = 0; i < n + 1; i++) {
			fun.add(sc.nextDouble());
		}
		for (int i = 0; i < 3; i++) {
			input.add(sc.nextDouble());
		}
//		System.out.println(fun);
//		System.out.println(input);
		ArrayList<Double> output = new ArrayList<>();
		ArrayList<Double> funrev = new ArrayList<>();
		
//		for (int i = fun.size() - 1; i >= 0; i--) {
//			funrev.add(fun.get(i));
//		}
//		System.out.println(funrev);

		double sum = 0.0;
		for(int i = 0 ; i< 3; i++){
			for(int j = 0 ; j < fun.size();j++){
				sum+= fun.get(j)*Math.pow(input.get(i), n-j);
			}
			output.add(sum);
			sum = 0.0;
		}
		
//		System.out.println(output);
		
		double min=2222222222222.0;
		for(int i = 0 ; i < output.size();i++){
			if(output.get(i)<min){
				min = output.get(i);
			}
		}
		ps.printf("%.2f", min);
		
		ps.close();
		sc.close();

	}

}
