
import java.io.PrintStream;
import java.util.Scanner;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int P  = sc.nextInt();
		double [] a = new double [100];
		double [] b = new double [100];
		for(int i=0; i<P+1;i++) {
			double C = sc.nextDouble();
			a[i] = C;
		}
		double x = sc.nextDouble();
		double y = sc.nextDouble();
		double z = sc.nextDouble();
		double x1 = 0;
		double y1 = 0;
		double z1 = 0;
		for(int i = 0; i<P;i++) {
			x1+=Math.pow(x, P-i)*a[i];
			
		}
		
		x1+= a[P];
		for(int i = 0; i<P;i++) {
			y1+=Math.pow(y, P-i)*a[i];
		}
		y1+= a[P];
		for(int i = 0; i<P;i++) {
			z1+=Math.pow(z, P-i)*a[i];
		}
		z1+= a[P];
		if(z1>x1&&y1>x1) {
			ps.printf("%.2f%n",x1);	
		}
		if(z1>y1&&x1>y1) {
			ps.printf("%.2f%n",y1);	
		}
		if(x1>z1&&y1>z1) {
			ps.printf("%.2f%n",z1);	
		}
		
		
		


		sc.close();
	}
}