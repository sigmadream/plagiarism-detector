 import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

 public class lav444{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		//ps.print("Enter two floating point numbers: ");
		int size = sc.nextInt();
		double coe[] = new double[size+1];
		double val[] = new double[size+1];
		double result[] = new double[size+1];
		for (int i=0;i<size+1;i++) {
			coe[i]= sc.nextDouble();			
			val2++;
			
		}
		 int val2=0;
		for (int i=0;i<size+1;i++) {
			val[i]= sc.nextDouble();
//					val2++;
		}
		for(int j=0; j<val2; j++) {
			for (int i=0;i<size+1;i++) {
				result[j]+= coe[i]*Math.pow(val[j], (double)(size-i));
			}
		}
		Arrays.sort(result);
		ps.printf("%.2f%n",result[0]);
		
		sc.close();
 	}
 }