import java.util.Scanner;
import java.io.PrintStream;

public class Lab4 {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		double[] co = new double[10];
		double[] sum= new double[10];
		double result =0;
		int n = sc.nextInt();
		for(int i=0; n==0;n--,i++){
			co[i] = sc.nextDouble();
		}
		
		for(int i =0,j =n,k=0; i<n; i++,n--,k++){
			sum[k] += co[i]*Math.pow(sc.nextDouble(),n);
		
		}
		for(int k=0; k<3; k++){
			if(sum[k]>=sum[k+1])
				result = sum[k+1];
			else
				result = sum[k];
		}
		ps.printf("%f ", result);
		ps.close();
		sc.close();
		
	}
}
