import java.io.PrintStream;
import java.util.Scanner;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int effi = sc.nextInt();
		double[] coef = new double[effi+1];
		for(int i = 0;i<effi+1;i++){
			coef[i] = sc.nextDouble();
			
		}
		
		double[] kvalue = new double[3];
		for(int i = 0;i<3;i++){
			kvalue[i] = sc.nextDouble();
			
		}
		int temp = effi;
		
		double[] Polval = new double[3];
		for(int i = 0;i<3;i++){
			
			for(int j = 0;j<=temp;j++){
				
				Polval[i] += coef[j]*Math.pow(kvalue[i],effi--);
			
			}
			
			effi = temp;
		}
		double min=0;
		for(int i = 0;i<2;i++){
			
			if(Polval[i]>Polval[i+1]){
				min = Polval[i+1];
			}
		}
		ps.printf("%.2f",min);
			
		
		sc.close();
	}
}
