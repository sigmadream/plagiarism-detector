
import java.util.Scanner;



public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		double[] x = new double[a+1];
		double p1 = 0;
		double p2 = 0;
		double p3 = 0;
		for(int i = 0 ; i < a+1; i++)
		{
			x[i] = sc.nextDouble();
			
		}

		double[] k = new double[a+1];
		double m = (double)a;
		for(int j =0 ; j < 3 ; j++)
		{
			k[j]=sc.nextDouble();
			
		}
		for(int j =0 ; j < a+1 ; j++)
		{
			p1+=x[j]*Math.pow(k[0], m);
			p2+=x[j]*Math.pow(k[1], m);
			p3+=x[j]*Math.pow(k[2], m);
			m--;
			
		}
		if (p1 <= p2 && p1 <= p3) 
			System.out.printf("%.2f%n", p1);

		
		else if (p2 <= p1 && p2 <= p3) 
			System.out.printf("%.2f%n", p2);

		
		else if (p3 <= p1 && p3 <= p2)
			System.out.printf("%.2f%n", p3);

		

		
		sc.close();
		
	}
}