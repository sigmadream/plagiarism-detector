import java.io.PrintStream;
import java.util.Scanner;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
//		ps.print("Enter two floating point numbers: ");
		double[] Coef = new double[100];
		double[] Result = new double[3];
//		double[] x = new double[100];
		
		int n = sc.nextInt();
		
		for (int i=n; i>-1; i--) {
			Coef[i] = sc.nextDouble();
		}
		
//		double x = sc.nextDouble();
//		double y = sc.nextDouble();
//		double z = sc.nextDouble();
		
		for (int i=0; i<3; i++) {
			double x=sc.nextDouble();
			double result = 0;
			for(int j=0; j<=n; j++) {
			result+=Coef[j]*Math.pow(x, j);
			}
			Result[i]=result;
		}
		
		double R = Result[0];
		for (int i=1; i<3; i++) {
			if (Result[i]<R) R=Result[i];
		}
		
//		double p = Math.pow(x, y);
//		ps.printf("pow(%f, %f) = %f%n", x, y, p);
		ps.printf("%.2f", R);
		sc.close();
	}
}