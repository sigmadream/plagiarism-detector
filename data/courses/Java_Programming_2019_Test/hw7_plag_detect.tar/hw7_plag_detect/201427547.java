import java.io.PrintStream;
import java.util.Scanner;

public class Lab04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		double c1 = 0;
		double c2 = 0;
		double c3 = 0;
		double c4 = 0;
		double[] d = new double[3];

		double[] function = new double[3];
		if(n == 2){
			
			c1 = sc.nextDouble();
			c2 = sc.nextDouble();
			c3 = sc.nextDouble();
			
			for(int j = 0; j < 3; j++){
				d[j] = sc.nextDouble();
				function[j] = c1*Math.pow(d[j], 2) + c2*Math.pow(d[j], 1) + c3*Math.pow(d[j], 0);
			}
		}
		
		
		if(n == 3){
			c1 = sc.nextDouble();
			c2 = sc.nextDouble();
			c3 = sc.nextDouble();
			c4 = sc.nextDouble();
		
			for(int j = 0; j < 3; j++){
				d[j] = sc.nextDouble();
				function[j] = c1*Math.pow(d[j], 3) + c2*Math.pow(d[j], 2) + c3*Math.pow(d[j], 1) + c4;
			}
		}
		
		if(function[0] < function[1]){
			if(function[0] < function[2]){
				ps.printf("%.2f",function[0]);
			}
			else{
				ps.printf("%.2f",function[2]);
			}
		}
		else if(function[0] > function[1]){
			if(function[1] > function[2]){
				ps.printf("%.2f",function[2]);
			}
			else{
				ps.printf("%.2f",function[1]);
			}
		}
	}
}
