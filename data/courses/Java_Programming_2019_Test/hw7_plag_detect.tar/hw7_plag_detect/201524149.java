import java.io.PrintStream;
import java.util.Scanner;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		double[] Coef = new double[100];
		int ind = sc.nextInt();

		
		double[] value = new double[3];
		double[] Calc =new double[3];
		for(int i=0;i<=ind;i++)
			Coef[i]=sc.nextDouble();
		
		for(int i=0;i<3;i++)
			value[i]=sc.nextDouble();

		
		for(int i=0;i<3;i++)
		{
			for(int j=ind,k=0;j>=0;j--,k++)
			{
				Calc[i]+=Math.pow(value[i],j)*Coef[k];
			}
		}
		ps.printf("%.2f",min(Calc));
		
	}
	public static double min(double n[]) {
	    double min = n[0];

	    for (int i = 1; i < n.length; i++)
	      if (n[i] < min) min = n[i];

	    return min;
	}


}



