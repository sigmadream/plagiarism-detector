import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class lab04 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n=sc.nextInt();
		double min=0;
		ArrayList<Double> al=new ArrayList<>();
		ArrayList<Double> bl=new ArrayList<>();
		ArrayList<Double> cl=new ArrayList<>();
		for(int i=0;i<n+1;i++){
			al.add(sc.nextDouble());
		}
		for(int j=0;j<3;j++){
			bl.add(sc.nextDouble());
		}
		for(int k=0;k<3;k++){
			double answer=0;
			for(int l=0;l<n;l++){
				answer+=(al.get(l))*Math.pow((bl.get(k)),n-l);
			}
			answer+=al.get(n);
			cl.add(answer);
		}
		if(cl.get(0)>cl.get(1)){
			if(cl.get(1)>cl.get(2))
				min=cl.get(2);
			else
				min=cl.get(1);
		}
		else{
			if(cl.get(0)>cl.get(2))
				min=cl.get(2);
			else
				min=cl.get(0);
		}
		ps.printf("%.2f",min);
		sc.close();
	}
}