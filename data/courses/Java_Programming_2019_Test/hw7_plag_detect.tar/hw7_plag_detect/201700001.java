import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class PolynomialValue {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PrintStream ps = System.out;
        //ps.print("Enter degree: ");
        int n = sc.nextInt();
        double[] f = new double[n+1];
        for (int i = 0; i <= n; i++)
            f[i] = sc.nextDouble();
        int pnts = 3;
        double[] x = new double[pnts];
        for (int i = 0; i < pnts; i++)
            x[i] = sc.nextDouble();
        //ps.println(Arrays.toString(x));
        double[] y = new double[pnts];
        for (int i = 0; i < pnts; i++)
            y[i] = eval(f, x[i]);
        //ps.println(Arrays.toString(y));
        double m = min(y);
        ps.printf("%.2f%n", m);
        sc.close();
    }

    private static double min(double[] y) {
        double m = y[0];
        for (int i = 0; i < y.length; i++)
            m = Math.min(m, y[i]);
        return m;
    }

    private static double eval(double[] f, double x) {
        double y = 0;
        // y = f[0]*x^n + f[1]*x^(n-1) + ... + f[n]
        for (int n = f.length - 1, i = 0; n >= 0; n--, i++)
            y += f[i] * Math.pow(x, n);
        return y;
    }
}