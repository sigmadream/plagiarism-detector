import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PolynomialValue {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		//ps.print("Enter two floating point numbers: ");
		int n = sc.nextInt();
		
		ArrayList<Double> coef= new ArrayList<>();
		for (int i=0; i<n+1; i++)
			coef.add(sc.nextDouble());
		//ps.println(coef);
		double min = 0;
		for (int i=0; i<3; i++){
			double dk=sc.nextDouble();
			double sum = 0;
			for (int j=n; j>=0; j--)
				sum += coef.get(n-j)*Math.pow(dk, j);
			//ps.printf("%.2f, %.2f%n", dk, sum);
			if (i==0)
				min = sum;
			else if (sum<min)
				min = sum;
		}
	

		ps.printf("%.2f", min);
		ps.close();
		sc.close();
	}
}