import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
	private int[] f;
	private int[] g;
	
	int sum;
	
	public Polynomial(int[] a, int[] b){
		this.f = a;
		this.g = b;
		
	}
	public void print(PrintStream ps){
		if(f.length == g.length){
			sum = 0;
			for(int i=f.length-1; i>=0; i--){
				sum = f[i] + g[i];
				if(i==0) ps.printf("%d", sum);
				else ps.printf("%d ", sum);
			}
		}
		else if(f.length > g.length){
			
			for(int i=f.length-1; i>=0; i--){
				sum = 0;
				if(i == f.length-1) sum = f[i];
				else sum = f[i] + g[i];
				if(i==0) ps.printf("%d", sum);
				else ps.printf("%d ", sum);
			}
		}
		else if(f.length < g.length){
			
			for(int i=g.length-1; i>=0; i--){
				sum = 0;
				if(i == g.length-1) sum = g[i];
				else sum = f[i] + g[i];
				if(i==0) ps.printf("%d", sum);
				else ps.printf("%d ", sum);
			}
		}
	}
}

public class PolyClass {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int f_deg = sc.nextInt();
		int[] f = new int[f_deg+1];
		
		for(int i=f_deg; i>=0; i--){
			f[i] = sc.nextInt();
		}
		
		int g_deg = sc.nextInt();
		int[] g = new int[g_deg+1];
		
		for(int i=g_deg; i>=0; i--){
			g[i] = sc.nextInt();
		}
		
		
		Polynomial p = new Polynomial(f, g);
		p.print(ps);
		sc.close();
	}
}
