import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial{
	private int[] c;
	public Polynomial(int[] cs) {
		c =cs;
	}

	public void print(PrintStream ps) {
		int n=c.length;
		for(int i=0;i<n-1;i++){
			ps.printf("%d ",c[i]);
		}
		ps.printf("%d",c[n-1]);
	
	}

	public void add(Polynomial g) {
		int n=0,s=0;
		int a=c.length;
		int b=g.c.length;
		if(a>b){
			n=a-b;
			for(int i=0;i<g.c.length;i++)
				c[i+n]+=g.c[i];
		}
		else{
			n=b-a;
			for(int i=0;i<c.length;i++)
				g.c[i+n]+=c[i];
			c=g.c;
		}
		for(s=0;s<(c.length) &&(c[s]==0) ;s++)
			;
		int[] d=new int[c.length-s];
		for(int i=0;i<d.length;i++)
			d[i]=c[i+s];
		if (d.length==0) {
			c=new int[1];
			c[0] = 0;
		}
		else
			c=d;
	
	}


}

public class PolyClass {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		
		
		int n=0,i=0,j=0;
		
		i=sc.nextInt();
		int[] fs=new int[i+1];
		for(int k=0;k<i+1;k++)
			fs[k]=sc.nextInt();
		
		j=sc.nextInt();
		int[] gs=new int[j+1];
		for(int k=0;k<j+1;k++)
			gs[k]=sc.nextInt();
	

		Polynomial f = new Polynomial(fs);
		Polynomial g = new Polynomial(gs);
		
		f.add(g);
		f.print(ps);
		sc.close();
		
	}
}