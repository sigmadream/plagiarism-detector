import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

class Poly {
	private int m_exp;
	private int[] cef;
	public Poly(int n) {
		this.m_exp=n;
	}
	public void init(Scanner sc) {
		m_exp = sc.nextInt();
		cef = new int[m_exp+1];
		for(int i=0;i<m_exp+1;++i)
			cef[i] = sc.nextInt();
	}
	public Poly sum(Poly p) {
		Poly tmp,s = new Poly(0);
		if(this.m_exp>=p.m_exp) {
			tmp = this;
			for(int i=this.m_exp-p.m_exp, j=0; i<this.m_exp+1 ;++i,++j)
				tmp.cef[i] = this.cef[i]+p.cef[j];
		}
		else {
			tmp = p;
			for(int i=p.m_exp-this.m_exp, j=0; i<p.m_exp+1 ;++i,++j)
				tmp.cef[i] = this.cef[j]+p.cef[i];
			
		}
		int i;
		for(i=0; i<tmp.m_exp+1 && tmp.cef[i]==0; ++i)
			;
		if(i<tmp.m_exp+1) {
			int n = tmp.m_exp+1-i;
			s.cef = new int[n];
			for(int j=0;j<n;++j)
				s.cef[j] = tmp.cef[i+j];
		}
		else 
			s = tmp;
		return s;
	}
	public void print(PrintStream ps) {
		ps.println(Arrays.toString(cef).replaceAll("^.|.$", "").replace(", ", " "));
	}
	
};


public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		Poly f = new Poly(0), g = new Poly(0);
		f.init(sc); 
		g.init(sc);
		Poly p = f.sum(g);
		p.print(ps);
		sc.close();
	}

}
