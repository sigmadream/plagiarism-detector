import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
 private int[] c;
 public Polynomial(int[] c) {
 this.c = c;
 }
 public void print(PrintStream ps) {
 ps.println(Arrays.toString(c).replaceAll("^.|.$", "").replace(", ", " "));
 }
}
public class PolyClass {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int size1;
		int size2;
		int min;
		int max;
		int sub;
		size1 = sc.nextInt();
		int[] p1 = new int[size1+1];
		for(int i=0; i<=size1; i++){
			p1[i] = sc.nextInt();
		}
		size2 = sc.nextInt();
		int[] p2 = new int[size2+1];
		for(int i=0; i<=size2; i++){
			p2[i] = sc.nextInt();
		}
		int[] result;
		int[] plus;
		if(size1 > size2){
			min = size2;
			max = size1;
			sub = max-min;
			result = p1;
			plus = p2;
		}
		else{
			min = size1;
			max = size2;
			sub = max-min;
			result = p2;
			plus = p1;
		}
		for(int i=0; i<=min; i++){
			result[i+sub] += plus[i];
		}
		int count =0;
		for(int i=0; i<=max; i++){
			if(result[i]==0) count++;
		}
		if(count == max+1) ps.printf("0\n");
		else{
			Polynomial p = new Polynomial(result);
			p.print(ps);
		}
		sc.close();


	}

}
