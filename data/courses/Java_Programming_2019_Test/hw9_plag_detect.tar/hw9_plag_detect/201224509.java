import java.util.*;
import java.io.PrintStream;

class Polynomial{
 private int[] f;
 private int size;
 public Polynomial(int _size){
  this.f = new int[_size+1];
  this.size = _size+1;
 }
 public void input(int _index,int _value){
  this.f[_index] = _value;
 }
 public void print(PrintStream ps){
  int sum = 0;
  for(int i=0; i<size; i++){
   sum += f[i];
   if(sum == 0)
    continue;
   else if(i==size)
	   ps.printf("%d", f[i]);
   else
    ps.printf("%d ", f[i]);
  }
 }
 public int getsize(){
  return size;
 }
 public int getvalue(int _index){
  return f[_index];
 }
 public Polynomial add(Polynomial _g){
  int tempsize;
  
  if(this.size >= _g.getsize()) tempsize = this.size;
  else tempsize = _g.getsize();
  
  int counterf = 0, counterg = 0;
  Polynomial temp = new Polynomial(tempsize-1);
  for(int i=0; i<tempsize; i++){
   int n = Math.abs(tempsize - i);
   if(n>_g.size){
    temp.input(i,this.getvalue(counterf));
    counterf++;
   }
   else if (n>this.size){
    temp.input(i, _g.getvalue(counterg));
    counterg++;
   }
   
   else{
    temp.input(i, this.getvalue(counterf) + _g.getvalue(counterg));
    counterf++;
    counterg++;
   }
  }
  return temp;
 }
}


public class polyclass {
 public static void main(String args[]){
  Scanner sc = new Scanner(System.in);
  PrintStream ps = System.out;
  
  Polynomial f = new Polynomial(sc.nextInt());
  for(int i=0; i<f.getsize(); i++){
   f.input(i, sc.nextInt());
  }
  
  Polynomial g = new Polynomial(sc.nextInt());
  for(int i=0; i<g.getsize(); i++){
   g.input(i, sc.nextInt());
  }
  
  Polynomial sum = new Polynomial(selectbigsize(f, g));
  
  sum = f.add(g);
  sum.print(ps);
  
  ps.close();
  sc.close();
  
 }

 private static int selectbigsize(Polynomial f, Polynomial g) {
  int bigsize;
    
  if(f.getsize()>=g.getsize()) bigsize = f.getsize();
  else bigsize = g.getsize();
  
  return bigsize;
 }
}
