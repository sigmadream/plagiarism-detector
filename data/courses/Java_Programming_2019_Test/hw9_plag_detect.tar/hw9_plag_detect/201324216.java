import java.util.*;
import java.io.*;

class Polynomial {
	private int[] c;
	public Polynomial (int[] c) {
		this.c = c;
	}
	public void print(PrintStream ps) {
		//ps.println(Arrays.toString(c));
		int n = c.length - 1;
		boolean valid = false;
		for (int i = 0 ; i < n ; i++) {
			if(c[i] != 0)
				valid = true;
			if(valid)
				ps.printf("%d ", c[i]);
			
		}
		ps.print(c[n]);
	}
	public Polynomial add(Polynomial f){
		int fcl = f.c.length;
		int tcl = this.c.length;
		int diff = tcl - fcl;
		int len = (fcl > tcl ? f.c.length : this.c.length) ;
		int[] tmp = new int[len];
		for (int i = 0; i < len; i++) {
			if(Math.abs(diff) > i)
				if(diff < 0)
					tmp[i] = f.c[i];
				else
					tmp[i] = this.c[i];
			else
				if(diff < 0)
					tmp[i] = this.c[i+diff] + f.c[i];
				else
					tmp[i] = this.c[i] + f.c[i-diff];
		}
		return new Polynomial(tmp);
	}
	
}

public class PolyClass {
	public static void main(String[] srgs) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int fn = sc.nextInt();
		int[] fcs = getCn(sc,fn);
		int gn = sc.nextInt();
		int[] gcs = getCn(sc,gn);
		Polynomial polyf  = new Polynomial(fcs);
		Polynomial polyg = new Polynomial(gcs);
		polyf.add(polyg).print(ps);
		sc.close();
	}
	private static int[] getCn(Scanner sc, int n) {
		int[] c = new int[n+1];
		for(int i = 0 ; i <= n ; i++) {
			c[i] = sc.nextInt();
		}
		return c;
	}
}
