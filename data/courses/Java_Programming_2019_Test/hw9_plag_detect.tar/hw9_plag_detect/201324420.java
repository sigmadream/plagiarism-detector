import java.io.PrintStream;
import java.util.Scanner;

class Polynomial{
	private int[] c;
	
	public Polynomial(String cs){
		PrintStream ps = System.out;
		String[] item = cs.split(" ");
		c = new int[item.length];
		for(int i = 0; i < item.length; i++){
			c[i] = Integer.parseInt(item[i]);
		}
	}
	public void print(PrintStream ps){
		//ps.println(Arrays.toString(c));
		int n = c.length -1;
		for(int i = n, k = 0; i > 0; i--, k++)
			ps.printf("%d ",c[k]);
		ps.println(c[n]);
	}
	public void add(Polynomial p){
		for(int i = c.length-1, j = p.c.length-1; i >= 0; i--, j--){
			c[i] += p.c[j];
		}
	}
}

public class PolyClass {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		String fx = null;
		String gx = null;
		
		if(sc.hasNextLine())
			fx = sc.nextLine();
		if(sc.hasNextLine())
			gx = sc.nextLine();
		
//		ps.println(fx);
//		ps.println(gx);
		
		Polynomial p = new Polynomial(fx);
		Polynomial g = new Polynomial(gx);

		p.add(g);
		p.print(ps);
		ps.close();
		sc.close();
	}

}
