import java.util.Scanner;
import java.util.Arrays;
import java.io.PrintStream;


public class PolyClass {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int size=0;
		int[] test = null;
		size = sc.nextInt();
		test = new int[size + 1];
		
		for(int i=size; i>=0; i--)
		{
			test[i] = sc.nextInt();
		}
		
		int size2=0;
		int[] test2 = null;
		size2 = sc.nextInt();
		test2 = new int[size2 + 1];
		
		for(int i=size2; i>=0; i--)
		{
			test2[i] = sc.nextInt();
		}
		
		for(int i=size; i>=0; i--)
		{
			ps.printf("%d ", test[i]);
		}
		ps.print("\n");
		
		for(int i=size2; i>=0; i--)
		{
			ps.printf("%d ", test2[i]);
		}
		
		
		if(size == size2)
		{
			int[] test3 = new int[size + 1];
			for(int i=size; i>=0; --i){
			test3[i] = test[i] + test2[i];
			ps.print(" ");
			//if(test3[i] != 0)
			ps.printf("%d", test3[i]);
			}
		}
		else if(size <= size2)
		{
			int[] test3 = new int[size2 + 1];
			for(int i=size2; i>0; --i)
			{
			test3[i] = test[i-1] + test2[i-1];
			ps.printf("%d ", test3[i]);
			}
			ps.print("\n");
		}
		else
		ps.print("not a possible case!");
		
		sc.close();
	}
}
