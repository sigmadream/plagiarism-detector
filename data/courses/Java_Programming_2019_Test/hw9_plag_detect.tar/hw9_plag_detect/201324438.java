import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
	private int[] c;
	private int[] d;
	private int size;

	public Polynomial(int[] c) {
		this.c = c;
	}
	public void get_size(int size){
		this.size= size;
		d = new int[size];
		
		for(int i = 0, k = 0; i < size; i++){
			
			if(c[0] == 0){
				if(c[i] != 0){
					d[k] = c[i];
				}
			}
			else{ d[i] = c[i];
				i++;
			}
		}
	}
	
	public void print(PrintStream ps){
		String line = Arrays.toString(d);
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
	}
}

public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> A = new ArrayList<>();
		ArrayList<Integer> B = new ArrayList<>();
		ArrayList<Integer> C= new ArrayList<>();
		ArrayList<Integer> D= new ArrayList<>();
		int t = 0;
		
		int a = sc.nextInt();
		
		for(int i = 0; i <=a; i++)
			A.add(sc.nextInt());
		
		int b = sc.nextInt();
		
		for(int i = 0; i <=b; i++)
			B.add(sc.nextInt());
	
		if(a > b) {
			C = A;
			D = B;
			t = b;
		}
		else {
			C = B;
			D = A;
			t =  a;
		}

		int[] object = new int[C.size()];
		for(int i = 0; i < C.size(); i++) object[i] = C.get(i);
		for(int i = 0; i <= t; i++)
			object[C.size() - i - 1] = C.get(C.size() - i - 1) + D.get(D.size() - i - 1); 
		Polynomial p = new Polynomial(object);
		p.get_size(C.size());
		p.print(ps);
		
		sc.close();
	}
}
	