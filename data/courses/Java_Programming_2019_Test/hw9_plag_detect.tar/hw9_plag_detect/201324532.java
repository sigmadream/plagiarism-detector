import java.io.PrintStream;
import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;

class Polynomial {
	private int[] c;
	public Polynomial(int[] cs) {
		this.c = cs; 
	}
	public void print(PrintStream ps,int n, int k) {
		if(k==0){
			for(int i=0; i<n; ++i)
				ps.printf("%d ", c[i] );
			ps.printf("%d", c[n]);
		}
		else {
			for(int i=k; i<n; ++i)
				ps.printf("%d ",c[i] );
			ps.printf("%d", c[n]);
		}
	}
}

public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int[] cs1 = new int[512];
		int[] cs2 = new int[512];
		int n1 = sc.nextInt();
		for(int i=0; i<n1+1; ++i)
			cs1[i] = sc.nextInt();  
		int n2 = sc.nextInt();
		for(int i=0; i<n2+1; ++i)
			cs2[i] = sc.nextInt(); 
		
		int cs_sum_len = n1>=n2? n1:n2;
		int[] cs_sum=new int[cs_sum_len+1];
		
		int gap = Math.abs(n1-n2);
		if(n1>n2) { 	
			for(int i=0; i<gap; ++i)
				cs_sum[i]=cs1[i];
			for(int i=gap; i<cs_sum_len+1; ++i)
				cs_sum[i]=cs1[i]+cs2[i-1];
		}
		else if(n1<n2) {
			for(int i=0; i<gap; ++i)
				cs_sum[i]=cs2[i];
			for(int i=gap; i<cs_sum_len+1; ++i)
				cs_sum[i]=cs1[i-1]+cs2[i];
		}
		else
			for(int i=0; i<cs_sum_len+1; ++i)
				cs_sum[i]=cs1[i]+cs2[i];
		int k=0;
		for(int i=0; i<cs_sum_len+1 && !(cs_sum[i]!=0); ++i)
			if(cs_sum[i]==0)
				++k;
		
		if(cs_sum[0]==0) {
			Polynomial p = new Polynomial(cs_sum);
			p.print(ps, cs_sum_len, k);
		}
		else {
			Polynomial p = new Polynomial(cs_sum);
			p.print(ps, cs_sum_len, 0);
		}
		
		ps.close();
		sc.close();
	}
}

