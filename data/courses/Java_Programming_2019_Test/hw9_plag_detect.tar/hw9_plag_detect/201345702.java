import java.io.PrintStream;
import java.util.Scanner;

class Polynomial{
	private int[] c;
	public Polynomial(int[] cs) {
		c = cs;
	}
	void add(Polynomial rhs) {
		int e = c.length - rhs.c.length;
		for(int i = c.length-1, j = rhs.c.length-1 ; i >= e ; --i, --j)
			c[i] += rhs.c[j];
		
	}
	
	public void print(PrintStream ps) {
		int e = 0;
		while(c[e] == 0 && e < c.length-1)
			e++;
		
		if(e > c.length-1)
			ps.printf("0");
		else {
			for(; e <= c.length-1 ; ++e) 
				ps.printf("%d ",c[e]);
			
		}
		
			
	}
}


public class PolyClass {
	public static void main(String[] args) {
		int SZ1, SZ2;
		int[] arr1, arr2;
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		SZ1 = sc.nextInt();
		arr1 = new int[SZ1+1];
		for(int i = 0; i <= SZ1 ; ++i)
			arr1[i] = sc.nextInt();
		SZ2 = sc.nextInt();
		arr2 = new int[SZ2+1];
		for(int i = 0; i <= SZ2 ; ++i)
			arr2[i] = sc.nextInt();
		Polynomial p1 = new Polynomial(arr1);
		Polynomial p2 = new Polynomial(arr2);

		if(SZ1 >= SZ2) {
			p1.add(p2);
			p1.print(ps);
		}
		else {
			p2.add(p1);
			p2.print(ps);
		}
		ps.close();
		sc.close();
		
	}
}
