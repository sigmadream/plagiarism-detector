
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;



class Polynomial {
	public ArrayList<Integer> poly;

	public Polynomial(ArrayList<Integer> poly) {
		this.poly = poly;
	}

	public ArrayList<Integer> add(Polynomial p) {
		int length = poly.size() ;
		int plength = p.polysize() ;
		ArrayList<Integer> temp = new ArrayList<>();
		int count = 0;
		if (length < plength) {
			
			for(int i = 0 ; i<length;i++){
				temp.add(poly.get(i)+p.poly.get(i));
				count++;
			}
			for(int i = count ; i<plength;i++){
				temp.add(p.poly.get(i));
			}
		}else if(length>plength){
			for(int i = 0 ; i<plength;i++){
				temp.add(poly.get(i)+p.poly.get(i));
				count++;
			}
			for(int i = count ; i<length;i++){
				temp.add(poly.get(i));
			}
		}
		return temp;
	}

	

	public int polysize() {
		return poly.size();
	}
		

}

public class PolyClass {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		ArrayList<Integer> polya = new ArrayList<>();
		ArrayList<Integer> polyb = new ArrayList<>();
		String line1 = sc.nextLine();
//		System.out.println(line1);
		Scanner scl1 = new Scanner(line1);
		
		String line2 = sc.nextLine();
//		System.out.println(line2);
		Scanner scl2 = new Scanner(line2);
		
		while(scl1.hasNextInt()){
			int n= scl1.nextInt();
			for(int i = 0 ; i < n+1 ; i++){
				polya.add(scl1.nextInt());
			}
		}
		while(scl2.hasNextInt()){
			int n= scl2.nextInt();
			for(int i = 0 ; i < n+1 ; i++){
				polyb.add(scl2.nextInt());
			}
		}
		
//		System.out.println(polya);
//		System.out.println(polyb);
		ArrayList<Integer> polyarev = new ArrayList<>();
		ArrayList<Integer> polybrev = new ArrayList<>();
		for(int i = polya.size()-1;i>=0;i--){
			polyarev.add(polya.get(i));
		}
		for(int i = polyb.size()-1;i>=0;i--){
			polybrev.add(polyb.get(i));
		}
//		System.out.println(polyarev);
//		System.out.println(polybrev);

		Polynomial polya1 = new Polynomial(polyarev);
		Polynomial polyb1 = new Polynomial(polybrev);
		
		ArrayList<Integer> result = polya1.add(polyb1);
		ArrayList<Integer> resultrev = new ArrayList<>();
		for(int i = result.size()-1;i>=0;i--){
			resultrev.add(result.get(i));
		}
		
//		System.out.println(resultrev);
		String resultline = resultrev.toString();
		resultline = resultline.replaceAll("^.|.$","").replace(", "," ");
		System.out.println(resultline);
		sc.close();
		ps.close();
		
	}

}

