
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
	private int[] c;
	private int[] d;
	public Polynomial(int[] c,int [] d) {
		this.c = c;
		this.d = d;
	}
	public void print(PrintStream ps) {
		int n = c.length -1;
		int n1 = d.length -1;
		int t =0;
		if(n==n1) {
			for(int i = n+1, k=0; i>0; i--, k++) {
				c[k]+=d[k];
			}
			while(c[0] == 0) {
				for(int m = 1; m < c.length; m++) {
					c[m-1] = c[m];
				}
				t++;
			}
			for(int j = 0; j <c.length-t;j++) {
				ps.printf("%d", c[j]);
				if(j!=c.length-1)
					ps.print(" ");

			}
		}
		else if(n>n1) {
			for(int i = n1,k=n;i>0; i--,k--) {
				c[k]+=d[i];
			}while(c[0] == 0) {
				for(int m = 1; m < c.length; m++)
					c[m-1] = c[m];
				t++;
			}
			for(int j = 0; j <c.length-t;j++) {

				ps.printf("%d", c[j]);
				if(j!=c.length-1)
					ps.print(" ");

			}
		}
		else if(n<n1) {
			for(int i = n1,k=n;i>0; i--,k--) {
				d[i]+=c[k];
			}while(d[0] == 0) {
					for(int m = 1; m < d.length; m++)
						d[m-1] = d[m];
				}
			for(int j = 0; j <d.length;j++) {
				ps.printf("%d", d[j]);
				if(j!=d.length-1)
					ps.print(" ");
			}
		}

	}

}


public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;

		int a = sc.nextInt();
		int[] cs = new int [a+1];
		for(int i =0; i<a+1; i++){
			cs[i]= sc.nextInt();
		}
		int b = sc.nextInt();
		int[] cs1 = new int [b+1];

		for(int i =0;  i<b+1; i++){
			cs1[i]= sc.nextInt();
		}

		Polynomial p = new Polynomial(cs,cs1);
		p.print(ps);
		sc.close();
	}
}
