import java.io.PrintStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

class Polynomial{
	private int[] c;
	public Polynomial (int[] c) {
		this.c = c;
	}
	public void print(PrintStream ps) {
		int count =0;
		for(int i=0; i<c.length;i++) {
			if(c[i]==0)
				count++;
			else break;
		}
		int []tem = new int[c.length-count];
		tem= Arrays.copyOfRange(c, count, c.length);
		String line = Arrays.toString(tem);
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		
		ps.println();
	}
	void add(Polynomial g) {
		int f_index=0;
		int g_index=0;
		int count=0;
		if(c.length>=g.c.length) {
			g_index=g.c.length-c.length;
			for(;f_index<c.length; f_index++, g_index++) {
				if(g_index>=0)
					c[f_index]=c[f_index]+g.c[g_index];
			}
		}
		else {
			f_index=c.length-g.c.length;
			for(;g_index<g.c.length; f_index++, g_index++) {
				if(f_index>=0) {
					g.c[g_index]=g.c[g_index]+c[f_index];
				}
			}
		}
	}
}
public class LAB9 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int first = sc.nextInt();
		int []one = new int [first+1];
		for(int i=0; i<first+1; i++) {
			one[i]=sc.nextInt();
		}
		int second =sc.nextInt();
		int []two = new int [second+1];
		for(int i=0; i<second+1; i++) {
			two[i]=sc.nextInt();
		}
		Polynomial f = new Polynomial(one);
		Polynomial g = new Polynomial(two);
		f.add(g);
		if(first>=second) {
			f.print(ps);
		}else {g.print(ps);}
		sc.close();
	}
}
