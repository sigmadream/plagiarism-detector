import java.io.PrintStream;
import java.util.Scanner;
import java.util.Arrays;

public class PolyClass {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int a=0;
		int[] test = null;
		a = sc.nextInt();
		test = new int[a + 1];
		
		for(int i=a; i>=0; i--)
		{
			test[i] = sc.nextInt();
		}
		
		int b=0;
		int[] test2 = null;
		b = sc.nextInt();
		test2 = new int[b + 1];
		
		for(int i=b; i>=0; i--)
		{
			test2[i] = sc.nextInt();
		}
		
		/*
		for(int i=a; i>=0; i--)
		{
			ps.printf("%d ", test[i]);
		}
			
		for(int i=b; i>=0; i--)
		{
			ps.printf("%d ", test2[i]);
		}*/
		
		
		if(a == b)
		{
			int[] test3 = new int[a + 1];
			for(int i=a; i>=0; --i){
			test3[i] = test[i] + test2[i];
			if(test3[i] != 0)
			ps.printf("%d ", test3[i]);
			}
		}
		else if(a <= b)
		{
			int[] test3 = new int[b + 1];
			for(int i=b; i>0; --i)
			{
			test3[i] = test[i-1] + test2[i];
			ps.printf("%d ", test3[i]);
			}		
		}
		else
		ps.print("not a possible case!");
		
		sc.close();
	}
}