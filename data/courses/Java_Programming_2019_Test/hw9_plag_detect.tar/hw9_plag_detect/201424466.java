import java.io.PrintStream;
import java.util.*;

class Polynomial {
	private ArrayList<Integer> coef1= new ArrayList<>();
	private ArrayList<Integer> coef2= new ArrayList<>();
	public Polynomial(ArrayList<Integer> a, ArrayList<Integer> b) {
		this.coef1 = a;
		this.coef2 = b;
		ArrayList<Integer> result = new ArrayList<>();
		for(int j=0; j<Math.abs(coef1.size()-coef2.size()); j++){
				result.add(coef2.get(j));
	 	}
	 	for(int i=Math.abs(coef1.size()-coef2.size()); i<coef2.size(); i++){
	 		result.add(coef1.get(i-Math.abs(coef1.size()-coef2.size()))+coef2.get(i));
	 	}
	}
	public void print(ArrayList<Integer> result) {
		PrintStream ps = System.out;
		String line = result.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
		
	}
 }

 public class PolyClass {
	 public static void main(String[] args) {
		 	Scanner sc = new Scanner(System.in);
		 	PrintStream ps = System.out;
		 	int num1 = sc.nextInt();
		 	ArrayList<Integer> pol1 = new ArrayList<>(); 
		 	ArrayList<Integer> pol2 = new ArrayList<>(); 
		 	ArrayList<Integer> result = new ArrayList<>();
		 	
		 	for(int i=0; i<=num1; i++){
		 		pol1.add(sc.nextInt());
		 	}
		 	int num2 = sc.nextInt();
		 	for(int i=0; i<=num2; i++){
		 		pol2.add(sc.nextInt());
		 	}
		 	for(int j=0; j<Math.abs(pol1.size()-pol2.size()); j++){
				result.add(pol2.get(j));
	 	}
	 	for(int i=Math.abs(pol1.size()-pol2.size()); i<pol2.size(); i++){
	 		result.add(pol1.get(i-Math.abs(pol1.size()-pol2.size()))+pol2.get(i));
	 	}
		 	
		 	Polynomial p = new Polynomial(pol1, pol2);
		 	p.print(result);
		 	ps.close();
		 	sc.close();
	 }
 }