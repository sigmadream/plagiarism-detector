import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
	private int[] c;
	public Polynomial(int[] c) {
		this.c = c;
	}
	public void print() {
		PrintStream ps = System.out;
		String line = Arrays.toString(this.c);
		ps.printf(line.replaceAll("^.|.$", "").replace(", ", " "));
	}
	public Polynomial add(Polynomial b) {
		int sz = Math.abs(this.c.length - b.c.length);
		ArrayList<Integer> tmp = new ArrayList<>();
		
		if(this.c.length > b.c.length) {
			for(int i = 0; i < sz; i++)
				tmp.add(this.c[i]);
			for(int i = 0; i < b.c.length; i++)
				tmp.add(this.c[sz+i] + b.c[i]);
		}
		else if(this.c.length < b.c.length) {
			for(int i = 0; i < sz; i++)
				tmp.add(b.c[i]);
			for(int i = 0; i < this.c.length; i++)
				tmp.add(this.c[i] + b.c[sz+i]);
		}
		else {
			for(int i = 0; i < this.c.length; i++)
				tmp.add(this.c[i] + b.c[i]);
		}
		
		while(tmp.get(0) == 0) {
			tmp.remove(0);
		}

		int[] ccsz = new int[tmp.size()];
		for(int i = 0; i < tmp.size(); i++)
			ccsz[i] = tmp.get(i);
		Polynomial temp = new Polynomial(ccsz);
		
		return temp;
	}
}
public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int asz, bsz;
		
		asz = sc.nextInt();
		int[] a = new int[asz+1];
		
		for(int i = 0; i < asz+1; i++)
			a[i] = sc.nextInt();
		
		bsz = sc.nextInt();
		int[] b = new int[bsz+1];
		
		for(int i = 0; i < bsz+1; i++)
			b[i] = sc.nextInt();
		
	
		Polynomial ap = new Polynomial(a);
		Polynomial bp = new Polynomial(b);
		
		(ap.add(bp)).print();
		sc.close();
	}
}