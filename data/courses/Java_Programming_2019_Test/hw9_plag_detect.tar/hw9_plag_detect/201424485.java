import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
	private int[] c;
	public Polynomial(int[] cs) {
		c= cs;
	}
	public void print(PrintStream ps) {
		ps.println(Arrays.toString(c));
//		int n = c.length - 1;
//		for (int i=n, k=0; i>0; i--, k++)
//			ps.printf("%dx^%d + " , c[k], i);
//			
//			
	}
}

public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n= sc.nextInt();
		int[] cs1 = new int[n+1];
		for (int i=0; i<=n; i++) {
			cs1[i] = sc.nextInt();
		}
		int m=sc.nextInt();
		int[] cs2 = new int[m+1];
		for (int i=0; i<=m; i++) {
			cs2[i] = sc.nextInt();
		}
		Polynomial p = new Polynomial(cs1);
 		Polynomial q = new Polynomial(cs2);
// 		p.print(ps);
//		q.print(ps);
		ArrayList<Integer> sum = new ArrayList<>();
		if (cs1.length == cs2.length)
			for (int i=0; i<cs1.length; i++) {
				sum.add(cs1[i]+cs2[i]);
			}
		else if (cs1.length > cs2.length) {
			int k = Math.abs(cs1.length - cs2.length);
			for (int i=0; i<k; i++){
				sum.add(cs1[i+k]+cs2[i]);
			}
		}
		else {
			int k = cs1.length - cs2.length;
			for (int i =0; i<k; i++)
				sum.add(cs1[i]+cs2[k+i]);
			
				
		}
		while (sum.get(0)== 0)
			sum.remove(0);
		String line = sum.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(", ", " "));
				
				
				
		sc.close();
		ps.close();
	}
}
