import java.util.*;
	import java.io.*;

	class Polynomial{
		private int a[];
		public Polynomial(int a[]){
			this.a = a;
		}
		public void print(PrintStream ps){

			for(int i=0;i< a.length;i++)
				ps.printf("%d ",a[i]);
		}
	}
	
	
public class PolyClass {
	
		
	
		static public void main(String args[]){
			Scanner sc= new Scanner(System.in);
			PrintStream ps= System.out;
			int c1 = sc.nextInt();
			int a[] = new int[c1+1];

			for(int i =0;i<=c1; i++){
				int n = sc.nextInt();
				a[i]= n;
			}
			
			int c2 = sc.nextInt();
			int b[] = new int[c2+1];

			for(int i =0;i<=c2; i++){
				
				int n = sc.nextInt();
				b[i]= n;
			}
			
			Polynomial p1 = new Polynomial(a);
			Polynomial p2 = new Polynomial(b);
			
			int max=c1;
			if(c2>=c1)
				max=c2;
			
			
			int result[] = new int[max+1];
			for(int i=0;i<=max;i++){
				result[i]=0;
			}
			Polynomial r = new Polynomial(result);
			
			int minus;
			if(max==c1)
				minus = c1-c2;
			else
				minus = c2-c1;
			
			
			if(c1==c2){
				for(int i=0;i<=c2;i++){
						result[i] = a[i] + b[i];
	
				}
				r.print(ps);
			}
			else
			{
				for(int i=0;i<minus;i++){
					if(max==c1)
						result[i]=a[i];
					else
						
						result[i]=b[i];
				}
				for(int i=0;i<=(max-minus);i++){
					if(minus == c2-c1)
						result[i+minus]=a[i]+b[i+minus];
					if(minus == c1-c2)
						result[i+minus]=b[i]+a[i+minus];
				}
				r.print(ps);
			}
			
		
		}
			
	

}
