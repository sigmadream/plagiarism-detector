import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

class Polynomial {
	private ArrayList<Integer> c;
	public Polynomial(ArrayList<Integer> poly1) {
		this.c = poly1;
	}
	public void print(PrintStream ps) {
		String line = c.toString();
		ps.print(line.replaceAll("^.|.$", "").replace(",", ""));
	}
}
public class PolyClass {
	public static void main(String[] args) {
		ArrayList<Integer> poly1 = new ArrayList<>();
		ArrayList<Integer> poly2 = new ArrayList<>();
		ArrayList<Integer> sum = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int a = sc.nextInt();
		int x = 0;
		for(int i=a; i>=0; i--) {
			poly1.add(sc.nextInt());
		}
		int b = sc.nextInt();
		for(int i=b; i>=0; i--) {
			poly2.add(sc.nextInt());
		}
		if(a<b) {
			for(int i=0; i<b-a; i++) {
				sum.add(poly2.get(i));
			}	
			for(int i=b-a; i<=b; i++) {
				sum.add(poly1.get(i-1)+poly2.get(i));
			}
			Polynomial p = new Polynomial(sum);
			p.print(ps);
		}
		else if(a == b){
			for(int i=0; i<=a; i++) {
				sum.add(poly1.get(i)+poly2.get(i));
			}	
			while(x<=b) {
				if(sum.get(x)==0){
					sum.remove(x);
				}
				else {
					break;
				}
			}
			Polynomial p = new Polynomial(sum);
			p.print(ps);
		}
		else {
			for(int i=0; i<a-b; i++) {
				sum.add(poly1.get(i));
			}	
			for(int i=a-b; i<=a; i++) {
				sum.add(poly1.get(i)+poly2.get(i-1));
			}			
			Polynomial p = new Polynomial(sum);
			p.print(ps);
		}
		sc.close();
	}
}
