import java.io.PrintStream;

import java.util.Scanner;

class Polynomial {
	private int[] c;
	public Polynomial(int[] c) {
		this.c = c;
	}
	public void print(PrintStream ps) {
//		ps.println(Arrays.toString(c));
		int n = c.length-1;
				
		int index = 0;
		for(int k=0;k<n;k++){
			if(c[index]==0){
				index++;
				continue;
			}
			ps.printf("%d ",c[k]);
		}
		ps.println(c[n]);
	}
	public Polynomial add(Polynomial p){
		PrintStream ps = System.out;
		int[] addPoly;
		if(c.length>p.c.length){
			int length = c.length;
			addPoly = new int[c.length];
			int i;
			for(i = 0;i<=length-p.c.length;i++)
				addPoly[i] = c[i];
			i--;
			for(int k = 0;i<length;i++,k++)
				addPoly[i] = c[i]+p.c[k];
			
		}
		else{
			addPoly = new int[p.c.length];
			int length = p.c.length;
			
			addPoly = new int[p.c.length];
			int i;
			for(i = 0;i<=length-c.length;i++){
				addPoly[i] = p.c[i];
				
			}
			i--;
			for(int k=0;i<length;i++,k++){
				addPoly[i] = c[k]+p.c[i];
			}
		}
		
		Polynomial add = new Polynomial(addPoly);
		return add;		
	}
}

public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int deg1 = sc.nextInt();
		int[] coef1 = new int[deg1+1];
		for(int i = 0;i<=deg1;i++)
			coef1[i] = sc.nextInt();
		Polynomial fx = new Polynomial(coef1);
		int deg2 = sc.nextInt();
		int[] coef2 = new int[deg2+1];
		for(int i = 0;i<=deg2;i++)
			coef2[i] = sc.nextInt();
		Polynomial gx = new Polynomial(coef2);
		Polynomial add = fx.add(gx);
		add.print(ps);
		
		sc.close();
	}
}