import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial{
	private int[] c, f;
	public Polynomial(int[] c,int[] f) {
		this.c = c;
		this.f = f;
	}
	public void print(PrintStream ps) {
		ps.println(Arrays.toString(c));
	}
	public void add(int[] c,int[] f)
	{
		ArrayList<Integer> al = new ArrayList<Integer>();
		if(c.length <= f.length)
		{
			int leng = f.length;
			int leng2 = c.length;
			int leng3 = leng2-1;
			int leng4 = leng3;
			int sum=0;
			
			for(int k =leng-1;k>=0; k--)
			{
				sum = c[leng3] + f[k];
				if(sum == 0){}
				else
				{	
					al.add(sum);
				}
				leng3--;
				if(leng3 == 0){break;}
			}
			if(f.length != c.length)
			{
				for(int q=0; q < leng4-1; q++)
				{
					al.add(0);
					al.add(f[q]);
				}
			}
		}
			else
			{
				int leng = c.length;
				int leng2 = f.length;
				int leng3 = leng2-1;
				int leng4 = leng3;
				int sum=0;
				
				for(int k =leng-1;k>=0; k--)
				{
					
					sum = c[k] + f[leng3];
					if(sum == 0){}
					else
					{	
						al.add(sum);
					}
					leng3--;
					if(leng3 == 0){break;}
				}
				if(f.length != c.length)
				{
					for(int q=0; q < leng4-1; q++)
					{
						al.add(0);
						al.add(f[q]);
					}
				}
			}
		
		for(int t = al.size()-1;t>=0;t--)
		{
			if(t==0)
			{
				System.out.printf("%d",al.get(t));
				break;
			}
			System.out.printf("%d ",al.get(t));
		}
		

	}
}

public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int num1 = sc.nextInt();
		int[] cs = new int[num1+1];
		for(int i=0; i< num1+1; i++)
		{
			cs[i] = sc.nextInt();
		}
		int num2 =sc.nextInt();
		int[] cs2 = new int[num2+1];
		for(int j=0; j< num2+1; j++)
		{
			cs2[j] = sc.nextInt();
		}
		Polynomial p = new Polynomial(cs,cs2);
		p.add(cs, cs2);
		
		
		sc.close();
	}
}