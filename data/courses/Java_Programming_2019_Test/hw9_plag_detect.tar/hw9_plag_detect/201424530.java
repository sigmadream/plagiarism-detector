import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
	private int[] c;
	public Polynomial(int[] cs) {
		c = cs;
	}
	public void print(PrintStream ps) {
		ps.println(Arrays.toString(c));
//		int n = c.length -1;
//		for (int i=n, k=0; i>0; i--, k++)
//			ps.printf("%dx^%d + ", c[k], i);
//		ps.println(c[n]);
	}
}

public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int fn = sc.nextInt();
		int[] fcs = new int[fn+1];
		for (int i=0; i<=fn; i++) {
			fcs[i] = sc.nextInt();
		}
		int gn = sc.nextInt();
		int[] gcs = new int [gn+1];
		for (int i=0; i<=gn; i++) {
			gcs[i] = sc.nextInt();
		}
		
		Polynomial f = new Polynomial(fcs);
		Polynomial g = new Polynomial(gcs);
//		f.print(ps);
//		g.print(ps);
		
		ArrayList<Integer> sum = new ArrayList<>();
		if (fcs.length == gcs.length)
			for (int i=0; i<fcs.length; i++) {
				sum.add(fcs[i]+gcs[i]);
			}
		
		else if (fcs.length > gcs.length) {
			int x = Math.abs(fcs.length - gcs.length);
			for (int i=0; i<x; i++)
				sum.add(fcs[i]);
			for (int i=0; i<gcs.length; i++)
				sum.add(fcs[x+i]+gcs[i]);
		}
		else {
			int x = gcs.length - fcs.length;
			for (int i=0; i<x; i++)
				sum.add(gcs[i]);
			for (int i=0; i<fcs.length; i++)
				sum.add(fcs[i]+gcs[x+i]);
		}
		while(sum.get(0) == 0)
			sum.remove(0);
//		for(int i=0; i<sum.size(); i++) {
//			ps.printf("%d ", sum.get(i));
//		}
		String line = sum.toString();
		ps.print(line.replaceAll("^.|.$", ""). replace(", ", " "));
//		String sumLine = sum.toString();
//		ps.println(sumLine);
		ps.close();
		sc.close();
	}
}