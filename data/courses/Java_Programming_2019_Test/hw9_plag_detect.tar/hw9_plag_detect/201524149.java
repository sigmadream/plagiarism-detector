import java.io.PrintStream;
//import java.util.Arrays;
import java.util.Scanner;

class Polynomial {

	private int[] c;

	public Polynomial(int[] cs) {
		c = cs;
	}

	public void print(PrintStream ps, int max) {
		int n = 0;
		for (int i = 1; i < max + 2; i++) {
			if (c[i] == 0)
				;
			else {
				n = i;
				break;
			}
		}
		for (int i = n; i < max + 2; i++) {
			if (i == max + 1)
				ps.printf("%d", c[i]);
			// ps.println(max);
			else
				ps.printf("%d ", c[i]);
		}
	}

}

public class PolyClass {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n1 = sc.nextInt();
		int[] fx = new int[100];
		for (int i = 0; i <= n1; i++) {
			fx[i + 1] = sc.nextInt();
		}
		int n2 = sc.nextInt();
		int[] gx = new int[100];
		for (int i = 0; i <= n2; i++) {
			gx[i + 1] = sc.nextInt();
		}

		int[] cs = new int[100];
		add(n1, fx, n2, gx, cs);

		int max = 0;

		if (n1 >= n2)
			max = n1;
		if (n1 < n2)
			max = n2;
		Polynomial p = new Polynomial(cs);
		p.print(ps, max);
		ps.close();
		sc.close();
	}

	private static void add(int n1, int[] fx, int n2, int[] gx, int[] cs) {
		int k1 = n1;
		int k2 = n2;
		for (int i = 0, j = 0, k = 0; k1 + 1 >= 0 && k2 + 1 >= 0;) {
			if (k1 > k2) {
				cs[k] = fx[i];
				k1--;
				i++;
				k++;
			}
			if (k1 == k2) {
				cs[k] = fx[i] + gx[j];
				k1--;
				k2--;
				i++;
				j++;
				k++;
			}
			if (k1 < k2) {
				cs[k] = gx[j];
				k2--;
				j++;
				k++;
			}

		}
	}
}
