import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class PolyClass {
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 PrintStream ps = System.out;
		 int n1 = sc.nextInt();
		 int[] cs1 = new int[n1+1];
		 for(int i=0; i<=n1; i++)
			 cs1[i]=sc.nextInt();
		 int n2 = sc.nextInt();
		 int[] cs2 = new int[n2+1];
		 for(int i=0; i<=n2; i++)
			 cs2[i]=sc.nextInt();
		 Polynomial p = new Polynomial(cs1,cs2);
		 int[] n=p.add(cs1,cs2);
		
		 String line = Arrays.toString(n); 
		 ps.print(line.replaceAll("^.|.$","").replace(",", " "));
		 
		 ps.close();
		 sc.close();
		}
}


class Polynomial {
	private int[] c1;
	private int[] c2;
	public Polynomial(int[] c1, int[] c2) {
		this.c1=c1;
		this.c2=c2;	
	}
	public int[] add(int[] c1, int[] c2) {
		int[] long_p= new int[100];
		int[] small_p = new int[100];
		if(c1.length > c2.length) {
			long_p= c1;
			small_p=c2;
		}
		else  {
			long_p= c2;
			small_p=c1;
		}
		for(int i=long_p.length-small_p.length,k=0; i<long_p.length; i++,k++) {
			long_p[i]=long_p[i]+small_p[k];
		}
		return long_p ;
	}
}