
import java.io.PrintStream;
import java.util.Scanner;


class Polynomial{
	private int[] a;
	public Polynomial(int[] a){
		this.a=a;
	}
	
	public void print(PrintStream ps){
		//ps.println(Arrays.toString(a));
		
		int n=a.length-1;
		for (int i=n,k=0;i>0;i--,k++){
			ps.printf("%dx^%d + ", a[k],i);
		}
		ps.println(a[n]);
	}
	public int[] add(int[] q){
		int g[]=new int[102];
		if(q[0]<a[0]){
			int degree = q[0]-a[0];
			for (int i=1;i<degree;i++)
				g[i]=q[i];
			for(int i=degree;i<a.length-1;i++){
				g[i]=q[i]+a[i];
			}
		}
		else if(a[0]<q[0]){
			int degree = a[0]-q[0];
			for (int i=1;i<degree;i++)
				g[i]=a[i];
			for(int i=degree;i<q.length-1;i++){
				g[i]=q[i]+a[i];
			}
		}
		else{
			for (int i=1;i<q.length-1;i++)
				g[i]=q[i]+a[i];
		}
		
		
		return q;
	}
	
}




public class Lab {
	public static void main(String[] args)  {
	
	Scanner sc = new Scanner(System.in);
	PrintStream ps = System.out;	
	int[] f = readInts(sc);
	Polynomial p=new Polynomial(f);
	int[] g = readInts(sc);
	p.print(ps);
	p.add(g);
	
	sc.close();
	ps.close();
	
	}

	private static int[] readInts(Scanner sc) {
		int[] a = new int[100];
		int i = 0;
		for (i = 0; sc.hasNextInt(); i++)
		a[i] = sc.nextInt();
		int[] b = new int[i];
		for (int j = 0; j < i; j++)
		b[j] = a[j];
		return b;
	}

}