import java.io.PrintStream;
import java.util.*;

 class Polynomial {
	 private int[] c;
	 public Polynomial(int[] cs) {
		 c = cs;
	 }
	 public void print(PrintStream ps) {
		 int n = c.length -1;
		 for(int i=n, k=0; i>0; i--, k++)
			 ps.printf("%dx^%d + ", c[k], i);
		 ps.println(c[n]);
		 
	 }
 }

 public class PolyClass {
	 public static void main(String[] args) {
		/* List<String> list = new ArrayList<String>();
		 List<String> list2 = new ArrayList<String>();*/


		 Scanner sc = new Scanner(System.in);
		 PrintStream ps = System.out;
		 int[] f = new int[100];
		 int[] g = new int [100];
		 
		 ps.println("First array");
		 for(int i=0;i<10;i++){
			 f[100]=sc.nextInt();}
		 ps.println("Second array");
		 for(int i=0;i<10;i++){
			 g[100]=sc.nextInt();}
		 ps.print(g);
		 ps.print(f);
		 
		 /*ps.println("Enter the polynomial : ");
		 while (sc.hasNextInt()){
         list.add(sc.next());}
		 String[] arr = list.toArray(new String[0]);
	
	     ps.println("Enter the polynomial 2 : ");
	     while (sc.hasNextInt()){
	     list2.add(sc.next());}
	     String[] arr2 = list2.toArray(new String[0]);
	     
		 ps.println("Array 1 is " + Arrays.toString(arr));
		 ps.println("Array 2 is " + Arrays.toString(arr2));*/
		 
		 ps.close();
		 sc.close();
	 }
	 }
 
 
 
