import java.io.PrintStream;
import java.util.Scanner;

class Polynomial {
	private int[] c;
	public Polynomial(int[] c) {
		this.c = c;
	}
	public void print(PrintStream ps) {
		int n=c.length-1;
		int j=0;
		while(c[j]==0){
			j+=1;
		}
		for(int k=j;k<n;k++){
			ps.printf("%d ", c[k]);
		}
		if(c[n]!=0)
			ps.println(c[n]);
		else
			ps.print("0");
	}
	public int[] add(int[] q){
		int n1=q.length-1;
		int n2=c.length-1;
		for(int i=n1;i>=0;i--)
			c[i+n2-n1]+=q[i];
		return c;
	}
}

public class lab05 {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	PrintStream ps = System.out;
	int n1=sc.nextInt();
	int[] cs = new int[n1+1];
	int[] es = new int[100];
	for(int i=0;i<n1+1;i++){
		cs[i]=sc.nextInt();
	}
	int n2=sc.nextInt();
	int[] ds = new int[n2+1];
	for(int i=0;i<n2+1;i++){
		ds[i]=sc.nextInt();
	}
	Polynomial p = new Polynomial(cs);
	Polynomial q = new Polynomial(ds);
	Polynomial r = new Polynomial(es);
	if(n1<n2){
		r=p;
		p=q;
		q=r;
		es=cs;
		cs=ds;
		ds=es;
	}
	p.add(ds);
	p.print(ps);
	sc.close();
	}
}