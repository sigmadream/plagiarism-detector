import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
 private int[] c;
 public Polynomial(int[] c) {
 this.c = c;
 }
 public void print(int[] k) {
	 PrintStream ps=System.out;
	 int n=k.length-1;
	 int a=0;
	 for(int i=n; i>0; i--) {
		 if(k[i]!=0 && a==0) {
			 a=1;
			 ps.printf("%d ", k[i]);
		 }
		 else if(k[i] != 0 || a==1) {
			 ps.printf("%d ", k[i]);
		 }

	 }
	 ps.printf("%d", k[0]);
 }
 public int[] add(int[] g) {
	 int a=c.length-1;
	 int b=g.length-1;
	 int[] k= new int[(a>b?a:b)+1];
	 if(a>=b) {
		 for(int i=a; i>b; i--) {
			 k[i]=c[i];
		 }
		 for(int i=b; i>=0; i--) {
			 k[i]=c[i]+g[i];
		 }
	 }
	 if(b>=a) {
		 for(int i=b; i>a; i--) {
			 k[i]=g[i];
		 }
		 for(int i=a; i>=0; i--) {
			 k[i]=c[i]+g[i];
		 }
	 }
	 return k;
 }
}


public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n1=sc.nextInt();
		int[] p1 = new int[n1+1];
		for(int i=n1; i>=0; i--) {
			p1[i]=sc.nextInt();
		}
		int n2=sc.nextInt();
		int[] p2 = new int[n2+1];
		for(int i=n2; i>=0; i--) {
			p2[i]=sc.nextInt();
		}
		Polynomial p=new Polynomial(p1);
		p.print(p.add(p2));
		
		
	}

}
