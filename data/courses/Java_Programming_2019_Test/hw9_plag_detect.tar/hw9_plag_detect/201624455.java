import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
	private int [] c;
	public Polynomial (int[]c) {
		this.c = c;
	}
	public void print(PrintStream ps) {
		ps.println(Arrays.toString(c));
	}
}
public class ex {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in) ;
		PrintStream ps = System.out;
		int[] = 
		Polynomial p = new Polynomial (cs);
		p.print(ps);
		sc.close();
	}

}
