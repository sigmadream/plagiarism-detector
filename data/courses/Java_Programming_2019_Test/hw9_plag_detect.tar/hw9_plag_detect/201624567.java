import java.io.PrintStream;
import java.util.Scanner;

class Polynomial {
	private int[] c;
	public Polynomial(int[] c) {
		this.c = c;
	}
	public void print(int []p) {
		PrintStream ps = System.out;
		int n = p.length-1;
		int k = 0;
		
		for(int i = n; i>0; i--) {
			if(p[i]!=0 && k == 0) {
				k = 1;
				ps.printf("%d ",p[i]);
			}
			else if(p[i] != 0 || k ==1) {
				ps.printf("%d ",p[i]);
			}
		}
		ps.printf("%d",p[0]);

	}
	public int[] add(int[] d) {
		
		int n = c.length-1;
		int m = d.length-1;
		int a = n>m?n:m;
		int[] k = new int[a+1];
		if(n>=m) {
			
			
			for(int i = n; i > m; i--) {
				k[i]=c[i];
			}
			for(int i = m; i >= 0; i--) {
				k[i]=c[i]+d[i];
			}
			
		}
		if(n<m) {
			for(int i = m; i > n; i--) {
				k[i]=d[i];
			}
			for(int i = n; i >= 0; i--) {
				k[i]=d[i]+c[i];
			}
			
		}
		
			
		return k;
	}
}

public class PolyClass {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		
		int n = sc.nextInt();
		int[] f = new int[n+1];
		
		for(int i = n ; i >= 0; i--) {
			f[i]=sc.nextInt();
		}
		
		int m = sc.nextInt();
		int[] g = new int[m+1];
		
		for(int i = m ; i >= 0; i--) {
			g[i]=sc.nextInt();
		}
		
		Polynomial p = new Polynomial(f);
		p.print(p.add(g));
		
		
		
		ps.close();
		sc.close();
	}
}
