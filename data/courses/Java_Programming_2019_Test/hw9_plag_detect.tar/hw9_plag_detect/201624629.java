import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

//class Polynomial {
//    private int[] c;
//    public Polynomial(int[] c) {
//        this.c = c;
//    }
//    public void print(PrintStream ps) {
//        ps.println(Arrays.toString(c));
//    }
//    public void add(Polynomial p) {
//    	    this.c = 
//    }
//}

//Polynomial fxp = new Polynomial(fx);
//Polynomial gxp = new Polynomial(gx);
//fxp.print(ps);
//gxp.print(ps);

public class PolyClass {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PrintStream ps = System.out;
        int sum;
        
        ArrayList<Integer> fx = new ArrayList<>();
        ArrayList<Integer> gx = new ArrayList<>();
        
//        while(sc.hasNextInt()){
//            fx.add(sc.nextInt());
//        }
//        
//        while(sc.hasNextInt()){
//            gx.add(sc.nextInt());
//        }
//        
        fx.add(3);
        fx.add(6);
        fx.add(5);
        
        gx.add(1);
        gx.add(-3);
        gx.add(-3);
        gx.add(2);
        
        while (gx.size() > fx.size()) {
        		fx.add(0, 0);
        }
        
        ps.println(fx);
        ps.println(gx);
        
        ArrayList<Integer> p = new ArrayList<>();
        

        for (int i = 1; i < gx.size(); i++) {
        		sum = fx.get(i) + gx.get(i);
        		p.add(sum);
        }
        
        
        ps.println(p);
        

        sc.close();
    }
}














