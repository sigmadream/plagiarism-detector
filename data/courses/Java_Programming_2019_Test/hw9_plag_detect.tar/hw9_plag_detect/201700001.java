import java.util.Scanner;

class Polynomial {
    private int[] f;

    public Polynomial(int[] f) {
        this.f = f;
    }

    public int[] add(int[] g) {

        int[] higher = f.length > g.length ? f : g;
        int[] lower = f.length < g.length ? f : g;
        if (f.length == g.length) {
            higher = f;
            lower = g;
        }

        int diff = Math.abs(f.length - g.length);
        int[] sum = new int[higher.length];

        for (int i = 0; i < diff; i++)
            sum[i] = higher[i];

        for (int i = diff; i < higher.length; i++)
            sum[i] = higher[i] + lower[i - diff];

        return sum;
    }
}

public class PolyClass {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int fLength = sc.nextInt();
        int[] pol1 = new int[fLength + 1];
        for (int i = 0; i < pol1.length; i++)
            pol1[i] = sc.nextInt();
        int gLength = sc.nextInt();
        int[] pol2 = new int[gLength + 1];
        for (int i = 0; i < pol2.length; i++)
            pol2[i] = sc.nextInt();

        Polynomial f = new Polynomial(pol1);
        int[] sum = f.add(pol2);
        int notZero = 0;
        for (int i = 0; i < sum.length; i++) {
            if (sum[i] == 0) {
                continue;
            }
            else {
                notZero = i;
                break;
            }
        }
        for (int i = notZero; i < sum.length - 1; i++)
            System.out.print(sum[i] + " ");
        System.out.print(sum[sum.length - 1]);
    }
}
