import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

class Polynomial {
	private int[] c;
	public Polynomial(int[] cs) {
		c = cs;
	}
	public void print(PrintStream ps) {
		//ps.println(Arrays.toString(c));
		int n = 0;
		while (c[n] == 0)
				n++;
		for (int i = n; i<c.length; i++)
			if (i == c.length-1)
				ps.printf("%d", c[i]);
			else ps.printf("%d ", c[i]);
		//ps.println();
	}
	public void add(Polynomial c2) {
		PrintStream ps = System.out;
		int n = c2.c.length-1;
		for (int i = 0, k = c.length-c2.c.length ; i<=n; i++, k++)
			c[k]= c[k] + c2.c[i]; 
//			ps.printf("%d %d", k, i);
//			ps.println(Arrays.toString(c));
		
	}
}

public class PolyClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PrintStream ps = System.out;
		int n = sc.nextInt();
		int poly1[] = new int[n+1];
		for (int i=0; i<n+1; i++)
			poly1[i]=sc.nextInt();
		Polynomial p1 = new Polynomial(poly1);

		n = sc.nextInt();
		int poly2[] = new int[n+1];
		for (int i=0; i<n+1; i++)
			poly2[i]=sc.nextInt();
		Polynomial p2 = new Polynomial(poly2);

		if (poly1.length>poly2.length){
			p1.add(p2);
			p1.print(ps);
		}
		else {
			p2.add(p1);
			p2.print(ps);
		}
		
		sc.close();
	}
}