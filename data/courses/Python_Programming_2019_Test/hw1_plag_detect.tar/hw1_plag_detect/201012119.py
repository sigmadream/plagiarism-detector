# -*- coding: utf-8 -*-

n1 = int(input())

n2 = int(input())

s = n1+n2

p = n1*n2


if(n1>n2):
   print(n1)
if(n2>n1):
  print(n2)





