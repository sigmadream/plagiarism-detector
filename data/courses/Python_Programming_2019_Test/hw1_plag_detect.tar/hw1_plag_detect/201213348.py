n1 = int(input())
n2 = int(input())
if n1*n2>n2+n1:
    print(n1*n2)
else:
    print(n1+n2)
