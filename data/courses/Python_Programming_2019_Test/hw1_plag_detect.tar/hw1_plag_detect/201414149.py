a = int(input())
b = int(input())

c = a + b
d = a * b

##print(a, " is a")
##print(b, " is b")
##print(a + b, "is a + b value")
##print(a * b, "is a * b value")
if c > d :
    print(c)
if c < d :
    print(d)
