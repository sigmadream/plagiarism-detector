# -*- coding: utf-8 -*-

n1 = int(input())
n2 = int(input())

s = n1 + n2
p = n1 * n2

if s < p:
    output = p
if p <= s:
    output = s


print(output)
