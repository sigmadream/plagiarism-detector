a=int(input())
b=int(input())
c=a+b
d=a*b

if c>d:
    print(c)

if c<d:
    print(d)

if c==d:
    print(c)
