# -*- coding: utf-8 -*-

inputNum1 = int(input())
inputNum2 = int(input())

sum = inputNum1 + inputNum2
product = inputNum1 * inputNum2

if sum > product:
    print(sum)
else: print(product)
