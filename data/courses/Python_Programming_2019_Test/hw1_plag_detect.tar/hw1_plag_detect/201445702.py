# -*- coding: utf-8 -*-
# The above line is not mandatory. It is just for Korean characters.

a = int(input())
b = int(input())
s = a + b
p = a * b

if s > p :
    print(s)

if p > s :
    print(p)
