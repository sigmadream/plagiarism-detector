# -*- coding: utf-8 -*-

n1 = int(input())
n2 = int(input())
s = n1 + n2
p = n1 * n2
if s >= p:
    print(s)
if p > s:
    print(p)
