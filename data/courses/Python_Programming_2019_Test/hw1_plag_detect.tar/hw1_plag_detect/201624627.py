a=int(input())
b=int(input())
c=a+b
d=a*b
if c>d:
    print(c)
elif c<d:
    print(d)
