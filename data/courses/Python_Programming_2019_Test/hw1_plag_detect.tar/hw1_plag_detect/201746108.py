# -*- coding: utf-8 -*-
a = int(input())
b = int(input())
if (a+b)> a*b :
    print(a+b)
else :
    print(a*b)


