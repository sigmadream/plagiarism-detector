# -*- coding: utf-8 -*-
#Lab 01: Sum or Product
#201812162 최창환

n1=int(input())
n2=int(input())
print(max(n1+n2,n1*n2))
