
a = int(input())
b = int(input())

s = a + b
p = a * b

if s > p :
    print(s)
if p > s :
    print(p)
