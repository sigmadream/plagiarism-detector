# -*- coding: utf-8 -*-

a = int(input())
b = int(input())
c = int(a+b)
d = int(a*b)

if c > d:
    print(c)
if c < d:
    print(d)
