# -*- coding: utf-8 -*-
# The above line is not mandatory. It is just for Korean characters.


n1 = int(input())
n2 = int(input())

c = n1 + n2
d = n1 * n2

if c>d:
    print(c)
else :
    print(d) 
