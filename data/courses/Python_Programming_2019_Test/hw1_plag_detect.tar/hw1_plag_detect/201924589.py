# -*- coding: utf-8 -*-




a = int(input())
b = int(input())


c = (a+b)
d = (a*b)

if c > d :
    print(c)

else:
    print(d)


