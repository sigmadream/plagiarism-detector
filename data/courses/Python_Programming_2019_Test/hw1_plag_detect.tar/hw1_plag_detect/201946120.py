# -*- coding: utf-8 -*-
# The above line is not mandatory. It is just for Korean characters.

a = int(input())
b = int(input())

if (a + b) > (a * b):
    print (a + b)

if (a + b) < (a * b):
    print (a * b)
