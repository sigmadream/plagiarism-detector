def repeat1(c,n):
    s = c * n
    print(s+"+")

def repeat2(c,n):
    s = c * n
    print(s+"|")

n = int(input())
height = n
while(height != 0):
    repeat1("+---",n)
    repeat2("|   ",n)
    height = height-1
repeat1("+---",n)
