def repeat(n):
    
        print("+---"*n,end="+\n")
        print("|   "*n,end="|\n")
      

def board(n):
    m = n
    while m>0:
        repeat(n)
        m=m-1
    
    print("+---"*n,end="+\n") 
n=int(input())
board(n)
