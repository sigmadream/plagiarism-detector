def width(c, n):
    s=c*n
    print(s, end='+\n')

def height(c, n):
    s=c*n
    print(s, end='|\n')


def board(n):
    rep = n
    while rep>0:
        width("+---",n)
        height("|   ",n)
        rep=rep-1
        
    width("+---",n)

        
n=int(input())
##
##width("+---", n)
##height("|   ", n)
board(n)
