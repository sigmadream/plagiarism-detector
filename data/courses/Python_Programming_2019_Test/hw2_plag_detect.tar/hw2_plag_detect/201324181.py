def repeat(c,n):
    s=c*n
    print(s)
    
def board(n):
    a=n
    while a>0:
        print('+', end='')
        repeat('---+',n)
        print('|', end='')
        repeat('   |',n)
        a=a-1
    print('+', end='')
    repeat('---+',n)
    
n=int(input())
board(n)
n=int(input())
board(n)
