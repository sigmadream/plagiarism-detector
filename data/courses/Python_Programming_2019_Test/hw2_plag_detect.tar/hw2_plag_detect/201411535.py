def repeat(n):
    print("+---" * n, end = "+")
    print()
    print("|   " * n, end = "|")
    print()

n = int(input())
for i in range(n):
    repeat(n)
print("+---" * n, end = "+")
