def Romeo(N):
    a = '+---'*N + '+\n'
    b = '|   '*N + '|\n'
    c = '+---'*N + '+'
    s = N*(a + b) + c
    print(s)


N = int(input())

Romeo(N)
