
def wide(n):

    c0 = "+"+"-"*3+"+"
    cn = 3*"-"+"+"

    c=c0+cn*n
    print(c)

def long(n):
    c0 = "|   |"
    cn = "   |"

    c=c0+cn*n
    print(c)

def board(n):
    if(n>0 and n<100):
        for i in range(n):
            wide(n-1)
            long(n-1)
        wide(n-1)

N = int(input())
board(N)
