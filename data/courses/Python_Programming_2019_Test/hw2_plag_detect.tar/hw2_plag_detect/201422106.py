def repeat1(c, n):
    print("+",end="")
    s = c * n
    print(s)


def repeat2(c, n):
    print("|",end="")
    s = c * n
    print(s)
   
   
    

n=int(input())

i=n*2+1     

while i>0:
    if i%2==0:
        repeat2("   |",n)
    else:
        repeat1("---+",n)

    i=i-1
