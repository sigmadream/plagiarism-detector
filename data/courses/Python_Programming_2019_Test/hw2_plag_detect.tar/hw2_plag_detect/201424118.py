N = int(input())
n = N
while n:
    print('+---+'+ '---+'* (N-1))
    print('|   |'+ '   |'* (N-1))
    n = n -1
print('+---+'+ '---+'* (N-1))







