def repeat(n):
    a = '+---' * n + '+\n'
    b = '|   ' * n + '|\n'
    c = (a+b)*n + a
    print(c,end="")

n = int(input())
repeat(n)

