def repeat(c, n):
    s =  c * n
    print(s,end="")



n= int(input())

def row(n):
    print("+",end="")
    repeat("---+",n)
    print()

def col(n):
    print("|",end="")
    repeat("   |",n)
    print()

rep = n
while rep > 0:
    row(n)
    col(n)
    rep = rep-1
row(n)
