def repeat(c,n):
    s = c*n
    print(s,end="")
    


n = int(input())
for i in range(0,n):
    repeat('+---',n)
    print('+')        
    repeat('|   ',n)
    print('|')
repeat('+---',n)
print('+')

        


