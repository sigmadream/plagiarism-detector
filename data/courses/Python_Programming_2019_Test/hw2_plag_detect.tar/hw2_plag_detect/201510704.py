def repeat(n):
    i=n
    while i>0:
        print("+---"*n+"+")
        print( "|   "*n+"|")
        i=i-1
    print("+---"*n+"+")

n=int(input())
repeat(n)
