def repeat(c,n):
    s = c * n
    print(s,end="")

def print_row(N):
    print("+",end="")
    repeat("---+",N)
    print()

def print_col(N):
    print("|",end="")
    repeat("   |",N)
    print()

def draw_block(N):
    rep = N
    while rep>0:
        print_row(N)
        print_col(N)
        rep = rep-1
    print_row(N)

N = int(input())

draw_block(N)
