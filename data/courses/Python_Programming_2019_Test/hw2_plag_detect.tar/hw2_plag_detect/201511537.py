def col(n):
    print('|', end="")
    print ("   |" * n)
    print('+', end="")
    print ("---+" * n)

i=0
n=int(input())

print('+', end="")
print ("---+" * n)

while (i<n):
    col(n)
    i=i+1

