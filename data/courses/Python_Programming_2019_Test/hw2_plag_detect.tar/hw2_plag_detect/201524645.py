def board(n):
    n=int(input())
    i=1
    while(i<=2*n+1):
        if i%2!=0:
            print("+---"*n,end="")
            print("+")
        else:
            print("|   "*n,end="")
            print("|")
        i=i+1

board(2)
