#printing boards


def board(n):
    frame="+---+"
    print(frame*n)

def board2(n):
    frame="|   |"
    print(frame*n)

def board3(n):
    frame='+---+'
    print(frame*n)


print("enter integer n(please enter 3)")
n=int(input())
if(n<0):
    print("fail")
    


board(n)
board2(n)
board3(n)
board(n)
board2(n)
board3(n)
board(n)
board2(n)
board3(n)
#sorry
