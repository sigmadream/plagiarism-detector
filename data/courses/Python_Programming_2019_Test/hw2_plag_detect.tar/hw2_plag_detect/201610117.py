N = int(input())

a = "---+" * N
b = "   |" * N
print("+",end="")    
print(a)
print("|",end="")
print(b)
print("+", end="")
print(a)

K=N-1
while K>0:
      print("|",end="")
      print(b)
      print("+", end="")
      print(a)
      K=K-1
      


