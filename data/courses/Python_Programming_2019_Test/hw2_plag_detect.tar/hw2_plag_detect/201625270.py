# -*- coding utf-8 -*-
    
def repeatwidth(n):
    s =  "+---" * n
    print(s, end="")
    print("+")

def repeatheight(n):
    s = "|   " * n
    print(s, end="")
    print("|")

def printslots(n):
    repeatwidth(n)
    repeatheight(n)
    
n = int(input())

i = 0

while n!= 0:
    printslots(n)
    i = i + 1
    if i >= n:
        repeatwidth(n)
        break;
