def repeat(n):
    s = "---+" * n
    print('+' + s)
    for i in range(0, n):
        if n>0:
            c = "   |" * n
            print("|" + c)
            s = "---+" * n
            print('+' + s)

n = int(input())
repeat(n)
