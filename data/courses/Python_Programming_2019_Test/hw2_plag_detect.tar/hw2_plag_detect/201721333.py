def board(n):
    i=1
    n=int(input())
    while(i<=2*n+1):
        b=1
        if(i%2!=0):
            print("+",end="")
            print("---+"*n)
        else:
            print("|",end="")
            print("   |"*n)
        i=i+1

board(2)
board(3)
