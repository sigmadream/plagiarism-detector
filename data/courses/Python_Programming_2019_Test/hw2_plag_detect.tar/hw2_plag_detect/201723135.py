def repeat(c,a):
    while a>0:
        print(c)
        a = a-1

N = int(input())

repeat("+---"*N + "+\n"+"|   "*N + "|", N)
print("+---"*N + "+")

     








