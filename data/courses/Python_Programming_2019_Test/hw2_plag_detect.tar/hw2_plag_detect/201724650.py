##def repeat (c,n):
##    s = c *n
##    print(s)
##
##
##n = int(input())
##repeat('*', n)
##repeat('$', n)


def board (n) :
     if (n > 0 & n < 100) :
        s = 0
        while n > s : 
            i = 0;
            while (i < n):
                print("+---", end = "")
                i = i + 1
            if (i == n) :
                print("+")
            b = 0
            while (b < n):
                print("|   ", end = "")
                b = b + 1
            if (b == n) :
                print("|")
            i = 0     
            s = s + 1
        while (i < n):
                print("+---", end = "")
                i = i + 1
        if (i == n) :
                print("+")

x = int(input())
board(x)
