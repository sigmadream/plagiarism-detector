def board(N):
    a = '+---'*N + '+\n'
    b = '|   '*N + '|\n'
    c = '+---'*N + '+'
    s = (a + b)*N + c
    print(s)

N = int(input())
board(N)
