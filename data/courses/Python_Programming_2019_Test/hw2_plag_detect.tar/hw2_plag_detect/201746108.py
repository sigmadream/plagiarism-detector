def repeat1(c,d,n):
            i = 0
            s = c*n+"+"
            t = d*n +"|"       
            while i<n :
                print(s)
                print(t)
                i = i+1        
            print(s)
n = int(input())
repeat1('+---','|   ',n) 
