def repeat(c,d,n):
           i=1
           s="+"+c*n
           a="|"+d*n
           while i<n+1 :
               print(s)
               print(a)
               i=i+1
           print(s)

n=int(input())

repeat('---+','   |',n)

