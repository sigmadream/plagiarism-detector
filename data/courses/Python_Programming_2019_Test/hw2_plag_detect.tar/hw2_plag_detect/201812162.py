def board(N):
    s=lambda x:"|"+"   |"*N if x%2 else "+"+"---+"*N
    res=""
    for i in range(0,2*N+1):
        #print(s(i))
        res+=s(i)+"\n"
    print(res, end="")
    return
N=int(input())
board(N)
