def repeat(c,n):
    s = c * n
    print(s, end="")

n = int(input())
if n > 0 and n<100:
    m = n
    while(n > 0) :
        repeat("+---",m)
        print("+")
        repeat("|   ",m)
        print("|")
        n = n - 1
    repeat("+---",m)
    print("+")

