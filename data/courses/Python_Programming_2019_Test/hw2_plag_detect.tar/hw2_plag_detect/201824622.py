def repeat(c, n):
    s=c*n
    print(s)

n=int(input())
i=n
while i>0:
    print('+', end='')
    repeat('---+', n)
    print('|', end='')
    repeat('   |', n)
    i=i-1
print('+', end='')
repeat('---+', n)
    

