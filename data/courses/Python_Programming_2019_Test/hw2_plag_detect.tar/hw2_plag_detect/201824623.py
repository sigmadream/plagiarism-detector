def repeat(s,i):
    k =  s * i
    print(k, end="")

while True:
    n = int(input())
    m = n
    if 0<n<100:
        while n>0:
            repeat('+---', m)
            print('+')
            repeat('|   ', m)
            print('|')
            n = n-1
        repeat('+---', m)
        print('+')
            

