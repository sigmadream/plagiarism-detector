def repeat(c, n):
    s = c * n
    print(s, end="")
    
n = int(input())
a = n

if n > 0 and n < 100 :
    while a > 0:
        repeat('+---', n)
        print("+")
        repeat('|   ', n)
        print("|")
        a = a - 1
    repeat("+---", n)
    print("+")
