def create_block(n):
    garo = "+---"
    sero = "|   "    
    print(garo*n, end = "+")
    print()
    print(sero*n, end = "|")
    print()

def create_board(n):
    a = n
    garo = "+---"
    while a > 0:
        create_block(n)
        a = a-1
    print(garo*n, end = "+")

n = int(input())
create_board(n)
