def board(N):
    a = '+---'*N + '+\n'
    b = '|   '*N + '|\n'
    s = (a + b)*N + a
    print(s,end="")

N = int(input())
board(N)