#coding: utf-8

n = int(input())

def board(n):
    for i in range(n):
        print(line(n))
        print(slot(n))
    print(line(n))

def line(n):
    return mix('+','---',n)

def slot(n):
    return mix('|','   ',n)

def mix(sep, mid, n):
    return (sep+mid)*n+sep

board(n)
