def repeat(c,n):
    s = c*n
    print(s,end ="")

n = int(input())
i = 0
while i<n:
    repeat('+---',n)
    print('+')
    repeat('|   ',n)
    print('|')
    i+=1
repeat('+---',n)
print('+')
