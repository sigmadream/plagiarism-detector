

def repeat(str,times):
    
    out = str * times
    print( out )

def board_make(Dec):

    loop = 0
    
    while(loop < Dec):

        print('+',  end = '')
        repeat('---+',  Dec )
        
        print('|',  end = '')
        repeat('   |',  Dec )
        
        loop = loop + 1

    print('+', end = '')
    repeat('---+', Dec )


inp = int(input())

board_make(inp)
