def repeat(c, n):
    s = c * n
    print(s)

    

n = int(input())


def board(n):
    i =0

    while (i < n) :
        print('+', end = '')
        repeat('---+',n)

        print('|', end = '')
        repeat('   |',n)
    
    
        i= i+1
    
    print('+', end = '')
    repeat('---+',n)

    

board(n)
