# -*- coding: utf-8 -*2

def changeNumber(string):
    returnNum = 0
    for i in range(0,len(string)-1):
        if(string[i]<string[i+1]):
            returnNum -= changeCharacterNum(string[i])
        elif(string[i]>string[i+1]):
            returnNum += changeCharacterNum(string[i])
    returnNum += changeCharacterNum(string[len(string)-1])
    return returnNum


def changeCharacterNum(character):
    returnNum = 0
    if(character == "I"):
                returnNum = 1
    elif(character == "V"):
                returnNum = 5
    elif(character == "X"):
                returnNum = 10
    elif(character == "L"):
                returnNum = 50
    elif(character == "C"):
                returnNum = 100
    elif(character == "D"):
                returnNum = 500
    elif(character == "M"):    
                returnNum = 1000
    return returnNum            
                
if __name__ == "__main__":
    myword = input()
    number = 0
    number = changeNumber(myword)
    print("%X" %number)

    
