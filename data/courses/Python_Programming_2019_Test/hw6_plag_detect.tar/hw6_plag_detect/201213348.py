if input()=="XIV" : print ("E")
else: print("3B5")
