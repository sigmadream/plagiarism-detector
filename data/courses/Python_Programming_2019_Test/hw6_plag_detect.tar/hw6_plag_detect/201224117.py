s=input("Roman Number Pls: ")
r=len(s)
I=1
V=5
X=10
L=50
C=100
D=500
M=1000
def convert(s):
    s1=s[0]
    s2=s[1]
    return

def romansum(s):
    while r1>1:
        if s1>=s2:
            s=s1+s2
        else:
            s=s1-s2
        r1=r-1
    return

def romancount(n,r):
    if n==r:
        pass
    else:
        romansum(s)
        romancount(n+1,r)

if __name__ == "__main__":
    convert(s)
    romancount(s,r)

##romancount(s,r)에서 r이 정의되지않았다는데 

    
##if len(s)==1:
##    ans=s
##elif len(s)>1:
##    if s[n]>=s[n+1]:
##        ans=s[n]+s[n+1]
##    else:
##        ans=s[n+1]-s[n]
##else:
##    pass
##print(ans)
##s길이를 대강 n으로 던진건데 인식을 못해서 실패.
