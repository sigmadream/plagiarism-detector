def star(n):
if n <= 0:
print()
else:
print("*", end="")
star(n-1)
if __name__ == "__main__":
while True:
n = int(input("Enter the size: "))
if n < 0: break
star(n)
