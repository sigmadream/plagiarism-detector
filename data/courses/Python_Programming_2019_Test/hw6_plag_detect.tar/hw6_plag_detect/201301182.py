def romtodec(s):
    num=[]
    for i in range(len(s)):
        if s[i] == 'I':
            num.append(1)
        elif s[i] == 'V':
            num.append(5)
        elif s[i] == 'X':
            num.append(10)
        elif s[i] =='L':
            num.append(50)
        elif s[i] =='C':
            num.append(100)
        elif s[i] =='D':
            num.append(500)
        elif s[i]=='M':
            num.append(1000)

    for i in range(len(num)):
        if i==len(num)-1:
            break
        if num[i]< num[i+1]:
            num[i]=-1*num[i]
        else:
            pass

    dec=0
    for i in range(len(num)):
        dec=dec+num[i]
    return dec

def dectohex(n):
    if n<16:
        return str(n)
    else:
        return dectohex(n//16)+dectohex(n%16)


if __name__ == "__main__":
    s=input()
    dec=romtodec(s)
    print("%X" % dec)





