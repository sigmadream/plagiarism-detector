def rn(c):
    return {'I' : '1',
            'V' : '5',
            'X' : '10',
            'L' : '50',
            'C' : '100',
            'D' : '500',
            'M' : '1000'}[c]

def rn2dec(s):
    ls = list(s)
    if len(ls) == 1:       
            return int(rn(s))
    else :
        if int(rn(ls[0])) < int(rn(ls[1])):
            return -1*int(rn(ls[0])) + rn2dec("".join(ls[1:len(ls)]))
        else :
            return int(rn(ls[0])) + rn2dec("".join(ls[1:len(ls)]))                               
        

def dec2hex(n):
    if n < 16 :
        return str({10 : 'A',
                11 : 'B',
                12 : 'C',
                13 : 'D',
                14 : 'E',
                15 : 'F'}.get(n, n))
    else :
        return dec2hex(n//16) + dec2hex(n%16)




if __name__=="__main__":
    s = input()
    print(dec2hex(rn2dec(s)))
