def transform_roman_numeral_to_number(roman_numeral):
    roman_char_dict = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    res = 0
    for i in range(0, len(roman_numeral)):
        if i == 0 or roman_char_dict[roman_numeral[i]] <= roman_char_dict[roman_numeral[i - 1]]:
            res += roman_char_dict[roman_numeral[i]]
        else:
            res += roman_char_dict[roman_numeral[i]] - 2 * roman_char_dict[roman_numeral[i - 1]]
    return res
 

def conv(number,base):
  T="0123456789ABCDEF"
  i,j=divmod(number,base)
 
  if i==0:
    return T[j]
  else:
    return conv(i,base)+T[j]



if __name__=="__main__":
    roman_numeral_input = input()
    number_output = transform_roman_numeral_to_number(roman_numeral_input)
    myNumber=[number_output]
    for n in myNumber:
        print(conv(n,16))


