
def remove(substr, str):
    index = 0
    length = len(substr)
    
    index = str.find(substr)
    str = str[0:index] + str[index+length:]
    return str

def rom_to_10(s,result=0):
    while len(s) > 0:
        if 'CM' in s:
            result+=900
            s = remove('CM',s)
        elif 'CD' in s:
            result+=400
            s = remove('CD',s)
        elif 'XC' in s:
            result+=90
            s = remove('XC',s)
        elif 'XL' in s:
            result+=40
            s = remove('XL',s)
        elif 'IX' in s:
            result+=9
            s = remove('IX',s)
        elif 'IV' in s:
            result+=4
            s = remove('IV',s)
            
        elif 'M' in s:
            result+=1000
            s = remove('M',s)
        elif 'D' in s:
            result+=500
            s = remove('D',s)
        elif 'C' in s:
            result+=100
            s = remove('C',s)
        elif 'L' in s:
            result+=50
            s = remove('L',s)
        elif 'X' in s:
            result+=10
            s = remove('X',s)
        elif 'V' in s:
            result+=5
            s = remove('V',s)
        elif 'I' in s:
            result+=1
            s = remove('I',s)
    return result



def dec2any(n, r):
    if n < r:
        result = str(n)
        if str(n) == '10':
            result = 'A'
        elif str(n) == '11':
            result = 'B'
        elif str(n) == '12':
            result = 'C'
        elif str(n) == '13':
            result = 'D'
        elif str(n) == '14':
            result = 'E'
        elif str(n) == '15':
            result = 'F'
        return result
    else:
        return dec2any(n//r, r) + dec2any(n%r, r)
    
if __name__ == "__main__":

    s = input()
    n = rom_to_10(s)
    result=dec2any(n,16)
    print(result)
