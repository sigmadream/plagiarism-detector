

def Roman(a):
    b = list(a)
    if len(a) == 0 :
        return 0
    if len(a) > 1 :
        if (b[0] == 'I'and b[1] == 'V'):
            return 4 + Roman(a[2:])
        elif (b[0] == 'I'and b[1] == 'X'):
            return 9 + Roman(a[2:])
        elif (b[0] == 'X'and b[1] == 'L'):
            return 40 + Roman(a[2:])
        elif (b[0] == 'X'and b[1] == 'C'):
            return 90 + Roman(a[2:])
        elif (b[0] == 'C'and b[1] == 'D'):
            return 400 + Roman(a[2:])
        elif (b[0] == 'C'and b[1] == 'M'):
            return 900 + Roman(a[2:])
        elif b[0] == 'I':
            return 1 + Roman(a[1:])
        elif b[0] == 'V':
            return 5 + Roman(a[1:])
        elif b[0] == 'X':
            return 10 + Roman(a[1:])
        elif b[0] == 'L':
            return 50 + Roman(a[1:])
        elif b[0] == 'C':
            return 100 + Roman(a[1:])
        elif b[0] == 'D':
            return 500 + Roman(a[1:])
        elif b[0] == 'M':
            return 1000 + Roman(a[1:])
    
    elif b[0] == 'I':
        return 1 + Roman(a[1:])
    elif b[0] == 'V':
        return 5 + Roman(a[1:])
    elif b[0] == 'X':
        return 10 + Roman(a[1:])
    elif b[0] == 'L':
        return 50 + Roman(a[1:])
    elif b[0] == 'C':
        return 100 + Roman(a[1:])
    elif b[0] == 'D':
        return 500 + Roman(a[1:])
    elif b[0] == 'M':
        return 1000 + Roman(a[1:])
    

if __name__ == '__main__':
    a = input().upper()
    print("%X" % Roman(a))
