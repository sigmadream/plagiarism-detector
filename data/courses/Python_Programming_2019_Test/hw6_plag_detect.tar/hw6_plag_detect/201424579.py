def roman_to_int(s):
    roman_value = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    value_sum = 0
    
    for i in range(len(s)):
        if i > 0 and roman_value[s[i]] > roman_value[s[i - 1]]:
            value_sum += roman_value[s[i]] - 2 * roman_value[s[i - 1]]
        else:
            value_sum += roman_value[s[i]]
    return dec2hex(value_sum, 16)

def dec2hex(n, base):
    T = "0123456789ABCDEF"
    q, r = divmod(n, base)
    if q == 0:
        return T[r]
    else:
        return dec2hex(q, base) + T[r]


if __name__=="__main__":
    n = input()
    print(roman_to_int(n))
    
