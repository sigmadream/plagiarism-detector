def rom(n):
    if n == 'I':
        return 1
    elif n == 'V':
        return 5
    elif n == 'X':
        return 10
    elif n == 'L':
        return 50
    elif n == 'C':
        return 100
    elif n == 'D':
        return 500
    elif n == 'M':
        return 1000
    else:
        return 0

    

n = input()
n1 = list(n)
n = []
for i in range(len(n1)):
    n.append(0)
#print(n)
for l in range(0,len(n1)):
    n[l] = rom(n1[l])

#print(n)


for k in range(0,len(n1)):
    if k == len(n1)-1:
        break
    if n[k] < n[k+1]:
        n[k] = -n[k]
sum = 0
for O in range(0,len(n1)):
    sum += n[O]
#print(sum)
#print(hex(sum))
list2 = hex(sum)
print(list2[2:].upper())


