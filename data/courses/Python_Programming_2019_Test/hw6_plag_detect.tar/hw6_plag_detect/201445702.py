n = input()

def rnum(n):
    
    num = { "I":1, "V":5, "X":10, "L":50, "C":100, "D":500, "M":1000 }
    sum = 0
    for s in range(0, len(str(n))-1):
        if num[n[s]] >= num[n[s+1]]:
            sum += int(num[n[s]])
        else:
            sum -= int(num[n[s]])
            
    final = sum + num[n[len(n)-1]]
    h = hex(rnum(final))
    print("%X" % h)   

if __name__ == "__main__":
    rnum(n)
