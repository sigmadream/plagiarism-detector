def nList(a):
    for i in range(len(a)):
        if a[i]=='I':
            a[i]=1
        elif a[i]=='V':
            a[i]=5
        elif a[i]=='X':
            a[i]=10
        elif a[i]=='L':
            a[i]=50
        elif a[i]=='C':
            a[i]=100
        elif a[i]=='D':
            a[i]= 500
        elif a[i]=='M':
            a[i]=1000


def plus(a):
    leng=len(a)
    sum=0
    for i in range(leng-1):
        if a[i]>a[i+1]:
           sum+= a[i]
        elif a[i]<a[i+1]:
            sum-=a[i]
        else:
            sum+=a[i]
    sum+=a[-1]
    print("%X"%sum)


if __name__=="__main__":
    a=input()
    a=list(a)
    nList(a)
    plus(a)
    
