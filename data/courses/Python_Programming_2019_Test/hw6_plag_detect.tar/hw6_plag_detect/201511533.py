def romanN(r):
    if r=='I':
        return 1
    elif r=='V':
        return 5
    elif r=='X':
        return 10
    elif r=='L':
        return 50
    elif r=='C':
        return 100
    elif r=='D':
        return 500
    elif r=='M':
        return 1000

def hexnum(n):
    if n<10:
        return str(n)
    elif n==10:
        return 'A'
    elif n==11:
        return 'B'
    elif n==12:
        return 'C'
    elif n==13:
        return 'D'
    elif n==14:
        return 'E'
    else:
        return 'F'

def dec2hex(d):
    if d<=0:
        return ""
    else:
        h = ""
        h += hexnum(d%16)
        h = dec2hex(d//16) + h
        return h

def roman2dec(r):
    d = 0
    n = len(r)
    rsft = r[1:n]
    for i in range(n-1):
        if romanN(r[i])<romanN(rsft[i]):
            d -= romanN(r[i])
        else:
            d += romanN(r[i])
    d += romanN(r[n-1])
    return d

if __name__=='__main__':
    r = input()
    rom = roman2dec(r)
    h = dec2hex(rom)
    print(h)
