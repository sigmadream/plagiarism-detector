def print_value(v):
    
    if v=='X':
        value = 10
    elif v=='I':
        value = 1
    elif v=='V':
        value = 5
    elif v=='C':
        value = 100
    elif v=='M':
        value = 1000
    elif v=='L':
        value = 50
    elif v=='C':
        value = 100
    return value

def plus(i,s,V):
    if i < len(s)-1:
        if print_value(s[i]) > print_value(s[i+1]):
            V += print_value(s[i])
        else:
            V -= print_value(s[i])
        plus(i+1,s,V)
    else:
        print("V = %d" %V)
        V += print_value(s[i])
        print("V = %d" %V)
        return V

def main():
    s = input()
    V = 0
    V = plus(0,s,V)
    print("%d" %V)

if __name__ =="__main__":
    main()
