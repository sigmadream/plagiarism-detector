def roman(a):
 for k in range(0,len(ls)):
   if k==len(ls)-1:
       ls1[k] = int(ls[k])
   elif int(ls[k])==int(ls[k+1]):
       ls1[k] = int(ls[k])
   elif int(ls[k])>int(ls[k+1]):
       ls1[k] = int(ls[k])
   else:
       ls1[k] = -int(ls[k])








if __name__ == "__main__":
   a = input().replace("I","1 ")
   b = a.replace("V","5 ")
   c=b.replace("X","10 ")
   d=c.replace("L","50 ")
   e=d.replace("C","100 ")
   f=e.replace("D", "500 ")
   e1=f.replace("M", "1000 ")
   
   ls = e1.split()
   ls1 = [0] * len(ls)
   roman(a)
   de = sum(ls1)
   print("%X" % de)
