def rnum (n) :
    roman = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    
    t = list(n)
    num = 0
    for i in range(len(t)-1) :
        if ( "IVXLCDMF".find(t[i]) < "IVXLCDMF".find(t[i+1]) ) :
            num += roman[t[i]] * (-1)
        else :
            num += roman[t[i]]
    s =num + roman[t[len(t)-1]]
    print( "%X" % s)
        
    
    




if __name__ == "__main__" :
     n= input() ;
     rnum(n)
