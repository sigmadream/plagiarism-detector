
def word(s):


print("%X" %word)


if __name__ == "__main__":
    word = input()

