def star(n):
 if n <= 0:
     print()
 else:
     print("*", end="")
     star(n-1)

if __name__ == "__main__":
     while True:
         n = input()
         if n < 0: break
         star(n)
