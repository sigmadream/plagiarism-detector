def romanN(st):
    if st == "I":
        return 1
    elif st == "V":
        return 5
    elif st == "X":
        return 10
    elif st == "L":
        return 50
    elif st == "C":
        return 100
    elif st == "D":
        return 500
    elif st == "M":
        return 1000

def countRomanN(rstr):
    ls = list(rstr)
    number = 0
    for st in ls:
        #if st == "I":
        number += romanN(st)
    print(number)
    return number

def printhex(rstr):
    number = countRomanN(rstr)
    print(hexdec(number))

def hexdec(rstr):
    hexstr =""
    while rstr >= 0:
        if rstr < 10:
            hexstr += str(rstr)
            rstr = rstr - 16
        elif rstr < 16:
            ihex = rstr - 10
            if ihex == 0:
                hexstr += "A"
            elif ihex == 1:
                hexstr += "B"
            elif ihex == 2:
                hexstr += "C"
            elif ihex == 3:
                hexstr += "D"
            elif ihex == 4:
                hexstr += "E"
            elif ihex == 5:
                hexstr += "F"
            rstr = rstr - 16
    return hexstr

def main():
    printhex(input())

if __name__=="__main__":
    main()
