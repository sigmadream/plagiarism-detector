def trans_dec(n):
    roman_dict = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    result = 0
    for i in range(0, len(n)):
        if i == 0 or roman_dict[n[i]] <= roman_dict[n[i - 1]]:
            result = result + roman_dict[n[i]]      #recursive
        else:
            result = result + roman_dict[n[i]] - 2 * roman_dict[n[i - 1]]   #recursive
    return result

if __name__ == "__main__":
    n = input()
    dec = trans_dec(n)
    print("{0:X}".format(dec))
