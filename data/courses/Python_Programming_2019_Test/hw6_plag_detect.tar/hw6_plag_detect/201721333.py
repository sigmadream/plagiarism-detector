def rom2dec(c):
    s=c.split()
    ss=len(s)

    n=0

    i=0
    while(i!=ss-1):
        if (s[i]<s[i+1]):
            n-=asf(s[i])
        else:
            n+=asf(s[i])
        i+=1

    return n+asf(s[ss-1])

def asf(s):
    if (s=="D"):
        return 500
    elif(s=="C"):
        return 100
    elif(s=="L"):
        return 50
    elif(s=="X"):
        return 10
    elif(s=="V"):
        return 5
    elif(s=="I"):
        return 1
    else:
        return 0


def dec2hex(s):
    if int(s)<10:
        return s
    elif int(s)==10:
        return "A"
    elif int(s)==11:
        return "B"
    elif int(s)==12:
        return "C"
    elif int(s)==13:
        return "D"
    elif int(s)==14:
        return "E"
    elif int(s)==15:
        return "F"
    else:
        return dec2hex(s//16)+dec2any(s%16)


def main():
    s=input()
    print("%X"%rom2dec(s))


if __name__=="__main__":
    main()
