def rom2dec(s):
    if len(s) == 0:
        return 0
    elif len(s) == 1:
        if s == 'I':
            return 1
        elif s == 'V':
            return 5
        elif s == 'X':
            return 10
        elif s == 'L':
            return 50
        elif s == 'C':
            return 100
        elif s == 'D':
            return 500
        elif s == 'M':
            return 1000

    elif rom2dec(s[-1]) > rom2dec(s[-2]):
        return rom2dec(s[0:-2]) - rom2dec(s[-2]) + rom2dec(s[-1])

    else:
        return rom2dec(s[0:-1]) + rom2dec(s[-1])
   
def dec2hexa(n):
    if n < 10:
        return str(n)
    elif n < 16:
        return chr(n+55)
    else:
        return dec2hexa(n//16) + dec2hexa(n%16)

def rnum():
    rn = input()
    D = rom2dec(rn)
    H = dec2hexa(D)
    print(H)

    
if __name__ == "__main__":
    rnum()






    ## I = 1
    ## V = 5
    ## X = 10
    ## L = 50
    ## C = 100
    ## D = 500
    ## M = 1000
