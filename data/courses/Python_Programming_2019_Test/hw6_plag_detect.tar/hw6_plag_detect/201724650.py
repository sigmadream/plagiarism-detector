def r2Dec(roman):
    result = ""
    if len(roman) < 0 :
        return ""
    else :
        for i in range(len(roman)):
            if roman[i] == 'I' :
                result += "1 "
            elif roman[i] == 'V' :
                result += "5 "
            elif roman[i] == 'X' :
                result += "10 "
            elif roman[i] == 'L' :
                result += "50 "
            elif roman[i] == 'C' :
                result += "100 "
            elif roman[i] == 'C' :
                result += "100 "
            else :
                result += ""
    
    return result.split(" ")

def str2Dec(dec) :
    result = 0
    for i in range(len(dec) - 1) :
        if (dec[i] >= dec[i + 1]) :
            result += int(dec[i])
        else :
            result -= int(dec[i])
    return result + int(dec[len(dec)-1])

##    if len(dec) == 1 :
##        return result
##    else:
##        if str2Dec(dec[1 : len(dec)]) >= int(dec[0]) :
####            print(dec[0], end= " + ")
####            print(str2Dec(dec[1 : len(dec)]))
##            return result + int(dec[0])
##        else :
####            print(dec[0], end= " - ")
####            print(str2Dec(dec[1 : len(dec)]))
##            return result  - int(dec[0])
    

def mf(x) :
    result = str2Dec(r2Dec(x)[0:len(r2Dec(x)) - 1])          
    print("%X" %result)

if __name__ == "__main__" :
    a = input()
    mf(a)
    #%X 16진수
