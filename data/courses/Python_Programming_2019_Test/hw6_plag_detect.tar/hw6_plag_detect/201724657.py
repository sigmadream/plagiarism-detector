def roman(r_str):
    rstr = list(r_str)
    s = len(r_str)
    n = [0]*s
    while True:
        if(s == 0):
            break
        elif(rstr[s-1] == "I"):
            n[s-1] = 1
        elif(rstr[s-1] == "V"):
            n[s-1] = 5
        elif(rstr[s-1] == "X"):
            n[s-1] = 10
        elif(rstr[s-1] == "L"):
            n[s-1] = 50
        elif(rstr[s-1] == "C"):
            n[s-1] = 100
        elif(rstr[s-1] == "D"):
            n[s-1] = 500
        elif(rstr[s-1] == "M"):
            n[s-1] = 1000
        else:
            print("Wrong roman number")
        s = s - 1
    return n

def calc(fn,n,s):
    if(s > 1):
        if(n[s-1] > n[s-2]):
            n[s-2] = n[s-1] - n[s-2]
        elif(n[s-1] < n[s-2]):
            n[s-2] = n[s-1] + n[s-2]
        elif(n[s-1] == n[s-2]):
            fn = fn + n[s-2]

    if(s <= 2):
        fn = n[0]+fn
        print("%X"%fn)
    else:
        calc(fn,n,s-1)    


if __name__=="__main__":
    r_str = input()
    s = len(r_str)
    n = roman(r_str)
    fn = 0
    calc(fn,n,s)
    
