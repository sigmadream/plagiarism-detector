rnum={'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000}

def rom2dec_nrcsv(rstr):
    n=rnum[rstr[-1]]
    for i in range(len(rstr)-1,0,-1):
        cn=rnum[rstr[i]]
        nn=rnum[rstr[i-1]]
        if cn <= nn:
            n+=nn
        elif cn > nn:
            n-=nn
    return n

def rom2dec(rstr):
    if len(rstr)==1:
        return rnum[rstr[0]]
    else:
        n=rom2dec(rstr[1:])
        nn=rnum[rstr[0]]
        cn=rnum[rstr[1]]
        if cn<=nn:
            return n+nn
        elif cn>nn:
            return n-nn
        else:
            return -1

def main():
    rstr=input()
    print(hex(rom2dec(rstr))[2:].upper())
    return 0

if __name__=="__main__":
    main()
