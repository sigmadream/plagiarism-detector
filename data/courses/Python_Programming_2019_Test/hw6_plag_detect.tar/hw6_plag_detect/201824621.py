def rom2dec(strrom):
    romV = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    intV = 0
    for i in range(len(strrom)):
        if i > 0 and romV[strrom[i]] > romV[strrom[i-1]]:
            intV += romV[strrom[i]] - 2 * romV[strrom[i-1]]
        else:
            intV += romV[strrom[i]]
    return(intV)

if __name__ == "__main__":
    n = input()
    n = rom2dec(n)
    print("%X" % n)
