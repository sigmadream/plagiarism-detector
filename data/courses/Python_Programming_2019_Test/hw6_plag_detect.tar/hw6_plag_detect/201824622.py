def l2d(s):
    if s=='I':
        return 1
    elif s=='V':
        return 5
    elif s=='X':
        return 10
    elif s=='L':
        return 50
    elif s=='C':
        return 100
    elif s=='D':
        return 500
    elif s=='M':
        return 1000


def rom2dec(ls):
    if len(ls)==1:
        return l2d(ls[0])
    elif len(ls)==0:
        return 0
    else:
        if l2d(ls[0])>=l2d(ls[1]):
            a=l2d(ls[0])
            ls.pop(0)
            return a+rom2dec(ls)
        else:
            b=l2d(ls[1])-l2d(ls[0])
            ls.pop(0)
            ls.pop(0)
            return b+rom2dec(ls)          
        
def main():
    ls=list(input())
    n=rom2dec(ls)
    print("%X" % n)

if __name__=='__main__':
    main()
