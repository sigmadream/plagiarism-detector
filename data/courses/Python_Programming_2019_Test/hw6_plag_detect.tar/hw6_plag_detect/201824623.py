def value(r):
    if (r == 'I'):
        return 1
    if (r == 'V'):
        return 5
    if (r == 'X'):
        return 10
    if (r == 'L'):
        return 50
    if (r == 'C'):
        return 100
    if (r == 'D'):
        return 500
    if (r == 'M'):
        return 1000
    
def main():
    rv = 0
    v = input()
    i=0
    while (i<len(v)):
        v1 = value(v[i])
        if (i+1<len(v)):
            v2 = value(v[i+1])
            if (v1>=v2):
                rv=rv+v1 
                i= i+1
            else:
                rv=rv+v2-v1 
                i=i+2
        else: 
            rv=rv+v1 
            i=i+1
   
    print("%X" % rv)
    
if __name__ == "__main__":
        main()
