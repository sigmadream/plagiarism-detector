#I = 1, V = 5, X = 10, L = 50, C = 100, D = 500, M = 1000

def rom2dec(s):
    if (len(s) == 0):
        return 0
    elif (len(s) > 1):
        if ((s[0] == 'I') and (s[1] == 'V')):
            return 4+rom2dec(s[2:])
        elif ((s[0] == 'I') and (s[1] == 'X')):
            return 9+rom2dec(s[2:])
        elif ((s[0] == 'X') and (s[1] == 'L')):
            return 40+rom2dec(s[2:])
        elif ((s[0] == 'X') and (s[1] == 'C')):
            return 90+rom2dec(s[2:])
        elif ((s[0] == 'C') and (s[1] == 'D')):
            return 400+rom2dec(s[2:])
        elif ((s[0] == 'C') and (s[1] == 'M')):
            return 900+rom2dec(s[2:])
        elif (s[0] == 'I'):
            return 1+rom2dec(s[1:])
        elif (s[0] == 'V'):
            return 5+rom2dec(s[1:])
        elif (s[0] == 'X'):
            return 10+rom2dec(s[1:])
        elif (s[0] == 'L'):
            return 50+rom2dec(s[1:])
        elif (s[0] == 'C'):
            return 100+rom2dec(s[1:])
        elif (s[0] == 'D'):
            return 500+rom2dec(s[1:])
        else:
            return 1000+rom2dec(s[1:])
    else:
        if (s[0] == 'I'):
            return 1+rom2dec(s[1:])
        elif (s[0] == 'V'):
            return 5+rom2dec(s[1:])
        elif (s[0] == 'X'):
            return 10+rom2dec(s[1:])
        elif (s[0] == 'L'):
            return 50+rom2dec(s[1:])
        elif (s[0] == 'C'):
            return 100+rom2dec(s[1:])
        elif (s[0] == 'D'):
            return 500+rom2dec(s[1:])
        else:
            return 1000+rom2dec(s[1:])

if __name__ == "__main__":
    a = input().upper()
    b = rom2dec(a)
    print("%X" % b)
    
