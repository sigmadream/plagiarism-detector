#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Lucky-CHO
#
# Created:     24-04-2019
# Copyright:   (c) Lucky-CHO 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------



def roman2dec(inn):
    rodict = {"I":1, "V":5, "X":10, "L":50, "C":100, "D":500, "M":1000}
    countlist = []
    countlist2 = []

    for i in inn:
        #print( rodict[i] )
        countlist.append(rodict[i])


    for q in range(len(inn)-1):
        countlist2.append(rodict[ inn[ q+1 ]])

    #print(countlist)
    #print(countlist2)
    allsum = 0
    for i in range(len(countlist2)):
        if countlist[i] < countlist2[i]:
            allsum = allsum - countlist[i]
        else:
            allsum = allsum + countlist[i]
    allsum += countlist[-1]
    #print (allsum)
    return allsum


def hexa(n):
    if n < 10 :
        return str(n)
    if n == 10:
        return "A"

    if n == 11:
        return "B"

    if n == 12:
        return "c"

    if n == 13:
        return "D"

    if n == 14:
        return "E"

    if n == 15:
        return "F"




def dec2hex(n):
    if n < 16:
        return str(n)
    else:
        return dec2hex(n//16) + hexa( int( dec2hex(n%16) ))

def main():
    mymy  = input()

    print("%X"%roman2dec(mymy))



if __name__ == '__main__':
    main()









