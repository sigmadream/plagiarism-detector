def romm(s):
    rodict = {"I":1, "V":5, "X":10, "L":50, "C":100, "D":500, "M":1000}
    rom1 = []
    rom2 = []


    for i in s:
        rom1.append(rodict[i])
    for q in range(len(s)-1):
        rom2.append(rodict[s[q+1]])


    fff = 0

    for i in range (len(rom2)):
        if rom1[i] < rom2[i]:
            fff = fff - rom1[i]
        else:
            fff = fff + rom1[i]

    fff = fff + rom1[-1]
    return fff

m = input()
print("%X"%romm(m))
    







