

def star(args, n):
    n = n
    global value
    if args[n]=='I':
        if args[n+1]=='I':
            value+=2
            n+=1
        elif args[n+1]=='V':
            value+=4
            n+=1
        elif args[n+2]=='X':
            value+=9
            n+=1
        else:
            value+=1
    elif args[n]=='V':
        if args[n+1]=='I':
            value+=6
            n+=1
        else:
            value+=5

    elif args[n] == 'X':
        if args[n+1]=='X':
            value+=20
            n+=1
        elif args[n + 1] == 'L':
            value+=40
            n+=1
        elif args[n + 1] == 'C':
            value+=90
            n+=1
        else:
            value+=10


    elif args[n] == 'L':
        if args[n+1]=='X':
            value+=60
            n+=1
        else:
            value+=50

    elif args[n] == 'C':
        if args[n+1]=='C':
            value+=200
            n+=1
        elif args[n + 1] == 'D':
            value+=400
            n+=1
        elif args[n + 1] == 'M':
            value+=900
            n+=1
        else:
            value+=100

    elif args[n] == 'D':
        if args[n+1]=='C':
            value+=600
            n+=1
        else:
            value+=500

    elif args[n] == 'M':
        if args[n+1]=='M':
            value+=2000
            n+=1

        else:
            value+=1000

    if(n==len(charList)):
        return value
    else:
        star(charList, n)


if "__main__" == __name__:
    charList = list(input())
    value=0
"""
    for i in range(len(charList)):
        if charList[i]=='I':
            x.setdefault('I',1)
        elif charList[i] == 'V':
            x.setdefault('V', 5)
        elif charList[i] == 'X':
            x.setdefault('X', 10)
        elif charList[i] == 'L':
            x.setdefault('L', 50)
        elif charList[i] == 'C':
            x.setdefault('C', 100)
        elif charList[i] == 'D':
            x.setdefault('D', 500)
        elif charList[i] == 'M':
            x.setdefault('M', 1000)
"""
result = star(charList,0)

print(result)