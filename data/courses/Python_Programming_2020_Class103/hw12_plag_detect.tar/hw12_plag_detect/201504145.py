def roman(s):
    roma = {'V': 5, 'X': 10,'I': 1,'L': 50,'C': 100, 'D': 500, 'M': 1000}
    int = 0
    for i in range(len(s)):
        if i > 0 and roma[s[i]] > roma[s[i - 1]]:
            int += roma[s[i]] - 2 * roma[s[i - 1]]
        else:
            int += roma[s[i]]
    return int


a=roman(input())
print(a)