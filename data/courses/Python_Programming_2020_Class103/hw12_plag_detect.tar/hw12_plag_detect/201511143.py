numbers = {
        "I" : 1,
        "IV" : 4,
        "V" : 5,
        "IX" : 9,
        "X" : 10,
        "XL" : 40,
        "L" : 50,
        "XC" : 90,
        "C" : 100,
        "CD" : 400,
        "D" : 500,
        "CM" : 900,
        "M" : 1000,
    }
def rnum(s: str) -> int:
        if not s:
            return 0
        if numbers.get(s[:2]):
            return numbers.get(s[:2]) + rnum(s[2:])
        return  numbers.get(s[:1]) + rnum(s[1:])


roman = input("")
print(rnum(roman))
