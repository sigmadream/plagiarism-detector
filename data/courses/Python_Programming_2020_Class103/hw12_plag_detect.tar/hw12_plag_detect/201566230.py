def romans(c):
    if (c == 'I'): 
        return 1
    if (c == 'V'): 
        return 5
    if (c == 'X'): 
        return 10
    if (c == 'L'): 
        return 50
    if (c == 'C'): 
        return 100
    if (c == 'D'): 
        return 500
    if (c == 'M'): 
        return 1000
    return 0


def dec(s):
    if len(s) == 1:
        return romans(s[0])
    else:
        n = romans(s[0])
        m = romans(s[1])
        
        '''recursion'''
        
        if n >= m:
            return dec(s[1:]) + n
        else:
            return dec(s[1:]) - n
        

if __name__ == "__main__":
    while True:
        words = input()
        if len(words)<=0 : break
        result = dec(words)
        print(result)
