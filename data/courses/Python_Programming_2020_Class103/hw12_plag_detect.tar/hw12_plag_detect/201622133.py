def roman_to_dec(s):
        r_val = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
        d_val = 0
        for i in range(len(s)):
            if i != 0 and r_val[s[i]] > r_val[s[i - 1]]:
                d_val = d_val + r_val[s[i]] - 2 * r_val[s[i - 1]]
            else:
                d_val = d_val + r_val[s[i]]
        return d_val

def main():
    s = input()
    print(roman_to_dec(s))

if __name__ == "__main__":
    main()
    
