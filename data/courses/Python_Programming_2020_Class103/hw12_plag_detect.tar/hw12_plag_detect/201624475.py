# coding: euc-kr

def roman_to_dec(str1):
    
    nums = {'F':5000, 'M':1000, 'D':500, 'C':100, 'L':50, 'X':10, 'V':5, 'I':1}
    sumnum = 0

    for i in range(len(str1))
        

if __name__ == "__main__":

    roman = str(input())
    roman_to_dec(roman)
    
