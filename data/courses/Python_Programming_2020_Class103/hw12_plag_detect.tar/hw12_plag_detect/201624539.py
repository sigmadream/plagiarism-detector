RomanNum = {'I': 1, 'V': 5, 'X': 10, 'L' :50, 'C' : 100, 'D' : 500, 'M' : 1000}


def RomanRecursion(RomanNumber,i,n,Sum):
    if i == n:
        return Sum
    if i==0 or RomanNum[RomanNumber[i]] <= RomanNum[RomanNumber[i-1]]:
        Sum += RomanNum[RomanNumber[i]]
    else:
        Sum += RomanNum[RomanNumber[i]] - 2*RomanNum[RomanNumber[i-1]]
    return RomanRecursion(RomanNumber, i+1 ,n ,Sum)


def getRomanNumber():
    RomanNum = input()
    return RomanNum
        
if __name__ == "__main__":
    result = 0
    RomanNumber = getRomanNumber()
    length = len(RomanNumber)

    if length == 1:
        print(RomanNum[RomanNumber])
    else:
        result = RomanRecursion(RomanNumber, 0, length, 0)

    print(result)
