roman = {'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000}

def roman_to_dec(data,index,current_num):
    if len(data)<=index:
        return current_num
    else:
        if index+1 < len(data) and roman[data[index]] < roman[data[index+1]] :
            current_num-=roman[data[index]]
        else:
            current_num+=roman[data[index]]
        return roman_to_dec(data,index+1,current_num)

if __name__ == "__main__":
    data = input()
    result = roman_to_dec(data,0,0)
    print(result)