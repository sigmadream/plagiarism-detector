def conversion(romnum):
    value = {
        'M': 1000,
        'CM': 900,
        'D': 500,
        'CD':400,
        'C': 100,
        'XC': 90,
        'L': 50,
        'XL': 40,
        'X': 10,
        'IX': 9,
        'V': 5,
        'IV': 4,
        'I': 1
    }

    pos = 0
    answer = 0

    n = len(romnum)
    for i in range(n-1, -1, -1):
        if value[romnum[i]] >= pos:
            answer += value[romnum[i]]
        else:
            answer -= value[romnum[i]]
        pos = value[romnum[i]]
    print(answer)

if __name__ == "__main__":
    roman = input()
    conversion(roman)
