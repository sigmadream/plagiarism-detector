#coding :utf-8

def ch(sl):
    re=0
    for a in sl:
        if len(a)==2:
            f=cal(a[0])
            s=cal(a[1])
            if(f<s):
                res=s-f
            else:
                res=s+f
        else:
            res=0
            res=cal(a)
        re+=res
    print(re)

def cal(c):
    if c in "X":
        c=10
    elif c in "C":
        c=1000
    elif c in "M":
        c=100
    elif c in "L":
        c=50
    elif c in "V":
        c=5
    elif c in "D":
        c=500
    else:
        c=1
    return c



def sps(s):
    sl=[]
    a=len(s)
    if a%2==0:
        n=0
        while(n<a-1):
            sl.append(s[n:n+2])
            n+=2
    else:
        sl.append(s[0])
        n=1
        while(n<a-1):
            sl.append(s[n:n+2])
            n=n+2
    return sl


if __name__ == "__main__":
    s= input()
    a=sps(s)
    ch(a)
    
