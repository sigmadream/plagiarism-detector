def transf(ro):
    romadict = { 'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000,'F':5000}
    intr = 0
    for i in range(0, len(ro)):
        if i==0 :
            intr = romadict[ro[i]]
        elif romadict[ro[i]] <= romadict[ro[i - 1]]:
            intr += romadict[ro[i]]
        else:
            intr += romadict[ro[i]] - 2 * romadict[ro[i - 1]]
            
    return intr

if __name__ == "__main__" :
    
    s = str(input())

    n = transf(s)

    print(n)

