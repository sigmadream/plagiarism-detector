roman_numerals = {'I':1, 'V':5, 'X':10, 'L':50, 'C':100, 'D':500, 'M':1000}

def convert_roman_string(rnum):
    dnum = []
    for i in rnum:
        dnum.append(roman_numerals[i])

    return dnum

def cal_decimal(dnum, index, pvalue, decimal):
    if index >= len(dnum):
        print(decimal)
        return

    if dnum[index] >= pvalue:
        decimal += dnum[index]
    else:
        decimal -= dnum[index]

    pvalue = dnum[index]
    cal_decimal(dnum, index+1, pvalue, decimal)


def main():
    rnum = input()
    dnum = convert_roman_string(rnum)
    dnum.reverse()

    cal_decimal(dnum, 0, 0, 0)


if __name__ == '__main__':
    main()
