def roman(s):
    r_num = {"I":1, "V":5, "X":10, "L":50, "C": 100,
    "D":500, "M":1000, "IV":4, "IX":9, "XL":40, "XC" :90, "CD":400, "CM":900}
    check = False
    num = 0
    for i, ch in enumerate(s):
        if check:
            check = False
            continue
        if i < len(s)-1:
            if ch == 'I':
                next_ch = s[i+1]
                if next_ch == 'V':
                    num+=4
                    check = True
                    continue
                elif next_ch == 'X':
                    num+=9
                    check = True
                    continue

            if ch == 'X':
                next_ch = s[i+1]
                if next_ch == 'L':
                    num +=40
                    check = True
                    continue
                elif next_ch == 'C':
                    num+= 90
                    check = True
                    continue
            
            if ch== 'C':
                next_ch = s[i+1]
                if next_ch == 'D':
                    num += 400
                    check = True
                    continue
                elif next_ch == 'M':
                    num += 900
                    check = True
                    continue
        num += r_num[ch]
    return num

if __name__ == "__main__":
    s = input()
    b = roman(s.upper())
    print(b)    