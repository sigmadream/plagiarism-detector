
def rnum_to_int(n):
    if n == 'I':
        return 1
    if n == 'V':
        return 5
    if n == 'X':
        return 10
    if n == 'L':
        return 50
    if n == 'C':
        return 100
    if n == 'D':
        return 500
    if n == 'M':
        return 1000
    return 0

def input_to_int(a):
    if len(a) == 1:
        return rnum_to_int(a[0])
    else:
        b = rnum_to_int(a[0])
        c = rnum_to_int(a[1])
        if b >= c:
            return input_to_int(a[1:]) + b
        else:
            return input_to_int(a[1:]) - b

if __name__ == "__main__":
   a = input()
   d = input_to_int(a)
   print(d)
