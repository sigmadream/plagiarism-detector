def rnum(s):
    table = {'I' : 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000, 'IV' : 4, 'IX' : 9, 'XL' : 40, 'XC' : 90, 'CD' : 400, 'CM' : 900, 'MF' : 4000}
    if not s:
        return 0
    
    if table.get(s[:2]):
        return table.get(s[:2]) + rnum(s[2:])
    elif table.get(s[:1]):
        return table.get(s[:1]) + rnum(s[1:])
    else:
        return table.get(s[:0]) + rnum(s[0:])


if __name__ == "__main__":
    string = input()
    print(rnum(string))
