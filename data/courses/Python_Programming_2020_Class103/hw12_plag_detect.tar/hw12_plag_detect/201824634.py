def roman_to_int(num):
    num = num.upper()
    ro_int = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    res = 0
    for i in range(0, len(num)):
        if i == 0 or ro_int[num[i]] <= ro_int[num[i - 1]]:
            res += ro_int[num[i]]
        else:
            res += ro_int[num[i]] - 2 * ro_int[num[i - 1]]
    return res
if __name__ == "__main__":
    roman = input()
    print(roman_to_int(roman))
