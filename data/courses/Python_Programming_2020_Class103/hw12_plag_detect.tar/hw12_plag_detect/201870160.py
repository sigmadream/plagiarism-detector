#coding: utf-8

def l2d(c):
    dict={'I': 1,'V': 5,'X': 10,'L': 50,'C': 100,'D': 500,'M': 1000}
    return dict[c]

def rome2int(str):
    if(len(str)==1):
        return l2d(str)
    symbols=list(str)
    if(l2d(symbols[0])>=l2d(symbols[1])):
        return l2d(symbols[0])+rome2int(str[1:])
    elif(len(str)>2):
        return -l2d(symbols[0])+l2d(symbols[1])+rome2int(str[2:])
    elif(len(str)==2):
        return -l2d(symbols[0])+l2d(symbols[1])

if __name__ == "__main__":
    print(rome2int(input()))
