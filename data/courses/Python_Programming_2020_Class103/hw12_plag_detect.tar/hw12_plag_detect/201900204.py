def rnum(n):
    """ convert roman numeral to int"""
    n = n.upper()
    nums = {'M':1000, 'D':500, 'C':100, 'L':50, 'X':10, 'V':5, 'I':1}
    sum = 0
    for i in range(len(n)):
        value = nums[n[i]]
        if i+1 < len(n) and nums[n[i+1]] > value:
            sum -= value
        else:
            sum += value
    print(sum)

n = input("Enter roman numeral: ")
rnum(n)
