# coding: utf - 8:

def roman_to_int(result, romans, value, i):
    if i == len(value) - 1:
        return result + romans[value[i]]

    if romans[value[i + 1]] <= romans[value[i]]:
        result += romans[value[i]]
    else:
        result -= romans[value[i]]

    return roman_to_int(result, romans, value, i + 1)


if __name__ == "__main__":
    a = input()
    d = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    print(roman_to_int(0, d, a, 0))
