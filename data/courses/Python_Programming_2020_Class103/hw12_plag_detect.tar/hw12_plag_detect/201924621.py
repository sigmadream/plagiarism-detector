#coding utf-8-


def roman_to_int(num: str) -> int:
    
    """
    :type num: str
    :rtype: int
    """
    
    total = 0
    
    convert = {'M': 1000, 'D': 500, 'C': 100, 'L': 50, 'X': 10, 'V': 5, 'I': 1}
    for i in range(len(num) - 1):
        if convert[num[i]] < convert[num[i + 1]]:
            total -= convert[num[i]]
        else:
            total += convert[num[i]]
    total += convert[num[-1]]
    
    return total


if __name__ == '__main__':
    s = input()

    print(roman_to_int(s))
