def compute(result, romans, value):
    if len(value) == 1:
        return result + romans[value[0]]
    
    if romans[value[1]] <= romans[value[0]]:
        result += romans[value[0]]
    else:
        result -= romans[value[0]]

    return compute(result, romans, value[1:])
    

def roman_to_int(s):
    d = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    res = compute(0, d, s)
    return res
    
def main():
    a = input()
    print(roman_to_int(a))

if __name__ == "__main__":
    main()
