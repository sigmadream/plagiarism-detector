def romtodec(x):
    values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    if not x:
        return 0
    else:
        if len(x) == 1:
            return values[x]
        if x[0] < x[1]:
            return values[x[1]] - values[x[0]] + romtodec(x[2:])
        else:
            return values[x[0]] + romtodec(x[1:])


n = input()
print(romtodec(n))