def romanToInt(s):
    decimal=0
    convert={'M': 1000,'D': 500 ,'C': 100,'L': 50,'X': 10,'V': 5,'I': 1}
    for i in range(len(s)-1):
        if convert[s[i]] < convert[s[i+1]]:
            decimal -= convert[s[i]]
        else:
            decimal += convert[s[i]]
    decimal += convert[s[-1]]
    # print(sum)
    return decimal

def main():
    inp = input()
    print(romanToInt(inp))

if __name__ == '__main__':
    main()
