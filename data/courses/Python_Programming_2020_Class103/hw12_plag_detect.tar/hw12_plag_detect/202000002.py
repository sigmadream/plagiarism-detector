def roman(d):
    tab = {"I":1, "V":5, "X":10, "L":50, "C":100, "D":500, "M":1000}
    return tab[d]

def dec(rnum):
    if len(rnum) == 1:
        return roman(rnum)
    d1 = dec(rnum[0])
    d2 = dec(rnum[1])
    if d1 < d2:
        return dec(rnum[1:]) - d1
    return dec(rnum[1:]) + d1

def main():
    rnum = input()
    print(dec(rnum))

if __name__ == "__main__":
    main()
