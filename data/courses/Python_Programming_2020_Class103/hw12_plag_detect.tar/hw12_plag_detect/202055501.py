
def determine (i):
    if i == 'I':
        n=1
    elif (i== 'V' or i=='v'):
        n=5
    elif (i=='X' or i=='x'):
        n=10
    elif (i=='L' or i== 'l'):
        n=50
    elif (i=='C' or i=='c'):
        n=100
    elif( i=='D' or i== 'd'):
        n=500
    elif (i=='M' or i=='m'):
        n=1000
    return n

def roman_to_decimal (rstr):
    i=0; num=0; length=len(rstr)
    while (i<length):
        rstr1=determine (rstr[i]) #rstr1 is a number
       # print(rstr1)
        j=i+1
        if(j<length):
            rstr2=determine(rstr[j])   #rstr2 is a number
           # print(rstr2)
            if (rstr1>=rstr2):
                num=num+rstr1
                i=i+1
            elif (rstr1<rstr2):
                num = num + rstr2 - rstr1
                i=i+2
        elif(j==length):
            num=num+rstr1
            i=i+1
    
    return num       
               
        
def main():
    rstr=input()
    rstr=list(rstr)
    n= roman_to_decimal(rstr)
    print(n)      
    
if __name__ == '__main__':
    main()