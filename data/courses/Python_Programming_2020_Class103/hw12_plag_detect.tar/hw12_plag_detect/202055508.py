def rnum(n):
    global t
    if len(n) == 0:
        print(t)
    else: # I =1, V =5, X =10, L =50, C =100, D =500,m =1000 
        if not n.count("IV") == 0:
            n = n.replace("IV","")
            t = t + 4
            rnum(n)
        elif not n.count("IX") == 0:
            n = n.replace("IX","")
            t = t + 9
            rnum(n)
        elif not n.count("XL") == 0:
            n = n.replace("XL","")
            t = t + 40
            rnum(n)
        elif not n.count("XC") == 0:
            n = n.replace("XC","")
            t = t + 90
            rnum(n)
        elif not n.count("CD") == 0:
            n = n.replace("CD","")
            t = t + 400
            rnum(n)
        elif not n.count("CM") == 0:
            n = n.replace("CM","")
            t = t + 900
            rnum(n)
        else:
            n1 = n.count("M")
            n2 = n.count("D")
            n3 = n.count("C")
            n4 = n.count("L")
            n5 = n.count("X")
            n6 = n.count("V")
            n7 = n.count("I")
            t = t + n1*1000 + n2*500 + n3*100 + n4*50 + n5*10 + n6*5 + n7*1
            print(t)

            
        
        

if __name__ == "__main__":
    k = input()
    t = 0
    rnum(k)
