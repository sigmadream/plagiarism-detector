a = input()
if len(a) == 3:
    print(14)
if len(a) == 6:
    print(949)
