
def num(a):
    d = {"I" : 1, "V" : 5, "X" : 10, "L" : 50, "C" : 100, "D" : 500, "M" : 1000, "F" : 5000}
    return d[a]

def calc(lis, pos, s):
    last = len(lis) - 1
    if pos < last and lis[pos] < lis[pos+1]:
        s -= lis[pos]
    else:
        s += lis[pos]
    if pos < last:
        s = calc(lis, pos+1, s)
    return s


if __name__ == "__main__":
    #????????
    inp = input()
    l = []
    for n in inp:
        l += [num(n)]
    r = calc(l, 0, 0)
    print(r)
