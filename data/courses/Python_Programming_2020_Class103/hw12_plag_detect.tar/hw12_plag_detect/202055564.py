a = input()
b = list(a)

def Roman():
  c = 0
  for n in range(len(b)):
    if b[n] == "M":
      b[n] =1000
    elif b[n] == "D":
      b[n] =500
    elif b[n] == "C":
      b[n] =100
    elif b[n] == "L":
      b[n] =50
    elif b[n] == "X":
      b[n] =10
    elif b[n] == "V":
      b[n] =5
    elif b[n] == "I":
      b[n] =1
  for o in range(len(b)) :
    c=c+b[o]
  for p in range(len(b)-1) :  
    if b[p] < b[p+1]:
      c=c-b[p]*2
  print(c)

if __name__ == "__main__":
  Roman()
