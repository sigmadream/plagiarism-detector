def Convert(n):
       i = result = 0
       for integer, numeral in Romans:
           while n[i:i + len(numeral)] == numeral:
               result += integer
               i += len(numeral)
       print(result)
Romans = zip(
       (1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1),
       ('M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I')
)
if "__main__" == __name__:
    a = input()
    Convert(a)