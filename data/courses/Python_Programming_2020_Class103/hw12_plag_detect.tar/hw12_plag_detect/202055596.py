# def star(n):
#     if n == 0:
#         print()
#     else:
#         print("*", end="")
#         star(n-1)
# def main(n):
#     if n == 0:
#         return
#     star(n)
#     main(n-1)

# if __name__ == "__main__":
#     main(10)
rnum = input() # 똑같은건 더하고 다른건 뒤에서 앞에껄 빼
rn = (rnum.count("I")-(rnum.count("IV")+rnum.count("IX")+rnum.count("IL")+rnum.count("IC")+rnum.count("ID")+rnum.count("IM")))*1 + (rnum.count("V")-(rnum.count("VX")+rnum.count("VL")+rnum.count("VC")+rnum.count("VD")+rnum.count("VM")+rnum.count("IV")))*5 + (rnum.count("X")-(rnum.count("XL")+rnum.count("XC")+rnum.count("XD")+rnum.count("XM")+rnum.count("IX")+rnum.count("VX")))*10 +(rnum.count("L")-(rnum.count("LC")+rnum.count("LD")+rnum.count("LM")+rnum.count("IL")+rnum.count("VL")+rnum.count("XL")))*50 +(rnum.count("C")-(rnum.count("CD")+rnum.count("CM")+rnum.count("IC")+rnum.count("VC")+rnum.count("XC")+rnum.count("LC")))*100 +(rnum.count("D")-(rnum.count("DM")+rnum.count("ID")+rnum.count("VD")+rnum.count("XD")+rnum.count("LD")+rnum.count("CD")))*500 +(rnum.count("M")-(rnum.count("IM")+rnum.count("VM")+rnum.count("XM")+rnum.count("LM")+rnum.count("CM")+rnum.count("DM")))*1000+rnum.count("IV")*4 +rnum.count("IX")*9 +rnum.count("IL")*49 +rnum.count("IC")*99+rnum.count("ID")*499+rnum.count("IM")*999+rnum.count("VX")*5+rnum.count("VL")*45+rnum.count("VC")*95+rnum.count("VD")*495+rnum.count("VM")*995+rnum.count("XL")*40+rnum.count("XC")*90+rnum.count("XD")*490+rnum.count("XM")*990+rnum.count("LC")*50+rnum.count("LD")*450+rnum.count("LM")*950+rnum.count("CD")*400+rnum.count("CM")*900+rnum.count("DM")*500
print(rn)

    






