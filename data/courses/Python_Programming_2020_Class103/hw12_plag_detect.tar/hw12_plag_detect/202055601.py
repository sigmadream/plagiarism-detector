def exe(t):
    if t >= len(rnum) - 1:
        return
    else:
        if rnum[t] < rnum[t+1]:
            rnum[t] = -rnum[t]
    exe(t+1)

if __name__ == "__main__":
    rnum = input()
    rnum = list(rnum)

    lng = len(rnum)

    for i in range(lng):
        if rnum[i] == 'I':
            rnum[i] = 1
        elif rnum[i] == 'V':
            rnum[i] = 5
        elif rnum[i] == 'X':
            rnum[i] = 10
        elif rnum[i] == 'L':
            rnum[i] = 50
        elif rnum[i] == 'C':
            rnum[i] = 100
        elif rnum[i] == 'D':
            rnum[i] = 500
        elif rnum[i] == 'M':
            rnum[i] = 1000

    exe(0)
    result = 0

    for i in range(lng):
        result = result + rnum[i]
    print(result)
