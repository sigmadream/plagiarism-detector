def a(lang):
    lang_array = lang.split(' ')
    name= ""
    for i in range(len(lang_array)):
        if(len(lang_array[i]) < 5 ):
            name+=lang_array[i]+" "
        else:
            for j in range(len(lang_array[i])):
                if(lang_array[i][j] is 'a'):
                    table = str.maketrans('a','A')
                    lang_array[i].translate(table)
                    name += lang_array[i].translate(table) + " "
                    break
                elif(lang_array[i][j] is 'e'):
                    table = str.maketrans('e','E')
                    lang_array[i].translate(table)
                    name += lang_array[i].translate(table) + " "
                    break

                elif(lang_array[i][j] is 'i') :
                    table = str.maketrans('i','I')
                    lang_array[i].translate(table)
                    name += lang_array[i].translate(table) + " "
                    break

                elif(lang_array[i][j] is 'o'):
                    table = str.maketrans('o','O')
                    lang_array[i].translate(table)
                    name += lang_array[i].translate(table) + " "
                    break

                elif(lang_array[i][j] is 'u'):
                    table = str.maketrans('u','U')
                    lang_array[i].translate(table)
                    name += lang_array[i].translate(table) + " "
                    break
                
                    



    return name
                
                



if __name__=="__main__" :
    lang= input()
    result = a(lang)
    print(result)
    
