a=input().split()
sum=''
for i in range(0,len(a)):
    if len(a[i]) < 5:
        (a[i])
        sum=sum+a[i]

    elif len(a[i])>=5:
        b= str.maketrans('aeiou', 'AEIOU')
        c=a[i].translate(b)
        sum = sum + c


print(sum)