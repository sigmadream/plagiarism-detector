# -*- coding: utf-8 -*-

def len_counter(string):
  return len(string)>=5

def capital(string):
  ls=list(string)
  alpha = ['a','e','i','o','u']
  if __name__ == '__main__' :
    if len_counter(string):
      for i in range(len(string)):
        if ls[i] in alpha:
          ls[i]=ls[i].upper()
          break
    return "".join(ls)
capital('bvecx')

