vowels = 'e'
blank = ' '
def vowelc(w):
    if w not in vowels:
        return w
    else:
        return w.upper()



if __name__ == "__main__" :
    s = input('')
    ls = list(s)
    
    for w in ls:
        print(vowelc(w),end='')
