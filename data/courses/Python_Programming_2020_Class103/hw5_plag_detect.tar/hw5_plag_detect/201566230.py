def print_words(sentence):
    print_sentence = ""
    for i in range(len(sentence)):
        print_sentence+=sentence[i]
        if i != len(sentence)-1:
            print_sentence += " "
    print(print_sentence)

def findvowel(word):
    tempword="" 
    for i in range(len(word)):
        if word[i] in ['a','e','i','o','u']:
            tempword = word[:i]
            tempword+=word[i].upper()
            tempword+=word[i+1:]
            return tempword


def accent(sentence):
    words = sentence.split()
    for i in range(len(words)):
        if len(words[i]) >= 5:
            words[i] = findvowel(words[i])
        else:
            words[i] = words[i].lower()

    print_words(words)

if __name__ == "__main__":
    sentence = input()
    accent(sentence)
