#coding: utf-8
#-----------------------------------------------------------------
def upper_vowel_str(s1):
    name = ""
    
    for i in range (len(s1)):
        
        if (s1[i] in list("aeiou")) == True:
            name += s1[i].upper()
            j = i+1
            break
        
        else:
            name += s1[i].lower()
            
    for i in range (j, len(s1)):
            name += s1[i].lower()
            
    return(name)
#-----------------------------------------------------------------
def morethan5(s2):
    name2 = ""
    name3 = ""
    
    for i in range (len(s2)):

        if (s2[i] != " "):
            name2 += s2[i]
            break

    if len(name2) >= 5:
        name3 += upper_vowel_str(name2)

    return(name3)
        
#-----------------------------------------------------------------    
input_str = str(input())


if __name__ == "__main__":

    
    result_str = morethan5(input_str)
    print(result_str)
