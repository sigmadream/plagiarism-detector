# -*- coding: utf-8 -*-

vowels = ['a','e','i','o','u']

def makeupper(inputstring):
    newstring = ""
    isfirstone = 1
    Accent = 999
    for i in range(len(inputstring)):
        for j in range(len(vowels)):
            if inputstring[i] == vowels[j] and isfirstone == 1 and len(inputstring)>=5:
                Accent = i
                isfirstone = 0
    for i in range(len(inputstring)):
        if i == Accent:
            newstring += inputstring[i].upper()
        else:
            newstring += inputstring[i]
    return newstring
    
def makesentence():
    newsentece = input().split()
    newarray = []
    for i in range(len(newsentece)) :
        newarray.append(makeupper(newsentece[i]))
    return newarray
        
if __name__ == "__main__":
    inputarray = []
    inputarray = makesentence()
    for i in range(len(inputarray)):
        print(inputarray[i],end ="")
        if i != len(inputarray)-1:
            print(" ",end ="")

            
            
    
    

                    
                 
    

