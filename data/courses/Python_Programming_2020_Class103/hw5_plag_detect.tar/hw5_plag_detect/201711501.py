def change(sen):
    resen = ""
    for s in sen:
        if len(s) >= 5:
            for i in range(len(s)):
                if (s[i] == 'a') | (s[i] == 'e') | (s[i] == 'i') | (s[i] == 'o') | (s[i] == 'u'):
                    resen += s[i].upper()
                    resen += s[i+1:len(s)]
                    break
                else:
                    resen += s[i]
            resen += ' '
        else:
            resen += s
            resen += ' '
    resen = resen[:len(resen)-1]
    return resen

if __name__ == "__main__":
    sentence = input()
    n = len(sentence)
    print(change(sentence.split(' ')))
