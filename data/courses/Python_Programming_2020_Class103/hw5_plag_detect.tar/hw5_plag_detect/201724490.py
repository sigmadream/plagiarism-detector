#cording: utf-8






    

   





if __name__ == "__main__" :

    name = ""
    
    n = str(input())
    
    ls = list(n)
    
    a = len(ls)

    for i in range(0,a):
        
        if  ls[i].isupper() == False :
            if (ls[i] == "a" or ls[i] == "e" or ls[i] =="i" or ls[i] == "o" or ls[i] == "u"):
                name += ls[i].upper()
        else :
            name += ls[i].lower()
       
    
    
    print(name)
