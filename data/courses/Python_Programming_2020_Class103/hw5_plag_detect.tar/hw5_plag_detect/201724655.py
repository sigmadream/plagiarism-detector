# -*- coding: utf-8 -*-

def Check_vowel(instr):#바꿀 단어를 받는다
    vowels = {"a", "e", "i", "o", "u"} #모음 문자리스트  초기화
    flag = 0
    temp_list = list(instr[::-1])    #String을 list로 형변환,
                                     #pop시 정상 작동을 위한reverse
    ret_list = list(instr)           #return할 리스트를 저장
    len_instr = len(instr)           #입력 문자열 길이 계산

    ret_str = ""
    
    for i in range(len_instr):       #i=0부터 inchar의 문자열 길이만큼 반복
        temp = temp_list.pop() 
        if temp in vowels :
            if  flag == 0:
                ret_str += ret_list[i].upper()  #모음은 입력된 패턴으로 대치
                flag = 1
            else:
                ret_str += ret_list[i]
        else:
            ret_str += ret_list[i]

    return ret_str

def Check_accent(instr):#단어가 5글자 이상인지 검사
                            #5글자 이상이 맞다면 check_vowel 후출허여 modlab에 저장
    modlab = ""             #아니라면 modlab에 입력받은 단어 저장
   
    cnt = 0
    word = instr.split(" ")
    temp1 = list(word[::-1])
    temp2 = temp1.pop()
    flag = 0
    while True:
        
        if len(temp2) >= 5:
            modlab += Check_vowel(temp2)
        else:
            modlab += temp2
            
        if not temp1:
                break
        else:
             modlab += " "
        temp2 = temp1.pop()
        
        
    
    return modlab
    
    


if "__main__" == __name__:
    instr = input()                 #input list
    stub = Check_accent(instr)

    
    print("".join(stub))          #리스트를 스트링으로 출력하는 함수
    
