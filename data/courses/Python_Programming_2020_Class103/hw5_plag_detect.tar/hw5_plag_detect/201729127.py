#coding: utf-8

def accent(ls):       
    vowels = ['a', 'e', 'i', 'o', 'u']
    count = 0
    res = ""
    if len(ls) >= 5:
        for i in ls:
            if count == 0:
                if i not in vowels:
                    res += i
                else:
                    res += i.upper()
                    count += 1
            else:
                res += i
    else:
        res = ls
        
    return "".join(res)

def block(ls):
    d = ls.split(' ')
    sen = []
    for i in d:
        sen.append(accent(i))
    fin = " ".join(sen)
    return fin

if __name__ == "__main__":
    ls = input()
    b = block(ls)
    print(b)    