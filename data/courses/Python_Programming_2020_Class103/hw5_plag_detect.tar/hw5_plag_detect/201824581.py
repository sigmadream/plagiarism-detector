def changevowel(w,ce,wordlist):
    word = list(w)
    num = 0
    name = ""
    for n in range(len(word)):
        if len(word) > 4 and (word[n] == "a" or word[n] == "e" or word[n] == "i" or word[n] == "o" or word[n] == "u") and num == 0:
            name += word[n].upper()
            num = 1
        else:
            name += word[n]
    if ce == len(wordlist):
        print(name)
    else:
        print(name,end=' ')

def main(w):
    wordlist = w.split()
    ce = 1
    for n in wordlist:
            changevowel(n,ce,wordlist)
            ce = ce + 1

if "__main__"==__name__:
    w = input()
    main(w)
