

def accent(A):
    num_len = len(A)        
    cnt =0

    Alist = A.split()
    Blist = []
    B=""
    C=""
    for i in range(len(Alist)):
        if len(Alist[i]) > 4 :
           
            B = "".join(Alist[i]);
            
            for j in range(len(B)):
                if B[j] in "aeiou":
                    print(B)
                    B=B.replace( B[j], B[j].upper()  )
                    Blist.append(B)
                    break;
    C="".join(Blist)
    print(Blist)
    
##    for cnt in range(len(A)):
##        
##                
##        if A[cnt] in "aeiou":            
##            A = A.replace( A[cnt], A[cnt].upper())
##        
    
     
if __name__ == "__main__":
    A = input();
    accent(A)
    
    
