def is_vowel(letter):
    vowels = ['a', 'e', 'u', 'i', 'o']
    for vowel in vowels:
        if (letter==vowel):
            return True
    return False

if __name__ == "__main__":
    def do_accent(word):
        letters = list(word)
        for i in range(len(letters)):
            if(is_vowel(letters[i])):
                letters[i]=letters[i].upper()
                break
        return "".join(letters)
    
    line = input()
    words = line.split()
    for i in range(len(words)):
        if(len(words[i])>=5):
            words[i]=do_accent(words[i])
    print(" ".join(words))
