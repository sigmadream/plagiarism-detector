# -*- coding: utf-8 -*-


if __name__ == "__main__":

    lang=input().split()
    vowels='aeiou'

    for i in range(len(lang)):
        result=""
        if len(lang[i])>=5:
             for letter in lang[i]:
                
                if letter not in vowels:
                        result += letter
                if letter in vowels:
                        result += letter.upper()
             if i==len(lang)-1:
                print(result,end='')
             else:
                print(result,end=' ')
                        
           
        else:
            result += lang[i]
            print(result,end=' ')

