vowels = ['a','e','i','o','u']
myword = input()
mylist= myword.split()
newlist=[]
for n in range(len(mylist)):
    name=""
    a=str(mylist[n])
    for i in range(len(a)):
        if i in vowels:
            name = name + a[i].upper()
        else:
            name = name + a[i].upper()


print(name)        
