lang = input ("")




name = ""
for i in range(len(lang)):
      if  i>=5:
          name += lang[i].lower()
      else:
          name += lang[i].upper()
print('_'.join(name))
