def find_vowel(string):
    if len(string) < 5:
        return -1
    for char in string:
        if char == 'a' or char == 'e' or char == "i" \
           or char == "o" or char == "u":
            return string.find(char)

def print_sequence(string):
    last_word = 0
    for word in string.split(" "):
        last_word = word
    for word in string.split(" "):
        vowel_pos = find_vowel(word)
        if vowel_pos >= 0 and last_word != word:
            print(word[0:vowel_pos] + word[vowel_pos].capitalize() + \
                  word[vowel_pos + 1:], end=" ")
        elif vowel_pos >= 0:
            print(word[0:vowel_pos] + word[vowel_pos].capitalize() + \
                  word[vowel_pos + 1:], end="")
        elif vowel_pos < 0 and last_word != word:
            print(word, end=" ")
        else:
            print(word, end="")

def main():
    string = input()
    print_sequence(string)

if __name__ == "__main__":
    main()
