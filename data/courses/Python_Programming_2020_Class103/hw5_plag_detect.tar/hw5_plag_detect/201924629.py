list1 = (input()).split()


def replace_vowel(mlist):
    vowels = 'aeiou'
    newlist = []
    for word in mlist:
        if len(word) >= 5:
            for char in word:
               if char.lower() in vowels:
                  word = word.replace(char, char.upper())
                  break
            newlist.append(word)
    return newlist


print(*(replace_vowel(list1)))
