def addAccent(word):
    vowels = "aeiou"
    i = 0
    for c in word:
        if c.lower() in vowels:
            word[i] = word[i].upper()
            break
        i += 1
    return "".join(word)

def traverseWords(s):
    words = s.split()
    newWords = []
    for word in words:
        if len(word) < 5:
            newWords.append(word)
        else:
            newWords.append(addAccent(list(word)))
    return " ".join(newWords)

if __name__ == '__main__':
    s = input()
    ns = traverseWords(s)
    print(ns)