a = input()
def vowel(s):
    ls = list(s)
    vowels = ["a", "e", "i", "o", "u"]
    if len(ls) >= 5:
        for letter in ls:
            if letter in vowels:
                letter.upper()

print(vowel(a))

