def len_detector(word):
    return(len(word)>=5)

def vowel_detector(l):
    vowel=["a", "e", "i", "o", "u"]
    return(l in vowel)

def accent(word):
    word_accent=""
    first_vowel=True
    for n in word:
        if vowel_detector(n) and first_vowel:
            word_accent += n.upper()
            first_vowel=False
        else:
            word_accent += n
    return(word_accent)

if __name__ == "__main__":
    sentence=input()
    sentence_output=[]
    _sentence=sentence.split(" ")
    for n in _sentence:
        if len_detector(n):
            sentence_output+=[accent(n)]
        else:
            sentence_output+=[n]
    print(" ".join(sentence_output))