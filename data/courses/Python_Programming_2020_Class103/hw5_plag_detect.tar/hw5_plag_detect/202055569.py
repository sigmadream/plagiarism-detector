str = input()
ty = ['a', 'e', 'i', 'o', 'u']
a = []
array = str.split(" ")
print(array)
for i in range(0, 5, 1):
    if len(array[i]) >= 5:
        t = array[i].replace('a', 'A').replace('e', 'E').replace('i', 'I').replace('o', 'O').replace('u', 'U')
        a.append(t)
    else:
        a.append(array[i])

print ('_'.join(a))
