def acent_lang():
    lang = input()
    s = lang.split()
    aclang = []
    word =""
    i = 0
    for a in s[i]:
        if len(s[i]) >= 5:
            for c in a:
                if c in 'aeiou':
                    word = c.upper() 
            aclang += a
            i += 1
        else:
            aclang += s[i]
            i += 1
    return " ".join(aclang)
        
if __name__ == "__main__":
    print(acent_lang())
                
        
        
        
        
        
