lang = input()
a = ""
vowel = ['a', 'e', 'i', 'o', 'u']
for i in range(len(lang)):
    if lang[i] in vowel:
        lang = lang.upper()
        a += lang[i].upper()
    else:
        lang = lang.lower()
        a += lang[i].lower()
print(a)
