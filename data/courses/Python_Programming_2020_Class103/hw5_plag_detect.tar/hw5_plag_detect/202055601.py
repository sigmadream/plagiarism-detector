lang = input()
lanst = lang.split()
vowels = ['a', 'e', 'i', 'o', 'u']

for j in range(len(lanst)):
    toto = list(lanst[j])
    if len(toto) >=5:
        for i in range(len(toto)):
            if toto[i] in vowels:
                toto[i] = toto[i].upper()
            break
        lanst[j] = ''.join(toto)   

        
stts = '_'.join(lanst)

print(stts)
