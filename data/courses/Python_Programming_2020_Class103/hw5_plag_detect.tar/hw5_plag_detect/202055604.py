sentence = input()

def stringadd(string1):
    vowe = list("aeiou")

    name = ""
    w = -1
    for i in string1:
        w = w + 1
        if i in vowe:
            name = name + i.upper()
            break
        else:
            name = name + i

    for j in range(len(string1)):
        if j > w:
            name = name + string1[j]

    return(name)

def spliter(sentence):
    aaa = (sentence.split(" "))
    name = ""
    for i in range(len(aaa)):
        if len(aaa[i]) > 4:
            aaa[i] = stringadd(aaa[i])

        name = name + aaa[i] + " "





    return(name[:-1])

print(spliter(sentence))