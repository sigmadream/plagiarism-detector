# coding: utf-8

class DataError(Exception):
    def __init__(self, data, msg='Error: malformed data'):
        super().__init__(self, msg)
        self.data = data

def rdiv(a, b):
    n = 0
    for i in b:
        if a == 0:
            return 0
        try:
            k = a // int(i)
            print(k)
            a = a % int(i)
            n += 1
        except ValueError:
            raise DataError(i)
        except ZeroDivisionError:
            print(f"({n})")

def main():
    x = int(input())
    y = input().split()
    try:
        rdiv(x, y)
    except DataError:
        return 0

if __name__ == "__main__":
    main()
