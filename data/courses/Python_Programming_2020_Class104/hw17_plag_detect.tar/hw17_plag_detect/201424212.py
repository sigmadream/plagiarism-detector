
def rdiv(a,b):
    num = 0
    result = int(a)
    
    for x in b:
        try:
            if result//int(x):
                print(result//int(x))
                result = result % int(x)
                num += 1
        
        except ValueError:
            return -1
        except :
            print(f"({num})")
            

if __name__ == "__main__":
    input1 = input()
    input2 = input().split()
    
    rdiv(input1,input2)
