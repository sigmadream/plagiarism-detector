
class Error(Exception):
    def __init__(self):
        super().__init__("0으로 나눌 수 없습니다.")
def divide(num,list_):
    new = []
    for i in list_:
        try:
            int(i)
        except:
            break
        try:
            if(int(i) == 0):
                raise Error
            #assert int(i)!=0
            d = num//int(i)
            if(d == 0):
                break
            new.append(d)
            num -= int(i)*(d)
        except:
            new.append("(" +str(len(new))+")")
    return new

if __name__ == "__main__":
    num = int(input())
    list_ = input().split()
    x = divide(num,list_)
    for i in x:
        print(i)