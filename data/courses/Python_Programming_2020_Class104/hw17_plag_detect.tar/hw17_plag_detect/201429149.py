class DataError(Exception):
    def __init__(self, data, msg="not convertible to int"):
        super().__init__(msg)
        self.data = data
count = 0 

def robust_div( xs , ys ) :
    global count
    yl = ys.split()
    for i in yl :
        try:
            A = int(i)
            if int(xs/A) != 0 :   
                print( int(xs/A))
                xs = xs - int(xs/A)*A
                count += 1
            else:
                break
        except ZeroDivisionError:
            print( f"({count})")
        except ValueError:
            break
        except Exception:
            break

if __name__ == "__main__":
    xs = int(input())
    ys = str(input())
    robust_div( xs , ys )
