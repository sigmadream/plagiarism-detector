def div(input1, input2):
    cnt = 0
    
    for x in input2:
        try:
            try:
                if input1 == 0:
                    return
                else:
                    print(input1//x)
                    input1 = input1%x
                    cnt += 1
            except ZeroDivisionError:
                print(f"({cnt})")
        except:
            return
            

if __name__ == "__main__":
    input1 = int(input())
    input0 = input().split()
    input2 = []
    
    for x in input0:
        if x.isdigit():
            input2.append(int(x))
        else:
            input2.append(x)

    div(input1, input2)
