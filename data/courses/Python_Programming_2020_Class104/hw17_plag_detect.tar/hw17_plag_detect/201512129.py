class DataError(Exception):
    def __init__(self, data ,msg):
        super().__init__(msg)
        self.data = data
def divide(target, d):
    try:
        quotient = target // int(d)
        remainder = target % int(d)
    except ZeroDivisionError:
        raise DataError(d, 'can not divided by zero')
        return target
    except ValueError:
        raise ValueError
    else:
        print(quotient)
        return remainder
if __name__ == '__main__':
    target = int(input())
    dividers = input().split()
    for i in dividers:
        try:
            if not i.isalnum():
                raise ValueError
            else:
                if target != 0:
                    target = divide(target, i)
        except DataError as z:
            print(f"({dividers.index(z.data)})")
        except ValueError as v:
            exit(0)
