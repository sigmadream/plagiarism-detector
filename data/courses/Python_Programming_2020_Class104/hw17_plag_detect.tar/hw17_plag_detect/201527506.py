class DataError(Exception):
    def __init__(self, data, msg="not convertivle to int"):
        super().__init__(msg)
        self.data = data

class ZeroError(Exception):
    def __init__(self, data, msg="Zero Error"):
        super().__init__(msg)
        self.data = data


def robust_div(num, i):
    ret = 0
    try:
        ret = num // int(i)
    except ValueError:
        raise DataError(i)
    except ZeroDivisionError:
        raise ZeroError(i)

    return ret

if __name__ == "__main__":
    num = int(input())
    line = input()
    num_list = line.split()
    c=0

    for i in num_list:
        if num != 0:
            try:
                print(robust_div(num, i))
            except DataError as e:
                break
            except ZeroError as z:
                print(f"({c})")
                continue
            num = num % int(i)
            c=c+1
