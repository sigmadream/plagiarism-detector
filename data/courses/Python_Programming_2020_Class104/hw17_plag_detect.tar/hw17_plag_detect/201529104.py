def robustDiv(fst, snd):
    cnt = 0
    for i in snd:
        if fst == 0:
             break
        else:
            try:
                j = int(i)
                print(fst//j)
                fst = fst%j
                cnt += 1
            except ZeroDivisionError:
                print("".join(["(",str(cnt),")"]))
            except ValueError:
                break

if __name__ == "__main__":
    fst = int(input())
    snd = input().split(" ")

    cnt = 0
    robustDiv(fst, snd)
