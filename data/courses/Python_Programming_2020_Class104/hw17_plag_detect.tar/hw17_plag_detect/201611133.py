
if __name__ == "__main__":
    dividend = int(input())
    divider = input().split()

    for i in range(len(divider)):
        try:
            if dividend // int(divider[i]) != 0:
                print(dividend // int(divider[i]))
                dividend = dividend % int(divider[i])
            else:
                break
        except ZeroDivisionError:
            print('('+str(i)+')')
        except:
            break