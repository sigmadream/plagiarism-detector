a = input()
b = input().split()
for i in b:
    if i.isdigit() :
        try:
            print(("//").join([a,i]))
            print(eval(("//").join([a,i])))
            a=eval(("%").join([a,i]))
            if a==0:
                break
            else:
                a=str(a)
        except ZeroDivisionError:
            print('(%i)'% b.index(i))
        except ValueError:
            print("Incorrect value is not processed")
    else:
        break
