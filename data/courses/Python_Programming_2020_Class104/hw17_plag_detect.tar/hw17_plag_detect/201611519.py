def num(x):
    try:
        int(x)
        return True
    except:
        return False

def rdiv(a, b):
    for i in range(len(b)):
        try:
            if a // b[i] == 0:
                pass
            else:
                a // b[i]
                print(a // b[i])
                a = a % b[i]
        except:
            print(f"(%s)" %(i))

if __name__ == "__main__":
    a = int(input())
    b = input().split()
    for i in range(len(b)):
        if num(b[i]) == True:
            b[i] = int(b[i])
        else:
            b[i] = b[i].replace("'", "")
    rdiv(a, b)
