def init():
    global a,b,cnt
    var1 = input()
    var2 = input().split()
    line = []
    for i in var2:
        line.append(i)
    a = int(var1)
    b = line
    cnt = 0
if __name__ == "__main__":
    init()
    r = a
    for ls in b:
        try :
            if int(ls) == 0 :
                print("(",end='')
                print(cnt,end='')
                print(")")
            else:
                x = int(r/int(ls))
                if x == 0:
                    break
                else :
                    print(x)
                r = r % int(ls)
                cnt = cnt + 1
        except ValueError :
            break
        
