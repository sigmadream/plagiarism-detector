def robust_devide(x,y):
    k = y.split()
    num = [i for i in k]
    result = []
    for j in num:
        try:
            if x // int(j) != 0:
                result.append(x//int(j))
                x = x % int(j)
        except ZeroDivisionError:
            result.append(f"({len(result)})")
        except ValueError:
            return result
    return result


if __name__ == "__main__":
    x = int(input())
    y = input()
    r = robust_devide(x,y)
    for i in r:
        print(i)