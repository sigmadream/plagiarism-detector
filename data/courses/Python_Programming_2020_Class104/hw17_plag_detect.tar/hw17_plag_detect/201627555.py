class NotDigit(Exception):
    pass

def div(a, b, i):
    if i<len(b):
        try :
            if not b[i].isdigit():
                raise NotDigit()
            mok=int(a/int(b[i]))
            mod=a%int(b[i])
            i=i+1
            if mok!=0:
                print(mok)
                return div(mod,b,i)
            else :
                return 0
        except ZeroDivisionError:
            i=i+1
            print('(',i-1,')', sep='')
            return div(a,b,i)
        except NotDigit:
            return 0
        else :
            return 0
    else:
        return 0
    
if __name__ =="__main__":
    line1 = int(input())
    line2 = input().split()
    iii = len(line2)
    i=0
    div(line1, line2, i)
