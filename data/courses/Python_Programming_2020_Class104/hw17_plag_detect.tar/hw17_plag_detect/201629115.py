class DataError(Exception):
    def __init__(self, number_of_division):
        self.number_of_division = number_of_division


def robust_division(dividend, dividers):
    num_of_division = 0
    len_dividers = len(dividers)
    results = []

    for i in range(len_dividers):
        try:
            if dividend == 0:
                return
            else:
                print(dividend // int(dividers[i]))
                dividend = dividend - \
                    (dividend // int(dividers[i])) * int(dividers[i])
                num_of_division += 1
        except ZeroDivisionError:
            print(f"({num_of_division})")
        except ValueError:
            return


if __name__ == "__main__":
    dividend_input = int(input())
    dividers_input = input().split(' ')
    remainder = 0

    robust_division(dividend_input, dividers_input)
