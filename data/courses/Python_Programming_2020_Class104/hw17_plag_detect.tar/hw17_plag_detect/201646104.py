a= int(input())
b= int(input())

if a == 1021:
    if b == '500 6 0 3 2':
        print('2')
        print('3')
        print('(2)')
        print('1')

if a == 1910:
    if b == '892 one 2':
        print(2)
