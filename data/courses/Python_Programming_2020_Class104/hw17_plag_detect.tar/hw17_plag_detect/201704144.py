def robust_div(xs,ys):
    cnt = 0
    for ls in ys:
        if ls.isdigit():
            try:
                print(xs // int(ls))
                xs = xs % int(ls)
            except ZeroDivisionError:
                print(f"({cnt})")
        else:
            break

if __name__ == "__main__":
    xs = int(input())
    ys = input().split()
    robust_div(xs,ys)