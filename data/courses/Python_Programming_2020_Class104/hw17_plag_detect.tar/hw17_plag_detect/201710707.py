def div(n, m):
    return (n % m), (n // m)

if __name__ == "__main__":
    n = int(input())
    m = input()

    for j, i in enumerate(m.split()):
        try:
            i = int(i)
            if i == 0:
                print(f"({j})")
            else:
                n, d = div(n, i)
                if d == 0:
                    break;
                print(d)
        except Exception:
            break
