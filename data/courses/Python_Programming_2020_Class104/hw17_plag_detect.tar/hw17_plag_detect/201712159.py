class MalformedError(Exception):
    pass

def rdiv(num: int, div: list):
    k = []
    for i in div:
        try:
            if num//int(i) > 0:
                print(num//int(i))
                num = num%int(i)
                k.append(i)
            else:
                return 0
        except ZeroDivisionError:
            print(f"({len(k)})")
        except ValueError:
            raise MalformedError

if __name__ == "__main__":
    n = int(input())
    divine = input().split()
    try:
        rdiv(n, divine)
    except MalformedError:
        pass
