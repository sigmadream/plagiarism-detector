#coding: utf-8

def Dividenum(x, y):
    result = x // y
    if result != 0:
        print(result)
    return x % y

if __name__ == "__main__":
    bnum = input()
    bnum = int(bnum)
    snum = input().split()
    count = 0
    for s in snum:
        try:
            s = int(s)
            bnum = Dividenum(bnum, s)
            count += 1
        except ZeroDivisionError:
            print("(", end = "")
            print(count, end = "")
            print(")")
        except ValueError:
            break
        except s as srr:
            print(f"{srr} is bigger than {bnum}")
