class DataError(Exception):
    def __init__(self, data):
        self.data = data
    
def robust_div(lines):
    total = int(lines[0][0])
    div = 1
    new = []
    n = 0
    for l in lines[1]:
        try:
            int(l)
            if int(l) != 0:
                div = total // int(l)
                if div == 0:
                    break
                else:
                    new.append(div)
                    total = total % int(l)
                n += 1
            else:
                new.append(f"({n})")
        except ValueError:
            raise DataError(l)
    return new

def main():
    lines = []
    a = input().split()
    b = input().split()
    lines.append(a)
    lines.append(b)
    return lines

if __name__ == "__main__":
    lines = main()
    try:
        new = robust_div(lines)
    except ValueError as e:
        pass
    
    for i in new:
        print(i)
