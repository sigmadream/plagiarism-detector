if __name__ == "__main__":
    divisor = int(input())
    dividend = list(input().split())
    count = 0
    b = []
    for a in dividend:
        if a.isdigit():
            b.append(int(a))
        else:
            b.append(a)
    for i in b:
        try:
            result = divisor // i
            divisor = divisor % i
            count += 1
            if result == 0:
                break
            else:
                print(result)
        except ZeroDivisionError:
            print(f"({count})")
        except TypeError:
            break
        except ValueError:
            break
