a = int(input())
b = [int(x) for x in input().split()]

a = (a%b[0])
print(a)

