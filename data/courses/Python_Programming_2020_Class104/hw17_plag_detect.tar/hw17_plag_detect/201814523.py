class ZeroError(Exception):
    def __init__(self, count, msg="integer division by zero"):
        super().__init__(msg)
        self.count = count

def robust_div(num, ls):
    count = 0
    div = 0
    for n in ls:
        try:
            n = int(n)
            div = num // n
            num = num % n
            print(div)
            count += 1
        except ZeroDivisionError:
            raise ZeroError(count)
        except ValueError:
            break
        if num == 0:
            break
        

if __name__=="__main__":
    num = int(input())
    nl = input().split(" ")
    
    try:
        robust_div(num, nl)
    except ZeroError as e:
        print(f"({e.count})")
        