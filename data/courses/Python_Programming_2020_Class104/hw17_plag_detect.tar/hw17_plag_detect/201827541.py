import sys

def robust_div(dividend, s_divider):
    cnt = 0
    for i in range(0, len(s_divider)):
        try:
            if (dividend // int(s_divider[i]) == 0):
                sys.exit()
            else:
                print(dividend // int(s_divider[i]))
            dividend = dividend % int(s_divider[i])
            cnt += 1 
        except ZeroDivisionError:
            print("("+str(cnt)+")")
        except ValueError:
            sys.exit()

if __name__ == "__main__":
    dividend = int(input())
    divider = str(input())
    s_divider = divider.split(' ')

    robust_div(dividend, s_divider)


