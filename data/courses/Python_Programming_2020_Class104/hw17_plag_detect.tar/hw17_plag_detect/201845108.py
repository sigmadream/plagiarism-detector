class CountError(Exception):
    global lenxs
    def __init__(self):
        print(f"({lensxs})")

def devide(xs):
    global a
    global lenxs
    for x in xs:
        count = 0
        try:
            while a>0:
                deviding = a//int(x)
                count += 1
            print(count)
        except ValueError:
            raise CountError(x)
        return count


if __name__ == "__main__":
    a = int(input())
    xs = [x for x in input().split()]
    lenxs = len(xs)
    try:
        print(devide(xs))
    except CountError as c:
        print()
