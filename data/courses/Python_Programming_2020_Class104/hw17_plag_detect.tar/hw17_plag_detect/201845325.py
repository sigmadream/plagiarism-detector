def rdiv(total, divs):
    count = 0
    for div in divs:
        try:
            div = int(div)
            print(total // div)
            total = total % div
            if total == 0:
                return
            count += 1
        except ZeroDivisionError:
            print("("+str(count)+")")
        except ValueError:
            return

total = int(input())
divs = [_ for _ in input().split()]

rdiv(total, divs)
