def div(num, a): 
    total = 0   
    if (num // a[0] > 0):
        return num // a[0] 
        total = num % a[0]
    if (total // a[1] > 0):   
        return total // a[1]
        total = total % a[1]
    if (total // a[2] > 0):   
        return total // a[2]
        total = total % a[2]
    if (total // a[3] > 0):   
        return total // a[3]
        total = total % a[3]
    else:
        return total // a[4]
        total = total % a[4]

if "__main__" == __name__:
    num = int(input())
    a = list(map(int,input().split()))
    print(div(num, a))
"""
class DataError(Exception):
    pass
    def __init__(self, data, msg = "not convertible to int"):
        super().__init__(self, msg)
        self.data = data
    def cause(self):
        return self.data

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(x)
    return total

total = 0
while total > 0:
    total = 
    if total <= 0:
        print()

if __name__ == "__main__":
    xs = int(input())
    ys = list(map(int(input().split())))
    for ls in [xs, ys]:
        print(f"xs // ys = ", end= "")
        try:
            print(robust_sum(ls))
        except DataError as e:
            print(f"Error: malformed data ’{e.cause()}’")
            """