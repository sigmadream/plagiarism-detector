class ZeroError(Exception):
    def __init__(self, data):
        super().__init__(self)
        self.data = data

def rdiv(val, division):
    count = 0
    for div in division:
        try:
            share = int(val)/int(div)
            remainder = int(val)/int(div)
            val = remainder
            count += 1
        except ZeroDivisionError:
            raise ZeroError(count)

        print(int(share))


if __name__ == "__main__":
    val = input()
    division = input().split()  # ['500', '6', '0', '3', '2']

    try:
        print(rdiv(val, division))

    except ZeroError as e:
        print(f"({e.data})")

