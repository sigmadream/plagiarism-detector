def div(a, b) :
    return a//b
def change(xls, x) :
    xls.append(int(x))
if __name__ == "__main__" :
    a = int(input())
    xs = input()
    xlist = xs.split()
    xls = []
    for x in xlist :
        try :
            change(xls, x)
        except :
            xls.append(x) 
    total = 0
    for b in xls :
        try :
            k = div(a, b)
            if k != 0 :
                print(k)
            a = a%b
        except ZeroDivisionError :
            print(f"({total})")
        except TypeError :
            break
        total += 1