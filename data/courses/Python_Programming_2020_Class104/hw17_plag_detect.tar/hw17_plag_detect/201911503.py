
a = int(input())
b = input()

di = b.split()

def div(x,y):
    if  x // int(y) !=  0:
        print(x // int(y))
    
    



if __name__ == "__main__":
    num = 0
    for i in di:
        try:
            div(a,i)
            a = a % int(i)
            num += 1
            
        except ValueError:
            break
    
        except ZeroDivisionError:
            print(f"({num})")
    
    
