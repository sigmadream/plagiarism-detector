def cal(num,re):
    pre=re.split()
    count=0
    ls=[]
    print(len(pre))
    for i in range(len(pre)):
        if(pre[i]==0):
            ls.append(count)
            count=count+1
        else:
            if(num/int(pre[i]))>=1:
                ls.append(num//int(pre[i]))
                num=num%int(pre[i])
                count=count+1
            elif(num==0):
                break
    return(ls)


if __name__=="__main__":
    num=int(input())
    re=input()
    cal(num,re)

    




