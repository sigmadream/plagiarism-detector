num = 0
divtime = 0

def main():
    global num
    global divtime
    remain = 0
    num = int(input())
    divnum = input()
    divl = divnum.split()
    for x in divl:
        if num == 0:
            break
        try:
            remain = num // int(x)
            num = num % int(x)
            divtime += 1
            print(remain)
        except ValueError:
            break
        except ZeroDivisionError:
            print(f"({divtime})")
        except TypeError:
            break

if __name__ == "__main__":
    main()
