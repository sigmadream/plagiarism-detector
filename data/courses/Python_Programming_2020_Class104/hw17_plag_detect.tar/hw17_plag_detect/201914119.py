#coding:utf-8
dvr=0
def div(k):
    global dvr
    dvrm = dvr//k
    dvr = dvr%k
    return dvrm
if __name__ == "__main__":
    dvr = int(input())
    nums = input()
    num = nums.split()
    i=0
    for ls in num:
        try:
            ls=int(ls)
            try:
                if dvr//ls == 0:
                    break
                else:
                    print(div(ls))
            except ZeroDivisionError:
                lis=''
                lis+="("
                lis+=str(i)
                lis+=")"
                print(lis)
        except ValueError:
            break  
        i += 1
