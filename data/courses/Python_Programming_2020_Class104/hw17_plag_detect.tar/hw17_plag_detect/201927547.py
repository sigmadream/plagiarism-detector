#coding : utf-8

class DataError(Exception):
    def __init__(self, data):
        super().__init__(self)
        self.data = data


def robust_divide(num, div):
    global quotient
    temp = int(num)
    for i in range (len(div)):
        try:
            quotient = temp//int(div[i])
        except ZeroDivisionError:
            raise DataError(i)
        except ValueError:
            break;
        else:
            if quotient == 0:
                break;
            else :
                print(quotient)
            temp = temp - int(div[i])*quotient


if __name__ == "__main__":
    num = int(input())
    div = input().split()
    quotient = 0
    try:
        robust_divide(num, div)
    except DataError as d:
        print(f"({d.data})")


