class DataError(Exception):
    pass

def robust(num, div):
    try:
        div = int(div)
        res = num//div
        if res == 0:
            raise DataError
    except ValueError:
        raise DataError
    return res

def main():
    num = int(input())
    dividers = input().split()
    cnt = 0
    for divider in dividers:
        if divider == '0':
            print(f"({cnt})")
            continue
        try:
            print(robust(num, divider))
            num = num % int(divider)
            cnt += 1
        except DataError:
            exit()

if __name__ == "__main__":
    main()
