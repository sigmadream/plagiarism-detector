import sys

def DataError(Exception):
    print("("+Exception+")")

def divisor(a, xs):
    total = a
    num = 0
    for x in xs:
        try:
            x = eval(x)
            if total // x == 0:
                sys.exit()
            else:
                print(eval('total // x'))
                total = total % x
                num = num + 1
        except ZeroDivisionError:
            DataError(str(num))
        except NameError:
            sys.exit()

if __name__ == "__main__":
    a = int(input())
    b = input().split()
    divisor(a, b)
