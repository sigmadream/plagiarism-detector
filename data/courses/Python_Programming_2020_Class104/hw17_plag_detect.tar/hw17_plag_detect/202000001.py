class DataError(Exception):
  def __init__(self, q):
    print(f"({q})")
    

dividend = int(input())
dividers_line = input()
dividers =list( map(int, dividers_line.split()))
Q = dividend
for i in dividers:
  try:
    print(int(Q/i))
    Q = Q - int(Q / i)*i
  except ValueError:
    raise DataError(Q)
  except ZeroDivisionError:
    continue
    #최예윤  
