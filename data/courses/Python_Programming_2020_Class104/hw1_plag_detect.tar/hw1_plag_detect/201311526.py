#coding: utf-8

a = int(input())
b = int(input())
c = int(a * a)
d = int(b * b)
if c > d:
    print(c - d)
else:
    print(d - c)
