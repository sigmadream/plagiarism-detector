#coding: utf-8

a= int(input())
b=int(input())
n1=a*a
n2=b*b

if n1>n2 :
    print(n1-n2)
else:
           print(n2-n1)
