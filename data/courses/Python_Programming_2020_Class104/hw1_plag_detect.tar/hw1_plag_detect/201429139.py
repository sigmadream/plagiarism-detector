a = int(input())
b = int(input())

if pow(a,2) > pow(b,2) :
    print(pow(a,2)-pow(b,2))
else:
    print(pow(b,2)-pow(a,2))
    
