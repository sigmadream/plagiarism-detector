#coding: utf-8

def sq_print(a,b):
    if a*a>b*b:
        print(a*a - b*b)
    else:
        print(b*b - a*a)
    
n = input()
n = eval(n)
m = input()
m = eval(m)
sq_print(n,m)


