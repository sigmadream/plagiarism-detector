a = int(input())
b = int(input())

if a > b:
    c = a-b
else:
    c = b-a

d = a+b

if d < 0:
    d = -d

print(c*d)
