a = int (input())
b = int (input())
c = a*a-b*b
if c > 0:
    print(c)
else:
    print(-c)
