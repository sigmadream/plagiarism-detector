a = int(input())
b = int(input())

aa = a**2
bb = b**2

result = aa-bb

if(result > 0):
    print(result)
else:
    print(-result)
