a = int(input())
b = int(input())
asq = int(a**2)
bsq = int(b**2)
if asq>bsq :
    print(asq-bsq)
else :
    print(bsq-asq)
        
