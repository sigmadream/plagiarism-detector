#coding: utf-8

a = int(input())
b = int(input())
print(abs(a*a-b*b))
