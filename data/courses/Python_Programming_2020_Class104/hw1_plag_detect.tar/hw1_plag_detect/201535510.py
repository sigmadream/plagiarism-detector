a = int(input())
b = int(input())

if a*a < b*b:
    print(b*b - a*a)
else:
    print(a*a - b*b)
