#coding: utf-8

def difference_square(a,b):
    c = a*a - b*b
    if c > 0:
        return c
    else:
        return -c

a = int(input())
b = int(input())
print(difference_square(a,b))
