a=int(input("정수값 n1 :"))
b=int(input("정수값 n2 :"))
c=abs(a**2-b**2)
print(c)
