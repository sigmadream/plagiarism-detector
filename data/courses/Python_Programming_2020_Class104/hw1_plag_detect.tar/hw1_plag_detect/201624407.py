a = int(input())
b = int(input())
asq = a*a
bsq = b*b
if asq >= bsq:
    print(asq-bsq)
else:
    print(bsq-asq)
