#coding: utf-8
import math
a=int(input("첫번째 정수: "))
b=int(input("두번째 정수: "))
if (a*a>b*b):
    print(a*a-b*b)
else:
    print(b*b-a*a)
