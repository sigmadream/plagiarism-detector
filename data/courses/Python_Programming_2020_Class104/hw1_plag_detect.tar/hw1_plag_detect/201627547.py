a = int(input())
b = int(input())
a1 = a*a
b1 = b*b
if a1 > b1:
    print(a1-b1)
else:
    print(b1-a1)
