#incoding: utf-8
a,b = int(input()), int(input())

if a*a < b*b : print( b*b - a*a )
else : print ( a*a - b*b )
