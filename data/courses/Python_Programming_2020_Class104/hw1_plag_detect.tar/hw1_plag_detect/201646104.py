a=abs(int(input()))
b=abs(int(input()))
if a<b:
    print(b*b-a*a)
elif a>b:
    print(a*a-b*b)

