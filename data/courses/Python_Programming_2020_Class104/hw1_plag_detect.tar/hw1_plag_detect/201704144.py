n1 = int(input())
n2 = int(input())
square_n1 = n1*n1
square_n2 = n2*n2
if square_n1 > square_n2:
    print(square_n1 - square_n2)
else:
    print(square_n2 - square_n1)
