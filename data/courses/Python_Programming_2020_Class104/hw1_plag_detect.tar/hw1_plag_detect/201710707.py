a = int(input())
b = int(input())
if ((a + b)*(a-b))>0:
    print((a + b)*(a-b))
else:
    print(-(a + b)*(a-b))
