a = int(input())
b = int(input())
a = a*a
b = b*b
if a > b:
    print(a - b)
else:
    print(b - a)
