a1 = int(input())
b1 = int(input())
a2 = a1**2
b2 = b1**2
if (a2>b2):
    print(a2-b2)
else:
    print(b2-a2)
