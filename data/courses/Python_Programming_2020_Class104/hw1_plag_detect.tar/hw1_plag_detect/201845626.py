#coding: utf-8

n1 = int(input())
n2 = int(input())

a = n1**2 - n2**2
b = n2**2 - n1**2

if n1**2 > n2**2:
    print(a)
else :
    print(b)
