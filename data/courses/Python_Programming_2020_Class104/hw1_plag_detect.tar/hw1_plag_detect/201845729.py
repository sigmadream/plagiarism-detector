n1 = input()
n2 = input()
print(abs(int(n1)**2 - int(n2)**2))