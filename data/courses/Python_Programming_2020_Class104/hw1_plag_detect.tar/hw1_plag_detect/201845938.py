#coding: utf-8

A = input()
B = input()
A = int(A)
B = int(B)
A = A**2
B = B**2
if A>B:
    print(A - B)
else:
    print(B - A)

"""
A = int(input())
B = int(input())
print(abs(a**2 - b**2))
"""
