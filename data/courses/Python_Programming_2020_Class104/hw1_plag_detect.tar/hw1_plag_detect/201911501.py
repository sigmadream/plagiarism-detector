#coding utf-8

n1 = int(input())
n2 = int(input())
if n1*n1>n2*n2 : print(n1*n1-n2*n2)
else : print(n2*n2-n1*n1)
