n1=int(input())
n2=int(input())

if n1**2 > n2**2 :
    print(n1**2-n2**2)
else :
    print(n2**2-n1**2)

