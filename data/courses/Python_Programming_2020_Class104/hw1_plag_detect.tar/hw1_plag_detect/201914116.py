#coding: utf-8

int1 = int(input())
int2 = int(input())

def sq_int(num):
    return num ** 2

int1 = sq_int(int1)
int2 = sq_int(int2)

if int1 > int2:
    diff = int1 - int2
else:
    diff = int2 - int1

print(diff)
