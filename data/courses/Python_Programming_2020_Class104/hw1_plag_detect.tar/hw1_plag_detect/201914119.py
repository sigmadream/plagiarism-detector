a=int(input())
b=int(input())

a1=a**2
b1=b**2

if a1>b1 :
    print(a1-b1)

else:
    print(b1-a1)
