n1 = int(input())
n2 = int(input())
N1 = n1**2
N2 = n2**2
if N1<N2:
    print(N2-N1)
else:
    print(N1-N2)