#coding utf-8

a=int(input())
b=int(input())
if a**2>b**2:
    print(a**2-b**2)
else:
    print(b**2-a**2)
