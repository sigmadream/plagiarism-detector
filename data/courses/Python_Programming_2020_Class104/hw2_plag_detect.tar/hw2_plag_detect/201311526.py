# coding: utf-8

def repeat(c1, c2, n):
    s = c1 * n
    print(s, end=c2)

a = int(input())
n = int(input())

while (a > 0):
    repeat("+---", "+\n", n)
    repeat("|   ", "|\n", n)
    a = a - 1
repeat("+---", "+", n)
