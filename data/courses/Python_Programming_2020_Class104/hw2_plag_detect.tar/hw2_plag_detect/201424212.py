#coding utf-8

def RepeatLine(char,num):    
    if char =="+---":
        string = char * num
        print(string+"+")
    if char =="|   ":
        string = char * num
        print(string+"|")
        
def board(row,col):
    while row>0:
        RepeatLine("+---",col)
        RepeatLine("|   ",col)
        row = row -1
    RepeatLine("+---",col)

row = int(input())
col = int(input())
if (row>0 and row<100) and (col>0 and col<100): 
    board(row,col)
