def line(col):
    while col>0:
        print('+---',end="")
        col=col-1    
    print("+")
    
def box(row,col):
    while col>0:
        print('+---',end="")
        col=col-1
    print("+")
    
def box2(row,col):
    while col>0:
        print('|   ',end="")
        col=col-1
    print("|")
  
    
           
n=int(input())
m=int(input())

while n>0:
 box(n,m)
 box2(n,m)
 n=n-1
 
line(m)
 
