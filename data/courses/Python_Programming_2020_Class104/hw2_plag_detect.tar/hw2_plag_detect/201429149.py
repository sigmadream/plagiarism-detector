a = 27
def repeat(c, n):
    print(c * n)

def line(col):
    print("+---" * col + "+")

def box(row , col):
        while row > 0:
            print("+---" * col + "+" )
            print("|   " * col + "|" )
            row = row - 1
        
        
n = int(input())
m = int(input())
box(n,m)
line(m)

