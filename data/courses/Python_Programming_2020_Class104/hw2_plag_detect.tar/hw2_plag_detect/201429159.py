#coding: utf-8

def makeSquares():
    row = int(input());
    column = int(input());

    while row <= 0 or row >= 100 or column <= 0 or column >= 100:
        print("행과 열의 크기를 1 이상 100 미만으로 다시 설정하십시오.");
        row = int(input());
        column = int(input());

    for i in range(0,row):
        for i in range(0,column):
            print("+---",end='');
        print("+");

        for i in range(0,column):
            print("|   ",end='');
        print("|");
    for i in range(0,column):
        print("+---",end='');
    print("+");
    
makeSquares();
