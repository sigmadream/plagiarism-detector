def column(col) :
    print('+---' * col, end='')
    print('+')

def pipe(col) :
    while (col >= 0) :   
        print("|", "      ", end="")
        col = col -1
    print()
    
def box(row, col) : 
    while (row >0):
        column(col)
        pipe(col)
        row = row -1
    column(col)
    
row = int(input())
col = int(input())
box(row,col)
