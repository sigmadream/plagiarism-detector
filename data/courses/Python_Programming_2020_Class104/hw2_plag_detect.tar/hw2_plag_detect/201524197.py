def rowline(col):
    print('+', end='')
    while col > 0 :
        print('---+', end='')
        col = col - 1
    print()

def colline(col):
    print('|', end='')
    while col > 0 :
        print('   |', end='')
        col = col - 1
    print()


def box(row, col):
    rowline(col)
    while row > 0 :
        colline(col)
        rowline(col)
        row = row - 1
   
n = int(input())
m = int(input())
box(n, m)