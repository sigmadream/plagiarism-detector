def makeboard(row, col):
    line_1 = "+---+"
    line_2 = "|   |"
    num = row*2 + 1
    
    while(col>1):
        line_1 = line_1 + "---+"
        line_2 = line_2 + "   |"
        col = col-1
        
    while(num>0):
        if(num%2 != 0):
            print(line_1)
        else:
            print(line_2)
        num = num-1
        

r = int(input())
c = int(input())

makeboard(r, c)
