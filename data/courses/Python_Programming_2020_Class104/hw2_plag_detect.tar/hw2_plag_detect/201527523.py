def row (a):
        print ("+---"*a, end = "")
        print ("+")

def column (a) :
    print ("|   "*a, end = "")
    print ("|")


def box (n,m) :
    while n>0 :
        row (m)
        column (m)
        n = n-1
    row(m)


n = int(input())
m = int(input())
box(n,m)
