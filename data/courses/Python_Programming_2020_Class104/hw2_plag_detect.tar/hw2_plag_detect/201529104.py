#coding: utf-8

def cell(row, column):
    print("+"+"---+"*column)
    while row > 0:
        print("|"+"   |"*column)
        print("+"+"---+"*column)
        row = row - 1

while True:    
    row = int(input())
    if (row>0) and (row<100):
        while True:
            column = int(input())
            if (column>0) and (column<100):
                break
        break
cell(row, column)
