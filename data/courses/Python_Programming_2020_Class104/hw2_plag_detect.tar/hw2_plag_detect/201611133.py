def just_line(n):
    while n > 0:
        print("+", end="")
        m = 3
        while m > 0:
            print("-", end="")
            m = m - 1
        n = n - 1
    print("+")

def box_in_line(n):
    while n > 0:
        print("|", end="")
        m = 3
        while m > 0:
            print(" ", end="")
            m = m - 1
        n = n - 1
    print("|")
    
def table(m, n):
    while m > 0:
        just_line(n)
        box_in_line(n)
        m = m - 1
    just_line(n)
    
m = int(input())
n = int(input())

table(m,n)
