#coding utf-8

def repeat(c,n) :
    s = c*n
    print(s)
m = int(input())
n = int(input())

for i in range(0,m)     :
    print("+---+",end='')
    repeat("---+",n-1)
    print("l   l",end='')
    repeat("   l",n-1)
print("+---+",end='')
repeat("---+",n-1)
