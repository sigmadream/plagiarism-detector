def repeat(c, n):
    print( c * n)

def line(m):
    print('+---' * m + '+')

    
def box(row, col):
    while row>0:
        line(m)
        print('|   ' * m + '|')
        row = row-1
    line(m)

n = int(input())
m = int(input())
box(n,m)

