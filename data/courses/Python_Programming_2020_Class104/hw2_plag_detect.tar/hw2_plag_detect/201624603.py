def Box(row,column):
    if (row>0 and column<100):
        
        while (row>0):
            print("+---"*column,end="")
            print("+")
            print("|   "*(column+1))
            row-=1
        print("+---"*column,end="")
        print("+")
    else:
        print("값을 잘못 입력하였습니다")
            
n=int(input("row을 입력: "))
m=int(input("column 입력: "))
Box(n,m)
