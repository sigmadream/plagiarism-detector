#coding: utf-8

def board(column,row):         
    
    while column > 0:
        print("+", end='')
        print("---+"*row)
        print("|", end='')
        print("   |"*row)
        column = column - 1
    print("+",end='')
    print("---+"*row)


    
C=int(input())
R=int(input())
board(C,R)
