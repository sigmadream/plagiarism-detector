def box(n, m):
    column(n)
    row(m)

def column(n):
    print("+", end='')
    print("---+"*n)

def row(m):
    while m>0:
        print("|", end='')
        print("   |"*n)
        print("+", end='')
        print("---+"*n)
        m=m-1

m = int(input())
n = int(input())

box(n, m)
