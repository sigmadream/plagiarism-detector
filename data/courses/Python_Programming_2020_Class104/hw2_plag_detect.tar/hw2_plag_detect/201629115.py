def print_row(col):
    count = 0
    rows_to_print = col * 2 + 1
    row_string = ''
    while count < rows_to_print:
        if count % 2 == 0:
            row_string += '+'
        else:
            row_string += '---'
        count = count + 1
    print(row_string)


def print_col(col):
    count = 0
    cols_to_print = col * 2 + 1
    col_string = ''
    while count < cols_to_print:
        if count % 2 == 0:
            col_string += '|'
        else:
            col_string += '   '
        count = count + 1
    print(col_string)


def print_board(n, m):
    count = 0
    while count < n * 2 + 1:
        if count % 2 == 0:
            print_row(m)
        else:
            print_col(m)
        count = count + 1


n = int(input())
m = int(input())

print_board(n, m)
