#coding: utf-8

def repeat1(c,n):
    print(c*n+'+')

def repeat2(c,n):
    print(c*n+'|')


def box(row,col):
    while row > 0:
        repeat1('+---',col)
        repeat2('|   ',col)
        row -= 1
    repeat1('+---',col)

n=int(input())
m=int(input())
box(n,m)
