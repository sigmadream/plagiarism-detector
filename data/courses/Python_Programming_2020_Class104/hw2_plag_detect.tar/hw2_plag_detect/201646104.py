#MakeaTable.py

def makeatable(line, row):
    while line>0:
        line = line - 1
        if row < 100:
            print('+---'*row + '+')
            print('|   '*row + '|')
        if line == 0: break
    print('+---'*row + '+')
    
line = int(input())
row = int(input())
makeatable(line, row)
