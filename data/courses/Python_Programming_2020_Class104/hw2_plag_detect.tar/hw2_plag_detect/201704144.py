#coding: utf-8

def firstline(n):
    while (n > 0):
        print("+---", end = "");
        n = n - 1;
    print("+");
    
def secondline(n):
    while (n > 0):
        print("|   ", end = "");
        n = n - 1;
    print("|");

def making_box(row,col):
    while (row > 0):
        firstline(col);
        secondline(col);
        row = row - 1;
    firstline(col);

n = int(input())
m = int(input())
making_box(n,m)
