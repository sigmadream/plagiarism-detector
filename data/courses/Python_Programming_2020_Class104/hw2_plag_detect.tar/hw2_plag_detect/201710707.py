def repeat(c, m):
    s = c * m
    print(s,end="")

n = int(input())
m = int(input())

for i in range (n):
    repeat('+---', m)
    print("+")
    repeat('|   ', m)
    print("|")

repeat('+---', m)
print("+")
