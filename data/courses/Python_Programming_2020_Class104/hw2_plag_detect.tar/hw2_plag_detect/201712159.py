#row = 행(가로) n
#col = 열(세로) m
def line(i):
      print('+',end="")
      print('---+'*i)

def row(i):
      print('|',end="")
      print('   |'*i)

def box(r, c):
      line(c)
      while(r>0):
            row(c)
            line(c)
            r-=1
n = int(input()) 
m = int(input())
box(n, m)




