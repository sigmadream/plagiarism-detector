#coding: utf-8

def line(l):
    print("+---"*l, end="")
    print("+")

def box(row, col):
    line(col)
    print("|   "*col, end="")
    print("|")
    line(col)
    while row > 1:
        print("|   "*col, end="")
        print("|")
        line(col)
        row=row-1

n=int(input())
m=int(input())

box(n, m)

