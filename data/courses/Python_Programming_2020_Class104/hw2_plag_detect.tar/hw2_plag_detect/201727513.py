def box(row, col):
    while row > 0:
        print('+---'*col, end='')
        print('+')
        print('|   '*col, end='')
        print('|')
        row = row - 1
    print('+---'*col, end='')
    print('+')

n = int(input())
m = int(input())
box(n, m)
    
