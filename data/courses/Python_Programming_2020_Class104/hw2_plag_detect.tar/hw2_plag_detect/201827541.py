# -*- coding: utf-8 -*-

def repeatstar (c, n):
    s = c*n
    print('+'+s)

def repeatbar (c, n):
    s = c*n
    print('|'+s)

n = int(input())
m = int(input())
repeatstar('---+',m)
num = 0
while(num!=n):
    repeatbar('   |',m)
    repeatstar('---+',m)
    num = num + 1

    
