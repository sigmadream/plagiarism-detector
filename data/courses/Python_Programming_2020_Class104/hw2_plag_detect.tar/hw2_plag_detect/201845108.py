def repeat(c,n):
    print(c*n)

def line():
    print('+---+',end="")

def box(row, col):
    if col>0:
        line()
        print('---+'*(col-1))
        while row>0:
            print('|   |',end="")
            print('   |'*(col-1))
            line()
            print('---+'*(col-1))
            row = row - 1
        
n = int(input())
m = int(input())

box(n,m)
            
            
