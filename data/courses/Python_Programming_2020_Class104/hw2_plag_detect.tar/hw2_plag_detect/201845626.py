#coding: utf-8

def repeat(row, col):
    if row == 0:
        return
    print(col * '+---'+'+')
    print(col * '|   '+'|')
    repeat(row-1,col)

def box(row, col): 
    repeat(row, col)
    print(col * '+---'+'+')

n = int(input())
m = int(input())
box(n, m)
