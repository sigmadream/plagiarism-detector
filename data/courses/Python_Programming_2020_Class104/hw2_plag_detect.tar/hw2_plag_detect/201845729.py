def box(row, col):
    while row > 0:
        print('+'+'---+'*col)
        print('|'+'   |'*col)
        row = row-1
    print('+'+'---+'*col)
    
n = int(input())
m = int(input())
box(n, m)