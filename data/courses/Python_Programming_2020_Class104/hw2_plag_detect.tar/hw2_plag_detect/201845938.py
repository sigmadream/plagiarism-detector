#coding: utf-8

def line(size): # +---+ size만큼 출력
    print('+', end="")
    print('---+'*size)

def blank(size):    # |   | size만큼 출력
    print('|', end="")
    print('   |'*size)

def box(row, col):
    line(col)   # 제일 위 +---+부분 출력하기
    while row > 0:  # line, blank 반복하기
        blank(col)
        line(col)
        row = row - 1

n = int(input())
m = int(input())
box(n, m)   # 정수 n, m 입력받기
