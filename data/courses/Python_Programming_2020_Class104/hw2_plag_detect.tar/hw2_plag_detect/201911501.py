def repeat1(c, n):
    s = c * n
    print(a+s)

def repeat2(c, n):
    s = c * n
    print(b+s)    
    
def function(s):
    i = 1
    while i <= s :
        repeat2("   |", n)
        repeat1("---+", n)
        i+=1
    
m = int(input())
n = int(input())

a = ("+")
b = ("|")
repeat1("---+", n)
function(m)
