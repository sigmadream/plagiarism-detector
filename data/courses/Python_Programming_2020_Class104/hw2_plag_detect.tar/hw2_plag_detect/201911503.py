def repeat(c,n):
    print(c*n)

def line(col):
    print('+---+'+'---+'*(col-1))
    

def blank(col):
    print('|   |'+'   |'*(col-1))
    

def box(row,col):
    while row>0 and col>0:
        line(col)
        blank(col)
        row=row-1
    line(col)

     
    
    

n = int(input())
m = int(input())
box(n,m)
