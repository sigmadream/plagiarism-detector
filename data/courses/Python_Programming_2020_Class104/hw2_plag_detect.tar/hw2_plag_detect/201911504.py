def box(row, col):
    def line():
        print('+---' * col + '+')
    while row > 0:
        line()
        print('|   ' * col + '|')
        row = row - 1
    line()

n = int(input())
m = int(input())
box(n, m)
