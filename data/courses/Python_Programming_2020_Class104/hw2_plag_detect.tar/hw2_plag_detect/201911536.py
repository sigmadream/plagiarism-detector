def repeat(c,n):
    print(c*n)


def line():
        print("+---+"+'---+'*(m-1))

def line2():
    print("|   |"+"   |"*(m-1))

def box(row,col):
    while row > 0 :
        line()
        line2()
        row = row-1
    line()

n=int(input())
m=int(input())
box(n,m)
