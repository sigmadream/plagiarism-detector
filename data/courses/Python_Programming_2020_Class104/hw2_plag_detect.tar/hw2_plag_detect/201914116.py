def line():
    print("+---", end="")

def line2():
    print("|   ", end="")

def box(n, m):
    while n > 0:
        m = m2
        while m > 0:
            line()
            m += -1
        print("+")
        m = m2
        while m > 0:
            line2()
            m += -1
        print("|")
        n += -1
        if n == 0:
            m = m2
            while m > 0:
                line()
                m += -1
            print("+")

n = int(input())
m = int(input())
m2 = m

box(n, m)
