def repeat(c,n):
    print(c*n,end='')

def box(row,col):
    while row>0:
        repeat('+---',col),print('+')
        repeat('|   ',col),print('|')
        row=row-1
    repeat('+---',col),print('+')

a=int(input())
b=int(input())
box(a,b)
