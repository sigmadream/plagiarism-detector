def bas(bas) :
    print('+---'*bas + '+')

def base(base) :
    print('|   '*base + '|')

def box(n, m) :
    while 0<n<100 and 0<m<100 :
        while n>0 :
            bas(m)
            base(m)
            n = n - 1
        bas(m)
        break;

n = int(input())
m = int(input())
box(n, m)
