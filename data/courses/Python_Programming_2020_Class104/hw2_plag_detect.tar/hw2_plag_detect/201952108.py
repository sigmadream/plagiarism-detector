def line(col):
    if col == 1:
        print('+---+')
    else:
        print('+', end = '')
        print('---+'*col)

def width(col):
    if col == 1:
        print('|   |')
    else:
        print('|', end = '')
        print('   |'*col)
        
def box(row,col):
    while row > 0:
        line(col)
        width(col)
        row = row - 1
    line(col)

n = int(input())
m = int(input())
box(n, m)
