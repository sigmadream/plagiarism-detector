#coding: utf-8

def repeat(c, n):
    s=c*n
    print(s,end='')
    print('+')

def line():
    repeat('+---', m)
    
def box(col, row):
    while col>0:
        line()
        print('|   '*m, end='')
        print('|')
        col = col - 1
    line()
    
n = int(input())
m = int(input())
box(n,m)

