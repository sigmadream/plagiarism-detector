# -*- coding: utf-8 -*-


def repeat(c, n):
    for i in range(n):
        print(c, end="")
    print()


def main():
    symbols = input()
    symlist = symbols.split()
    a = symlist[0]
    b = symlist[1:]
    n = 0
    for sym in b:
        k = int(sym)
        n = n + k
        repeat(a, n)


main()
