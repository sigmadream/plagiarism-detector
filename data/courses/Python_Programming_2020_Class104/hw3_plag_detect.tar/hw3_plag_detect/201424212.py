def repeat(char,num):
    print(char * num)

def main():
    Input = str(input(""))
    Inputlist = Input.split()
    char = Inputlist[0]
    num = 0
    
    for i in Inputlist[1:]:
        i = int(i)
        if i >= 0:
            num += i
            print(char*num)
    
main()


##def repeat(char,num):
##    for i in range(0,num):
##        print(char, end = '')
##    print()
##
##def main():
##    Input = input("")
##    Inputlist = Input.split()
##    char = Inputlist[0]
##    num = 0
##    
##    for i in Inputlist[1:]:
##        i = int(i)
##        if i >= 0:
##            num += i
##            repeat(char, num)
##    
##main()
