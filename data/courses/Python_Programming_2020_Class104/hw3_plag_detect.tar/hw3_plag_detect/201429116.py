
def repeat(c,n):
    
 for i in range(n):
     print(c,end="")
 print()




a = (input().split())

symbol=a[0]

A=len(a)

n=0 
for i in range(A-1):
   m=int(a[i+1])
   n=n+m
   repeat(symbol,n)






