ch=input().split()
list=[]
for i in ch:
    list.append(str(i))
list2 = list[1:]
sum = 0   
for n in list2:
    sum = sum + int(n)
    print(list[0] * sum)
