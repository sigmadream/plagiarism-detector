def main():
    sym = str(input())
    symlist = sym.split()
    m = 0
    n = 0
    sym2 = symlist[1:]
    C = symlist[0]
    for A in sym2:
            n = int(A)
            m = m + n
            for i in range(m) :
                print(C , end='')
            print()
main()
