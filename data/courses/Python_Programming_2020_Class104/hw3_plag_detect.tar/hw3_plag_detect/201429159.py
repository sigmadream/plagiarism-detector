# -*- coding: utf-8 -*-

def main():
    symbols = input()
    symlist = symbols.split()

    sym = symlist[0]
    length = len(symlist)

    for i in range(length - 1):
        symlist[i+1] = int(symlist[i+1])
        for j in range(i+1):
            print(sym*symlist[j+1], end='')
        print()

main()
