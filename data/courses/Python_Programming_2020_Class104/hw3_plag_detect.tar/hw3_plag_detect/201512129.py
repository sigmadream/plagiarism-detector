data  = input().split()
sym = data[0]
count = 0
for i in data[1:] :
    j = int(i)
    count += j
    print(sym * count)
