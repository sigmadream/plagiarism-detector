def PrintLine(symbol, num):
    for i in range(num):
        print(symbol, end='')
    print('')

def main():
    symbols = str(input())
    symlist = symbols.split()
    for i in range(1, len(symlist)):
        symlist[i] = int(symlist[i])
        if i > 1:
            symlist[i] += symlist[i-1]
        PrintLine(symlist[0], symlist[i])

main()
