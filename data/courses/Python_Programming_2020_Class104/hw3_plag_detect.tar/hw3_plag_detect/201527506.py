def print_line(num, char):
    for i in range(0, num):
        print(char, end = '')

def main():
    index = 1
    cumulate = 0
    line = input()
    list = line.split()
    for i in list:
        if index == 1:
            char = i
            index = 0
        else:
            cumulate = cumulate + int(i)
            print_line(cumulate, char)
            print()


main()
