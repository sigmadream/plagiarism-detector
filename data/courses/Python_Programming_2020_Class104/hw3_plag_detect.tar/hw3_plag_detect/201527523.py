def main() :
    s = input()
    slist = s.split()
    s_char = slist[0]
    n = 0
    for i in slist[1:] :
        n = n + int (i)
        print (s_char*n)
main()
