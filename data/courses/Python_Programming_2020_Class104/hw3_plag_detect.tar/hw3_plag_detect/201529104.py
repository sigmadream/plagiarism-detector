# -*- coding: utf-8 -*-

def main():
    data = input()
    symbol = data[0]
    sum = 0
    for NumCheck in data.split():
        if NumCheck.isdigit() == True:
            sum+=int(NumCheck)
            print(symbol*sum)

main()



