# -*- coding: utf-8 -*-

def repeating(c, n):
    print(c*n)

def main():
    information = input()
    infor_list = information.split()
    infor_size = len(infor_list)
    number_sum = 0
    
    for i in range(infor_size - 1): # (infor_size - 1): reapeating_size
        k = i + 1
        number_sum = number_sum + int(infor_list[k]) # int(infor_list[k]): string -> integer
        repeating(infor_list[0], number_sum)
        
main()
