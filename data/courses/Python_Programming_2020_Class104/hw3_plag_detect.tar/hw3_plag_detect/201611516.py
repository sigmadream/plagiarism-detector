def main() :
    keyword = input()
    kw = keyword.split(' ')
    key = kw[0]
    del kw[0]
    n = 0
    for rp in kw    :
        n = int(rp)+n
        for i in range (n) :
            print(key,end='')
        print()


main()
