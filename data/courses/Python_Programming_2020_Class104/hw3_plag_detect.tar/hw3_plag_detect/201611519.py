def main():
    n = 0
    a = input().split()
    b = ' '.join(a[1:])
    for i in range(len(b.split())):
        n += int(b.split()[i])
        for j in range(n):
            print(a[0], end='')
        print()

main()    


