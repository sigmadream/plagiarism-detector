# -*- coding: utf-8 -*-
def main():
    a = input().split()
    b = ""
    for i in range(len(a)):
        if i>0:
            a[i] = int(a[i])
            b = b + a[0]*a[i]
            print(b, end='')
            print()
main()
