
def main(input_value):
    sum=0
    for i in range(1,len(input_value)):
        if (int(input_value[i])<0):
            print("음수를 입력하였습니다")
            break
        else:
            sum+=int(input_value[i])
            print(input_value[0]*sum)

        
key=input().split()        
main(key)
