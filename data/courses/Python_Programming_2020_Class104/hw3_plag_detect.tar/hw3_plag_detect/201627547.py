#coding:utf-8

def main():
        
    data = input()
        
    splits = data.split()
    symbol = splits[0]

    line = 1
    stack = 0
        

    while line < len(splits):

        n = int(splits[line])
        stack = stack + n
        
        print(stack*symbol)
        
        line = line + 1
        
main()
