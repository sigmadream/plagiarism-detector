def main():
    a = input()
    alist = a.split()
    sym = alist[0]
    i=1
    num = 0
    while i<len(alist):
        num = num + int(alist[i])
        print(alist[0]*num)
        i=i+1
main()
