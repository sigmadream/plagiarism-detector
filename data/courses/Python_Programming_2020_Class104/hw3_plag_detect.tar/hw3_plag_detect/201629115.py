user_input = input().split()
input_length = len(user_input)
symbol_input = user_input[0]
accumulate_values = user_input[1: input_length+1]


def main(symbol, accumulate_list):
    accumulate_value = 0
    for current_value in accumulate_list:
        accumulate_value = accumulate_value + int(current_value)
        print_symbol(symbol, accumulate_value)


def print_symbol(symbol_to_print, number_of_symbols):
    print(symbol_to_print * number_of_symbols)


main(symbol_input, accumulate_values)
