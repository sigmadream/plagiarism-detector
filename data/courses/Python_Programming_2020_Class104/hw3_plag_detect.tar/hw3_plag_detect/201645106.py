def main():
    symbols = input()
    symlist = symbols.split()

    count = 0
    j = 0
    for i,sym in enumerate(symlist) :
        if(symlist[i][0] != '-'):
            if(len(symlist[i]) < 2):
               n = ord(sym)-48
            if(len(symlist[i]) ==2):
               n = (ord(symlist[i][1]) -48) + (ord(symlist[i][0])-48)*10
            if(i!=0):
                count = count + n
                for j in range(count) :
                    print(symlist[0], end='')
                print()

main()
