# -*- coding: utf-8 -*-

def main(sign): 
    symbol = sign.split()
    num = 0
    for k in symbol[1:]:
        while k in symbol:
            add = int(k)
            num = num + add
            print(symbol[0]*num)
            break
text = input()            
main(text)
