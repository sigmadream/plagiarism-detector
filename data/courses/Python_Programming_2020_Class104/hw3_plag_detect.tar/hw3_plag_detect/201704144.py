def main():
    making_graph = input()
    g_list = making_graph.split()
    num=0
    for sym in g_list[1:]:
        sym = int(sym)
        num = num + sym
        print(g_list[0]*num)

main()
