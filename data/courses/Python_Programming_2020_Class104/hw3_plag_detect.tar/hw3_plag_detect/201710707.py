def out(bol, n):
    print(bol*n)

def main():
    symlist = list(input().split())
    cnt = 0

    for i in range(1,len(symlist)):
        cnt += int(symlist[i])
        out(symlist[0], cnt)

main()
