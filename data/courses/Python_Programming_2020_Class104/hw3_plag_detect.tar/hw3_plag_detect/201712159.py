def main():
    count=0
    ar = list(input().split())
    symbol = ar[0]
    n = map(int, ar[1:])
    for i in n:
        count+=i
        print(symbol*count)
main()