#coding: utf-8

def main(symbols):
    symlist=symbols.split()
    char=symlist.pop(0)
    cumnum=0
    for symbol in symlist:
        cumnum+=int(symbol)
        for i in range(cumnum):
            print(char, end="")  
        print()  
            

symbols=input()
main(symbols)
