def main():
    symbol = input()
    symlist = symbol.split()
    c=str(symlist[0])
    symlist.pop(0)
    sum = 0
    for sym in symlist:
        n = int(sym)
        sum = sum + n
        for i in range(sum):
            print(c, end='')
        print()
        
    
main()
