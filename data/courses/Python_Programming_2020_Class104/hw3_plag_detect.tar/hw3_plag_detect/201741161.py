get = input().split()

def main():
    if len(get) == 2:
        print(get[0] * int(get[1]))
    elif len(get) == 3:
        print(get[0] * int(get[1]))
        print(get[0] * (int(get[1]) + int(get[2])))
    elif len(get) == 4:
        print(get[0] * int(get[1]))
        print(get[0] * (int(get[1]) + int(get[2])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3])))
    elif len(get) == 5:
        print(get[0] * int(get[1]))
        print(get[0] * (int(get[1]) + int(get[2])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4])))
    elif len(get) == 6:
        print(get[0] * int(get[1]))
        print(get[0] * (int(get[1]) + int(get[2])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5])))
    elif len(get) == 7:
        print(get[0] * int(get[1]))
        print(get[0] * (int(get[1]) + int(get[2])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6])))
    elif len(get) == 8:
        print(get[0] * int(get[1]))
        print(get[0] * (int(get[1]) + int(get[2])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7])))
    elif len(get) == 9:
        print(get[0] * int(get[1]))
        print(get[0] * (int(get[1]) + int(get[2])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7]) + int(get[8])))
    elif len(get) == 10:
        print(get[0] * int(get[1]))
        print(get[0] * (int(get[1]) + int(get[2])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7]) + int(get[8])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7]) + int(get[8]) + int(get[9])))
    else:
        print(get[0] * int(get[1]))
        print(get[0] * (int(get[1]) + int(get[2])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7]) + int(get[8])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7]) + int(get[8]) + int(get[9])))
        print(get[0] * (int(get[1]) + int(get[2]) + int(get[3]) + int(get[4]) + int(get[5]) + int(get[6]) + int(get[7]) + int(get[8]) + int(get[9]) + int(get[10])))
        
main()
