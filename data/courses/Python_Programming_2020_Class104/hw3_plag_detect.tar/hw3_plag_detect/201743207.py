#coding: utf-8

def repeat(c, n):
##     for i in range(n):
##        print(symbol, end="")
##     print()
    print(c*n)

def main():
    symbols = "! @ # $ % & *"
    symlist = symbols.split()
    for sym in symlist:
        n = int(input())
        m = int(input())
        n = n + m
        for i in range(n):
            print(sym, end='')
        print()

main()
