def main():
    symnum = input()
    numlist = symnum.split()
    sym = numlist[0]
    del numlist[0]
    nlen = len(numlist)

    for i in range(nlen):
        k=i+1
        for num in range(k):
            n = int(numlist[num])
            print(sym*n,end="")
        print()

main()
