def repeat(c,n):
    print(c*n, end = '')

def main():
    inputstr = str(input())
    ls = inputstr.split()
    sym = ls[0]
    for i in range(len(ls)-1):
        for j in range(i+1):
            repeat(sym, int(ls[j+1]))
        print ()
main()
