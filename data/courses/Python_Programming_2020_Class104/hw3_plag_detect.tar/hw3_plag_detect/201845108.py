a = [x for x in input().split()]

for i in range(1, len(a)):
    a[i] = int(a[i])

for i in range(1, len(a)-1):
    a[i + 1] += a[i]

for i in range(1, len(a)):
    for j in range(a[i]):
        print(a[0], end="")
    print()
