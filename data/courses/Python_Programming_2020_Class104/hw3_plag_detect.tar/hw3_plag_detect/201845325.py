# -*- coding: utf-8 -*-

def repeat(c,n):
    print(c*n)

def main():
    symbols = input()
    symlist = symbols.split()
    sym = symlist[0]
    sum = 0
    for i in symlist [1:]:
        sum = sum + int(i)
        repeat(sym,sum)
main()        
