def repeat(c, n):
    print(c * n)

def main():
    symbols = input().split()
    symbolNum = list(symbols)
    num = 0
    for i in range(1, len(symbolNum)):
        num += int(symbols[i])
        repeat(symbols[0], num)
    
main()
