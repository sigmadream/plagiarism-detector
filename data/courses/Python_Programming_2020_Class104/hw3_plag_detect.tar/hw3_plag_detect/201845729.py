def main():
    data = input().split()
    shape = data[0]
    n = 0
    
    for i in range(1,len(data)):
        n += int(data[i])
        print(shape * n)

main()