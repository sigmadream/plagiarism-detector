#coding: utf-8

def repeat(c, n):
    print(c * n)    # 문자 c를 n번만큼 반복 출력

def main():
    lst = input().split()   # 입력받기 (공백 기준으로 split)
    c = lst[0]  # 첫 번째 입력은 문자로
    lst[0:1]=[] # lst를 숫자만 있도록 변경(제거)
    sum = 0     # 초기화
    for num in lst:
        sum = sum + int(num)  # sum이 for문을 돌며 누적되도록
        repeat(c, sum)    # repeat 실행

main()