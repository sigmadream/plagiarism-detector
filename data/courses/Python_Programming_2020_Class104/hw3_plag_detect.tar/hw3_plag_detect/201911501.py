def main():
    def repeat(c,k):
        print(c*k)
    start=input()
    drive=start.split( )
    symbol=drive[0]
    numlist=drive[1:]
    m=0
    for n in numlist:
        m=int(m)+int(n)
        repeat(symbol,m)
   
main()
