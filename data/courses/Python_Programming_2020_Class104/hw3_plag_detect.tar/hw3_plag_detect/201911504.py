def main():
    a = input().split()
    s = 0
    for i in a[1:]:
        s = s + int(i)
        print(a[0] * s)

main()
