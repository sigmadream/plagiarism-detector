def repeat(c,n):
    for i in range(n):
        print(c, end="")
    print()


def main():
    a=input()
    symlist= a.split()
    sym=symlist[0]
    b=symlist[1:]
    x=0
    for i in b:
        x=x+int(i)
        repeat(sym,x)
        
main()
