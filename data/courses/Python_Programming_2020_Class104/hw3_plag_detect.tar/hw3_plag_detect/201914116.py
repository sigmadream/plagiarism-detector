def main():
    inputlist = list(input().split())
    symbol = inputlist[0]
    graph = inputlist[1:]
    cumloop = 0

    for cum in graph:
        i = 0
        loop = int(cum)
        cumloop += loop
        while(i < cumloop):
            print(symbol, end = '')
            i += 1
        print("")

main()
