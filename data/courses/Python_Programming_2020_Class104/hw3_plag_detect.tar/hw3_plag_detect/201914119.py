def main():
    a=input()
    list=a.split()
    f=list[0]
    s=0
    for b in list[1:]:
        s+=int(b)
        for k in range(s):
            print(f,end='')
        print()
main()

