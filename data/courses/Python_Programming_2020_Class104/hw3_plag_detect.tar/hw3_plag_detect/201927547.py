def count(lis) :
    length = 0
    for pattern in lis :
        length = length + 1
    return length

def main(patte, length) :
    count(patte)
    pattern = patte[0]
    sum = 0
    for j in range(1, length) :
        sum = sum + int(patte[j])
        print(pattern*sum)
    

lis = input()
patte = lis.split()
length = count(patte)

main(patte, length)