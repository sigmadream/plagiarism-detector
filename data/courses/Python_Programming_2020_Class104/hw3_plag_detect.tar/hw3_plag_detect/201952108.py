def repeat(symbol, time):
    for i in range(time):
        print(symbol, end ='')
    print()
        
def main():
    symbols = input()
    symlist = symbols.split()
    symbol = symlist[0]
    numlist = symlist[1:]
    time = 0
    for value in numlist:
        intValue = int(value)
        time = time + intValue
        repeat(symbol, time)
    
main()
