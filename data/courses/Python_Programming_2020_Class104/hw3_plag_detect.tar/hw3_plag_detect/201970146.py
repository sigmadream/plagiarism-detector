#coding:utf-8


def main():
    symbol = m[0]
    symlist=list(m.split())
    symlist.remove(symlist[0])
    symlist=[int (i) for i in symlist]
    sym=0
    for i in symlist:
        sym=sym+i
        print(symbol*sym)

m = input()
main()
