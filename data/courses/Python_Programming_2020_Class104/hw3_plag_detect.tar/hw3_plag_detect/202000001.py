# -*- coding: utf-8 -*-

def main():
    inputs = input()
    inpList = inputs.split()
    seqSum = 0
    for i in range(1,len(inpList)):
        seqSum += int(inpList[i])
        for j in range(seqSum):
            print(inpList[0], end="")
        print()

main()