def str_split(string):
    str_split = string.split()

    return str_split


def str_upper_lower(string):
    result = ""
    if len(string) >= 5:
        result = result + string[0].upper()
        for i in range(1,len(string)):
            result += string[i].lower()
        return result
            
    elif len(string)>=0:
        for i in range(0,len(string)):
            result += string[i].lower()
        return result

if __name__ == '__main__':
    string = str(input(""))
    if len(string) >=0 :
        str_split = str_split(string)
        
        sample = []
        for i in str_split:
            sample.append(str_upper_lower(i))
        result= " ".join(sample)
        print(result)
