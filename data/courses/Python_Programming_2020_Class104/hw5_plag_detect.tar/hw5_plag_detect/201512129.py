def capitalize(word_list) :
    name = ""
    for i in word_list :
        if len(i) >= 5 :
            name += i[0].upper() + i[1:] + " "
        else :
            name += i + " "
    return name

def main() :
    word = input().split()
    print_word = capitalize(word)
    print(print_word)

if __name__ == "__main__" :
    main() 
