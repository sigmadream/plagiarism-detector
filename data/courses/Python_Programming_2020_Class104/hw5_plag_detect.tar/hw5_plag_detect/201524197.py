def maskedWord (word) :
    wordList = list(word)
    for i in range(len(wordList)) :
        if wordList[i] == ' ' :
            wordList[i] = '_'
    return "".join(wordList)

if __name__ == "__main__" :
    word = str(input())
    print(maskedWord(word))