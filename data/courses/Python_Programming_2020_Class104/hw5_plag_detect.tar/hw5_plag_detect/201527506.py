def is_five(s):
    if len(s)>=5:
        return True
    else:
        return False

def first_upper(s):
    str = ""
    for i in range(len(s)):
        if i == 0:
            str += s[i].upper()
        else:
            str += s[i]
    return str

if __name__ == "__main__":
    str = input()
    str_list = str.split(' ')
    ans = ""
    for i in range(len(str_list)):
        if is_five(str_list[i]):
            ans += first_upper(str_list[i])
        else:
            ans += str_list[i]
        if i < len(str_list)-1:
            ans += ' '

    print(ans)
            

