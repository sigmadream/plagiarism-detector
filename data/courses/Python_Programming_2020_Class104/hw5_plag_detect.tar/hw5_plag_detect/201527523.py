# coding: utf-8

def lang_split(s) :
    words = s.split()
    return words

def up(w) :
    words = w
   for i in range(len(words)) :
       if len(words(i)) > 4 :
           slist= split.words[i]
           slist[0].upper()
           i = i+1
           continue
        i = i+1
        continue
    return(" ".join(words))


if __name__ == "__main__" :
    lang = input()
    words = lang_split(lang)
    print(up(words))