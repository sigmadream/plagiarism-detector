
def first_capital(string):
    convert = ""
    for i in range(len(string)):
        if i == 0:
            convert = convert + string[i].upper()
        else:
            convert = convert + string[i]
    return convert
        
def convert_list(string_list):
    convert = []
    for i in range(len(string_list)):
        if len(string_list[i]) < 5:
            convert.append(string_list[i])
        else:
            convert.append(first_capital(string_list[i]))
    return convert

if __name__ == "__main__":
    string = input()
    string_list = string.split()
    final_list = convert_list(string_list)

    for i in range(len(final_list)):
        print(final_list[i], end="")
        if i < len(final_list)-1:
            print(' ',end="")
