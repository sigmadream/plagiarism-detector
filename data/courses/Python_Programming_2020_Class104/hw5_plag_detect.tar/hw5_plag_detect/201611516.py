lang=input()
lang_s=lang.split()
k = ""

k=""
for i in lang_s:
    if len(i)>=5:
        k+=i[0].upper()
        k+=i[1:].lower()
        k+=" "
    else :
        k+=i.lower()
        k+=" "

if __name__ == "__main__":   
    print(k)
