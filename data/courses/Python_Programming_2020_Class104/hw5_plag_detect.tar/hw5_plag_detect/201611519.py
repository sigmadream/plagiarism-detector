lang=input()
lang_a=lang.split()
k = ""

for i in lang_a:
    if len(i)>=5:
        k+=i[0].upper()
        k+=i[1:]
        k+=" "
    else :
        k+=i
        k+=" "

if __name__ == "__main__":   
    print(k)
