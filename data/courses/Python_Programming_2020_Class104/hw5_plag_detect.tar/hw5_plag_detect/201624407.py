#coding: utf-8

def split_str(r):
    r = r.split(' ')
    return r
def make_upper(s):
        cnt = 0
        for i in s:
            if len(s) >= 5 and cnt==0:
                s = s.replace(i, i.upper(), 1)
                cnt+=1
        return s
if __name__ == "__main__":
    ls = input()
    newls = ''
    for i in split_str(ls):
        newls = newls + make_upper(i) + " " 
    print(newls.rstrip())
