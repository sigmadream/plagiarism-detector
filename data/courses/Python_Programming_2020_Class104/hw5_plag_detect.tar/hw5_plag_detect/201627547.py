def capitalize(letter):
    new_letter=""
    for i in range(len(letter)):
        if i==0:
            new_letter = new_letter + letter[0].upper()
        else:
            new_letter = new_letter +letter[i]
    return new_letter



def change(text):
    joins=[]
    for i in text:
        if len(i) >=5 :
            joins = joins + [capitalize(i)]
        else:
            joins = joins + [i]
    final = " ".join(joins)
    return final


if "__main__" == __name__:
    a = input()
    b = a.split()
    c = change(b)

    print(c)
    
