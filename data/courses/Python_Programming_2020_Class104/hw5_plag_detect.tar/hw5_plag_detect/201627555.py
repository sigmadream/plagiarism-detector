def capa(xx):
    for i in xx:
        if (len(i)>=5):
            print(i.capitalize(), end='')
            if (i != xx[len(xx)-1]):
                print(' ', end = '')
        else :
            print(i, end='')
            if (i != xx[len(xx)-1]):
                print(' ', end = '')




if __name__ =='__main__':
    text = input()
    xx = text.split(' ')
    capa(xx)
