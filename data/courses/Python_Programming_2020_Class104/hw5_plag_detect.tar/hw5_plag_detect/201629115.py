user_string = input()
output_string = ''

split_string = user_string.split(' ')

def capitalize(word):
    return word[0:1].upper() + word[1 : len(word) + 1]

def add_space(word):
    return word + ' '


if __name__ == "__main__":
    count = 1
    for word in split_string:
        if len(word) >= 5:
            if count == len(split_string):
                output_string += capitalize(word)
                count = count + 1
            else:
                output_string += add_space(capitalize(word))
                count = count + 1
        else:
            if count == len(split_string):
                output_string += word
                count = count + 1
            else:
                output_string += add_space(word)
                count = count + 1
                
print(output_string)