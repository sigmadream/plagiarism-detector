# -*- coding: utf-8 -*-

sentence = input()


def capital(sentence):
    part = sentence.split()
    num = len(part)
    for i in range(num):
        if len(part[i]) >4:
            part[i]=part[i].capitalize()
    print(" ".join(part))

capital(sentence)
