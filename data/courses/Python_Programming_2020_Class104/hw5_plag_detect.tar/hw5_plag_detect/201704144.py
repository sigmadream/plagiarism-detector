# coding: utf-8

def capitalize(cr):
    name = ""
    lst = cr.split()
    for i in lst:
        if (len(i)>=5):
            name += i[0].upper()
            name += i[1:]
        else:
            name += i
        name += " "
    return name

if "__main__" == __name__:
    lang = input()
    print(capitalize(lang))
