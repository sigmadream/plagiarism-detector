def cap(w):
    if len(w) >= 5 :
        w[0]=w[0].upper()
    return w

def out(w):
    for i in w:
        print(i,end="")
    print(end=" ")

if __name__ == "__main__":
    sen = input()
    words = sen.split()
    
    for word in words:
        wd = list(word)
        wd = cap(wd)
        out(wd)
