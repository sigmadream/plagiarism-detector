def capital(lang):
	d_word = lang.split()
	st=[]
	for i in range(len(d_word)):
		name=""
		for j in range(len(d_word[i])):
			if len(d_word[i])>=5:
				if j==0:
					name+=d_word[i][0].upper()
				else:
					name+=d_word[i][j].lower()
			else:
				name+=d_word[i][j].lower()	
		st.append(name)
	sentence = " ".join(st)
	print(sentence)

if __name__ == "__main__":
	lang = input()
	capital(lang)

