def fir(n):
    loc = ""
    for j in range(len(n)):
        if j == 0:
            loc += n[j].upper()
        else:
            loc += n[j]
                 
    return loc


def non(n):
    loc=""
    loc += n+" "
    
    return loc


if __name__ =='__main__':
    line = input()
    list = line.split()
    A=""
    for i in range(len(list)):
        if len(list[i]) >= 5:
            A+=fir(list[i]) + " "
            
        else:
            A+=non(list[i])
            
    A = A[:-1]
    print(A)
