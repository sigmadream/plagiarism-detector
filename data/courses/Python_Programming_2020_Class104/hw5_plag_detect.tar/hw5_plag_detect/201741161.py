a = input()

new_a = a.title()
    
print(new_a)

