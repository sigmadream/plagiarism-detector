def lancheck(langlist):
    for i in range(len(langlist)):
        if len(langlist[i]) >= 5:
            lan = langlist[i][0].upper() + langlist[i][1:]
            langlist[i] = lan
    return langlist

def lansplit(lang):
    langlist = lang.split()
    return langlist

    



if __name__ == "__main__":
    lang = input()
    langlist = lansplit(lang)
    langlist = lancheck(langlist)
    print(" ".join(langlist))
        


        
        
        
