#-*- coding: utf-8 -*-

def toupper(word):
    first = word[0]
    return first.upper()

def maketemp(i):
    temp = list()
    first = toupper(i)
    temp.append(first)
    temp.append(i[1:])
    return ''.join(temp)

def makeresult(ls):
    result = list()
    for i in ls:
        if len(i) < 5:
            result.append(i)
        if len(i) >= 5:
            temp = maketemp(i)
            result.append(temp)
    return result

if __name__=='__main__':
    sentence = str(input())
    ls = sentence.split(" ")
    result = makeresult(ls)
    print(' '.join(result))
            
