a = input().split()
name=""
for i in range(len(a)):
    if len(a[i])>=5:
        name += a[i].upper()+" "
        
    else:
        name += a[i]+" "
print(name)
