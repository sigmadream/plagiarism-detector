sentence = input()
words = sentence.split()

for i in range(len(words)):
    if len(words[i]) >= 5:
        words[i]=words[i][0].upper()+words[i][1:]
print("".join(words))
