


s = input()
capitalized_s = " ".join([word.capitalize()
for word in s.split(" ")])

if len(s) < 5 :
    s.lower()

if "__main__" == __name__:
    print(capitalized_s)


