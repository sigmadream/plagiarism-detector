def capital(w):    
    ws = w.split(" ")

    result = ""
    for i in range(len(ws)):
        if len(ws[i])>=5:
            af = ws[i].capitalize()
            result += af
        else:
            af = ws[i].lower()
            result += af
        if i != len(ws)-1:
            result += " "
            # print(result.split(""))
    
    return print(result)

if __name__ == "__main__":
    words=input()
    capital(words)
