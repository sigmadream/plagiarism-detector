def capi(s):
    return s[0].upper()+s[1:]


def main():
    line = input()
    lst = line.split()

    capiline = ""

    for i in range(len(lst)):
        if len(lst[i]) < 5:
            capiline += lst[i]
        else:
            capiline += capi(lst[i])
        if i < len(lst) - 1:
            capiline += " "

    print(capiline)


if __name__ == "__main__":
    main()
