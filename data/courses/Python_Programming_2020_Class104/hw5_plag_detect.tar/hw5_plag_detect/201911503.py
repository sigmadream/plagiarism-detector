

def lspt(a):
    if __name__ == "__main__":
        xlist=""
        alist=a.split(" ")
        for i in range(len(alist)):
            if len(alist[i])>=5:
                xlist += alist[i][0].upper()
                for b in range(1,len(alist[i])):
                    xlist += alist[i][b]
                if i != len(alist)-1:
                    xlist += " "
                
                
            else:
                xlist += alist[i][0].lower()
                for b in range(1,len(alist[i])):
                    xlist += alist[i][b]
                if i != len(alist)-1:
                    xlist += " "

    print(xlist)



n=input()

lspt(n)
