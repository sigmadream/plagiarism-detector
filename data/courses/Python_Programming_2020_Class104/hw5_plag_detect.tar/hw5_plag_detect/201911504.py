word = input()
sword = word.split()
lsword = list(sword)


name = ""
for i in range(len(lsword)):
    if len(lsword[i])>4:
        name = name + lsword[i].capitalize() + " "
    else:
        name = name + lsword[i].lower() + " "

print(name.strip())
