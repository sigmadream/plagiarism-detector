def capitalize(a):
    symlist=a.split()
    name=""
    for i in range(len(symlist)):        
        if len(symlist[i])>=5:
            name=name+symlist[i][0].upper()
            name=name+symlist[i][1:].lower()+" "

        else:
            name=name+symlist[i].lower()+" "
    print(name)
        
if "__main__"==__name__:
    a=input()
    capitalize(a)
