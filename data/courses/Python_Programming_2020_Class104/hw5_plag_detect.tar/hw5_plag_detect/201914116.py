# -*- coding: utf-8 -*-

def length(s):
    if len(s) >= 5:
        return True
    else:
        return False

def upper(lang):
    lang = list(lang)
    lang[0] = lang[0].upper()
    lang = "".join(lang)
    return lang

def lower(lang):
    return lang

if __name__ == "__main__":
    s = input()
    lang = ""
    output = ""
    for i in range(len(s)):
        if s[i] != " ":
            lang += s[i]
        else:
            if (length(lang)):
                output += upper(lang)
                output += " "
                lang = ""
            else:
                output += lower(lang)
                output += " "
                lang = ""
                
    if (length(lang)):
        output += upper(lang)
        lang = ""
    else:
        output += lower(lang)
        lang = ""

    print(output)
            
        
