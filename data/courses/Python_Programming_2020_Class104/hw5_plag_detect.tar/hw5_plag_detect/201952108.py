def main():
    line = input()
    line_list = line.split()
    lang = make_lang(line_list)
    print(lang)

def make_lang(line_list):
    lang = ''
    for word in line_list:
        if (len(word) >= len(line_list)):
            lang += word[0].upper()+word[1:] + ' '
        elif (len(word) < len(line_list)):
            lang += word+ ' '
    lang = lang.strip()
    return lang

if __name__=="__main__":
    main()
