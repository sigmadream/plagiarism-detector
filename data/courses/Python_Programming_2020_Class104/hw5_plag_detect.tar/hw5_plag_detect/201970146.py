def capitalize():
    for i in range(0,len(a)):
        if len(a[i]) < 5 :
            c.append(a[i])
        else:
            b=str(a[i])
            b=(str(b[0].upper())+str(b[1::]))
            c.append(b)

def de():
    a=input().split()
    return a

if __name__ == "__main__":
    a=de()
    c=[]
    capitalize()
    print(' '.join(c))
