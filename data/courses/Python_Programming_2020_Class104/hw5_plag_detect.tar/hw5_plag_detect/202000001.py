def lang(a):
    b = ""
    for i in range(len(a)):
        if(a[i].isalpha()):
            b += a[i]
        else:
            b += "_"
        i += 1
    return b
 
def capital(b):
    c = 0
    name = ""
    for i in range(len(b)):
        if(b[i].isalpha()):
            name = name + b[i]
            c += 1
            if(c >= 5):
                name = name[:i-c+1] + b[i-c+1].upper() + name[i-c+2:]
                c = 0
        else:
            name = name + b[i]
            c = 0
    print(name)
 
if __name__ == "__main__": 
    print("Enter the lang : ",end = "")
    a = input()
    capital(lang(a))