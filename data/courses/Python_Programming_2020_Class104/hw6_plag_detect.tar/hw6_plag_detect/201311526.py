# coding: utf-8

def wlen(a):
    b = a.split()
    c = "".join(b)
    return len(c)





if __name__ == "__main__":
    a = input()
    b = input()
    c = wlen(a)
    k = len(set(b)) / c
    print(f"{k:5.2f}", k)
