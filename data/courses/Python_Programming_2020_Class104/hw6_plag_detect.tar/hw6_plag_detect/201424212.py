def str_count(string):
    count_dic ={}
    for i in string:
        if i.isalpha():
            count_dic[i] = string.count(i)
        else:
            count_dic[i] = -1
    return count_dic

def all_string_count(string):
    count = 0
    for i in string:
        if i.isalpha():
            count +=1
    return count
            

def freq(c,s):
    return c/s

if __name__ == '__main__':
    string = input()
    string = string.lower()
    
    count_dic = str_count(string)

    values = list(count_dic.values())
    maxcnt = max(values)
    keys = list(count_dic.keys())
    all_count = all_string_count(string)

    print("%.2f"%freq(maxcnt,all_count))
