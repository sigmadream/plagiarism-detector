def calcluate():
    a= input()
    str=a.upper()
    list =[]
    n=0
    for  i in str:
        if (i.isalpha()):
            list.append(str.count(i))
            n += 1
    max_ = max(list)
    value =max_ /n
    print(f"{value:.2f}")
 
   
if __name__== "__main__":
      calcluate()
    
   
