def frate():
    a = input()
    ustr = a.upper()
    list_ = []
    n = 0
    for i in ustr:
        if(i.isalpha()):
            list_.append(ustr.count(i))
            n += 1
    max_ = max(list_)
    value = max_/n
    print(f"{value:.2f}")

if __name__ == "__main__":
    frate()