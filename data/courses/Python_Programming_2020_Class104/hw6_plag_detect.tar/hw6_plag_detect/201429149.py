if __name__ == "__main__" :
    line = str(input())
    ustr = line.upper()
    freq = []
    for c in ustr:
        n = ustr.count(c)
        if c.isalpha():
            freq.append(n)
        else :
            freq.append(-1)

    maxcnt = max(freq)
    line2 = line.split(" ")
    line2 = "".join(line2)
    count = 0
    for i in line2:
        if i.isalpha() :
            count += 1
    value = maxcnt / count
    print( f"{value:.2f}" )
