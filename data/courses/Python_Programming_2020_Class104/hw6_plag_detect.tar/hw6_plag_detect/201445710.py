for n in range(1, 10):
 str = "Hello Python"
 cnt = str.count(str[0])
 freq = cnt / str
 print(f"(freq:.2f)")
