if __name__ == "__main__" :
    in_line= input()
    line = in_line.upper()
    freq = {}
    alpha_count = 0

    for i in line :
        if i.isalpha() :
           freq[i] = line.count(i)
           alpha_count += 1
    max_freq = max(freq.values())

    for key in sorted(freq) :
        if freq[key] == max_freq :
            freq_alpha = key
            break
    frate = line.count(freq_alpha) / alpha_count
    print(f"{frate:.2f}")
