def frequency(mystring) :
    mystring = mystring.lower()
    s = set(mystring)
    maxCount = 0
    alphalen = 0

    for i in mystring :
        if i.isalpha() :
            alphalen = alphalen + 1

    for x in s :
        if x.isalpha() :
            current = mystring.count(x)
            if( current > maxCount ) :
                maxCount = current

    return maxCount / alphalen

if __name__=="__main__" :
    mystring = str(input())
    print('%.2f' %frequency(mystring), end='')