def make_low(str):
    str_low = ""
    for c in str:
        if c.isalpha():
            str_low = str_low + c.lower()
    return str_low


def max_count(str_low):
    alpha_list = []
    for i in range(0, 26):
        alpha_list.append(0)
        
    for c in str_low:
        alpha_list[ord(c)-97]+=1
    return max(alpha_list)

if __name__ == "__main__":
    str = input()
    str_low = make_low(str)
    ans = max_count(str_low) / len(str_low)
    print(f"{ans:0.2f}")
