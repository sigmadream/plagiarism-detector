# coding: utf-8

def freq(s) :
    up_s =s.upper()
    s_dic = {}
    num = 0
    for c in up_s:
        if c.isalpha() :
            s_dic[c] = up_s.count(c)
            num +=1

    maxcnt = max(s_dic.values())
    return maxcnt/num




if __name__ =="__main__" :
    s = input()
    result = freq(s)
    print(f"{result:.2f}")