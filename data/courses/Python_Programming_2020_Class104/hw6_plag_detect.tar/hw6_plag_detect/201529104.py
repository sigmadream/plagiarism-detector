# -*- coding: utf-8 -*-
def newprint(value):
    print(f"{value:3.2f}")

def frequency_rate(line):
    ustr = line.upper()
    count = {}
    numchar = 0
    
    for c in ustr:
        if c.isalpha():
            count[c] = ustr.count(c)
            numchar = numchar + 1
    maxcnt = max(count.values())
    for key in sorted(count.keys()):
        if count[key] == maxcnt:
            break
    return maxcnt/numchar


if __name__ == "__main__":
    word = input()
    newprint(frequency_rate(word))
