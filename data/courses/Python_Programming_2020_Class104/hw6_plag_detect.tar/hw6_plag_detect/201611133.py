def length(string):
    string_length = 0
    for i in range(len(string)):
        if string[i].isalpha() == True:
            string_length = string_length + 1
    return string_length

def frequency(string):
    string = string.upper()
    string_frequency = 0
    for i in range(len(string)):
        if string[i].isalpha() and (string.count(string[i]) > string_frequency):
            string_frequency = string.count(string[i])
    return string_frequency

if __name__ == "__main__":
    string = input()
    result = frequency(string)/length(string)
    print(f"{result:4.2f}")
