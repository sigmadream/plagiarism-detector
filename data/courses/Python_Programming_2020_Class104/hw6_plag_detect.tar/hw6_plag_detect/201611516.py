words=input()
ims_wor=""
max_h=0
value=0
for i in range(len(words)) :
    ims_wor=words[i]
    for j in range(len(words)):
        max_h=0
        if words[j]==ims_wor :
            max_h+=1
    print(max_h)
print(f"{value:3.2f}")
