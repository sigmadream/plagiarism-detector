

def frate(a):
    most = a.count(a[0])
    b = 0
    for i in range(len(a)):
        if b < a.count(a[i]):
            b = a.count(a[i])
        else:
            most = b
    print(f"{most/len(a):.2f}")
    print(most)


if __name__ == "__main__":
    a = input().replace(" ","")
    frate(a)
    
