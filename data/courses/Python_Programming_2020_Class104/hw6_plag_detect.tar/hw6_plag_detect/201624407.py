if __name__ == "__main__":
        line = input()
        ustr = line.upper()
        freq = []
        for c in ustr:
                n = ustr.count(c)
                if c.isalpha():
                        freq.append(n)
        maxcnt = max(freq)

        freqR = maxcnt/len(freq)
        print(f"{freqR:3.2f}")
