#use __name__
# use f- string


if __name__=="__main__":
    word=input("입력하세요: ")
    space_cnt=0         # 공백 문자 개수
    word_cnt=len(word)         # 입력 문자 길이
    mystr=word.upper()
    mylist=[]
    for c in mystr:
        if c.isalpha():
            mylist.append((mystr.count(c),c))
    mylist.sort()
    mylist.reverse()
    maxcnt=mylist[0][0]        # 문자의 최대 개수
    for ch in word:
        if ch==" ":
            space_cnt+=1
    word_cnt-=space_cnt     # 공백 문자를 제거한 문자 길이
    result=maxcnt/word_cnt
    print(f"{result:.2f}")

    
