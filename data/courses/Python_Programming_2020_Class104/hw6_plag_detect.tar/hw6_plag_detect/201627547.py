def freq(a):
    alphabet=a.upper()
    flow = list()

    for i in alphabet:
        if i.isalpha():
            flow.append(alphabet.count(i))
        else:
            flow.append(-1)
    return  max(flow)

            

def num(a):
    list_a = a.split()
    r = 0
    b = ''.join(list_a)
    for i in list(b):
        if i.isalpha():
            r = r + 1
    return r

if __name__ == "__main__":

    letters = input()
    c = freq(letters)
    s = num(letters)

    print(f"{c/s:0.2f}")
