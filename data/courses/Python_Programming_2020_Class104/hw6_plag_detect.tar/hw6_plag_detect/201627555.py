#def ab(text):


if __name__ == '__main__':
    text = list(input())
    i = 97
    s= 0
    while (i <=122):
        s = s + text.count(chr(i))
        i = i +1
  
    c = max(text.count('a'), text.count('b'), text.count('c'), text.count('d'), text.count('e'), text.count('f'), text.count('g'), text.count('h'), text.count('i'), text.count('j'), text.count('k'), text.count('l'), text.count('m'), text.count('n'), text.count('o'), text.count('p'), text.count('q'), text.count('r'), text.count('s'), text.count('t'), text.count('u'), text.count('v'), text.count('w'), text.count('x'), text.count('y'), text.count('z'))
    ans=float(c)/float(s)
    print(f"{ans:.2f}")