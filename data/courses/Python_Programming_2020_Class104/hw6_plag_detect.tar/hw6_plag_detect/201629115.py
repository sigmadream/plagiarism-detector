def find_most_frequent(string):
    counts = []
    for ch in string:
        counts.append(string.count(ch))
    return max(counts)


if __name__ == "__main__":
    user_input = input()

    words = []
    for ch in user_input:
        if ch != ' ' and ch.isalpha():
            words.append(ch.lower())

    most_frequent = find_most_frequent(words)
    len_of_words = len(words)
    frequent_rate = most_frequent / len_of_words
    print(f"{frequent_rate:.2f}")
