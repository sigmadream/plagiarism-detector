def look(a):
    lis = list(a)
    while ' ' in lis:
        lis.remove(' ')
    num = len(lis)
    y = 2/num
    print(f'{y:0.2f}')

if __name__=="__main__":
    a=input()
    look(a)
