def freq_Rate(s):
    lst = s.split()
    num = 0
    freq = 1
    alpha = []
    for i in lst:
        for j in i:
            if j.isalpha():
                alpha.append(j)
                num += 1
    print(alpha)
    # value = freq/num
    # print(f"{value:.2f}")

if __name__ == "__main__":
    s = input()
    freq_Rate(s)
