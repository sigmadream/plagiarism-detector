def count(c,s):
    fre = 0

    for i in s:
        if c==i:
            fre = fre+1

    return fre

if __name__ == "__main__":
    str = input()
    str = str.upper()

    max = 0
    maxal = 0

    alcnt = 0
    cnt = 0

    for n in str:
        if n.isalpha()==True:
            alcnt = alcnt+1
            if maxal != n:
                cnt = count(n,str)
                if max<cnt:
                    max = cnt
                    maxal = n

    print(f"{max/alcnt:.2f}")
