def frate():
	alpha = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
	string = input()
	string = string.lower()
	word = ""
	ar = string.split()
	count=[]
	length=0
	for i in ar:
		word+=i
	for i in range(len(word)):
		if word[i] in alpha:
			count.append(word.count(word[i]))
			length+=1

	value = max(count)/length
	print(f"{value:.2f}")

if __name__ == "__main__":
	frate()