#coding:utf-8

st=input()
ust=st.upper()
count={}

for c in ust:
    if c.isalpha():
        count[c]=ust.count(c)

maxcount=max(count.values())

nchar=0
valuelist=list(count.values())

for value in count.values():
    nchar+=value
    
result=maxcount/nchar
print(f"{result:.2f}")

        
        
