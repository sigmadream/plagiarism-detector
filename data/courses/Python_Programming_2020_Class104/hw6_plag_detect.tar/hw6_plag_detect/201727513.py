if __name__ == "__main__":
    str = input().lower()
    aa=[]
    num = ['1','2','3','4','5','6','7','8','9','0']
    
    for i in str:
        if i not in num and i != " ":
            aa.append(i)
    cnt = []
    for c in aa:
        bb = aa.count(c)
        cnt.append(bb)
        mx = max(cnt)
        result = mx / len(aa)

    print(f"{result:4.2f}")
        
        
        
    
