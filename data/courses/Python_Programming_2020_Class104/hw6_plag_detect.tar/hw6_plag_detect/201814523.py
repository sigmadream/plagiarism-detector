def f_string(str):
    countn = 0
    count = {}
    strup = str.upper()
    for c in strup:
        if c.isalpha():
            countn += 1
            count[c] = strup.count(c)
    maxcnt = max(count.values())
    f = maxcnt/countn
    return f
    


if __name__=="__main__":
    
    str = input()


    fcs = f_string(str)

    print(f"{fcs:.2f}")
            

    

    
