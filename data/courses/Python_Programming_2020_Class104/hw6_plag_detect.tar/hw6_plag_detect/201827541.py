def findmax(n):

    result = 0
    
    lstr = n.lower()

    plist = []

    for c in lstr:
        if c.isalpha():
            plist.append((lstr.count(c),c))

    plist.sort()
    plist.reverse()

    result = plist[0][0]

    return result

def num_of_all(l):

    l = str.replace(' ', '')
    l.lower()
    
    length = len(l)

    return length

if __name__ == '__main__':

    result = 0

    length = 0

    str = input()

    result = findmax(str)

    length = num_of_all(str)

    frate = result / length

    print(f"{frate:.2f}")


