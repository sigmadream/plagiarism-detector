a = input()
freq=[]
cnt = str.count(a[0])
freq = cnt/a
print(f"{freq:.2f}")
