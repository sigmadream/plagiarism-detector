if __name__ == "__main__":
    str=input()
    cnt=str.count(str[0:])
    freq=cnt/str
    print(f"{freq:2f}",freq)

    

