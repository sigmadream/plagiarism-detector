

def frate(word):
    map = {}
    for alphabet in word:
        if map.get(alphabet) == None :
            map[alphabet] = 1
        else :
            map[alphabet] += 1
    max = -1
    for key in map :
        if map[key] > max:
            max = map[key]
    return max
    return ''.join(word)

def freq_Rate(word):
    a = frate(word) / (len(word)-1)
    print(f"{a:.2f}")
    
if "__main__" == __name__ :
    word = input()
    word.lower()
    print(freq_Rate(word))
