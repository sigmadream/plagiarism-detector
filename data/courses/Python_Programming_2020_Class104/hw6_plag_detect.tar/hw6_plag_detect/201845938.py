def main():
    line = input()
    line = line.upper()
    cdict = {}
    count = 0
    for c in line:
        if c.isalpha():
            n = line.count(c)
            cdict[c] = n
            count = count+1
    maxcnt = max(cdict.values())
    maxcnt = int(maxcnt)
    f = maxcnt / count
    print(f"{f:4.2f}")


if __name__ == "__main__":
    main()
