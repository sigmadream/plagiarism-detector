num = ("0", "1", "2", "3", "4", "5", "6", "7", "8", "9")

def cnt(s):
    number = len(s)
    for i in s :
        for k in num:
            if i == k :
                number -= 1
    for i in s :
        if i == " " :
            number -= 1
        else :
            number = number
    return number

def fre(n) :
    k = 0
    p = 0
    for i in n :
        k = n.count(i)
        if k > p :
            p = k
        else :
            p = p
    return p
         

def f(word) :
    c = fre(word)
    s = cnt(word)
    c/s
    return c/s

if "__main__" == __name__ :
    word = input()
    result=f(word)
    print(f"{result:.2f}")
