str=input()


if __name__ == "__main__":
    ustr=str.upper()
    freq=[]
    lent=0
    for c in ustr:
        if c.isalpha() :
            lent= lent+1
            n= ustr.count(c)
            freq.append(n)
    maxc=int(max(freq))
    leng =int(lent)
    rate= maxc/leng
    

   
    print(f"{rate:0.2f}")
    

