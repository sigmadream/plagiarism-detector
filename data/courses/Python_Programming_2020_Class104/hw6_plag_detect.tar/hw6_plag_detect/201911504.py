text = input()
text = text.replace(" ","")
cnt1 = text.count(text[2])  #가장 빈번한것
cnt2 = text.count(text[3])
if cnt1 > cnt2:
    freq = cnt1 / len(text)
    print(f"{freq:0.2f}")
else:
    freq = cnt2 / len(text)
    print(f"{freq:0.2f}")
