def frate(a):
    ustr=a.upper()
    freq=[]
    for c in ustr:
        if c.isalpha():
            n=ustr.count(c)
            freq.append(n)
        else:
            pass
    maxcnt=max(freq)
    b=len(freq)
    float=maxcnt/b
    print("%.2f"%float)

if __name__=="__main__":
    a=input()
    frate(a)

