def main():
    s = input()
    freq = getfreq(s)
    print(f"{freq:.2f}") 

def getfreq(s):
    us = s.upper()
    length = 0
    count = {}
    for c in us:
        if c.isalpha():
            count[c] = us.count(c)
            length += 1
    maxfreq = max(count.values())
    freq = maxfreq/length
    return freq

if __name__ == "__main__":
    main()
