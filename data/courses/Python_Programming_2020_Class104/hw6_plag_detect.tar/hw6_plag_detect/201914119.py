#-*-coding:utf-8-*-

def freq(i) :
    isp=list(i)
    blan=""
    count=""
    for q in range(len(isp)) :
        if isp[q].isalpha=='True' :
            blan+=isp[q]

    for k in range(len(blan)) :
        count+=str(blan.count(blan[k]))

    c=max(count)

    cal=c/len(blan)
    print(cal)
        
            
   

a=input()
freq(a)
