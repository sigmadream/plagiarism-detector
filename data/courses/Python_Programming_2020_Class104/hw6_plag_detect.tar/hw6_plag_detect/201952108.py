#공백 무시, 숫자 무시

def main():
    line = input()
    line = line.lower()
    for c in line:
        if not c.isalpha():
            line = line.replace(c, '')
    maxcnt = 0
    for c in line:
        if maxcnt< line.count(c):
            maxcnt = line.count(c)
        
    for c in line:
        if maxcnt == line.count(c):
            maxchar = c
            break
    #m: 등장 횟수, c: 문자
    result = maxcnt / len(line)

    print(f"{result:.2f}")
    
if __name__ == "__main__":
    main()
