def f(c):
    for i in range(0, len(c)):
        if c[i].isalpha() == True:
            b.append(c[i])
    for i in range(0, len(b)):
        b[i]=b[i].upper()
    for i in range(0, len(b)):
        a.append(b.count(b[i]))
    print(f"{max(a)/len(b):.2f}")
c=input()
a=[]
b=[]
if __name__ == '__main__':
    f(c)
