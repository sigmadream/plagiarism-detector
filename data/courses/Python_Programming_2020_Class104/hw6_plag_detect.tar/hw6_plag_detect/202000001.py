if __name__ == "__main__":
    d = {}
    s = input()
    num=0
    Max = 0
    s = s.lower()
    for i in s:
        if i.isalpha():
            d[i] = 0
            num = num+1
    for i in s:
        if i.isalpha(): d[i] = d[i]+1
    Max = max(d.values())
    ans = Max/(num)
    #print(num,end=" ")
    #print(d)
    #print(d,num, Max, sub,end=" ")
    print(f"{ans:.2f}")
