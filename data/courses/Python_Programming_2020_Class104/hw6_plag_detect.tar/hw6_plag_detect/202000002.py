str = input()
cnt = str.count(str[0])
freq = cnt / len(str)
print(f"{freq:.2f}")