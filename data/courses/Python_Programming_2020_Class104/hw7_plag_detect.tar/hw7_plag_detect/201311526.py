# coding: utf-8

a = int(input())
b = int(input())
c = a * a
d = b * b

if a > b:
    e = c - d
else:
    e = d - c


    
if a > b:
    if e > a:
        print(b, a, e)
    else:
        if e > b:
            print(b, e, a)
        else:
            print(e, b, a)
if a < b:
    if e > b:
        print(a, b, e)
    else:
        if e > a:
            print(a, e, b)
        else:
            print(e, a, b)
    
