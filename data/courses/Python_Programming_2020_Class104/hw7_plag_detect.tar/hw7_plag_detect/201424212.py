def square(k):
    a = k[0]**2
    b = k[1]**2
    
    return abs(a-b)

if __name__ == "__main__":
    
    a=int(input())
    b=int(input())
    if a <= 1000 or b <=1000:
        k=[]
        k.append(a)
        k.append(b)
        k.sort()
        result = square(k)
        print(k[0],k[1],result)
        
