a=int(input())
b=int(input())

a1=a*a
a2=b*b
if (a1>a2):
    c=a1-a2
else:
    c=a2-a1
    
if (a<b):
    print(a,end=" ")
    print(b,end=" ")
else:
    print(b,end=" ")
    print(a,end=" ")

print(c)


