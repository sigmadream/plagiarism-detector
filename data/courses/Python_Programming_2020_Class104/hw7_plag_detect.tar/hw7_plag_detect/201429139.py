def sort_():
    a = int(input())
    b = int(input())
    if(a > b):
        if(pow(a,2)>pow(b,2)):
            print(b,a,pow(a,2)-pow(b,2))
        else:
            print(b,a,pow(b,2)-pow(a,2))
    else:
        if(pow(a,2)>pow(b,2)):
            print(a,b,pow(a,2)-pow(b,2))
        else:  
            print(a,b,pow(b,2)-pow(a,2))
if __name__ == "__main__":
    sort_()