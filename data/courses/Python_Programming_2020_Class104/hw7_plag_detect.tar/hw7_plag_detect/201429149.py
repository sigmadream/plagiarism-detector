def main():
    A = int(input())
    B = int(input())
    if A**2 > B**2:
        C = A**2 - B**2
    else:
        C = B**2 - A**2
    if A > B :
        print(B , A , C)
    else :
        print(A , B , C)
    
        


if __name__ == "__main__" :
    main()
