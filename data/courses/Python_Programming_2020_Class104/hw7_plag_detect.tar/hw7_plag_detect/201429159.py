def cal(num1, num2):
    x = 0
    if num1 > num2:
        x = num1 - num2
        number1 = num2
        number2 = num1
    else:
        x = num2 - num1
        number1 = num1
        number2 = num2
    y = num1 + num2

    num3 = x * y

    print(number1, number2, num3)

if __name__ == "__main__":
    num1 = int(input())
    num2 = int(input())

    while num1>1000 or num2>1000:
        print("1000 이하의 숫자로 다시 입력하세요")
        num1 = int(input())
        num2 = int(input())

    cal(num1, num2)

    
