A = 5
B = 2
print(int(B))
print(int(A))

if A >= B :
    print(int(A*A)-int(B*B))
else :
    print(int(B*B)-int(A*A))

A = 8
B = 3
print(int(B))
print(int(A))

if A >= B :
    print(int(A*A)-int(B*B))
else :
    print(int(B*B)-int(A*A))

