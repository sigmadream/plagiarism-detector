def sorting_number(a,b) :
    if a > b :
        diff = a**2 - b**2 
    else : 
        diff = b**2 - a**2
    ls = [a,b,diff]
    ls.sort()
    for i in ls :
        print(i , end = " ")

def main() :
    a = int(input())
    b = int(input())
    sorting_number(a,b)


if __name__ == "__main__" :
    main()
