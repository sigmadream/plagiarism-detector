
if __name__ == "__main__" :
    a = int(input())
    b = int(input())
    if (a < b) :
        print(a, b, b*b - a*a)
    else :
        print(b, a, a*a - b*b)
