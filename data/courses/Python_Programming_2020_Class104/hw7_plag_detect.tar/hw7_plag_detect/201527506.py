a = input()
b = input()

aa = int(a)
bb = int(b)

d = aa*aa - bb*bb
if d>=0:
    ans = d
else:
    ans = -d

list = [aa, bb, ans]

for i in range(0, 2):
    for j in range(i,3):
        if list[i] > list[j]:
            temp = list[j]
            list[j] = list[i]
            list[i] = temp
            
for c in range(0, 3):
    if c == 2:
        print(list[c], end="")
    else:
        print(list[c], end=" ")
