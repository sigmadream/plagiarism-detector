#coding: utf-8

def sq(a):
    return a*a

if __name__ == "__main__" :
    a = int(input())
    b = int(input())
    if a>=b :
        result = sq(a)-sq(b)
    else : result = sq(b)-sq(b)

    if a>=b :
        if result>=a :
            print(b, a, result)
        else : print(b, result, a)
    
    elif b>=a :
        if result>=b :
            print(a, b, result)
        else : print(a, result, b)
