def mysort(a,b):
    if a > b:
        temp = a
        a = b
        b = temp


if __name__ == "__main__":
    A = int(input())
    B = int(input())
    
    mysort(A,B)

    print(A, B, abs(A*A-B*B))
