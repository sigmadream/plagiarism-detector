# 제곱의 차
# 솔트하고 제곱의차
# 인라인 3

a=int(input())
b=int(input())

tmp = []
if a>b:
    
    tmp.append(str(b))
    tmp.append(str(a))
    tmp.append(str(a*a-b*b))
else:
    
    tmp.append(str(a))
    tmp.append(str(b))
    tmp.append(str(b*b - a*a))
# print(tmp)

print((' ').join(tmp))
    