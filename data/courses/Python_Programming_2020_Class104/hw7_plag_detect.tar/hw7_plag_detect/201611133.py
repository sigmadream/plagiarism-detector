
def result(number_list):
    number = 0
    for i in range(len(number_list)):
        for j in range(len(number_list)-1):
            if number_list[i] <= number_list[j]:
                number = number_list[j]
                number_list[j] = number_list[i]
                number_list[i] = number

def difference(a, b):
    c = 0
    c = a*a - b*b
    if c >= 0:
        pass
    else:
        c = -c
    return c

if __name__ == "__main__":
    a = int(input())
    b = int(input())
    c = difference(a,b)

    number_list = []

    number_list.append(a)
    number_list.append(b)
    number_list.append(c)

    result(number_list)

    for i in range(len(number_list)):
        print(number_list[i],sep="",end="")
        if i < len(number_list)-1:
            print(" ",sep="",end="")
