a=int(input())
b=int(input())
c=a**2-b**2
for i in (a,b,c):
    if a<b:
        if a>c :
            print(c,a,b)
            break
        else :
            if b>c :
                print(a,c,b)
                break
            else :
                print(a,b,c)
                break
    else :
        if a>c :
            if b>c :
                print(b,c,a)
                break
            else :
                print(c,a,b)
                break
        else :
            print(b,a,c)
            break
