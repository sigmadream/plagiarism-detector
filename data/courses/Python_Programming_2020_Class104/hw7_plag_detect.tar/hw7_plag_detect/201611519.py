def problem1(a,b):
    if a > b:
        print(b, a, a*a-b*b)
    else:
        print(a, b, b*b-a*a)

if __name__ == "__main__":
    a = int(input())
    b = int(input())
    problem1(a,b)
