A = int(input())
B = int(input())
A_sq = A*A
B_sq = B*B
result = 0
if A_sq>B_sq :
    result = A_sq - B_sq
else :
    result = B_sq - A_sq
ls = []
ls.append(A)
ls.append(B)
ls.append(result)
first = min(ls)
ls.remove(min(ls))
mid = min(ls)
ls.remove(min(ls))
last = min(ls)

print(first, end='')
print(" ", end='')
print(mid, end='')
print(" ", end='')
print(last, end='')
