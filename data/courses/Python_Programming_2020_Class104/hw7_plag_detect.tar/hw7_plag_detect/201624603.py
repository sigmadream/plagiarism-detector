n1=int(input("첫번째 정수: "))
n2=int(input("두번째 정수: "))
numlist=[]
if n1<=1000 and n2<=1000:
    numlist.append(n1)
    numlist.append(n2)
    if numlist[0]>numlist[1]:
        temp=numlist[1]
        numlist[1]=numlist[0]
        numlist[0]=temp
    
    result=numlist[1]**2-numlist[0]**2
    numlist.append(result)
    for i in range(0,2):
        if numlist[i]>numlist[i+1]:
            temp2=numlist[i+1]
            numlist[i+1]=numlist[i]
            numlist[i]=temp2
    for n in numlist:
        print(n,end=" ")

