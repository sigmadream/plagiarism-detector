#coding:utf-8

a = int(input())
b = int(input())

a1 = a**2
b1 = b**2

c = 0

if a1>=b1:
    c = a1 - b1
    print(b,a,c)
else:
    c= b1 - a1
    print(a,b,c)
