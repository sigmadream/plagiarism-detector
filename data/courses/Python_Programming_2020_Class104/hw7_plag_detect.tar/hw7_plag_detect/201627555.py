a = int(input())
b = int(input())
if (a>=b) :
    print(b, a, a*a-b*b)
else :
    print(a, b, b*b-a*a)
