def calc_square_diff(n1, n2):
    return abs(n1**2 - n2**2)


def sort_nums(nums):
    for i in range(len(nums)):
        for j in range(i+1, len(nums)):
            if nums[i] > nums[j]:
                temp = nums[i]
                nums[i] = nums[j]
                nums[j] = temp
    return nums


if __name__ == "__main__":
    num1 = int(input())
    num2 = int(input())
    abs_diff = calc_square_diff(num1, num2)
    numbers = [num1, num2, abs_diff]

    for i, num in enumerate(sort_nums(numbers)):
        if i != 2:
            print(num, end=" ")
        else:
            print(num)
