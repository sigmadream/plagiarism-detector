a=int(input())
b=int(input())

def calcu(a,b):
    if a>b:
        c=(a**2)-(b**2)
        print('%d %d %d' %(b, a, c))
    else:
        c=(b**2)-(a**2)
        print('%d %d %d' %(a, b, c))

calcu(a,b)
