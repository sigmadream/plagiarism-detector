def sort(a,b):
    if (a>b):
        diff = (a*a)-(b*b)
        if (diff>a):
            print(b,a,diff)
        else:
            if(diff>b):
                print(b,diff,a)
            else:
                print(diff,b,a)            
    else:
        diff = (b*b)-(a*a)
        if (diff>b):
            print(a,b,diff)
        else:
            if(diff>a):
                print(a,diff,b)
            else:
                print(diff,a,b)      


if __name__ == "__main__":
    a = int(input())
    b = int(input())
    sort(a,b)
