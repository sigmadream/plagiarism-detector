def odd(m,l):
    return m*(2*l+1);

def edd(m,l):
    return m*2*l

if __name__ == "__main__":
    sen = input()
    sen = sen.split()

    k = int(sen[1])
    
    for i in range(1,k+1):
        if(i%2==1):
            c=odd(sen[0],i)
        else:
            c=edd(sen[0],i)
        print(c)
