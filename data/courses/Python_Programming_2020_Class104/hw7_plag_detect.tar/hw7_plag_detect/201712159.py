a = int(input())
b = int(input())
so = []
if a>=b:
    so.append(str(b))
    so.append(str(a))
    so.append(str(a**2-b**2))
else:
    so.append(str(a))
    so.append(str(b))
    so.append(str(b**2-a**2))
s = " ".join(so)
print(s)