#coding:utf-8

def square(n1, n2):
    if(n1>n2):
        result=(n1*n1)-(n2*n2)
        print(n2, n1, result)
        
    elif(n2>n1):
        result=(n2*n2)-(n1*n1)
        print(n1, n2, result)

    elif(n1==n2):
        result=0
        print(n1, n2, result)

if __name__=="__main__":
    n1=int(input())
    n2=int(input())
    square(n1, n2)
    
