
a = int(input())
b = int(input())

aa = pow(a, 2)
bb = pow(b, 2)

d = abs(aa - bb)
result = []

if a > b and d > a:
    result.append(str(b))
    result.append(" ")
    result.append(str(a))
    result.append(" ")
    result.append(str(d))
elif a < b and b < d:
    result.append(str(a))
    result.append(" ")
    result.append(str(b))
    result.append(" ")
    result.append(str(d))
elif a < d and d < b:
    result.append(str(a))
    result.append(" ")
    result.append(str(d))
    result.append(" ")
    result.append(str(b))
elif b < d and d < a:
    result.append(str(b))
    result.append(" ")
    result.append(str(d))
    result.append(" ")
    result.append(str(a))
elif a == b:
    result.append(str(d))
    result.append(" ")
    result.append(str(a))
    result.append(" ")
    result.append(str(b))
    
print("".join(result))
