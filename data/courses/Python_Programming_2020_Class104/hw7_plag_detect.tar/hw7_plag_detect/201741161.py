a = int(input())
b = int(input())
if a *a > b * b:
    c = a * a - b * b
    print(b, a, c)
else:
    c = b * b - a * a
    print(a, b, c)