a = int(input())

b = int(input())


sq = abs((a**2) - (b**2))

numlist = [a,b,sq]

if numlist[0] > numlist[1]:
    k = numlist[0]
    numlist[0]=numlist[1]
    numlist[1]=k

if numlist[1] > numlist[2]:
    m = numlist[1]
    numlist[1]=numlist[2]
    numlist[2]=m



for i in range(len(numlist)):
    print(numlist[i],end=" ")
