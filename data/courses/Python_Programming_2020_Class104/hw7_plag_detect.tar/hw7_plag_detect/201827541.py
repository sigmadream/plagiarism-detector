a = int(input())
a <= 1000
b = int(input())
b <= 1000

nums = []

if a > b:
    nums = [b, a]
else:
    nums = [a, b]

print(nums[0], nums[1], nums[1]*nums[1] - nums[0]*nums[0])

    
    
