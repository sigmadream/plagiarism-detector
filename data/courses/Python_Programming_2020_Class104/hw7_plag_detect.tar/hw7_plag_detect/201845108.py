a = [x for x in input().split()]
n = int(a[1])
i=1
while n-i>=0:
    if i==1:
        print(a[0]*3)
        i += 1
    elif i%2==0:
        print(a[0]*(2*i))
        i += 1
    else :
        print(a[0]*(2*i-1))
        i += 1
