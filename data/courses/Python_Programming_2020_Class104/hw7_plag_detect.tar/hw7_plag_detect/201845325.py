
a=int(input())
b=int(input())
c=a**2
d=b**2
if c>d :
    print(b)
    print(a)
    print(c-d)
else:
    print(a)
    print(b)
    print(d-c)
