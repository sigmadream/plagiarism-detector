
def squares(a,b):
    if a > b :
        c = a**2 - b**2
        print(b,a,c)
    else :
        c = b**2 - a**2
        print(a,b,c)

if "__main__" == __name__ :
    a = int(input())
    b = int(input())
    squares(a,b)
    
