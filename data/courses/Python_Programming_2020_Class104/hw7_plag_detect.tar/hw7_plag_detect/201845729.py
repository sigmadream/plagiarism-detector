def main():
    int1 = int(input())
    int2 = int(input())

    # result = [int1, int2, abs(int1**2 - int2**2)]
    result = abs(int1**2 - int2**2)
    # print(result)
    # result.sort()
    
    # for i in range(len(result)):
    #     print(result[i], end=" ")
    
    # # print(int1, int2, result)
    if int1>=int2:
        temp = int1
        int1 = int2
        int2 = temp

        print(int1, int2, result)

    

if __name__ == "__main__":
    main()