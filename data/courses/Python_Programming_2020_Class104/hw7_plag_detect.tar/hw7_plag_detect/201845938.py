n1 = int(input())
n2 = int(input())

if n1 > n2:
    tmp = n1
    n1 = n2
    n2 = tmp

print(n1, n2, n2*n2-n1*n1)