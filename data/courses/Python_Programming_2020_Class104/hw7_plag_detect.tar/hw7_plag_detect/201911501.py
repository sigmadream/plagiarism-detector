a = int(input())
b = int(input())
c = abs(a*a-b*b)
s = [a, b, c]
k = sorted(s)
print(k[0], k[1], k[2])
