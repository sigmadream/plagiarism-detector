

a=int(input())
b=int(input())


if __name__ == "__main__":
    if a>b:
        print(b,a,(a+b)*(a-b))
    else:
        print(a,b,(a+b)*(b-a))

        
            
    
