a = input()
b = input()

a = int(a)
b = int(b)
if a < b & (a<=1000) & (b<=1000):
    print(a, b, abs(a*a - b*b))
else:
    print(b, a, abs(b*b-a*a))
