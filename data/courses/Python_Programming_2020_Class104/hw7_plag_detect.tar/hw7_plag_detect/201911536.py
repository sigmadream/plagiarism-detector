A=int(input())
B=int(input())
if A>B:
    C=(A**2-B**2)
    print(B,A,C)
else:
    C=(B**2-A**2)
    print(A,B,C)

    
