num1 = input()
num2 = input()
diff = int(num1)**2 - int(num2)**2

if diff < 0:
    diff *= -1

ls = []
ls.append(int(num1))
ls.append(int(num2))
ls.append(diff)
ls.sort()

for i in range(len(ls)):
    ls[i] = str(ls[i])

s = " ".join(ls)
s = s.strip()
print(s)

