#coding:utf-8

def sq(x,y) :
    if x>=y :
        x1=int(x)**2
        y1=int(y)**2
        c=x1-y1
        print(y,end=' ')
        print(x,end=' ')
        print(c,end='')
    else :
        x1=int(x)**2
        y1=int(y)**2
        c=y1-x1
        print(x,end=' ')
        print(y,end=' ')
        print(c,end='')
        
        
    

if __name__=='__main__' :
    a=input()
    b=input()
    sq(a,b)
