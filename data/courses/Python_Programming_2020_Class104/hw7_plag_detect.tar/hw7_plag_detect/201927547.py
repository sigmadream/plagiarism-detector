
num11 = input()
num22 = input()
num1 = int(num11)
num2 = int(num22)

def check(a, b) :
    number1 = a * a
    number2 = b * b
    if number1>= number2 :
        return number1 - number2
    elif number1 < number2 :
        return number2 - number1


if __name__ == "__main__" :
    diff = check(num1, num2)
    if (num1 <= 1000, num2<= 1000) :
        if num1 >= num2 :
            print(num2, num1, diff)
        elif num2 > num1 :
            print(num1, num2, diff)