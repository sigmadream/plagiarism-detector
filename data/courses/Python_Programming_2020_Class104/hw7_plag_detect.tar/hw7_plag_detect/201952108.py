A = int(input())
B = int(input())
a = A*A
b = B*B
if A>B:
    print(B, A, a-b)
else:
    print(A, B, b-a)
