a=int(input())
b=int(input())
c=[a,b]
if a>b:
    c=[b,a]

print(c[0], c[1], (c[1]**2)-(c[0]**2))
