def sortNums(nums):
    n1 = nums[0]
    n2 = nums[1]
    n3 = nums[2]
    if n1 > n2:
        nums[0] = n2
        nums[1] = n1
    if nums[0] > n3:
        del nums[2]
        nums = [n3] + nums
    return nums

def diffOfSqaure(nums):
    n3 = abs(nums[0] * nums[0] - nums[1]*nums[1])
    nums.append(n3)
    return nums

if __name__ == '__main__':
    nums = []
    nums.append(int(input()))
    nums.append(int(input()))
    nums = diffOfSqaure(nums)
    nums = sortNums(nums)
    i = 0
    for n in nums:
        nums[i] = str(n)
        i += 1
    print(" ".join(nums))