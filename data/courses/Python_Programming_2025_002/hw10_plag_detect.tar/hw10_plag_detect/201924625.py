# Read pattern character
c = input().strip()

# Read list of integers xi
x_list = list(map(int, input().split()))
n = len(x_list)

# Calculate differences di = xi - xi-1
d_list = [x_list[i] - x_list[i - 1] for i in range(1, n)]

max = 0
for d in d_list:
	if(d<max):
		max = d
max = abs(max)
for d in d_list:
	if(d<0):
		print(" "*(max+d) + c*(abs(d)) + "|")
	else:
		print(" "*max + "|" + c*d)