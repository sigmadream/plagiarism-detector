def repeat_pattern(char, times):
    "Repeating the char for several number of times"
    # converting the char to ascii code
    result = chr(ord(char))
    count = 0
    output = chr(0)
    while count < times:
        if count == 0:
            # starting with the first char
            output = result
        else:
            # adding the char to the result
            output = output + result
        count += 1
    return output


def generate_space(count):
    "Generating a string of spaces"
    spaces = []
    for _ in range(count):
        # adding a space character
        spaces.append(chr(32))
    # joining the list into a single string
    return ''.join(spaces)


def main():
    "Printing the graph of differences for the integer sequence"
    symbol = input() # symbol pattern
    input_line = input() # sequence of numbers
    # splitting the input into a list
    parts = input_line.split()
    # converting it into a list of integers
    numbers = []
    for i in parts:
        numbers.append(int(i))
    # calculating the differences between two numbers
    differences = []
    for i in range(1, len(numbers)):
        differences.append(numbers[i] - numbers[i-1])
    # finding the maximum left difference for alignment
    max_left = 0
    for d in differences:
        if d < 0:
            max_left = max(max_left, -d)
    # generating and printing each line of the graph
    for d in differences:
        result = []
        # checking if the difference is negative
        if d < 0:
            # adding the spaces -> symbol pattern -> vertical bar
            result.append(generate_space(max_left - (-d)))
            result.append(repeat_pattern(symbol, -d))
            result.append("|")
        # if the difference is positive
        elif d > 0:
            # adding the spaces -> vertical bar -> symbol pattern
            result.append(generate_space(max_left))
            result.append("|")
            result.append(repeat_pattern(symbol, d))
        # if the difference is equal to zero
        else:
            # adding the spaces -> vertical bar
            result.append(generate_space(max_left))
            result.append("|")
        # joining and printing the line
        print(''.join(result))

if __name__ == "__main__":
    main()
