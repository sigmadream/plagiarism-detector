def main():
    pattern = input()

    numbers = list(map(int, input().split()))
    for i in range(1, len(numbers)):
        diff = numbers[i] - numbers[i - 1]
        line = []
        if diff < 0:
            for _ in range(-diff):
                line.append(pattern)
            line.append('|')
            print(''.join(line))

        elif diff > 0:
            line.append('|')
            for _ in range(diff):
                line.append(pattern)
            print(''.join(line))
        else:
            print('|')


if __name__ == "__main__":
    main()
