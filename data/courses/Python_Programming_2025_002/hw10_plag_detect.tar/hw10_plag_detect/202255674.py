def make_space(li):
    """공백 개수를 계산해서, 출력문 줄 맞춤"""
    values = []
    differences = []
    offset=0

    for part in li:
        values.append(int(part))

    for i in range(1, len(values)):
        differences.append(values[i] - values[i - 1])

    for d in differences:
        if d < 0 and -d > offset:
            offset = -d

    return differences, offset

def main():
    """
    사용자에게 입력은 받고, 계산된 공백에 맞게 출력하는 함수
    """
    pattern = input().strip()
    li = input().split()
    differences,space = make_space(li)

    col = chr(124)
    sp = chr(32)

    for d in differences:
        line = sp
        if d >= 0:
            count = 0
            while count < space:
                line = line + sp
                count += 1
            line = line + col
            count = 0
            while count < d:
                line = line + pattern
                count += 1
        else:
            count = 0
            total_spaces = space + d
            while count < total_spaces:
                line = line + sp
                count += 1
            count = 0
            while count < -d:
                line = line + pattern
                count += 1
            line = line + col

        print(line)

if __name__ == '__main__':
    main()
