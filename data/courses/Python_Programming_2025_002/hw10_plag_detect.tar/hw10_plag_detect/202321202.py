def main():
    pattern = input().strip()

    numbers = list(map(int, input().strip().split()))

    differences = [numbers[i] - numbers[i - 1] for i in range(1, len(numbers))]

    for diff in differences:
        print("|", end="")

        for _ in range(abs(diff)):  # abs()로 음수일 경우 처리
            print(pattern, end="")

        print()

if __name__ == "__main__":
    main()
