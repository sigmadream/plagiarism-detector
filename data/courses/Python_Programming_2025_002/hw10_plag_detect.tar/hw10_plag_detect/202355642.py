def aaa(c, count):
    result = str()
    i = 0
    while i < count:
        result = result + c
        i = i + 1
    return result

def main():
    p = input().strip()
    a = list(map(int, input().split()))
    i = 1
    while i < len(a):
        d = a[i] - a[i - 1]
        if d >= 0:
            s = chr(124) + aaa(p, d)
        else:
            s = aaa(p, -d) + chr(124)
        print(s)
        i = i + 1

main()
