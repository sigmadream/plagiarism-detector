def poschanger(cha, words, max_width):
    words = int(words)
    stars = cha * words
    line = stars.rjust(max_width) + "|"
    return line

def negchanger(cha, words, max_width):
    words = int(words) * -1
    stars = cha * words
    line = " " * max_width + "|" + stars
    return line

def main():
    cha = input()
    nums = list(map(int, input().split()))
    renums = []
    real = []

    for i in range(len(nums)-1):
        lo = nums[i] - nums[i+1]
        renums.append(lo)

    max_width = max(abs(num) for num in renums)

    for p in renums:
        if p >= 0:
            real.append(poschanger(cha, p, max_width))
        else:
            real.append(negchanger(cha, p, max_width))

    for line in real:
        print(line)

if __name__ == "__main__":
    main()