char = input()
integers = input().split()
int_list = []

for i in range(len(integers) - 1):
    int_list.append(int(integers[i + 1]) - int(integers[i]))

gap = abs(min(int_list))

for i in int_list:
    if i >= 0:
        print(" " * gap + "|" + char * i)
    else:
        print(" " * (gap + i) + char * (-i) + "|")
        