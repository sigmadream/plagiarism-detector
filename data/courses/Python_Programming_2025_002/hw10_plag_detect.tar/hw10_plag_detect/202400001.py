def join_string(char_list):
    """Join a list of characters into a string."""
    result = chr(0)
    i = 0
    while i < len(char_list):
        result = result + char_list[i]
        i += 1
    return result[1:]


def make_line(pattern_char, char_num, min_num, max_num):
    """Make a line of the graph with the given pattern character and count."""
    result = []
    if char_num < 0:
        for i in range(abs(min_num - char_num)):
            result.append(chr(32))
        for i in range(abs(char_num)):
            result.append(pattern_char)
        result.append(chr(124))  # |
        for i in range(abs(max_num)):
            result.append(chr(32))  # 공백
    else:
        for i in range(abs(min_num)):
            result.append(chr(32))
        result.append(chr(124))  # |
        for i in range(abs(char_num)):
            result.append(pattern_char)
    return join_string(result)


def calc_n1n2(num_list):
    """Calculate n1 and n2 for the graph."""
    result = []
    for i in range(0, len(num_list) - 1):
        result.append(num_list[i + 1] - num_list[i])
    return result


if __name__ == "__main__":
    pattern = input()
    numbers = list(map(int, input().split()))
    result = []
    calc_numbers = calc_n1n2(numbers)
    min_num = min(calc_numbers, default=0)
    max_num = max(calc_numbers, default=0)
    for i in range(len(calc_numbers)):
        result.append(make_line(pattern, calc_numbers[i], min_num, max_num))
    for i in range(len(result)):
        print(result[i])
