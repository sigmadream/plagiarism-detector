import sys
def main():
    "it inputs a string of symbols and a list of numbers"
    pattern = sys.stdin.readline().strip()
    numbers_line = sys.stdin.readline().strip()
    numbers = list(map(int, numbers_line.split()))
    differences = [numbers[i] - numbers[i - 1] for i in range(1, len(numbers))]
    for diff in differences:
        if diff > 0:
            print('|' + ''.join(pattern for _ in range(diff)))
        elif diff < 0:
            print(''.join(pattern for _ in range(-diff)) + '|')
        else:
            print('|')
if __name__ == "__main__":
    main()
