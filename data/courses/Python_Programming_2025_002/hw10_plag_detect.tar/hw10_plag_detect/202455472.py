def main():
    '''Function to print the graph bar'''
    sym = str(input())
    number = list(map(int, input().split()))
    bar =chr(124)
    for i in range(1,len(number)):
        diff = number[i] - number[i-1]
        abs_diff = abs(diff)
        if diff > 0:
            print(bar, end='')
            n = 0
            while n < abs_diff:
                print(sym, end = '')
                n += 1
            print()
        elif diff < 0:
            n = 0
            while n < abs_diff:
                print(sym, end = '')
                n += 1
            print(bar)
        else:
            print(bar)
main()
