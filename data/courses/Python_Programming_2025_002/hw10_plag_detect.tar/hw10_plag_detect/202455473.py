def repeat(ch, count):
    """Repeat a character without using string literals or '*'."""
    result = []
    for _ in range(count):
        result += [ch]
    return result

def main():
    """Reads pattern and values, and prints aligned difference graph."""
    ch = input()
    values = list(map(int, input().split()))

    left_pad = 0
    for i in range(1, len(values)):
        d = values[i] - values[i - 1]
        if d < 0 and -d > left_pad:
            left_pad = -d

    for i in range(1, len(values)):
        d = values[i] - values[i - 1]
        line = []

        if d > 0:
            line += repeat(chr(32), left_pad)
            line += [chr(124)]
            line += repeat(ch, d)
        elif d < 0:
            pad = left_pad + d  # d is negative
            line += repeat(chr(32), pad)
            line += repeat(ch, -d)
            line += [chr(124)]
        else:
            line += repeat(chr(32), left_pad)
            line += [chr(124)]

        print(''.join(line))

main()
