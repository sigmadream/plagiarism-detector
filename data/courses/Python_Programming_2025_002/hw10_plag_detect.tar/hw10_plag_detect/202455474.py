import sys
char = input()
integers = input().split()

nums = []
MIN_NUM = sys.maxsize
for i in range(1,len(integers)):
    calc = int(integers[i]) - int(integers[i-1])
    MIN_NUM = min(MIN_NUM,calc)
    nums.append(calc)

EXTENDED_CHAR = str()
for i in range(100):
    EXTENDED_CHAR += char

SPACE = str()
for i in range((-MIN_NUM)):
    SPACE += chr(32)

for i in nums:
    if i > 0:
        print(SPACE + chr(124) + EXTENDED_CHAR[:i])
    elif MIN_NUM < i < 0:
        print(SPACE[:i - MIN_NUM] + EXTENDED_CHAR[:-i] + chr(124))
    else:
        print(EXTENDED_CHAR[:-i] + chr(124))
