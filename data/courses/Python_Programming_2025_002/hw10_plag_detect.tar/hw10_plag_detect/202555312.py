def main():
    '''main'''
    input_char = input()
    input_nums = input().split()
    diff_list = []
    min_diff = 0

    for i in range(len(input_nums) - 1):
        diff_list.append(int(input_nums[i + 1]) - int(input_nums[i]))
        min_diff = diff_list[i] if diff_list[i] < min_diff else min_diff

    for d in diff_list:
        if d >= 0:
            for i in range(-1 * min_diff):
                print(chr(32), end=str()) # chr(32) = ' '
            print(chr(124), end=str()) # chr(124) = '|'
            for i in range(d):
                print(input_char, end=str())
            print()
        else:
            for i in range(-1 * min_diff + d):
                print(chr(32), end=str())
            for i in range(-1 * d):
                print(input_char, end=str())
            print(chr(124))


if __name__ == "__main__":
    main()
