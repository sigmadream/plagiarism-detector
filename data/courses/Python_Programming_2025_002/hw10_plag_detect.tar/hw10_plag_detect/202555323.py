def print_dgraph():
    input_first = input().strip()       
    input_sec = input().strip()           

    parts = input_sec.split()
    numbers = []                          
    for p in parts:
        numbers.append(int(p))           

    for i in range(1, len(numbers)):
        diff = numbers[i] - numbers[i - 1]

        if diff > 0:
            print('|' + input_first * diff)
        elif diff < 0:
            print(input_first * abs(diff) + '|')
        else:
            print('|')

print_dgraph()



