c = input()
d = [] # difference array
es = chr(32)
nums = input().split()

for i in range(1, len(nums)):
    d.append(int(nums[i]) - int(nums[i - 1]))

mx = max(d)
mn = min(d)

for n in d:
    if n > 0:
        for _ in range(-mn):
            es += chr(32)
        es += chr(124)
        for _ in range(n):
            es += c
    elif n < 0:
        for _ in range(n - mn):
            es += chr(32)
        for _ in range(-n):
            es += c
        es += chr(124)
    else:
        es += chr(124)
    print(es)
    es = chr(32)
