pattern = input().strip()
input_numbers = input().split()
nums = []
for num in input_numbers:
    nums.append(int(num))

for i in range(1, len(nums)):
    diff = nums[i] - nums[i-1]
    
    if diff == 0:
        print("|")
    elif diff > 0:
        print("|" + pattern * diff)
    else:
        print(pattern * abs(diff) + "|")