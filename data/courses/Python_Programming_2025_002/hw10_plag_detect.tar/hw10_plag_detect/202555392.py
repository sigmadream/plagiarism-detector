"""
Additional requirements for bonus points
1. Do not use string literals (even the empty string literal (’’ or "") is not usable) nor
the string repetition operator (*).
2. Check the quality of your code to make it have fewer than three quality issues.
"""

def repeat_string(char: str, num: int):
    """makes repeated string w/o string repetition operator"""
    n = -num if num < 0 else num
    result = [char for _ in range(n)]
    return str().join(result)


def mk_diff_graph(char: str, num_diff: list):
    """makes difference graph"""
    space = -(min(num_diff)) if min(num_diff) < 0 else 0
    for j in num_diff:
        repeated = repeat_string(char, j)
        if j > 0:
            print(f"{chr(124) + repeated:>{space + j + 1}}")
        else:
            print(f"{repeated + chr(124):>{space}}")


character = input()
numbers = list(map(int, input().split()))
diff = []
for i in range(0, len(numbers) - 1):
    diff.append(numbers[i+1] - numbers[i])

mk_diff_graph(character, diff)
