def dgraph():
    # Read the pattern character
    pattern = input().strip()
    
    # Read the sequence of integers
    nums = list(map(int, input().split()))
    
    # Calculate differences between consecutive integers
    diffs = []
    for i in range(1, len(nums)):
        diffs.append(nums[i] - nums[i-1])
    
    # Generate and print the graph
    for diff in diffs:
        line = []
        if diff > 0:
            # Add vertical bar at position 0
            line.append('|')
            # Add pattern characters after the bar
            for _ in range(diff):
                line.append(pattern)
        elif diff < 0:
            # Add pattern characters before the bar
            for _ in range(-diff):
                line.append(pattern)
            # Add vertical bar at the end
            line.append('|')
        else:  # diff == 0
            # Just the vertical bar
            line.append('|')
        
        print(''.join(line))

# Call the function
dgraph()

