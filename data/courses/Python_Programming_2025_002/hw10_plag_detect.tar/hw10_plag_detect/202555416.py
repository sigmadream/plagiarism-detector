def main():
    import sys

    # Read the input
    lines = sys.stdin.read().splitlines()
    pattern = lines[0]
    xi = list(map(int, lines[1].split()))
    n = len(xi)

    for i in range(1, n):
        diff = xi[i] - xi[i - 1]
        line = []

        if diff > 0:
            for _ in range(xi[i - 1]):
                line.append(' ')
            line.append('|')
            for _ in range(diff):
                line.append(pattern)
        elif diff < 0:
            for _ in range(xi[i]):
                line.append(' ')
            line.append('|')
            for _ in range(-diff):
                line.append(pattern)
        else:
            for _ in range(xi[i]):
                line.append(' ')
            line.append('|')

        # Print line after joining characters without trailing spaces
        i = len(line) - 1
        while i >= 0 and line[i] == ' ':
            i -= 1
        print(''.join(line[:i+1]))

if __name__ == "__main__":
    main()