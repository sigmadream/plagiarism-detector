def repeat_symbol(symbol, count):
    """ prints the symbol the amount of times I want."""
    result = chr(32)
    while count > 0:
        result = result + symbol
        count = count - 1
    return result.strip()

def make_spaces(n):
    """ Generate spaces before the bar."""
    space_num = chr(32)
    count = 1
    while count < n:
        space_num = space_num + chr(32)
        count += 1
    return space_num

input_symbol = input()
input_number = input()
str_number = input_number.split()
numbers = []
differences = []

for i in str_number:
    numbers.append(int(i))

for k in range(len(numbers) - 1):
    diff = numbers[k + 1] - numbers[k]
    differences.append(diff)

mn = min(differences)
mx = max(differences)

for j in differences:
    if j < 0  and j == mn:
        print(repeat_symbol(input_symbol, -j) + chr(124))
    elif j < 0 and j != mn :
        spaces = make_spaces(-(mn - j))
        print(spaces + repeat_symbol(input_symbol, -j) + chr(124))
    else:
        spaces = make_spaces(-mn)
        print(spaces + chr(124) + repeat_symbol(input_symbol, j))
