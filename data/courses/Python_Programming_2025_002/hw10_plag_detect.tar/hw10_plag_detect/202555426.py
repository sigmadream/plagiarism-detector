def dgraph():
    import sys

    # Input
    input_lines = sys.stdin.read().splitlines()
    c = input_lines[0]  # pattern character
    x_list = list(map(int, input_lines[1].split()))

    i = 1
    while i < len(x_list):
        d = x_list[i] - x_list[i - 1]
        output = []

        if d > 0:
            output.append('|')
            j = 0
            while j < d:
                output.append(c)
                j += 1

        elif d < 0:
            j = 0
            while j < -d:
                output.append(c)
                j += 1
            output.append('|')

        else:
            output.append('|')

        # print the line without trailing spaces
        index = 0
        while index < len(output):
            sys.stdout.write(output[index])
            index += 1
        print()

        i += 1


if __name__ == '__main__':
    dgraph()
