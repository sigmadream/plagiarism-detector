PATTERN = input()
N_INT = input().split()
SAVE_CHAR = chr(32)

LEFT_INDENTATION = 0

for i in range(len(N_INT) - 1):
    N_INT[i] = int(N_INT[i + 1]) - int(N_INT[i])
    if N_INT[i] < LEFT_INDENTATION:
        LEFT_INDENTATION = N_INT[i]

for i in range(len(N_INT) - 1):
    for j in range(-LEFT_INDENTATION + (N_INT[i] if N_INT[i] < 0 else 0)):
        SAVE_CHAR += chr(32)

    if N_INT[i] > 0:
        SAVE_CHAR += chr(124)

    for j in range(-N_INT[i]):
        SAVE_CHAR += PATTERN

    if N_INT[i] <= 0:
        SAVE_CHAR += chr(124)

    for j in range(N_INT[i]):
        SAVE_CHAR += PATTERN

    SAVE_CHAR += chr(10)

print(SAVE_CHAR[1:-1])
