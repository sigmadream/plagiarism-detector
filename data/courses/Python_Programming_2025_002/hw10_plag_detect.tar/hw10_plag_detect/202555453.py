def main():
    """main is the start point of prgm."""

    pattern = input()
    nums = list(map(int, input().split()))

    diffs = []

    for i in range(len(nums) - 1):
        diffs.append(nums[i + 1] - nums[i])

    left_size = -min(diffs) if min(diffs) < 0 else 0

    for diff in diffs:
        if diff < 0:
            print(repeat(chr(32), left_size - abs(diff)) + repeat(pattern, abs(diff)) + chr(124))
        else:
            print(repeat(chr(32), left_size) + chr(124) + repeat(pattern, abs(diff)))


def repeat(string, count):
    """repeat returns repeated string"""

    result = str()  # 빈 문자열을 표현하는 방법은 str() 말고도 편법으로는 __name__[0:0] 혹은 __name__[:-8]도 가능함.
    for _ in range(count):
        result += string

    return result


if __name__ == "__main__":
    main()
