def roman_to_decimal(roman):
    """
    Convert a Roman numeral string to its decimal (integer) equivalent using recursion.

    Parameters:
    roman (str): A string representing a Roman numeral (e.g., "IX", "MCMXCIV").

    Returns:
    int: The decimal (integer) value of the Roman numeral.
    
    The function handles subtractive notation (e.g., IV = 4, IX = 9) and supports
    standard Roman numeral characters: I, V, X, L, C, D, M.
    """
    roman_numerals = {
        'I': 1,
        'V': 5,
        'X': 10,
        'L': 50,
        'C': 100,
        'D': 500,
        'M': 1000
    }

    if not roman:
        return 0

    last_value = roman_numerals[roman[-1]]

    if len(roman) <= 1:
        return last_value

    second_last_value = roman_numerals[roman[-2]]

    if last_value > second_last_value:
        return roman_to_decimal(roman[:-2]) + (last_value - second_last_value)

    return roman_to_decimal(roman[:-1]) + last_value


# Prompt the user for input
a = input()

# Output the converted decimal value
print(roman_to_decimal(a))
