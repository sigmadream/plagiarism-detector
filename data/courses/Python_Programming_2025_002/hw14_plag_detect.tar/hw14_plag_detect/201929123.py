roman_dict = {
    'I': 1,
    'V': 5,
    'X': 10,
    'L': 50,
    'C': 100,
    'D': 500,
    'M': 1000
}

def roman_to_decimal(line):
    '''
    define roman number with recursive 
    '''
    if not line:
        return 0

    curr = roman_dict[line[0]]
    if len(line) > 1 and roman_dict[line[0]] < roman_dict[line[1]]:
        return -curr + roman_to_decimal(line[1:])

    return curr + roman_to_decimal(line[1:])

roman_num = input().strip()
print(roman_to_decimal(roman_num))
