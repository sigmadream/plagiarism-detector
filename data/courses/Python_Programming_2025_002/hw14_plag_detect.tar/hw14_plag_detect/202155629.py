m={'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000}
def r(n):return 0 if not n else m[n[1]]-m[n[0]]+r(n[2:]) if len(n)>1 and m[n[0]]<m[n[1]] else m[n[0]]+r(n[1:])
print(r(input()))