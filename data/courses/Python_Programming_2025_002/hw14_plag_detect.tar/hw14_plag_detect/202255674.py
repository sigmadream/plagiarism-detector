r={'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000}
def roma(s):
 if not s:return 0
 return -r[s[0]]+roma(s[1:]) if len(s)>1 and r[s[0]]<r[s[1]] else r[s[0]]+roma(s[1:])
print(roma(input()))
