def roman_to_decimal(roman_str):
    """Convert a Roman numeral string to its decimal (integer) equivalent."""
    values = {'I': 1, 'V': 5, 'X': 10, 'L': 50,
              'C': 100, 'D': 500, 'M': 1000}

    def helper(i):
        """Recursive helper function to compute the decimal value from index i."""
        if i == len(roman_str) - 1:
            return values[roman_str[i]]
        if i >= len(roman_str):
            return 0
        c, n = values[roman_str[i]], values[roman_str[i + 1]]
        return (n - c if c < n else c) + helper(i + (2 if c < n else 1))

    return helper(0)

user_input = input().strip()
print(roman_to_decimal(user_input))
