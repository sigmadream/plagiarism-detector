d = {'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000}
def f(s):
 return 0 if not s else (d[s[1]] > d[s[0]] if len(s)>1 else False)*-2*d[s[0]]+d[s[0]]+f(s[1:])
print(f(input()))
