r={'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000}
def f(s): return 0 if not s else r[s[0]]*(-1 if len(s)>1 and r[s[0]]<r[s[1]] else 1)+f(s[1:])
print(f(input()))