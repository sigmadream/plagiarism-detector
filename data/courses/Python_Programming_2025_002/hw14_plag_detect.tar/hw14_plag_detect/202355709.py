def rom_to_int(rom):
    """reverse input and evaluate each values"""
    rom_dict = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}

    total = 0
    sub_value = 0

    for char in reversed(rom):
        if rom_dict[char] < sub_value:
            total -= rom_dict[char]
        else:
            total += rom_dict[char]
            sub_value = rom_dict[char]

    return total

def main():
    """execute rom_to_int with rom"""
    rom = input().strip()
    result = rom_to_int(rom)
    print(result)

if __name__ == "__main__":
    main()
