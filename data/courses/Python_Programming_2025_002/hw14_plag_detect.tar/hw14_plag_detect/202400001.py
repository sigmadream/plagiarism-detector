def roman(s):
    if not s:
        return 0
    v = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
    if len(s) == 1 or v[s[0]] >= v[s[1]]:
        return v[s[0]] + roman(s[1:])
    else:
        return v[s[1]] - v[s[0]] + roman(s[2:])


print(roman(input()))
