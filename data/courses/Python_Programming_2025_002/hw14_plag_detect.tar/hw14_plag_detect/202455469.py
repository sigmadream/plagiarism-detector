def roman_to_int(s):
    """Roman to integer"""
    roman = {'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000}
    def helper(i):
        """Convert"""
        if i == len(s) - 1:
            return roman[s[i]]
        curr, next_ = roman[s[i]], roman[s[i+1]]
        if curr < next_:
            return helper(i+1) - curr
        return curr + helper(i+1)
    return helper(0)

print(roman_to_int(input().strip()))
