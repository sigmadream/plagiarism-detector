r={'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000}
def f(s):
 if not s:return 0
 return r[s[0]]+f(s[1:]) if len(s)==1 or r[s[0]]>=r[s[1]] else -r[s[0]]+f(s[1:])
print(f(input().strip()))
