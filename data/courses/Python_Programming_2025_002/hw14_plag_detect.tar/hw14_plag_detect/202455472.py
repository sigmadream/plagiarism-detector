def rom2dec(s):
    '''Function to convert roman number to decimal'''
    values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    if len(s) == 0:
        return 0
    if len(s) == 1:
        return values[s[0]]
    if values[s[0]] < values[s[1]]:
        return values[s[1]] - values[s[0]] + rom2dec(s[2:])
    return values[s[0]] + rom2dec(s[1:])
roman = input().upper()
print(rom2dec(roman))
