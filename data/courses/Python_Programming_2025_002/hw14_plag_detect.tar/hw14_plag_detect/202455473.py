d = dict(I=1, V=5, X=10, L=50, C=100, D=500, M=1000)
r = lambda s: 0 if not s else d[s[0]] * (-1 if len(s) > 1 and d[s[0]] < d[s[1]] else 1) + r(s[1:])
print(r(input()))