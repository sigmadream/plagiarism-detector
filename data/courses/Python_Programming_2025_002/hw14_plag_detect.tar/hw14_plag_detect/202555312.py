CONSTANTS = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}

def roman_to_arabic(roman, largest = 0):
    '''converts roman numeral string to arabic numerals'''
    if roman == "":
        return 0
    digit = CONSTANTS[roman[-1]]
    largest = max(largest, digit)
    return roman_to_arabic(roman[0:-1], largest) + digit * (-1 if largest > digit else 1)


def main():
    '''main'''
    roman = input()
    print(roman_to_arabic(roman))


if __name__ == "__main__":
    main()
