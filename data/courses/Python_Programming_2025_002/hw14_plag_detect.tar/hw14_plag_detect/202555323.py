roman_numeral = input()
numeral = roman_numeral.upper()

roman_values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
total = 0
i = 0
while i < len(numeral):
    if i + 1 < len(numeral) and roman_values[numeral[i]] < roman_values[numeral[i+1]]:
        total += roman_values[numeral[i+1]] - roman_values[numeral[i]]
        i += 2
    else:
        total += roman_values[numeral[i]]
        i += 1
print(total)
