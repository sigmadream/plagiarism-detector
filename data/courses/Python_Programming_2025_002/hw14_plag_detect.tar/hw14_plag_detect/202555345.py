roman_map = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
def roman(n):
    if len(n) == 0:
        return 0
    if len(n) == 1:
        return roman_map[n[0]]
    if roman_map[n[0]] < roman_map[n[1]]:
        return roman_map[n[1]] - roman_map[n[0]] + roman(n[2:])
    else:
        return roman_map[n[0]] + roman(n[1:])

def main():
    print(roman(input()))

if __name__ == "__main__":
    main()
