def r(s):
    """convert r to decimal"""
    t={'I':1,'V':5,'X':10,'L':50,'C':100,'D':500,'M':1000}
    return 0 if not s else r(s[1:])-t[s[0]]if len(s)>1 and t[s[0]]<t[s[1]]else t[s[0]]+r(s[1:])
print(r(input()))
