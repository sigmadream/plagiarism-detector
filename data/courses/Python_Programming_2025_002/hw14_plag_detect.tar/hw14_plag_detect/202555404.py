values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}

def roman_to_decimal(s, i=0):
    if i >= len(s):
        return 0
    if i + 1 < len(s) and values[s[i]] < values[s[i+1]]:
        return values[s[i+1]] - values[s[i]] + roman_to_decimal(s, i+2)
    return values[s[i]] + roman_to_decimal(s, i+1)

print(roman_to_decimal(input()))