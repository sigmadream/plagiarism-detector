r={"I":1,"V":5,"X":10,"L":50,"C":100,"D":500,"M":1000}
def f(s,i=0):
 return 0 if i==len(s)else(-r[s[i]]+f(s,i+1)if i+1<len(s)and r[s[i]]<r[s[i+1]]else r[s[i]]+f(s,i+1))
print(f(input()))