ROMAN, ARABIC = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"], [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
def arabic(s, i=0, res=0): return res if not s else arabic(s[len(ROMAN[i]):], i, res + ARABIC[i]) if s.startswith(ROMAN[i]) else arabic(s, i + 1, res)
print(arabic(input()))