r = input()
t = {"I": 1,"V": 5,"X": 10,"L": 50,"C": 100,"D": 500,"M": 1000}
def f(c, i):
 q=t[c[i]]
 if i==len(r)-1:
  return q
 if t[c[i+1]] <= q:
  return q+f(c, i + 1)
 else:
  return -q+f(c, i + 1)
print(f(r, 0))