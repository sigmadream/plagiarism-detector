# Get user input
inp = input()
x, y = map(int, inp.split())  # Convert input strings to integers

# Ensure x is the smaller number and y is the larger number
if y < x:
    x, y = y, x  # Swap x and y if y is less than x

def fib_sq(a, b):
    """
    Calculate the area of a rectangle formed by Fibonacci squares.

    This function recursively generates Fibonacci numbers starting from
    the given values a and b. It checks if the generated Fibonacci numbers
    match the user-provided dimensions x and y. If they do, it returns
    the area of the rectangle formed by these dimensions. If the generated
    Fibonacci numbers exceed the dimensions, it returns 0.

    Parameters:
    a (int): The first Fibonacci number in the sequence.
    b (int): The second Fibonacci number in the sequence.

    Returns:
    int: The area of the rectangle if Fibonacci numbers match x and y,
         otherwise 0.
    """
    # Base case: if the current Fibonacci numbers match the input x and y
    if a == x and b == y:
        return a * b  # Return half the area of the rectangle formed by x and y
    # If the current Fibonacci numbers exceed the input values, return 0
    if a > x or b > y:
        return 0
    # Recursive case: calculate the next Fibonacci number and continue
    return fib_sq(b, a + b)

# Call the function with the first two Fibonacci numbers (1, 1)
print(fib_sq(1, 1))
