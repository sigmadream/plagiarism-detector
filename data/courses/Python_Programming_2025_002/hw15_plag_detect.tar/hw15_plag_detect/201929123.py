def fib (n: int, fib_memo: dict[int, int] = None) -> int:
    '''
    define fibonacci number with recursive
    '''
    if fib_memo is None:
        fib_memo = {}

    if n in fib_memo:
        return fib_memo[n]

    result:int = n if n <= 1 else fib(n-1) + fib(n-2)
    fib_memo[n] = result
    return fib_memo[n]

if __name__ == "__main__":
    x, y = map(int, input().split())

    N = 0
    while (fib(N) < x or fib(N) < y):
        N += 1

    if N == 1:
        print(1)
    elif fib(N) == x:
        if fib(N -1) == y:
            print(x * y)
        else: print(0)
    elif fib(N) == y:
        if fib(N-1) == x:
            print(x*y)
        else: print(0)
    else:
        print(0)
