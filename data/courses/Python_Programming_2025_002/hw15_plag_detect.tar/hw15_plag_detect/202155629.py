def f(n:int,m:dict[int,int]={})->int:
 if n in m:return m[n]
 m[n]=n if n<2 else f(n-1)+f(n-2)
 return m[n]
a,b=map(int,input().split())
for i in range(99):
 if a==f(i-1)and b==f(i):
  print(a*b)
  break
else:print(0)