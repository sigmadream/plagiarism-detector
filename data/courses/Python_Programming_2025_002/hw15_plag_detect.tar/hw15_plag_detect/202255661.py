from typing import Dict

def fib(n: int, memo: Dict[int, int] = {}) -> int:
    if n in memo: return memo[n]
    memo[n] = n if n <= 1 else fib(n - 1, memo) + fib(n - 2, memo)
    return memo[n]

if __name__ == "__main__":
    s: str = input().split()
    a: int = int(s[0])
    b: int = int(s[1])
    x: int = min(a, b)
    y: int = max(a, b)
    f0: int = 0
    f1: int = 1
    while f1 < y:
        f0, f1 = f1, f0 + f1
        if (f0 == x and f1 == y) or (f0 == y and f1 == x):
            print(a * b)
            break
    else:
        print(a * b if a == b and a in (1, 0) else 0)
