m={0:0,1:1};a,b=map(int,input().split())
def fibo(n: int) -> int:
    if n in m: return m[n]
    m[n] = fibo(n-1)+fibo(n-2)
    return m[n]
def s(a: int, b: int) -> int:
    i=2
    while fibo(i)<=b:
        if fibo(i)==b and fibo(i-1)==a: return a*b
        i+=1
    return 0
print(s(a,b))