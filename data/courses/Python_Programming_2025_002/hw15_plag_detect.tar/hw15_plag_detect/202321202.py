from typing import Dict

def f(n: int, m: Dict[int, int] = {0: 0, 1: 1}) -> int:
    if n not in m:
        m[n] = f(n - 1, m) + f(n - 2, m)
    return m[n]

def t(a: int, b: int) -> bool:
    i = 0
    while True:
        x, y = f(i), f(i + 1)
        if (x == a and y == b) or (x == b and y == a):
            return True
        if x > a or y > b:
            return False
        i += 1

a, b = map(int, input().split())
print(a * b if t(a, b) else 0)
