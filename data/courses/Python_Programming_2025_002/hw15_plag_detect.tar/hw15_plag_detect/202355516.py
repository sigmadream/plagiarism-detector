def fib(n: int, memo: dict[int, int] = {}) -> int:
    if n in memo:
        return memo[n]
    memo[n] = n if n <= 1 else fib(n - 1, memo) + fib(n - 2, memo)
    return memo[n]

def is_fib_tile(a: int, b: int) -> int:
    n = 0
    while True:
        f1, f2 = fib(n), fib(n + 1)
        if (a == f1 and b == f2) or (a == f2 and b == f1):
            return a * b
        if f2 > b:
            return 0
        n += 1

if __name__ == "__main__":
    x, y = map(int, input().split())
    print(is_fib_tile(x, y))
