from functools import cache
def main()->None:
 a,b=map(int,input().split())
 @cache
 def f(n:int)->int:return n if n<2 else f(n-1)+f(n-2)
 i=1
 while f(i)<b:i+=1
 print(a*b if f(i)==b and f(i-1)==a else 0)
main()