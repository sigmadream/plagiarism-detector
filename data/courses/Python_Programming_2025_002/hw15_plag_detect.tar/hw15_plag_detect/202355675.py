def f(n:int,m={0:0,1:1})->int:m[n]=m[n]if n in m else f(n-1)+f(n-2);return m[n]
def t(a:int,b:int)->bool:return any(f(i)==a and f(i+1)==b for i in range(50))
a,b=map(int,input().split());print(a*b if t(a,b)else 0)