from functools import cache

@cache
def fib(n: int) -> int:
    """피보나치 계산"""
    return n if n < 2 else fib(n-1)+fib(n-2)

def main(a: int, b: int) -> int:
    """조건에 따라 넓이 또는 0 반환"""
    for i in range(1, 50):  # <- 2 → 1로 변경
        if (fib(i))==a and fib(i+1)==b:
            return a*b
    return 0

print(main(*map(int, input().split())))
