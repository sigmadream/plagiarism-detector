def fib(n: int, memo: dict[int, int] = {}) -> int:
    if n in memo:
        return memo[n]
    memo[n] = n if n <= 1 else fib(n - 1, memo) + fib(n - 2, memo)
    return memo[n]


def is_fib_tile(x: int, y: int) -> int:
    a, b = 0, 1
    while b < y:
        a, b = b, a + b
        if (a == x and b == y) or (a == y and b == x):
            return x * y
    return x * y if x == y == 1 else 0


if __name__ == "__main__":
    x, y = map(int, input().split())
    print(is_fib_tile(x, y))
