def fib(n: int, memo: dict[int, int] | None = None) -> int:
    """Return the nth Fibonacci number."""
    if memo is None:
        memo = {}
    if n in memo:
        return memo[n]
    if n < 2:
        return n
    memo[n] = fib(n-1, memo) + fib(n-2, memo)
    return memo[n]

def is_fib_tiling(a: int, b: int) -> bool:
    """Check if a rectangle of size a x b can be tiled with Fibonacci numbers."""
    f = [fib(i) for i in range(30)]
    pairs = {(f[i], f[i+1]) for i in range(len(f)-1)}
    return (a, b) in pairs or (b, a) in pairs

def main() -> None:
    """Main function to read input and print the result."""
    a, b = map(int, input().split())
    print(a*b if is_fib_tiling(a, b) else 0)

if __name__ == "__main__":
    main()
