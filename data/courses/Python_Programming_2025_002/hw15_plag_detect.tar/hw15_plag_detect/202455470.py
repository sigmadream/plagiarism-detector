def a(n,f={}):f[n]=f[n]if n in f else n if n<2 else a(n-1)+a(n-2);return f[n]
b,k=map(int,input().split())
print(next((b*k for n in range(99)if b==a(n-1)and k==a(n)),0))