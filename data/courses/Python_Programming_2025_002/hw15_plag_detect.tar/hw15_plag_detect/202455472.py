n1, n2 = map(int, input().split())
def fib(n: int, fib_memo: dict[int, int]=None) -> int:
    '''Function to print fibonacci tiling'''
    if fib_memo is None:
        fib_memo = {}
    if n in fib_memo:
        return fib_memo[n]
    result: int = n if n <= 1 else fib(n - 1) + fib(n - 2)
    fib_memo[n] = result
    return result

def is_fibonacci_number(a,b):
    '''Function to check whether the number is in fibonacci sequence or not'''
    i = 0
    while True:
        f1 = fib(i)
        f2 = fib(i+1)
        if f1 == a and f2 == b:
            return True
        if f1> a or f2>b:
            return False
        i+=1
if __name__ == "__main__":
    if is_fibonacci_number(n1, n2):
        print(n1 * n2)
    else:
        print(0)
