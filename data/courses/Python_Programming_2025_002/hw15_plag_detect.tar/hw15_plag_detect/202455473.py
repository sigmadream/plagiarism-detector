def f(n:int,m:dict[int,int]={})->int:
 if n in m:return m[n]
 if n<2:return n
 m[n]=f(n-1,m)+f(n-2,m);return m[n]
a,b=map(int,input().split())
i=0;L=[]
while(f(i)<=b):L+=[f(i)];i+=1
print(a*b if any(L[i]==a and L[i+1]==b for i in range(len(L)-1)) else 0)
