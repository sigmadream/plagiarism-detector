def main():
    """
    Reads two integers from user input and performs a check based on the Fibonacci sequence.
    The program should print the area of the rectangle if the input numbers denote the sides
    of the rectangle built by Fibonacci tiling, or print 0 otherwise.
    Example:
    Input: 5 8
    Output: 40
    """
    user_input: list[int] = input().split()
    first: int = int(user_input[0])
    second: int = int(user_input[1])

    curr: int = 0
    nxt: int= 1
    nxt_of_nxt: int = 1
    while curr < first:
        curr, nxt, nxt_of_nxt = nxt,curr + nxt, nxt + nxt_of_nxt

    if second in (nxt,nxt_of_nxt):
        print(first * second)
    else:
        print(0)

if __name__ == "__main__":
    main()
