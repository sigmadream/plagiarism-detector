def fib(n: int) -> int:
    if n <= 2:
        return 1
    return fib(n - 1) + fib(n - 2)

def main() -> None:
    raw_input: list[str] = input().split()
    side_lengths: list[int] = [int(raw_input[0]), int(raw_input[1])]

    is_valid_size: bool = False

    index: int = 1
    while fib(index) <= side_lengths[0]:
        if side_lengths[0] == fib(index) and side_lengths[1] == fib(index + 1):
            is_valid_size = True
            break
        index += 1

    print(side_lengths[0] * side_lengths[1] if is_valid_size else "0")

if __name__ == "__main__":
    main()
