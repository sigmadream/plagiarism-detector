import sys
sys.setrecursionlimit(10000)

fib_cache = {1: 1, 2: 1}
def fib(n):
    if n in fib_cache:
        return fib_cache[n]
    fib_cache[n] = fib(n-1) + fib(n-2)
    return fib_cache[n]


def generate_fib(limit):
    fibs = []
    i = 1
    while True:
        f = fib(i)
        if f > limit:
            break
        fibs.append(f)
        i += 1
    return fibs

def is_fibonacci(a, b):
    fibs = generate_fib(b)
   
    for i in range(len(fibs) - 1):
        if (fibs[i] == a and fibs[i+1] == b) or (fibs[i] == b and fibs[i+1] == a):
            return a * b
    return 0

if __name__ == "__main__":
    a, b = map(int, input().split())
    print(is_fibonacci(a, b))
