x, y = map(int, input().split())
fib_memo: dict[int, int]={}
def fib(n: int) -> int:
    """Generating fib sequence"""
    if n in fib_memo:
        return fib_memo[n]
    result: int = n if n <= 1 else fib(n - 1) + fib(n - 2)
    fib_memo[n] = result
    return result
fib(100)

if (x in fib_memo.values() and y in fib_memo.values()):
    if list(fib_memo.values()).index(x, 2) + 1 == list(fib_memo.values()).index(y, 2):
        print(x * y)
    elif (x == 1 and y == 1):
        print(1)
    else:
        print(0)
else:
    print(0)
