from sys import stdin

def fib(n: int, fib_memo: dict[int, int]={}) -> int:
    if n in fib_memo:
        return fib_memo[n]
    result: int = n if n <= 1 else fib(n - 1) + fib(n - 2)
    fib_memo[n] = result
    return result

def is_fibonacci_number(num: int) -> bool:
    i: int = 0
    while True:
        f: int = fib(i)
        if f == num:
            return True
        if f > num:
            return False
        i += 1

def solve(a: int, b: int) -> int:
    return a * b if is_fibonacci_number(a) and is_fibonacci_number(b) else 0

if __name__ == "__main__":
    a, b = map(int, stdin.read().split())
    print(solve(a, b))
    