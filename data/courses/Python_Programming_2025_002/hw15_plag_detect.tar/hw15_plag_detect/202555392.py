"""
Additional requirements for bonus points
1. The type hints should be attached to all the functions and the parameters.
2. Reduce the size of your program (the number of tokens) as much as possible. The
top 10% of small codes working correctly are considered for the bonus points.
"""

memo = {}
def fib(x: int, mem: dict[int, int]) -> int:
    """fibonacci"""
    if x in mem:
        return mem[x]
    if x <= 1:
        return x
    mem[x] = fib(x - 1, memo) + fib(x - 2, memo)
    return mem[x]
fib(996, memo)
fibs = set(memo.values())

a, b = map(int, input().split())
if a == b and a != 1:
    print(0)
else:
    print(a * b if a in fibs and b in fibs else 0)
