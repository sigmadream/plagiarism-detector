def fib(n: int, fib_memo: dict[int, int]={}) -> int:
    """
    Calculate the nth Fibonacci number using memoization.
    """
    if n in fib_memo:
        return fib_memo[n]
    result: int = n if n <= 1 else fib(n - 1, fib_memo) + fib(n - 2, fib_memo)
    fib_memo[n] = result
    return result

def is_fibonacci_pair(side1: int, side2: int) -> bool:
    """
    Check if the two sides form a valid Fibonacci rectangle.
    A valid Fibonacci rectangle has sides that are consecutive Fibonacci numbers.
    """
    if side1 > side2:
        side1, side2 = side2, side1
    
    # Generate Fibonacci numbers until we find a match or exceed the larger side
    i: int = 0
    while True:
        fib_i: int = fib(i)
        fib_i_plus_1: int = fib(i + 1)
        
        # Check if this pair matches our sides
        if fib_i == side1 and fib_i_plus_1 == side2:
            return True
        
        # If we've exceeded the larger side, no match is possible
        if fib_i_plus_1 > side2:
            return False
        
        i += 1

def main() -> None:
    # Read input
    sides: list[int] = list(map(int, input().split()))
    side1, side2 = sides
    
    # Check if the sides form a valid Fibonacci rectangle
    if is_fibonacci_pair(side1, side2):
        print(side1 * side2)
    else:
        print(0)

if __name__ == "__main__":
    main()