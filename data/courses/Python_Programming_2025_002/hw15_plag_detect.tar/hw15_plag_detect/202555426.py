def fib(n: int, memo: dict[int, int] = None) -> int:
    """Compute Fibonacci number using memoization"""
    if memo is None:
        memo = {}
    if n in memo:
        return memo[n]
    memo[n] = n if n < 2 else fib(n - 1, memo) + fib(n - 2, memo)
    return memo[n]

def is_fib_tiling(x: int, y: int) -> int:
    """Determine if the sides can form a Fibonacci rectangle"""
    memo = {}
    i = 0
    while True:
        f = fib(i, memo)
        if f > y:
            break
        if f == x and fib(i + 1, memo) == y:
            return x * y
        i += 1
    return 0

def main() -> None:
    """Main function to read input and print output"""
    try:
        sides = list(map(int, input().strip().split()))
        if len(sides) != 2:
            raise ValueError
        side1, side2 = sorted(sides)
        print(is_fib_tiling(side1, side2))
    except ValueError:
        print(0)

if __name__ == "__main__":
    main()
