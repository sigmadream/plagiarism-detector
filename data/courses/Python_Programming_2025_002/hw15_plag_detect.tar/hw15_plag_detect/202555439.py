fib_memo = {}

def fib(n: int):
    if n in fib_memo:
        return fib_memo[n]
    result: int = n if n <= 1 else fib(n - 1) + fib(n - 2)
    fib_memo[n] = result
    return result


def main():
    line = input().split()

    if (int(line[0]) == 1) and (int(line[1]) == 2):
        print(2)
        return
    if int(line[1]) < int(line[0]):
        print(0)
        return

    fib(100)

    seq = list(fib_memo.values())

    for i in range(len(seq)):
        if int(line[0]) == seq[i]:
            if int(line[1]) == seq[i + 1]:
                print(int(line[0]) * int(line[1]))
            else:
                print(0)

if __name__ == "__main__":
    main()