s:set[int]=set([1])
def t(n:int,m:dict[int,int]={})->int:
 if n in m:
  return m[n]
 if n<2:
  return n
 m[n]=t(n-1,m)+t(n-2,m)
 s.add(m[n])
 return m[n]
t(100)
w:int
h:int
w,h=map(int, input().split())
if not (w in s and h in s) or w==h:
 print(0)
else:
 print(w * h)