def is_even(n):
    if n & 1 == 0:
        print("E")
    else:
        print("O")

a = int(input())
b = int(input())
is_even(a)
is_even(b)

