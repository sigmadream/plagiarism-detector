# coding: utf-8

a = int(input())
b = int(input())
if a == (a // 2) * 2:
    print("E")
else:
    print("O")
if b == (b // 2) * 2:
    print("E")
else:
    print("O")
