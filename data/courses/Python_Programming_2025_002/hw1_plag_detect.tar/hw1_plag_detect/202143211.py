x = int(input())
y = int(input())

if x % 2 == 2:
    print('E')
else:
    print('O')
