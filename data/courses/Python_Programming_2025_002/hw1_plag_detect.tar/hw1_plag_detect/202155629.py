def parity(n):
    res = (n//2)*2
    if res == n:
        print("E")
    else:
        print("O")


n1 = int(input())
n2 = int(input())
parity(n1)
parity(n2) 


