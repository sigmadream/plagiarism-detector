

a = int(input())
b = int(input())

if a % 2 == 0 :
    print("E")
else :
    print("0")

if b % 2 == 0 :
    print("E")
else :
    print("0")
