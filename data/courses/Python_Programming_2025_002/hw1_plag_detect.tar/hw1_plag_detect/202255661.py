a = int(input())
b = int(input())
if((a//2)*2==a):
    print('E')
else:
    print('O')
if((b//2)*2==b):
    print('E')
else:
    print('O')
