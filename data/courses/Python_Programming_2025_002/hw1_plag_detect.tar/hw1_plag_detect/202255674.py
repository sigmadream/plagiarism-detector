#coding: utf-8

a = int(input())
b = int(input())

if ((a // 2) * 2 == a):
    print('E')  
else:
    print('O')  

if ((b // 2) * 2 == b):
    print('E')  
else:
    print('O')  

# if ((a & 1) == 0):
#     print('E')  
# else:
#     print('O')  
    
# if ((b & 1) == 0):
#     print('E') 
# else:
#     print('O') 