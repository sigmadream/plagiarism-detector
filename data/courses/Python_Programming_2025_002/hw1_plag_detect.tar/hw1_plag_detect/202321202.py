#coding: utf-8

a = int(input())

if a%2==0 :
	print("E")
else : print("O")

b = int(input())

if b%2==0 :
	print("E")
else : print("O")