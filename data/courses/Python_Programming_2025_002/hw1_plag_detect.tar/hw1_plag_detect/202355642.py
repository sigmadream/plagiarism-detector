n1, n2 = int(input()), int(input())

def determine_parity(n):
    if n & 1 == 0:
        return 'E'
    else:
        return 'O'

print(determine_parity(n1))
print(determine_parity(n2))
