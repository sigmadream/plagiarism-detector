a = int(input())
b = int(input())

if a % 2 == 0:
    print("E")
else:
    print("O")

if b % 2 == 0:
    print("E")
else:
    print("O")