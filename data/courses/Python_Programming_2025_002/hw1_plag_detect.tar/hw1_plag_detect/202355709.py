#coding : utf-8

a = int(input())
b = int(input())

if a%2 == 0:
    print("E")
elif a%2 != 0:
    print("O")

if b%2 == 0:
    print("E")
elif b%2 != 0:
    print("O")

