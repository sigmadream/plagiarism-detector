import sys

max_val = -2**31
min_val = 2**31 - 1

while (num := sys.stdin.readline()) != "": 
    num = int(num)  
    max_val = num if num > max_val else max_val
    min_val = num if num < min_val else min_val

print(max_val - min_val)