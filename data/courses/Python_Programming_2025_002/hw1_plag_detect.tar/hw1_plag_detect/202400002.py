def is_even(n):
    if int(n / 2) * 2 == n:
        print("E")
    else:
        print("O")

a = int(input())
b = int(input())

is_even(a)
is_even(b)
