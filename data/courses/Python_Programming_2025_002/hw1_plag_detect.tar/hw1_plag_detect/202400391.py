﻿a = int(input())
b = int(input())

if (int(a / 2) * 2) == a:
    print("E")
else:
    print("O")

if (int(b / 2) * 2) == b:
    print("E")
else:
    print("O")
