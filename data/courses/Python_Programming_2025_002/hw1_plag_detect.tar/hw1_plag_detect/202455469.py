#coding: utf-8

a = int(input())
b = int(input())
x = a/2
y = b/2

if a==int(x)*2:
    print("E")
else:
    print("O")

if b==int(y)*2:
    print("E")
else:
    print("O")
