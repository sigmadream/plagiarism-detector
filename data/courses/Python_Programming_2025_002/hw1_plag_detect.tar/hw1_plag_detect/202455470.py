x = int(input())
y = int(input())
def E(n):
    return (n//2)*2==n
def O(n):
    return (n//2)*2!=n

if E(x):
    print("E");
elif O(x):
    print("O");
if E(y):
    print("E");
elif O(y):
    print("O");
