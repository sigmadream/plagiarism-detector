a = int(input())
b = int(input())
if (a // 2) * 2 == a:
    if (b // 2) * 2 == b:
        print ("E")
        print ("E")
    else:
        print ("E")
        print ("O")
else:
    if (b // 2) * 2 == b:
        print ("O")
        print ("E")
    else:
        print ("O")
        print ("O")

