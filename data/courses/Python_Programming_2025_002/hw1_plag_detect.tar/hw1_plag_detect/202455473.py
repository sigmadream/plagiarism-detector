# Read two integers from input
n1 = int(input().strip())
n2 = int(input().strip())

# Check parity without using modulo operator
if (n1 & 1) == 0:  # Even numbers have the least significant bit as 0
    print("E")
else:
    print("O")

if (n2 & 1) == 0:
    print("E")
else:
    print("O")

