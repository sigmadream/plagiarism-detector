#coding: utf-8

def function(num):
    return "E" if (num // 2) * 2 == num else "O"

a = int(input())
b = int(input())
print(function(a))
print(function(b))


