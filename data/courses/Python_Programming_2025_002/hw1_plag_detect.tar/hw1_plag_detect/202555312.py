firstInteger = int(input())
secondInteger = int(input())

if(firstInteger / 2 == firstInteger // 2):
    print("E")
else:
    print("O")

if(secondInteger / 2 == secondInteger // 2):
    print("E")
else:
    print("O")
