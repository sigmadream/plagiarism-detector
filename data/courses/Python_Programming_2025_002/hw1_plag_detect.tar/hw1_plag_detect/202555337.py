a = int(input())
if a / 2 == int(a / 2):
 print("E")
else:
 print("O")
a = int(input())
if a / 2 == int(a / 2):
 print("E")
else:
 print("O")


