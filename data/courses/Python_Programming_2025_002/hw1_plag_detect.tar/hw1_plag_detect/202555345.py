def lab(d):
    if (d//2) * 2 == d:
        print("E")
    else:
        print("O")

a = int(input())
b = int(input())

lab(a)
lab(b)
