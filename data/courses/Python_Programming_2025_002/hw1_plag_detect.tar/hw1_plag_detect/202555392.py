a = int(input())
print("E" if a % 2 == 0  else "O")
b = int(input())
print("E" if b % 2 == 0  else "O")

