def fun(n):
    if n % 2:
        return "O"
    else:
        return "E"

a = int(input())
b = int(input())

print(fun(a))
print(fun(b))
