x=int(input())
y=int(input())
if (x//2)*2==x:
   print("E")
else:
   print("O")
   
if (y//2)*2==y:
 print("E")
else:
 print("O")
