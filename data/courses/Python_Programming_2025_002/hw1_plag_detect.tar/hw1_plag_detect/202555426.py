#Read two integers from input
a = int(input())
b = int(input())

def parity(n):
    if (n//2)*2 == n:
        return 'E'
    else:
        return 'O'
print(parity(a))
print(parity(b))
    
