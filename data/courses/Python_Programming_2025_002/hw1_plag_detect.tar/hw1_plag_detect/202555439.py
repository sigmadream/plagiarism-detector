#coding: utf-8

a = int(input())
b = int(input())

if a / 2 == a // 2:
	print("E")
else:
        print("O")
if b / 2 == b // 2:
        print("E")
else:
        print("O")
