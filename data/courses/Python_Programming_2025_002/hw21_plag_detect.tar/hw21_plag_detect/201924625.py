import sys

def points_f():
    """
    Reads rectangle coordinates from the first line
    of input and subsequent points from the following lines.
    Counts how many of the given points lie within
    or on the boundary of the specified rectangle.

    The rectangle is defined by two corners (x1, y1) and (x2, y2), where:
    - (x1, y1) is the bottom-left corner
    - (x2, y2) is the top-right corner

    Points are read until an empty line is encountered.
    Each point is defined by its (x, y) coordinates.
    
    The function prints the total number of points
    that are inside or on the boundary of the rectangle.
    """
    result = 0
    # Read the first line and split it into rectangle coordinates
    first_line = sys.stdin.readline().strip()
    if first_line:
        # Unpack the rectangle coordinates
        x1, y1, x2, y2 = map(int, first_line.split())
        # Store rectangle corners as dictionaries
        rectangle = [{"x": x1, "y": y1}, {"x": x2, "y": y2}]

    # Read subsequent lines for points
    for line in sys.stdin:
        if line.strip() == "":
            break
        # Append the points as tuples to the points list
        [x, y] = tuple(map(int, line.split()))
        # Check if the point is within the rectangle
        if (rectangle[0]["x"] <= x <= rectangle[1]["x"] and
            rectangle[0]["y"] <= y <= rectangle[1]["y"]):
            result += 1

    print(result)

if __name__ == "__main__":
    points_f()
