import sys

def rectangle():
    """직사각형을 만들고 비교"""
    xl, yl, xr, yr = map(int,input().split())
    total = 0
    for line in sys.stdin.readlines() :
        if line.strip() == "":
            break
        nums = list(map(int,line.split()))
        if nums[0] < xl or nums[1] < yl:
            continue
        if nums[0] > xr or nums[1] > yr:
            continue

        total += 1
    print(total)

if __name__ == "__main__":
    rectangle()
