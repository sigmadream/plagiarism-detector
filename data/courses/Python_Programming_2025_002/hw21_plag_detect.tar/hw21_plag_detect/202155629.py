import sys

class Point:
    """
    The Point class representing a point in a 2D space

    Attributes:
       x (int) - the x-coordinate of a point
       y (int) - the y-coordinate of a point
    """
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Rectangle:
    """
    The Rectangle class representing a rectangle 
    defined by its lower-left and upper-right corner coordinates

    Attributes:
       x1 (int) - the x coordinate of lower-left corner
       y1 (int) - the y coordinate of lower-left corner
       x2 (int) - the x coordinate of upper-right corner
       y2 (int) - the y coordinate of upper-right corner 
    """
    def __init__(self, x1, y1, x2, y2):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    def contain(self, point):
        """
        Checking whether the given point lies on or inside the rectangle

        Args:
           point (Point) - the point to be checked
        
        Returns:
           bool: True if it lies on / inside the rectangle
                 False if it does not lie on / inside the rectangle
        """
        return self.x1 <= point.x <= self.x2 and self.y1 <= point.y <= self.y2


def main():
    """ Main Functionality """
    lines = sys.stdin.read().splitlines()
    # reading the first line to get rectangle coordinates
    x1, y1, x2, y2 = map(int, lines[0].split())
    rect = Rectangle(x1, y1, x2, y2)
    # initializing the count of points inside rectangle
    count = 0
    # iterating through the rest of the lines to check points
    for line in lines[1:]:
        # reading the point coordinates
        x, y = map(int, line.split())
        p = Point(x, y)
        # checking if the point lies inside the rectangle
        if rect.contain(p):
            # if it does -> incrementing the count
            count += 1
    # printing the final number of points
    print(count)

if __name__ == "__main__":
    main()
