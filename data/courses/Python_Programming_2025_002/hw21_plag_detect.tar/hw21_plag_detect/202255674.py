import sys

class Rectangle:
    """
    좌하단(x1, y1)과 우상단(x2, y2) 좌표로 정의되는 사각형 클래스입니다.

    속성:
        x1 (int): 좌하단 꼭짓점의 x좌표
        y1 (int): 좌하단 꼭짓점의 y좌표
        x2 (int): 우상단 꼭짓점의 x좌표
        y2 (int): 우상단 꼭짓점의 y좌표
    """

    def __init__(self, x1, y1, x2, y2):
        """
        사각형 객체를 초기화합니다.

        Args:
            x1 (int): 좌하단 x좌표
            y1 (int): 좌하단 y좌표
            x2 (int): 우상단 x좌표
            y2 (int): 우상단 y좌표
        """
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    def contains_point(self, point):
        """
        주어진 Point 객체가 사각형 내부 또는 경계 위에 있는지를 확인합니다.

        Args:
            point (Point): 검사할 점 객체

        Returns:
            int: 포함되면 1, 그렇지 않으면 0
        """
        return int(self.x1 <= point.x <= self.x2 and self.y1 <= point.y <= self.y2)


class Point:
    """
    2차원 평면상의 점을 나타내는 클래스입니다.

    속성:
        x (int): 점의 x좌표
        y (int): 점의 y좌표
    """

    def __init__(self, x, y):
        """
        점 객체를 초기화합니다.

        Args:
            x (int): x좌표
            y (int): y좌표
        """
        self.x = x
        self.y = y


def main():
    """
    표준 입력으로부터 사각형과 점들을 입력받아,
    사각형 내부 또는 경계 위에 존재하는 점의 개수를 출력합니다.
    """
    points = []
    first = True

    for line in sys.stdin:
        nums = list(map(int, line.strip().split()))
        if first:
            rect = Rectangle(nums[0], nums[1], nums[2], nums[3])
            first = False
        else:
            points.append(Point(nums[0], nums[1]))

    count = 0
    for pt in points:
        count += rect.contains_point(pt)

    print(count)


if __name__ == "__main__":
    main()
