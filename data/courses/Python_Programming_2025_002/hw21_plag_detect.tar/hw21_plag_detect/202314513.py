import sys

class Point:
    """A class representing a 2D point with x and y coordinates."""
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Rectangle:
    """A class representing a rectangle defined by two corner points.
    
    Provides a method to check if a given Point lies within (or on) the rectangle.
    """
    def __init__(self, x1, y1, x2, y2):
        self.left = min(x1, x2)
        self.right = max(x1, x2)
        self.bottom = min(y1, y2)
        self.top = max(y1, y2)

    def includes(self, point):
        """Return True if the point lies inside or on the boundary of the rectangle."""
        return self.left <= point.x <= self.right and self.bottom <= point.y <= self.top

def main():
    """Reads input from stdin and counts how many points are inside the rectangle."""
    lines = sys.stdin.readlines()

    x1, y1, x2, y2 = map(int, lines[0].split())
    rect = Rectangle(x1, y1, x2, y2)

    count = 0
    for line in lines[1:]:
        x, y = map(int, line.split())
        point = Point(x, y)
        if rect.includes(point):
            count += 1

    print(count)

if __name__ == "__main__":
    main()
