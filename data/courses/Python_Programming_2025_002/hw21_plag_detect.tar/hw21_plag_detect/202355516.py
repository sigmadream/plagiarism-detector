# -*- coding: utf-8 -*-
import sys

class Point:
    """Represents a 2D point."""
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Rectangle:
    """Represents a rectangle defined by two corners."""
    def __init__(self, x1, y1, x2, y2):
        self.left = min(x1, x2)
        self.right = max(x1, x2)
        self.bottom = min(y1, y2)
        self.top = max(y1, y2)

    def contains(self, point):
        """Checks whether a point is inside or on the edge of the rectangle."""
        return self.left <= point.x <= self.right and self.bottom <= point.y <= self.top

def main():
    lines = sys.stdin.readlines()
    x1, y1, x2, y2 = map(int, lines[0].split())
    rect = Rectangle(x1, y1, x2, y2)
    count = 0

    for line in lines[1:]:
        if line.strip() == "":
            continue
        x, y = map(int, line.split())
        p = Point(x, y)
        if rect.contains(p):
            count += 1

    print(count)

if __name__ == "__main__":
    main()
