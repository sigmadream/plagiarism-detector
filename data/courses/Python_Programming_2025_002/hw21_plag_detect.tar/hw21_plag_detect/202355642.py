import sys

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Rectangle:
    def __init__(self, xL, yL, xR, yR):
        self.xL = xL
        self.yL = yL
        self.xR = xR
        self.yR = yR

    def contains(self, point):
        return self.xL <= point.x <= self.xR and self.yL <= point.y <= self.yR

def main():
    lines = sys.stdin.readlines()
    xL, yL, xR, yR = map(int, lines[0].split())
    rect = Rectangle(xL, yL, xR, yR)

    count = 0
    for line in lines[1:]:
        if line.strip() == "":
            continue
        x, y = map(int, line.strip().split())
        pt = Point(x, y)
        if rect.contains(pt):
            count += 1
    print(count)

if __name__ == "__main__":
    main()
