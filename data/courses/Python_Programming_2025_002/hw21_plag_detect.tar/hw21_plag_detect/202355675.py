import sys

class Point:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Point({self.x}, {self.y})"

class Rectangle:
    def __init__(self, bottom_left=Point(), top_right=Point()):
        self.bottom_left = bottom_left
        self.top_right = top_right

    def contains(self, point):
        """"""
        return (self.bottom_left.x <= point.x <= self.top_right.x and
                self.bottom_left.y <= point.y <= self.top_right.y)

def main():
    """"""
    x1, y1, x2, y2 = map(int, input().split())
    rect = Rectangle(Point(x1, y1), Point(x2, y2))
    total = 0
    for line in sys.stdin:
        if line.strip() == "":
            continue
        xi, yi = map(int, line.split())
        point = Point(xi, yi)
        if rect.contains(point):
            total += 1
    print(total)

if __name__ == "__main__":
    main()
