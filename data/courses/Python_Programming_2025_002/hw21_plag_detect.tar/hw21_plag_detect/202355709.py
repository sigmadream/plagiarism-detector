import sys

def rectangle():
    """입력받은 네 정수를 각각 리스트 요소로 저장"""
    rect = list(map(int, input().split()))
    return rect

def point(rect):
    """입력받은 포인트가 리스트 범위 내에 있는지 판별"""
    cnt = 0
    for line in sys.stdin.readlines():
        if line.strip() == "":
            break
        p = list(map(int, line.split()))
        if rect[0] <= p[0] <= rect[2] and rect[1] <= p[1] <= rect[3]:
            cnt += 1
    print(cnt)

if __name__ == "__main__":
    point(rectangle())
