# coding: utf-8
"""Lab 11: Rectangle 내 포함된 점 개수 세기"""

import sys


class Point:
    """2차원 평면상의 점"""

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y


class Rectangle:
    """좌하단과 우상단 좌표로 정의된 직사각형"""

    def __init__(self, x1: int, y1: int, x2: int, y2: int):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    def contains(self, p: Point) -> bool:
        """점 p가 사각형 안(경계 포함)에 있는지 확인"""
        return self.x1 <= p.x <= self.x2 and self.y1 <= p.y <= self.y2


def main():
    lines = sys.stdin.read().splitlines()
    x1, y1, x2, y2 = map(int, lines[0].split())
    rect = Rectangle(x1, y1, x2, y2)
    count = 0
    for line in lines[1:]:
        x, y = map(int, line.split())
        if rect.contains(Point(x, y)):
            count += 1
    print(count)


if __name__ == "__main__":
    main()
