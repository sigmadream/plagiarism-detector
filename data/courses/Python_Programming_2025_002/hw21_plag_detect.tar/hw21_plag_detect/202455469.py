import sys

def points(a,b):
    """Count the number of points within a rectangle defined by two coordinates."""
    count = 0
    while (line := sys.stdin.readline()) != "":
        x, y = map(int, line.split())
        if x in range(a[0], b[0] + 1) and y in range(a[1], b[1] + 1):
            count +=1
    return count

def main():
    """Main Function"""
    coords = input().split()
    coord1 = [int(i) for i in coords[:2]]
    coord2 = [int(i) for i in coords[2:]]
    print(points(coord1, coord2))

if __name__ == "__main__":
    main()
