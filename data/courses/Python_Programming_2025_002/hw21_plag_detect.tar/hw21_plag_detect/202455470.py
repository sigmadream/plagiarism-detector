class Rectangle:
    """rectangle"""
    def __init__(self, x1, y1, x2, y2):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2
    
class Point:
    """A point"""
    def __init__(self, x, y):
        self.x = x
        self.y = y

def in_rectangle(x, y, x1, y1, x2, y2):
    """if the point (x, y) is inside the rectangle"""
    return x1 <= x <= x2 and y1 <= y <= y2

if __name__ == "__main__":
    import sys
    x1, y1, x2, y2 = map(int, sys.stdin.readline().strip().split())
    rect = Rectangle(x1, y1, x2, y2)
    """Read points and count how many are inside the rectangle."""
    count = 0
    for line in sys.stdin:
        if line.strip() == "":
            """Stop reading when an empty line is encountered"""
            break
        x, y = map(int, line.strip().split())
        pt = Point(x, y)
        """Check if the point is inside the rectangle"""
        if in_rectangle(pt.x, pt.y, rect.x1, rect.y1, rect.x2, rect.y2):
            count += 1
    """Print the count of points inside the rectangle"""
    print(count)
