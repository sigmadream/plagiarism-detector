import sys

class Point:
    """Represents a 2D point."""
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y

class Rectangle:
    """Represents a rectangle and supports checking if a point is inside or on its boundary."""
    def __init__(self, x1: int, y1: int, x2: int, y2: int):
        self.x_l = min(x1, x2)
        self.y_l = min(y1, y2)
        self.x_r = max(x1, x2)
        self.y_r = max(y1, y2)

    def contains(self, point: Point) -> bool:
        """Returns True if the point lies inside or on the rectangle."""
        return self.x_l <= point.x <= self.x_r and self.y_l <= point.y <= self.y_r

def main():
    """Reads input, counts points inside the rectangle, and prints the result."""
    lines = sys.stdin.read().splitlines()
    x_l, y_l, x_r, y_r = map(int, lines[0].split())
    rect = Rectangle(x_l, y_l, x_r, y_r)

    count = 0
    for line in lines[1:]:
        x, y = map(int, line.split())
        point = Point(x, y)
        if rect.contains(point):
            count += 1

    print(count)

if __name__ == "__main__":
    main()
