import sys
class Point:
    def __init__(self,x,y):
        """Point Class"""
        self.x = x
        self.y = y

class Rectangle:
    def __init__(self,bl,tr):
        """Rectangle Class"""
        self.bl = bl
        self.tr = tr
        self.total_points = 0

    def check_point(self,pt):
        """Check point method"""
        x, y = pt.x,pt.y
        if not (x < self.bl.x or x > self.tr.x or y < self.bl.y or y > self.tr.y):
            self.total_points += 1

i = list(map(int,input().split()))
rec = Rectangle(Point(i[0],i[1]),Point(i[2],i[3]))

for point in sys.stdin.readlines():
    if point.strip() == '':
        break
    point = list(map(int,point.split()))
    rec.check_point(Point(point[0],point[1]))

print(rec.total_points)
