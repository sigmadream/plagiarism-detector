import sys

class Point:
    '''
    Attributes:
        x: x coordinate
        y: y coordinate
    '''
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def __str__(self):
        return str((self.x, self.y))


class Rectangle:
    '''
    Attributes:
        dl: lower left corner
        ur: upper right corner
        dr: lower right corner
        ul: upper left corner
    Methods:
        onRectangle: determines if a Point p is on the rectangle
    '''
    def __init__(self, corner_dl, corner_ur):
        self.dl = corner_dl
        self.ur = corner_ur
        self.dr = Point(self.ur.x, self.dl.y)
        self.ul = Point(self.dl.x, self.ur.y)

    def on_rectangle(self, p):
        '''determines if p is on rectangle'''
        if (p.x <= self.ur.x) and (p.x >= self.dl.x) and (p.y <= self.ur.y) and (p.y >= self.dl.y):
            return True
        return False

def main():
    '''main'''
    rect_points = list(map(int, input().split()))
    rect = Rectangle(Point(rect_points[0], rect_points[1]), Point(rect_points[2], rect_points[3]))

    points_on_rect = 0

    for line in sys.stdin:
        points_coords = list(map(int, line.split()))
        point = Point(points_coords[0], points_coords[1])
        if rect.on_rectangle(point):
            points_on_rect += 1

    print(points_on_rect)


if __name__ == "__main__":
    main()
