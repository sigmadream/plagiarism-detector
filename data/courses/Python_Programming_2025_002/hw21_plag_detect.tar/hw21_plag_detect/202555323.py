# -*- coding: utf-8 -*-
""" 
Lab 11: Rectangle 안에 포함된 점의 개수 세기
"""

import sys

class Point:
    """2차원 공간의 점을 나타내는 클래스"""

    def __init__(self, x, y):
        self.x = x
        self.y = y

class Rectangle:
    """사각형을 나타내는 클래스. 두 꼭짓점으로 정의됨"""

    def __init__(self, xL, yL, xR, yR):
        self.xL = xL
        self.yL = yL
        self.xR = xR
        self.yR = yR

    def contains(self, point):
        """주어진 점이 사각형 내부 또는 경계에 포함되어 있는지 확인"""
        return (self.xL <= point.x <= self.xR) and (self.yL <= point.y <= self.yR)

def main():
    lines = sys.stdin.readlines()
    xL, yL, xR, yR = map(int, lines[0].strip().split())
    rect = Rectangle(xL, yL, xR, yR)

    count = 0
    for line in lines[1:]:
        if line.strip() == "":
            continue
        x, y = map(int, line.strip().split())
        pt = Point(x, y)
        if rect.contains(pt):
            count += 1

    print(count)

if __name__ == "__main__":
    main()