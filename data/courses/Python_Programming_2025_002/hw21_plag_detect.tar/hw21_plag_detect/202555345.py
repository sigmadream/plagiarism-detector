"""
Rectangle Point Inclusion Counter

This script defines two classes, `Rectangle` and `Point`, and counts how many
given points lie on or within a rectangle specified by its lower-left and upper-right corners.

Input:
- The first line from standard input contains four integers: xL yL xR yR,
  representing the coordinates of the lower-left and upper-right corners of the rectangle.
- Each subsequent line contains two integers representing the coordinates of a point.
- Input ends with an EOF signal (Ctrl+Z on Windows, Ctrl+D on Unix/Linux/Mac).

Example:
Input:
    0 0 2 3
    1 1
    2 5
    2 2
[Ctrl+Z + Enter]

Output:
    2

The script reads all input using `sys.stdin.readlines()` and prints the number of
points that lie on or inside the rectangle (edges included).
"""
import sys

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Rectangle:
    def __init__(self, xL, yL, xR, yR):
        self.xL = xL
        self.yL = yL
        self.xR = xR
        self.yR = yR

    def contains(self, point):
        return self.xL <= point.x <= self.xR and self.yL <= point.y <= self.yR

def main():
    lines = sys.stdin.readlines()
    if not lines:
        return  # Exit if no input

    xL, yL, xR, yR = map(int, lines[0].strip().split())
    rect = Rectangle(xL, yL, xR, yR)

    count = 0
    for line in lines[1:]:
        line = line.strip()
        if line == "":
            continue
        x, y = map(int, line.split())
        pt = Point(x, y)
        if rect.contains(pt):
            count += 1

    print(count)

if __name__ == "__main__":
    main()