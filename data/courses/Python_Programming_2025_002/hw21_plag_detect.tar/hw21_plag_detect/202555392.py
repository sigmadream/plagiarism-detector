import sys

class Rectangle:
    """rectangle class"""
    def __init__(self, x1, y1, x2, y2):
        self.x_range = set(range(min(x1, x2), max(x1, x2) + 1))
        self.y_range = set(range(min(y1, y2), max(y1, y2) + 1))
    def is_on_rectangle(self, point):
        """check if a specific point is on rectangle"""
        x, y = point.point
        if x in self.x_range and y in self.y_range:
            return True
        return False

class Point:
    """Point class"""
    def __init__(self, x, y):
        self.point = (x, y)

xl, yl, xr, yr = map(int, sys.stdin.readline().split())
points = sys.stdin.read().splitlines()
COUNT = 0
rectangle = Rectangle(xl, yl, xr, yr)

for line in points:
    a, b = map(int, line.split())
    coordinate = Point(a, b)
    if rectangle.is_on_rectangle(coordinate):
        COUNT += 1
sys.stdout.write(str(COUNT))
