import sys

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lab 11: Counting Points Included
Program to count points that lie within or on a rectangle boundary.
"""

import sys


class Point:
    """
    Represents a point in 2D coordinate system.
    
    Attributes:
        x (int): X-coordinate of the point
        y (int): Y-coordinate of the point
    """
    
    def __init__(self, x, y):
        """
        Initialize a Point with x and y coordinates.
        
        Args:
            x (int): X-coordinate
            y (int): Y-coordinate
        """
        self.x = x
        self.y = y
    
    def __str__(self):
        """
        String representation of the point.
        
        Returns:
            str: Point coordinates in format (x, y)
        """
        return f"({self.x}, {self.y})"


class Rectangle:
    """
    Represents a rectangle defined by lower-left and upper-right corners.
    
    Attributes:
        x_left (int): X-coordinate of lower-left corner
        y_lower (int): Y-coordinate of lower-left corner
        x_right (int): X-coordinate of upper-right corner
        y_upper (int): Y-coordinate of upper-right corner
    """
    
    def __init__(self, x_left, y_lower, x_right, y_upper):
        """
        Initialize a Rectangle with corner coordinates.
        
        Args:
            x_left (int): X-coordinate of lower-left corner
            y_lower (int): Y-coordinate of lower-left corner
            x_right (int): X-coordinate of upper-right corner
            y_upper (int): Y-coordinate of upper-right corner
        """
        self.x_left = x_left
        self.y_lower = y_lower
        self.x_right = x_right
        self.y_upper = y_upper
    
    def contains_point(self, point):
        """
        Check if a point lies within or on the boundary of the rectangle.
        
        Args:
            point (Point): The point to check
        
        Returns:
            bool: True if point is within or on rectangle boundary, False otherwise
        """
        return (self.x_left <= point.x <= self.x_right and 
                self.y_lower <= point.y <= self.y_upper)
    
    def __str__(self):
        """
        String representation of the rectangle.
        
        Returns:
            str: Rectangle corners in readable format
        """
        return f"Rectangle[({self.x_left}, {self.y_lower}) to ({self.x_right}, {self.y_upper})]"


def count_points_in_rectangle():
    """
    Main function to read input and count points within rectangle.
    Reads rectangle coordinates and points from standard input,
    then counts how many points lie within or on the rectangle.
    """
    lines = []
    
    # Read all input lines
    for line in sys.stdin:
        line = line.strip()
        if line == "":
            break
        lines.append(line)
    
    if not lines:
        return
    
    # Parse rectangle coordinates from first line
    rect_coords = list(map(int, lines[0].split()))
    x_left, y_lower, x_right, y_upper = rect_coords
    
    # Create rectangle object
    rectangle = Rectangle(x_left, y_lower, x_right, y_upper)
    
    # Count points within rectangle
    count = 0
    
    # Process each point from remaining lines
    for i in range(1, len(lines)):
        point_coords = list(map(int, lines[i].split()))
        x, y = point_coords
        
        # Create point object
        point = Point(x, y)
        
        # Check if point is within rectangle
        if rectangle.contains_point(point):
            count += 1
    
    # Output the count
    print(count)


if __name__ == "__main__":
    count_points_in_rectangle()

