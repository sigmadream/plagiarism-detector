# -*- coding: utf-8 -*-
"""
This program defines a Rectangle and Point class to count how many points lie on or within a rectangle.
"""

class Point:
    """
    Class representing a 2D point.

    Attributes:
        x (int): x-coordinate of the point.
        y (int): y-coordinate of the point.
    """
    def __init__(self, x, y):
        self.x = x
        self.y = y


class Rectangle:
    """
    Class representing a rectangle aligned to the axes.

    Attributes:
        xL (int): x-coordinate of the lower-left corner.
        yL (int): y-coordinate of the lower-left corner.
        xR (int): x-coordinate of the upper-right corner.
        yR (int): y-coordinate of the upper-right corner.
    """
    def __init__(self, xL, yL, xR, yR):
        self.xL = xL
        self.yL = yL
        self.xR = xR
        self.yR = yR

    def contains(self, point):
        """
        Determines if a point lies on or inside the rectangle.

        Args:
            point (Point): The point to check.

        Returns:
            bool: True if point is on or inside the rectangle, False otherwise.
        """
        return self.xL <= point.x <= self.xR and self.yL <= point.y <= self.yR


def process_input(input_lines):
    """
    Processes a batch of lines representing one test case.

    Args:
        input_lines (List[str]): List of input lines.

    Returns:
        int: Number of points on the rectangle.
    """
    rect_coords = list(map(int, input_lines[0].split()))
    rectangle = Rectangle(*rect_coords)

    count = 0
    for line in input_lines[1:]:
        if not line.strip():
            continue
        x, y = map(int, line.strip().split())
        point = Point(x, y)
        if rectangle.contains(point):
            count += 1
    return count


if __name__ == "__main__":
    import sys

    all_lines = sys.stdin.read().strip().split('\n')
    n = len(all_lines)
    i = 0

    while i < n:
        block = []
        # First line of the block (rectangle)
        while i < n and all_lines[i].strip() == "":
            i += 1  # skip empty lines
        if i >= n:
            break
        block.append(all_lines[i])
        i += 1

        # Read point lines until the next 4-number line or end
        while i < n:
            line = all_lines[i].strip()
            if line == "":
                i += 1
                continue
            parts = line.split()
            if len(parts) == 4:  # Start of new rectangle
                break
            elif len(parts) == 2:
                block.append(line)
            i += 1

        # Process current block
        print(process_input(block))