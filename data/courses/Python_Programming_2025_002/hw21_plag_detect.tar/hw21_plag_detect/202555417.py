import sys

class Point:
    """
    Represents a point in 2D space.
    
    Attributes:
        x (int): The x-coordinate of the point.
        y (int): The y-coordinate of the point.
    """
    def __init__(self, x, y):
        """
        Initializes a Point object with x and y coordinates.
        """
        self.x = x
        self.y = y

class Rectangle:
    """
    Represents a rectangle defined by the bottom-left and top-right corners.

    Attributes:
        xl (int): The x-coordinate of the bottom-left corner.
        yl (int): The y-coordinate of the bottom-left corner.
        xr (int): The x-coordinate of the top-right corner.
        yr (int): The y-coordinate of the top-right corner.
    """
    def __init__(self, xl, yl, xr, yr):
        """
        Initializes a Rectangle object.
        """
        self.xl = xl
        self.yl = yl
        self.xr = xr
        self.yr = yr

    def contains(self, point):
        """
        Checks if the given point is inside or on the boundary of the rectangle.

        Args:
            point (Point): The point to check.

        Returns:
            bool: True if the point is inside or on the rectangle, False otherwise.
        """
        return self.xl <= point.x <= self.xr and self.yl <= point.y <= self.yr

rec = input().split()
rectangle = Rectangle(int(rec[0]), int(rec[1]), int(rec[2]), int(rec[3]))

points = []
for line in sys.stdin.readlines():
    if line.strip() == "":
        break
    x, y = map(int, line.split())
    points.append(Point(x, y))

num = 0
for point in points:
    if rectangle.contains(point):
        num += 1

print(num)
