# -*- coding: utf-8 -*-
import sys

class Point:
    """Class representing a point in 2D space."""
    def __init__(self, x, y):
        """
        Initialize a point with x and y coordinates.
        
        :param x: The x-coordinate of the point.
        :param y: The y-coordinate of the point.
        """
        self.x = x
        self.y = y

class Rectangle:
    """Class representing a rectangle defined by its bottom-left and top-right corners."""
    def __init__(self, x_left, y_lower, x_right, y_upper):
        """
        Initialize a rectangle using the bottom-left and top-right corner coordinates.
        
        :param x_left: x-coordinate of the bottom-left corner.
        :param y_lower: y-coordinate of the bottom-left corner.
        :param x_right: x-coordinate of the top-right corner.
        :param y_upper: y-coordinate of the top-right corner.
        """
        self.x_left = x_left
        self.y_lower = y_lower
        self.x_right = x_right
        self.y_upper = y_upper

    def contains(self, point):
        """
        Check whether a point lies inside or on the border of the rectangle.
        
        :param point: A Point object to check.
        :return: True if the point lies within or on the boundary, False otherwise.
        """
        return (
            self.x_left <= point.x <= self.x_right and
            self.y_lower <= point.y <= self.y_upper)


def main():
    """
    Main function that reads input from standard input and counts how many points
    lie on or within the given rectangle. Outputs the count.
    """
    lines = sys.stdin.readlines()
    if not lines or len(lines) < 2:
        print(0)
        return

    # Read rectangle coordinates from the first line
    x_left, y_lower, x_right, y_upper = map(int, lines[0].strip().split())
    rect = Rectangle(x_left, y_lower, x_right, y_upper)

    count = 0
    # Read and evaluate each point
    for line in lines[1:]:
        if line.strip() == "":
            continue
        x, y = map(int, line.strip().split())
        pt = Point(x, y)
        if rect.contains(pt):
            count += 1

    print(count)

if __name__ == "__main__":
    main()
