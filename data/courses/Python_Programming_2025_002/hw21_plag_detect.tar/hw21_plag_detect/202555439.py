class Point:
    """Represents a point in a 2D Cartesian coordinate system."""
    def __init__(self, x, y):
        """Initializes a Point object."""
        self.x = x
        self.y = y

class Rectangle:
    """Represents a rectangle defined by its lower-left and upper-right corners."""
    def __init__(self, xL, yL, xR, yR):
        """Initializes a Rectangle object"""
        self.xL = xL
        self.yL = yL
        self.xR = xR
        self.yR = yR
    def contains(self, p):
        """Checks if a given Point is inside or on the boundary of this rectangle."""
        return self.xL <= p.x <= self.xR and self.yL <= p.y <= self.yR

def main():
    xL, yL, xR, yR = map(int, input().split())
    r = Rectangle(xL, yL, xR, yR)
    count = 0
    while True:
        try:
            x, y = map(int, input().split())
            if r.contains(Point(x, y)):
                count += 1
        except EOFError:
            break
        except:
            continue
    print(count)

if __name__ == "__main__":
    main()