import sys


class Point:
    """Point represents position in the x-y coordinate system"""

    x: int
    y: int

    def __init__(self, x_in: int, y_in: int):
        self.x = x_in
        self.y = y_in


class Rectangle:
    """Rectangle represents rectangle in the x-y coordinate system"""

    x1: int
    y1: int
    x2: int
    y2: int

    def __init__(self, x1: int, y1: int, x2: int, y2: int):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    def contain(self, point: Point):
        """contain method checks that rect contains a point"""
        if self.x1 <= point.x <= self.x2 and self.y1 <= point.y <= self.y2:
            return True

        return False


if __name__ == "__main__":
    rect_pos = list(map(int, input().split()))
    rect = Rectangle(*rect_pos)

    points: list[Point] = []

    for line in sys.stdin.readlines():
        if line.strip() == "":
            break

        x, y = map(int, line.split())

        points.append(Point(x, y))

    CNT = 0

    for p in points:
        if rect.contain(p):
            CNT += 1

    print(CNT)
