class DataError(Exception):
    """
    Custom exception to indicate invalid (non-integer) data in the input.
    
    Attributes:
        data (int): The partial sum before encountering the error.
    """
    def __init__(self, data):
        self.data = data

    def __str__(self):
        return f"({self.data})"

def robust_sum(line):
    """
    Parses a line of text and calculates the sum of valid integers.
    
    If a non-integer token is encountered, raises a DataError with
    the partial sum before the error.
    
    Args:
        line (str): A string containing space-separated data items.
    
    Returns:
        int: The total sum of all valid integers in the line.
    
    Raises:
        DataError: If a non-integer is encountered in the input.
    """
    total = 0
    for item in line.split():
        try:
            total += int(item)
        except ValueError as exc:
            raise DataError(total) from exc  # <-- Proper exception chaining
    return total


def main():
    """
    Continuously reads input lines from the user, computes the sum of integers
    on each line using `robust_sum`, and prints the result.
    
    If any line contains a non-integer, prints the partial sum in parentheses.
    Terminates upon encountering an empty line or EOF, printing "_EOT_".
    """
    while True:
        try:
            line = input()
            if line.strip() == "":
                print("_EOT_")
                break
            try:
                result = robust_sum(line)
                print(result)
            except DataError as e:
                print(e)
        except EOFError:
            print("_EOT_")
            break

if __name__ == "__main__":
    main()
