import sys
from dataclasses import dataclass

@dataclass
class DataError(Exception):
    '''예외 함수'''
    data: str
    partial_sum: int

def compute_sum(xs):
    '''합 계산'''
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError as exc:
            raise DataError(data=x, partial_sum=total) from exc

    return total

if __name__ == "__main__":
    results = []
    for line in sys.stdin.readlines():
        line = line.strip()
        if not line:
            continue
        items = line.split()
        try:
            result = compute_sum(items)
            results.append(str(result))
        except DataError as e:
            results.append(f"({e.partial_sum})")

    for r in results:
        print(r)
    print("_EOT_")
