from dataclasses import dataclass

@dataclass
class DataError(Exception):
    "Custom exception for errors in robust_sum"
    total: int
    bad_data: str

class EndOfTask(Exception):
    "Custom exception to signal the end of task"
    pass

def robust_sum(xs):
    "Robust sym function"
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError as exc:
            raise DataError(total, x) from exc
    return total

if __name__ == "__main__":
    lines = []
    try:
        while True:
            line = input()
            if line.strip() == "":
                break  # Stop reading at the first empty line
            lines.append(line)
    except EOFError:
        pass  # Handle Ctrl+D/Z gracefully in case no empty line is entered

    res = []
    for line in lines:
        xs = line.split()
        try:
            res.append(str(robust_sum(xs)))
        except DataError as e:
            res.append(f"({e.total})")

    for r in res:
        print(r)
    print("_EOT_")
