
class EmptyLineError(Exception):
    pass

class NonIntegerError(Exception):
    def __init__(self, partial_sum):
        self.partial_sum = partial_sum

def compute_sum(items):
    total = 0
    for item in items:
        try:
            num = int(item)
            total += num
        except ValueError:
            raise NonIntegerError(total)
    return total

def main():
    while True:
        try:
            line = input()
        except EOFError:
            print("_EOT_")
            break


        if line.strip() == "":
            try:
                raise EmptyLineError()
            except EmptyLineError:
                print("_EOT_")
                break

        items = line.strip().split()
        try:
            result = compute_sum(items)
            print(result)
        except NonIntegerError as e:
            print(f"({e.partial_sum})")

if __name__ == "__main__":
    main()
