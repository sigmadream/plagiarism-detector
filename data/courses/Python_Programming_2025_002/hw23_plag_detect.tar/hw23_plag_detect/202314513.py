import sys

class NonIntegerData(Exception):
    """Raised when non-integer data is found in a line."""
    def __init__(self, value):
        self.value = value

def compute_sum(tokens):
    """Returns the sum of a list of tokens; raises exception on non-integer."""
    total = 0
    for token in tokens:
        try:
            total += int(token)
        except ValueError as exc:
            raise NonIntegerData(token) from exc
    return total

def main():
    """Reads lines until empty line or EOF, computes sums, and prints results."""
    while (line := sys.stdin.readline()) != "":
        line = line.strip()
        if not line:
            break

        tokens = line.split()

        try:
            total = compute_sum(tokens)
            print(total)
        except NonIntegerData:
            partial = 0
            for t in tokens:
                try:
                    partial += int(t)
                except ValueError:
                    break
            print(f'({partial})')

    print("_EOT_")

main()
