from dataclasses import dataclass


@dataclass
class BadDataError(Exception):
    """Exception raised for non-integer input data."""
    data: str


class BlankLineError(Exception):
    """Exception raised for a blank input line."""


class EndOfTaskError(Exception):
    """Exception raised to terminate the task."""


def calculate_sum(input_line):
    """Calculate sum of integers in the input line. Raise custom exceptions when needed."""
    if input_line.strip() == "":
        raise EndOfTaskError()

    total = 0
    for token in input_line.strip().split():
        try:
            total += int(token)
        except ValueError as exc:
            raise BadDataError(token) from exc
    return total


if __name__ == "__main__":
    while True:
        try:
            raw_input_line = input()

            try:
                result = calculate_sum(raw_input_line)
                print(result)

            except BadDataError as err:
                temp_sum = 0
                for word in raw_input_line.strip().split():
                    try:
                        temp_sum += int(word)
                    except ValueError:
                        break
                print(f"({temp_sum})")

        except EndOfTaskError:
            print("_EOT_")
            break
