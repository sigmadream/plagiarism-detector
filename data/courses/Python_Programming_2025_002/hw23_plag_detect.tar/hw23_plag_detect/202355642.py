from dataclasses import dataclass

@dataclass
class DataError(Exception):
    data: str

@dataclass
class EmptyLineError(Exception):
    pass

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(x)
    return total

while True:
    try:
        line = input()
        if line.strip() == "":
            raise EmptyLineError()
        tokens = line.strip().split()
        try:
            print(robust_sum(tokens))
        except DataError as e:
            partial = 0
            for t in tokens:
                try:
                    partial += int(t)
                except ValueError:
                    break
            print(f"({partial})")
    except EmptyLineError:
        print("_EOT_")
        break