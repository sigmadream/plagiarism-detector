
class EmptyLineException(Exception):
    pass

class EndOfTaskException(Exception):
    pass

def robust_sum(line):
    """
    Compute the sum of positive integers from a line.
    If a non-integer item is found, raise ValueError with the item.
    """
    tokens = line.split()
    total = 0
    for token in tokens:
        try:
            num = int(token)
            if num <= 0:
                raise ValueError(token)
            total += num
        except ValueError:
            raise ValueError(token)
    return total

def main():
    while True:
        try:
            line = input()
            if line == "":
                raise EmptyLineException()
            try:
                s = robust_sum(line)
                print(s)
            except ValueError as e:
                partial_sum = 0
                tokens = line.split()
                for token in tokens:
                    try:
                        num = int(token)
                        if num <= 0:
                            raise ValueError(token)
                        partial_sum += num
                    except ValueError:
                        break
                print(f"({partial_sum})")

        except EmptyLineException:
            raise EndOfTaskException()
        except EndOfTaskException:
            print("_EOT_")
            break

if __name__ == "__main__":
    main()