from dataclasses import dataclass

@dataclass
class DataError(Exception):
    data: str
    partial_sum: int

class EmptyLineError(Exception):
    pass

def calculate_robust_sum(items):
    total = 0
    for item in items:
        try:
            total += int(item)
        except ValueError:
            raise DataError(item, total)
    return total

def process_input_lines():
    while True:
        try:
            line = input()
        except EOFError:
            break  # Just in case there's EOF

        if line.strip() == "":
            raise EmptyLineError()

        items = line.strip().split()
        try:
            result = calculate_robust_sum(items)
            print(result)
        except DataError as e:
            print(f"({e.partial_sum})")

def main():
    try:
        process_input_lines()
    except EmptyLineError:
        print("_EOT_")

if __name__ == "__main__":
    main()
