from dataclasses import dataclass

@dataclass
class DataError(Exception):
    """Exception raised when an item cannot be converted to an integer."""
    data: str

def robust_sum(tokens):
    """Compute the sum of a list of items, raising DataError on invalid input."""
    total = 0
    for token in tokens:
        try:
            total += int(token)
        except ValueError as exc:
            raise DataError(token) from exc
    return total

while True:
    line = input()
    if line.strip() == "":
        print("_EOT_")
        break

    fields = line.split()
    try:
        print(robust_sum(fields))
    except DataError as e:
        partial_sum = 0
        for field in fields:
            try:
                partial_sum += int(field)
            except ValueError:
                break
        print(f"({partial_sum})")
