'''
Write a robust summation program that repeatedly reads a line containing several positive
 integers and prints the sum of them. If any of the data items of the line is not an integer,
 your program should raise an exception and handle this with the problematic data item.
 To handle the exception, the partial sum should be printed in a pair of parentheses. Your
 program should repeat this procedure until you meet an empty line. Encountering an
 empty line, your program should print _EOT_ denoting the “end of task.”
 The input consists of more than one line, each of which contains several data items.
 Your program should print the sum of the integers of every line. If a line contains a non
integral data item, the partial sum before the malformed data should be printed in a pair
 of parentheses. The number of output lines is less than the number of input lines since the
 program should terminate when encountering an empty line.
 Additional requirements for bonus points
 1. You have to define and use a function computing the sum with a meaningful name.
 2. You have to define and use two user-defined exceptions to handle the empty line.

'''

# from dataclasses import dataclass

# class EmptyLineException(Exception):
#     pass

# class EndOfTaskException(Exception):
#     pass

# @dataclass
# class DataError(Exception):
#     data: str
#     partial_sum: int

# def robust_sum(items):
#     total = 0
#     for item in items:
#         try:
#             total += int(item)
#         except ValueError:
#             raise DataError(item, total)
#     return total

# def main():
#     try:
#         while True:
#             try:
#                 line = input()
#                 if line.strip() == "":
#                     raise EmptyLineException()
#                 items = line.strip().split()
#                 try:
#                     s = robust_sum(items)
#                     print(s)
#                 except DataError as e:
#                     print(f"({e.partial_sum})")
#             except EmptyLineException:
#                 raise EndOfTaskException()
#     except EndOfTaskException:
#         print("_EOT_")

# if __name__ == "__main__":
#     main()





# from dataclasses import dataclass

# @dataclass
# class DataError(Exception):
#     data: str

# def robust_sum(xs):
#     total = 0
#     for x in xs:
#         try:
#             total += int(x)
#         except ValueError:
#             raise DataError(x)
#     return total

# if __name__ == "__main__":
#     xs = [10, 21, "thirty one", 40, 5]
#     ys = [10, 21, 31, 40, 5]

#     for ls in [xs, ys]:
#         try:
#             print(robust_sum(ls))
#         except DataError as e:
#             print(f"Error: neglecting '{e.data}'")

from dataclasses import dataclass

# Exception for non-integer input
@dataclass
class DataError(Exception):
    data: str

# Exception for empty input line (first one stops processing)
class EmptyLineError(Exception):
    pass

# Exception to signal stopping further processing
class StopProcessingError(Exception):
    pass

def compute_robust_sum(data_items):
    """Compute sum of integers in data_items until a non-integer is found."""
    total = 0
    for item in data_items:
        try:
            total += int(item)
        except ValueError:
            raise DataError(item)
    return total

def main():
    try:
        while True:
            try:
                line = input().strip()
                if line == "":
                    raise EmptyLineError

                parts = line.split()
                try:
                    total = compute_robust_sum(parts)
                    print(total)
                except DataError as e:
                    index = parts.index(e.data)
                    partial_sum = compute_robust_sum(parts[:index])
                    print(f"({partial_sum})")

            except EmptyLineError:
                print("_EOT_")
                raise StopProcessingError

    except StopProcessingError:
        pass

if __name__ == "__main__":
    main()
