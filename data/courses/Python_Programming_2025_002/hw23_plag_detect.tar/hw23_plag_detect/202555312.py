import sys

class EmptyLine(Exception):
    "exception for empty line"

class EOTError(Exception):
    "exception passed"

def get_sum(l):
    "obtains sum from line"
    try:
        sum_ = 0
        if l.strip() == "":
            raise EmptyLine()
        split_line = l.split()
        for number in split_line:
            sum_ += int(number)

    except EmptyLine as exc:
        raise EOTError() from exc
    except ValueError:
        return "(" + str(sum_) + ")"
    return str(sum_)


def main():
    "main function"
    exception = False
    for line in sys.stdin:
        try:
            print(get_sum(line))
        except EOTError:
            print("_EOT_")
            exception = True
            break
    if not exception:
        print("_EOT_")

if __name__ == "__main__":
    main()
