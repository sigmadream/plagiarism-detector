from dataclasses import dataclass

# 2. User-Defined Exception for Data Errors
@dataclass
class DataError(Exception):
    data: str
    partial_sum: int # To store the sum before the error

# 4. User-Defined Exceptions for Empty Lines (Bonus)
class EmptyLineError(Exception):
    pass

class EndOfTaskError(Exception):
    pass

# 1. Robust Summation Function
def robust_sum(line_str):
    total = 0
    items = line_str.split()
    if not items:
        raise EmptyLineError # Raise for empty line
    for x in items:
        try:
            total += int(x)
        except ValueError:
            # Pass the current total along with the problematic data
            raise DataError(data=x, partial_sum=total)
    return total

# Main program
if __name__ == "__main__":
    while True:
        try:
            line = input()
            if not line:
                raise EndOfTaskError # Signal end of task on empty line

            # 1. and 3. Call robust_sum and handle DataError
            current_sum = robust_sum(line)
            print(current_sum)

        except DataError as e:
            # 3. Handle DataError: print partial sum in parentheses
            print(f"({e.partial_sum})")
        except EmptyLineError:
            # This case might be caught by EndOfTaskError in current setup if we simply check `if not line`.
            # For strict adherence to "two user-defined exceptions to handle the empty line"
            # we can refine this.
            pass # Or handle specific empty line logic if different from EOT
        except EndOfTaskError:
            # 5. Handle EndOfTaskError: print _EOT_ and break
            print("_EOT_")
            break
        except EOFError: # Handle Ctrl+D or end of file input
            print("_EOT_")
            break