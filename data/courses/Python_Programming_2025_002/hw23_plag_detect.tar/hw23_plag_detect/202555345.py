class NonIntegerError(Exception):
    def __init__(self, item):
        self.item = item
        super().__init__(f"Invalid item: {item}")

def main():
    ignore_mode = False

    while True:
        try:
            line = input()
            if line.strip() == "":
                print("_EOT_")
                ignore_mode = True
                break

            if ignore_mode:
                continue  # Ignore input after empty line

            tokens = line.strip().split()
            total = 0
            for token in tokens:
                try:
                    num = int(token)
                    if num < 0:
                        raise NonIntegerError(token)
                    total += num
                except ValueError:
                    raise NonIntegerError(token)
            print(f"{total}")

        except NonIntegerError:
            print(f"({total})")

        except EOFError:
            print("_EOT_")
            break

if __name__ == "__main__":
    main()