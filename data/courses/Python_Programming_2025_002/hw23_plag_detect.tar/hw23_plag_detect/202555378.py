# Two custom exceptions for bonus
class EmptyLine(Exception):
    pass

class BadNumber(Exception):
    pass

# Sum function for bonus
def sum_numbers(data):
    total = 0
    for item in data:
        total += int(item)
    return total

# Main loop
while True:
    try:
        line = input()
        
        if line == "":
            raise EmptyLine()
        
        numbers = line.split()
        result = sum_numbers(numbers)
        print(result)
        
    except ValueError:
        # Bad data found, calculate partial sum
        partial = 0
        for item in line.split():
            try:
                partial += int(item)
            except ValueError:
                break
        print(f"({partial})")
        
    except EmptyLine:
        print("*EOT*")
        break