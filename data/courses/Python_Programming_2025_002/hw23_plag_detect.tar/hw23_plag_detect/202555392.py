while True:
    RESULT = 0
    try:
        line = input()
        if not line:
            break
    except EOFError:
        break
    for item in line.split():
        if not item.isdigit():
            print(f"({RESULT})")
            break
        RESULT += int(item)
    else:
        print(RESULT)
print("_EOT_")
