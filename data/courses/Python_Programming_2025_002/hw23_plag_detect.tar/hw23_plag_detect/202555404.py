from dataclasses import dataclass

@dataclass
class DataError(Exception):
    """Exception raised when encountering non-integer data"""
    data: str
    partial_sum: int

@dataclass 
class EmptyLineError(Exception):
    """Exception raised when encountering an empty line"""
    pass

def compute_robust_sum(data_items):
    """
    Computes the sum of integers from a list of data items.
    Raises DataError if a non-integer item is encountered.
    """
    total = 0
    for item in data_items:
        try:
            total += int(item)
        except ValueError:
            raise DataError(item, total)
    return total

def main():
    """Main program loop that processes input lines until empty line is encountered"""
    try:
        while True:
            line = input()
            
            # Check for empty line
            if line.strip() == "":
                raise EmptyLineError()
            
            # Split the line into data items
            data_items = line.split()
            
            # Try to compute the sum
            try:
                result = compute_robust_sum(data_items)
                print(result)
            except DataError as e:
                print(f"({e.partial_sum})")
                
    except EmptyLineError:
        print("_EOT_")
    except EOFError:
        # Handle case where input ends without empty line
        print("_EOT_")

if __name__ == "__main__":
    main()