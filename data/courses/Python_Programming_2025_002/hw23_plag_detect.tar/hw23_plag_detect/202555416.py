import sys

class EmptyLineException(Exception):
    """Exception raised when an empty line is encountered."""
    pass

class EndOfTaskException(Exception):
    """Exception raised to terminate the summation program."""
    pass

def process_line_and_print_sum(line):
    """
    Processes a line of input, computes sum of valid integers,
    and handles invalid items by printing partial sum in parentheses.
    """
    items = line.split()
    total = 0
    for item in items:
        try:
            num = int(item)
            total += num
        except ValueError:
            # Invalid integer encountered, print partial sum in parentheses
            print(f"({total})")
            return
    # All items were valid integers
    print(total)

def main():
    """
    Main loop that reads input lines until an empty line is encountered.
    Handles exceptions and ends with a specific message.
    """
    exception_happened = False
    try:
        for line in sys.stdin:
            if line.strip() == "":
                raise EmptyLineException
            process_line_and_print_sum(line)
    except EmptyLineException:
        exception_happened = True
        print("_EOT_")
        raise EndOfTaskException("End of Task")
    
    if not exception_happened:
        print("_EOT_")

if __name__ == "__main__":
    try:
        main()
    except EndOfTaskException:
        # Graceful termination of the program
        pass
