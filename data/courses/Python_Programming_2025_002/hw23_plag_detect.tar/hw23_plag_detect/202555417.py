import sys

class DataError(Exception):
    """Raised when a non-integer value is encountered."""
    def __init__(self, total, bad_data):
        self.total = total
        self.bad_data = bad_data

class EmptyLineError(Exception):
    """Raised when the first empty line is encountered."""
    pass

def robust_sum(xs):
    total = 0
    for x in xs:
        try:
            total += int(x)
        except ValueError:
            raise DataError(total, x)
    return total

lines = sys.stdin.read().splitlines()  # Read all input lines at once
outputs = []
empty_line_encountered = False

for line in lines:
    line = line.strip()
    if line == "":
        if not empty_line_encountered:
            empty_line_encountered = True
            outputs.append("_EOT_")
        else:
            outputs.append("")  # Just a blank line
        continue
    tokens = line.split()
    try:
        result = robust_sum(tokens)
        outputs.append(str(result))
    except DataError as e:
        outputs.append(f"({e.total})")


# Print all results after input
for out in outputs:
    print(out)
