def simple_init(cls):
    def __init__(self, data):
        self.data = data
    cls.__init__ = __init__
    return cls

@simple_init
class DataError(Exception):
    """Exception for invalid data item."""
    pass

class EndOfTaskError(Exception):
    """Exception raised on empty input line."""
    ...

def compute_line_sum(items):
    """Sum integers in items or raise DataError if invalid."""
    total = 0
    for item in items:
        try:
            total += int(item)
        except ValueError as exc:
            raise DataError(item) from exc
    return total

def main():
    """Read lines, sum integers, handle errors, and stop on empty line."""
    while True:
        try:
            line = input().strip()
            if line == "":
                raise EndOfTaskError()
            
            items = line.split()
            try:
                result = compute_line_sum(items)
                print(result)
            except DataError as e:
                partial_sum = 0
                for item in items:
                    if item == e.data:
                        break
                    try:
                        partial_sum += int(item)
                    except ValueError:
                        break
                print(f"({partial_sum})")
        except EndOfTaskError:
            print("_EOT_")
            break

if __name__ == "__main__":
    main()
