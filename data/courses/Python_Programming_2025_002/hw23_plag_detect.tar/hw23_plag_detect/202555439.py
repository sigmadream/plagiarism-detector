from dataclasses import dataclass

@dataclass
class MalformedDataError(Exception):
    p_s: int 

class EmptyLineError(Exception):
    pass

def calc_sum(seq):
    p_s = 0
    for s in seq:
        try:
            if not s.isdecimal():
                raise ValueError
            p_s += int(s)
        except ValueError:
            raise MalformedDataError(p_s=p_s)
    return p_s

while True:
    try:
        line = input()
        if not line:
            raise EmptyLineError()
        print(calc_sum(line.split()))
    except MalformedDataError as e:
        print(f"({e.p_s})")
    except EmptyLineError:
        print("_EOT_")
        break
    except EOFError:
        print("_EOT_")
        break