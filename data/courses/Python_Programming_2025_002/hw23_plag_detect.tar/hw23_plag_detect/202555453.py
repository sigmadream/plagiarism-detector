class StrToNumError(Exception):
  error_num_str: str
  prev_sum: int

  def __init__(self, error_num_str: str, prev_sum: int):
    self.error_num_str = error_num_str
    self.prev_sum = prev_sum

class EmptyLineError(Exception):
  pass

class MyEOFError(EOFError):
  pass

def sum_appropriate_num(line: str):
  s = 0

  if line.strip() == "":
    raise EmptyLineError()

  for num_str in line.split():
    if num_str.isdigit():
      s += int(num_str)
    else:
      raise StrToNumError(error_num_str=num_str, prev_sum=s)
    
  return s

def main():
  while True:
    try:
      line = input()
      x = sum_appropriate_num(line)

      print(x)
    except StrToNumError as e:
      print(f"({e.prev_sum})")
    except EmptyLineError:
      print("_EOT_")
      break
    except EOFError:
      print("_EOT_")
      break
      
    

if __name__ == "__main__":
  main()