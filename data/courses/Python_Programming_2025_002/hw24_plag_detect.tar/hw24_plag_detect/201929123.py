from dataclasses import dataclass
import sys

@dataclass
class Point:
    '''x, y point를 저장'''
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __str__(self):
        return f"({self.x}, {self.y})"

def calculate_slope(point1, point2):
    """
    두 점 point1과 point2 사이의 기울기를 계산.
    x-좌표가 같으면 y-좌표의 차이를 반환.
    """
    if point1.x == point2.x:
        return point2.y - point1.y

    return (point2.y - point1.y) / (point2.x - point1.x)

if __name__ == "__main__":
    try:
        line1 = sys.stdin.readline().split()
        x1 = int(line1[0])
        y1 = int(line1[1])
        p1 = Point(x1, y1)

        line2 = sys.stdin.readline().split()
        x2 = int(line2[0])
        y2 = int(line2[1])
        p2 = Point(x2, y2)

        result = calculate_slope(p1, p2)

        if p1.x == p2.x:
            print(f"({result:.2f})")
        else:
            print(f"{result:.2f}")

    except ValueError:
        pass

    finally:
        print("_EOC_")
