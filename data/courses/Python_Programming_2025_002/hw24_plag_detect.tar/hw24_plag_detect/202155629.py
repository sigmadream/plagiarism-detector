from dataclasses import dataclass

@dataclass
class Point:
    """
    decorated class Point
    representing a 2D point with x, y coordinates
    """
    x: int
    y: int

class DataError(Exception):
    """
    custom exception
    case when slope cannot be calculated  
    """
    def __init__(self, difference):
        self.difference = difference

def slope(p1: Point, p2: Point):
    "function for computing the slope between two points"
    # if x coordinates are equal
    if p1.x == p2.x:
        difference = abs(p2.y - p1.y)
        # raise an exception
        # printing the difference of y coordinates
        raise DataError(difference)
    # calculating the slope by using the formula:
    # slope(p, q) = (y_q - y_p) / (x_q - x_p)
    return (p2.y - p1.y) / (p2.x - p1.x)

if __name__ == "__main__":
    try:
        # waiting for user inputs
        line1 = input().split()
        line2 = input().split()
        # parsing two input points
        point1 = Point(int(line1[0]), int(line1[1]))
        point2 = Point(int(line2[0]), int(line2[1]))
        # calculating and printing the slope
        result = slope(point1, point2)
        # rounding up to two decimal places after the decimal point
        print(f"{result:.2f}")
    except DataError as exc:
        # printing the difference of y coordinates
        # if the slope cannot be calculated
        print(f"({exc.difference:.2f})")
    print("_EOC_")
