# slope.py

from dataclasses import dataclass

class VerticalLineError(Exception):
    def __init__(self, diff_y: float):
        super().__init__(diff_y)
        self.diff_y = diff_y


@dataclass
class Point:
    x: int
    y: int


def compute_slope(p: Point, q: Point) -> float:
    if p.x == q.x:
        diff = abs(q.y - p.y)
        raise VerticalLineError(diff)
    return (q.y - p.y) / (q.x - p.x)


def main():
    x1, y1 = map(int, input().split())
    x2, y2 = map(int, input().split())

    p = Point(x1, y1)
    q = Point(x2, y2)

    try:
        slope = compute_slope(p, q)
        print(f"{slope:.2f}")
    except VerticalLineError as e:
        print(f"({e.diff_y:.2f})")

    print("_EOC_")


if __name__ == "__main__":
    main()
