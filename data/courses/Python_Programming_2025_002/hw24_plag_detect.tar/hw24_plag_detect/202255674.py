from dataclasses import dataclass

class SlopeCalculationError(Exception):
    def __init__(self, dy):
        self.dy = dy

@dataclass
class Point:
    x: int
    y: int

def calculate_slope(p1: Point, p2: Point) -> float:
    dx = p2.x - p1.x
    dy = p2.y - p1.y
    if dx == 0:
        raise SlopeCalculationError(dy)
    return dy / dx

def main():
    try:
        x1, y1 = map(int, input().strip().split())
        x2, y2 = map(int, input().strip().split())
        p1 = Point(x1, y1)
        p2 = Point(x2, y2)
        try:
            slope = calculate_slope(p1, p2)
            print(f"{slope:.2f}")
        except SlopeCalculationError as e:
            print(f"({abs(e.dy):.2f})")
    except Exception as e:
        print(f"Unexpected error: {e}")
    print("_EOC_")

if __name__ == "__main__":
    main()
