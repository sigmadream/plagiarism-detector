from dataclasses import dataclass
import sys

@dataclass
class Point:
    """A class representing a 2D point with x and y coordinates."""
    x: int
    y: int

class UndefinedSlope(Exception):
    """Raised when slope is undefined due to identical x-coordinates."""
    def __init__(self, delta_y: float):
        self.delta_y = delta_y

def compute_slope(p1: Point, p2: Point) -> float:
    """Computes the slope of two points, or raises an exception if undefined."""
    if p1.x == p2.x:
        raise UndefinedSlope(abs(p2.y - p1.y))
    return (p2.y - p1.y) / (p2.x - p1.x)

def main():
    """Reads two points from input and prints the slope or the difference in y."""
    line1 = sys.stdin.readline()
    line2 = sys.stdin.readline()

    x1, y1 = map(int, line1.strip().split())
    x2, y2 = map(int, line2.strip().split())

    p1 = Point(x1, y1)
    p2 = Point(x2, y2)

    try:
        slope = compute_slope(p1, p2)
        print(f"{slope:.2f}")
    except UndefinedSlope as e:
        print(f"({e.delta_y:.2f})")

    print("_EOC_")

if __name__ == "__main__":
    main()
