from dataclasses import dataclass

# 사용자 정의 예외: 기울기 계산 불가능한 경우
class SlopeError(Exception):
    def __init__(self, dy):
        self.dy = dy

# 보너스 조건: Point 클래스
@dataclass
class Point:
    x: int
    y: int

# 기울기 계산 함수
def slope(p1: Point, p2: Point) -> float:
    if p1.x == p2.x:
        raise SlopeError(abs(p2.y - p1.y))
    return (p2.y - p1.y) / (p2.x - p1.x)

# 입력 처리 및 출력
if __name__ == "__main__":
    x1, y1 = map(int, input().split())
    x2, y2 = map(int, input().split())

    p1 = Point(x1, y1)
    p2 = Point(x2, y2)

    try:
        result = slope(p1, p2)
        print(f"{result:.2f}")
    except SlopeError as e:
        print(f"({e.dy:.2f})")

    print("_EOC_")
