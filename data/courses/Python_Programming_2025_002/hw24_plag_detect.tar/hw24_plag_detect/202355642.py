class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class VerticalLineError(Exception):
    pass

a = list(map(int, input().split()))
b = list(map(int, input().split()))
p1 = Point(a[0], a[1])
p2 = Point(b[0], b[1])

try:
    if p1.x == p2.x:
        raise VerticalLineError
    result = (p2.y - p1.y) / (p2.x - p1.x)
    print(f"{result:.2f}")
except VerticalLineError:
    print(f"({abs(p2.y - p1.y):.2f})")

print("_EOC_")