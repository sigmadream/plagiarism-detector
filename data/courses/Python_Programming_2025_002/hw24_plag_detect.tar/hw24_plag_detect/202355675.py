from dataclasses import dataclass

class SlopeError(Exception):
    """error"""
    def __init__(self, dy):
        self.dy = abs(dy)

    def __str__(self):
        return f"({self.dy:.2f})"

@dataclass
class Point:
    """Represents a point in 2D space."""
    x: int
    y: int

def findslope(p1, p2):
    """"""
    dx = p2.x - p1.x
    dy = p2.y - p1.y
    if dx == 0:
        raise SlopeError(dy)
    return dy / dx

def main():
    """main"""
    try:
        x1,y1 = map(int, input().split())
        x2,y2 = map(int, input().split())
        p1 = Point(x1,y1)
        p2 = Point(x2,y2)
        result = findslope(p1,p2)
        print(f"{result:.2f}")
    except SlopeError as e:
        print(e)
    finally:
        print("_EOC_")

if __name__ == "__main__":
    main()
