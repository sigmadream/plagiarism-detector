from dataclasses import dataclass

class DataError(Exception):
    """x좌표 같아 기울기를 계산할 수 없는 경우"""
    def __init__(self, y1, y2):
        self.y_diff = abs(y2 - y1)

@dataclass
class Point:
    """점 좌표"""
    x: int
    y: int

def calculate_slope(p1: Point, p2: Point) -> float:
    """기울기"""
    if p1.x == p2.x:
        raise DataError(p1.y, p2.y)
    return (p2.y - p1.y) / (p2.x - p1.x)

if __name__ == "__main__":
    x1, y1 = map(int, input().split())
    x2, y2 = map(int, input().split())

    point1 = Point(x1, y1)
    point2 = Point(x2, y2)

    try:
        slope = calculate_slope(point1, point2)
        print(f"{slope:.2f}")
    except DataError as e:
        print(f"({e.y_diff:.2f})")

    print("_EOC_")
