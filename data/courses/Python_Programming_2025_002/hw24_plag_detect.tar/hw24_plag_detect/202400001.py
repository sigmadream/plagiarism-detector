from dataclasses import dataclass


@dataclass
class DataError(Exception):
    data: str
    partial_sum: int


class EmptyLineError(Exception):
    pass


def robust_sum(tokens: list[str]) -> int:
    """
    tokens 리스트에 대해 한 토큰씩 정수로 변환을 시도하며 합을 계산한다.
    정수로 변환할 수 없는 토큰이 나오면 DataError를 발생시킨다.
    """
    total = 0
    for tok in tokens:
        try:
            num = int(tok)
            total += num
        except ValueError:
            raise DataError(data=tok, partial_sum=total)
    return total


def main():
    while True:
        try:
            line = input().strip()
            if line == "":
                raise EmptyLineError()

            tokens = line.split()
            total = robust_sum(tokens)
            print(total)

        except DataError as e:
            print(f"({e.partial_sum})")

        except EmptyLineError:
            print("_EOT_")
            break


if __name__ == "__main__":
    main()
