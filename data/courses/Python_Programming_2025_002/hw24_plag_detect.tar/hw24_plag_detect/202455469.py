from dataclasses import dataclass

class UndefinedSlopeError(Exception):
    """Exception raised when the slope is undefined (vertical line)."""

@dataclass
class Point:
    """Data class to represent a point in 2D space."""
    x: int
    y: int

def calculate_slope(p1: Point, p2: Point) -> float:
    """Calculate the slope between two points."""
    if p1.x == p2.x:
        raise UndefinedSlopeError
    return (p2.y - p1.y) / (p2.x - p1.x)

def main():
    """Main function."""
    try:
        x1, y1 = map(int, input().strip().split())
        x2, y2 = map(int, input().strip().split())

        p1 = Point(x1, y1)
        p2 = Point(x2, y2)

        try:
            slope = calculate_slope(p1, p2)
            print(f"{slope:.2f}")
        except UndefinedSlopeError:
            dy = abs(p2.y - p1.y)
            print(f"({dy:.2f})")
    finally:
        print("_EOC_")

if __name__ == "__main__":
    main()
