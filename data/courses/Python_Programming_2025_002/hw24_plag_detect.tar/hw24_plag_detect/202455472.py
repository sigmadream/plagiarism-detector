class SlopeError(Exception):
    '''Class represing an error'''
    def __init__(self, y_diff):
        self.y_diff = y_diff

    def __str__(self):
        return f"({self.y_diff:.2f})"

def slope(point1, point2):
    '''Function to find the slope between two points'''
    x1, y1 = point1
    x2, y2 = point2
    if x1 == x2:
        raise SlopeError(abs(y2 - y1))
    return round((y2 - y1) / (x2 - x1), 2)

def main():
    '''Main function'''
    point1 = map(int, input().strip().split())
    point2 = map(int, input().strip().split())
    try:
        result = slope(point1, point2)
        print(f"{result:.2f}")
    except SlopeError as e:
        print(e)
    print("_EOC_")

if __name__ == "__main__":
    main()
