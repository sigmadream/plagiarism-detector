class SlopeError(Exception):
    """Exception raised when the slope of two points cannot be calculated (vertical line)."""


class Point:
    """Represents a point in a two-dimensional plane with x and y coordinates."""
    def __init__(self, x, y):
        """
        Initialize a Point object.

        :param x: x-coordinate (integer)
        :param y: y-coordinate (integer)
        """
        self.x = x
        self.y = y


def calculate_slope(p, q):
    """
    Calculate the slope between two points.

    :param p: First Point object
    :param q: Second Point object
    :return: The slope as a formatted string with two decimal places.
    :raises SlopeError: If the slope cannot be calculated (division by zero).
    """
    if p.x == q.x:
        raise SlopeError(f"({round(q.y - p.y, 2):.2f})")
    slope = (q.y - p.y) / (q.x - p.x)
    return f"{round(slope, 2):.2f}"


def main():
    """
    Main function to read input points, calculate and print the slope.
    Handles the exceptional case when the slope cannot be calculated.
    """
    x1, y1 = map(int, input().split())
    x2, y2 = map(int, input().split())
    p = Point(x1, y1)
    q = Point(x2, y2)

    try:
        slope = calculate_slope(p, q)
        print(slope)
    except SlopeError as e:
        print(e)
    finally:
        print("_EOC_")  # end of calculation


if __name__ == "__main__":
    main()
