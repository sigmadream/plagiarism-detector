'''
Write a robust summation program that repeatedly reads a line containing several positive
 integers and prints the sum of them. If any of the data items of the line is not an integer,
 your program should raise an exception and handle this with the problematic data item.
 To handle the exception, the partial sum should be printed in a pair of parentheses. Your
 program should repeat this procedure until you meet an empty line. Encountering an
 empty line, your program should print _EOT_ denoting the “end of task.”
 The input consists of more than one line, each of which contains several data items.
 Your program should print the sum of the integers of every line. If a line contains a non
integral data item, the partial sum before the malformed data should be printed in a pair
 of parentheses. The number of output lines is less than the number of input lines since the
 program should terminate when encountering an empty line.
 Additional requirements for bonus points
 1. You have to define and use a function computing the sum with a meaningful name.
 2. You have to define and use two user-defined exceptions to handle the empty line.

'''

from dataclasses import dataclass

class EmptyLineException(Exception):
    pass

class EndOfTaskException(Exception):
    pass

class print_nothing_exception(Exception):
    pass

@dataclass
class DataError(Exception):
    data: str
    partial_sum: int

def robust_sum(items):
    total = 0
    for item in items:
        try:
            total += int(item)
        except ValueError:
            raise DataError(item, total)
    return total

def main():
    stopped = False
    while True:
        line = input()
        if stopped:
            print()
            continue
        if line.strip() == "":
            print("_EOT_")
            stopped = True
            continue
        items = line.strip().split()
        try:
            s = robust_sum(items)
            print(s)
        except DataError as e:
            print(f"({e.partial_sum})")

if __name__ == "__main__":
    main()
