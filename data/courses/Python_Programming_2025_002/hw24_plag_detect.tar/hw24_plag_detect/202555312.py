class Point:
    """point"""
    def __init__(self, coords):
        self.x = coords[0]
        self.y = coords[1]
    def difference(self, p):
        return Point([self.x - p.x, self.y - p.y])


def main():
    point_1 = Point(list(map(int, input().split() )))
    point_2 = Point(list(map(int, input().split() )))

    diff = point_1.difference(point_2)

    try:
        slope = diff.y / diff.x
    except:
        print(f"({(diff.y if diff.y >= 0 else -1 * diff.y):.2f})")
    else:
        print(f"{slope:.2f}")
    finally:
        print("_EOC_")


if __name__ == "__main__":
    main()
