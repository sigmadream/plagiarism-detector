class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class UndefinedSlopeError(Exception):
    pass

def calculate_slope(p, q):
    delta_x = q.x - p.x
    delta_y = q.y - p.y

    if delta_x == 0:
        raise UndefinedSlopeError(delta_y)
    else:
        return delta_y / delta_x
    
if __name__ == "__main__":
    try:
        x1_str, y1_str = input().split()
        p = Point(int(x1_str), int(y1_str))

        x2_str, y2_str = input().split()
        q = Point(int(x2_str), int(y2_str))

        slope = calculate_slope(p, q)
        print(f"{slope:.2f}")

    except UndefinedSlopeError as e:
        print(f"({abs(e.args[0]):.2f})")
    
    except ValueError:
        print("Invalid input. Please enter integers for coordinates.")
    
    finally:
        print("_EOC_")