class NoSlopeError(Exception):
    def __init__(self, y1, y2):
        self.y1 = y1
        self.y2 = y2
    def __str__(self):
        return f"({abs(self.y1 - self.y2):.2f})"
    
def check_slope(x1, y1, x2, y2):
    if x1 == x2:
        raise NoSlopeError(y1, y2)

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def slope(self, x, y):
        if y - self.y != 0:
            return f"{(y - self.y) / (x - self.x):.2f}"
        else:
            return f"{(y - self.y) / abs(x - self.x)}"

x1, y1 = map(int, input().split())
p1 = Point(x1, y1)
x2, y2 = map(int, input().split())
try:
    check_slope(x1, y1, x2, y2)
    print(p1.slope(x2, y2))
except NoSlopeError as e:
    print(e)
finally:
    print("_EOC_")
