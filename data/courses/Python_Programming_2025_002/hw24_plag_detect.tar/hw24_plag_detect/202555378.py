import math
from dataclasses import dataclass

class SlopeError(Exception):
    def __init__(self, y_diff_abs: float):
        self.y_diff = y_diff_abs
        super().__init__(
            f"Cannot calculate slope: x-coordinates are identical. Y difference: {self.y_diff:.2f}"
        )

@dataclass
class Point:
    x: int
    y: int

def calculate_slope(p1: Point, p2: Point) -> float:
    if p1.x == p2.x:
        raise SlopeError(abs(p2.y - p1.y))
    
    return (p2.y - p1.y) / (p2.x - p1.x)

def main():
    try:
        x1, y1 = map(int, input().split())
        p1 = Point(x1, y1)

        x2, y2 = map(int, input().split())
        p2 = Point(x2, y2)

        slope = calculate_slope(p1, p2)
        
        print(f"{slope:.2f}")

    except SlopeError as e:
        print(f"({e.y_diff:.2f})")
    except ValueError:
        print("Invalid input: Please ensure coordinates are integers separated by a space.")
    except EOFError:
        print("Error: No input provided.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        print("_EOC_")

if __name__ == "__main__":
    main()
