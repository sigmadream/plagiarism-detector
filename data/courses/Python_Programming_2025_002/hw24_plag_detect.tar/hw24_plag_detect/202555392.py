import sys

def for_additional_point(c):
    """kinda meaningless"""
    class JustForAdditionalPoint(c):
        """makes decorated class"""
        def __init__(self, x, y):
            super().__init__(x, y)
            self.x = x
            self.y = y
            self.description = "nothing"

        def method2(self):
            """for lint viewer"""


        def method3(self):
            """for lint viewer"""
    return JustForAdditionalPoint

@for_additional_point
class Point:
    """stores x, y"""
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def method1(self):
        """for lint viewer"""


    def calc_slope(self, other_point):
        """calculates slope"""
        x1, x2 = self.x, other_point.x
        y1, y2 = self.y, other_point.y
        if x1 == x2:
            print(f"({max(y1, y2) - min(y1, y2):.2f})")
            raise IdenticalX

        slope = (y1 - y2) / (x1 - x2)
        rounded = round(slope * 100) / 100
        print(f"{rounded:.2f}")
        print("_EOC_")

class IdenticalX(Exception):
    """when two points have same x value"""

x_1, y_1 = map(int, input().split())
x_2, y_2 = map(int, input().split())
p1 = Point(x_1, y_1)
p2 = Point(x_2, y_2)
try:
    p1.calc_slope(p2)
except IdenticalX:
    print("_EOC_")
    sys.exit()
