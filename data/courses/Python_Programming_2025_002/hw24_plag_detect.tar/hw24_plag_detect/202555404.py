class Point:
    """A decorated class to represent a point in 2D plane"""
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __str__(self):
        return f"Point({self.x}, {self.y})"
    
    def __repr__(self):
        return self.__str__()


class VerticalLineException(Exception):
    """Custom exception for when slope cannot be calculated (vertical line)"""
    
    def __init__(self, y_diff):
        self.y_diff = y_diff
        super().__init__(f"Cannot calculate slope: vertical line")


def calculate_slope(point1, point2):
    """
    Calculate the slope between two points.
    Raises VerticalLineException if x-coordinates are identical.
    """
    if point1.x == point2.x:
        y_diff = abs(point2.y - point1.y)  # Take absolute value for difference
        raise VerticalLineException(y_diff)
    
    slope = (point2.y - point1.y) / (point2.x - point1.x)
    return slope


def main():
    # Read input for first point
    x1, y1 = map(int, input().split())
    point1 = Point(x1, y1)
    
    # Read input for second point
    x2, y2 = map(int, input().split())
    point2 = Point(x2, y2)
    
    try:
        # Calculate slope
        slope = calculate_slope(point1, point2)
        print(f"{slope:.2f}")
    except VerticalLineException as e:
        # Handle the case where slope cannot be calculated
        # Print absolute difference of y coordinates in parentheses
        print(f"({e.y_diff:.2f})")
    
    print("_EOC_")


if __name__ == "__main__":
    main()