from dataclasses import dataclass


class SlopeUndefinedError(Exception):
    """Custom exception raised when slope is undefined."""
    def __init__(self, y_diff):
        self.y_diff = y_diff
        super().__init__(f"Slope undefined, y-difference: {y_diff:.2f}")


@dataclass
class Point:
    x: int
    y: int


def calculate_slope(p1: Point, p2: Point) -> float:
    if p1.x == p2.x:
        raise SlopeUndefinedError(abs(p2.y - p1.y))
    return (p2.y - p1.y) / (p2.x - p1.x)


def main():
    try:
        x1, y1 = map(int, input().strip().split())
        x2, y2 = map(int, input().strip().split())

        point1 = Point(x1, y1)
        point2 = Point(x2, y2)

        slope = calculate_slope(point1, point2)
        print(f"{slope:.2f}")
    except SlopeUndefinedError as e:
        print(f"({e.y_diff:.2f})")
    finally:
        print("_EOC_")


if __name__ == "__main__":
    main()