from dataclasses import dataclass

@dataclass
class Point:
    """
    Represents a point in 2D space.
    Attributes:
        x (int): The x-coordinate of the point.
        y (int): The y-coordinate of the point.
    """
    x: int
    y: int

# Read two points from input
x1, y1 = map(int, input().split())
x2, y2 = map(int, input().split())

p1 = Point(x1, y1)
p2 = Point(x2, y2)

# Calculate and print the slope or vertical distance
if p1.x == p2.x:
    print(f"({abs(p2.y - p1.y):.2f})")
else:
    slope = (p2.y - p1.y) / (p2.x - p1.x)
    print(f"{slope:.2f}")

print("_EOC_")
