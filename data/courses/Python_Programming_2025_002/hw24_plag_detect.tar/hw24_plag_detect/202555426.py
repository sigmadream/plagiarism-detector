from dataclasses import dataclass

class SlopeUndefinedError(Exception):
    """Raised when the slope is undefined (vertical line)."""
    def __init__(self, y_diff):
        self.y_diff = y_diff


@dataclass
class Point:
    """Represents a 2D point."""
    x: int
    y: int


def slope(p1: Point, p2: Point) -> float:
    """Returns the slope of two points or raises an error if undefined."""
    if p1.x == p2.x:
        raise SlopeUndefinedError(abs(p2.y - p1.y))
    return (p2.y - p1.y) / (p2.x - p1.x)


def main():
    """Reads input, calculates slope, and prints the result."""
    try:
        x1, y1 = map(int, input().split())
        x2, y2 = map(int, input().split())

        p1 = Point(x1, y1)
        p2 = Point(x2, y2)

        result = slope(p1, p2)
        print(f"{result:.2f}")
    except SlopeUndefinedError as e:
        print(f"({e.y_diff:.2f})")

    print("_EOC_")


if __name__ == "__main__":
    main()
