from dataclasses import dataclass

@dataclass
class Point():
    """a point defined by a pair of x and y coords"""
    x_coord: int
    y_coord: int

class ZeroXDiffError(Exception):
    """error raised when x difference is 0"""

p, q = Point(*map(int, input().split())), Point(*map(int, input().split()))
y_diff, x_diff = q.y_coord - p.y_coord, q.x_coord - p.x_coord

try:
    if x_diff == 0:
        raise ZeroXDiffError
except ZeroXDiffError:
    print(f"({abs(y_diff):.2f})")
else:
    print(f"{(y_diff / x_diff):.2f}")
print("_EOC_")
