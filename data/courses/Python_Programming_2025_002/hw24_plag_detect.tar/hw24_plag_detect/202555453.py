from __future__ import annotations
import math


class SlopeCalcError(Exception):
    """Error occurs when the difference involving x is zero."""

    p1: Point
    p2: Point

    def __init__(self, p1: Point, p2: Point):
        self.p1 = p1
        self.p2 = p2


class Point:
    """Point represents point in x-y coordinates."""

    x: int
    y: int

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y

    @staticmethod
    def calc_slope(p1: Point, p2: Point):
        """calc_slope calculate slope about two points."""
        if p1.x == p2.x:
            raise SlopeCalcError(p1, p2)

        slope = (p2.y - p1.y) / (p2.x - p1.x)

        if slope < 0:
            return -(math.ceil(-1 * slope * 10**2) / 10**2)

        return math.ceil(slope * 10**3) / 10**3


def main():
    """main function"""
    x1, y1 = map(int, input().split())
    p1 = Point(x1, y1)

    x2, y2 = map(int, input().split())
    p2 = Point(x2, y2)

    try:
        ans = Point.calc_slope(p1, p2)

        print(f"{ans:.2f}")
    except SlopeCalcError:
        print(f"({abs(p2.y - p1.y):.2f})")

    print("_EOC_")


if __name__ == "__main__":
    main()
