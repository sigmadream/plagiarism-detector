import sys
minV=2147483648
maxV=-minV
def minF(a,b):
	return a if a < b else b
	
def maxF(a,b):
	return a if a > b else b
while (line := sys.stdin.readline()) != "":
	a = int(line)
	maxV = maxF(maxV, a)
	minV = minF(minV, a)
print(maxV-minV)