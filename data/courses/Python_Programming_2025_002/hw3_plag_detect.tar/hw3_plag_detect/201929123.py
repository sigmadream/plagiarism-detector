import sys

first = int(input())
max, min = first, first 

while (line:= sys.stdin.readline()) != "":
    N = int(line)
    if N > max:
        max = N
    elif N < min:
        min = N

print(max - min)

    
    