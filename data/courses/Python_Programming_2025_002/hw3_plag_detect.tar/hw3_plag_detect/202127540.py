#coding: utf-8

import sys

max_num = -2 ** 31
min_num = 2 ** 31 - 1

while (line := sys.stdin.readline()) != "":
    n = int(line)
    if max_num < n:
        max_num = n
    if min_num > n:
        min_num = n
        

print(f"{max_num - min_num}")
