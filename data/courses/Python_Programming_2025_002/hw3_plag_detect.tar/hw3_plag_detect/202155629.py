import sys

# reading the first number
line = sys.stdin.readline()
# initializing minimum and maximum values
min_num = max_num = int(line) if line else 0

# reading the remaining integers
while (line := sys.stdin.readline()) != "":
    num = int(line)
    
    # if the new value < existing minimum
    # updating the minimum value, else remaining the same
    min_num = num if num < min_num else min_num

    # if the new value > existing maximum
    # updating the maximum value, else remaining the same
    max_num = num if num > max_num else max_num

# calculating & printing the diameter
diameter = max_num - min_num
print(diameter)
