import sys
a=(-2)**31
b=(2)**31-1
while(line:=sys.stdin.readline())!="":
    x=int(line)
    if(x>a and x<b):
        a=x
        b=x
    elif(x>a):
        a=x
    elif(x<b):
        b=x
print(a-b)
