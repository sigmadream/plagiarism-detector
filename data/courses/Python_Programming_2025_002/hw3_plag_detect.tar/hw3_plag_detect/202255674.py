# coding: utf-8
import sys

first = True

while (line := sys.stdin.readline()) != "":
    num = int(line)  

    max_num = num if first or num > max_num else max_num
    min_num = num if first or num < min_num else min_num
    
    first = False if first else first

# 지름 계산 후 출력
diameter = max_num - min_num
print(diameter)
