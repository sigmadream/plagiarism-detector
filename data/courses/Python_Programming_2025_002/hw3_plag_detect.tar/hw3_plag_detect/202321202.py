import sys

min = float('inf')
max = float('-inf')

while (line := sys.stdin.readline()) != "":
    num = int(line)
    min = num if num < min else min
    max = num if num > max else max

print(max - min)