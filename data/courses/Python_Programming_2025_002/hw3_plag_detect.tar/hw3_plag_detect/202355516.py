import sys

numbers = []

try:
    while True:
        line = input().strip()
        if line:
            numbers.append(int(line))
except EOFError:
    if numbers:
        print(max(numbers) - min(numbers))
