import sys

mi = ma = int(sys.stdin.readline())

while (line := sys.stdin.readline()) != "":
    num = int(line)
    mi, ma = (num, ma) if num < mi else (mi, num) if num > ma else (mi, ma)

print(ma - mi)