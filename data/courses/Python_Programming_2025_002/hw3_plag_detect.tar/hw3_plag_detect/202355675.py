import sys

def set_min(A):
    mini = float('inf') 
    for num in A:
        if num < mini:
            mini = num
    return mini

def set_max(A):
    maxi = float('-inf')  
    for num in A:
        if num > maxi:
            maxi = num
    return maxi

numbers = []
while (line := sys.stdin.readline().strip()) != "":
    try:
        num = int(line)
        numbers.append(num)
    except ValueError:
        print("error")
        continue

if numbers:  
    max_num = set_max(numbers)
    min_num = set_min(numbers)
    diameter = max_num - min_num
    print(diameter)
else:
    print("No numbers provided.")
