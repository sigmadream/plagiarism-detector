#coding : utf-8
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
import sys
numbers = []
while (line := sys.stdin.readline()) != "":
    num = int(line)
    numbers.append(num)

if numbers:
    max_num = max(numbers)
    min_num = min(numbers)
    print(max_num - min_num)