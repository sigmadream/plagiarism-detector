﻿import sys


def main():
    numbers = []

    while (line := sys.stdin.readline()) != "":
        number = line[:-1]
        if not number:
            break

        numbers.append(int(number))

    largest_number = find_largest(numbers)
    smallest_number = find_smallest(numbers)

    diameter = largest_number - smallest_number
    print(diameter)


def find_largest(numbers):
    largest = -2 ** 31
    for i in range(len(numbers)):
        a = numbers[i]
        largest = a if a > largest else largest

    return largest


def find_smallest(numbers):
    smallest = 2 ** 31 - 1

    for i in range(len(numbers)):
        a = numbers[i]
        smallest = a if a < smallest else smallest

    return smallest


if __name__ == "__main__":
    main()
