n = int(input())
num1 = int(input())
minimum, maximum = num1, num1

for _ in range(n-1):
    num2 = int(input())
    minimum = (num2 < minimum) * num2 + (num2 >= minimum) * minimum
    maximum = (num2 > maximum) * num2 + (num2 <= maximum) * maximum

diameter = maximum - minimum
print(diameter)