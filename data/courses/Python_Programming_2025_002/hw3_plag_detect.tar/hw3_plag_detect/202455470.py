import sys
first= sys.stdin.readline()
min_val, max_val = int(first),int(first)
for line in sys.stdin:
    num=int(line)
    min_val= num if num<min_val else min_val
    max_val= num if num>max_val else max_val
print(max_val - min_val)
