import sys

# Read the first int
n = int(sys.stdin.readline().strip())
min_val, max_val = n, n

# Read the rem
for line in sys.stdin:
    num = int(line.strip())
    min_val = num if num < min_val else min_val
    max_val = num if num > max_val else max_val

# Print d (max - min)
print(max_val - min_val)
