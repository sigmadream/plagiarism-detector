import sys

l = []
minn = 2147483649
maxx = -2147483649
while (line := sys.stdin.readline()) != "":
    n = int(line)
    maxx = (n if n > maxx else maxx)
    minn = (n if n < minn else minn)

print(maxx-minn)