#coding: utf-8

import sys

max = -2147483649
min = 2147483648

while(line := sys.stdin.readline()) != "":
    n = int(line)
    max = (n if n > max else max)
    min = (n if n < min else min)

print(max-min)
