import sys

first = int(sys.stdin.readline())
minval = first
maxval = first

while (line := sys.stdin.readline().strip()) != "":
    num = int(line)
    maxval = num if num > maxval else maxval
    minval = num if num < minval else minval
    
print(maxval - minval)
