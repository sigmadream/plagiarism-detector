#coding: utf-8
import sys

a = 0
max1 = 0
min1 = 0
while (line := sys.stdin.readline()) != "":
    if (not a):
        max1 = int(line)
        min1 = int(line)
        a = 1
    else:
        if (int(line) > max1):
            max1 = int(line)
        elif (int(line) < min1):
            min1 = int(line)
        
diameter = max1 - min1
print(diameter)
    
