import sys
highest, lowest = 0, 2147483647 + 1
while (number := sys.stdin.readline()) != "":
    number = int(number)
    highest = number if number > highest else highest
    lowest = number if number < lowest else lowest

print(highest-lowest)