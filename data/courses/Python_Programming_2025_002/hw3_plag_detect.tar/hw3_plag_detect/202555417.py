import sys
line= sys.stdin.readline()
first_num= int(line)
max_num=first_num
min_num=first_num
while(line:= sys.stdin.readline()) !="":
    num=int(line)
    max_num=num if num>max_num else max_num
    min_num=num if num<min_num else min_num
diameter=max_num-min_num
print(diameter)
