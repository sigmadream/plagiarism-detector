import sys

cnt = 0
while (line := sys.stdin.readline()) != '':
	n = int(line)
	max_n = n if cnt == 0 else (n if n > max_n else max_n)
	min = n if cnt == 0 else (n if n < min else min)
	cnt += 1
	
print(max_n - min)