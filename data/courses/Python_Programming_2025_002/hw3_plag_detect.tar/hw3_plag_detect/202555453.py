#coding: utf-8
import sys

min_int = 2 ** 31 - 1
max_int = -2 ** 31

while (line := sys.stdin.readline()) != "":
    num = int(line)

    min_int = num if num < min_int else min_int
    max_int = num if num > max_int else max_int

print(max_int - min_int)