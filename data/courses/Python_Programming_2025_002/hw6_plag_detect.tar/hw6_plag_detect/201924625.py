def sum_black_squares(x, y):
    return 16 * (2 * x * y + 7 * (x + y) + 24)
x, y = map(int, input().split())
print(sum_black_squares(x, y))