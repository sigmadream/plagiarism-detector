x, y = map(int,input().split())

sum = 0
for i in range(x + 1, x + 8 ,2):
    for j in range(y, y + 8, 2):
        sum += i*j

for i in range(x, x + 8 ,2):
    for j in range(y+1, y + 8, 2):
        sum += i*j

print(sum)

