#coding: utf-8

asked_num = input().split()
x = int(asked_num[0])
y = int(asked_num[1])

result = 0
i = 0
j = 0
for all in range(64):
    i = all // 8
    j = all % 8
    if (i + j) % 2 == 1:
        result += (x + i) * (y + j)

print(result)