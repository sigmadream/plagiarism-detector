# reading the coordinate of the upper-left corner

# splitting the input
coordinates = input().split()
# an empty list for storing coordinates
coord_list = []
# converting and adding the inputs to a new list
coord_list.append(int(coordinates[0]))
coord_list.append(int(coordinates[1]))
# assigning the values to x and y coordinates
x = int(coord_list[0])
y = int(coord_list[1])

# calculating the sum of black squares

# initalizing the sum to 0
sum = 0 
# looping through 64 squares of the 8x8 chessboard
for k in range(64): 
    # calculating the row index  
    i = k // 8  # integer division by 8
    # computing the column index    
    j = k % 8   # remainder of division by 8

    # checking if the square is black
    # if the sum of the row and column indices is odd
    # -> black square
    if (i + j) % 2 == 1:
        # calculating the product of the multiplication table coordinates
        # x + i = row value, y + i = column value
        sum += (x + i) * (y + j)

# printing the final result
print(sum)