def is_black(i, j):
    return (i + j) % 2 == 1

def calculate(x, y):
    s = 0
    for i in range(8):
        for j in range(8):
            if is_black(i, j):
                r = x + i
                c = y + j
                s += r * c
    return s
line = input()
words = line.split()
ns = []
for word in words:
    ns.append(int(word))
print(calculate(ns[0],ns[1]))