def offset(i):
    if i % 2 == 0:
        return 1
    else:
        return 0

line = input()
words = line.split()
x = int(words[0])
y = int(words[1])

output = 0
for k in range(32):
    i = k // 4
    j = (k % 4) * 2 + offset(i) 
    output += (y + i) * (x + j)

print(output)
