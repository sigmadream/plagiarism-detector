x, y = map(int, input().split())

if not (1 <= x <= 92 and 1 <= y <= 92):
    print(0)
    exit()

total = 0

for i in range(8):
    for j in range(8):
        if (i + j) % 2 == 1:
            a = x + i
            b = y + j
            total += a * b

print(total)
