def main():
    x, y = map(int, input().split())
    total = 0
    for i in range(8):
        for j in range(8):
            if (i + j) % 2 == 1:
                row = y + i
                col = x + j
                total += row * col
    print(total)

main()
