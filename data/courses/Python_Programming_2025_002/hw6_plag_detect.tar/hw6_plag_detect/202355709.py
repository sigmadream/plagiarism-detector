X, Y = input().split()
x = int(X)
y = int(Y)
total = 0

for i in range(8):
    for j in range(8):
        if (i + j) % 2 == 1:
            total += (x + j) * y
    y += 1

print(total)
