def nib_sum(x, y):
    total = 0
    for i in range(8):
        xi = x + i
        j = 1 if i % 2 == 0 else 0
        total += xi * (y + j) + xi * (y + j + 2) + xi * (y + j + 4) + xi * (y + j + 6)
    return total

line = input()
words = line.split()
x = int(words[0])
y = int(words[1])
print(nib_sum(x, y))