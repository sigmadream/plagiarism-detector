﻿line = input()
words = line.split()
x = int(words[0])
y = int(words[1])

total = sum(
    (x + i) * (y + j)
    for i in range(8)
    for j in range(8)
    if (i + j) % 2 == 1
)

print(total)
