#coding: utf-8

def add(a, b):
    return a + b

line = str(input())
words = line.split()
ns = []
for word in words:
    ns.append(int(word))
x = ns[0]
y = ns[1]
b = y + 1
sum1 = 0
sum2 = 0

for n in range(y, y+8, 2):
    sum1 += y*(x+1)+y*(x+3)+y*(x+5)+y*(x+7)
    y += 2

for n in range(y, y+8, 2):
    sum2 += b*(x)+b*(x+2)+b*(x+4)+b*(x+6)
    b += 2

print(sum1+sum2)
