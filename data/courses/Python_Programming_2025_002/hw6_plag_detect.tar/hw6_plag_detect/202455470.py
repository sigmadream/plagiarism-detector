line = input().strip()
x, y = map(int, line.split())
total = sum(
    (x + i) * (y + j)
    for i in range(8) 
    for j in range(8) 
    if (i + j) % 2 == 1
)
print(total)
