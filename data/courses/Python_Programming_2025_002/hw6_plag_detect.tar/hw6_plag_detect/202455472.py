x,y= map(int, input().split())
total = 0
for i in range (8):
    for j in range(8):
        row = x + i
        column = y + j
        if (i+j)%2 == 1:
            total += row * column

print(total)
