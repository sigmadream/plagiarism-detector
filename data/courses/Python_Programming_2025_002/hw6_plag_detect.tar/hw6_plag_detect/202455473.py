def main():
    x, y = map(int, input().split())
    total_sum = 0
    for i in range(8):
        for j in range(8):
            if (i + j) % 2 == 1:
                total_sum += (x + i) * (y + j)
    print(total_sum)
if __name__ == "__main__":
    main()
