user_input = input()
x,y = user_input.split()

x = int(x)
y = int(y)

l = [x*y for x in range(x, x + 8)]
total = 0
odd = True
k = 1

for i in range(1,9):
    if odd:
        k = 1
    else:
        k = 0
    total += l[k] + l[k+2] + l[k+4] + l[k+6]
    odd = not odd
    l[0] = x * (y + i)
    l[1] = (x+1) * (y + i)
    l[2] = (x+2) * (y + i)
    l[3] = (x+3) * (y + i)
    l[4] = (x+4) * (y + i)
    l[5] = (x+5) * (y + i)
    l[6] = (x+6) * (y + i)
    l[7] = (x+7) * (y + i)

print(total)