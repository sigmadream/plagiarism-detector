def isOdd(a):
    return a % 2 # 1 is equal to True and 0 is equal to False. Returning this value is equal to returning True for odd numbers and False for even.

rawInput = input()
rawLeftString = ""
rawTopString = ""

inputParser = 0 # using the split function creates a list. Therefore, I decided to implement my own parser using only strings.
while(rawInput[inputParser] != " "):
    rawLeftString += rawInput[inputParser]
    inputParser += 1

left = int(rawLeftString)
top = int(rawInput[inputParser + 1:])

totalSum = 0 # initialization

for cursor in range(64): # there are guaranteed to be 64 squares in a chessboard, this code iterates through all of them linearly from 0 to 63.
# Note that this type of implementation is only required for bonus points.
# However, iterating from 1 to 8 for X and 1 to 8 for Y still uses the same principle.
# The only difference is that you would not need to go through the process of getting the X and Y coordinates separately.

    cursorX = cursor % 8 + 1 # see explanation below
    cursorY = cursor // 8 + 1
    if isOdd(cursorX + cursorY):
        totalSum += (cursorX + left - 1) * (cursorY + top - 1)

print(totalSum)

# Bonus points strategy: In total, not a single list has been used.
# Every operation that could have been done through a list was instead done with strings and loops.
# I have no idea if you're meant to go this far though.

'''
The Explanation Below in Question
Chessboard Diagram, format: (square number: x coordinate, y coordinate). Square 0 is white.
+------------+------------+------------+------------+------------+------------+------------+------------+
| ( 0: 1, 1) | ( 1: 2, 1) | ( 2: 3, 1) | ( 3: 4, 1) | ( 4: 5, 1) | ( 5: 6, 1) | ( 6: 7, 1) | ( 7: 8, 1) |
+------------+------------+------------+------------+------------+------------+------------+------------+
| ( 8: 1, 2) | ( 9: 2, 2) | (10: 3, 3) | (11: 4, 4) | (12: 5, 5) | (13: 6, 6) | (14: 7, 7) | (15: 8, 8) |
+------------+------------+------------+------------+------------+------------+------------+------------+
| (16: 1, 3) | (17: 2, 3) | (18: 3, 3) | (19: 4, 3) | (20: 5, 3) | (21: 6, 3) | (22: 7, 3) | (23: 8, 3) |
+------------+------------+------------+------------+------------+------------+------------+------------+
| (24: 1, 4) | (25: 2, 4) | (26: 3, 4) | (27: 4, 4) | (28: 5, 4) | (29: 6, 4) | (30: 7, 4) | (31: 8, 4) |
+------------+------------+------------+------------+------------+------------+------------+------------+
| (32: 1, 5) | (33: 2, 5) | (34: 3, 5) | (35: 4, 5) | (36: 5, 5) | (37: 6, 5) | (38: 7, 5) | (39: 8, 5) |
+------------+------------+------------+------------+------------+------------+------------+------------+
| (40: 1, 6) | (41: 2, 6) | (42: 3, 6) | (43: 4, 6) | (44: 5, 6) | (45: 6, 6) | (46: 7, 6) | (47: 8, 6) |
+------------+------------+------------+------------+------------+------------+------------+------------+
| (48: 1, 7) | (49: 2, 7) | (50: 3, 7) | (51: 4, 7) | (52: 5, 7) | (53: 6, 7) | (54: 7, 7) | (55: 8, 7) |
+------------+------------+------------+------------+------------+------------+------------+------------+
| (56: 1, 8) | (57: 2, 8) | (58: 3, 8) | (59: 4, 8) | (60: 5, 8) | (61: 6, 8) | (62: 7, 8) | (63: 8, 8) |
+------------+------------+------------+------------+------------+------------+------------+------------+
First of all, let's take the coordinate for each square given its number.
We can observe that the X coordinate increases every square, but can never exceed 8.
This almost always means that such a situation can be resolved using mod(%).
As such, the X coordinate can be taken as (number % 8). However, because I wanted to work with numbers greater than 0, I added 1 to the result.

The Y coordinate increases every 8 squares.
This can be recreated using the integer division operation.
Similarily, the Y coordinate can be taken as (number // 8). I added 1 to the result again for the same reason.

Now, let's look at the white and black squares. I have no idea what the mathematical proof for this is, but by observation, we can see a pattern.
If we add up the coordinates of a white square, the sum is an even number. (e. g. Square 18: 3 + 3 = 6)
Conversely, if we add up the coordinates of a black square, the sum is an odd number. (e. g. Square 51: 4 + 7 = 11)
Note that this has nothing to do with the parity of the square's number, as both 0 and 8 are even, yet they have different colors.
'''
