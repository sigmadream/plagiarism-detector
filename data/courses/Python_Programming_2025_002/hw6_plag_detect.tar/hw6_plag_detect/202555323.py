def sum_black_squares(x, y):
    total = 0
    for row in range(8):
        for col in range(8):
            if (row + col) % 2 == 1:  
                total += (x + row) * (y + col)
    return total
x, y = map(int, input().split())
print(sum_black_squares(x, y))