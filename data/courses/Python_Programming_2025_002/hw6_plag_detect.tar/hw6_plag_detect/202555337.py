x1, y1 = input().split()
x1 = int(x1)
y1 = int(y1)

total = 0 
for i in range(8):
    for j in range(8):
        if (i+j)%2 == 1:
            total += (x1+i)*(y1+j)
print(total)
