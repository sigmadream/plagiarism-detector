def sum(x, y):
    total = 0
    for i in range(8):
        for j in range(8):
            if (i + j) % 2 == 1:
                total += (x + i) * (y + j)
    return total
x, y = map(int, input().split())
print(sum(x, y))