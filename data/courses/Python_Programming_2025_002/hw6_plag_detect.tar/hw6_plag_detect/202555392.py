x, y = map(int, input().split())
result = 0
rows = list(range(x, x+8))
board = [rows[:] for i in range(8)]
for row in board:
    row[0] *= y
    row[1] *= y
    row[2] *= y
    row[3] *= y
    row[4] *= y
    row[5] *= y
    row[6] *= y
    row[7] *= y
    y += 1
for j, row in enumerate(board):
    if (j % 2) == 0:
        result += row[1] + row[3] + row[5] + row[7]
    else:
        result += row[0] + row[2] + row[4] + row[6]

print(result)