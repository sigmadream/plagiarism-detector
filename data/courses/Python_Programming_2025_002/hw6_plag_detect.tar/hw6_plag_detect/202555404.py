# nib.py

def sum_black_squares(x, y):
    total = 0
    for i in range(8):
        for j in range(8):
            if (i + j) % 2 == 1:  # Black square
                row = x + i
                col = y + j
                total += row * col
    return total

# Read input
x, y = map(int, input().split())

# Calculate and print result
result = sum_black_squares(x, y)
print(result)
