def sum_black_squares(x, y):
    # Precompute the relative indices of the black squares
    black_squares = [(0, 1), (0, 3), (0, 5), (0, 7), (1, 0), (1, 2), (1, 4), (1, 6),
                     (2, 1), (2, 3), (2, 5), (2, 7), (3, 0), (3, 2), (3, 4), (3, 6),
                     (4, 1), (4, 3), (4, 5), (4, 7), (5, 0), (5, 2), (5, 4), (5, 6),
                     (6, 1), (6, 3), (6, 5), (6, 7), (7, 0), (7, 2), (7, 4), (7, 6)]
    
    total_sum = 0
    for dx, dy in black_squares:
        total_sum += (x + dx) * (y + dy)
    
    return total_sum

# Input handling
coordinates = input().split()
x, y = int(coordinates[0]), int(coordinates[1])

# Calculate and print the sum of black squares
print(sum_black_squares(x, y))
