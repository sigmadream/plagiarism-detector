upper_left=input()
coordinate=upper_left.split()
sum=0
x=int(coordinate[0])
y=int(coordinate[1])
for i in range(8):
    for j in range(8):
        if (i+j)%2==1:
            sum+=(x+j)*(y+i)
print(sum)
    

