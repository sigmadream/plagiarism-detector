def black_squares_sum(x, y):
    return sum((x + i) * (y + j) for i in range(8) for j in range(8) if (i + j) % 2 == 1)

x, y = map(int, input().split())
print(black_squares_sum(x, y))
