line = input().split()
upper_left_x, upper_left_y = int(line[0]), int(line[1])

sum_factor = 4 * upper_left_x + 16

sum_row = 0
for y in range(upper_left_y, upper_left_y + 8):
    sum_row += y * (sum_factor if ((y - upper_left_y) % 2 == 0) else (sum_factor - 4))

print(sum_row)