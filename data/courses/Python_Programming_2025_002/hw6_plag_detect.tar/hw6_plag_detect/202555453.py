#coding: utf-8

x, y = map(int, input().split())

i = x # col
j = y # row

black_square_sum = 0



while j <= y + 7:
  if ((0 if (x + y) % 2 == 0 else 1) + (i + j)) % 2 != 0:
    black_square_sum += i*j
    # print(f"{i}*{j} = {i*j}")

  if i >= x + 7:
    i = x
    j += 1
  else:
    i += 1

print(black_square_sum)



